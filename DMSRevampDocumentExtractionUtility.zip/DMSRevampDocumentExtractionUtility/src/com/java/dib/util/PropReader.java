
/*
 * NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 * Group                                        : CDC_Mercedes_AP_Imp_IND
 * Product / Project			        : Mercedes Benz
 * Module					: AP
 * File Name					: PropReader.java
 * Author					: Joseph Premanand. M
 * Date written (DD/MM/YYYY)	                :  16 Sep 2016
 * Description				        : Contain the CSVandSAPUpload methods and ProopertyReader and to write a log.
  -----------------------------------------------------
CHANGE HISTORY
Date Change by Change Despriction(BUG NO if any)
 
 -------------------------------------------------------

 
 */
package com.java.dib.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Properties;

/**
 *
 * @author Joseph Premanand. M
 */
public class PropReader {

    private Properties reader = null;
    private static PropReader propreader = new PropReader();

    private PropReader(){
    }

    public static PropReader getInstance() {
        return propreader;
    }
    public String getValueOf(String propKey) {
        if (reader == null) {
            reader = new Properties();
            readPropertyFile();
        }
        if (!(reader.containsKey(propKey))) {
            return "";
        }
            return reader.getProperty(propKey);        
    }
    /*  Function Name              :readPropertyFile
    Input Parameters         :propertyFilePath
    Output parameters        :True/False
    Return Values            :True/False
    Description              :To readPropertyFile File
    Global variables         :
    Author                   :Joseph Premanand. M
    Date                   :12/09/2016
    * */
    public boolean readPropertyFile() {
        Logging logging = Logging.getInstance();
        int errorLog = logging.getValueOfLog("errorLog");
        String propertyFilePath = "resources\\utility.properties";
        try {
            reader.load(new FileInputStream(propertyFilePath));
            if (!(reader.getProperty("CabinetName") != null && !reader.getProperty("CabinetName").equals(""))) {
                logging.writeToLog(errorLog, "CabinetName not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("userName") != null && !reader.getProperty("userName").equals(""))) {
                logging.writeToLog(errorLog, "userName not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("Password") != null && !reader.getProperty("Password").equals(""))) {
                logging.writeToLog(errorLog, "Password not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("ServerIp") != null && !reader.getProperty("ServerIp").equals(""))) {
                logging.writeToLog(errorLog, "ServerIp not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("ServerPort") != null && !reader.getProperty("ServerPort").equals(""))) {
                logging.writeToLog(errorLog, "ServerPort not Exist in Property File");
                return false;
            }            
            if (!(reader.getProperty("WriteLogFlag") != null && !reader.getProperty("WriteLogFlag").equals(""))) {
                logging.writeToLog(errorLog, "WriteLogFlag not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("ProcessName") != null && !reader.getProperty("ProcessName").equals(""))) {
                logging.writeToLog(errorLog, "ProcessName not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("SERVERTYPE") != null && !reader.getProperty("SERVERTYPE").equals(""))) {
                logging.writeToLog(errorLog, "Server Type not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("TBL_EXTERNAL") != null && !reader.getProperty("TBL_EXTERNAL").equals(""))) {
                logging.writeToLog(errorLog, "Table not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("REPORTPATH") != null && !reader.getProperty("REPORTPATH").equals(""))) {
                logging.writeToLog(errorLog, "Report Path not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("FileName") != null && !reader.getProperty("FileName").equals(""))) {
                logging.writeToLog(errorLog, "File name not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("CSVRowCount") != null && !reader.getProperty("CSVRowCount").equals(""))) {
                logging.writeToLog(errorLog, "CSVRowCount not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("ProcessdefId") != null && !reader.getProperty("ProcessdefId").equals(""))) {
                logging.writeToLog(errorLog, "ProcessdefId not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("TBL_EXTERNAL") != null && !reader.getProperty("TBL_EXTERNAL").equals(""))) {
                logging.writeToLog(errorLog, "Table not Exist in Property File");
                return false;
            }
            if (!(reader.getProperty("PATH") != null && !reader.getProperty("PATH").equals(""))) {
                logging.writeToLog(errorLog, "Shared folder path not Exist in Property File");
                return false;
            }
        } catch (IOException ex) {
            logging.writeToLog(errorLog, "Exception in Read Property file" + ex.getMessage());
            return false;
        }
        return true;
    }
}