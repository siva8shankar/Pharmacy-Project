
/*
 * NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 * Group                                        : CDC_Mercedes_AP_Imp_IND
 * Product / Project			        : Mercedes Benz
 * Module					: AP
 * File Name					: Logging.java
 * Author					: Joseph Premanand. M
 * Date written (DD/MM/YYYY)	                :  16 Sep 2016
 * Description				        : Contain the CSVandSAPUpload methods and functions and to write a log.
  -----------------------------------------------------
CHANGE HISTORY
Date Change by Change Despriction(BUG NO if any)
 
 -------------------------------------------------------

 
 */
package com.java.dib.util;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

public class Logging {

    static int logcount = 1;
    final int xmlLog = 1;
    final int errorLog = 2;
    final int successLog = 3;
    final int statusLog = 4;
    Logger log = null;
    private static Logging logging = new Logging();

    public Logging() {
        DOMConfigurator.configure("log4j.xml");
        log = Logger.getRootLogger();
    }

    public static Logging getInstance() {
        return logging;
    }
  /*  Function Name              :getValueOfLog
    Input Parameters         :Key
    Output parameters        :Key
    Return Values            :Key
    Description              :To getValueOfLog File
    Global variables         :
    Author                   :Joseph Premanand. M
    Date                   :12/09/2016
    * */
    public int getValueOfLog(String Key) {
        if ("xmlLog".equalsIgnoreCase(Key)) {
            return xmlLog;
        } else if ("errorLog".equalsIgnoreCase(Key)) {
            return errorLog;
        } else if ("successLog".equalsIgnoreCase(Key)) {
            return successLog;
        } else if ("statusLog".equalsIgnoreCase(Key)) {
            return statusLog;
        }
        return 0;
    }
      /*  Function Name              :writeToLog
    Input Parameters         :strText
    Output parameters        :strText
    Return Values            :strText
    Description              :To writeToLog File
    Global variables         :
    Author                   :Joseph Premanand. M
    Date                   :12/09/2016
    * */

    public void writeToLog(int iLogType, String strText) {
        PropReader propreader = PropReader.getInstance();
        String writeLogFlag = propreader.getValueOf("WriteLogFlag");
        if ("Y".equalsIgnoreCase(writeLogFlag) || "Yes".equalsIgnoreCase(writeLogFlag)) {
            log.setLevel(Level.ALL);
            switch (iLogType) {
                case xmlLog:
                    log.debug(strText);
                    break;
                case errorLog:
                    log.error(strText);
                    break;
                case successLog:
                    log.info(strText);
                    break;
                case statusLog:
                    log.info(strText);
                    break;
            }
        } else {
            log.setLevel(Level.OFF);
        }
    }


}
