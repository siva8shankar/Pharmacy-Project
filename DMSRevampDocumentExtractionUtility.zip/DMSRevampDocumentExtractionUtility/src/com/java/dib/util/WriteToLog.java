/*
 * NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 * Group                                        : CDC_Mercedes_AP_Imp_IND
 * Product / Project			        : Mercedes Benz
 * Module					: AP
 * File Name					: WriteToLog.java
 * Author					: Joseph Premanand. M
 * Date written (DD/MM/YYYY)	                :  16 Sep 2016
 * Description				        : Contain the CSVandSAPUpload methods and SAPFunctions then write to log.
  -----------------------------------------------------
CHANGE HISTORY
Date Change by Change Despriction(BUG NO if any)
 
 -------------------------------------------------------

 
 */
//package VendorUpload;
package com.java.dib.util;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.*;
public class WriteToLog 
{
     private PrintWriter log;
     static private WriteToLog instance; 
	 String path ="";
     Calendar calendar = Calendar.getInstance();

	 static synchronized public WriteToLog getInstance() 
	 {
        if (instance == null)
			{
				instance = new WriteToLog();
            }
        return instance;
     }
     public WriteToLog() 
	  {
        init();
      }

     /*  Function Name              :init
    Input Parameters         :projectRoot
    Output parameters        :projectRoot
    Return Values            :
    Description              :To init File
    Global variables         :
    Author                   :Joseph Premanand. M
    Date                   :12/09/2016
    * */
     public void init()
	 {
       Properties dbProps = new Properties();
	   String projectRoot = System.getProperty("user.dir");
	   //System.out.println("projectRoot==>"+projectRoot);
	   String result = projectRoot +"\\Log";
	   //System.out.println("result==>"+result);
       boolean exists=(new File(result)).exists();
       if(exists)
		  {
           
           path =projectRoot +"\\Log"+"\\Log"+ "_" +calendar.get(5)+ "_" + (calendar.get(2) + 1) + "_" + calendar.get(1)+"[1]"+".log";
		   //System.out.println("path==>"+path);
          }
       else
		  {
           
            boolean created=new File(result).mkdir();
			path =projectRoot +"\\Log"+"\\Log"+ "_" +calendar.get(5)+ "_" + (calendar.get(2) + 1) + "_" + calendar.get(1)+"[1]"+".log";
			
          }

          File file					= new File(path);
		  try
		  {
			  boolean success = file.createNewFile();
			  if (success) 
			  {
				//System.out.println(" New File was created");
			  }
			  else 
			  {
				//System.out.println(" New File was not created");
			  }
			  }
		  catch (Exception e)
		  {
			  System.out.println("Error While Creating New File:"+e);
		  }
		  /////
          String logFile = dbProps.getProperty("logfile", path);
		  try 
		  {
				log = new PrintWriter(new FileWriter(logFile, true), true);
		  }
		  catch (IOException e)
		  {
				System.err.println("Can't Open the log file: " +logFile);
				log = new PrintWriter(System.err);
		  }
  
		  /////
 	  	  long len1=0;
		  long len=file.length();
		  len1=len;
		  File dir = new File(projectRoot +"\\Log");
    	 
		  String[] children  = dir.list();
		  int j              = 0;
		  String day         = "";
		  String mon         = "";
		  String year        = "";
		  String binlogpath1 = "";
		  String name        = "";
		  String Numvalue    = "";
		  String NumVal	     = "";
		  if (children == null)
		  {
			System.out.println("No file exits in the directory");
		  }
		  else 
		  {
				for (int i=0; i<children.length; i++) 
				{
					int index1 = children[i].indexOf("Error");
					//System.out.println("index1==>"+index1);
				   
					if(index1!=-1)
					{ 
						StringTokenizer stn   = new StringTokenizer(children[i],"_");
						//System.out.println("children[i]==>"+children[i]);
						while(stn.hasMoreTokens())
						{
							name= stn.nextToken();
							//System.out.println("name==>"+name);
							/*if(stn.hasMoreTokens())
							{
							String name1=stn.nextToken();
							System.out.println("name1==>"+name1);
							}*/
							if(stn.hasMoreTokens())
							{
							day= stn.nextToken();
							//System.out.println("day==>"+day);
							}
							if(stn.hasMoreTokens())
							{
							mon= stn.nextToken();
							//System.out.println("mon==>"+mon);
							}
							if(stn.hasMoreTokens())
							{
								year= stn.nextToken();
								StringTokenizer stn1   = new StringTokenizer(year,"[");
								if(stn1.hasMoreTokens())
								{
								year	 = stn1.nextToken();
								Numvalue = stn1.nextToken();
								//System.out.println("year==>"+year);
								}
								StringTokenizer stnVal   = new StringTokenizer(Numvalue,"]");
								if(stnVal.hasMoreTokens())
								{
								NumVal=stnVal.nextToken();
								//System.out.println("year==>"+year);
								}
						    }
				       }
				String xx=(calendar.get(2) + 1)+"/"+calendar.get(5)+"/"+calendar.get(1); //get the current date string
                //System.out.println("xx"+xx);
				
				String yy=mon+"/"+day+"/"+year;
				//System.out.println("yy"+yy);
				long tt1=GetDateDiff(xx,yy);
				
				path = projectRoot +"\\Log"+ "\\" +children[i];	
				
				file	   = new File(path); 
				if(tt1 >= 345600000 ) // For 4 days log file will be there
				{
				file.delete();
				}
				else
				{

				if(tt1 == 0)
				{
				if(file.length() > (5*1024*1024)) // Size of the each file will be 5 MB
				{
				binlogpath1 = projectRoot +"\\Log"+"\\Log"+"_"+calendar.get(5)+ "_" + (calendar.get(2) + 1) + "_" + calendar.get(1)+"["+(Integer.parseInt(NumVal)+1)+"]"+".log";
				
				}
				else
				{
					binlogpath1=path;
					
				}
 			  }
			}
		  }
		}
				path=binlogpath1;

	}
}////End
    

/*  Function Name              :GetDateDiff
    Input Parameters         :x,y
    Output parameters        :differ
    Return Values            :differ
    Description              :To GetDateDiff File
    Global variables         :
    Author                   :Joseph Premanand. M
    Date                   :12/09/2016
    * */
public long  GetDateDiff(String x,String y)
{ 
	Date dateN=null;
	Date dateM=null;
	try 
	{
		SimpleDateFormat df=new SimpleDateFormat("MM/dd/yyyy");
		dateN=df.parse(x);
		dateM=df.parse(y);
		
	}
	catch (Exception err)
	{
      err.printStackTrace();
	}
		long differ= (dateN.getTime() - dateM.getTime());
		
		return differ;
}


public void log(String msg)
{
   WriteToLog lWriteToLog=null;
   try
   {
	   lWriteToLog=new WriteToLog();
	   //String packageName = lWriteToLog.getClass().getPackage().getName();
	   String packageName = lWriteToLog.getClass().getName();
	   log.println(packageName+"::"+new Date()+": " + msg);		   
   }
   catch (Exception e)
   {
	  System.out.println("In  File:WriteToLog And Function:log:: Exception......"+e.getMessage()); 
   }
   finally
   {
		if(lWriteToLog!=null)
		{
			lWriteToLog=null;
			
		}

	}
}
     
private void log(Throwable e, String msg) 
{
      log.println(new Date()+": " + msg);
      e.printStackTrace(log);
}
public static void main(String a[])
	{
      WriteToLog lWriteToLog= new WriteToLog();
    
	}
	
}

