/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.java.dib.util;

import static com.java.dib.util.DMSRevampDocumentExtractionUtility.mErrLogger;
import static com.java.dib.util.DMSRevampDocumentExtractionUtility.mRepLogger;
import static com.java.dib.util.DMSRevampDocumentExtractionUtility.mXMLLogger;
import com.newgen.dmsapi.DMSXmlList;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 *
 * @author KS.Sivashankar
 */
public class CommonMethods {

    File IniFile = null;
    FileInputStream fi = null;
    Properties prop = null;
    String NG_SUCCESS = "SUCCESS";
    String NG_FAIL = "FAIL";
    String NG_EXCEPTION = "";
    String strPropertyPath = "";
    String Xmlout = "";
    DMSXmlList xmlList = null;
    StringBuffer strBuffer = null;
    String strIP = "";
    String strPort = "";
    int iPort;
    int FileCount;
    String strAppServerType = "";
    String strCabName = "";
    String strUsername = "";
    String strPwd = "";
    String strXLSXFilePath = "";
    String strExceptionPath = "";
    String strSessionId = "";
    Sheet sheet1 = null;
    Row row = null;
    Cell Cell = null;
    String sAttributes = "";

    public String ReadProperty() {
        try {
            strPropertyPath = System.getProperty("user.dir") + File.separator + "Settings.ini";
            IniFile = new File(strPropertyPath);
            FileInputStream File_Ini = new FileInputStream(strPropertyPath);
            prop = new Properties();
            prop.load(File_Ini);
        } catch (FileNotFoundException fe) {
            System.out.println(" \n### configuration file " + fi + " not found ");
            mErrLogger.info("\nProperties file " + fi + " not found\n" + "Exception in configuration file : " + fe);
            return NG_FAIL;
        } catch (IOException e) {
            System.out.println(" \n###  **[Error]**  Error in configuration file");
            mErrLogger.info("\nError in configuration file " + fi + "Exception in configuration file : " + e);
            return NG_FAIL;
        }

        try {
            if (IniFile.exists()) {
                mRepLogger.info("Start Reading INI File ..........");
                if ((prop.getProperty("AppServerIP") != null) && (!prop.getProperty("AppServerIP").equals(""))) {
                    strIP = prop.getProperty("AppServerIP").trim();
                } else {
                    //System.out.println("\n[ERROR] Login Username not specified in the configuration file.");
                    mErrLogger.info("\n[ERROR] AppServerIP not specified in the Settings.ini file.");
                    return NG_FAIL;
                }
                if ((prop.getProperty("AppServerPort") != null) && (!prop.getProperty("AppServerPort").equals(""))) {
                    strPort = prop.getProperty("AppServerPort").trim();
                } else {
                    //System.out.println("\n[ERROR] Login Username not specified in the configuration file.");
                    mErrLogger.info("\n[ERROR] AppServerPort not specified in the Settings.ini file.");
                    return NG_FAIL;
                }
                iPort = Integer.parseInt(strPort);
                if ((prop.getProperty("AppServerType") != null) && (!prop.getProperty("AppServerType").equals(""))) {
                    strAppServerType = prop.getProperty("AppServerType").trim();
                } else {
                    //System.out.println("\n[ERROR] Login Username not specified in the configuration file.");
                    mErrLogger.info("\n[ERROR] AppServerType not specified in the Settings.ini file.");
                    return NG_FAIL;
                }

                if ((prop.getProperty("CabinetName") != null) && (!prop.getProperty("CabinetName").equals(""))) {
                    strCabName = prop.getProperty("CabinetName").trim();
                } else {
                    //System.out.println("\n[ERROR] Login Username not specified in the configuration file.");
                    mErrLogger.info("\n[ERROR] CabinetName not specified in the Settings.ini file.");
                    return NG_FAIL;
                }
                if ((prop.getProperty("UserName") != null) && (!prop.getProperty("UserName").equals(""))) {
                    strUsername = prop.getProperty("UserName").trim();
                } else {
                    //System.out.println("\n[ERROR] Login Username not specified in the configuration file.");
                    mErrLogger.info("\n[ERROR] UserName not specified in the Settings.ini file.");
                    return NG_FAIL;
                }
                if ((prop.getProperty("Password") != null) && (!prop.getProperty("Password").equals(""))) {
                    strPwd = prop.getProperty("Password").trim();
                } else {
                    //System.out.println("\n[ERROR] Login Username not specified in the configuration file.");
                    mErrLogger.info("\n[ERROR] Password not specified in the Settings.ini file.");
                    return NG_FAIL;
                }
                if ((prop.getProperty("XLSXFilePath") != null) && (!prop.getProperty("XLSXFilePath").equals(""))) {
                    strXLSXFilePath = prop.getProperty("XLSXFilePath").trim();
                } else {
                    System.out.println("\n[ERROR] XLSXFilePath not specified in the configuration file.");
                    mErrLogger.info("\n[ERROR] XLSXFilePath not specified in the Settings.ini file.");
                    return NG_FAIL;
                }
                mRepLogger.info("Ends Reading INI File ..........");
            } else {
                mRepLogger.info("No Property file exist in " + strPropertyPath);
                return NG_FAIL;
            }
        } catch (Exception e) {
            mErrLogger.info("\n\n### **[Error]** Exception in ReadProperty " + e);
        }
        System.out.println(" strIP = " + strIP + " \n XLSXFilePath = " + strXLSXFilePath);
        return NG_SUCCESS;
    }

    public boolean conCabinet() {

        DMSXmlResponse xmlResponse = null;
        Xmlout = "";
        String WIName = "";
        String InsuranceType = "";
        String Status = "";
        String PolicyNo = "";
        String dbactionselstatus = "";
        try {
            //strPwd = decrypt(strPwd);
            strBuffer = new StringBuffer();
            strBuffer.append("<?xml version=1.0?>");
            strBuffer.append("<NGOConnectCabinet_Input>");
            strBuffer.append("<Option>NGOConnectCabinet</Option>");
            strBuffer.append("<CabinetName>" + strCabName + "</CabinetName>");
            strBuffer.append("<UserName>" + strUsername + "</UserName>");
            strBuffer.append("<UserPassword>" + strPwd + "</UserPassword>");
            strBuffer.append("<UserExist>N</UserExist>");
            strBuffer.append("</NGOConnectCabinet_Input>");
            mXMLLogger.info("ConnectCabinet InputXML:\n" + strBuffer.toString());
            Xmlout = WFCallBroker.execute(strBuffer.toString(), strIP, iPort, 0);
            mXMLLogger.info("ConnectCabinet OutputXML:\n" + Xmlout);
            //encrypt("system123#");
            xmlResponse = new DMSXmlResponse(Xmlout);
            if (xmlResponse.getVal("status").equals("0")) {
                strSessionId = xmlResponse.getVal("UserDBId");
                mRepLogger.info("Cabinet Connected successfully ....." + strSessionId);
                return true;
            } else {

                mRepLogger.info("Problem in Connecting Cabinet : " + xmlResponse.getVal("Error"));
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();
            mRepLogger.info("\n\n### **[Error]** Exception in Connecting Cabinet : " + e);
            return false;
        }
    }

    public void DisconCabinet() {
        DMSXmlResponse xmlResponse = null;
        Xmlout = "";
        try {
            strBuffer = new StringBuffer();
            strBuffer.append("<?xml version='1.0'?>");
            strBuffer.append("<NGODisconnectCabinet_Input>");
            strBuffer.append("<Option>NGODisconnectCabinet</Option>");
            strBuffer.append("<CabinetName>" + strCabName + "</CabinetName>");
            strBuffer.append("<UserDBId>" + strSessionId + "</UserDBId>");
            strBuffer.append("</NGODisconnectCabinet_Input>");
            Xmlout = WFCallBroker.execute(strBuffer.toString(), strIP, iPort, 0);
            mXMLLogger.info("Disconnect Cabinet InputXML:\n" + strBuffer.toString());
            mXMLLogger.info("Disconnect Cabinet OutputXMLt:\n" + Xmlout);
            xmlResponse = new DMSXmlResponse(Xmlout);
            if (xmlResponse.getVal("Status").equals("0")) {
                mRepLogger.info("Cabinet Disconnected Successfully ...");
            } else {
                mRepLogger.info("Problem in Disconnecting cabinet:" + xmlResponse.getVal("Error"));
            }
        } catch (Exception e) {
            mRepLogger.info("\n\n### **[Error]** Exception in Disconnecting cabinet : " + e);
        }
    }

    public String readXLSXFile(String strExceptionPath) throws FileNotFoundException, IOException {
        mRepLogger.info("~~~~~~~~~~~~~~~~~~readXLSXFile Method Starts of DMSRevampDocumentExtractionUtility ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        //ReadXLS objReadxls = new ReadXLS();
        String sts="false";
        Workbook workbook = null;
        HashMap<String, ArrayList<String>> dataMap = new HashMap<>();
        ArrayList<String> strArr=null;
//            boolean check = conCabinet();
//            if (check) {
                try {
                    FileInputStream file = new FileInputStream(new File(strExceptionPath));
                    mRepLogger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    mErrLogger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    Date d = new Date();
                    Long l = d.getTime();
                    try {
                        boolean blankFile = false;
                        workbook = WorkbookFactory.create(file);
                        sheet1 = workbook.getSheetAt(0);
                        int noOfRows = sheet1.getLastRowNum();
                        mRepLogger.info("Reading Sheet. No of rows :" + noOfRows);
                        System.out.println("Reading Sheet. No of rows :" + noOfRows);
                        if (noOfRows == 0) {
                            blankFile = true;
                        }
                        if ((sheet1.getRow(0) != null && noOfRows != 0)) {
                            for (int i = 1; i <= noOfRows; i++) {
                                Boolean rowmpty = isRowEmpty(sheet1.getRow(i));
                                if (!rowmpty) {
                                    mRepLogger.info("Row No is : " + i);
                                    int noOfCols = sheet1.getRow(i).getLastCellNum();
                                    mRepLogger.info("Reading Sheet. No of Columns :" + noOfCols);
                                     System.out.println("Reading Sheet. No of Columns :" + noOfCols);
                                    System.out.println("Row No is : " + i);
                                    for (int j = 0; j < noOfCols; j++) {
                                        mRepLogger.info("Column No is : " + j);
                                        System.out.println("Column No is : " + j);
                                        Cell = sheet1.getRow(i).getCell(j);
                                         mRepLogger.info("Cell Value is ( "+ i + ","+ j+" ): " + Cell);
                                         System.out.println("Cell Value is ( "+ i + ","+ j+" ):  " + Cell);
                                         strArr.add(getCellValueAsString(Cell));
                                         System.out.println("test1");
                                    }
//                                    System.out.println(strArr);
                                }
                                
//                                sAttributes = "";
//                                HashMap<String, String> hattributes = new HashMap<String, String>();

                                System.out.println("test2");
                            dataMap.put(Integer.toString(i), strArr);
                            strArr=null;
                            }
                        }

                    } catch (Exception e) {
                        mErrLogger.info("Exception in ReadFiles():" + e);
                    }
                    file.close();
                    System.out.println("Testing Results Start \n");
                    for (String key : dataMap.keySet()) {
                        ArrayList<String> values = dataMap.get(key);
                        System.out.println("Key: " + key + " -> Values: ");
                        for (String value : values) {
                            System.out.println(value);
                        }
                    }
                    System.out.println("Testing Results Ends \n");
                } catch (Exception e) {
                    mErrLogger.info("Exception in ReadFiles():" + e);
                }
                
//                DisconCabinet();
//            }
        sts="true";
        return sts;
    }
    
    
    public boolean isRowEmpty(Row row) throws NullPointerException {
        try {
            for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
                Cell cell = row.getCell(c);
                if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK) {
                    return false;
                }
            }
        } catch (Exception e) {
            mErrLogger.info("Exception in isRowEmpty:" + e);
            System.out.println("Exception in isRowEmpty:" + e);
        }
        return true;
    }
    
    // Function to convert cell to String
    public static String getCellValueAsString(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                // Check if the numeric cell is actually a date
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString(); // Convert date to string
                } else {
                    return String.valueOf(cell.getNumericCellValue()); // Convert number to string
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                // If the cell contains a formula, return the formula itself or its evaluated value
                return cell.getCellFormula();
            case BLANK:
                return "";  // Return empty string for blank cells
            default:
                return "Unknown Cell Type";  // Handle unknown types
        }
    }

}
