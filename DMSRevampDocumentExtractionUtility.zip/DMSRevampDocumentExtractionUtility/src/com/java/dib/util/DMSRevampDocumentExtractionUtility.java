/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.java.dib.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author KS.Sivashankar
 */
public class DMSRevampDocumentExtractionUtility {

    public static org.apache.log4j.Logger mXMLLogger = org.apache.log4j.Logger.getLogger("mLogger");
    public static org.apache.log4j.Logger mRepLogger = org.apache.log4j.Logger.getLogger("Reportlog");
    public static org.apache.log4j.Logger mErrLogger = org.apache.log4j.Logger.getLogger("Errorlog");
    static String mstrlog4jConfigFilePath = "";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mRepLogger.info("~~~~~~~~~~~~~~~~~~main Method Starts of DMSRevampDocumentExtractionUtility ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        // TODO code application logic here
        try {
            CommonMethods comObj = new CommonMethods();
            DMSRevampDocumentExtractionUtility.InitLog();
            mRepLogger.info("~~~~~~~~~~~~~~~~~~ReadProperty Method Starts of DMSRevampDocumentExtractionUtility ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            String Status = comObj.ReadProperty();
            mRepLogger.info("~~~~~~~~~~~~~~~~~~ReadProperty Method Ends of DMSRevampDocumentExtractionUtility ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            if (Status.equalsIgnoreCase(comObj.NG_SUCCESS)) {
                mRepLogger.info("~~~~~~~~~~~~~~~~~~ReadProperty Method Success of DMSRevampDocumentExtractionUtility ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                String strStatus = "";
                try {
                    strStatus = comObj.readXLSXFile(comObj.strXLSXFilePath);
                } catch (Exception e) {
                    System.out.println("Exception Occurred in the ReadXLSXAndMoveFiles:: " + e);
                }
                System.out.println("strStatus from ReadXLSXAndMoveFiles :: " + strStatus);
                if (strStatus.equalsIgnoreCase("SUCCESS")) {
                    System.out.println("ReadXLSXAndMoveFiles is Completed Successfully");
                } else {
                    System.out.println("Invalid Excel,Kindly Check the Excel File values.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        mRepLogger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        mErrLogger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        mXMLLogger.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    /*
     * Function Name        : InitLog
     * Input Parameters     : None
     * Output parameters    : None
     * Return Values        : None
     * Description          : This function is called for initallization log4j.properties file
     * Global variables     : mstrlog4jConfigFilePath
     */
    private static void InitLog() {
        try {

            mstrlog4jConfigFilePath = System.getProperty("user.dir") + System.getProperty("file.separator") + "Config"
                    + System.getProperty("file.separator") + "log4j.properties";
            File lobjFile = new File(mstrlog4jConfigFilePath);
            if (!lobjFile.exists()) {
                mRepLogger.info("Logger Config file doesnot exists !"
                        + mstrlog4jConfigFilePath);
            } else {
                ConfigureLogger(mstrlog4jConfigFilePath);
            }
            lobjFile = null;

        } catch (Exception lobjExcp) {
            mErrLogger.info("Exception Occurs during Logger Initialization: "
                    + lobjExcp.toString());
        }
    }

    /*
     * Function Name        : ConfigureLogger
     * Input Parameters     : None
     * Output parameters    : None
     * Return Values        : None
     * Description          : This function is called for configure the Logger file
     * Global variables     : mstrlog4jConfigFilePath
     */
    public static void ConfigureLogger(String plog4jConfigFilePath) throws Exception {
        String lExceptionId = new String("com.newgen.lns.myqueue.process.configureLogger.");
        try {
            FileInputStream lobjFileInputStream = null;
            lobjFileInputStream = new FileInputStream(plog4jConfigFilePath);
            Properties lobjPropertiesINI = new Properties();
            lobjPropertiesINI.load(lobjFileInputStream);
            lobjPropertiesINI = LoadProperties(lobjPropertiesINI);
            PropertyConfigurator propertyConfigurator = new PropertyConfigurator();
            propertyConfigurator.doConfigure(lobjPropertiesINI, LogManager.getLoggerRepository());
        } catch (Exception lobjExcp) {
            mErrLogger.info(lExceptionId + ": Exception occurs during Logger Initialization: "
                    + lobjExcp.toString());
            throw lobjExcp;
        }

    }

    /*
     * Function Name        : LoadProperties
     * Input Parameters     : pobjProperties as Properties
     * Output parameters    : LoadProperties
     * Return Values        : Properties
     * Description          : This function is called for read the Logger property file
     */
    private static Properties LoadProperties(Properties pobjProperties)
            throws Exception {
        Properties lobjProperties = pobjProperties;
        try {
            Enumeration lobjEnumeration = null;
            lobjEnumeration = lobjProperties.keys();

            while (lobjEnumeration.hasMoreElements()) {
                String s1 = ((String) lobjEnumeration.nextElement()).trim();
                if (!s1.startsWith("log4j.logger.")) {
                    continue;
                }
                String s4 = lobjProperties.getProperty(s1);
                StringTokenizer stringtokenizer = new StringTokenizer(s4, ",");

                while (stringtokenizer.hasMoreTokens()) {
                    String s7 = stringtokenizer.nextToken();
                    String s2 = "log4j.appender." + s7.trim() + ".File";
                    String str1 = lobjProperties.getProperty(s2);
                }

                stringtokenizer = null;
            }

        } catch (Exception lobjExcp) {
            mErrLogger.info("LoadProperties : Exception occurs during Logger Initialization: " + lobjExcp.toString());
            throw lobjExcp;
        }

        return lobjProperties;
    }

}
