/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class CNFRoomDetails {
    String SNO,dateofrequest,RoomLocation,RoomName, FullAddress, RoomType, RoomCapacity, CareTakerDetails, Remarks, BookingDate, BookedBy, EmpDepartment, BookedFor, FromTime, ToTime, NoOfParticipants
            ,EmployeeNumber,empUserID,EmployeeName,EmailID,ContactNumber,Region,VendorCode,VendorGL,Designation,Grade,WorkLocation,CostCenter,RepManager,HRBPName,HRBPUserID,RMUserID,ExtNumber,bookingRoomStatus,amenitiesAvailable,meetingDescription,remarks,ContactDetails,InitiationType, State, adminMailID, ccColumn;

    public String getRoomLocation() {
        return RoomLocation;
    }

    public void setRoomLocation(String RoomLocation) {
        this.RoomLocation = RoomLocation;
    }

    public String getRoomName() {
        return RoomName;
    }

    public void setRoomName(String RoomName) {
        this.RoomName = RoomName;
    }

    public String getFullAddress() {
        return FullAddress;
    }

    public void setFullAddress(String FullAddress) {
        this.FullAddress = FullAddress;
    }

    public String getRoomType() {
        return RoomType;
    }

    public void setRoomType(String RoomType) {
        this.RoomType = RoomType;
    }

    public String getRoomCapacity() {
        return RoomCapacity;
    }

    public void setRoomCapacity(String RoomCapacity) {
        this.RoomCapacity = RoomCapacity;
    }

    public String getCareTakerDetails() {
        return CareTakerDetails;
    }

    public void setCareTakerDetails(String CareTakerDetails) {
        this.CareTakerDetails = CareTakerDetails;
    }

    public String getRemarks() {
        return Remarks;
    }

    public void setRemarks(String Remarks) {
        this.Remarks = Remarks;
    }

    public String getBookingDate() {
        return BookingDate;
    }

    public void setBookingDate(String BookingDate) {
        this.BookingDate = BookingDate;
    }

    public String getBookedBy() {
        return BookedBy;
    }

    public void setBookedBy(String BookedBy) {
        this.BookedBy = BookedBy;
    }

    public String getEmpDepartment() {
        return EmpDepartment;
    }

    public void setEmpDepartment(String EmpDepartment) {
        this.EmpDepartment = EmpDepartment;
    }

    public String getBookedFor() {
        return BookedFor;
    }

    public void setBookedFor(String BookedFor) {
        this.BookedFor = BookedFor;
    }

    public String getFromTime() {
        return FromTime;
    }

    public void setFromTime(String FromTime) {
        this.FromTime = FromTime;
    }

    public String getToTime() {
        return ToTime;
    }

    public void setToTime(String ToTime) {
        this.ToTime = ToTime;
    }

    public String getNoOfParticipants() {
        return NoOfParticipants;
    }

    public void setNoOfParticipants(String NoOfParticipants) {
        this.NoOfParticipants = NoOfParticipants;
    }

    public String getEmployeeNumber() {
        return EmployeeNumber;
    }

    public void setEmployeeNumber(String EmployeeNumber) {
        this.EmployeeNumber = EmployeeNumber;
    }

    public String getEmpUserID() {
        return empUserID;
    }

    public void setEmpUserID(String empUserID) {
        this.empUserID = empUserID;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String EmployeeName) {
        this.EmployeeName = EmployeeName;
    }

    public String getEmailID() {
        return EmailID;
    }

    public void setEmailID(String EmailID) {
        this.EmailID = EmailID;
    }

    public String getContactNumber() {
        return ContactNumber;
    }

    public void setContactNumber(String ContactNumber) {
        this.ContactNumber = ContactNumber;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getVendorCode() {
        return VendorCode;
    }

    public void setVendorCode(String VendorCode) {
        this.VendorCode = VendorCode;
    }

    public String getVendorGL() {
        return VendorGL;
    }

    public void setVendorGL(String VendorGL) {
        this.VendorGL = VendorGL;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String Designation) {
        this.Designation = Designation;
    }

    public String getGrade() {
        return Grade;
    }

    public void setGrade(String Grade) {
        this.Grade = Grade;
    }

    public String getWorkLocation() {
        return WorkLocation;
    }

    public void setWorkLocation(String WorkLocation) {
        this.WorkLocation = WorkLocation;
    }

    public String getCostCenter() {
        return CostCenter;
    }

    public void setCostCenter(String CostCenter) {
        this.CostCenter = CostCenter;
    }

    public String getRepManager() {
        return RepManager;
    }

    public void setRepManager(String RepManager) {
        this.RepManager = RepManager;
    }

    public String getHRBPName() {
        return HRBPName;
    }

    public void setHRBPName(String HRBPName) {
        this.HRBPName = HRBPName;
    }

    public String getHRBPUserID() {
        return HRBPUserID;
    }

    public void setHRBPUserID(String HRBPUserID) {
        this.HRBPUserID = HRBPUserID;
    }

    public String getRMUserID() {
        return RMUserID;
    }

    public void setRMUserID(String RMUserID) {
        this.RMUserID = RMUserID;
    }

    public String getExtNumber() {
        return ExtNumber;
    }

    public void setExtNumber(String ExtNumber) {
        this.ExtNumber = ExtNumber;
    }

    public String getBookingRoomStatus() {
        return bookingRoomStatus;
    }

    public void setBookingRoomStatus(String bookingRoomStatus) {
        this.bookingRoomStatus = bookingRoomStatus;
    }

    public String getAmenitiesAvailable() {
        return amenitiesAvailable;
    }

    public void setAmenitiesAvailable(String amenitiesAvailable) {
        this.amenitiesAvailable = amenitiesAvailable;
    }

    public String getMeetingDescription() {
        return meetingDescription;
    }

    public void setMeetingDescription(String meetingDescription) {
        this.meetingDescription = meetingDescription;
    }

    public String getContactDetails() {
        return ContactDetails;
    }

    public void setContactDetails(String ContactDetails) {
        this.ContactDetails = ContactDetails;
    }

    public String getInitiationType() {
        return InitiationType;
    }

    public void setInitiationType(String InitiationType) {
        this.InitiationType = InitiationType;
    }

    public String getDateofrequest() {
        return dateofrequest;
    }

    public void setDateofrequest(String dateofrequest) {
        this.dateofrequest = dateofrequest;
    }

    public String getSNO() {
        return SNO;
    }

    public void setSNO(String SNO) {
        this.SNO = SNO;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getAdminMailID() {
        return adminMailID;
    }

    public void setAdminMailID(String adminMailID) {
        this.adminMailID = adminMailID;
    }

    public String getCcColumn() {
        return ccColumn;
    }

    public void setCcColumn(String ccColumn) {
        this.ccColumn = ccColumn;
    }
    
    
    
}
