/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class HelpDeskPortalFields {
    String PID,EmployeeNumber,EmployeeName,CorporateFunction,HRFunction,Gender,EmailID,WorkLocation,TicketFunction,TicketCategory,TicketSubCategory,TicketAssigningUser,TicketSubject,TicketPriority,TicketContactNumber,TicketMessage,Department,Region,VendorCode,VendorGL,Designation,Grade,OriginalLocation,Category,ticketAssigningUserFullName,InitBy;

    public String getPID() {
        return PID;
    }

    public void setPID(String PID) {
        this.PID = PID;
    }

    public String getEmployeeNumber() {
        return EmployeeNumber;
    }

    public void setEmployeeNumber(String EmployeeNumber) {
        this.EmployeeNumber = EmployeeNumber;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String EmployeeName) {
        this.EmployeeName = EmployeeName;
    }

    public String getCorporateFunction() {
        return CorporateFunction;
    }

    public void setCorporateFunction(String CorporateFunction) {
        this.CorporateFunction = CorporateFunction;
    }

    public String getHRFunction() {
        return HRFunction;
    }

    public void setHRFunction(String HRFunction) {
        this.HRFunction = HRFunction;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getEmailID() {
        return EmailID;
    }

    public void setEmailID(String EmailID) {
        this.EmailID = EmailID;
    }

    public String getWorkLocation() {
        return WorkLocation;
    }

    public void setWorkLocation(String WorkLocation) {
        this.WorkLocation = WorkLocation;
    }

    public String getTicketFunction() {
        return TicketFunction;
    }

    public void setTicketFunction(String TicketFunction) {
        this.TicketFunction = TicketFunction;
    }

    public String getTicketCategory() {
        return TicketCategory;
    }

    public void setTicketCategory(String TicketCategory) {
        this.TicketCategory = TicketCategory;
    }

    public String getTicketSubCategory() {
        return TicketSubCategory;
    }

    public void setTicketSubCategory(String TicketSubCategory) {
        this.TicketSubCategory = TicketSubCategory;
    }

    public String getTicketAssigningUser() {
        return TicketAssigningUser;
    }

    public void setTicketAssigningUser(String TicketAssigningUser) {
        this.TicketAssigningUser = TicketAssigningUser;
    }

    public String getTicketSubject() {
        return TicketSubject;
    }

    public void setTicketSubject(String TicketSubject) {
        this.TicketSubject = TicketSubject;
    }

    public String getTicketPriority() {
        return TicketPriority;
    }

    public void setTicketPriority(String TicketPriority) {
        this.TicketPriority = TicketPriority;
    }

    public String getTicketContactNumber() {
        return TicketContactNumber;
    }

    public void setTicketContactNumber(String TicketContactNumber) {
        this.TicketContactNumber = TicketContactNumber;
    }

    public String getTicketMessage() {
        return TicketMessage;
    }

    public void setTicketMessage(String TicketMessage) {
        this.TicketMessage = TicketMessage;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getVendorCode() {
        return VendorCode;
    }

    public void setVendorCode(String VendorCode) {
        this.VendorCode = VendorCode;
    }

    public String getVendorGL() {
        return VendorGL;
    }

    public void setVendorGL(String VendorGL) {
        this.VendorGL = VendorGL;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String Designation) {
        this.Designation = Designation;
    }

    public String getGrade() {
        return Grade;
    }

    public void setGrade(String Grade) {
        this.Grade = Grade;
    }

    public String getOriginalLocation() {
        return OriginalLocation;
    }

    public void setOriginalLocation(String OriginalLocation) {
        this.OriginalLocation = OriginalLocation;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String Category) {
        this.Category = Category;
    }

    public String getTicketAssigningUserFullName() {
        return ticketAssigningUserFullName;
    }

    public void setTicketAssigningUserFullName(String ticketAssigningUserFullName) {
        this.ticketAssigningUserFullName = ticketAssigningUserFullName;
    }

    public String getInitBy() {
        return InitBy;
    }

    public void setInitBy(String InitBy) {
        this.InitBy = InitBy;
    }
    
    
}
