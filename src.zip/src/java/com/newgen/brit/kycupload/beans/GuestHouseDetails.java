/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class GuestHouseDetails {
    String Location, FullAddress, ReservationsBy, ContactDetails, CareTakerDetails, NoOfSingleOccupancy, NoOfDoubleOccupancy, NoOfTotalOccupancy, Remarks, RegionalAdmin,RegionalAdminEmail,GUESTHOUSE_USEREMAIL,CABREQ_USEREMAIL;

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public String getFullAddress() {
        return FullAddress;
    }

    public void setFullAddress(String FullAddress) {
        this.FullAddress = FullAddress;
    }

    public String getReservationsBy() {
        return ReservationsBy;
    }

    public void setReservationsBy(String ReservationsBy) {
        this.ReservationsBy = ReservationsBy;
    }

    public String getContactDetails() {
        return ContactDetails;
    }

    public void setContactDetails(String ContactDetails) {
        this.ContactDetails = ContactDetails;
    }

    public String getCareTakerDetails() {
        return CareTakerDetails;
    }

    public void setCareTakerDetails(String CareTakerDetails) {
        this.CareTakerDetails = CareTakerDetails;
    }

    public String getNoOfSingleOccupancy() {
        return NoOfSingleOccupancy;
    }

    public void setNoOfSingleOccupancy(String NoOfSingleOccupancy) {
        this.NoOfSingleOccupancy = NoOfSingleOccupancy;
    }

    public String getNoOfDoubleOccupancy() {
        return NoOfDoubleOccupancy;
    }

    public void setNoOfDoubleOccupancy(String NoOfDoubleOccupancy) {
        this.NoOfDoubleOccupancy = NoOfDoubleOccupancy;
    }

    public String getNoOfTotalOccupancy() {
        return NoOfTotalOccupancy;
    }

    public void setNoOfTotalOccupancy(String NoOfTotalOccupancy) {
        this.NoOfTotalOccupancy = NoOfTotalOccupancy;
    }

    public String getRemarks() {
        return Remarks;
    }

    public void setRemarks(String Remarks) {
        this.Remarks = Remarks;
    }

    public String getRegionalAdmin() {
        return RegionalAdmin;
    }

    public void setRegionalAdmin(String RegionalAdmin) {
        this.RegionalAdmin = RegionalAdmin;
    }

    public String getRegionalAdminEmail() {
        return RegionalAdminEmail;
    }

    public void setRegionalAdminEmail(String RegionalAdminEmail) {
        this.RegionalAdminEmail = RegionalAdminEmail;
    }

    public String getGUESTHOUSE_USEREMAIL() {
        return GUESTHOUSE_USEREMAIL;
    }

    public void setGUESTHOUSE_USEREMAIL(String GUESTHOUSE_USEREMAIL) {
        this.GUESTHOUSE_USEREMAIL = GUESTHOUSE_USEREMAIL;
    }

    public String getCABREQ_USEREMAIL() {
        return CABREQ_USEREMAIL;
    }

    public void setCABREQ_USEREMAIL(String CABREQ_USEREMAIL) {
        this.CABREQ_USEREMAIL = CABREQ_USEREMAIL;
    }
    
    
}
