/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class EmployeeMaster {
    String strEmployeeCode,strCompanyCode,strRegion,strEmpName,strVendorCode,strVendorGL,strDesaigntion,strDept,strGrade,strCostCenter,strBusinessArea,strOrgLoc,strBasicSal,strDOJ,strDtOfTransfer,strPLoc,strPSubLoc,strDtOfConfirm,strUSERID;
    String strCorporateFunction,strHRFunction,strGender,strEmailID,strWorkLocation,strFunction,strWorkArea,strCategory;
    
    public String getStrEmployeeCode() {
        return strEmployeeCode;
    }

    public void setStrEmployeeCode(String strEmployeeCode) {
        this.strEmployeeCode = strEmployeeCode;
    }

    public String getStrCompanyCode() {
        return strCompanyCode;
    }

    public void setStrCompanyCode(String strCompanyCode) {
        this.strCompanyCode = strCompanyCode;
    }

    public String getStrRegion() {
        return strRegion;
    }

    public void setStrRegion(String strRegion) {
        this.strRegion = strRegion;
    }

    public String getStrEmpName() {
        return strEmpName;
    }

    public void setStrEmpName(String strEmpName) {
        this.strEmpName = strEmpName;
    }

    public String getStrVendorCode() {
        return strVendorCode;
    }

    public void setStrVendorCode(String strVendorCode) {
        this.strVendorCode = strVendorCode;
    }

    public String getStrVendorGL() {
        return strVendorGL;
    }

    public void setStrVendorGL(String strVendorGL) {
        this.strVendorGL = strVendorGL;
    }

    public String getStrDesaigntion() {
        return strDesaigntion;
    }

    public void setStrDesaigntion(String strDesaigntion) {
        this.strDesaigntion = strDesaigntion;
    }

    public String getStrDept() {
        return strDept;
    }

    public void setStrDept(String strDept) {
        this.strDept = strDept;
    }

    public String getStrGrade() {
        return strGrade;
    }

    public void setStrGrade(String strGrade) {
        this.strGrade = strGrade;
    }

    public String getStrCostCenter() {
        return strCostCenter;
    }

    public void setStrCostCenter(String strCostCenter) {
        this.strCostCenter = strCostCenter;
    }

    public String getStrBusinessArea() {
        return strBusinessArea;
    }

    public void setStrBusinessArea(String strBusinessArea) {
        this.strBusinessArea = strBusinessArea;
    }

    public String getStrOrgLoc() {
        return strOrgLoc;
    }

    public void setStrOrgLoc(String strOrgLoc) {
        this.strOrgLoc = strOrgLoc;
    }

    public String getStrBasicSal() {
        return strBasicSal;
    }

    public void setStrBasicSal(String strBasicSal) {
        this.strBasicSal = strBasicSal;
    }

    public String getStrDOJ() {
        return strDOJ;
    }

    public void setStrDOJ(String strDOJ) {
        this.strDOJ = strDOJ;
    }

    public String getStrDtOfTransfer() {
        return strDtOfTransfer;
    }

    public void setStrDtOfTransfer(String strDtOfTransfer) {
        this.strDtOfTransfer = strDtOfTransfer;
    }

    public String getStrPLoc() {
        return strPLoc;
    }

    public void setStrPLoc(String strPLoc) {
        this.strPLoc = strPLoc;
    }

    public String getStrPSubLoc() {
        return strPSubLoc;
    }

    public void setStrPSubLoc(String strPSubLoc) {
        this.strPSubLoc = strPSubLoc;
    }

    public String getStrDtOfConfirm() {
        return strDtOfConfirm;
    }

    public void setStrDtOfConfirm(String strDtOfConfirm) {
        this.strDtOfConfirm = strDtOfConfirm;
    }

    public String getStrUSERID() {
        return strUSERID;
    }

    public void setStrUSERID(String strUSERID) {
        this.strUSERID = strUSERID;
    }

    public String getStrCorporateFunction() {
        return strCorporateFunction;
    }

    public void setStrCorporateFunction(String strCorporateFunction) {
        this.strCorporateFunction = strCorporateFunction;
    }

    public String getStrHRFunction() {
        return strHRFunction;
    }

    public void setStrHRFunction(String strHRFunction) {
        this.strHRFunction = strHRFunction;
    }

    public String getStrGender() {
        return strGender;
    }

    public void setStrGender(String strGender) {
        this.strGender = strGender;
    }

    public String getStrEmailID() {
        return strEmailID;
    }

    public void setStrEmailID(String strEmailID) {
        this.strEmailID = strEmailID;
    }

    public String getStrWorkLocation() {
        return strWorkLocation;
    }

    public void setStrWorkLocation(String strWorkLocation) {
        this.strWorkLocation = strWorkLocation;
    }

    public String getStrFunction() {
        return strFunction;
    }

    public void setStrFunction(String strFunction) {
        this.strFunction = strFunction;
    }

    public String getStrWorkArea() {
        return strWorkArea;
    }

    public void setStrWorkArea(String strWorkArea) {
        this.strWorkArea = strWorkArea;
    }

    public String getStrCategory() {
        return strCategory;
    }

    public void setStrCategory(String strCategory) {
        this.strCategory = strCategory;
    }
    
    
    
}
