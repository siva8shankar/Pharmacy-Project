/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: SDC-South
*    Product / Project                  	: Britannia Industries Limited
*    Module                                  	: customibps
*    File Name                               	: EmployeeGuestHouseData.java
*    Author                                    	: ksivashankar
*    Date written                          	: 29/05/2019
*    (DD/MM/YYYY)                      
*    Description                            	: Bean class
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class EmployeeGuestHouseData {
    String EmpNumber,EmpUserID,EmpName,EmpEmailID,EmpContactNum,EmpRegion,EmpWorkLoc,EmpRM,EmpHRBPUserID,EmpHRBPName,EmpVendorCode,EmpDesignation,EmpDepartment,EmpGrade,
            Location, FullAddress, ReservationsBy, ContactDetails, CareTakerDetails, NoOfSingleOccupancy, NoOfDoubleOccupancy, 
            NoOfTotalOccupancy, Remarks, RegionalAdmin,EmpVendorGL,EmpCostCenter,EmpState,EEVPF,BusinessAreaCode;

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public String getFullAddress() {
        return FullAddress;
    }

    public void setFullAddress(String FullAddress) {
        this.FullAddress = FullAddress;
    }

    public String getReservationsBy() {
        return ReservationsBy;
    }

    public void setReservationsBy(String ReservationsBy) {
        this.ReservationsBy = ReservationsBy;
    }

    public String getContactDetails() {
        return ContactDetails;
    }

    public void setContactDetails(String ContactDetails) {
        this.ContactDetails = ContactDetails;
    }

    public String getCareTakerDetails() {
        return CareTakerDetails;
    }

    public void setCareTakerDetails(String CareTakerDetails) {
        this.CareTakerDetails = CareTakerDetails;
    }

    public String getNoOfSingleOccupancy() {
        return NoOfSingleOccupancy;
    }

    public void setNoOfSingleOccupancy(String NoOfSingleOccupancy) {
        this.NoOfSingleOccupancy = NoOfSingleOccupancy;
    }

    public String getNoOfDoubleOccupancy() {
        return NoOfDoubleOccupancy;
    }

    public void setNoOfDoubleOccupancy(String NoOfDoubleOccupancy) {
        this.NoOfDoubleOccupancy = NoOfDoubleOccupancy;
    }

    public String getNoOfTotalOccupancy() {
        return NoOfTotalOccupancy;
    }

    public void setNoOfTotalOccupancy(String NoOfTotalOccupancy) {
        this.NoOfTotalOccupancy = NoOfTotalOccupancy;
    }

    public String getRemarks() {
        return Remarks;
    }

    public void setRemarks(String Remarks) {
        this.Remarks = Remarks;
    }

    public String getRegionalAdmin() {
        return RegionalAdmin;
    }

    public void setRegionalAdmin(String RegionalAdmin) {
        this.RegionalAdmin = RegionalAdmin;
    }

    public String getEmpNumber() {
        return EmpNumber;
    }

    public void setEmpNumber(String EmpNumber) {
        this.EmpNumber = EmpNumber;
    }

    public String getEmpName() {
        return EmpName;
    }

    public void setEmpName(String EmpName) {
        this.EmpName = EmpName;
    }

    public String getEmpEmailID() {
        return EmpEmailID;
    }

    public void setEmpEmailID(String EmpEmailID) {
        this.EmpEmailID = EmpEmailID;
    }

    public String getEmpContactNum() {
        return EmpContactNum;
    }

    public void setEmpContactNum(String EmpContactNum) {
        this.EmpContactNum = EmpContactNum;
    }

    public String getEmpRegion() {
        return EmpRegion;
    }

    public void setEmpRegion(String EmpRegion) {
        this.EmpRegion = EmpRegion;
    }

    public String getEmpWorkLoc() {
        return EmpWorkLoc;
    }

    public void setEmpWorkLoc(String EmpWorkLoc) {
        this.EmpWorkLoc = EmpWorkLoc;
    }

    public String getEmpRM() {
        return EmpRM;
    }

    public void setEmpRM(String EmpRM) {
        this.EmpRM = EmpRM;
    }

    public String getEmpHRBPName() {
        return EmpHRBPName;
    }

    public void setEmpHRBPName(String EmpHRBPName) {
        this.EmpHRBPName = EmpHRBPName;
    }

    public String getEmpVendorCode() {
        return EmpVendorCode;
    }

    public void setEmpVendorCode(String EmpVendorCode) {
        this.EmpVendorCode = EmpVendorCode;
    }

    public String getEmpDesignation() {
        return EmpDesignation;
    }

    public void setEmpDesignation(String EmpDesignation) {
        this.EmpDesignation = EmpDesignation;
    }

    public String getEmpGrade() {
        return EmpGrade;
    }

    public void setEmpGrade(String EmpGrade) {
        this.EmpGrade = EmpGrade;
    }

    public String getEmpUserID() {
        return EmpUserID;
    }

    public void setEmpUserID(String EmpUserID) {
        this.EmpUserID = EmpUserID;
    }

    public String getEmpHRBPUserID() {
        return EmpHRBPUserID;
    }

    public void setEmpHRBPUserID(String EmpHRBPUserID) {
        this.EmpHRBPUserID = EmpHRBPUserID;
    }

    public String getEmpDepartment() {
        return EmpDepartment;
    }

    public void setEmpDepartment(String EmpDepartment) {
        this.EmpDepartment = EmpDepartment;
    }

    public String getEmpVendorGL() {
        return EmpVendorGL;
    }

    public void setEmpVendorGL(String EmpVendorGL) {
        this.EmpVendorGL = EmpVendorGL;
    }

    public String getEmpCostCenter() {
        return EmpCostCenter;
    }

    public void setEmpCostCenter(String EmpCostCenter) {
        this.EmpCostCenter = EmpCostCenter;
    }

    public String getEmpState() {
        return EmpState;
    }

    public void setEmpState(String EmpState) {
        this.EmpState = EmpState;
    }

    public String getEEVPF() {
        return EEVPF;
    }

    public void setEEVPF(String EEVPF) {
        this.EEVPF = EEVPF;
    }

    public String getBusinessAreaCode() {
        return BusinessAreaCode;
    }

    public void setBusinessAreaCode(String BusinessAreaCode) {
        this.BusinessAreaCode = BusinessAreaCode;
    }
    
    
    
}
