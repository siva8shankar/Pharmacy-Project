/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class KYCMaster {
    
    private String EmployeeCode;
    private String EmpUserId;
    private String AadharNumber;
    private String AadharAckNumber;
    private String PANNumber;
    private String PANAckNumber;
    private String DrivingLicense;
    private String VoterId;

    public String getEmployeeCode() {
        return EmployeeCode;
    }

    public void setEmployeeCode(String EmployeeCode) {
        this.EmployeeCode = EmployeeCode;
    }

    public String getAadharNumber() {
        return AadharNumber;
    }

    public void setAadharNumber(String AadharNumber) {
        this.AadharNumber = AadharNumber;
    }

    public String getAadharAckNumber() {
        return AadharAckNumber;
    }

    public void setAadharAckNumber(String AadharAckNumber) {
        this.AadharAckNumber = AadharAckNumber;
    }

    public String getPANNumber() {
        return PANNumber;
    }

    public void setPANNumber(String PANNumber) {
        this.PANNumber = PANNumber;
    }

    public String getPANAckNumber() {
        return PANAckNumber;
    }

    public void setPANAckNumber(String PANAckNumber) {
        this.PANAckNumber = PANAckNumber;
    }

    public String getDrivingLicense() {
        return DrivingLicense;
    }

    public void setDrivingLicense(String DrivingLicense) {
        this.DrivingLicense = DrivingLicense;
    }

    public String getVoterId() {
        return VoterId;
    }

    public void setVoterId(String VoterId) {
        this.VoterId = VoterId;
    }        

    public String getEmpUserId() {
        return EmpUserId;
    }

    public void setEmpUserId(String EmpUserId) {
        this.EmpUserId = EmpUserId;
    }
    
    
    
}
