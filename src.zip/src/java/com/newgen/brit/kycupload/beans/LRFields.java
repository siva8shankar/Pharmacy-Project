/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class LRFields {
    String reqEmployeeNumber,reqEmployeeName,reqEmailID,reqWorkLocation,EmployeeNumber,EmployeeName,DateOfJoining,EmailID,POrg,PA,PSA,
            ContactNumber,EmpGrade,EmpDesignation,CorporateFunction,HRFunction,Region,WorkLocation,RepManager,HRBPName,ComplaintRaisedBy
            ,complaintraisedon,complaintAbout,ComplaintAboutOthers,referenceComments,detailsOfComplaint,comments,InitBy,PID,hiddenHRBP
            ,hiddenHRBPEmployeeCode,strEmployeeUID,strdateofrequest,vendorCode,vendorGL,Department
            ,isBritEmployee,comRepEmployeeNumber,comRepEmployeeName,comRepEmailID,comRepWorkLocation,comRepNonEmployeeNumber,comRepNonEmployeeName;

    public String getReqEmployeeNumber() {
        return reqEmployeeNumber;
    }

    public void setReqEmployeeNumber(String reqEmployeeNumber) {
        this.reqEmployeeNumber = reqEmployeeNumber;
    }

    public String getReqEmployeeName() {
        return reqEmployeeName;
    }

    public void setReqEmployeeName(String reqEmployeeName) {
        this.reqEmployeeName = reqEmployeeName;
    }

    public String getReqEmailID() {
        return reqEmailID;
    }

    public void setReqEmailID(String reqEmailID) {
        this.reqEmailID = reqEmailID;
    }

    public String getReqWorkLocation() {
        return reqWorkLocation;
    }

    public void setReqWorkLocation(String reqWorkLocation) {
        this.reqWorkLocation = reqWorkLocation;
    }

    public String getEmployeeNumber() {
        return EmployeeNumber;
    }

    public void setEmployeeNumber(String EmployeeNumber) {
        this.EmployeeNumber = EmployeeNumber;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String EmployeeName) {
        this.EmployeeName = EmployeeName;
    }

    public String getDateOfJoining() {
        return DateOfJoining;
    }

    public void setDateOfJoining(String DateOfJoining) {
        this.DateOfJoining = DateOfJoining;
    }

    public String getEmailID() {
        return EmailID;
    }

    public void setEmailID(String EmailID) {
        this.EmailID = EmailID;
    }

    public String getPOrg() {
        return POrg;
    }

    public void setPOrg(String POrg) {
        this.POrg = POrg;
    }

    public String getPA() {
        return PA;
    }

    public void setPA(String PA) {
        this.PA = PA;
    }

    public String getPSA() {
        return PSA;
    }

    public void setPSA(String PSA) {
        this.PSA = PSA;
    }

    public String getContactNumber() {
        return ContactNumber;
    }

    public void setContactNumber(String ContactNumber) {
        this.ContactNumber = ContactNumber;
    }

    public String getEmpGrade() {
        return EmpGrade;
    }

    public void setEmpGrade(String EmpGrade) {
        this.EmpGrade = EmpGrade;
    }

    public String getEmpDesignation() {
        return EmpDesignation;
    }

    public void setEmpDesignation(String EmpDesignation) {
        this.EmpDesignation = EmpDesignation;
    }

    public String getCorporateFunction() {
        return CorporateFunction;
    }

    public void setCorporateFunction(String CorporateFunction) {
        this.CorporateFunction = CorporateFunction;
    }

    public String getHRFunction() {
        return HRFunction;
    }

    public void setHRFunction(String HRFunction) {
        this.HRFunction = HRFunction;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getWorkLocation() {
        return WorkLocation;
    }

    public void setWorkLocation(String WorkLocation) {
        this.WorkLocation = WorkLocation;
    }

    public String getRepManager() {
        return RepManager;
    }

    public void setRepManager(String RepManager) {
        this.RepManager = RepManager;
    }

    public String getHRBPName() {
        return HRBPName;
    }

    public void setHRBPName(String HRBPName) {
        this.HRBPName = HRBPName;
    }

    public String getComplaintRaisedBy() {
        return ComplaintRaisedBy;
    }

    public void setComplaintRaisedBy(String ComplaintRaisedBy) {
        this.ComplaintRaisedBy = ComplaintRaisedBy;
    }

    public String getComplaintraisedon() {
        return complaintraisedon;
    }

    public void setComplaintraisedon(String complaintraisedon) {
        this.complaintraisedon = complaintraisedon;
    }

    public String getComplaintAbout() {
        return complaintAbout;
    }

    public void setComplaintAbout(String complaintAbout) {
        this.complaintAbout = complaintAbout;
    }

    public String getComplaintAboutOthers() {
        return ComplaintAboutOthers;
    }

    public void setComplaintAboutOthers(String ComplaintAboutOthers) {
        this.ComplaintAboutOthers = ComplaintAboutOthers;
    }

    public String getReferenceComments() {
        return referenceComments;
    }

    public void setReferenceComments(String referenceComments) {
        this.referenceComments = referenceComments;
    }

    public String getDetailsOfComplaint() {
        return detailsOfComplaint;
    }

    public void setDetailsOfComplaint(String detailsOfComplaint) {
        this.detailsOfComplaint = detailsOfComplaint;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getInitBy() {
        return InitBy;
    }

    public void setInitBy(String InitBy) {
        this.InitBy = InitBy;
    }

    public String getPID() {
        return PID;
    }

    public void setPID(String PID) {
        this.PID = PID;
    }

    public String getHiddenHRBP() {
        return hiddenHRBP;
    }

    public void setHiddenHRBP(String hiddenHRBP) {
        this.hiddenHRBP = hiddenHRBP;
    }

    public String getHiddenHRBPEmployeeCode() {
        return hiddenHRBPEmployeeCode;
    }

    public void setHiddenHRBPEmployeeCode(String hiddenHRBPEmployeeCode) {
        this.hiddenHRBPEmployeeCode = hiddenHRBPEmployeeCode;
    }

    public String getStrEmployeeUID() {
        return strEmployeeUID;
    }

    public void setStrEmployeeUID(String strEmployeeUID) {
        this.strEmployeeUID = strEmployeeUID;
    }

    public String getStrdateofrequest() {
        return strdateofrequest;
    }

    public void setStrdateofrequest(String strdateofrequest) {
        this.strdateofrequest = strdateofrequest;
    }

    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public String getVendorGL() {
        return vendorGL;
    }

    public void setVendorGL(String vendorGL) {
        this.vendorGL = vendorGL;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getIsBritEmployee() {
        return isBritEmployee;
    }

    public void setIsBritEmployee(String isBritEmployee) {
        this.isBritEmployee = isBritEmployee;
    }

    public String getComRepEmployeeNumber() {
        return comRepEmployeeNumber;
    }

    public void setComRepEmployeeNumber(String comRepEmployeeNumber) {
        this.comRepEmployeeNumber = comRepEmployeeNumber;
    }

    public String getComRepEmployeeName() {
        return comRepEmployeeName;
    }

    public void setComRepEmployeeName(String comRepEmployeeName) {
        this.comRepEmployeeName = comRepEmployeeName;
    }

    public String getComRepEmailID() {
        return comRepEmailID;
    }

    public void setComRepEmailID(String comRepEmailID) {
        this.comRepEmailID = comRepEmailID;
    }

    public String getComRepWorkLocation() {
        return comRepWorkLocation;
    }

    public void setComRepWorkLocation(String comRepWorkLocation) {
        this.comRepWorkLocation = comRepWorkLocation;
    }

    public String getComRepNonEmployeeNumber() {
        return comRepNonEmployeeNumber;
    }

    public void setComRepNonEmployeeNumber(String comRepNonEmployeeNumber) {
        this.comRepNonEmployeeNumber = comRepNonEmployeeNumber;
    }

    public String getComRepNonEmployeeName() {
        return comRepNonEmployeeName;
    }

    public void setComRepNonEmployeeName(String comRepNonEmployeeName) {
        this.comRepNonEmployeeName = comRepNonEmployeeName;
    }
    
    
    
}
