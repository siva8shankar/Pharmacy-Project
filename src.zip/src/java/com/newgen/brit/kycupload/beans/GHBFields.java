/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: SDC-South
*    Product / Project                  	: Britannia Industries Limited
*    Module                                  	: customibps
*    File Name                               	: GHBFields.java
*    Author                                    	: ksivashankar
*    Date written                          	: 29/05/2019
*    (DD/MM/YYYY)                      
*    Description                            	: Bean Class
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class GHBFields {
    String PID,EmployeeCode,strEmployeeUID,EmployeeName,EmpEmailID,EmpContactNumber,DateOfTravel,FromLocation,ToLocation,FromDate,ToDate,RoomType,RoomStatus,
            NoOfNights,NoOfPersons,GuestHouseLocation,GuestHouseFullAddress,ReservationsBy,ReservationContactDetails,CareTakerDetails,GuestHouseRemarks,RegionalAdmin,Flag
            ,GHB_InitiationBy,RequestType,InitiationBy,Comments,cb_checkin_hh,cb_checkin_mm,cb_checkout_hh,cb_checkout_mm,Region,VendorCode,VendorGL,Designation,Department,Grade,RoomName,RoomNumber,BookingComments,EmpWorkLocation,EmpHRBPUserID,EmpRMUserID,isCabReq,IsGHAvailable,CostCenter,bookingBookingForOtherTxt;

    public String getEmployeeCode() {
        return EmployeeCode;
    }

    public void setEmployeeCode(String EmployeeCode) {
        this.EmployeeCode = EmployeeCode;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String EmployeeName) {
        this.EmployeeName = EmployeeName;
    }

    public String getEmpEmailID() {
        return EmpEmailID;
    }

    public void setEmpEmailID(String EmpEmailID) {
        this.EmpEmailID = EmpEmailID;
    }

    public String getEmpContactNumber() {
        return EmpContactNumber;
    }

    public void setEmpContactNumber(String EmpContactNumber) {
        this.EmpContactNumber = EmpContactNumber;
    }

    public String getDateOfTravel() {
        return DateOfTravel;
    }

    public void setDateOfTravel(String DateOfTravel) {
        this.DateOfTravel = DateOfTravel;
    }

    public String getFromLocation() {
        return FromLocation;
    }

    public void setFromLocation(String FromLocation) {
        this.FromLocation = FromLocation;
    }

    public String getToLocation() {
        return ToLocation;
    }

    public void setToLocation(String ToLocation) {
        this.ToLocation = ToLocation;
    }

    public String getFromDate() {
        return FromDate;
    }

    public void setFromDate(String FromDate) {
        this.FromDate = FromDate;
    }

    public String getToDate() {
        return ToDate;
    }

    public void setToDate(String ToDate) {
        this.ToDate = ToDate;
    }

    public String getRoomType() {
        return RoomType;
    }

    public void setRoomType(String RoomType) {
        this.RoomType = RoomType;
    }

    public String getRoomStatus() {
        return RoomStatus;
    }

    public void setRoomStatus(String RoomStatus) {
        this.RoomStatus = RoomStatus;
    }

    public String getNoOfNights() {
        return NoOfNights;
    }

    public void setNoOfNights(String NoOfNights) {
        this.NoOfNights = NoOfNights;
    }

    public String getNoOfPersons() {
        return NoOfPersons;
    }

    public void setNoOfPersons(String NoOfPersons) {
        this.NoOfPersons = NoOfPersons;
    }

    public String getGuestHouseLocation() {
        return GuestHouseLocation;
    }

    public void setGuestHouseLocation(String GuestHouseLocation) {
        this.GuestHouseLocation = GuestHouseLocation;
    }

    public String getGuestHouseFullAddress() {
        return GuestHouseFullAddress;
    }

    public void setGuestHouseFullAddress(String GuestHouseFullAddress) {
        this.GuestHouseFullAddress = GuestHouseFullAddress;
    }

    public String getReservationsBy() {
        return ReservationsBy;
    }

    public void setReservationsBy(String ReservationsBy) {
        this.ReservationsBy = ReservationsBy;
    }

    public String getReservationContactDetails() {
        return ReservationContactDetails;
    }

    public void setReservationContactDetails(String ReservationContactDetails) {
        this.ReservationContactDetails = ReservationContactDetails;
    }

    public String getCareTakerDetails() {
        return CareTakerDetails;
    }

    public void setCareTakerDetails(String CareTakerDetails) {
        this.CareTakerDetails = CareTakerDetails;
    }

    public String getGuestHouseRemarks() {
        return GuestHouseRemarks;
    }

    public void setGuestHouseRemarks(String GuestHouseRemarks) {
        this.GuestHouseRemarks = GuestHouseRemarks;
    }

    public String getRegionalAdmin() {
        return RegionalAdmin;
    }

    public void setRegionalAdmin(String RegionalAdmin) {
        this.RegionalAdmin = RegionalAdmin;
    }

    public String getFlag() {
        return Flag;
    }

    public void setFlag(String Flag) {
        this.Flag = Flag;
    }

    public String getGHB_InitiationBy() {
        return GHB_InitiationBy;
    }

    public void setGHB_InitiationBy(String GHB_InitiationBy) {
        this.GHB_InitiationBy = GHB_InitiationBy;
    }

    public String getRequestType() {
        return RequestType;
    }

    public void setRequestType(String RequestType) {
        this.RequestType = RequestType;
    }

    public String getInitiationBy() {
        return InitiationBy;
    }

    public void setInitiationBy(String InitiationBy) {
        this.InitiationBy = InitiationBy;
    }

    public String getComments() {
        return Comments;
    }

    public void setComments(String Comments) {
        this.Comments = Comments;
    }

    public String getCb_checkin_hh() {
        return cb_checkin_hh;
    }

    public void setCb_checkin_hh(String cb_checkin_hh) {
        this.cb_checkin_hh = cb_checkin_hh;
    }

    public String getCb_checkin_mm() {
        return cb_checkin_mm;
    }

    public void setCb_checkin_mm(String cb_checkin_mm) {
        this.cb_checkin_mm = cb_checkin_mm;
    }

    public String getCb_checkout_hh() {
        return cb_checkout_hh;
    }

    public void setCb_checkout_hh(String cb_checkout_hh) {
        this.cb_checkout_hh = cb_checkout_hh;
    }

    public String getCb_checkout_mm() {
        return cb_checkout_mm;
    }

    public void setCb_checkout_mm(String cb_checkout_mm) {
        this.cb_checkout_mm = cb_checkout_mm;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getVendorCode() {
        return VendorCode;
    }

    public void setVendorCode(String VendorCode) {
        this.VendorCode = VendorCode;
    }

    public String getVendorGL() {
        return VendorGL;
    }

    public void setVendorGL(String VendorGL) {
        this.VendorGL = VendorGL;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String Designation) {
        this.Designation = Designation;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getGrade() {
        return Grade;
    }

    public void setGrade(String Grade) {
        this.Grade = Grade;
    }

    public String getRoomName() {
        return RoomName;
    }

    public void setRoomName(String RoomName) {
        this.RoomName = RoomName;
    }

    public String getRoomNumber() {
        return RoomNumber;
    }

    public void setRoomNumber(String RoomNumber) {
        this.RoomNumber = RoomNumber;
    }

    public String getBookingComments() {
        return BookingComments;
    }

    public void setBookingComments(String BookingComments) {
        this.BookingComments = BookingComments;
    }

    public String getPID() {
        return PID;
    }

    public void setPID(String PID) {
        this.PID = PID;
    }

    public String getStrEmployeeUID() {
        return strEmployeeUID;
    }

    public void setStrEmployeeUID(String strEmployeeUID) {
        this.strEmployeeUID = strEmployeeUID;
    }

    public String getEmpWorkLocation() {
        return EmpWorkLocation;
    }

    public void setEmpWorkLocation(String EmpWorkLocation) {
        this.EmpWorkLocation = EmpWorkLocation;
    }

    public String getEmpHRBPUserID() {
        return EmpHRBPUserID;
    }

    public void setEmpHRBPUserID(String EmpHRBPUserID) {
        this.EmpHRBPUserID = EmpHRBPUserID;
    }

    public String getEmpRMUserID() {
        return EmpRMUserID;
    }

    public void setEmpRMUserID(String EmpRMUserID) {
        this.EmpRMUserID = EmpRMUserID;
    }

    public String getIsCabReq() {
        return isCabReq;
    }

    public void setIsCabReq(String isCabReq) {
        this.isCabReq = isCabReq;
    }

    public String getIsGHAvailable() {
        return IsGHAvailable;
    }

    public void setIsGHAvailable(String IsGHAvailable) {
        this.IsGHAvailable = IsGHAvailable;
    }

    public String getCostCenter() {
        return CostCenter;
    }

    public void setCostCenter(String CostCenter) {
        this.CostCenter = CostCenter;
    }

    public String getBookingBookingForOtherTxt() {
        return bookingBookingForOtherTxt;
    }

    public void setBookingBookingForOtherTxt(String bookingBookingForOtherTxt) {
        this.bookingBookingForOtherTxt = bookingBookingForOtherTxt;
    }

    
    

   }
