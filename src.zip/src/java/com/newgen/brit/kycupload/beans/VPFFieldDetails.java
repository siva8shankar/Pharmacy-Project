/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload.beans;

/**
 *
 * @author ngappadmin
 */
public class VPFFieldDetails {
    String SNO, EmpDepartment, EmployeeNumber,empUserID,EmployeeName,EmailID,ContactNumber,Region,VendorCode,VendorGL,Designation,Grade,WorkLocation,CostCenter,RepManager,HRBPName,HRBPUserID, RMUserID, InitiationType, State,EEVPF,NewVpfContribution,Comments,adminMailID, ccColumn;

    public String getSNO() {
        return SNO;
    }

    public void setSNO(String SNO) {
        this.SNO = SNO;
    }

    public String getEmpDepartment() {
        return EmpDepartment;
    }

    public void setEmpDepartment(String EmpDepartment) {
        this.EmpDepartment = EmpDepartment;
    }

    public String getEmployeeNumber() {
        return EmployeeNumber;
    }

    public void setEmployeeNumber(String EmployeeNumber) {
        this.EmployeeNumber = EmployeeNumber;
    }

    public String getEmpUserID() {
        return empUserID;
    }

    public void setEmpUserID(String empUserID) {
        this.empUserID = empUserID;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String EmployeeName) {
        this.EmployeeName = EmployeeName;
    }

    public String getEmailID() {
        return EmailID;
    }

    public void setEmailID(String EmailID) {
        this.EmailID = EmailID;
    }

    public String getContactNumber() {
        return ContactNumber;
    }

    public void setContactNumber(String ContactNumber) {
        this.ContactNumber = ContactNumber;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public String getVendorCode() {
        return VendorCode;
    }

    public void setVendorCode(String VendorCode) {
        this.VendorCode = VendorCode;
    }

    public String getVendorGL() {
        return VendorGL;
    }

    public void setVendorGL(String VendorGL) {
        this.VendorGL = VendorGL;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String Designation) {
        this.Designation = Designation;
    }

    public String getGrade() {
        return Grade;
    }

    public void setGrade(String Grade) {
        this.Grade = Grade;
    }

    public String getWorkLocation() {
        return WorkLocation;
    }

    public void setWorkLocation(String WorkLocation) {
        this.WorkLocation = WorkLocation;
    }

    public String getCostCenter() {
        return CostCenter;
    }

    public void setCostCenter(String CostCenter) {
        this.CostCenter = CostCenter;
    }

    public String getRepManager() {
        return RepManager;
    }

    public void setRepManager(String RepManager) {
        this.RepManager = RepManager;
    }

    public String getHRBPName() {
        return HRBPName;
    }

    public void setHRBPName(String HRBPName) {
        this.HRBPName = HRBPName;
    }

    public String getHRBPUserID() {
        return HRBPUserID;
    }

    public void setHRBPUserID(String HRBPUserID) {
        this.HRBPUserID = HRBPUserID;
    }

    public String getRMUserID() {
        return RMUserID;
    }

    public void setRMUserID(String RMUserID) {
        this.RMUserID = RMUserID;
    }

    public String getInitiationType() {
        return InitiationType;
    }

    public void setInitiationType(String InitiationType) {
        this.InitiationType = InitiationType;
    }

    public String getState() {
        return State;
    }

    public void setState(String State) {
        this.State = State;
    }

    public String getAdminMailID() {
        return adminMailID;
    }

    public void setAdminMailID(String adminMailID) {
        this.adminMailID = adminMailID;
    }

    public String getCcColumn() {
        return ccColumn;
    }

    public void setCcColumn(String ccColumn) {
        this.ccColumn = ccColumn;
    }

    public String getNewVpfContribution() {
        return NewVpfContribution;
    }

    public void setNewVpfContribution(String NewVpfContribution) {
        this.NewVpfContribution = NewVpfContribution;
    }

    public String getComments() {
        return Comments;
    }

    public void setComments(String Comments) {
        this.Comments = Comments;
    }

    public String getEEVPF() {
        return EEVPF;
    }

    public void setEEVPF(String EEVPF) {
        this.EEVPF = EEVPF;
    }
    
    
}