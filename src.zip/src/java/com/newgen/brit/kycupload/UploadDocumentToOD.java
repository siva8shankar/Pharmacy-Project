///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package com.newgen.brit.kycupload;
//
//import java.io.File;
//
///**
// *
// * @author ngappadmin
// */
//public class UploadDocumentToOD {
//    
//    public String addDocument(String strCabinetName, String strSessionId, int itemIndex, String strFilePath, String DocName){
//        
//        System.out.println("**************************into Add Document()***************************");
//        System.out.println("parameter values:::"+strCabinetName+","+strSessionId+","+itemIndex+","+strFilePath+","+DocName);
//        String value = null;
//        String outputXML = "";
//        char docType = 'I';
//        File file = null;
//        String fileName = "";
//        boolean statusB = false;
//        String strDate = "";
//        try {
//            String volume_ID = "4";
//                    StringBuffer inputXML = new StringBuffer();
//                    value = strFilePath;
//                    System.out.println("DocPath :" + value);
//                    String strFileType = strFilePath.substring(strFilePath.lastIndexOf(".") + 1, strFilePath.length());
//                    JPDBRecoverDocData docDBData = new JPDBRecoverDocData();
//                    JPISIsIndex isIndex = new JPISIsIndex();
//                   // String ISProviderURL = "jnp://" + strJbossIp + ":" + strJbossPort;
//                    String ISJndiContextFactory = "org.jnp.interfaces.NamingContextFactory";
////                    try {
//                        System.out.println("inside try() block");
//                       // jts = new JtsConnection("10.143.82.73", 3333, 0);
//                        String ISLookupBean = "com.newgen.omni.jts.txn.NGOClientServiceHandlerHome";                    
//                       // CPISDocumentTxn.AddDocument_MT(null, "10.143.82.73", Short.parseShort("3333"), "wems", Short.parseShort("4"), value, docDBData, null, isIndex);
////                    } catch (JPISException exception) {
////                        exception.printStackTrace();
////                    }
//                    System.out.println("Success");
//                    //genLog("Success");
//                    if ((strFileType.equalsIgnoreCase("tif")) || (strFileType.equalsIgnoreCase("tiff")) || (strFileType.equalsIgnoreCase("jpg")) || (strFileType.equalsIgnoreCase("jpeg")) || (strFileType.equalsIgnoreCase("gif"))) {
//                        docType = 'I';
//                    } else {
//                        docType = 'N';
//                    }
//                    int pageCount = 1;
//                    if ((strFileType.equalsIgnoreCase("tif")) || (strFileType.equalsIgnoreCase("tiff"))) {
//                       // TIFFDecodeParam tiff = new TIFFDecodeParam();
//                        File fileNam = new File(value.trim());
//                       // fStream = new FileInputStream(fileNam);
//
//                       // ImageDecoder imagedecoder = ImageCodec.createImageDecoder("tiff", fStream, tiff);
//                       // pageCount = imagedecoder.getNumPages();
//                        System.out.println("Page count is" + pageCount);
//                        //genLog("Page count is" + pageCount);
//                        //fStream.close();
//                    }
//                    System.out.println("Adding Document...");
//                    inputXML.append("<?xml version=\"1.0\"?>");
//                    inputXML.append("<NGOAddDocument_Input>");
//                    inputXML.append("<Option>NGOAddDocument</Option>");
//                    inputXML.append("<CabinetName>" + strCabinetName + "</CabinetName>");
//                    inputXML.append("<UserDBId>" + strSessionId + "</UserDBId>");
//                    inputXML.append("<GroupIndex>0</GroupIndex>");
//                    inputXML.append("<Document>");
//                    inputXML.append("<ParentFolderIndex>" + itemIndex + "</ParentFolderIndex>");
//                    inputXML.append("<NoOfPages>").append(pageCount).append("</NoOfPages>");
//                    inputXML.append("<AccessType>I</AccessType>");
//                    inputXML.append("<DocumentName>"+ "iv_initial_" + DocName + "</DocumentName>");
//                    inputXML.append("<DocumentType>" + docType + "</DocumentType>");
//                    inputXML.append("<DocumentSize>" + new File(value).length() + "</DocumentSize>");
//                    inputXML.append("<CreatedByAppName>" + strFileType + "</CreatedByAppName>");
//                    inputXML.append("<ISIndex>" + isIndex.m_nDocIndex + "#" + isIndex.m_sVolumeId + "#</ISIndex>");
//                    inputXML.append("<ODMADocumentIndex></ODMADocumentIndex>");
//                    inputXML.append("<EnableLog>Y</EnableLog>");
//                    inputXML.append("<FTSFlag>PP</FTSFlag>");
//                    inputXML.append("<DataDefinition></DataDefinition>");
//                    inputXML.append("<Keywords></Keywords>");
//                    inputXML.append("</Document>");
//                    inputXML.append("</NGOAddDocument_Input>");
//                    System.out.println("inputXML" + inputXML);
//                   // outputXML = DMSCallBroker.execute(inputXML.toString(), strJbossIp, 3333, 0);
//                  //  xmlResponse = new DMSXmlResponse(outputXML);
//                   // if (xmlResponse.getVal("Status").equals("0")) {
//                   //     System.out.println("*****Add Document Successful*****");
//                 //   }
//            //}
//        } catch (NullPointerException nullPointerException) {
//            System.out.println("Document Details Null");
//            //genErrorLog("Document Details Null");
//        } catch (Exception exception) {
//            //System.out.println("xmlResponse" + xmlResponse);
//            System.out.println("Error in Adding Document : " + exception);
//        }
//        return outputXML;
//    }
//}
