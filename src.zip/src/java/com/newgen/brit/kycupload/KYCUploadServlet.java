/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload;

import ISPack.ISUtil.JPISException;
import com.itextpdf.text.exceptions.BadPasswordException;
import com.itextpdf.text.pdf.PdfReader;
import com.newgen.brit.kycupload.beans.KYCMaster;
import com.newgen.brit.util.AddToSMS;
import com.newgen.brit.util.CommonMethod;
import com.newgen.brit.util.PropReader;
import com.newgen.brit.util.PropertyBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import java.io.File;
import java.util.ArrayList;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */
public class KYCUploadServlet extends HttpServlet {

    Session session = null;
    SessionFactory sessionFactory = null;
    Transaction transaction = null;
    PrintWriter out = null;
    private String result = "";
    String filePath = null;
    String fileName = "";
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
        loggerCnsl.info("*********^^^^^^^  Inside processRequest method ^^^^^^^^^^^^*********");
        try {
            loggerCnsl.info("request.getParameter(\"empCode\") " + request.getParameter("empCode"));
            if (!request.getParameter("empCode").equalsIgnoreCase("")) {
                try {
                    Configuration cfg = new Configuration().configure("com/newgen/brit/kycupload/resources/hibernate.cfg.xml");
                    sessionFactory = cfg.buildSessionFactory();
                    session = sessionFactory.openSession();
                } catch (Exception e) {
                    loggerErr.info("Exception " + e.getMessage());
                }
                try {
                    transaction = session.beginTransaction();
                    out = response.getWriter();
                    KYCMaster objKYC = new KYCMaster();
                    String strEmployeeCode = request.getParameter("empCode");
                    String strEmployeeName = request.getParameter("empName");
                    loggerCnsl.info("strEmployeeCode after get param " + strEmployeeCode);
                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);
                    String strsessionID = request.getParameter("sessionID");
                    String strscabinetName = request.getParameter("cabinetName");
                    String strAadharNumber = request.getParameter("aadharNumber");
                    String strAadharAckNum = request.getParameter("aadharAckNum");
                    String strPanNumber = request.getParameter("panNumber");
                    String strPanAckNum = request.getParameter("panAckNum");
                    String strDrivingLicenceNumber = request.getParameter("drivingLicenceNumber");
                    String strVoterNumber = request.getParameter("voterNumber");
                    String strAadharDoc = request.getParameter("aadharDoc");
                    String strPanDoc = request.getParameter("panDoc");
                    String strDLDoc = request.getParameter("DLDoc");
                    String strVoterDoc = request.getParameter("voterDoc");
                    loggerCnsl.info("strAadharDoc --> " + strAadharDoc);
                    loggerCnsl.info("strPanDoc --> " + strPanDoc);
                    loggerCnsl.info("strDLDoc --> " + strDLDoc);
                    loggerCnsl.info("strVoterDoc --> " + strVoterDoc);
                    objKYC.setEmployeeCode(strEmployeeCode);
                    objKYC.setEmpUserId(strEmployeeName);
                    objKYC.setAadharNumber(strAadharNumber);
                    objKYC.setAadharAckNumber(strAadharAckNum);
                    objKYC.setPANNumber(strPanNumber);
                    objKYC.setPANAckNumber(strPanAckNum);
                    objKYC.setDrivingLicense(strDrivingLicenceNumber);
                    objKYC.setVoterId(strVoterNumber);
                    loggerCnsl.info("strscabinetName ==> " + strscabinetName);
                    //17-May-2018 starts
                    String Sessionid = "";
                    PropertyBean probBean = null;
                    ArrayList<String> AddtoSMS_Response_sd = null;
                    AddtoSMS_Response_sd = new ArrayList<String>();
                    loggerCnsl.info("************getting sessionID using static user Execution Starts ***************");
                    PropReader propReader = new PropReader();
                    probBean = new PropertyBean();
                    probBean = propReader.readPropertyFile();
                    PropertyBean probBeanConnectRes = CommonMethod.connect(probBean);
                    String sessionID = probBeanConnectRes.getUserDBId();
                    loggerCnsl.info("sessionID :: " + sessionID);
                    loggerCnsl.info("************getting sessionID using static user Execution Ends ***************");
//                    Sessionid = strsessionID;//logged in user
                    Sessionid = sessionID;//supervisor user
                    String a = "";
                    String strCabinetName = probBean.getCabinetName();
                    String strUserName = probBean.getUserName();
                    String strPassword = probBean.getPassword();
                    String strServerIP = probBean.getServerIP();
                    String strjtsPort = probBean.getJtsPort();
                    String strVolumeIndex = probBean.getVolumeIndex();
//                    Sessionid = "1791058955";

                    if (Sessionid == "" || Sessionid == "error"
                            || Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
                        loggerCnsl.info("Error in getting OD session id!!");
                        loggerCnsl.info("Error in getting OD session id!!");
                        out.println("Error in getting OD session id!!");
                        response.setStatus(500);
                        result = "500";
                        return;
                    }
                    loggerCnsl.info("sessionID ===> " + Sessionid);

                    String serverPath = System.getProperty("user.dir");
                    String folderpath = "", Docname = "", strDocType = "", strDocData = "";
                    loggerCnsl.info("Working Directory = " + System.getProperty("user.dir"));

                    boolean isMultipart = ServletFileUpload.isMultipartContent(request);
                    loggerCnsl.info("isMultipartContent::" + isMultipart);
                    isMultipart = true;
                    if (!isMultipart) {
                        response.setStatus(501);
                        out.println("is not Multipart Content!!");
                        return;
                    }
                    List items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

                    loggerCnsl.info("items Size :::: " + items.size());
                    if (items.size() == 0) {
                        response.setStatus(502);
                        out.println("items size is 0!!");
                        result = "502";
                        out.print("Requested operation timeout. Please try after sometimes");
                        return;

                    }
                    boolean isPasswordProtectedDocExist = false;
                    int j = 0;

                    for (int i = 0; i < items.size(); i++) {

                        FileItem item_sd = (FileItem) items.get(i);
//                        if (i == 2 || i == 3) {
                        if (item_sd.isFormField()) {
                            loggerCnsl.info("inside is form field..!");
                            // do nothing
                        } else {
                            loggerCnsl.info("inside else is form field..!");
                            long cdt = System.currentTimeMillis();
                            folderpath = serverPath + File.separator + "Documents";
                            loggerCnsl.info("folderpath " + folderpath);
                            File file = new File(folderpath);
                            if (!file.isDirectory()) {
                                file.mkdir();
                            }
                            String itemName = item_sd.getName();
                            itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());
                            fileName = itemName;

                            filePath = folderpath + File.separator + cdt + "_" + itemName;
                            File savedFile = new File(filePath);
                            item_sd.write(savedFile);

                        }
                        loggerCnsl.info("filePath ----> " + filePath);
                        try {
                            loggerCnsl.info("filepath ---> " + filePath);
                            PdfReader reader = new PdfReader(filePath);
                        } catch (BadPasswordException e) {
                            isPasswordProtectedDocExist = true;
                            loggerCnsl.info("PDF is password protected");
                        } catch (Exception e) {
                            loggerCnsl.info("Exception in Reading File");
                        }

//                        }
                    }
                    if (!isPasswordProtectedDocExist) {
                        for (int i = 0; i < items.size(); i++) {

                            FileItem item_sd = (FileItem) items.get(i);
                            loggerCnsl.info("no----->" + i);
//                        if (i == 2 || i == 3) {
                            if (item_sd.isFormField()) {
                                loggerCnsl.info("inside is form field..!");
                                // do nothing
                            } else {
                                loggerCnsl.info("inside else is form field..!");
                                long cdt = System.currentTimeMillis();
                                folderpath = serverPath + File.separator + "Documents";
                                loggerCnsl.info("folderpath " + folderpath);
                                File file = new File(folderpath);
                                if (!file.isDirectory()) {
                                    file.mkdir();
                                }
                                String itemName = item_sd.getName();
                                itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());
                                fileName = itemName;

                                filePath = folderpath + File.separator + cdt + "_" + itemName;
                                File savedFile = new File(filePath);
                                item_sd.write(savedFile);

                            }

                            if (i == 0) {
                                Docname = strEmployeeCode + "_" + strAadharNumber;
                                strDocType = "AadharDoc";
                                strDocData = strAadharNumber;
                            } else if (i == 1) {
                                Docname = strEmployeeCode + "_" + strPanNumber;
                                strDocType = "PanDoc";
                                strDocData = strPanNumber;
                            } else if (i == 2) {
                                Docname = strEmployeeCode + "_" + strDrivingLicenceNumber;
                                strDocType = "DlDoc";
                                strDocData = strDrivingLicenceNumber;
                            } else if (i == 3) {
                                Docname = strEmployeeCode + "_" + strVoterNumber;
                                strDocType = "VoterDoc";
                                strDocData = strVoterNumber;
                            }

                            loggerCnsl.info("Docname ----> " + Docname);
                            loggerCnsl.info("filePath ----> " + filePath);
                            boolean flag = false;
                            try {
                                loggerCnsl.info("filepath ---> " + filePath);
                                PdfReader reader = new PdfReader(filePath);
                            } catch (BadPasswordException e) {
                                flag = true;
                                isPasswordProtectedDocExist = true;
                                loggerCnsl.info("PDF is password protected");
                            } catch (Exception e) {
                                loggerCnsl.info("Exception in Reading File");
                            }

                            if (flag) {
                                try {
                                    loggerCnsl.info("PDF is password protected");
                                } catch (Exception e) {
                                    loggerCnsl.info("Exception occurred in pswdprotectd() " + e);
                                }
                            } else {
                                loggerCnsl.info("PDF is not password protected");
                                a = AddToSMS.AddtoSms(Docname, filePath, Sessionid, strServerIP, strCabinetName,
                                        strjtsPort, strVolumeIndex);
                                loggerCnsl.info("+AddtoSMS_Response_sd--->" + a);
                                AddtoSMS_Response_sd.add(a);
                                String strDocIndex = null;
                                if (AddtoSMS_Response_sd != null && AddtoSMS_Response_sd.size() != 0) {
                                    CommonMethod cmnMethod = new CommonMethod();
                                    loggerCnsl.info("strEmployeeCode before addfolder ==> " + strEmployeeCode);
                                    loggerCnsl.info("Sessionid before addfolder ==> " + Sessionid);
                                    String folderIndex = cmnMethod.addFolder(strEmployeeCode, Sessionid);
                                    File tifFile = new File(filePath);
                                    String tifFileName = tifFile.getName();
                                    String fileSize = Long.toString(new File(filePath).length());
                                    String fileExtn = tifFileName.substring(tifFileName.lastIndexOf(".") + 1, tifFileName.length());
                                    strDocIndex = cmnMethod.adddocument(filePath, fileSize, 0, a.toString(), fileExtn, "I", folderIndex, Docname, Sessionid);
                                    loggerCnsl.info(" :: Document uploaded succesfully in OD :: strDocIndex is ==> " + strDocIndex);
                                    cmnMethod.addDocProperties(strDocIndex, Sessionid, strEmployeeCode, strDocType, strDocData);
//                           loggerCnsl.info(" :: Document uploaded succesfully in OD :: strDocIndex is ==> " + strDocIndex);                           
                                } else {
                                    loggerCnsl.info(" :: Document uploaded failed in OD :: ");
                                }
                            }

//                        }
                        }
//                     CommonMethod.disconCabinet(probBean, Sessionid);
//                    if (!isPasswordProtectedDocExist) {
                        try {
                            loggerCnsl.info("PDF is not password protected");
                            session.saveOrUpdate(objKYC);
                            transaction.commit();
                            loggerCnsl.info("Data Updated Successfully");
                            out.println("Successfully Updated");
                            CommonMethod.disconCabinet(probBean, Sessionid);
                            request.setAttribute("EmployeeCode", strEmployeeCode);
                        } catch (Exception e) {
                            loggerCnsl.info("Exception occurred in Hibernate while updating the data " + e);
                        }
                    } else {
                        out.println("Password protected document exist, Cannot update the data!");
                        CommonMethod.disconCabinet(probBean, Sessionid);
                        session.close();
                        sessionFactory.close();
                    }
                    //17-May-2018

//            request.getRequestDispatcher("uploadkyc.jsp").forward(request, response);
                } catch (Exception e) {
                    loggerErr.info("Exception :: " + e.getMessage());
                    request.setAttribute("EmployeeCode", "");
//            request.getRequestDispatcher("uploadkyc.jsp").forward(request, response);
                } catch (JPISException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } finally {
                    session.close();
                    sessionFactory.close();
                }
            } else {
                request.setAttribute("EmployeeCode", "");
//            request.getRequestDispatcher("uploadkyc.jsp").include(request, response);
            }
        } catch (Exception e) {
            loggerErr.info("Exception ===> " + e.getMessage());
//            request.getRequestDispatcher("uploadkyc.jsp").include(request, response);
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        loggerCnsl.info("*********^^^^^^^  Inside doGet method ^^^^^^^^^^^^*********");
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
