/** ******************************************************************
 *    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 *    Group                                     	: SDC-South
 *    Product / Project                  	: Britannia Industries Limited
 *    Module                                  	: customibps
 *    File Name                               	: GuestHouseAddDocumentServlet.java
 *    Author                                    	: ksivashankar
 *    Date written                          	: 29/05/2019
 *    (DD/MM/YYYY)
 *    Description                            	: Add document servlet
 *  CHANGE HISTORY
 ***********************************************************************************************
 * Date                                Change By                    Change Description (Bug No. (If Any))
 * (DD/MM/YYYY)
 *********************************************************************************************** */
package com.newgen.brit.kycupload;

import ISPack.ISUtil.JPISException;
import com.itextpdf.text.exceptions.BadPasswordException;
import com.itextpdf.text.pdf.PdfReader;
import com.newgen.brit.kycupload.beans.GHBFields;
import com.newgen.brit.kycupload.beans.GuestHouseDetails;
import com.newgen.brit.kycupload.beans.HelpDeskPortalFields;
import com.newgen.brit.kycupload.beans.KYCMaster;
import com.newgen.brit.kycupload.beans.LRFields;
import com.newgen.brit.util.AddToSMS;
import com.newgen.brit.util.CommonMethod;
import com.newgen.brit.util.PropReader;
import com.newgen.brit.util.PropertyBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */
public class GuestHouseAddDocumentServlet extends HttpServlet {

    Session session = null;
    SessionFactory sessionFactory = null;
    Transaction transaction = null;
    PrintWriter out = null;
    private String result = "";
    String filePath = null;
    String fileName = "";
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
        loggerCnsl.info("*********^^^^^^^  Inside processRequest method ^^^^^^^^^^^^*********");
        try {
            loggerCnsl.info("request.getParameter(\"EmployeeNumber\") " + request.getParameter("EmployeeNumber"));
            if (!request.getParameter("EmployeeNumber").equalsIgnoreCase("")) {
                try {
//                    Configuration cfg = new Configuration().configure("com/newgen/brit/kycupload/resources/helpdeskhibernate.cfg.xml");
//                    sessionFactory = cfg.buildSessionFactory();
//                    session = sessionFactory.openSession();
                } catch (Exception e) {
                    loggerErr.info("Exception " + e.getMessage());
                }
                String Sessionid = "";
                PropertyBean probBean = null;
                try {
                    String cabLocation = "";
                    String cabTypeOfCar = "";
                    String cabDateOfPickup = "";
                    String cb_pickup_hh = "";
                    String cb_pickup_mm = "";
                    String cabTypeOfTravel = "";
                    String cabFromAddress = "";
                    String cabToAddress = "";
                    String strRomSts = "";
//                    transaction = session.beginTransaction();
                    out = response.getWriter();
                    GHBFields objHPF = new GHBFields();
                    String strreqEmployeeNumber = request.getParameter("EmployeeNumber");
                    String strEmpUserID = request.getParameter("empUserID");
                    String strEmployeeName = request.getParameter("strEmployeeName");
                    loggerCnsl.info("strEmployeeCode after get param " + strreqEmployeeNumber);
                    loggerCnsl.info("strEmpUserID after get param " + strEmpUserID);
                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);
                    String strsessionID = request.getParameter("sessionID");
                    String strscabinetName = request.getParameter("cabinetName");
                    String strreqEmailID = request.getParameter("EmailID");

//                    String strdateofrequest = request.getParameter("dateofrequest");
//                    String strreqWorkLocation = request.getParameter("reqWorkLocation");
//                    String strEmployeeNumber = request.getParameter("EmployeeNumber");
//                    String strEmployeeName = request.getParameter("EmployeeName");
//                    String strEmployeeUID = request.getParameter("hiddenUserID");
//                    String strDateOfJoining = request.getParameter("DateOfJoining");
//                    String strEmailID = request.getParameter("EmailID");
//                    String strPOrg = request.getParameter("POrg");
//                    String strPA = request.getParameter("PA");
//                    String strPSA = request.getParameter("PSA");
                    String strtContactNumber = request.getParameter("ContactNumber");
                    String strguestLocation = request.getParameter("guestLocation");
                    String strHRFunction = request.getParameter("HRFunction");
                    String strRegion = request.getParameter("Region");
                    String strVendorCode = request.getParameter("VendorCode");
                    String strVendorGL = request.getParameter("VendorGL");
                    String strDesignation = request.getParameter("Designation");
                    String strDepartment = request.getParameter("Department");
                    String strGrade = request.getParameter("Grade");
                    String strWorkLocation = request.getParameter("WorkLocation");
                    String strCostCenter = request.getParameter("CostCenter");
                    String strRepManager = request.getParameter("RepManager");
                    String strHRBPName = request.getParameter("HRBPName");
                    String strHRBPUserID = request.getParameter("HRBPUserID");
                    String strRMUserID = request.getParameter("RMUserID");
                    String strfromdate = request.getParameter("fromdate");
                    String strtodate = request.getParameter("todate");
                    String strfromdate1 = CommonMethod.formatDate(strfromdate);
                    String strtodate1 = CommonMethod.formatDate(strtodate);
//                    String strfromdate = CommonMethod.formatDate(request.getParameter("fromdate"));
//                    String strtodate = CommonMethod.formatDate(request.getParameter("todate"));
                    String noofnights = request.getParameter("noofnights");
                    String strnoofpersons = request.getParameter("noofpersons");
                    String strRequestType = request.getParameter("RequestType");
                    String strcb_checkin_hh = request.getParameter("cb_checkin_hh");
                    String strcb_checkin_mm = request.getParameter("cb_checkin_mm");
                    String strcb_checkout_hh = request.getParameter("cb_checkout_hh");
                    String strcb_checkout_mm = request.getParameter("cb_checkout_mm");
                    String strcomments = request.getParameter("comments");
                    String strbookingRoomType = request.getParameter("bookingRoomType");
                    String strisGuestHouseRoomsAreAvailable = request.getParameter("isGuestHouseRoomsAreAvailable");
                    String strbookingRoomName = "";
                    String strbookingRoomNumber = "";
                    String strbookingRoomStatus = "";
                    String bookingBookingForOtherTxt = "";
                    if (strisGuestHouseRoomsAreAvailable.equalsIgnoreCase("GuestHouseAvailable")) {
                        strbookingRoomName = request.getParameter("bookingRoomName");
                        strbookingRoomNumber = request.getParameter("bookingRoomNumber");
                        strbookingRoomStatus = request.getParameter("bookingRoomStatus");
                    }
                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);
                    String strbookingBookingFor = request.getParameter("bookingBookingFor");

                    String strbookingComments = request.getParameter("bookingComments");
                    if (!CommonMethod.isNullOrEmpty(strbookingComments)) {
                        strbookingComments = strbookingComments;
                    } else {
                        strbookingComments = "NA";
                    }
                    String strInitiationType = request.getParameter("InitiationType");
                    if (!strbookingBookingFor.equalsIgnoreCase("Self")) {
                        bookingBookingForOtherTxt = request.getParameter("bookingBookingForOtherTxt");
                    }
                    //Cab Details starts here
                    String isCabReq = request.getParameter("isCabReq");
                    if (isCabReq.equalsIgnoreCase("Yes")) {
                        cabLocation = request.getParameter("cabLocation");
                        cabTypeOfCar = request.getParameter("cabTypeOfCar");
                        cabDateOfPickup = request.getParameter("cabDateOfPickup");
                        cb_pickup_hh = request.getParameter("cb_pickup_hh");
                        cb_pickup_mm = request.getParameter("cb_pickup_mm");
                        cabTypeOfTravel = request.getParameter("cabTypeOfTravel");
                        cabFromAddress = request.getParameter("cabFromAddress");
                        cabToAddress = request.getParameter("cabToAddress");
                    }
                    //Cab Details ends here

                    String strDOJ = "";
                    loggerCnsl.info("strsessionID --> " + strsessionID);
                    loggerCnsl.info("strscabinetName --> " + strscabinetName);
                    loggerCnsl.info("strHRFunction --> " + strHRFunction);

                    objHPF.setEmployeeCode(strreqEmployeeNumber);
                    objHPF.setEmployeeName(strEmployeeName);
                    objHPF.setStrEmployeeUID(strEmpUserID);
                    objHPF.setEmpEmailID(strreqEmailID);
                    objHPF.setFromDate(strfromdate1);
                    objHPF.setToDate(strtodate1);
                    loggerCnsl.info("strfromdate --> " + strfromdate);
                    loggerCnsl.info("strfromdate1 --> " + strfromdate1);
                    loggerCnsl.info("strtodate --> " + strtodate);
                    loggerCnsl.info("strtodate1 --> " + strtodate1);
                    objHPF.setNoOfNights(noofnights);
                    objHPF.setNoOfPersons(strnoofpersons);
                    if (!CommonMethod.isNullOrEmpty(strcomments)) {
                        objHPF.setComments(strcomments);
                        strcomments = strcomments;
                    } else {
                        objHPF.setComments("NA");
                        strcomments = "NA";
                    }
                    objHPF.setEmpContactNumber(strtContactNumber);
                    objHPF.setRegion(strRegion);
                    objHPF.setGrade(strGrade);
                    objHPF.setVendorCode(strVendorCode);
                    objHPF.setVendorGL(strVendorGL);
                    objHPF.setDepartment(strDepartment);
                    objHPF.setDesignation(strDesignation);

                    objHPF.setEmpWorkLocation(strWorkLocation);
                    objHPF.setCostCenter(strCostCenter);
                    objHPF.setBookingBookingForOtherTxt(bookingBookingForOtherTxt);
                    objHPF.setEmpHRBPUserID(strHRBPUserID);
                    objHPF.setEmpRMUserID(strRMUserID);

                    objHPF.setGuestHouseLocation(strguestLocation);
                    objHPF.setIsGHAvailable(strisGuestHouseRoomsAreAvailable);
                    objHPF.setRegion(strRegion);
                    objHPF.setRequestType(strRequestType);
                    objHPF.setCb_checkin_hh(strcb_checkin_hh);
                    objHPF.setCb_checkin_mm(strcb_checkin_mm);
                    objHPF.setCb_checkout_hh(strcb_checkout_hh);
                    objHPF.setCb_checkout_mm(strcb_checkout_mm);
                    objHPF.setIsCabReq(isCabReq);
                    //Add document starts here
                    ArrayList<String> AddtoSMS_Response_sd = null;
                    AddtoSMS_Response_sd = new ArrayList<String>();
                    loggerCnsl.info("************getting sessionID using static user Execution Starts ***************");
                    PropReader propReader = new PropReader();
                    probBean = new PropertyBean();
                    probBean = propReader.readPropertyFile();
                    PropertyBean probBeanConnectRes = CommonMethod.connect(probBean);
                    String sessionID = probBeanConnectRes.getUserDBId();
                    loggerCnsl.info("sessionID :: " + sessionID);
                    loggerCnsl.info("************getting sessionID using static user Execution Ends ***************");
//                    Sessionid = strsessionID;//logged in user
                    Sessionid = sessionID;//HelpDesk_Initiator user
                    String a = "";
                    String strCabinetName = probBean.getCabinetName();
                    String strUserName = probBean.getUserName();
                    String strPassword = probBean.getPassword();
                    String strServerIP = probBean.getServerIP();
                    String strjtsPort = probBean.getJtsPort();
                    String strVolumeIndex = probBean.getVolumeIndex();

                    String strWorkitemEndPointurl = probBean.getWorkitemEndPointurl();
                    //for UAT
//                    String strInitiateFromActivityId = "19";
//                    String strInitiateFromActivityName = "Request";
//                    String strProcessDefId = "12";
//                    String strProcessName = "GHB";
                    //for PRODUCTION
                    String strInitiateFromActivityId = "1";
                    String strInitiateFromActivityName = "Request";
                    String strProcessDefId = "6";
                    String strProcessName = "GHB";
                    String strCabinet = probBean.getCabinet();
//                    Sessionid = "1791058955";

                    if (Sessionid == "" || Sessionid == "error"
                            || Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
                        loggerCnsl.info("Error in getting OD session id!!");
                        loggerCnsl.info("Error in getting OD session id!!");
                        out.println("Error in getting OD session id!!");
                        response.setStatus(500);
                        result = "500";
                        return;
                    }
                    loggerCnsl.info("sessionID ===> " + Sessionid);
                    if (strInitiationType.equalsIgnoreCase("withOutDoc")) {
                        CommonMethod cmnMethod = new CommonMethod();
                        String result = cmnMethod.initiateGuestHouseWorkitem(objHPF, strWorkitemEndPointurl, Sessionid, strCabinet, strInitiateFromActivityId, strInitiateFromActivityName,
                                strProcessDefId, strProcessName);
                        loggerCnsl.info("CaseNumber --> " + result);
                        if (!result.equalsIgnoreCase("Pending")) {
                            objHPF.setPID(result);
                            strRomSts = "Booked";
                            if (strRequestType.equalsIgnoreCase("Personal")) {
                                strRomSts = "Blocked";
                            }
                            //Need to implement the code to get details of the guest house starts here
                            ArrayList<GuestHouseDetails> objGHDetails = new ArrayList<GuestHouseDetails>();
                            GuestHouseDetails ghousedetails = null;
                            String strFullAddress = "";
                            String strReservationsBy = "";
                            String strContactDetails = "";
                            String strCareTakerDetails = "";
                            String strRemarks = "";
                            String strRegionalAdmin = "";
                            String strREGIONALADMIN_USEREMAIL = "";
                            String strGUESTHOUSE_USEREMAIL = "";
                            String strCABREQ_USEREMAIL = "";
                            objGHDetails = CommonMethod.getGuestHouseDetailsMethodForMail(sessionID, probBean, strguestLocation);

                            for (int i = 0; i < objGHDetails.size(); i++) {
                                System.out.println("objGHDetails.size()  --> " + objGHDetails.size());
                                System.out.println("i  --> " + i);
                                ghousedetails = (GuestHouseDetails) objGHDetails.get(i);
                                strFullAddress = ghousedetails.getFullAddress();
                                strReservationsBy = ghousedetails.getReservationsBy();
                                strContactDetails = ghousedetails.getContactDetails();
                                strCareTakerDetails = ghousedetails.getCareTakerDetails();
                                strRemarks = ghousedetails.getRemarks();
                                strRegionalAdmin = ghousedetails.getRegionalAdmin();
                                strREGIONALADMIN_USEREMAIL = ghousedetails.getRegionalAdminEmail();
                                strGUESTHOUSE_USEREMAIL = ghousedetails.getGUESTHOUSE_USEREMAIL();
                                strCABREQ_USEREMAIL = ghousedetails.getCABREQ_USEREMAIL();
                            }
                            //Need to implement the code to get details of the guest house ends here
                            if (objHPF.getIsGHAvailable().equalsIgnoreCase("GuestHouseNotAvailable")) {
                                if (isCabReq.equalsIgnoreCase("Yes")) {
                                    //Cab Request details
                                    String sQuery = "INSERT INTO dbo.EXT_GHB_Complex_CabRequest (PID, Location, Type_Of_Car, Date_Of_Pickup, Pick_up_Time_HH, Pick_up_Time_MM, Type_of_Travel, From_Address, To_Address)\n"
                                            + "VALUES ('" + result + "','" + cabLocation + "', '" + cabTypeOfCar + "',  '" + cabDateOfPickup + "',  '" + cb_pickup_hh + "', '" + cb_pickup_mm + "', '" + cabTypeOfTravel + "', '" + cabFromAddress + "', '" + cabToAddress + "')";
                                    loggerCnsl.info("sQuery --> " + sQuery);
                                    cmnMethod.executeUpdateQry(sQuery, Sessionid);
                                    //Need to implement mail trigger for cab services team as per the 
                                    String StrMailBody = "<HTML><head><style>td{padding: 6px 6px;width: 180px;border: 1px solid #ccc;}th{padding: 6px 6px;width: 180px;border: 1px solid #ccc;background:blue;color:white;}</style></head><BODY>Dear Guest <b></b>,<BR><BR>Thank you for the cab booking request.<BR><br><h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Request Details</h4>"
                                            + "<TABLE> <TR><TH>Employee Code</TH> <TH>Employee Name</TH> <TH>Email ID</TH><TH>Contact Number</TH><TH>Designation</TH><TH>Grade</TH><TH>Cost Center</TH><TH>Cab Location</TH>  <TH> Date Of Pickup</TH><TH>Pickup Time</TH><TH>Type Of Car</TH><TH>Type Of Travel</TH><TH>From Location</TH><TH>To Location</TH></TR>"
                                            + "<TR><TD><B>" + strreqEmployeeNumber + "</B></TD><TD>" + strEmployeeName + "</TD> <TD>" + strreqEmailID + "</TD><TD>" + strtContactNumber + "</TD> <TD>" + strDesignation + "</TD> <TD>" + strGrade + "</TD><TD>" + strCostCenter + "</TD><TD>" + cabLocation + "</TD><TD>" + cabDateOfPickup + "</TD><TD>" + cb_pickup_hh + ":" + cb_pickup_mm + "</TD><TD>" + cabTypeOfCar + "</TD><TD>" + cabTypeOfTravel + "</TD><TD>" + cabFromAddress + "</TD><TD>" + cabToAddress + "</TD></TR>"
                                            + "</TABLE>";
                                    StrMailBody += "<br><br>The chaufeur and vehicle details will be shared shortly.<br><br><br><b>Regards,<br>Admin Team</b><br><BR><FONT style=\"COLOR: red\">Note:- This is a system generated E-mail,please do not reply to this E-mail.</FONT><BR></BODY></HTML>";
                                    String strQuery = "INSERT INTO WFMAILQUEUETABLE ( mailFrom,mailTo, mailCC, mailSubject, mailMessage, mailContentType, mailPriority, mailStatus,insertedBy, mailActionType, insertedTime,processDefId,processInstanceId, workitemId, activityId,noOfTrials )VALUES('" + strreqEmailID + "','" + strCABREQ_USEREMAIL + "','" + strreqEmailID + ";travel@britindia.com','Successfully registered the Cab request details from Britannia Industries Ltd. Please refere " + result + " and Cab details will be shared shortly.','" + StrMailBody + "','text/html;charset=UTF-8',1,'N', 'CabBooking', 'N',getdate(), 12,'" + result + "',1,9,0)";
                                    loggerCnsl.info("sQuery --> " + strQuery);
                                    cmnMethod.executeMailUpdateQry(strQuery, Sessionid);
                                }
                                String sQuery1 = "INSERT INTO dbo.EXT_Complex_BookingDetails (PID, RoomName, RoomNumber, RoomType, RoomStatus, BookingComments, BookingFor)\n"
                                        + "VALUES ('" + result + "','" + strbookingRoomName + "', '" + strbookingRoomNumber + "', '" + strbookingRoomType + "', 'Guest House Rooms are not Available',  '" + strbookingComments + "', '" + strbookingBookingFor + "')";
                                loggerCnsl.info("sQuery1 --> " + sQuery1);
                                cmnMethod.executeUpdateQry(sQuery1, Sessionid);
                                //Need to implement the mail trigger to admin team for booking OYO Rooms
                                String StrMailBody = "<HTML><head><style>td{padding: 6px 6px;width: 180px;border: 1px solid #ccc;}th{padding: 6px 6px;width: 180px;border: 1px solid #ccc;background:blue;color:white;}</style></head><BODY>Dear Guest <b></b>,<BR><BR>Thank you for the Oyo room booking request.<BR><br><h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Request Details</h4>"
                                        + "<TABLE> <TR><TH>Employee Code</TH> <TH>Employee Name</TH> <TH>Email ID</TH><TH>Contact Number</TH><TH>Designation</TH><TH>Grade</TH><TH>Location</TH>  <TH>Check-In Date</TH><TH>Check-In Time</TH><TH>Check-Out Date</TH><TH>Check-Out Time</TH><TH>No Of Nights</TH><TH>No Of Persons</TH></TR>"
                                        + "<TR><TD><B>" + strreqEmployeeNumber + "</B></TD><TD>" + strEmployeeName + "</TD> <TD>" + strreqEmailID + "</TD><TD>" + strtContactNumber + "</TD> <TD>" + strDesignation + "</TD> <TD>" + strGrade + "</TD><TD>" + strguestLocation + "</TD><TD>" + strfromdate + "</TD><TD>" + strcb_checkin_hh + ":" + strcb_checkin_mm + "</TD><TD>" + strtodate + "</TD><TD>" + strcb_checkout_hh + ":" + strcb_checkout_mm + "</TD><TD>" + noofnights + "</TD><TD>" + strnoofpersons + "</TD></TR>"
                                        + "</TABLE>";
                                StrMailBody += "<br><br>The hotel options will be shared shortly.<br><br><br><b>Regards,<br>Oyo Team</b><br><BR><FONT style=\"COLOR: red\">Note:- This is a system generated E-mail,please do not reply to this E-mail.</FONT><BR></BODY></HTML>";
                                String strQuery = "INSERT INTO WFMAILQUEUETABLE ( mailFrom,mailTo, mailCC, mailSubject, mailMessage, mailContentType, mailPriority, mailStatus,insertedBy, mailActionType, insertedTime,processDefId,processInstanceId, workitemId, activityId,noOfTrials )VALUES('" + strreqEmailID + "','brit.reservations@oyorooms.com','" + strreqEmailID + ";" + strGUESTHOUSE_USEREMAIL + "','Your Guest House request has been forwarded to OYO Hotels, shortly you will get confirmation mail from OYO Hotels. Please refere " + result + "','" + StrMailBody + "','text/html;charset=UTF-8',1,'N', 'RequestToOYOHotels', 'N',getdate(), 12,'" + result + "',1,9,0)";
                                loggerCnsl.info("sQuery --> " + strQuery);
                                cmnMethod.executeMailUpdateQry(strQuery, Sessionid);
                            } else {
                                if (isCabReq.equalsIgnoreCase("Yes")) {
                                    //Cab Request details
                                    String sQuery = "INSERT INTO dbo.EXT_GHB_Complex_CabRequest (PID, Location, Type_Of_Car, Date_Of_Pickup, Pick_up_Time_HH, Pick_up_Time_MM, Type_of_Travel, From_Address, To_Address)\n"
                                            + "VALUES ('" + result + "','" + cabLocation + "', '" + cabTypeOfCar + "',  '" + cabDateOfPickup + "',  '" + cb_pickup_hh + "', '" + cb_pickup_mm + "', '" + cabTypeOfTravel + "', '" + cabFromAddress + "', '" + cabToAddress + "')";
                                    loggerCnsl.info("sQuery --> " + sQuery);
                                    cmnMethod.executeUpdateQry(sQuery, Sessionid);

                                    //Need to implement mail trigger for cab services team as per the 
                                    String StrMailBody = "<HTML><head><style>td{padding: 6px 6px;width: 180px;border: 1px solid #ccc;}th{padding: 6px 6px;width: 180px;border: 1px solid #ccc;background:blue;color:white;}</style></head><BODY>Dear Guest<b></b>,<BR><BR>Thank you for the cab booking request.<BR><br><h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Request Details</h4>"
                                            + "<TABLE> <TR><TH>Employee Code</TH> <TH>Employee Name</TH> <TH>Email ID</TH><TH>Contact Number</TH><TH>Designation</TH><TH>Grade</TH><TH>Cost Center</TH><TH>Cab Location</TH>  <TH> Date Of Pickup</TH><TH>Pickup Time</TH><TH>Type Of Car</TH><TH>Type Of Travel</TH><TH>From Location</TH><TH>To Location</TH></TR>"
                                            + "<TR><TD><B>" + strreqEmployeeNumber + "</B></TD><TD>" + strEmployeeName + "</TD> <TD>" + strreqEmailID + "</TD><TD>" + strtContactNumber + "</TD> <TD>" + strDesignation + "</TD> <TD>" + strGrade + "</TD><TD>" + strCostCenter + "</TD><TD>" + cabLocation + "</TD><TD>" + cabDateOfPickup + "</TD><TD>" + cb_pickup_hh + ":" + cb_pickup_mm + "</TD><TD>" + cabTypeOfCar + "</TD><TD>" + cabTypeOfTravel + "</TD><TD>" + cabFromAddress + "</TD><TD>" + cabToAddress + "</TD></TR>"
                                            + "</TABLE>";
                                    StrMailBody += "<br><br>The chaufeur and vehicle details will be shared shortly.<br><br><br><b>Regards,<br>Admin Team</b><br><BR><FONT style=\"COLOR: red\">Note:- This is a system generated E-mail,please do not reply to this E-mail.</FONT><BR></BODY></HTML>";
                                    String strQuery = "INSERT INTO WFMAILQUEUETABLE ( mailFrom,mailTo, mailCC, mailSubject, mailMessage, mailContentType, mailPriority, mailStatus,insertedBy, mailActionType, insertedTime,processDefId,processInstanceId, workitemId, activityId,noOfTrials )VALUES('" + strreqEmailID + "','" + strCABREQ_USEREMAIL + "','" + strreqEmailID + ";travel@britindia.com','Successfully registered the Cab request details from Britannia Industries Ltd. Please refere " + result + " and Cab details will be shared shortly.','" + StrMailBody + "','text/html;charset=UTF-8',1,'N', 'CabBooking', 'N',getdate(), 12,'" + result + "',1,9,0)";
                                    loggerCnsl.info("sQuery --> " + strQuery);
                                    cmnMethod.executeMailUpdateQry(strQuery, Sessionid);
                                }
                                //Guest House Booking Details
                                String sQuery1 = "INSERT INTO dbo.EXT_Complex_BookingDetails (PID, RoomName, RoomNumber, RoomType, RoomStatus, BookingComments, BookingFor)\n"
                                        + "VALUES ('" + result + "','" + strbookingRoomName + "', '" + strbookingRoomNumber + "', '" + strbookingRoomType + "', 'Available',  '" + strbookingComments + "', '" + strbookingBookingFor + "')";
                                loggerCnsl.info("sQuery1 --> " + sQuery1);
                                cmnMethod.executeUpdateQry(sQuery1, Sessionid);
                                //Guest House Booking
                                String sQuery2 = "INSERT INTO dbo.EXT_GUESTHOUSE_OCCUPANCY_DETAILS_ACTIVE (GuestHouseLocation, FromDate, CheckInTime, ToDate, CheckOutTime, RoomType, RoomName, RoomNumber, RoomStatus, NoOfNights, NoOfPersons, FullAddress, ReservationsBy, ContactDetails, CareTakerDetails, RegionalAdmin, EmployeeCode, EmpUserID, EmployeeName, EmpEmailID, EmpContactNumber, DateOfTravel, FromLocation, ToLocation, Comments, LastModifiedOn, PID, BookingFor)\n"
                                        + "VALUES ('" + strguestLocation + "','" + strfromdate1 + "', '" + strcb_checkin_hh + ":" + strcb_checkin_mm + "','" + strtodate1 + "', '" + strcb_checkout_hh + ":" + strcb_checkout_mm + "', '" + strbookingRoomType + "', '" + strbookingRoomName + "', '" + strbookingRoomNumber + "',  '" + strRomSts + "',  '" + noofnights + "', '" + strnoofpersons + "','','','','','','" + strreqEmployeeNumber + "', '" + strEmpUserID + "',  '" + strEmployeeName + "', '" + strreqEmailID + "','" + strtContactNumber + "','','','','" + strcomments + "',getDate(),'" + result + "','" + strbookingBookingFor + "')";
                                loggerCnsl.info("sQuery2 --> " + sQuery2);
                                cmnMethod.executeUpdateQry(sQuery2, Sessionid);
                                //Insert Comments
                                String sQuery3 = "INSERT INTO dbo.EXT_GuestHouseBooking_CommentsHistory (Username, Proc_instid, Comments, EntryDateTime, workstepName, ACTION, Stage, CommentsType)\n"
                                        + "VALUES ('" + strEmpUserID + "','" + result + "', '" + strcomments + "',getDate(),'GHB_Registration', 'Register','Registered','External')";
                                loggerCnsl.info("sQuery3 --> " + sQuery3);
                                cmnMethod.executeUpdateQry(sQuery3, Sessionid);

                                //Need to implement the mail trigger to admin team for booking GuestHouse Rooms
                                String StrMailBody = "<HTML><head><style>td{padding: 6px 6px;width: 180px;border: 1px solid #ccc;}th{padding: 6px 6px;width: 180px;border: 1px solid #ccc;background:blue;color:white;}</style></head><BODY>Dear Sir/Madam <b></b>,<BR><BR>Greetings of the day!!<BR><BR>We are pleased to confirm your stay in our Britannia Gardens Guest House as per itinerary mentioned below.<br><br><h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Request Details</h4>"
                                        + "<TABLE> <TR><TH>Employee Code</TH> <TH>Employee Name</TH> <TH>Email ID</TH><TH>Contact Number</TH><TH>Designation</TH><TH>Grade</TH><TH>Request Type</TH><TH>Guest House Location</TH> <TH>Guest House Details </TH><TH>Check-In Date</TH><TH>Check-In Time</TH><TH>Check-Out Date</TH><TH>Check-Out Time</TH><TH>No Of Nights</TH><TH>No Of Persons</TH></TR>"
                                        + "<TR><TD><B>" + strreqEmployeeNumber + "</B></TD><TD>" + strEmployeeName + "</TD> <TD>" + strreqEmailID + "</TD><TD>" + strtContactNumber + "</TD> <TD>" + strDesignation + "</TD> <TD>" + strGrade + "</TD><TD>" + strRequestType + "</TD><TD>" + strguestLocation + "</TD><TD><b>" + strFullAddress + "<BR><BR><p style=\"color: #0a79d2;font-weight: bold;\">" + strCareTakerDetails + "<p></b></TD><TD>" + strfromdate + "</TD><TD>" + strcb_checkin_hh + ":" + strcb_checkin_mm + "</TD><TD>" + strtodate + "</TD><TD>" + strcb_checkout_hh + ":" + strcb_checkout_mm + "</TD><TD>" + noofnights + "</TD><TD>" + strnoofpersons + "</TD></TR>"
                                        + "</TABLE>";
                                StrMailBody += "<h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Booking Details</h4><TABLE> <TR><TH>Booking For</TH><TH>Room Type</TH> <TH>Room Name</TH> <TH>Room Number</TH> <TH>Room Status</TH> <TH>Booking Comments</TH></TR><TR><TD>" + strbookingBookingFor + "</TD><TD>" + strbookingRoomType + "</TD> <TD>" + strbookingRoomName + "</TD><TD>" + strbookingRoomNumber + "</TD> <TD>" + strRomSts + "</TD> <TD>" + strbookingComments + "</TD> </TR></TABLE>";
                                StrMailBody += "<br><br>The Britannia Administration team wihses you a happy journey and a pleasant stay.<br><br><br><b>Regards,<br>Admin Team</b><br><BR><FONT style=\"COLOR: red\">Note:- This is a system generated E-mail,please do not reply to this E-mail.</FONT><BR></BODY></HTML>";
                                String strQuery = "INSERT INTO WFMAILQUEUETABLE ( mailFrom,mailTo, mailCC, mailSubject, mailMessage, mailContentType, mailPriority, mailStatus,insertedBy, mailActionType, insertedTime,processDefId,processInstanceId, workitemId, activityId,noOfTrials )VALUES('" + strreqEmailID + "','" + strREGIONALADMIN_USEREMAIL + "','" + strreqEmailID + ";" + strGUESTHOUSE_USEREMAIL + "','Your Guest House has been booked successfully. Please refere " + result + "','" + StrMailBody + "','text/html;charset=UTF-8',1,'N', 'GuestHouseBooking', 'N',getdate(), 12,'" + result + "',1,9,0)";
                                loggerCnsl.info("sQuery --> " + strQuery);
                                cmnMethod.executeMailUpdateQry(strQuery, Sessionid);
                                if (!(CommonMethod.isNullOrEmpty(objHPF.getComments())) && !(strcomments.equalsIgnoreCase("NA"))) {
                                    //Need to implement the mail trigger to admin team for booking GuestHouse Rooms with Special Instructions
                                    String StrMailBody1 = "<HTML><head><style>td{padding: 6px 6px;width: 180px;border: 1px solid #ccc;}th{padding: 6px 6px;width: 180px;border: 1px solid #ccc;background:blue;color:white;}</style></head><BODY>Dear Sir/Madam <b></b>,<BR><BR>Greetings of the day!!<BR><BR>We are pleased to confirm your stay in our Britannia Gardens Guest House as per itinerary mentioned below.<br><br><h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Request Details</h4>"
                                            + "<TABLE> <TR><TH>Employee Code</TH> <TH>Employee Name</TH> <TH>Email ID</TH><TH>Contact Number</TH><TH>Designation</TH><TH>Grade</TH><TH>Request Type</TH><TH>Guest House Location</TH> <TH>Guest House Details </TH><TH>Check-In Date</TH><TH>Check-In Time</TH><TH>Check-Out Date</TH><TH>Check-Out Time</TH><TH>No Of Nights</TH><TH>No Of Persons</TH><TH style=\"background:#F44336;padding:4px;text-align:center;color:#fff;\">Special Instructions</TH></TR>"
                                            + "<TR><TD><B>" + strreqEmployeeNumber + "</B></TD><TD>" + strEmployeeName + "</TD> <TD>" + strreqEmailID + "</TD><TD>" + strtContactNumber + "</TD> <TD>" + strDesignation + "</TD> <TD>" + strGrade + "</TD><TD>" + strRequestType + "</TD><TD>" + strguestLocation + "</TD><TD><b>" + strFullAddress + "<BR><BR><p style=\"color: #0a79d2;font-weight: bold;\">" + strCareTakerDetails + "<p></b></TD><TD>" + strfromdate + "</TD><TD>" + strcb_checkin_hh + ":" + strcb_checkin_mm + "</TD><TD>" + strtodate + "</TD><TD>" + strcb_checkout_hh + ":" + strcb_checkout_mm + "</TD><TD>" + noofnights + "</TD><TD>" + strnoofpersons + "</TD><TD style=\"background:#F44336;padding:4px;text-align:center;color:#fff;\">" + strcomments + "</TD></TR>"
                                            + "</TABLE>";
//                                    StrMailBody1 += "<h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Booking Details</h4><TABLE> <TR><TH>Booking For</TH><TH>Room Type</TH> <TH>Room Name</TH> <TH>Room Number</TH> <TH>Room Status</TH> <TH>Booking Comments</TH></TR><TR><TD>" + strbookingBookingFor + "</TD><TD>" + strbookingRoomType + "</TD> <TD>" + strbookingRoomName + "</TD><TD>" + strbookingRoomNumber + "</TD> <TD>" + strRomSts + "</TD> <TD>" + strcomments + "</TD> </TR></TABLE>";
                                    StrMailBody1 += "<br><br>The Britannia Administration team wihses you a happy journey and a pleasant stay.<br><br><br><b>Regards,<br>Admin Team</b><br><BR><FONT style=\"COLOR: red\">Note:- This is a system generated E-mail,please do not reply to this E-mail.</FONT><BR></BODY></HTML>";
                                    String strQuery12 = "INSERT INTO WFMAILQUEUETABLE ( mailFrom,mailTo, mailCC, mailSubject, mailMessage, mailContentType, mailPriority, mailStatus,insertedBy, mailActionType, insertedTime,processDefId,processInstanceId, workitemId, activityId,noOfTrials )VALUES('" + strreqEmailID + "','" + strREGIONALADMIN_USEREMAIL + "','" + strreqEmailID + ";" + strGUESTHOUSE_USEREMAIL + "','Guest House has been booked with Special Instructions. Please refere " + result + "','" + StrMailBody1 + "','text/html;charset=UTF-8',1,'N', 'GuestHouseBooking', 'N',getdate(), 12,'" + result + "',1,9,0)";
                                    loggerCnsl.info("sQuery --> " + strQuery12);
                                    cmnMethod.executeMailUpdateQry(strQuery12, Sessionid);
                                }
                            }

                        } else {
                            objHPF.setPID("Pending");
                        }
                    }
//                     CommonMethod.disconCabinet(probBean, Sessionid);
//                    if (!isPasswordProtectedDocExist) {
                    try {
//                        session.saveOrUpdate(objHPF);
//                        transaction.commit();
                        loggerCnsl.info("Data Updated Successfully");
                        if (objHPF.getPID().equalsIgnoreCase("Pending")) {
                            out.println("Invalid Session, Please try to login and register New Ticket again..!");
                        } else {
                            out.println("New ticket <b>" + objHPF.getPID() + "</b> has been registered in Guest House Booking System");
                        }
//                            CommonMethod.disconCabinet(probBean, Sessionid);//for Logged in user not required
                        request.setAttribute("EmployeeCode", strreqEmployeeNumber);
                    } catch (Exception e) {
                        loggerCnsl.info("Exception occurred in Hibernate while updating the data " + e);
                    }
//                    } else {
//                        out.println("Password protected document exist, Cannot update the data!");
//                        CommonMethod.disconCabinet(probBean, Sessionid);
//                        session.close();
//                        sessionFactory.close();
//                    }
                    //17-May-2018

//            request.getRequestDispatcher("uploadkyc.jsp").forward(request, response);
                } catch (Exception e) {
                    loggerErr.info("Exception :: " + e.getMessage());
                    request.setAttribute("EmployeeCode", "");
//            request.getRequestDispatcher("uploadkyc.jsp").forward(request, response);
                } // TODO Auto-generated catch block
                finally {
//                    session.close();
                    CommonMethod.disconCabinet(probBean, Sessionid);
//                    sessionFactory.close();
                }
            } else {
                request.setAttribute("EmployeeCode", "");
                System.out.println("Please contact HR team to create/update employee details in SAP master");
//            request.getRequestDispatcher("uploadkyc.jsp").include(request, response);
            }
        } catch (Exception e) {
            loggerErr.info("Exception ===> " + e.getMessage());
//            request.getRequestDispatcher("uploadkyc.jsp").include(request, response);
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        loggerCnsl.info("*********^^^^^^^  Inside doGet method ^^^^^^^^^^^^*********");
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
