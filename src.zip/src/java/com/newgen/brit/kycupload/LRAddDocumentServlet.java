/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload;

import ISPack.ISUtil.JPISException;
import com.itextpdf.text.exceptions.BadPasswordException;
import com.itextpdf.text.pdf.PdfReader;
import com.newgen.brit.kycupload.beans.HelpDeskPortalFields;
import com.newgen.brit.kycupload.beans.KYCMaster;
import com.newgen.brit.kycupload.beans.LRFields;
import com.newgen.brit.util.AddToSMS;
import com.newgen.brit.util.CommonMethod;
import com.newgen.brit.util.PropReader;
import com.newgen.brit.util.PropertyBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */
public class LRAddDocumentServlet extends HttpServlet {

    Session session = null;
    SessionFactory sessionFactory = null;
    Transaction transaction = null;
    PrintWriter out = null;
    private String result = "";
    String filePath = null;
    String fileName = "";
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
        loggerCnsl.info("*********^^^^^^^  Inside processRequest method ^^^^^^^^^^^^*********");
        try {
            loggerCnsl.info("request.getParameter(\"EmployeeNumber\") " + request.getParameter("EmployeeNumber"));
            if (!request.getParameter("EmployeeNumber").equalsIgnoreCase("")) {
                try {
//                    Configuration cfg = new Configuration().configure("com/newgen/brit/kycupload/resources/helpdeskhibernate.cfg.xml");
//                    sessionFactory = cfg.buildSessionFactory();
//                    session = sessionFactory.openSession();
                } catch (Exception e) {
                    loggerErr.info("Exception " + e.getMessage());
                }
                try {
//                    transaction = session.beginTransaction();
                    out = response.getWriter();
                    LRFields objHPF = new LRFields();
                    String strreqEmployeeNumber = request.getParameter("reqEmployeeNumber");
                    String strreqEmployeeName = request.getParameter("reqEmployeeName");
                    loggerCnsl.info("strEmployeeCode after get param " + strreqEmployeeNumber);
                    loggerCnsl.info("strEmployeeName after get param " + strreqEmployeeName);
                    String strsessionID = request.getParameter("sessionID");
                    String strscabinetName = request.getParameter("cabinetName");
                    String strreqEmailID = request.getParameter("reqEmailID");
                    String strdateofrequest = request.getParameter("dateofrequest");
                    String strreqWorkLocation = request.getParameter("reqWorkLocation");
                    String strEmployeeNumber = request.getParameter("EmployeeNumber");
                    String strEmployeeName = request.getParameter("EmployeeName");
                    String strEmployeeUID = request.getParameter("hiddenUserID");
                    String strDateOfJoining = request.getParameter("DateOfJoining");
                    String strEmailID = request.getParameter("EmailID");
                    String strPOrg = request.getParameter("POrg");
                    String strPA = request.getParameter("PA");
                    String strPSA = request.getParameter("PSA");
                    String strtContactNumber = request.getParameter("ContactNumber");
                    String strEmpGrade = request.getParameter("EmpGrade");
                    String strEmpDesignation = request.getParameter("EmpDesignation");
                    String strCorporateFunction = request.getParameter("CorporateFunction");
                    String strHRFunction = request.getParameter("HRFunction");
                    String strRegion = request.getParameter("Region");
                    String strWorkLocation = request.getParameter("WorkLocation");
                    String strvendorCode = request.getParameter("vendorCode");
                    String strvendorGL = request.getParameter("vendorGL");
                    String strDepartment = request.getParameter("Department");
                    String strRepManager = request.getParameter("RepManager");
                    String strHRBPName = request.getParameter("HRBPName");
                    String strhiddenHRBP = request.getParameter("hiddenHRBP");
                    String strhiddenHRBPEmployeeCode = request.getParameter("hiddenHRBPEmployeeCode");
                    String strComplaintRaisedBy = request.getParameter("ComplaintRaisedBy");
                    String strcomplaintraisedon = request.getParameter("complaintraisedon");
                    String strcomplaintAbout = request.getParameter("complaintAbout");
                    String strComplaintAboutOthers = request.getParameter("ComplaintAboutOthers");
                    String strreferenceComments = request.getParameter("referenceComments");
                    String strdetailsOfComplaint = request.getParameter("detailsOfComplaint");
                    String strcomments = request.getParameter("comments");
                    String strisBritEmployee = request.getParameter("isBritEmployee");
                    String strcomRepEmployeeNumber = "";
                    String strcomRepEmployeeName = "";
                    String strcomRepEmailID = "";
                    String strcomRepWorkLocation = "";
                    String strcomRepNonEmployeeNumber = "";
                    String strcomRepNonEmployeeName = "";
                    if (strisBritEmployee.equalsIgnoreCase("Yes")) {
                        strcomRepEmployeeNumber = request.getParameter("comRepEmployeeNumber");
                        strcomRepEmployeeName = request.getParameter("comRepEmployeeName");
                        strcomRepEmailID = request.getParameter("comRepEmailID");
                        strcomRepWorkLocation = request.getParameter("comRepWorkLocation");
                    } else if (strisBritEmployee.equalsIgnoreCase("No")) {
                        strcomRepNonEmployeeNumber = request.getParameter("comRepNonEmployeeNumber");
                        strcomRepNonEmployeeName = request.getParameter("comRepNonEmployeeName");
                    }
                    String strInitiationType = request.getParameter("InitiationType");
                    String strDOJ = "";
                    String strDateOfReq1 = "";
                    String strCompRaiseOn1 = "";
                    loggerCnsl.info("strsessionID --> " + strsessionID);
                    loggerCnsl.info("strscabinetName --> " + strscabinetName);
                    loggerCnsl.info("strCorporateFunction --> " + strCorporateFunction);
                    loggerCnsl.info("strHRFunction --> " + strHRFunction);
                    loggerCnsl.info("strcomplaintraisedon --> " + strcomplaintraisedon);
                    strDOJ = CommonMethod.formatDate(strDateOfJoining);
                    strDateOfReq1 = CommonMethod.formatDate(strdateofrequest);
                    strCompRaiseOn1 = CommonMethod.formatDate(strcomplaintraisedon);
                    loggerCnsl.info("strCompRaiseOn1 --> " + strCompRaiseOn1);
                    objHPF.setReqEmployeeNumber(strreqEmployeeNumber);
                    objHPF.setReqEmployeeName(strreqEmployeeName);
                    objHPF.setReqEmailID(strreqEmailID);
                    objHPF.setStrdateofrequest(strDateOfReq1);
                    objHPF.setReqWorkLocation(strreqWorkLocation);

                    objHPF.setEmployeeNumber(strEmployeeNumber);
                    objHPF.setEmployeeName(strEmployeeName);
                    objHPF.setStrEmployeeUID(strEmployeeUID);
                    objHPF.setDateOfJoining(strDOJ);
                    objHPF.setEmailID(strEmailID);
                    objHPF.setPOrg(strPOrg);
                    objHPF.setPA(strPA);
                    objHPF.setPSA(strPSA);
                    objHPF.setContactNumber(strtContactNumber);
                    objHPF.setEmpGrade(strEmpGrade);
                    objHPF.setEmpDesignation(strEmpDesignation);
                    objHPF.setCorporateFunction(strCorporateFunction);
                    objHPF.setHRFunction(strHRFunction);
                    objHPF.setRegion(strRegion);
                    objHPF.setWorkLocation(strWorkLocation);
                    objHPF.setVendorCode(strvendorCode);
                    objHPF.setVendorGL(strvendorGL);
                    objHPF.setDepartment(strDepartment);
                    objHPF.setRepManager(strRepManager);
                    objHPF.setHRBPName(strHRBPName);
                    objHPF.setHiddenHRBP(strhiddenHRBP);
                    objHPF.setHiddenHRBPEmployeeCode(strhiddenHRBPEmployeeCode);
                    objHPF.setComplaintRaisedBy(strComplaintRaisedBy);
                    objHPF.setComplaintraisedon(strCompRaiseOn1);
                    objHPF.setComplaintAbout(strcomplaintAbout);
                    objHPF.setComplaintAboutOthers(strComplaintAboutOthers);
                    objHPF.setReferenceComments(strreferenceComments);
                    objHPF.setDetailsOfComplaint(strdetailsOfComplaint);
                    objHPF.setComments(strcomments);
                    objHPF.setIsBritEmployee(strisBritEmployee);
                    if (strisBritEmployee.equalsIgnoreCase("Yes")) {
                        objHPF.setComRepEmployeeNumber(strcomRepEmployeeNumber);
                        objHPF.setComRepEmployeeName(strcomRepEmployeeName);
                        objHPF.setComRepEmailID(strcomRepEmailID);
                        objHPF.setComRepWorkLocation(strcomRepWorkLocation);
                    } else if (strisBritEmployee.equalsIgnoreCase("No")) {
                        objHPF.setComRepNonEmployeeNumber(strcomRepNonEmployeeNumber);
                        objHPF.setComRepNonEmployeeName(strcomRepNonEmployeeName);
                    }
                    //Add document starts here
                    String Sessionid = "";
                    PropertyBean probBean = null;
                    ArrayList<String> AddtoSMS_Response_sd = null;
                    AddtoSMS_Response_sd = new ArrayList<String>();
                    loggerCnsl.info("************getting sessionID using static user Execution Starts ***************");
                    PropReader propReader = new PropReader();
                    probBean = new PropertyBean();
                    probBean = propReader.readPropertyFile();
                    PropertyBean probBeanConnectRes = CommonMethod.connect(probBean);
                    String sessionID = probBeanConnectRes.getUserDBId();
                    loggerCnsl.info("sessionID :: " + sessionID);
                    loggerCnsl.info("************getting sessionID using static user Execution Ends ***************");
//                    Sessionid = strsessionID;//logged in user
                    Sessionid = sessionID;//HelpDesk_Initiator user
                    String a = "";
                    String strCabinetName = probBean.getCabinetName();
                    String strUserName = probBean.getUserName();
                    String strPassword = probBean.getPassword();
                    String strServerIP = probBean.getServerIP();
                    String strjtsPort = probBean.getJtsPort();
                    String strVolumeIndex = probBean.getVolumeIndex();

                    String strWorkitemEndPointurl = probBean.getWorkitemEndPointurl();
                    String strInitiateFromActivityId = "1";
                    String strInitiateFromActivityName = "LR_Initiation";
//                    String strProcessDefId = "11";//for UAT
                    String strProcessDefId = "5";//for PRODUCTION
                    String strProcessName = "LR";
                    String strCabinet = probBean.getCabinet();
//                    Sessionid = "1791058955";

                    if (Sessionid == "" || Sessionid == "error"
                            || Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
                        loggerCnsl.info("Error in getting OD session id!!");
                        loggerCnsl.info("Error in getting OD session id!!");
                        out.println("Error in getting OD session id!!");
                        response.setStatus(500);
                        result = "500";
                        return;
                    }
                    loggerCnsl.info("sessionID ===> " + Sessionid);
                    if (strInitiationType.equalsIgnoreCase("withDoc")) {
                        String serverPath = System.getProperty("user.dir");
                        String folderpath = "", Docname = "", strDocType = "", strDocData = "";
                        loggerCnsl.info("Working Directory = " + System.getProperty("user.dir"));

                        boolean isMultipart = ServletFileUpload.isMultipartContent(request);
                        loggerCnsl.info("isMultipartContent::" + isMultipart);
                        isMultipart = true;
                        if (!isMultipart) {
                            response.setStatus(501);
                            out.println("is not Multipart Content!!");
                            return;
                        }
                        List items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

                        loggerCnsl.info("items Size :::: " + items.size());
                        if (items.size() == 0) {
                            response.setStatus(502);
                            out.println("items size is 0!!");
                            result = "502";
                            out.print("Requested operation timeout. Please try after sometimes");
                            return;

                        }
//                    boolean isPasswordProtectedDocExist = false;
//                    int j = 0;
//
//                    for (int i = 0; i < items.size(); i++) {
//
//                        FileItem item_sd = (FileItem) items.get(i);
////                        if (i == 2 || i == 3) {
//                        if (item_sd.isFormField()) {
//                            loggerCnsl.info("inside is form field..!");
//                            // do nothing
//                        } else {
//                            loggerCnsl.info("inside else is form field..!");
//                            long cdt = System.currentTimeMillis();
//                            folderpath = serverPath + File.separator + "Documents";
//                            loggerCnsl.info("folderpath " + folderpath);
//                            File file = new File(folderpath);
//                            if (!file.isDirectory()) {
//                                file.mkdir();
//                            }
//                            String itemName = item_sd.getName();
//                            itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());
//                            fileName = itemName;
//
//                            filePath = folderpath + File.separator + cdt + "_" + itemName;
//                            loggerCnsl.info("filePath ----> " + filePath);
//                            File savedFile = new File(filePath);
//                            item_sd.write(savedFile);                            
//                        }
//                        loggerCnsl.info("filePath ----> " + filePath);
//                        try {
//                            loggerCnsl.info("filepath ---> " + filePath);
//                            PdfReader reader = new PdfReader(filePath);
//                        } catch (BadPasswordException e) {
//                            isPasswordProtectedDocExist = true;
//                            loggerCnsl.info("PDF is password protected");
//                        } catch (Exception e) {
//                            loggerCnsl.info("Exception in Reading File");
//                        }
//
////                        }
//                    }
//                    if (!isPasswordProtectedDocExist) {
                        for (int i = 0; i < items.size(); i++) {

                            FileItem item_sd = (FileItem) items.get(i);
                            loggerCnsl.info("no----->" + i);
//                        if (i == 2 || i == 3) {
                            if (item_sd.isFormField()) {
                                loggerCnsl.info("inside is form field..!");
                                // do nothing
                            } else {
                                loggerCnsl.info("inside else is form field..!");
                                long cdt = System.currentTimeMillis();
                                folderpath = serverPath + File.separator + "Documents";
                                loggerCnsl.info("folderpath " + folderpath);
                                File file = new File(folderpath);
                                if (!file.isDirectory()) {
                                    file.mkdir();
                                }
                                String itemName = item_sd.getName();
                                itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());
                                fileName = itemName;

                                filePath = folderpath + File.separator + cdt + "_" + itemName;
                                File savedFile = new File(filePath);
                                item_sd.write(savedFile);

                            }

                            if (i == 0) {
                                Docname = strEmployeeNumber + "_" + strreqEmployeeName;
                                strDocType = "LR_Attachment";
                                strDocData = strEmployeeNumber;
                            }

                            loggerCnsl.info("Docname ----> " + Docname);
                            loggerCnsl.info("filePath ----> " + filePath);
//                            boolean flag = false;
//                            try {
//                                loggerCnsl.info("filepath ---> " + filePath);
//                                PdfReader reader = new PdfReader(filePath);
//                            } catch (BadPasswordException e) {
//                                flag = true;
//                                isPasswordProtectedDocExist = true;
//                                loggerCnsl.info("PDF is password protected");
//                            } catch (Exception e) {
//                                loggerCnsl.info("Exception in Reading File");
//                            }
//
//                            if (flag) {
//                                try {
//                                    loggerCnsl.info("PDF is password protected");
//                                } catch (Exception e) {
//                                    loggerCnsl.info("Exception occurred in pswdprotectd() " + e);
//                                }
//                            } else {
//                                loggerCnsl.info("File is not password protected");
                            a = AddToSMS.AddtoSms(Docname, filePath, Sessionid, strServerIP, strCabinetName,
                                    strjtsPort, strVolumeIndex);
                            loggerCnsl.info("+AddtoSMS_Response_sd--->" + a);
                            AddtoSMS_Response_sd.add(a);
                            String strDocIndex = null;
                            if (AddtoSMS_Response_sd != null && AddtoSMS_Response_sd.size() != 0) {
                                CommonMethod cmnMethod = new CommonMethod();
                                String result = cmnMethod.initiateLRworkitemwithDocument(objHPF, strWorkitemEndPointurl, Sessionid,
                                        AddtoSMS_Response_sd, strCabinet, strInitiateFromActivityId, strInitiateFromActivityName,
                                        strProcessDefId, strProcessName, Docname);
                                loggerCnsl.info("CaseNumber --> " + result);
                                if (!result.equalsIgnoreCase("Pending")) {
                                    objHPF.setPID(result);
                                } else {
                                    objHPF.setPID("Pending");
                                }
//                                    CommonMethod cmnMethod = new CommonMethod();
//                                    loggerCnsl.info("strEmployeeCode before addfolder ==> " + strEmployeeCode);
//                                    loggerCnsl.info("Sessionid before addfolder ==> " + Sessionid);
//                                    String folderIndex = cmnMethod.addFolder(strEmployeeCode, Sessionid);
//                                    File tifFile = new File(filePath);
//                                    String tifFileName = tifFile.getName();
//                                    String fileSize = Long.toString(new File(filePath).length());
//                                    String fileExtn = tifFileName.substring(tifFileName.lastIndexOf(".") + 1, tifFileName.length());
//                                    strDocIndex = cmnMethod.adddocument(filePath, fileSize, 0, a.toString(), fileExtn, "I", folderIndex, Docname, Sessionid);
//                                    loggerCnsl.info(" :: Document uploaded succesfully in OD :: strDocIndex is ==> " + strDocIndex);
//                                    cmnMethod.addDocProperties(strDocIndex, Sessionid, strEmployeeCode, strDocType, strDocData);
//                           loggerCnsl.info(" :: Document uploaded succesfully in OD :: strDocIndex is ==> " + strDocIndex);                           
                            } else {
                                loggerCnsl.info(" :: Document uploaded failed in OD :: ");
                            }
//                            }

//                        }
                        }
                    } else {
                        CommonMethod cmnMethod = new CommonMethod();
                        String result = cmnMethod.initiateLRworkitem(objHPF, strWorkitemEndPointurl, Sessionid, strCabinet, strInitiateFromActivityId, strInitiateFromActivityName,
                                strProcessDefId, strProcessName);
                        loggerCnsl.info("CaseNumber --> " + result);
                        if (!result.equalsIgnoreCase("Pending")) {
                            objHPF.setPID(result);
                            String sInputArr[] = objHPF.getComplaintAbout().split(";");
                            for (int b = 0; b < sInputArr.length; b++) {
                                String sQuery = "INSERT INTO EXT_LR_complex_ComplaintAbout values ('" + result + "','" + sInputArr[b] + "')";
                                cmnMethod.executeUpdateQry(sQuery, Sessionid);
                            }
                        } else {
                            objHPF.setPID("Pending");
                        }
                    }
//                     CommonMethod.disconCabinet(probBean, Sessionid);
//                    if (!isPasswordProtectedDocExist) {
                    try {
//                        session.saveOrUpdate(objHPF);
//                        transaction.commit();
                        loggerCnsl.info("Data Updated Successfully");
                        if (objHPF.getPID().equalsIgnoreCase("Pending")) {
                            out.println("Invalid Session, Please try to login and register New Ticket again..!");
                        } else {
                            out.println("New ticket <b>" + objHPF.getPID() + "</b> has been registered in Compliance & Repository System");
                        }
//                            CommonMethod.disconCabinet(probBean, Sessionid);//for Logged in user not required
                        request.setAttribute("EmployeeCode", strEmployeeNumber);
                    } catch (Exception e) {
                        loggerCnsl.info("Exception occurred in Hibernate while updating the data " + e);
                    }
//                    } else {
//                        out.println("Password protected document exist, Cannot update the data!");
//                        CommonMethod.disconCabinet(probBean, Sessionid);
//                        session.close();
//                        sessionFactory.close();
//                    }
                    //17-May-2018

//            request.getRequestDispatcher("uploadkyc.jsp").forward(request, response);
                } catch (Exception e) {
                    loggerErr.info("Exception :: " + e.getMessage());
                    request.setAttribute("EmployeeCode", "");
//            request.getRequestDispatcher("uploadkyc.jsp").forward(request, response);
                } catch (JPISException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } finally {
//                    session.close();
//                    sessionFactory.close();
                }
            } else {
                request.setAttribute("EmployeeCode", "");
                System.out.println("Please contact HR team to create/update employee details in SAP master");
//            request.getRequestDispatcher("uploadkyc.jsp").include(request, response);
            }
        } catch (Exception e) {
            loggerErr.info("Exception ===> " + e.getMessage());
//            request.getRequestDispatcher("uploadkyc.jsp").include(request, response);
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        loggerCnsl.info("*********^^^^^^^  Inside doGet method ^^^^^^^^^^^^*********");
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
