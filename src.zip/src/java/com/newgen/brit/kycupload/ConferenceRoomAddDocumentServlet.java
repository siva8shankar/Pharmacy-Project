/** ******************************************************************
 *    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 *    Group                                     	: SDC-South
 *    Product / Project                  	: Britannia Industries Limited
 *    Module                                  	: customibps
 *    File Name                               	: ConferenceRoomAddDocumentServlet.java
 *    Author                                    	: ksivashankar
 *    Date written                          	: 13/09/2019
 *    (DD/MM/YYYY)
 *    Description                            	: Add document servlet
 *  CHANGE HISTORY
 ***********************************************************************************************
 * Date                                Change By                    Change Description (Bug No. (If Any))
 * (DD/MM/YYYY)
 *********************************************************************************************** */
package com.newgen.brit.kycupload;

import com.newgen.brit.kycupload.beans.CNFRoomDetails;
import com.newgen.brit.util.CNFROOMCommonMethods;
import com.newgen.brit.util.CommonMethod;
import com.newgen.brit.util.PropReader;
import com.newgen.brit.util.PropertyBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */
public class ConferenceRoomAddDocumentServlet extends HttpServlet {

    PrintWriter out = null;
    private String result = "";
    String filePath = null;
    String fileName = "";
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
        loggerCnsl.info("*********^^^^^^^  Inside processRequest method ^^^^^^^^^^^^*********");
        try {
            loggerCnsl.info("request.getParameter(\"EmployeeNumber\") " + request.getParameter("EmployeeNumber"));
            if (!request.getParameter("EmployeeNumber").equalsIgnoreCase("")) {
                try {
                } catch (Exception e) {
                    loggerErr.info("Exception " + e.getMessage());
                }
                String Sessionid = "";
                PropertyBean probBean = null;
                boolean strCNFDBSts = false;
                boolean strMailSts = false;
                String duplicateCheck = "";
                try {
                    String strRomSts = "";
                    out = response.getWriter();
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
                    String strreqEmployeeNumber = request.getParameter("EmployeeNumber");
                    String strEmpUserID = request.getParameter("empUserID");
                    String strEmployeeName = request.getParameter("strEmployeeName");
                    loggerCnsl.info("strEmployeeCode after get param " + strreqEmployeeNumber);
                    loggerCnsl.info("strEmpUserID after get param " + strEmpUserID);
                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);
                    String strsessionID = request.getParameter("sessionID");
                    String strscabinetName = request.getParameter("cabinetName");
                    String strreqEmailID = request.getParameter("EmailID");
                    String strtContactNumber = request.getParameter("ContactNumber");
                    String strRegion = request.getParameter("Region");
                    String strVendorCode = request.getParameter("VendorCode");
                    String strVendorGL = request.getParameter("VendorGL");
                    String strDesignation = request.getParameter("Designation");
                    String strDepartment = request.getParameter("Department");
                    String strGrade = request.getParameter("Grade");
                    String strWorkLocation = request.getParameter("WorkLocation");
                    String strCostCenter = request.getParameter("CostCenter");
                    String strState = request.getParameter("State");
                    String strRepManager = request.getParameter("RepManager");
                    String strHRBPName = request.getParameter("HRBPName");
                    String strHRBPUserID = request.getParameter("HRBPUserID");
                    String strRMUserID = request.getParameter("RMUserID");
                    String strExtNumber = request.getParameter("ExtNumber");
                    String strBookedBy = request.getParameter("BookedBy");
                    String strcnfrBookedFor = request.getParameter("cnfrBookedFor");
                    String strcnfroomLocation = request.getParameter("cnfroomLocation");
                    String strcnfRoomName = request.getParameter("cnfbookingRoomName");
                    String strcnfbookingdate = request.getParameter("cnfbookingdate");
                    String strdateofrequest = request.getParameter("dateofrequest");
                    loggerCnsl.info("strEmpUserID after get param strdateofrequest = " + strdateofrequest);
                    String strfromdate1 = CommonMethod.reverseFormatDate(strcnfbookingdate);
//                    String strdateofrequest1 = CommonMethod.formatDate(strdateofrequest);
//                    loggerCnsl.info("strEmpUserID after get param strdateofrequest1== " + strdateofrequest1);
                    String strcb_fromtime_hh = request.getParameter("cb_fromtime_hh");
                    String strcb_fromtime_mm = request.getParameter("cb_fromtime_mm");
                    String strcb_totime_hh = request.getParameter("cb_totime_hh");
                    String strcb_totime_mm = request.getParameter("cb_totime_mm");
                    String noofparticipants = request.getParameter("noofparticipants");
                    String strbookingRoomStatus = request.getParameter("bookingRoomStatus");
                    String stramenitiesAvailable = request.getParameter("amenitiesAvailable");
                    String strmeetingDescription = request.getParameter("meetingDescription");
                    String strremarks = request.getParameter("remarks");
                    String strcnfRoomType = request.getParameter("cnfRoomType");
                    String strcnfRoomCapacity = request.getParameter("cnfRoomCapacity");
                    String strcnfAddressFloor = request.getParameter("cnfAddressFloor");
                    String strcnfContactDetails = request.getParameter("cnfContactDetails");
                    String strInitiationType = request.getParameter("InitiationType");

                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);

                    if (!CommonMethod.isNullOrEmpty(strremarks)) {
                        strremarks = strremarks;
                    } else {
                        strremarks = "NA";
                    }
                    loggerCnsl.info("strsessionID --> " + strsessionID);
                    loggerCnsl.info("strscabinetName --> " + strscabinetName);
                    objCNFR.setEmployeeNumber(strreqEmployeeNumber);
                    objCNFR.setEmployeeName(strEmployeeName);
                    objCNFR.setEmpUserID(strEmpUserID);
                    objCNFR.setEmailID(strreqEmailID);
                    objCNFR.setNoOfParticipants(noofparticipants);
                    objCNFR.setContactNumber(strtContactNumber);
                    objCNFR.setRegion(strRegion);
                    objCNFR.setGrade(strGrade);
                    objCNFR.setVendorCode(strVendorCode);
                    objCNFR.setVendorGL(strVendorGL);
                    objCNFR.setEmpDepartment(strDepartment);
                    objCNFR.setDesignation(strDesignation);
                    objCNFR.setWorkLocation(strWorkLocation);
                    objCNFR.setCostCenter(strCostCenter);
                    objCNFR.setState(strState);
                    objCNFR.setHRBPUserID(strHRBPUserID);
                    objCNFR.setRMUserID(strRMUserID);
                    objCNFR.setExtNumber(strExtNumber);
                    objCNFR.setBookedBy(strBookedBy);
                    objCNFR.setBookedFor(strcnfrBookedFor);
                    objCNFR.setRoomLocation(strcnfroomLocation);
                    objCNFR.setRoomName(strcnfRoomName);
                    objCNFR.setBookingDate(strcnfbookingdate);
                    objCNFR.setDateofrequest(strdateofrequest);
                    objCNFR.setFromTime(strcb_fromtime_hh + ":" + strcb_fromtime_mm);
                    objCNFR.setToTime(strcb_totime_hh + ":" + strcb_totime_mm);
                    objCNFR.setBookingRoomStatus(strbookingRoomStatus);
                    objCNFR.setAmenitiesAvailable(stramenitiesAvailable);
                    objCNFR.setMeetingDescription(strmeetingDescription);
                    objCNFR.setRemarks(strremarks);
                    objCNFR.setRoomType(strcnfRoomType);
                    objCNFR.setRoomCapacity(strcnfRoomCapacity);
                    objCNFR.setFullAddress(strcnfAddressFloor);
                    objCNFR.setContactDetails(strcnfContactDetails);
                    objCNFR.setInitiationType(strInitiationType);

                    //Add document starts here
                    loggerCnsl.info("************getting sessionID using static user Execution Starts ***************");
                    PropReader propReader = new PropReader();
                    probBean = new PropertyBean();
                    probBean = propReader.readPropertyFile();
                    PropertyBean probBeanConnectRes = CommonMethod.connect(probBean);
                    String sessionID = probBeanConnectRes.getUserDBId();
                    loggerCnsl.info("sessionID :: " + sessionID);
                    loggerCnsl.info("************getting sessionID using static user Execution Ends ***************");
//                    Sessionid = strsessionID;//logged in user
                    Sessionid = sessionID;//HelpDesk_Initiator user
                    String a = "";
                    String strCabinetName = probBean.getCabinetName();
                    String strUserName = probBean.getUserName();
                    String strPassword = probBean.getPassword();
                    String strServerIP = probBean.getServerIP();
                    String strjtsPort = probBean.getJtsPort();
                    String strVolumeIndex = probBean.getVolumeIndex();

                    String strWorkitemEndPointurl = probBean.getWorkitemEndPointurl();
                    String strInitiateFromActivityId = "1";
                    String strInitiateFromActivityName = "Request";
                    String strProcessDefId = "6";
                    String strProcessName = "GHB";
                    String strCabinet = probBean.getCabinet();

                    if (Sessionid == "" || Sessionid == "error"
                            || Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
                        loggerCnsl.info("Error in getting OD session id!!");
                        loggerCnsl.info("Error in getting OD session id!!");
                        out.println("Error in getting OD session id!!");
                        response.setStatus(500);
                        result = "500";
                        return;
                    }
                    loggerCnsl.info("sessionID ===> " + Sessionid);
                    if (strInitiationType.equalsIgnoreCase("withOutDoc")) {
                        CommonMethod cmnMethod = new CommonMethod();
                        if (objCNFR.getBookingRoomStatus().equalsIgnoreCase("Available")) {
                            strRomSts = "Booked";
                        }
                        
                        //Need to implement the code to get details of the guest house starts here
                            ArrayList<CNFRoomDetails> objCNFetails = new ArrayList<CNFRoomDetails>();
                            CNFRoomDetails confObj = null;
                            String strAdminMailID = "";
                            String strCcMailID = "";
                            objCNFetails = CNFROOMCommonMethods.getCNFDetailsMethodForMail(sessionID, probBean, objCNFR.getRoomLocation());

                            for (int i = 0; i < objCNFetails.size(); i++) {
                                System.out.println("objGHDetails.size()  --> " + objCNFetails.size());
                                System.out.println("i  --> " + i);
                                confObj = (CNFRoomDetails) objCNFetails.get(i);
                                strAdminMailID = confObj.getAdminMailID();
                                strCcMailID = confObj.getCcColumn();
                            }

                        String retVal = CNFROOMCommonMethods.getCNFRoomsAvailabilityMethod(Sessionid, objCNFR.getRoomLocation(), objCNFR.getRoomName(), objCNFR.getBookingDate(), objCNFR.getFromTime(), objCNFR.getToTime());
                        if (!(Integer.parseInt(retVal) >= 1)) {
                            duplicateCheck = "False";
                            String sQuery1 = "INSERT INTO dbo.EXT_CNFROOM_BOOKING_DETAILS_ACTIVE (RoomLocation, RoomName, BookingDate, BookedBy, BookedFor, FromTime, ToTime, BookingFromTime, BookingToTime, RoomStatus, AddressFloor, RoomType, RoomCapacity, NoOfHours, NoOfParticipants, ContactDetails, Amenities, MeetingDescription, Remarks, EmployeeCode, EmpUserID, EmployeeName, EmpEmailID, EmpContactNumber, EmpDepartment, LastModifiedOn,EmpExtNumber,DateOfRequest,StatusFlag,Region,WorkLocation,CostCenter,State) VALUES "
                                    + "('" + objCNFR.getRoomLocation() + "','" + objCNFR.getRoomName() + "', '" + objCNFR.getBookingDate() + "', '" + objCNFR.getEmployeeName() + "', '" + objCNFR.getBookedFor() + "',  '" + objCNFR.getFromTime() + "', '" + objCNFR.getToTime() + "', '" + objCNFR.getBookingDate() + " " + objCNFR.getFromTime() + ":00',  '" + objCNFR.getBookingDate() + " " + objCNFR.getToTime() + ":00', '" + objCNFR.getBookingRoomStatus() + "', "
                                    + "'" + objCNFR.getFullAddress() + "', '" + objCNFR.getRoomType() + "', " + objCNFR.getRoomCapacity() + ",1 ," + objCNFR.getNoOfParticipants() + ",'" + objCNFR.getContactDetails() + "','" + objCNFR.getAmenitiesAvailable() + "','" + objCNFR.getMeetingDescription() + "','" + objCNFR.getRemarks() + "','" + objCNFR.getEmployeeNumber() + "','" + objCNFR.getEmpUserID() + "','" + objCNFR.getEmployeeName() + "','" + objCNFR.getEmailID() + "','" + objCNFR.getContactNumber() + "','" + objCNFR.getEmpDepartment() + "',getDate(),'" + objCNFR.getExtNumber() + "','" + objCNFR.getDateofrequest() + "','Booked','" + objCNFR.getRegion() + "','" + objCNFR.getWorkLocation() + "','" + objCNFR.getCostCenter() + "','" + objCNFR.getState() + "')";
                            loggerCnsl.info("sQuery1 --> " + sQuery1);
                            strCNFDBSts = cmnMethod.executeUpdateQry(sQuery1, Sessionid);

                            /*
                        //Guest House Booking
                        String sQuery2 = "INSERT INTO dbo.EXT_GUESTHOUSE_OCCUPANCY_DETAILS_ACTIVE (GuestHouseLocation, FromDate, CheckInTime, ToDate, CheckOutTime, RoomType, RoomName, RoomNumber, RoomStatus, NoOfNights, NoOfPersons, FullAddress, ReservationsBy, ContactDetails, CareTakerDetails, RegionalAdmin, EmployeeCode, EmpUserID, EmployeeName, EmpEmailID, EmpContactNumber, DateOfTravel, FromLocation, ToLocation, Comments, LastModifiedOn, PID, BookingFor)\n"
                                + "VALUES ('" + strguestLocation + "','" + strfromdate1 + "', '" + strcb_checkin_hh + ":" + strcb_checkin_mm + "','" + strtodate1 + "', '" + strcb_checkout_hh + ":" + strcb_checkout_mm + "', '" + strbookingRoomType + "', '" + strbookingRoomName + "', '" + strbookingRoomNumber + "',  '" + strRomSts + "',  '" + noofnights + "', '" + strnoofpersons + "','','','','','','" + strreqEmployeeNumber + "', '" + strEmpUserID + "',  '" + strEmployeeName + "', '" + strreqEmailID + "','" + strtContactNumber + "','','','','" + strcomments + "',getDate(),'" + result + "','" + strbookingBookingFor + "')";
                        loggerCnsl.info("sQuery2 --> " + sQuery2);
                        cmnMethod.executeUpdateQry(sQuery2, Sessionid);
                        //Insert Comments
                        String sQuery3 = "INSERT INTO dbo.EXT_GuestHouseBooking_CommentsHistory (Username, Proc_instid, Comments, EntryDateTime, workstepName, ACTION, Stage, CommentsType)\n"
                                + "VALUES ('" + strEmpUserID + "','" + result + "', '" + strcomments + "',getDate(),'GHB_Registration', 'Register','Registered','External')";
                        loggerCnsl.info("sQuery3 --> " + sQuery3);
                        cmnMethod.executeUpdateQry(sQuery3, Sessionid);
                             */
                            //Need to implement the mail trigger to admin team for booking GuestHouse Rooms
                            String StrMailBody = "<HTML><head><style>td{padding: 6px 6px;width: 180px;border: 1px solid #ccc;}th{padding: 6px 6px;width: 180px;border: 1px solid #ccc;background:blue;color:white;}</style></head><BODY>Dear Sir/Madam <b></b>,<BR><BR>Greetings of the day!!<BR><BR>Your Conference Room has been booked successfully as per the deatils mentioned below.<br><br><h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Requestor Details</h4>"
                                    + "<TABLE> <TR><TH>Employee Code</TH> <TH>Employee Name</TH><TH>Department</TH><TH>Email ID</TH><TH>Contact Number</TH><TH>Ext Number</TH><TH>Booking For</TH></TR>"
                                    + "<TR><TD><B>" + strreqEmployeeNumber + "</B></TD><TD>" + strEmployeeName + "</TD> <TD>" + objCNFR.getEmpDepartment() + "</TD> <TD>" + strreqEmailID + "</TD><TD>" + strtContactNumber + "</TD><TD>" + objCNFR.getExtNumber() + "</TD><TD>" + objCNFR.getBookedFor() + "</TD></TR>"
                                    + "</TABLE>";
                            StrMailBody += "<h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Booking Details</h4><TABLE> <TR><TH>Booking Date</TH><TH>Room Location</TH> <TH>Room Name</TH><TH>Room Address</TH><TH>From Time</TH><TH>To Date</TH><TH>No Of Participants</TH><TH>Room Status</TH></TR><TR><TD>" + strfromdate1 + "</TD><TD>" + objCNFR.getRoomLocation() + "</TD> <TD>" + objCNFR.getRoomName() + "</TD><TD><b>" + objCNFR.getFullAddress() + "</b></TD><TD>" + objCNFR.getFromTime() + ":00</TD><TD>" + objCNFR.getToTime() + ":00</TD><TD>" + objCNFR.getNoOfParticipants() + "</TD><TD>" + strRomSts + "</TD></TR><TR><TD style=\"background: blue;color: #fff;\">Other Amenities</TD><TD colspan=\"7\">"+ objCNFR.getAmenitiesAvailable() +"</TD></TR><TR><TD style=\"background: blue;color: #fff;\">Meeting Description</TD><TD colspan=\"7\">"+ objCNFR.getMeetingDescription()+"</TD></TR><TR><TD style=\"background: blue;color: #fff;\">Remarks</TD><TD colspan=\"7\">"+ objCNFR.getRemarks()+"</TD></TR></TABLE>";
                            StrMailBody += "<br>Please forward this mail to all Participants.<br><P>Please contact respective Regional Admin Helpdesk Person for Other Amenities / arrangements in this meeting room if required.</P><br><b>Regards,<br>ADMIN Team</b><br><BR><FONT style=\"COLOR: red\">Note:- This is a system generated E-mail, please do not reply to this E-mail.</FONT><BR></BODY></HTML>";
                            String strQuery = "INSERT INTO WFMAILQUEUETABLE ( mailFrom,mailTo, mailCC, mailSubject, mailMessage, mailContentType, mailPriority, mailStatus,insertedBy, mailActionType, insertedTime,processDefId,processInstanceId, workitemId, activityId,noOfTrials )VALUES('noreply-conferenceroom@britindia.com','" + strreqEmailID + ";','"+strAdminMailID+";" + strCcMailID + "','Your Conference Room " + objCNFR.getRoomName() + " has been booked successfully.','" + StrMailBody + "','text/html;charset=UTF-8',1,'N', 'ConferenceRoomBooking', 'N',getdate(), 12,'" + result + "',1,9,0)";
                            loggerCnsl.info("sQuery --> " + strQuery);
                            strMailSts = cmnMethod.executeMailUpdateQry(strQuery, Sessionid);
                        } else {
                            duplicateCheck = "True";
                        }
                    }
                    try {
                        loggerCnsl.info("Data Updated Successfully");
                        if(duplicateCheck.equalsIgnoreCase("True")){
                            out.println("You have already booked the selected room. <br> Kindly close the window!");
                        } else if ((strCNFDBSts == true && strMailSts == true)) {
                            out.println("Conference Room <b>" + objCNFR.getRoomName() + "</b> has been booked successfully.<br><br> For date <b> " + strfromdate1 + " from " + objCNFR.getFromTime() + "  to " + objCNFR.getToTime() + " </b>.");
                        } else {
                            out.println("Invalid Session, Please try to login and do booking again..!");
                        }
//                            CommonMethod.disconCabinet(probBean, Sessionid);//for Logged in user not required
                        request.setAttribute("EmployeeCode", strreqEmployeeNumber);
                    } catch (Exception e) {
                        loggerCnsl.info("Exception occurred in Hibernate while updating the data " + e);
                    }
                } catch (Exception e) {
                    loggerErr.info("Exception :: " + e.getMessage());
                    request.setAttribute("EmployeeCode", "");
                } finally {
                    CommonMethod.disconCabinet(probBean, Sessionid);
                }
            } else {
                request.setAttribute("EmployeeCode", "");
                System.out.println("Please contact HR team to create/update employee details in SAP master");
            }
        } catch (Exception e) {
            loggerErr.info("Exception ===> " + e.getMessage());
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        loggerCnsl.info("*********^^^^^^^  Inside doGet method ^^^^^^^^^^^^*********");
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
