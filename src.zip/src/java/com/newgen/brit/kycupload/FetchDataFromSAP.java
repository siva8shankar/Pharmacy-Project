/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload;

import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.cabinet.IFormCabinetList;
import com.newgen.omniforms.xmlviewerapi.IFormCallBroker;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */



public class FetchDataFromSAP {
    
    
     public static String SAPHostName = "";
    public static String SAPInstance = "";
    public static String SAPClient = "";
    public static String SAPUserName = "";
    public static String SAPPassword = "";
    public static String SAPLanguage = "";
    static NGEjbClient ejbObj = null;
    
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

                /**--------------------------------------------------------------------//
    Function Name     :getconnectionstring
    Input Parameters  :
    Output parameters :connectionstring
    Return Values     :String
    Description       :This function used create SAP connection
    Global variables  :
    Author            :Harinatha R
    Date              :13-Dec-2016
    -------------------------------------------------------------------
     * @return 
     * @throws java.io.FileNotFoundException-*/
    public static String getconnectionstring() throws FileNotFoundException, IOException {
       loggerCnsl.info("In getconnectionstring SAP");
        String strIniFilepath = System.getProperty("user.dir") + "\\SAP_Details\\SAPConnections.ini";
        //CommonObj.writeToLog(2,"strIniFilepath: " + strIniFilepath, winame);
        File fileinipath = new File(strIniFilepath);
        String InstanceName = "";
        FileInputStream fistream = new FileInputStream(fileinipath);
        Properties prop = new Properties();
        prop.load(fistream);
        SAPHostName = prop.getProperty(InstanceName + "SAPHostName").trim();
        SAPInstance = prop.getProperty(InstanceName + "SAPInstance").trim();
        SAPClient = prop.getProperty(InstanceName + "SAPClient").trim();
        SAPUserName = prop.getProperty(InstanceName + "SAPUserName").trim();
        SAPPassword = prop.getProperty(InstanceName + "SAPPassword").trim();
        SAPLanguage = prop.getProperty(InstanceName + "SAPLanguage").trim();
        
//        SAPHostName = "172.16.8.164 ".trim();
//        SAPInstance = "00".trim();
//        SAPClient = "300".trim();
//        SAPUserName = "NEWGENAP".trim();
//        SAPPassword = "ibps@2019".trim();
//        SAPLanguage = "EN".trim();
        
        StringBuilder connectionstring = new StringBuilder();
        connectionstring.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        connectionstring.append("<WFSAPInvokeFunction_Input>");
        connectionstring.append("<Option>WFSAPInvokeFunction</Option>");
        //SAP Connection String
        connectionstring.append("<SAPConnect>");
        connectionstring.append("<SAPHostName>").append(SAPHostName).append("</SAPHostName>");
        connectionstring.append("<SAPInstance>").append(SAPInstance).append("</SAPInstance>");
        connectionstring.append("<SAPClient>").append(SAPClient).append("</SAPClient>");
        connectionstring.append("<SAPUserName>").append(SAPUserName).append("</SAPUserName>");
        connectionstring.append("<SAPPassword>").append(SAPPassword).append("</SAPPassword>");
        connectionstring.append("<SAPLanguage>").append(SAPLanguage).append("</SAPLanguage>");
        connectionstring.append("</SAPConnect>");
        return connectionstring.toString();
    }

                    /**--------------------------------------------------------------------//
    Function Name     :callServer
    Input Parameters  :xml
    Output parameters :
    Return Values     :String
    Description       :This function used call the BAPI
    Global variables  :
    Author            :Harinatha R
    Date              :13-Dec-2016
    -------------------------------------------------------------------
     * @param xml-
     * @return 
     * @throws java.lang.Exception*/
    public String callServer(String xml) throws Exception {
        ejbObj = NGEjbClient.getSharedInstance();
       loggerXml.info("xml :: "+xml);
//        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
//        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        //String winame = formConfig.getConfigElement("ProcessInstanceId");
        
        String output = "";
        xml=xml.replaceAll("&", "&amp;");
       loggerXml.info("Input XML :==== " + xml);
//        CommonObj.writeToLog(1, "BAPI Call Execution Start============================================================================================:", winame);
//        CommonObj.writeToLog(1, "BAPI Input:" + xml, winame);
//        CommonObj.writeToLog(1,"Input XML Engine Name:==== " + formObject.getWFEngineName(),winame);
//        CommonObj.writeToLog(1,"Input XML Port:==== " + Integer.parseInt(IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName()).getM_strServerPort()),winame);
        //IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName());
       // output = IFormCallBroker.execute(xml, IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName()).getM_strServerIP(), Integer.parseInt(IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName()).getM_strServerPort()));
       
//       ejbObj.initialize( "172.16.8.81", "3333", "JBossEAP");//for UAT
//       ejbObj.initialize( "172.16.8.97", "3333", "JBossEAP");//for PRODUCTION
       ejbObj.initialize( "127.0.0.1", "3333", "JBossEAP");//for PRODUCTION
       output = ejbObj.makeCall(xml);
       
//       output = IFormCallBroker.execute(xml, "172.16.8.81", Integer.parseInt("3333"));
       loggerXml.info("output1::: "+output);
//        CommonObj.writeToLog(1, "BAPI Output:" + output, winame);
//        CommonObj.writeToLog(1, "BAPI Call Execution End==============================================================================================:", winame);
        String mainCode = new WFXmlResponse(output).getVal("MainCode");
        if (mainCode == null || mainCode.length() == 0) {
            mainCode = new WFXmlResponse(output).getVal("Status");
        }
        if (mainCode == null || !((mainCode.equalsIgnoreCase("0")) || (mainCode.equalsIgnoreCase("18")))) {
            /* throw new Exception("\n Error in request\nOutput XML : \n"
             + output + "\n\n");*/
        }
        output = output.replaceAll("&amp;", "&");
        output = output.replaceAll("'", "`");
       loggerXml.info("Output XML  AFTER SPL CHAR CHECK:::: " + output);
        
        return output;

    }
    
    /**
     * @param strUserId
     * @throws java.io.IOException
     */      
    
    public void getEmpKYCDetails(String strUserId) throws IOException, Exception{
                
        StringBuilder rfcInput = new StringBuilder();
        String BAPIOutput = "";        
        //JSONObject objJSN = new JSONObject();
        
        rfcInput.append(getconnectionstring());
        rfcInput.append("<SAPFunctionName>ZHR_RFC_PAN_AADHAR</SAPFunctionName>");
        rfcInput.append("<Parameters><ImportParameters>");
        rfcInput.append("<USR_ID>01008620</USR_ID>");
//        rfcInput.append("<USR_ID>").append(strUserId.trim()).append("</USR_ID>");
        rfcInput.append("</ImportParameters>");
        rfcInput.append("</Parameters>");
        rfcInput.append("</WFSAPInvokeFunction_Input>");
        
       loggerXml.info("rfcInput BAPI Input ---> "+rfcInput);
        BAPIOutput = callServer(rfcInput.toString());
       loggerXml.info("BAPIOutput BAPI output ---> "+BAPIOutput);
        //writeToLog("BAPIOutput :: "+BAPIOutput,);
        WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
        if (XmlResponse.getVal("MainCode").equals("0")) {

            WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "GS_EMP_DETAILS");
            String strEmployeeCode = XMLListMessage.getVal("PERNR").trim();
            String strPANNum = XMLListMessage.getVal("EMP_PAN").trim();
            String strAadharNum = XMLListMessage.getVal("EMP_AADHAR").trim(); 
            
//            objJSN.put("EmpCode", strEmployeeCode);
//            objJSN.put("PanNum", strPANNum);
//            objJSN.put("AdharNum", strAadharNum);            
//            
        }     


//      objJSN.put("PanAckNum", new Boolean(true));
//      objJSN.put("DrivingLics", new Boolean(true));
//      objJSN.put("VoterId", new Boolean(true));
    }
    
}
