/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload;

import com.newgen.brit.kycupload.beans.KYCMaster;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author ngappadmin
 */
public class KYCUploadDAO {

    Session session = null;
    SessionFactory sessionFactory = null;
    Transaction transaction = null;
    PrintWriter out = null;
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    public boolean connectHibernate() {
        try {
             loggerCnsl.info("Initilialized logs....");
            Configuration cfg = new Configuration().configure("com/newgen/brit/kycupload/resources/hibernate.cfg.xml");            
            sessionFactory = cfg.buildSessionFactory();
            session = sessionFactory.openSession();
        } catch (Exception e) {
           loggerErr.info("Exception " + e.getMessage());
        }
        return session.isOpen();
    }

    public ArrayList<KYCMaster> fetchUserKYCDetailsByEmpCode(String EmpCode) {
        ArrayList<KYCMaster> empdetails=new ArrayList<KYCMaster>();
        if (connectHibernate()) {    
            try{
            String query = "SELECT AadharNumber, AadharAckNumber, PANNumber, PANAckNumber, DrivingLicense,VoterId FROM KYCMaster WHERE EmployeeCode ='" + EmpCode + "'";
           loggerCnsl.info("query ==> " + query);
           loggerCnsl.info("session.isOpen() ==> "+session.isOpen());
            Query strQuery = session.createQuery(query);
            List<Object> list = strQuery.list();
           loggerCnsl.info("Records are ");
           loggerCnsl.info("=============================");
            for (Object o : list) {
                Object st[] = (Object[]) o;
               loggerCnsl.info(st[0] + "  " + st[1] + "  " + st[2] + "   " + st[3] + "   " + st[4]);
                String strEmployeeCode = EmpCode;
                String strAadharNumber = (String) st[0];
                String strAadharAckNum = (String) st[1];
                String strPanNumber = (String) st[2];
                String strPanAckNum = (String) st[3];
                String strDrivingLicenceNumber = (String) st[4];
                String strVoterNumber = (String) st[5];
                KYCMaster objKYC = new KYCMaster();
                objKYC.setEmployeeCode(strEmployeeCode);
                objKYC.setAadharNumber(strAadharNumber);
                objKYC.setAadharAckNumber(strAadharAckNum);
                objKYC.setPANNumber(strPanNumber);
                objKYC.setPANAckNumber(strPanAckNum);
                objKYC.setDrivingLicense(strDrivingLicenceNumber);
                objKYC.setVoterId(strVoterNumber);
                empdetails.add(objKYC);
//            String record = st.getItemindex() + " | " + st.getComments() + " | " + st.getTransactionid() + " | " + st.getBarcode();
//           loggerCnsl.info(record);
            }
            }catch(Exception e){
               loggerErr.info("Exception in e :: "+e.getMessage());
            }
        }
        return empdetails;
    }

}
