/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload;

import ISPack.ISUtil.JPISException;
import com.itextpdf.text.exceptions.BadPasswordException;
import com.itextpdf.text.pdf.PdfReader;
import com.newgen.brit.kycupload.beans.HelpDeskPortalFields;
import com.newgen.brit.kycupload.beans.KYCMaster;
import com.newgen.brit.util.AddToSMS;
import com.newgen.brit.util.CommonMethod;
import com.newgen.brit.util.PropReader;
import com.newgen.brit.util.PropertyBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import java.io.File;
import java.util.ArrayList;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */
public class HelpDeskAddDocumentServlet extends HttpServlet {

    Session session = null;
    SessionFactory sessionFactory = null;
    Transaction transaction = null;
    PrintWriter out = null;
    private String result = "";
    String filePath = null;
    String fileName = "";
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
        loggerCnsl.info("*********^^^^^^^  Inside processRequest method ^^^^^^^^^^^^*********");
        try {
            loggerCnsl.info("request.getParameter(\"EmployeeNumber\") " + request.getParameter("EmployeeNumber"));
            if (!request.getParameter("EmployeeNumber").equalsIgnoreCase("")) {
                try {
                    Configuration cfg = new Configuration().configure("com/newgen/brit/kycupload/resources/helpdeskhibernate.cfg.xml");
                    sessionFactory = cfg.buildSessionFactory();
                    session = sessionFactory.openSession();
                } catch (Exception e) {
                    loggerErr.info("Exception " + e.getMessage());
                }
                try {
                    transaction = session.beginTransaction();
                    out = response.getWriter();
                    HelpDeskPortalFields objHPF = new HelpDeskPortalFields();
                    String strEmployeeCode = request.getParameter("EmployeeNumber");
                    String strEmployeeName = request.getParameter("EmployeeName");
                    String strEmployeeName1 = request.getParameter("strEmployeeName");
                    loggerCnsl.info("strEmployeeCode after get param " + strEmployeeCode);
                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);
                    String strsessionID = request.getParameter("sessionID");
                    String strscabinetName = request.getParameter("cabinetName");
                    String strCorporateFunction = request.getParameter("CorporateFunction");
                    String strHRFunction = request.getParameter("HRFunction");
                    String strGender = request.getParameter("Gender");
                    String strEmailID = request.getParameter("EmailID");
                    String strWorkLocation = request.getParameter("WorkLocation");
                    String strticketFunction = request.getParameter("ticketFunction");
                    String strticketCategory = request.getParameter("ticketCategory");
                    String strticketSubCategory = request.getParameter("ticketSubCategory");
                    String strticketAssigningUser = request.getParameter("ticketAssigningUser");
                    String strticketSubject = request.getParameter("ticketSubject");
                    String strticketPriority = request.getParameter("ticketPriority");
                    String strContactNumber = request.getParameter("ContactNumber");
                    String strticketMessage = request.getParameter("ticketMessage");
                    String strRegion = request.getParameter("Region");
                    String strvendorCode = request.getParameter("vendorCode");
                    String strvendorGL = request.getParameter("vendorGL");
                    String strDesignation = request.getParameter("Designation");
                    String strDepartment = request.getParameter("Department");
                    String strGrade = request.getParameter("Grade");
                    String strOriginalLoc = request.getParameter("OriginalLoc");
                    String strCategory = request.getParameter("Category");
                    String strticketAssigningUserFullName = request.getParameter("ticketAssigningUserFullName");
                    String strInitiationType = request.getParameter("InitiationType");
                    loggerCnsl.info("strsessionID --> " + strsessionID);
                    loggerCnsl.info("strscabinetName --> " + strscabinetName);
                    loggerCnsl.info("strCorporateFunction --> " + strCorporateFunction);
                    loggerCnsl.info("strHRFunction --> " + strHRFunction);
                    loggerCnsl.info("strInitiationType --> " + strInitiationType);
                    loggerCnsl.info("strCategory --> " + strCategory);
                    loggerCnsl.info("ticketAssigningUserFullName --> " + strticketAssigningUserFullName);
                    objHPF.setEmployeeNumber(strEmployeeCode);
                    objHPF.setEmployeeName(strEmployeeName);
                    objHPF.setCorporateFunction(strCorporateFunction);
                    objHPF.setHRFunction(strHRFunction);
                    objHPF.setGender(strGender);
                    objHPF.setEmailID(strEmailID);
                    objHPF.setWorkLocation(strWorkLocation);
                    objHPF.setTicketFunction(strticketFunction);
                    objHPF.setTicketCategory(strticketCategory);
                    objHPF.setTicketSubCategory(strticketSubCategory);
                    objHPF.setTicketAssigningUser(strticketAssigningUser);
                    objHPF.setTicketSubject(strticketSubject);
                    objHPF.setTicketPriority(strticketPriority);
                    objHPF.setTicketContactNumber(strContactNumber);
                    objHPF.setTicketMessage(strticketMessage);
                    objHPF.setRegion(strRegion);
                    objHPF.setVendorCode(strvendorCode);
                    objHPF.setVendorGL(strvendorGL);
                    objHPF.setDesignation(strDesignation);
                    objHPF.setDepartment(strDepartment);
                    objHPF.setGrade(strGrade);
                    objHPF.setOriginalLocation(strOriginalLoc);
                    objHPF.setCategory(strCategory);
                    objHPF.setTicketAssigningUserFullName(strticketAssigningUserFullName);
                    objHPF.setInitBy(strEmployeeName1);
                    //Add document starts here
                    String Sessionid = "";
                    PropertyBean probBean = null;
                    ArrayList<String> AddtoSMS_Response_sd = null;
                    AddtoSMS_Response_sd = new ArrayList<String>();
                    loggerCnsl.info("************getting sessionID using static user Execution Starts ***************");
                    PropReader propReader = new PropReader();
                    probBean = new PropertyBean();
                    probBean = propReader.readPropertyFile();
                    PropertyBean probBeanConnectRes = CommonMethod.connect(probBean);
                    String sessionID = probBeanConnectRes.getUserDBId();
                    loggerCnsl.info("sessionID :: " + sessionID);
                    loggerCnsl.info("************getting sessionID using static user Execution Ends ***************");
//                    Sessionid = strsessionID;//logged in user
                    Sessionid = sessionID;//HelpDesk_Initiator user
                    String a = "";
                    String strCabinetName = probBean.getCabinetName();
                    String strUserName = probBean.getUserName();
                    String strPassword = probBean.getPassword();
                    String strServerIP = probBean.getServerIP();
                    String strjtsPort = probBean.getJtsPort();
                    String strVolumeIndex = probBean.getVolumeIndex();
                    
                    String strWorkitemEndPointurl = probBean.getWorkitemEndPointurl();
                    String strInitiateFromActivityId = probBean.getInitiateFromActivityId();
                    String strInitiateFromActivityName = probBean.getInitiateFromActivityName();
                    String strProcessDefId = probBean.getProcessDefId();
                    String strProcessName = probBean.getProcessName();
                    String strCabinet = probBean.getCabinet();
//                    Sessionid = "1791058955";

                    if (Sessionid == "" || Sessionid == "error"
                            || Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
                        loggerCnsl.info("Error in getting OD session id!!");
                        loggerCnsl.info("Error in getting OD session id!!");
                        out.println("Error in getting OD session id!!");
                        response.setStatus(500);
                        result = "500";
                        return;
                    }
                    loggerCnsl.info("sessionID ===> " + Sessionid);
                    if(strInitiationType.equalsIgnoreCase("withDoc")){
                    String serverPath = System.getProperty("user.dir");
                    String folderpath = "", Docname = "", strDocType = "", strDocData = "";
                    loggerCnsl.info("Working Directory = " + System.getProperty("user.dir"));

                    boolean isMultipart = ServletFileUpload.isMultipartContent(request);
                    loggerCnsl.info("isMultipartContent::" + isMultipart);
                    isMultipart = true;
                    if (!isMultipart) {
                        response.setStatus(501);
                        out.println("is not Multipart Content!!");
                        return;
                    }
                    List items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

                    loggerCnsl.info("items Size :::: " + items.size());
                    if (items.size() == 0) {
                        response.setStatus(502);
                        out.println("items size is 0!!");
                        result = "502";
                        out.print("Requested operation timeout. Please try after sometimes");
                        return;

                    }
//                    boolean isPasswordProtectedDocExist = false;
//                    int j = 0;
//
//                    for (int i = 0; i < items.size(); i++) {
//
//                        FileItem item_sd = (FileItem) items.get(i);
////                        if (i == 2 || i == 3) {
//                        if (item_sd.isFormField()) {
//                            loggerCnsl.info("inside is form field..!");
//                            // do nothing
//                        } else {
//                            loggerCnsl.info("inside else is form field..!");
//                            long cdt = System.currentTimeMillis();
//                            folderpath = serverPath + File.separator + "Documents";
//                            loggerCnsl.info("folderpath " + folderpath);
//                            File file = new File(folderpath);
//                            if (!file.isDirectory()) {
//                                file.mkdir();
//                            }
//                            String itemName = item_sd.getName();
//                            itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());
//                            fileName = itemName;
//
//                            filePath = folderpath + File.separator + cdt + "_" + itemName;
//                            loggerCnsl.info("filePath ----> " + filePath);
//                            File savedFile = new File(filePath);
//                            item_sd.write(savedFile);                            
//                        }
//                        loggerCnsl.info("filePath ----> " + filePath);
//                        try {
//                            loggerCnsl.info("filepath ---> " + filePath);
//                            PdfReader reader = new PdfReader(filePath);
//                        } catch (BadPasswordException e) {
//                            isPasswordProtectedDocExist = true;
//                            loggerCnsl.info("PDF is password protected");
//                        } catch (Exception e) {
//                            loggerCnsl.info("Exception in Reading File");
//                        }
//
////                        }
//                    }
//                    if (!isPasswordProtectedDocExist) {
                        for (int i = 0; i < items.size(); i++) {

                            FileItem item_sd = (FileItem) items.get(i);
                            loggerCnsl.info("no----->" + i);
//                        if (i == 2 || i == 3) {
                            if (item_sd.isFormField()) {
                                loggerCnsl.info("inside is form field..!");
                                // do nothing
                            } else {
                                loggerCnsl.info("inside else is form field..!");
                                long cdt = System.currentTimeMillis();
                                folderpath = serverPath + File.separator + "Documents";
                                loggerCnsl.info("folderpath " + folderpath);
                                File file = new File(folderpath);
                                if (!file.isDirectory()) {
                                    file.mkdir();
                                }
                                String itemName = item_sd.getName();
                                itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());
                                fileName = itemName;

                                filePath = folderpath + File.separator + cdt + "_" + itemName;
                                File savedFile = new File(filePath);
                                item_sd.write(savedFile);

                            }

                            if (i == 0) {
                                Docname = strEmployeeCode + "_" + strEmployeeCode;
                                strDocType = "HelpDesk_Attachment";
                                strDocData = strEmployeeCode;
                            } 

                            loggerCnsl.info("Docname ----> " + Docname);
                            loggerCnsl.info("filePath ----> " + filePath);
//                            boolean flag = false;
//                            try {
//                                loggerCnsl.info("filepath ---> " + filePath);
//                                PdfReader reader = new PdfReader(filePath);
//                            } catch (BadPasswordException e) {
//                                flag = true;
//                                isPasswordProtectedDocExist = true;
//                                loggerCnsl.info("PDF is password protected");
//                            } catch (Exception e) {
//                                loggerCnsl.info("Exception in Reading File");
//                            }
//
//                            if (flag) {
//                                try {
//                                    loggerCnsl.info("PDF is password protected");
//                                } catch (Exception e) {
//                                    loggerCnsl.info("Exception occurred in pswdprotectd() " + e);
//                                }
//                            } else {
//                                loggerCnsl.info("File is not password protected");
                                a = AddToSMS.AddtoSms(Docname, filePath, Sessionid, strServerIP, strCabinetName,
                                        strjtsPort, strVolumeIndex);
                                loggerCnsl.info("+AddtoSMS_Response_sd--->" + a);
                                AddtoSMS_Response_sd.add(a);
                                String strDocIndex = null;
                                if (AddtoSMS_Response_sd != null && AddtoSMS_Response_sd.size() != 0) {
                                   CommonMethod cmnMethod = new CommonMethod(); 
                                  String  result = cmnMethod.initiateworkitemwithDocument(objHPF, strWorkitemEndPointurl, Sessionid,
						AddtoSMS_Response_sd, strCabinet, strInitiateFromActivityId, strInitiateFromActivityName,
						strProcessDefId, strProcessName, Docname);
				loggerCnsl.info("CaseNumber --> " + result);
                                    if (!result.equalsIgnoreCase("Pending")) {
                                        objHPF.setPID(result);
                                    }    else{
                                     objHPF.setPID("Pending");
                                 }                                       
//                                    CommonMethod cmnMethod = new CommonMethod();
//                                    loggerCnsl.info("strEmployeeCode before addfolder ==> " + strEmployeeCode);
//                                    loggerCnsl.info("Sessionid before addfolder ==> " + Sessionid);
//                                    String folderIndex = cmnMethod.addFolder(strEmployeeCode, Sessionid);
//                                    File tifFile = new File(filePath);
//                                    String tifFileName = tifFile.getName();
//                                    String fileSize = Long.toString(new File(filePath).length());
//                                    String fileExtn = tifFileName.substring(tifFileName.lastIndexOf(".") + 1, tifFileName.length());
//                                    strDocIndex = cmnMethod.adddocument(filePath, fileSize, 0, a.toString(), fileExtn, "I", folderIndex, Docname, Sessionid);
//                                    loggerCnsl.info(" :: Document uploaded succesfully in OD :: strDocIndex is ==> " + strDocIndex);
//                                    cmnMethod.addDocProperties(strDocIndex, Sessionid, strEmployeeCode, strDocType, strDocData);
//                           loggerCnsl.info(" :: Document uploaded succesfully in OD :: strDocIndex is ==> " + strDocIndex);                           
                                } else {
                                    loggerCnsl.info(" :: Document uploaded failed in OD :: ");
                                }
//                            }

//                        }
                        }
                        }else{
                            CommonMethod cmnMethod = new CommonMethod(); 
                                  String  result = cmnMethod.initiateworkitem(objHPF, strWorkitemEndPointurl, Sessionid, strCabinet, strInitiateFromActivityId, strInitiateFromActivityName,
						strProcessDefId, strProcessName);
				loggerCnsl.info("CaseNumber --> " + result);
                                 if (!result.equalsIgnoreCase("Pending")) {
                                        objHPF.setPID(result);
                                    }   else{
                                     objHPF.setPID("Pending");
                                 }                                      
                        }
//                     CommonMethod.disconCabinet(probBean, Sessionid);
//                    if (!isPasswordProtectedDocExist) {
                        try {
                            session.saveOrUpdate(objHPF);
                            transaction.commit();
                            loggerCnsl.info("Data Updated Successfully");
                            if(objHPF.getPID().equalsIgnoreCase("Pending")){
                                out.println("Invalid Session, Please try to login and register New Ticket again..!");
                            }else{
                            out.println("New ticket <b>"+objHPF.getPID()+"</b> has been registered in Employee Helpdesk System");
                            }
//                            CommonMethod.disconCabinet(probBean, Sessionid);//for Logged in user not required
                            request.setAttribute("EmployeeCode", strEmployeeCode);
                        } catch (Exception e) {
                            loggerCnsl.info("Exception occurred in Hibernate while updating the data " + e);
                        }
//                    } else {
//                        out.println("Password protected document exist, Cannot update the data!");
//                        CommonMethod.disconCabinet(probBean, Sessionid);
//                        session.close();
//                        sessionFactory.close();
//                    }
                    //17-May-2018

//            request.getRequestDispatcher("uploadkyc.jsp").forward(request, response);
                } catch (Exception e) {
                    loggerErr.info("Exception :: " + e.getMessage());
                    request.setAttribute("EmployeeCode", "");
//            request.getRequestDispatcher("uploadkyc.jsp").forward(request, response);
                } catch (JPISException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } finally {
                    session.close();
                    sessionFactory.close();
                }
            } else {
                request.setAttribute("EmployeeCode", "");
                System.out.println("Please contact HR team to create/update employee details in SAP master");
//            request.getRequestDispatcher("uploadkyc.jsp").include(request, response);
            }
        } catch (Exception e) {
            loggerErr.info("Exception ===> " + e.getMessage());
//            request.getRequestDispatcher("uploadkyc.jsp").include(request, response);
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        loggerCnsl.info("*********^^^^^^^  Inside doGet method ^^^^^^^^^^^^*********");
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
