/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.kycupload;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author ngappadmin
 */
public class CustomLogs {
    
    private static final String WriteLOG = "Y";
    private static final String XML_LOG_NAME = "xml.log";
    private static final String SUCCESS_LOG_NAME = "success.log";
    private static final String Error_LOG_NAME = "error.log";
    
     /*
     * Function Name    :writeToLog
     * Description      :This function is used to write XML,Success and Error logs for the specified processinstance id
     * Return Value     :Void
     * Input Parameter  :1)LogType(1-XmlLog,2-SuccessLog,3-ErrorLog)
     *                   2)Log String
     *                   3)ProcessInstanceID
         
     
     */
    public static void writeToLogKYC(int intLogType, String strText, String strEmployeeCode) {
        int logcount = 0;
        String strLogFilePath = "";
        GregorianCalendar cal = new GregorianCalendar();
        File objDirs = null;
        if (WriteLOG.equalsIgnoreCase("y") || intLogType == 3) {
            try {

                //strLogFilePath = "ProcessInstanceIDLogs\\" + File.separator + strProcessInstanceID;
                strLogFilePath = "KYC_Logs\\" + File.separator + strEmployeeCode;
                objDirs = new File(strLogFilePath);
                objDirs.mkdirs();
                switch (intLogType) {
                    case 1:
                        strLogFilePath = strLogFilePath + File.separator + XML_LOG_NAME;
                        break;
                    case 2:
                        strLogFilePath = strLogFilePath + File.separator + SUCCESS_LOG_NAME;
                        break;
                    case 3:
                        strLogFilePath = strLogFilePath + File.separator + Error_LOG_NAME;
                        break;

                }
                File objDirs1 = new File(strLogFilePath);
                while (true) {
                    if (new File(objDirs1.getAbsolutePath() + "_" + logcount).length() > 0) {
                        logcount++;
                        continue;
                    }
                    if (objDirs1.length() > (1024 * 1024 * 10)) {
                        objDirs1.renameTo(new File(objDirs1.getAbsolutePath() + "_" + logcount));
                        break;
                    }
                    break;
                }
                FileOutputStream os = new FileOutputStream(strLogFilePath, true);
                String strNewLine = "\n";
                byte[] bNewLine = strNewLine.getBytes();
                byte[] bText = strText.getBytes();
                String strTime = new SimpleDateFormat("HH:mm:ss").format(cal.getTime());
                String strDate = cal.get(Calendar.DAY_OF_MONTH) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.YEAR);
                byte[] btime = strTime.getBytes();
                byte[] bdate = strDate.getBytes();
                byte[] bspecial = ":".getBytes();
                byte[] bspace = " ".getBytes();
                os.write(bNewLine);
                os.write(bdate);
                os.write(bspace);
                os.write(btime);
                os.write(bspecial);
                os.write(bText);
                os.write(bNewLine);
                os.close();
            } catch (Exception e) {
                System.out.println("exception in writing to log " + e.getMessage());
            } finally {
                if (strLogFilePath != null) {
                    strLogFilePath = null;
                }
                if (cal != null) {
                    cal = null;
                }
                if (objDirs != null) {
                    objDirs = null;
                }
            }
        }
    }
}
