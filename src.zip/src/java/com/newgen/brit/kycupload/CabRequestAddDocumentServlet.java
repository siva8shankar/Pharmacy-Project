/** ******************************************************************
 *    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 *    Group                                     	: SDC-South
 *    Product / Project                  	: Britannia Industries Limited
 *    Module                                  	: customibps
 *    File Name                               	: CabRequestAddDocumentServlet.java
 *    Author                                    	: ksivashankar
 *    Date written                          	: 29/05/2019
 *    (DD/MM/YYYY)
 *    Description                            	: Add document servlet
 *  CHANGE HISTORY
 ***********************************************************************************************
 * Date                                Change By                    Change Description (Bug No. (If Any))
 * (DD/MM/YYYY)
 *********************************************************************************************** */
package com.newgen.brit.kycupload;

import ISPack.ISUtil.JPISException;
import com.itextpdf.text.exceptions.BadPasswordException;
import com.itextpdf.text.pdf.PdfReader;
import com.newgen.brit.kycupload.beans.GHBFields;
import com.newgen.brit.kycupload.beans.GuestHouseDetails;
import com.newgen.brit.kycupload.beans.HelpDeskPortalFields;
import com.newgen.brit.kycupload.beans.KYCMaster;
import com.newgen.brit.kycupload.beans.LRFields;
import com.newgen.brit.util.AddToSMS;
import com.newgen.brit.util.CommonMethod;
import com.newgen.brit.util.PropReader;
import com.newgen.brit.util.PropertyBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */
public class CabRequestAddDocumentServlet extends HttpServlet {

    Session session = null;
    SessionFactory sessionFactory = null;
    Transaction transaction = null;
    PrintWriter out = null;
    private String result = "";
    String filePath = null;
    String fileName = "";
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
        loggerCnsl.info("*********^^^^^^^  Inside processRequest method ^^^^^^^^^^^^*********");
        try {
            loggerCnsl.info("request.getParameter(\"EmployeeNumber\") " + request.getParameter("EmployeeNumber"));
            if (!request.getParameter("EmployeeNumber").equalsIgnoreCase("")) {
                try {
//                    Configuration cfg = new Configuration().configure("com/newgen/brit/kycupload/resources/helpdeskhibernate.cfg.xml");
//                    sessionFactory = cfg.buildSessionFactory();
//                    session = sessionFactory.openSession();
                } catch (Exception e) {
                    loggerErr.info("Exception " + e.getMessage());
                }
                String Sessionid = "";
                PropertyBean probBean = null;
                try {
                    String cabLocation = "";
                    String cabTypeOfCar = "";
                    String cabDateOfPickup = "";
                    String cb_pickup_hh = "";
                    String cb_pickup_mm = "";
                    String cabTypeOfTravel = "";
                    String cabFromAddress = "";
                    String cabToAddress = "";
                    String strRomSts = "";
                    String strbookingRoomName = "";
                    String strbookingRoomNumber = "";
                    String strbookingRoomStatus = "";
                    String bookingBookingForOtherTxt = "NA";
                    out = response.getWriter();
                    GHBFields objHPF = new GHBFields();
                    String strreqEmployeeNumber = request.getParameter("EmployeeNumber");
                    String strEmpUserID = request.getParameter("empUserID");
                    String strEmployeeName = request.getParameter("strEmployeeName");
                    loggerCnsl.info("strEmployeeCode after get param " + strreqEmployeeNumber);
                    loggerCnsl.info("strEmpUserID after get param " + strEmpUserID);
                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);
                    String strsessionID = request.getParameter("sessionID");
                    String strscabinetName = request.getParameter("cabinetName");
                    String strreqEmailID = request.getParameter("EmailID");
                    String strtContactNumber = request.getParameter("ContactNumber");
                    String strguestLocation = request.getParameter("guestLocation");
                    String strHRFunction = request.getParameter("HRFunction");
                    String strRegion = request.getParameter("Region");
                    String strVendorCode = request.getParameter("VendorCode");
                    String strVendorGL = request.getParameter("VendorGL");
                    String strDesignation = request.getParameter("Designation");
                    String strDepartment = request.getParameter("Department");
                    String strGrade = request.getParameter("Grade");
                    String strWorkLocation = request.getParameter("WorkLocation");
                    String strCostCenter = request.getParameter("CostCenter");
                    String strRepManager = request.getParameter("RepManager");
                    String strHRBPName = request.getParameter("HRBPName");
                    String strHRBPUserID = request.getParameter("HRBPUserID");
                    String strRMUserID = request.getParameter("RMUserID");
                    String strbookingBookingFor = request.getParameter("bookingBookingFor");
                    String strbookingComments = request.getParameter("bookingComments");
                    if (!CommonMethod.isNullOrEmpty(strbookingComments)) {
                        strbookingComments = strbookingComments;
                    } else {
                        strbookingComments = "NA";
                    }
                    String strInitiationType = request.getParameter("InitiationType");
                    if (!strbookingBookingFor.equalsIgnoreCase("Self")) {
                        bookingBookingForOtherTxt = request.getParameter("bookingBookingForOtherTxt");
                    }
                    cabLocation = request.getParameter("cabLocation");
                    cabTypeOfCar = request.getParameter("cabTypeOfCar");
                    cabDateOfPickup = request.getParameter("cabDateOfPickup");
                    cb_pickup_hh = request.getParameter("cb_pickup_hh");
                    cb_pickup_mm = request.getParameter("cb_pickup_mm");
                    cabTypeOfTravel = request.getParameter("cabTypeOfTravel");
                    cabFromAddress = request.getParameter("cabFromAddress");
                    cabToAddress = request.getParameter("cabToAddress");
                    String strDOJ = "";
                    loggerCnsl.info("strsessionID --> " + strsessionID);
                    loggerCnsl.info("strscabinetName --> " + strscabinetName);
                    loggerCnsl.info("strHRFunction --> " + strHRFunction);

                    objHPF.setEmployeeCode(strreqEmployeeNumber);
                    objHPF.setEmployeeName(strEmployeeName);
                    objHPF.setStrEmployeeUID(strEmpUserID);
                    objHPF.setEmpEmailID(strreqEmailID);
                    objHPF.setEmpContactNumber(strtContactNumber);
                    objHPF.setRegion(strRegion);
                    objHPF.setGrade(strGrade);
                    objHPF.setVendorCode(strVendorCode);
                    objHPF.setVendorGL(strVendorGL);
                    objHPF.setDepartment(strDepartment);
                    objHPF.setDesignation(strDesignation);

                    objHPF.setEmpWorkLocation(strWorkLocation);
                    objHPF.setCostCenter(strCostCenter);
                    objHPF.setBookingBookingForOtherTxt(bookingBookingForOtherTxt);
                    objHPF.setEmpHRBPUserID(strHRBPUserID);
                    objHPF.setEmpRMUserID(strRMUserID);

                    objHPF.setGuestHouseLocation(cabLocation);
                    objHPF.setRegion(strRegion);
                    //Add document starts here
                    ArrayList<String> AddtoSMS_Response_sd = null;
                    AddtoSMS_Response_sd = new ArrayList<String>();
                    loggerCnsl.info("************getting sessionID using static user Execution Starts ***************");
                    PropReader propReader = new PropReader();
                    probBean = new PropertyBean();
                    probBean = propReader.readPropertyFile("CabReqBooking");
                    PropertyBean probBeanConnectRes = CommonMethod.connect(probBean);
                    String sessionID = probBeanConnectRes.getUserDBId();
                    loggerCnsl.info("sessionID :: " + sessionID);
                    loggerCnsl.info("************getting sessionID using static user Execution Ends ***************");
//                    Sessionid = strsessionID;//logged in user
                    Sessionid = sessionID;//HelpDesk_Initiator user
                    String a = "";
                    String strCabinetName = probBean.getCabinetName();
                    String strUserName = probBean.getUserName();
                    String strPassword = probBean.getPassword();
                    String strServerIP = probBean.getServerIP();
                    String strjtsPort = probBean.getJtsPort();
                    String strVolumeIndex = probBean.getVolumeIndex();

                    String strWorkitemEndPointurl = probBean.getWorkitemEndPointurl();
                    //for PRODUCTION
                    String strInitiateFromActivityId = probBean.getInitiateFromActivityId();
                    String strInitiateFromActivityName = probBean.getInitiateFromActivityName();
                    String strProcessDefId = probBean.getProcessDefId();
                    String strProcessName = probBean.getProcessName();
                    String strCabinet = probBean.getCabinet();

                    if (Sessionid == "" || Sessionid == "error"
                            || Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
                        loggerCnsl.info("Error in getting OD session id!!");
                        loggerCnsl.info("Error in getting OD session id!!");
                        out.println("Error in getting OD session id!!");
                        response.setStatus(500);
                        result = "500";
                        return;
                    }
                    loggerCnsl.info("sessionID ===> " + Sessionid);
                    if (strInitiationType.equalsIgnoreCase("withOutDoc")) {
                        CommonMethod cmnMethod = new CommonMethod();
                        String result = cmnMethod.initiateCabRequestWorkitem(objHPF, strWorkitemEndPointurl, Sessionid, strCabinet, strInitiateFromActivityId, strInitiateFromActivityName,
                                strProcessDefId, strProcessName);
                        loggerCnsl.info("CaseNumber --> " + result);
                        if (!result.equalsIgnoreCase("Pending")) {
                            objHPF.setPID(result);
                            strRomSts = "Booked";
                            //Need to implement the code to get details of the guest house starts here
                            ArrayList<GuestHouseDetails> objGHDetails = new ArrayList<GuestHouseDetails>();
                            GuestHouseDetails ghousedetails = null;
                            String strRegionalAdmin = "";
                            String strREGIONALADMIN_USEREMAIL = "";
                            String strGUESTHOUSE_USEREMAIL = "";
                            String strCABREQ_USEREMAIL = "";
                            objGHDetails = CommonMethod.getCabRequestDetailsMethodForMail(sessionID, probBean, cabLocation);

                            for (int i = 0; i < objGHDetails.size(); i++) {
                                System.out.println("objGHDetails.size()  --> " + objGHDetails.size());
                                System.out.println("i  --> " + i);
                                ghousedetails = (GuestHouseDetails) objGHDetails.get(i);
                                strRegionalAdmin = ghousedetails.getRegionalAdmin();
                                strREGIONALADMIN_USEREMAIL = ghousedetails.getRegionalAdminEmail();
                                strGUESTHOUSE_USEREMAIL = ghousedetails.getGUESTHOUSE_USEREMAIL();
                                strCABREQ_USEREMAIL = ghousedetails.getCABREQ_USEREMAIL();
                            }
                            String sQuery = "INSERT INTO dbo.EXT_CABREQUEST_COMPLEX (PID, Location, FromAddress, ToAddress, TypeOfCar, CostCenter, DateOfPickup, PickUpTime_HH, PickUpTime_MM, PurposeOfTravel, BookingFor, BookingForOthers, BookingComments)\n"
                                    + "VALUES ('" + result + "', '" + cabLocation + "', '" + cabFromAddress + "', '" + cabToAddress + "', '" + cabTypeOfCar + "', '" + strCostCenter + "',  '" + cabDateOfPickup + "',  '" + cb_pickup_hh + "', '" + cb_pickup_mm + "', '" + cabTypeOfTravel + "', '" + strbookingBookingFor + "', '" + bookingBookingForOtherTxt + "', '" + strbookingComments + "')";
                            loggerCnsl.info("sQuery --> " + sQuery);
                            cmnMethod.executeUpdateQry(sQuery, Sessionid);
                            //Insert Comments
                                String sQuery3 = "INSERT INTO dbo.EXT_CabRequest_CommentsHistory (Username, Proc_instid, Comments, EntryDateTime, workstepName, ACTION, Stage, CommentsType)\n"
                                        + "VALUES ('" + strEmpUserID + "','" + result + "', '" + strbookingComments + "',getDate(),'CabRequest_Registration', 'Register','Registered','External')";
                                loggerCnsl.info("sQuery3 --> " + sQuery3);
                                cmnMethod.executeUpdateQry(sQuery3, Sessionid);
                            //Need to implement mail trigger for cab services team as per the 
                            String StrMailBody = "<HTML><head><style>td{padding: 6px 6px;width: 180px;border: 1px solid #ccc;}th{padding: 6px 6px;width: 180px;border: 1px solid #ccc;background:blue;color:white;}</style></head><BODY>Dear Guest <b></b>,<BR><BR>Thank you for the cab booking request.<BR><br><h4 style=\"background:rgb(132, 189, 0);padding:4px;text-align:center;color:#fff;\">Request Details</h4>"
                                    + "<TABLE> <TR><TH>Employee Code</TH> <TH>Employee Name</TH> <TH>Email ID</TH><TH>Contact Number</TH><TH>Designation</TH><TH>Grade</TH><TH>Cost Center</TH><TH>Cab Location</TH>  <TH> Date Of Pickup</TH><TH>Pickup Time</TH><TH>Type Of Car</TH><TH>Type Of Travel</TH><TH>From Location</TH><TH>To Location</TH></TR>"
                                    + "<TR><TD><B>" + strreqEmployeeNumber + "</B></TD><TD>" + strEmployeeName + "</TD> <TD>" + strreqEmailID + "</TD><TD>" + strtContactNumber + "</TD> <TD>" + strDesignation + "</TD> <TD>" + strGrade + "</TD><TD>" + strCostCenter + "</TD><TD>" + cabLocation + "</TD><TD>" + cabDateOfPickup + "</TD><TD>" + cb_pickup_hh + ":" + cb_pickup_mm + "</TD><TD>" + cabTypeOfCar + "</TD><TD>" + cabTypeOfTravel + "</TD><TD>" + cabFromAddress + "</TD><TD>" + cabToAddress + "</TD></TR>"
                                    + "</TABLE>";
                            StrMailBody += "<br><br>The chaufeur and vehicle details will be shared shortly.<br><br><br><b>Regards,<br>Admin Team</b><br><BR><FONT style=\"COLOR: red\">Note:- This is a system generated E-mail,please do not reply to this E-mail.</FONT><BR></BODY></HTML>";
                            String strQuery = "INSERT INTO WFMAILQUEUETABLE ( mailFrom,mailTo, mailCC, mailSubject, mailMessage, mailContentType, mailPriority, mailStatus,insertedBy, mailActionType, insertedTime,processDefId,processInstanceId, workitemId, activityId,noOfTrials )VALUES('" + strreqEmailID + "','" + strCABREQ_USEREMAIL + "','" + strreqEmailID + ";travel@britindia.com','Successfully registered the Cab request details from Britannia Industries Ltd. Please refere " + result + " and Cab details will be shared shortly.','" + StrMailBody + "','text/html;charset=UTF-8',1,'N', 'CabBookingRequest', 'N',getdate(), 12,'" + result + "',1,9,0)";
                            loggerCnsl.info("sQuery --> " + strQuery);
                            cmnMethod.executeMailUpdateQry(strQuery, Sessionid);

                        } else {
                            objHPF.setPID("Pending");
                        }
                    }
                    try {
                        loggerCnsl.info("Data Updated Successfully");
                        if (objHPF.getPID().equalsIgnoreCase("Pending")) {
                            out.println("Invalid Session, Please try to login and register New Ticket again..!");
                        } else {
                            out.println("New ticket <b>" + objHPF.getPID() + "</b> has been registered in Cab Booking Request System");
                        }
                        request.setAttribute("EmployeeCode", strreqEmployeeNumber);
                    } catch (Exception e) {
                        loggerCnsl.info("Exception occurred in Hibernate while updating the data " + e);
                    }
                } catch (Exception e) {
                    loggerErr.info("Exception :: " + e.getMessage());
                    request.setAttribute("EmployeeCode", "");
                } // TODO Auto-generated catch block
                finally {
                    CommonMethod.disconCabinet(probBean, Sessionid);
                }
            } else {
                request.setAttribute("EmployeeCode", "");
                System.out.println("Please contact HR team to create/update employee details in SAP master");
            }
        } catch (Exception e) {
            loggerErr.info("Exception ===> " + e.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        loggerCnsl.info("*********^^^^^^^  Inside doGet method ^^^^^^^^^^^^*********");
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
