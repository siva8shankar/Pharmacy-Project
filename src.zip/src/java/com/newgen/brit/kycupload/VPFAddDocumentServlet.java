/** ******************************************************************
 *    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 *    Group                                     : SDC-South
 *    Product / Project                  	: Britannia Industries Limited
 *    Module                                  	: customibps
 *    File Name                               	: VPFAddDocumentServlet.java
 *    Author                                    : ksivashankar
 *    Date written                          	: 11/10/2019
 *    (DD/MM/YYYY)
 *    Description                            	: Add document servlet
 *  CHANGE HISTORY
 ***********************************************************************************************
 * Date                                Change By                    Change Description (Bug No. (If Any))
 * (DD/MM/YYYY)
 *********************************************************************************************** */
package com.newgen.brit.kycupload;

import com.newgen.brit.kycupload.beans.VPFFieldDetails;
import com.newgen.brit.util.CommonMethod;
import com.newgen.brit.util.PropReader;
import com.newgen.brit.util.PropertyBean;
import com.newgen.brit.util.VPFCommonMethod;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */
public class VPFAddDocumentServlet extends HttpServlet {

    PrintWriter out = null;
    private String result = "";
    String filePath = null;
    String fileName = "";
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
        loggerCnsl.info("*********^^^^^^^  Inside processRequest method ^^^^^^^^^^^^*********");
        try {
            loggerCnsl.info("request.getParameter(\"EmployeeNumber\") " + request.getParameter("EmployeeNumber"));
            if (!request.getParameter("EmployeeNumber").equalsIgnoreCase("")) {
                try {
                } catch (Exception e) {
                    loggerErr.info("Exception " + e.getMessage());
                }
                String Sessionid = "";
                PropertyBean probBean = null;
                boolean strCNFDBSts = false;
                boolean strMailSts = false;
                String duplicateCheck = "";
                try {
                    String strVPFSts = "";
                    String strFortheMonth = "";
                    String strFortheYear = "";
                    String strFYYear = "";
                    out = response.getWriter();
                    VPFFieldDetails objVPF = new VPFFieldDetails();
                    String strreqEmployeeNumber = request.getParameter("EmployeeNumber");
                    String strEmpUserID = request.getParameter("empUserID");
                    String strEmployeeName = request.getParameter("strEmployeeName");
                    loggerCnsl.info("strEmployeeCode after get param " + strreqEmployeeNumber);
                    loggerCnsl.info("strEmpUserID after get param " + strEmpUserID);
                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);
                    String strsessionID = request.getParameter("sessionID");
                    String strscabinetName = request.getParameter("cabinetName");
                    String strreqEmailID = request.getParameter("EmailID");
                    String strtContactNumber = request.getParameter("ContactNumber");
                    String strRegion = request.getParameter("Region");
                    String strVendorCode = request.getParameter("VendorCode");
                    String strVendorGL = request.getParameter("VendorGL");
                    String strDesignation = request.getParameter("Designation");
                    String strDepartment = request.getParameter("Department");
                    String strGrade = request.getParameter("Grade");
                    String strWorkLocation = request.getParameter("WorkLocation");
                    String strCostCenter = request.getParameter("CostCenter");
                    String strState = request.getParameter("State");
                    String strNewVpfContribution = request.getParameter("NewVpfContribution");
                    String strOldVpfContribution = request.getParameter("oldVpfContribution");
                    String strComments = request.getParameter("Comments");
                    String strInitiationType = request.getParameter("InitiationType");

                    loggerCnsl.info("strEmployeeName after get param " + strEmployeeName);

                    if (!CommonMethod.isNullOrEmpty(strComments)) {
                        strComments = strComments;
                    } else {
                        strComments = "NA";
                    }
                    loggerCnsl.info("strsessionID --> " + strsessionID);
                    loggerCnsl.info("strscabinetName --> " + strscabinetName);
                    objVPF.setEmployeeNumber(strreqEmployeeNumber);
                    objVPF.setEmployeeName(strEmployeeName);
                    objVPF.setEmpUserID(strEmpUserID);
                    objVPF.setEmailID(strreqEmailID);
                    objVPF.setContactNumber(strtContactNumber);
                    objVPF.setRegion(strRegion);
                    objVPF.setGrade(strGrade);
                    objVPF.setVendorCode(strVendorCode);
                    objVPF.setVendorGL(strVendorGL);
                    objVPF.setEmpDepartment(strDepartment);
                    objVPF.setDesignation(strDesignation);
                    objVPF.setWorkLocation(strWorkLocation);
                    objVPF.setCostCenter(strCostCenter);
                    objVPF.setState(strState);
                    objVPF.setNewVpfContribution(strNewVpfContribution);
                    objVPF.setComments(strComments);
                    objVPF.setInitiationType(strInitiationType);

                    //Add document starts here
                    loggerCnsl.info("************getting sessionID using static user Execution Starts ***************");
                    PropReader propReader = new PropReader();
                    probBean = new PropertyBean();
                    probBean = propReader.readPropertyFile("VPFRequest");
                    PropertyBean probBeanConnectRes = CommonMethod.connect(probBean);
                    String sessionID = probBeanConnectRes.getUserDBId();
                    loggerCnsl.info("sessionID :: " + sessionID);
                    loggerCnsl.info("************getting sessionID using static user Execution Ends ***************");
//                    Sessionid = strsessionID;//logged in user
                    Sessionid = sessionID;//HelpDesk_Initiator user
                    if (Sessionid == "" || Sessionid == "error"
                            || Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
                        loggerCnsl.info("Error in getting OD session id!!");
                        loggerCnsl.info("Error in getting OD session id!!");
                        out.println("Error in getting OD session id!!");
                        response.setStatus(500);
                        result = "500";
                        return;
                    }
                    loggerCnsl.info("sessionID ===> " + Sessionid);
                    if (strInitiationType.equalsIgnoreCase("withOutDoc")) {
                        CommonMethod cmnMethod = new CommonMethod();
                        strVPFSts = "Booked";

                        //Need to implement the code to get details of the guest house starts here
                        ArrayList<VPFFieldDetails> objVPFDetails = new ArrayList<VPFFieldDetails>();
                        VPFFieldDetails vpfObj = null;
                        String strAdminMailID = "";
                        String strCcMailID = "";
                        objVPFDetails = VPFCommonMethod.getVPFMailDeatilsMethod(sessionID, probBean, objVPF.getRegion());

                        for (int i = 0; i < objVPFDetails.size(); i++) {
                            System.out.println("objGHDetails.size()  --> " + objVPFDetails.size());
                            System.out.println("i  --> " + i);
                            vpfObj = (VPFFieldDetails) objVPFDetails.get(i);
                            strAdminMailID = vpfObj.getAdminMailID();
                            strCcMailID = vpfObj.getCcColumn();
                        }

                        Calendar c = Calendar.getInstance();
                        strFortheMonth = c.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH);
                        strFortheYear = Integer.toString(c.get(Calendar.YEAR));
                        strFYYear = strFortheMonth+"-"+strFortheYear;
                        System.out.println(strFortheMonth);
                        loggerCnsl.info("strFortheMonth == " + strFortheMonth);
                        loggerCnsl.info("strFortheYear == " + strFortheYear);

                        String retVal = VPFCommonMethod.getDuplicateStatusMethod(Sessionid, objVPF.getEmployeeNumber(), strFYYear);
                        if (!(Integer.parseInt(retVal) >= 1)) {
                            duplicateCheck = "False";
                            String sQuery1 = "INSERT INTO dbo.EXT_VPF_CONTRIBUTE_DETAILS (EmployeeCode, EmpUserID, EmployeeName, EmpEmailID, EmpContactNumber, Region, VendorCode, VendorGL, EmpDesignation, EmpDepartment, CostCenter, Grade, WorkLocation, OldVPFContribution, NewVPFContribution, State, StatusFlag, LastModifiedOn) VALUES "
                                    + "('" + objVPF.getEmployeeNumber() + "','" + objVPF.getEmpUserID()+ "', '" + objVPF.getEmployeeName()+ "', '" + objVPF.getEmailID()+ "', '" + objVPF.getContactNumber()+ "',  '" + objVPF.getRegion()+ "', '" + objVPF.getVendorCode()+ "', '" + objVPF.getVendorGL()+ "','" + objVPF.getDesignation()+ "',  '" + objVPF.getEmpDepartment()+ "','" + objVPF.getCostCenter()+ "', '" + objVPF.getGrade()+ "', "
                                    + "'" + objVPF.getWorkLocation()+ "', '" + strOldVpfContribution + "', '" + strNewVpfContribution + "','" + objVPF.getState()+ "','Updated',getDate())";
                            loggerCnsl.info("sQuery1 --> " + sQuery1);
                            strCNFDBSts = cmnMethod.executeUpdateQry(sQuery1, Sessionid);

                            String sQuery2 = "INSERT INTO dbo.EXT_VPF_CMPLX_CONTRIBUTE_DETAILS (EmployeeCode, EmpUserID, EmployeeName, OldVPFContribution, NewVPFContribution, Comments, ForTheMonthOf, LastModifiedOn) VALUES ('" + objVPF.getEmployeeNumber() + "','" + objVPF.getEmpUserID()+ "', '" + objVPF.getEmployeeName()+ "', '" + strOldVpfContribution + "', '" + strNewVpfContribution + "','" + objVPF.getComments()+ "','" + strFYYear + "',getDate())";
                            loggerCnsl.info("sQuery2 --> " + sQuery2);
                            cmnMethod.executeUpdateQry(sQuery2, Sessionid);
                            String StrMailBody = "<HTML><head><style>td{padding: 6px 6px;width: 180px;border: 1px solid #ccc;}th{padding: 6px 6px;width: 180px;border: 1px solid #ccc;background:blue;color:white;}</style></head><BODY>Dear "+strEmployeeName+"<b></b>,<BR><BR>Greetings of the day!!<BR><BR>Your VPF Contribution has been updated successfully. Kindly find the below details.<br>"
                                    + "<br><TABLE> <TR><TH>Employee Code</TH> <TH>Employee Name</TH><TH>Department</TH><TH>Email ID</TH><TH>Contact Number</TH><TH>Existing VPF Contribution</TH><TH>Updated VPF Contribution</TH></TR>"
                                    + "<TR><TD><B>" + strreqEmployeeNumber + "</B></TD><TD>" + strEmployeeName + "</TD> <TD>" + objVPF.getEmpDepartment() + "</TD> <TD>" + strreqEmailID + "</TD><TD>" + strtContactNumber + "</TD><TD>" + strOldVpfContribution + "</TD><TD>" + strNewVpfContribution + ".00</TD></TR>"
                                    + "</TABLE>";
                            StrMailBody += "<br><P>Contribution to VPF is eligible for deduction under section 80C of the Income Tax Act 1961 subject to the maximum limit prescribed.<br><br><b>Regards,<br>EOPAYROLL Team</b><br><BR><FONT style=\"COLOR: red\">Note:- This is a system generated E-mail, please do not reply to this E-mail.</FONT><BR></BODY></HTML>";
                            String strQuery = "INSERT INTO WFMAILQUEUETABLE ( mailFrom,mailTo, mailCC, mailSubject, mailMessage, mailContentType, mailPriority, mailStatus,insertedBy, mailActionType, insertedTime,processDefId,processInstanceId, workitemId, activityId,noOfTrials )VALUES('EOPAYROLL@BRITINDIA.COM','" + strreqEmailID + ";','" + strAdminMailID + ";" + strCcMailID + "','You have successfully updated VPF Contribution effective from : " + strFYYear + "','" + StrMailBody + "','text/html;charset=UTF-8',1,'N', 'VPFRequest', 'N',getdate(), 12,'" + result + "',1,9,0)";
                            loggerCnsl.info("sQuery --> " + strQuery);
                            strMailSts = cmnMethod.executeMailUpdateQry(strQuery, Sessionid);
                        } else {
                            duplicateCheck = "True";
                        }
                    }
                    try {
                        loggerCnsl.info("Data Updated Successfully");
                        if (duplicateCheck.equalsIgnoreCase("True")) {
                            out.println("You have already submitted the VPF for the current month. <br> Kindly close the window!");
                        } else if ((strCNFDBSts == true && strMailSts == true)) {
                            out.println("Your request for VPF Contribution of <b>"+ strNewVpfContribution +"%</b> has been considered effective from <b>" + strFYYear + "</b>.");
                        } else {
                            out.println("Invalid Session, Please try to login and do booking again..!");
                        }
//                            CommonMethod.disconCabinet(probBean, Sessionid);//for Logged in user not required
                        request.setAttribute("EmployeeCode", strreqEmployeeNumber);
                    } catch (Exception e) {
                        loggerCnsl.info("Exception occurred in Hibernate while updating the data " + e);
                    }
                } catch (Exception e) {
                    loggerErr.info("Exception :: " + e.getMessage());
                    request.setAttribute("EmployeeCode", "");
                } finally {
                    CommonMethod.disconCabinet(probBean, Sessionid);
                }
            } else {
                request.setAttribute("EmployeeCode", "");
                System.out.println("Please contact HR team to create/update employee details in SAP master");
            }
        } catch (Exception e) {
            loggerErr.info("Exception ===> " + e.getMessage());
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        loggerCnsl.info("*********^^^^^^^  Inside doGet method ^^^^^^^^^^^^*********");
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
