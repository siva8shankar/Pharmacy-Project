package com.newgen.brit.util;

import com.newgen.brit.kycupload.beans.EmployeeGuestHouseData;
import com.newgen.brit.kycupload.beans.GHBFields;
import com.newgen.brit.kycupload.beans.GuestHouseDetails;
import com.newgen.brit.kycupload.beans.HelpDeskPortalFields;
import com.newgen.brit.kycupload.beans.LRFields;
import com.newgen.brit.kycupload.beans.VPFFieldDetails;
import org.apache.log4j.Logger;

import com.newgen.brit.util.PropertyBean;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.XMLParser;
import com.newgen.webserviceclient.NGWebServiceClient;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 *
 * @author Administrator
 */
public class VPFCommonMethod {

    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");
    static String CabinetName = null;
    static String UserName = null;
    static String Password = null;
    static String ServerIP = null;
    static String jtsPort = null;

    static StringBuffer strBuffer = null;
    NGEjbClient ngEJBClient = null;
    StringBuffer strInputXml = null;
    String sOutputXml = new String();
    String strDocIndex = null;
    String strFID = null;

    public static ArrayList<EmployeeGuestHouseData> getVPFEmpDataMethod(String sessionId, PropertyBean probBean, String strEmployeeName) {
        loggerCnsl.info("Inside getVPFEmpDataMethod  ==");
        String strInputXml;
        EmployeeGuestHouseData objGHouse = new EmployeeGuestHouseData();
        ArrayList<EmployeeGuestHouseData> guestDetails = new ArrayList<EmployeeGuestHouseData>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT Employee_ID AS 'Employee Number',User_ID AS 'EmployeeUserID',Employee_Name AS 'Employee Name',Email_ID AS 'Email ID',Mobile_No AS 'Contact Number',Region AS 'Region',Work_Location AS 'Work Location',RM_USERID AS 'Reporting Manager',USERID AS 'HRBPUSERID',ENAME AS 'HRBP Name',Vendor_Code AS 'Vendor Code',Designation,Emp_Subgroup AS 'Grade',Org_Unit AS 'Department',VEN_GLCODE,Cost_Centre,Personnel_Area as 'State',EEVPF FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WITH(NOLOCK) WHERE User_ID='" + strEmployeeName + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getVPFEmpDataMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getVPFEmpDataMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objGHouse.setEmpNumber(wfxmllist.getVal("Value1").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpUserID(wfxmllist.getVal("Value2").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpName(wfxmllist.getVal("Value3").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpEmailID(wfxmllist.getVal("Value4").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpContactNum(wfxmllist.getVal("Value5").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRegion(wfxmllist.getVal("Value6").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpWorkLoc(wfxmllist.getVal("Value7").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRM(wfxmllist.getVal("Value8").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPUserID(wfxmllist.getVal("Value9").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPName(wfxmllist.getVal("Value10").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorCode(wfxmllist.getVal("Value11").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDesignation(wfxmllist.getVal("Value12").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpGrade(wfxmllist.getVal("Value13").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDepartment(wfxmllist.getVal("Value14").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorGL(wfxmllist.getVal("Value15").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpCostCenter(wfxmllist.getVal("Value16").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpState(wfxmllist.getVal("Value17").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEEVPF(wfxmllist.getVal("Value18").trim().replaceAll("&amp;", "and"));
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }
    private static SimpleDateFormat inSDF = new SimpleDateFormat("mm/dd/yyyy");
    private static SimpleDateFormat outSDF = new SimpleDateFormat("yyyy-dd-mm");

    public static String formatDate(String inDate) {
        String outDate = "";
        if (inDate != null) {
            try {
                java.util.Date date = inSDF.parse(inDate);
                outDate = outSDF.format(date);
            } catch (ParseException ex) {
            }
        }
        return outDate;
    }

    public static String reverseFormatDate(String inDate) {
        String outDate = "";
        if (inDate != null) {
            try {
                java.util.Date date = outSDF.parse(inDate);
                outDate = inSDF.format(date);
            } catch (ParseException ex) {
            }
        }
        return outDate;
    }

    public static ArrayList<VPFFieldDetails> getVPFMailDeatilsMethod(String sessionId, PropertyBean probBean, String strRoomLocation) {
        loggerCnsl.info("Inside getVPFMailDeatilsMethod ==");
        String strInputXml;
        VPFFieldDetails objVPF = new VPFFieldDetails();
        ArrayList<VPFFieldDetails> vpfArrObjDetails = new ArrayList<VPFFieldDetails>();
        String strQuery = "SELECT AdminEmailID,ccColumn FROM EXT_VPF_REGIONALMAIL_MASTER_DETAILS WITH(NOLOCK)";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getVPFMailDeatilsMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getVPFMailDeatilsMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objVPF.setAdminMailID(wfxmllist.getVal("Value1").trim());
                    objVPF.setCcColumn(wfxmllist.getVal("Value2").trim());
                    vpfArrObjDetails.add(objVPF);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return vpfArrObjDetails;
    }

    public static String getDuplicateStatusMethod(String sessionId, String strEmployeeCode, String strForTheMonthOf) {
        loggerCnsl.info("Inside getDuplicateStatusMethod ==");
//        String FromDate1 = CommonMethod.formatDate(FromDate);
//        String ToDate1 = CommonMethod.formatDate(ToDate);
        String strInputXml;
        final String strCabinateName = "britbpm";
        final String strJbossIp = "172.16.8.81";//for UAT
//        final String strJbossIp = "172.16.8.97";//for PRODUCTION
//        final String strJbossIp = "127.0.0.1";//for PRODUCTION
//        String strQuery = "SELECT count(1) FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WITH(nolock) WHERE RoomLocation='" + strRoomLocation + "' AND RoomName='" + strRoomName + "' AND BookingDate='" + strBookingDate + "' AND FromTime='" + strFromTime + "' AND ToTime='" + strToTime + "'";
        String strQuery = "SELECT count(1) FROM EXT_VPF_CMPLX_CONTRIBUTE_DETAILS WITH(NOLOCK) WHERE EmployeeCode='" + strEmployeeCode + "' AND ForTheMonthOf='" + strForTheMonthOf + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strReturnVal = "";

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + strCabinateName + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getDuplicateStatusMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("strJbossIp == " + strJbossIp);
        loggerCnsl.info("strCabinateName == " + strCabinateName);
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), strJbossIp, Integer.parseInt("3333"), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getDuplicateStatusMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
//                RoomType_add.add("--Select--"+ "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    strReturnVal = wfxmllist.getVal("Value1").trim();
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return strReturnVal;
    }
}
