package com.newgen.brit.util;

import com.newgen.brit.kycupload.beans.EmployeeGuestHouseData;
import com.newgen.brit.kycupload.beans.GHBFields;
import com.newgen.brit.kycupload.beans.GuestHouseDetails;
import com.newgen.brit.kycupload.beans.HelpDeskPortalFields;
import com.newgen.brit.kycupload.beans.LRFields;
import org.apache.log4j.Logger;

import com.newgen.brit.util.PropertyBean;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.XMLParser;
import com.newgen.webserviceclient.NGWebServiceClient;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Administrator
 */
public class CommonMethod {

    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");
    static String CabinetName = null;
    static String UserName = null;
    static String Password = null;
    static String ServerIP = null;
    static String jtsPort = null;

    public static PropertyBean connect(PropertyBean propBean) {
        loggerCnsl.info("Inside connect method ....");
        String output = null;
        DMSXmlResponse oResp = null;

        CabinetName = propBean.getCabinetName();
        UserName = propBean.getHelpDeskUserName();
        Password = propBean.getHelpDeskPassword();
        ServerIP = propBean.getServerIP();
        jtsPort = propBean.getJtsPort();

        loggerCnsl.info("UserName-->" + UserName);
        loggerCnsl.info("Password-->" + Password);
        loggerCnsl.info("ServerIP-->" + ServerIP);
        loggerCnsl.info("UserName-->" + UserName);
        loggerCnsl.info("Password-->" + Password);
        loggerCnsl.info("ServerIP-->" + ServerIP);

        StringBuilder inputconnect = new StringBuilder();
        inputconnect.append("<?xml version=\"1.0\"?><NGOConnectCabinet_Input><Option>NGOConnectCabinet</Option>"
                + "<CabinetName>" + CabinetName + "</CabinetName><UserName>" + UserName + "</UserName>"
                + "<UserPassword>" + Password + "</UserPassword>"// OmniDocs_Authentication_Manager_0123456789_!@#$%&*
                + "<CurrentDateTime></CurrentDateTime><UserExist>N</UserExist>"
                + "<MainGroupIndex></MainGroupIndex><UserType>U</UserType><Locale>en-US</Locale>"
                + "<ApplicationName></ApplicationName><ApplicationInfo></ApplicationInfo>" + "<Hook>No</Hook>"
                + "</NGOConnectCabinet_Input>");
        try {
            loggerCnsl.info("NGOConnectCabinet_Input Input XML ===> " + inputconnect.toString());
            loggerXml.debug("NGOConnectCabinet_Input Input XML ===> " + inputconnect.toString());
            output = WFCallBroker.execute(inputconnect.toString(), ServerIP, Integer.parseInt("3333"), 0);
            oResp = new DMSXmlResponse(output);
            loggerCnsl.info("NGOConnectCabinet_Input Output XML ===> " + oResp);
            loggerXml.debug("NGOConnectCabinet_Input Output XML ===> " + oResp);
            if ("0".equalsIgnoreCase(oResp.getVal("Status"))) {
                propBean.setUserDBId(oResp.getVal("UserDBId"));
                propBean.setUserIndex(oResp.getVal("LoginUserIndex"));
            } else {
                propBean.setUserDBId("Invalid Session");
                propBean.setUserIndex("");
            }
        } catch (Exception ex) {
            loggerErr.debug("\n\n### **[Error]** Exception in connect cabinet : " + oResp.getVal("Error"));
            propBean.setUserDBId("Exception");
            propBean.setUserIndex("");
            ex.printStackTrace();
        } finally {
            if (output != null) {
                output = null;
            }
            if (oResp != null) {
                oResp = null;
            }
        }

        return propBean;
    }

    public static PropertyBean connectGHB(PropertyBean propBean) {
        loggerCnsl.info("Inside connect method ....");
        String output = null;
        DMSXmlResponse oResp = null;

        CabinetName = propBean.getCabinetName();
        UserName = propBean.getHelpDeskUserName();
        Password = propBean.getHelpDeskPassword();
        ServerIP = propBean.getServerIP();
        jtsPort = propBean.getJtsPort();

        loggerCnsl.info("UserName-->" + UserName);
        loggerCnsl.info("Password-->" + Password);
        loggerCnsl.info("ServerIP-->" + ServerIP);
        loggerCnsl.info("UserName-->" + UserName);
        loggerCnsl.info("Password-->" + Password);
        loggerCnsl.info("ServerIP-->" + ServerIP);

        StringBuilder inputconnect = new StringBuilder();
        inputconnect.append("<?xml version=\"1.0\"?><NGOConnectCabinet_Input><Option>NGOConnectCabinet</Option>"
                + "<CabinetName>" + CabinetName + "</CabinetName><UserName>" + UserName + "</UserName>"
                + "<UserPassword>" + Password + "</UserPassword>"// OmniDocs_Authentication_Manager_0123456789_!@#$%&*
                + "<CurrentDateTime></CurrentDateTime><UserExist>N</UserExist>"
                + "<MainGroupIndex></MainGroupIndex><UserType>U</UserType><Locale>en-US</Locale>"
                + "<ApplicationName></ApplicationName><ApplicationInfo></ApplicationInfo>" + "<Hook>No</Hook>"
                + "</NGOConnectCabinet_Input>");
        try {
            loggerCnsl.info("NGOConnectCabinet_Input Input XML ===> " + inputconnect.toString());
            loggerXml.debug("NGOConnectCabinet_Input Input XML ===> " + inputconnect.toString());
            output = WFCallBroker.execute(inputconnect.toString(), ServerIP, Integer.parseInt("3333"), 0);
            oResp = new DMSXmlResponse(output);
            loggerCnsl.info("NGOConnectCabinet_Input Output XML ===> " + oResp);
            loggerXml.debug("NGOConnectCabinet_Input Output XML ===> " + oResp);
            if ("0".equalsIgnoreCase(oResp.getVal("Status"))) {
                propBean.setUserDBId(oResp.getVal("UserDBId"));
                propBean.setUserIndex(oResp.getVal("LoginUserIndex"));
            } else {
                propBean.setUserDBId("Invalid Session");
                propBean.setUserIndex("");
            }
        } catch (Exception ex) {
            loggerErr.debug("\n\n### **[Error]** Exception in connect cabinet : " + oResp.getVal("Error"));
            propBean.setUserDBId("Exception");
            propBean.setUserIndex("");
            ex.printStackTrace();
        } finally {
            if (output != null) {
                output = null;
            }
            if (oResp != null) {
                oResp = null;
            }
        }

        return propBean;
    }

    public static void disconCabinet(PropertyBean propBean, String SessionID) {
        loggerCnsl.info("Inside disconCabinet method ....");
        DMSXmlResponse oResp = null;
        String output = null;

        String CabinetName = propBean.getCabinetName();
        String UserName = propBean.getUserName();
        String Password = propBean.getPassword();
        String ServerIP = propBean.getServerIP();

        loggerCnsl.info("CabinetName-->" + CabinetName);
        loggerCnsl.info("SessionID-->" + SessionID);
        try {
            StringBuilder inputconnect = new StringBuilder();
            inputconnect.append("<?xml version='1.0'?>");
            inputconnect.append("<NGODisconnectCabinet_Input>");
            inputconnect.append("<Option>NGODisconnectCabinet</Option>");
            inputconnect.append("<CabinetName>" + CabinetName + "</CabinetName>");
            inputconnect.append("<UserDBId>" + SessionID + "</UserDBId>");
            inputconnect.append("</NGODisconnectCabinet_Input>");
            loggerCnsl.info("NGODisconnectCabinet_Input input XML ==> " + inputconnect.toString());
            loggerXml.debug("NGODisconnectCabinet_Input input XML ==> " + inputconnect.toString());
            output = WFCallBroker.execute(inputconnect.toString(), ServerIP, Integer.parseInt("3333"), 0);
            oResp = new DMSXmlResponse(output);
            loggerCnsl.info("NGODisconnectCabinet_Input Output XML ===> " + oResp);
            loggerXml.debug("NGODisconnectCabinet_Input Output XML ===> " + oResp);
            if ("0".equalsIgnoreCase(oResp.getVal("Status"))) {
                loggerCnsl.info("Cabinet Disconnected Successfully ...");
            } else {
                loggerCnsl.info("Problem in Disconnecting cabinet:" + oResp.getVal("Error"));
            }
        } catch (Exception ex) {
            loggerErr.debug("\n\n### **[Error]** Exception in Disconnecting cabinet : " + oResp.getVal("Error"));
            ex.printStackTrace();
        } finally {
            if (output != null) {
                output = null;
            }
            if (oResp != null) {
                oResp = null;
            }
        }
    }
    static StringBuffer strBuffer = null;
    NGEjbClient ngEJBClient = null;
    StringBuffer strInputXml = null;
    String sOutputXml = new String();
    String strDocIndex = null;
    String strFID = null;

    public String adddocument(String FileName, String FileSize, int pages, String Index, String Extension, String FileType, String folderindex, String sfilename, String Sessionid) throws IOException, Exception {
        loggerCnsl.info("Inside add document");
        try {

            ngEJBClient = NGEjbClient.getSharedInstance();

            strInputXml = new StringBuffer();
            strInputXml.append("<?xml version=1.0?>");
            strInputXml.append("<NGOAddDocument_Input>");
            strInputXml.append("<Option>NGOAddDocument</Option>");
            strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
            strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
            strInputXml.append("<Document>");
            strInputXml.append("<ParentFolderIndex>" + folderindex + "</ParentFolderIndex>");
            strInputXml.append("<DocumentName>" + sfilename + "</DocumentName>");
            strInputXml.append("<DocumentType>N</DocumentType>");
            strInputXml.append("<CreatedByAppName>" + Extension + "</CreatedByAppName>");
            strInputXml.append("<DocumentSize>" + FileSize + "</DocumentSize>");
            strInputXml.append("<ISIndex>" + Index + "</ISIndex>");
            strInputXml.append("<TextISIndex></TextISIndex>");

            //added by ksivashankar for configuring the dataclass
//            strInputXml.append("<DataDefinition>");
//            strInputXml.append("<DataDefIndex>BritKYC</DataDefIndex>");
////            strInputXml.append("<Fields>1234</Fields>");
////            strInputXml.append("<Fields>432</Fields>");
////            strInputXml.append("<Fields>2343</Fields>");
//            strInputXml.append("</DataDefinition>");
            strInputXml.append("</Document>");
            strInputXml.append("</NGOAddDocument_Input>");

            sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt(jtsPort), 0);
            loggerCnsl.info("NGOAddDocument_Input XML ====> " + strInputXml.toString());
            loggerXml.info("NGOAddDocument_Input XML ====> " + strInputXml.toString());

            loggerCnsl.info("NGOAddDocument_Output XML ====> " + sOutputXml.toString());
            loggerXml.info("NGOAddDocument_Output XML ====> " + sOutputXml.toString());

            WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);

            if (xmlResponse.getVal("Status").equals("0")) {
                strDocIndex = xmlResponse.getVal("DocumentIndex");
                loggerCnsl.info("document added!!!!!!!!!!!!!");
            }
        } catch (NGException ex) {
            loggerErr.info("\n\n### **(Error)**###");
            //ad.writeToLog("\nError");
        }
        return strDocIndex;

    }

    public String addDocumentToPassPhoto(String FileName, String FileSize, int pages, String Index, String Extension, String FileType, String folderindex, String sfilename, String Sessionid) throws IOException, Exception {
        loggerCnsl.info("Inside add document");
        try {

            ngEJBClient = NGEjbClient.getSharedInstance();

            strInputXml = new StringBuffer();
            strInputXml.append("<?xml version=1.0?>");
            strInputXml.append("<NGOAddDocument_Input>");
            strInputXml.append("<Option>NGOAddDocument</Option>");
            strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
            strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
            strInputXml.append("<Document>");
            strInputXml.append("<ParentFolderIndex>" + folderindex + "</ParentFolderIndex>");
            strInputXml.append("<NoOfPages>1</NoOfPages>");
            strInputXml.append("<AccessType>I</AccessType>");
            strInputXml.append("<DocumentName>" + sfilename + "</DocumentName>");
            strInputXml.append("<DocumentType>I</DocumentType>");
            strInputXml.append("<CreatedByAppName>" + Extension + "</CreatedByAppName>");
            strInputXml.append("<DocumentSize>" + FileSize + "</DocumentSize>");
            strInputXml.append("<ISIndex>" + Index + "</ISIndex>");
            strInputXml.append("<TextISIndex></TextISIndex>");

            //added by ksivashankar for configuring the dataclass
//            strInputXml.append("<DataDefinition>");
//            strInputXml.append("<DataDefIndex>BritKYC</DataDefIndex>");
////            strInputXml.append("<Fields>1234</Fields>");
////            strInputXml.append("<Fields>432</Fields>");
////            strInputXml.append("<Fields>2343</Fields>");
//            strInputXml.append("</DataDefinition>");
            strInputXml.append("</Document>");
            strInputXml.append("</NGOAddDocument_Input>");

            sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt(jtsPort), 0);
            loggerCnsl.info("NGOAddDocument_Input XML ====> " + strInputXml.toString());
            loggerXml.info("NGOAddDocument_Input XML ====> " + strInputXml.toString());

            loggerCnsl.info("NGOAddDocument_Output XML ====>  " + sOutputXml.toString());
            loggerXml.info("NGOAddDocument_Output XML ====>  " + sOutputXml.toString());

            WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);

            if (xmlResponse.getVal("Status").equals("0")) {
                strDocIndex = xmlResponse.getVal("DocumentIndex");
                loggerCnsl.info("document added!!!!!!!!!!!!!");
            }
        } catch (NGException ex) {
            loggerErr.info("\n\n### **(Error)**###");
            //ad.writeToLog("\nError");
        }
        return strDocIndex;

    }

    public void addDocProperties(String strDocIndex, String Sessionid, String strEmployeeCode, String strDocType, String strDocData) {
        loggerCnsl.info("Inside add addDocProperties");
        try {

            strInputXml = new StringBuffer();
            strInputXml.append("<?xml version=1.0?>");
            strInputXml.append("<NGOChangeDocumentProperty_Input>");
            strInputXml.append("<Option>NGOChangeDocumentProperty</Option>");
            strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
            strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
            strInputXml.append("<GroupIndex>0</GroupIndex>");
            strInputXml.append("<Document>");
            strInputXml.append("<DocumentIndex>" + strDocIndex + "</DocumentIndex>");
            strInputXml.append("<DataDefinition>");
            strInputXml.append("<DataDefName>BritKYC</DataDefName>");
            strInputXml.append("<Fields>");
            strInputXml.append("<Field>");
            strInputXml.append("<IndexId>1037</IndexId>");
            strInputXml.append("<IndexType>S</IndexType>");
            strInputXml.append("<IndexValue>" + strEmployeeCode + "</IndexValue>");
            strInputXml.append("</Field>");
            strInputXml.append("<Field>");
            strInputXml.append("<IndexId>1038</IndexId>");
            strInputXml.append("<IndexType>S</IndexType>");
            strInputXml.append("<IndexValue>" + strDocType + "</IndexValue>");
            strInputXml.append("</Field>");
            strInputXml.append("<Field>");
            strInputXml.append("<IndexId>1039</IndexId>");
            strInputXml.append("<IndexType>S</IndexType>");
            strInputXml.append("<IndexValue>" + strDocData + "</IndexValue>");
            strInputXml.append("</Field>");
            strInputXml.append("</Fields>");
            strInputXml.append("</DataDefinition>");
            strInputXml.append("</Document>");
            strInputXml.append("</NGOChangeDocumentProperty_Input>");
            loggerCnsl.info("NGOChangeDocumentProperty INPUT XML ====>  " + strInputXml.toString());
            loggerXml.info("NGOChangeDocumentProperty INPUT XML ====>  " + strInputXml.toString());
            sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt(jtsPort), 0);
            loggerCnsl.info("NGOChangeDocumentProperty OUTPUT XML ====>  " + sOutputXml.toString());
            loggerXml.info("NGOChangeDocumentProperty OUTPUT XML ====>  " + sOutputXml.toString());
            WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);
            if (xmlResponse.getVal("Status").equals("0")) {
                loggerCnsl.info("document Properties updated !!!!!!!!!!!!!");
            }

        } catch (Exception ex) {
            loggerErr.info("\n\n### **(Error)**###");
        }

    }

    public void addDocPassPhotoProperties(String strDocIndex, String Sessionid, String strEmployeeCode, String strDocType, String strDocData) {
        loggerCnsl.info("Inside add addDocProperties");
        try {

            strInputXml = new StringBuffer();
            strInputXml.append("<?xml version=1.0?>");
            strInputXml.append("<NGOChangeDocumentProperty_Input>");
            strInputXml.append("<Option>NGOChangeDocumentProperty</Option>");
            strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
            strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
            strInputXml.append("<GroupIndex>0</GroupIndex>");
            strInputXml.append("<Document>");
            strInputXml.append("<DocumentIndex>" + strDocIndex + "</DocumentIndex>");
            strInputXml.append("<DataDefinition>");
            strInputXml.append("<DataDefName>BritPassphoto</DataDefName>");
            strInputXml.append("<Fields>");
            strInputXml.append("<Field>");
            strInputXml.append("<IndexId>1048</IndexId>");
            strInputXml.append("<IndexType>S</IndexType>");
            strInputXml.append("<IndexValue>" + strEmployeeCode + "</IndexValue>");
            strInputXml.append("</Field>");
            strInputXml.append("<Field>");
            strInputXml.append("<IndexId>1049</IndexId>");
            strInputXml.append("<IndexType>S</IndexType>");
            strInputXml.append("<IndexValue>" + strDocType + "</IndexValue>");
            strInputXml.append("</Field>");
            strInputXml.append("<Field>");
            strInputXml.append("<IndexId>1050</IndexId>");
            strInputXml.append("<IndexType>S</IndexType>");
            strInputXml.append("<IndexValue>" + strDocData + "</IndexValue>");
            strInputXml.append("</Field>");
            strInputXml.append("</Fields>");
            strInputXml.append("</DataDefinition>");
            strInputXml.append("</Document>");
            strInputXml.append("</NGOChangeDocumentProperty_Input>");
            loggerCnsl.info("NGOChangeDocumentProperty INPUT XML ====>  " + strInputXml.toString());
            loggerXml.info("NGOChangeDocumentProperty INPUT XML ====>  " + strInputXml.toString());
            sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt(jtsPort), 0);
            loggerCnsl.info("NGOChangeDocumentProperty OUTPUT XML ====>  " + sOutputXml.toString());
            loggerXml.info("NGOChangeDocumentProperty OUTPUT XML ====>  " + sOutputXml.toString());
            WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);
            if (xmlResponse.getVal("Status").equals("0")) {
                loggerCnsl.info("document Properties updated !!!!!!!!!!!!!");
            }

        } catch (Exception ex) {
            loggerErr.info("\n\n### **(Error)**###");
        }

    }

    public String addFolder(String strFolderName, String Sessionid) throws IOException, Exception, FileNotFoundException {
//        NGEjbClient ngEJBClient = null;
//        ngEJBClient = NGEjbClient.getSharedInstance();
//        DMSInputXml input=new DMSInputXml();
//        input.getAddFolderXml(str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str)
        StringBuffer strInputXml = null;
        try {
            strInputXml = new StringBuffer();
            String sOutputXml = new String();
            strInputXml.append("<?xml version=1.0?>");
            strInputXml.append("<NGOAddFolder_Input>");
            strInputXml.append("<Option>NGOAddFolder</Option>");
            strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
            strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
            strInputXml.append("<Folder>");
            strInputXml.append("<ParentFolderIndex>21737</ParentFolderIndex>");//21737 is BritanniaKYC
            strInputXml.append("<FolderName>" + strFolderName + "</FolderName>");
            strInputXml.append("<CreationDateTime></CreationDateTime>");
            strInputXml.append("<AccessType>S</AccessType>");
            strInputXml.append("<ImageVolumeIndex>1</ImageVolumeIndex>");
            strInputXml.append("<FolderType>G</FolderType>");
            //strInputXml.append("<Location>G</Location>");
            strInputXml.append("<Comment>comments</Comment>");
            strInputXml.append("<Owner>" + UserName + "</Owner>");
            strInputXml.append("<LogGeneration>Y</LogGeneration>");
            strInputXml.append("<EnableFtsFlag>Y</EnableFtsFlag>");
            strInputXml.append("<DuplicateName>N</DuplicateName>");
//            strInputXml.append("<DataDefinition>");
//            strInputXml.append("<DataDefName></DataDefName>");
//            strInputXml.append("<Fields>");
//            strInputXml.append("<Field>");
//            strInputXml.append("<IndexId></IndexId>");
//            strInputXml.append("<IndexValue></IndexValue>");
//            strInputXml.append("<IndexType></IndexType>");
//            strInputXml.append("</Field>");
//            strInputXml.append("</Fields>");
//            strInputXml.append("</DataDefinition>");
            strInputXml.append("</Folder>");
            strInputXml.append("</NGOAddFolder_Input>");
            loggerCnsl.info("addFolder Input XML ====>  " + strInputXml.toString());
            loggerXml.info("addFolder Input XML ====>  " + strInputXml.toString());
            sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt(jtsPort), 0);
            loggerCnsl.info("addFolder output XML ====>  " + sOutputXml.toString());
            loggerXml.info("addFolder output XML ====>  " + sOutputXml.toString());
            WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);
            if (xmlResponse.getVal("Status").equals("0")) {
                loggerCnsl.info("Folder created Successfully!!!!!!!!!!!!!");
                strFID = xmlResponse.getVal("FolderIndex");
            } else {
                loggerCnsl.info("Folder already exist with the same name.!!!!!!!!!!!!!");
                strFID = xmlResponse.getVal("FolderIndex");
            }
        } catch (NGException ex) {
            loggerErr.info("\n\n### **(Error)**###");
        } catch (FileNotFoundException exx) {
            loggerErr.info("\n\n### **(Error)**###");
        }
        return strFID;
    }

    public String addUploadPhotoFolder(String strFolderName, String Sessionid) throws IOException, Exception, FileNotFoundException {
//        NGEjbClient ngEJBClient = null;
//        ngEJBClient = NGEjbClient.getSharedInstance();
//        DMSInputXml input=new DMSInputXml();
//        input.getAddFolderXml(str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str)
        StringBuffer strInputXml = null;
        try {
            strInputXml = new StringBuffer();
            String sOutputXml = new String();
            strInputXml.append("<?xml version=1.0?>");
            strInputXml.append("<NGOAddFolder_Input>");
            strInputXml.append("<Option>NGOAddFolder</Option>");
            strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
            strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
            strInputXml.append("<Folder>");
            strInputXml.append("<ParentFolderIndex>22106</ParentFolderIndex>");//22106 is HR_Upload_PHOTOGRAPH
            strInputXml.append("<FolderName>" + strFolderName + "</FolderName>");
            strInputXml.append("<CreationDateTime></CreationDateTime>");
            strInputXml.append("<AccessType>S</AccessType>");
            strInputXml.append("<ImageVolumeIndex>1</ImageVolumeIndex>");
            strInputXml.append("<FolderType>G</FolderType>");
            //strInputXml.append("<Location>G</Location>");
            strInputXml.append("<Comment>comments</Comment>");
            strInputXml.append("<Owner>" + UserName + "</Owner>");
            strInputXml.append("<LogGeneration>Y</LogGeneration>");
            strInputXml.append("<EnableFtsFlag>Y</EnableFtsFlag>");
            strInputXml.append("<DuplicateName>N</DuplicateName>");
//            strInputXml.append("<DataDefinition>");
//            strInputXml.append("<DataDefName></DataDefName>");
//            strInputXml.append("<Fields>");
//            strInputXml.append("<Field>");
//            strInputXml.append("<IndexId></IndexId>");
//            strInputXml.append("<IndexValue></IndexValue>");
//            strInputXml.append("<IndexType></IndexType>");
//            strInputXml.append("</Field>");
//            strInputXml.append("</Fields>");
//            strInputXml.append("</DataDefinition>");
            strInputXml.append("</Folder>");
            strInputXml.append("</NGOAddFolder_Input>");
            loggerCnsl.info("addFolder Input XML ====> " + strInputXml.toString());
            loggerXml.info("addFolder Input XML ====> " + strInputXml.toString());
            sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt(jtsPort), 0);
            loggerCnsl.info("addFolder output XML ====> " + sOutputXml.toString());
            loggerXml.info("addFolder output XML ====> " + sOutputXml.toString());
            WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);
            if (xmlResponse.getVal("Status").equals("0")) {
                loggerCnsl.info("Folder created Successfully!!!!!!!!!!!!!");
                strFID = xmlResponse.getVal("FolderIndex");
            } else {
                loggerCnsl.info("Folder already exist with the same name.!!!!!!!!!!!!!");
                strFID = xmlResponse.getVal("FolderIndex");
            }
        } catch (NGException ex) {
            loggerErr.info("\n\n### **(Error)**###");
        } catch (FileNotFoundException exx) {
            loggerErr.info("\n\n### **(Error)**###");
        }
        return strFID;
    }

    public static List<String> getTypeOfFunctionMethod(String sessionId, PropertyBean probBean) {
        loggerCnsl.info("Inside getTypeOfFunctionMethod==");
        String strInputXml;
        List<String> typeOfFunc = new ArrayList();
        typeOfFunc.add("Select a Query Raised For");
        String strQuery = "SELECT TypeOfFunction FROM EXT_HELPDESK_MASTER_TICKET_FUNCTION WITH(NOLOCK)";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    typeOfFunc.add(strTypeOfFunction);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfFunction==" + strTypeOfFunction);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return typeOfFunc;
    }

    public static List<String> getGuestHouseListMethod(String sessionId, PropertyBean probBean) {
        loggerCnsl.info("Inside getTypeOfFunctionMethod==");
        String strInputXml;
        List<String> typeOfLoc = new ArrayList();
        typeOfLoc.add("Select a Location");
        String strQuery = "SELECT DISTINCT(location) FROM EXT_ER_MASTER_PAN_GUESTHOUSE_DETAILS WITH(nolock) WHERE Location='Bangalore'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfLocation = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    strTypeOfLocation = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    typeOfLoc.add(strTypeOfLocation);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfLocation==" + strTypeOfLocation);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return typeOfLoc;
    }
    
    public static List<String> getCabRequestListMethod(String sessionId, PropertyBean probBean) {
        loggerCnsl.info("Inside getTypeOfFunctionMethod==");
        String strInputXml;
        List<String> typeOfLoc = new ArrayList();
        typeOfLoc.add("Select a Location");
        String strQuery = "SELECT DISTINCT(location) FROM EXT_CABREQUEST_MASTER_DETAILS WITH(nolock)";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfLocation = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    strTypeOfLocation = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    typeOfLoc.add(strTypeOfLocation);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfLocation==" + strTypeOfLocation);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return typeOfLoc;
    }

    public static List<String> getTypeOfComplaintAbountMethod(String sessionId, PropertyBean probBean) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        List<String> typeOfFunc = new ArrayList();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT TypeOfFunction FROM EXT_LR_COMPLAINTS_MASTER_FUNCTION WITH(NOLOCK)";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    typeOfFunc.add(strTypeOfFunction);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfFunction==" + strTypeOfFunction);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return typeOfFunc;
    }

    public static ArrayList<GuestHouseDetails> getGuestHouseDetailsMethod(String sessionId, PropertyBean probBean, String strvarToLoc) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        GuestHouseDetails objGHouse = new GuestHouseDetails();
        ArrayList<GuestHouseDetails> guestDetails = new ArrayList<GuestHouseDetails>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT Location, FullAddress, ReservationsBy, ContactDetails, CareTakerDetails, NoOfSingleOccupancy,NoOfDoubleOccupancy, NoOfTotalOccupancy, Remarks, RegionalAdmin FROM dbo.EXT_ER_MASTER_PAN_GUESTHOUSE_DETAILS WITH(nolock) WHERE Location='" + strvarToLoc + "' ";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objGHouse.setLocation(wfxmllist.getVal("Value1").trim());
                    objGHouse.setFullAddress(wfxmllist.getVal("Value2").trim());
                    objGHouse.setReservationsBy(wfxmllist.getVal("Value3").trim());
                    objGHouse.setContactDetails(wfxmllist.getVal("Value4").trim());
                    objGHouse.setCareTakerDetails(wfxmllist.getVal("Value5").trim());
                    objGHouse.setNoOfSingleOccupancy(wfxmllist.getVal("Value6").trim());
                    objGHouse.setNoOfDoubleOccupancy(wfxmllist.getVal("Value7").trim());
                    objGHouse.setNoOfTotalOccupancy(wfxmllist.getVal("Value8").trim());
                    objGHouse.setRemarks(wfxmllist.getVal("Value9").trim());
                    objGHouse.setRegionalAdmin(wfxmllist.getVal("Value10").trim());
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfFunction==" + strTypeOfFunction);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }

    public static ArrayList<GuestHouseDetails> getGuestHouseDetailsMethodForMail(String sessionId, PropertyBean probBean, String strvarToLoc) {
        loggerCnsl.info("Inside getGuestHouseDetailsMethodForMail ==");
        String strInputXml;
        GuestHouseDetails objGHouse = new GuestHouseDetails();
        ArrayList<GuestHouseDetails> guestDetails = new ArrayList<GuestHouseDetails>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT FullAddress, ReservationsBy, ContactDetails, CareTakerDetails, Remarks, RegionalAdmin, REGIONALADMIN_USEREMAIL,GUESTHOUSE_USEREMAIL,CABREQ_USEREMAIL FROM dbo.EXT_ER_MASTER_PAN_GUESTHOUSE_DETAILS WITH(nolock) WHERE Location='" + strvarToLoc + "' ";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objGHouse.setFullAddress(wfxmllist.getVal("Value1").trim());
                    objGHouse.setReservationsBy(wfxmllist.getVal("Value2").trim());
                    objGHouse.setContactDetails(wfxmllist.getVal("Value3").trim());
                    objGHouse.setCareTakerDetails(wfxmllist.getVal("Value4").trim());
                    objGHouse.setRemarks(wfxmllist.getVal("Value5").trim());
                    objGHouse.setRegionalAdmin(wfxmllist.getVal("Value6").trim());
                    objGHouse.setRegionalAdminEmail(wfxmllist.getVal("Value7").trim());
                    objGHouse.setGUESTHOUSE_USEREMAIL(wfxmllist.getVal("Value8").trim());
                    objGHouse.setCABREQ_USEREMAIL(wfxmllist.getVal("Value9").trim());
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfFunction==" + strTypeOfFunction);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }
    
    public static ArrayList<GuestHouseDetails> getCabRequestDetailsMethodForMail(String sessionId, PropertyBean probBean, String strvarToLoc) {
        loggerCnsl.info("Inside getGuestHouseDetailsMethodForMail ==");
        String strInputXml;
        GuestHouseDetails objGHouse = new GuestHouseDetails();
        ArrayList<GuestHouseDetails> guestDetails = new ArrayList<GuestHouseDetails>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT RegionalAdmin, REGIONALADMIN_USEREMAIL,GUESTHOUSE_USEREMAIL,CABREQ_USEREMAIL FROM dbo.EXT_CABREQUEST_MASTER_DETAILS WITH(nolock) WHERE Location='" + strvarToLoc + "' ";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    objGHouse.setRegionalAdmin(wfxmllist.getVal("Value1").trim());
                    objGHouse.setRegionalAdminEmail(wfxmllist.getVal("Value2").trim());
                    objGHouse.setGUESTHOUSE_USEREMAIL(wfxmllist.getVal("Value3").trim());
                    objGHouse.setCABREQ_USEREMAIL(wfxmllist.getVal("Value4").trim());
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfFunction==" + strTypeOfFunction);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }

    public static ArrayList<String> getGuestHouseRoomTypesMethod(String sessionId, PropertyBean probBean, String strGuestHouseLocation) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT DISTINCT(RoomType) FROM EXT_GUESTHOUSE_ROOMS_MASTER WITH(NOLOCK) WHERE GuestHouseLocation='" + strGuestHouseLocation + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                RoomType_add.add("--Select--" + "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strRoomType = wfxmllist.getVal("Value1").trim();
                    RoomType_add.add(strRoomType + "$#!");
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }

    public static ArrayList<String> getGuestHouseTypeOfCabMethod(String sessionId, PropertyBean probBean, String empGrade) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT CARTYPE FROM EXT_GHB_CABTYPE_ONGRADEWISE_MASTER WITH(NOLOCK) WHERE GRADE='" + empGrade + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                RoomType_add.add("--Select--" + "/");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strCabType = wfxmllist.getVal("Value1").trim();
                    RoomType_add.add(strCabType + "/");
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }
    
    public static ArrayList<String> getCabRequestOtherEmpDataMethod(String sessionId, PropertyBean probBean, String otherEmpEmailID) {
        loggerCnsl.info("Inside getCabRequestOtherEmpDataMethod ==");
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT Employee_ID,Vendor_Code,Employee_Name,Designation,Cost_Centre,Business_Area_Code,RM_USERID,CompanyCode FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WITH(nolock) WHERE Email_ID='" + otherEmpEmailID + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCabRequestOtherEmpDataMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCabRequestOtherEmpDataMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                RoomType_add.add("--Select--" + "/");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strEmployeeCode = wfxmllist.getVal("Value1").trim();
                    String strVendorCode = wfxmllist.getVal("Value2").trim();
                    String strEmpName = wfxmllist.getVal("Value3").trim();
                    String strDesignation = wfxmllist.getVal("Value4").trim();
                    String strCostcenter = wfxmllist.getVal("Value5").trim();
                    String strBusinessArea = wfxmllist.getVal("Value6").trim();
                    String strRMUserID = wfxmllist.getVal("Value7").trim();
                    String strCompanyCode = wfxmllist.getVal("Value8    ").trim();
                    RoomType_add.add(strEmployeeCode + "/$#!"+strVendorCode+ "/$#!"+strEmpName+ "/$#!"+strDesignation+ "/$#!"+strCostcenter+ "/$#!"+strBusinessArea+ "/$#!"+strRMUserID+ "/$#!"+strCompanyCode);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }

    public static ArrayList<String> getGuestHouseRoomNamesMethod(String sessionId, PropertyBean probBean, String strGuestHouseLocation, String RoomType) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT DISTINCT(RoomName) FROM EXT_GUESTHOUSE_ROOMS_MASTER WITH(NOLOCK) WHERE GuestHouseLocation='" + strGuestHouseLocation + "' AND RoomType='" + RoomType + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                RoomType_add.add("--Select--" + "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strRoomType = wfxmllist.getVal("Value1").trim();
                    RoomType_add.add(strRoomType + "$#!");
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }

    public static ArrayList<String> getGuestHouseRoomNumbersMethod(String sessionId, PropertyBean probBean, String strGuestHouseLocation, String RoomType, String RoomName) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT DISTINCT(RoomNumber) FROM EXT_GUESTHOUSE_ROOMS_MASTER WITH(NOLOCK) WHERE GuestHouseLocation='" + strGuestHouseLocation + "' AND RoomType='" + RoomType + "' AND RoomName='" + RoomName + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                RoomType_add.add("--Select--" + "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strRoomType = wfxmllist.getVal("Value1").trim();
                    RoomType_add.add(strRoomType + "$#!");
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }

    public static ArrayList<String> getGuestHouseRoomStatusMethod(String sessionId, PropertyBean probBean, String strGuestHouseLocation, String RoomType, String RoomName, String RoomNumber, String FromDate, String ToDate) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String FromDate1 = CommonMethod.formatDate(FromDate);
        String ToDate1 = CommonMethod.formatDate(ToDate);
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
//        String strQuery = "SELECT DISTINCT(RoomStatus) FROM EXT_GUESTHOUSE_ROOMS_MASTER WITH(NOLOCK) WHERE GuestHouseLocation='" + strGuestHouseLocation + "' AND RoomType='" + RoomType + "' AND RoomName='" + RoomName + "' AND RoomNumber='" + RoomNumber + "'";
        String strQuery = "SELECT CONVERT(CHAR(10), FromDate, 103),CONVERT(CHAR(10), ToDate, 103) FROM EXT_GUESTHOUSE_OCCUPANCY_DETAILS_ACTIVE WITH(NOLOCK) WHERE GuestHouseLocation='" + strGuestHouseLocation + "' AND (((FromDate BETWEEN '" + FromDate1 + "' AND '" + ToDate1 + "') OR (ToDate BETWEEN '" + FromDate1 + "' AND '" + ToDate1 + "')) OR (('" + FromDate1 + "' BETWEEN FromDate AND ToDate) OR ('" + ToDate1 + "' BETWEEN FromDate AND ToDate))) AND RoomType='" + RoomType + "' AND RoomName='" + RoomName + "' AND RoomNumber='" + RoomNumber + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
//                RoomType_add.add("--Select--"+ "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strFromDate = wfxmllist.getVal("Value1").trim();
                    String strToDate = wfxmllist.getVal("Value2").trim();
                    RoomType_add.add("Unavailable" + "$#!" + strFromDate + "$#!" + strToDate + "$#!");
                    wfxmllist.skip(true);
                }
            } else if (parsergetlist.getValueOf("MainCode").equals("18")) {
                RoomType_add.add("Available");
//                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
//                wfxmllist = wfXmlResponse.createList("DataList", "Data");
//                wfxmllist.reInitialize(true);
////                RoomType_add.add("--Select--"+ "$#!");
//                while (wfxmllist.hasMoreElements()) {
////                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
//                    //String tCode = wfxmllist.getVal("TaxCode");
////                    String strFromDate = wfxmllist.getVal("Value1").trim();
////                    String strToDate = wfxmllist.getVal("Value2").trim();
//                    RoomType_add.add("Available");
//                    wfxmllist.skip(true);
//                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }

    public static ArrayList<String> getGuestHouseRoomsAvailabilityMethod(String sessionId, PropertyBean probBean, String strGuestHouseLocation, String RoomType, String FromDate, String ToDate) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String FromDate1 = CommonMethod.formatDate(FromDate);
        String ToDate1 = CommonMethod.formatDate(ToDate);
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
//        String strQuery = "SELECT DISTINCT(RoomStatus) FROM EXT_GUESTHOUSE_ROOMS_MASTER WITH(NOLOCK) WHERE GuestHouseLocation='" + strGuestHouseLocation + "' AND RoomType='" + RoomType + "' AND RoomName='" + RoomName + "' AND RoomNumber='" + RoomNumber + "'";
        String strQuery = "SELECT Count(1) FROM EXT_GUESTHOUSE_OCCUPANCY_DETAILS_ACTIVE a WITH(NOLOCK), EXT_GUESTHOUSE_ROOMS_MASTER  b WITH(NOLOCK) WHERE b.RoomNumber=a.RoomNumber AND b.RoomName=a.RoomName AND a.GuestHouseLocation='" + strGuestHouseLocation + "' AND (((a.FromDate BETWEEN '" + FromDate1 + "' AND '" + ToDate1 + "') OR (a.ToDate BETWEEN '" + FromDate1 + "' AND '" + ToDate1 + "')) OR (('" + FromDate1 + "' BETWEEN FromDate AND ToDate) OR ('" + ToDate1 + "' BETWEEN FromDate AND ToDate))) AND b.RoomType='" + RoomType + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
//                RoomType_add.add("--Select--"+ "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strFromDate = wfxmllist.getVal("Value1").trim();
                    RoomType_add.add(strFromDate);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }
    
    public static ArrayList<EmployeeGuestHouseData> getGuestHouseEmpDataMethod(String sessionId, PropertyBean probBean, String strEmployeeName) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        EmployeeGuestHouseData objGHouse = new EmployeeGuestHouseData();
        ArrayList<EmployeeGuestHouseData> guestDetails = new ArrayList<EmployeeGuestHouseData>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT Employee_ID AS 'Employee Number',User_ID AS 'EmployeeUserID',Employee_Name AS 'Employee Name',Email_ID AS 'Email ID',Mobile_No AS 'Contact Number',Region AS 'Region',Work_Location AS 'Work Location',RM_USERID AS 'Reporting Manager',USERID AS 'HRBPUSERID',ENAME AS 'HRBP Name',Vendor_Code AS 'Vendor Code',Designation,Emp_Subgroup AS 'Grade',Org_Unit AS 'Department',VEN_GLCODE,Cost_Centre FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WITH(NOLOCK) WHERE User_ID='" + strEmployeeName + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objGHouse.setEmpNumber(wfxmllist.getVal("Value1").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpUserID(wfxmllist.getVal("Value2").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpName(wfxmllist.getVal("Value3").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpEmailID(wfxmllist.getVal("Value4").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpContactNum(wfxmllist.getVal("Value5").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRegion(wfxmllist.getVal("Value6").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpWorkLoc(wfxmllist.getVal("Value7").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRM(wfxmllist.getVal("Value8").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPUserID(wfxmllist.getVal("Value9").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPName(wfxmllist.getVal("Value10").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorCode(wfxmllist.getVal("Value11").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDesignation(wfxmllist.getVal("Value12").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpGrade(wfxmllist.getVal("Value13").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDepartment(wfxmllist.getVal("Value14").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorGL(wfxmllist.getVal("Value15").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpCostCenter(wfxmllist.getVal("Value16").trim().replaceAll("&amp;", "and"));
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }
    
    public static ArrayList<EmployeeGuestHouseData> getCabRequestEmpDataMethod(String sessionId, PropertyBean probBean, String strEmployeeName) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        EmployeeGuestHouseData objGHouse = new EmployeeGuestHouseData();
        ArrayList<EmployeeGuestHouseData> guestDetails = new ArrayList<EmployeeGuestHouseData>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT Employee_ID AS 'Employee Number',User_ID AS 'EmployeeUserID',Employee_Name AS 'Employee Name',Email_ID AS 'Email ID',Mobile_No AS 'Contact Number',Region AS 'Region',Work_Location AS 'Work Location',RM_USERID AS 'Reporting Manager',USERID AS 'HRBPUSERID',ENAME AS 'HRBP Name',Vendor_Code AS 'Vendor Code',Designation,Emp_Subgroup AS 'Grade',Org_Unit AS 'Department',VEN_GLCODE,Cost_Centre,Business_Area_Code FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WITH(NOLOCK) WHERE User_ID='" + strEmployeeName + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objGHouse.setEmpNumber(wfxmllist.getVal("Value1").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpUserID(wfxmllist.getVal("Value2").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpName(wfxmllist.getVal("Value3").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpEmailID(wfxmllist.getVal("Value4").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpContactNum(wfxmllist.getVal("Value5").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRegion(wfxmllist.getVal("Value6").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpWorkLoc(wfxmllist.getVal("Value7").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRM(wfxmllist.getVal("Value8").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPUserID(wfxmllist.getVal("Value9").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPName(wfxmllist.getVal("Value10").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorCode(wfxmllist.getVal("Value11").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDesignation(wfxmllist.getVal("Value12").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpGrade(wfxmllist.getVal("Value13").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDepartment(wfxmllist.getVal("Value14").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorGL(wfxmllist.getVal("Value15").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpCostCenter(wfxmllist.getVal("Value16").trim().replaceAll("&amp;", "and"));
                    objGHouse.setBusinessAreaCode(wfxmllist.getVal("Value17").trim().replaceAll("&amp;", "and"));
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }

    public static List<String> getTypeOfCategoryMethod(String ticketFunction, String sessionId, PropertyBean probBean) {
        loggerCnsl.info("Inside getTypeOfCategoryMethod==");
        String strInputXml;
        List<String> typeOfCategory = new ArrayList();
        typeOfCategory.add("Select a Category");
        String strQuery = "SELECT TypeOfCategory FROM EXT_HELPDESK_MASTER_TICKET_CATEGORY WITH(NOLOCK) WHERE TypeOfFunction='" + ticketFunction + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfCategory = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    strTypeOfCategory = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    typeOfCategory.add(strTypeOfCategory);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfCategory==" + strTypeOfCategory);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return typeOfCategory;
    }

    public static List<String> getTypeOfSubCategoryMethod(String ticketFunction, String ticketCategory, String sessionId, PropertyBean probBean) {
        loggerCnsl.info("Inside getTypeOfCategoryMethod==");
        String strInputXml;
        List<String> typeOfCategory = new ArrayList();
        typeOfCategory.add("Select a Sub-Category$#!Enter Assigning User$#!Enter Assigning User Full Name");
        String strQuery = "SELECT TypeOfSubCategory,AdminUser,AdminUserFullName FROM EXT_HELPDESK_MASTER_TICKET_CATEGORY WITH(NOLOCK) WHERE TypeOfFunction='" + ticketFunction + "' AND TypeOfCategory='" + ticketCategory + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfSubCategory = "";
        String strAssigningUser = "";
        String strAssigningUserFullName = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    strTypeOfSubCategory = wfxmllist.getVal("Value1").trim();
                    strAssigningUser = wfxmllist.getVal("Value2").trim();
                    strAssigningUserFullName = wfxmllist.getVal("Value3").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    typeOfCategory.add(strTypeOfSubCategory + "$#!" + strAssigningUser + "$#!" + strAssigningUserFullName);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfSubCategory == " + strTypeOfSubCategory);
                loggerCnsl.info("strAssigningUser == " + strAssigningUser);
                loggerCnsl.info("strAssigningUserFullName == " + strAssigningUserFullName);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return typeOfCategory;
    }

    public String initiateworkitemwithDocument(HelpDeskPortalFields objHPF, String WorkitemEndPointurl,
            String Sessionid, ArrayList AddtoSMS_Response_sd, String cabinet,
            String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId, String ProcessName,
            String Docname) {
        long starttime = System.currentTimeMillis();
        loggerCnsl.info("initiateworkitemwithDocument Method Starts..." + WorkitemEndPointurl);
        CommonMethod cmnMethod = new CommonMethod();
        String Response = "";
        String SOAP_inxml = "";
        String sessionid = "";
        String option = "";
        String result = "";
        String folderindex = "";
        String processinstanceid = "";
        String maincode = "";
        HashMap<String, String> xmlvalues = null;
        ArrayList<HashMap<String, String>> OdValues_List = null;
        HashMap<String, String> xmlvalues_odvalues = null;
        ArrayList<String> outptXMLlst = null;
        SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        String str_dateFrom = "";
        String str_dateTo = "";
        ArrayList<String> SOAPResponse_xml_vp = null;
        try {

            xmlvalues = new HashMap<String, String>();

            OdValues_List = new ArrayList<HashMap<String, String>>();
            xmlvalues.put("EmployeeNumber", objHPF.getEmployeeNumber().trim());
            xmlvalues.put("EmployeeName", objHPF.getEmployeeName());
            xmlvalues.put("InitiationBy", objHPF.getInitBy());
            xmlvalues.put("CorporateFunction", objHPF.getCorporateFunction());
            xmlvalues.put("HRFunction", objHPF.getHRFunction());
            xmlvalues.put("InitiationStatus", "HP");
            xmlvalues.put("Gender", objHPF.getGender());
            xmlvalues.put("EmailID", objHPF.getEmailID());
            xmlvalues.put("WorkLocation", objHPF.getWorkLocation());
            xmlvalues.put("TicketFunction", objHPF.getTicketFunction());
            xmlvalues.put("TicketCategory", objHPF.getTicketCategory());
            xmlvalues.put("TicketSubCategory", objHPF.getTicketSubCategory());
            xmlvalues.put("TicketAssigningUser", objHPF.getTicketAssigningUser());
            xmlvalues.put("TicketSubject", objHPF.getTicketSubject());
            xmlvalues.put("TicketPriority", objHPF.getTicketPriority());
            xmlvalues.put("TicketContactNumber", objHPF.getTicketContactNumber());
            xmlvalues.put("TicketMessage", objHPF.getTicketMessage());

            xmlvalues.put("Region", objHPF.getRegion());
            xmlvalues.put("VendorCode", objHPF.getVendorCode());
            xmlvalues.put("VendorGL", objHPF.getVendorGL());
            xmlvalues.put("Designation", objHPF.getDesignation());
            xmlvalues.put("Department", objHPF.getDepartment());
            xmlvalues.put("Grade", objHPF.getGrade());
            xmlvalues.put("Category", objHPF.getCategory());
            xmlvalues.put("TicketAssigningUserFullName", objHPF.getTicketAssigningUserFullName());

            for (int i = 0; i < AddtoSMS_Response_sd.size(); i++) {
                String[] sISIndex = ((String) AddtoSMS_Response_sd.get(i)).split("#");
                String simgDocId = sISIndex[0];
                String simgVolId1 = sISIndex[1];
                String apptype = sISIndex[2];
                String nNoOfPages = sISIndex[3];
                String lgvDocSize = sISIndex[4];
                String doctype = "";
                if (apptype == "pdf") {
                    doctype = "N";
                } else {
                    doctype = "I";
                }

                loggerCnsl.info("simgDocId --> " + simgDocId);
                loggerCnsl.info("simgVolId1 --> " + simgVolId1);
                loggerCnsl.info("apptype --> " + apptype);
                loggerCnsl.info("doctype --> " + doctype);
                if (i == 0) {
                    Docname = "HelpDesk_Attachment";
                }

                xmlvalues_odvalues = new HashMap<String, String>();
                xmlvalues_odvalues.put("appType", apptype);
                xmlvalues_odvalues.put("checkoutBy", "0");
                xmlvalues_odvalues.put("checkoutStatus", "no");
                xmlvalues_odvalues.put("comment", "Workitem with Document");
                xmlvalues_odvalues.put("createdByAppName", apptype);
                xmlvalues_odvalues.put("documentIndex", simgDocId);
                xmlvalues_odvalues.put("documentSize", lgvDocSize);
                xmlvalues_odvalues.put("documentType", doctype);
                xmlvalues_odvalues.put("imageIndex", simgDocId);
                xmlvalues_odvalues.put("name", Docname);
                xmlvalues_odvalues.put("noOfPages", nNoOfPages);
                xmlvalues_odvalues.put("ownerIndex", "1");
                xmlvalues_odvalues.put("versionNumber", "1");
                xmlvalues_odvalues.put("volumnIndex", simgVolId1);

                OdValues_List.add(xmlvalues_odvalues);
            }

            SOAP_inxml = CommonMethod.wfInitiatewithDocumentXML(xmlvalues, OdValues_List, Sessionid, cabinet,
                    InitiateFromActivityId, InitiateFromActivityName, ProcessDefId, ProcessName);

            loggerCnsl.info(" SOAP_inxml after framing the Tags" + SOAP_inxml);
            loggerXml.info(" SOAP_inxml after framing the Tags" + SOAP_inxml);

            String SOAPResponse_xml = "";
            String action = "wfinitiate";
            //WebService Call
            NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
            SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, WorkitemEndPointurl, action);

            loggerCnsl.info("SOAPResponse_xml--->" + SOAPResponse_xml);

            loggerXml.info("outputXML : " + SOAPResponse_xml);

            if (!CommonMethod.isNullOrEmpty(SOAPResponse_xml)) {
                int startPosition = SOAPResponse_xml.indexOf("processInstanceId>");
                int startmainPosition = SOAPResponse_xml.indexOf("mainCode>");
                processinstanceid = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("processInstanceId>") + 18,
                        SOAPResponse_xml.indexOf("</", startPosition));
                maincode = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("mainCode>") + 9,
                        SOAPResponse_xml.indexOf("</", startmainPosition));
                loggerCnsl.info("processinstanceid" + processinstanceid);
                loggerCnsl.info("processinstanceid =====> " + processinstanceid);

                if (maincode.equalsIgnoreCase("0")) {
                    result = processinstanceid;
                    loggerCnsl.info("result =====> " + result);
                    Response = result;
                    loggerCnsl.info("WorkItem Initiated Successfully");
                } else {
                    result = "Pending";
                    Response = result;
                    loggerCnsl.info("Document added to SMS  and WorkItem Initiation Unsuccessful");
                }

            } else {
                result = "Pending";
                Response = result;
                loggerCnsl.info("Document added to SMS  and WorkItem Initiation Unsuccessful");
            }

        } catch (Exception e) {
            loggerErr.error("Exception occured :" + e.getMessage());
            e.printStackTrace();
            result = "Pending";
            Response = result;
        }

        long endTime = System.currentTimeMillis();
        long totaltime = endTime - starttime;
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("Response is --->:" + Response);
        loggerCnsl.info("Total Time Taken in initiating workitem is:" + totaltime);

        return Response;
    }

    public String initiateLRworkitemwithDocument(LRFields objHPF, String WorkitemEndPointurl,
            String Sessionid, ArrayList AddtoSMS_Response_sd, String cabinet,
            String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId, String ProcessName,
            String Docname) {
        long starttime = System.currentTimeMillis();
        loggerCnsl.info("initiateworkitemwithDocument Method Starts..." + WorkitemEndPointurl);
        CommonMethod cmnMethod = new CommonMethod();
        String Response = "";
        String SOAP_inxml = "";
        String sessionid = "";
        String option = "";
        String result = "";
        String folderindex = "";
        String processinstanceid = "";
        String maincode = "";
        HashMap<String, String> xmlvalues = null;
        ArrayList<HashMap<String, String>> OdValues_List = null;
        HashMap<String, String> xmlvalues_odvalues = null;
        ArrayList<String> outptXMLlst = null;
        SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        String str_dateFrom = "";
        String str_dateTo = "";
        ArrayList<String> SOAPResponse_xml_vp = null;
        try {

            xmlvalues = new HashMap<String, String>();

            OdValues_List = new ArrayList<HashMap<String, String>>();
            xmlvalues.put("DateOfRequest", objHPF.getStrdateofrequest().trim());
            xmlvalues.put("ReqEmployeeCode", objHPF.getReqEmployeeNumber().trim());
            xmlvalues.put("ReqEmployeeName", objHPF.getReqEmployeeName().trim());
            xmlvalues.put("ReqEmailID", objHPF.getReqEmailID().trim());
            xmlvalues.put("ReqWorkLocation", objHPF.getReqWorkLocation().trim());
            xmlvalues.put("EmpNumber", objHPF.getEmployeeNumber().trim());
            xmlvalues.put("EmpName", objHPF.getEmployeeName());
            xmlvalues.put("EmpEmailID", objHPF.getEmailID());
            xmlvalues.put("EmpWorkLocation", objHPF.getWorkLocation());
            xmlvalues.put("EmpDOJ", objHPF.getDateOfJoining());
            xmlvalues.put("EmpPO", objHPF.getPOrg());
            xmlvalues.put("EmpPA", objHPF.getPA());
            xmlvalues.put("EmpPSA", objHPF.getPSA());
            xmlvalues.put("EmpContactNo", objHPF.getContactNumber());
            xmlvalues.put("EmpGrade", objHPF.getEmpGrade());
            xmlvalues.put("EmpDesignation", objHPF.getEmpDesignation());
            xmlvalues.put("EmpCorporateFunc", objHPF.getCorporateFunction());
            xmlvalues.put("EmpHRFunc", objHPF.getHRFunction());
            xmlvalues.put("EmpRegion", objHPF.getRegion());
            xmlvalues.put("EmpVendorCode", objHPF.getVendorCode());
            xmlvalues.put("EmpGL", objHPF.getVendorGL());
            xmlvalues.put("EmpDepartment", objHPF.getDepartment());
            xmlvalues.put("EmpRM", objHPF.getRepManager());
            xmlvalues.put("EmpHRBP", objHPF.getHiddenHRBP());
            xmlvalues.put("EmpHRBPFullName", objHPF.getHRBPName());
            xmlvalues.put("EmpHRBPEmpCode", objHPF.getHiddenHRBPEmployeeCode());
            xmlvalues.put("ComplaintRaisedBy", objHPF.getHiddenHRBP());
            xmlvalues.put("ComplaintRaisedOn", objHPF.getComplaintraisedon());
            xmlvalues.put("ComplaintAction", "Register");
            xmlvalues.put("ComplaintAbout", objHPF.getComplaintAbout());
            xmlvalues.put("ComplaintOthersFreeText", objHPF.getComplaintAboutOthers());
            xmlvalues.put("ReferenceComment", objHPF.getReferenceComments());
            xmlvalues.put("DetailsOfTheComplaint", objHPF.getDetailsOfComplaint());
            xmlvalues.put("comments", objHPF.getComments());
            xmlvalues.put("isBritEmployee", objHPF.getIsBritEmployee());
            if (objHPF.getIsBritEmployee().equalsIgnoreCase("Yes")) {
                xmlvalues.put("comRepEmployeeNumber", objHPF.getComRepEmployeeNumber());
                xmlvalues.put("comRepEmployeeName", objHPF.getComRepEmployeeName());
                xmlvalues.put("comRepEmailID", objHPF.getComRepEmailID());
                xmlvalues.put("comRepWorkLocation", objHPF.getComRepWorkLocation());
            } else if (objHPF.getIsBritEmployee().equalsIgnoreCase("No")) {
                xmlvalues.put("comRepNonEmployeeNumber", objHPF.getComRepNonEmployeeNumber());
                xmlvalues.put("comRepNonEmployeeName", objHPF.getComRepNonEmployeeName());
            }
            xmlvalues.put("LR_Initiation_By", objHPF.getStrEmployeeUID());

            for (int i = 0; i < AddtoSMS_Response_sd.size(); i++) {
                String[] sISIndex = ((String) AddtoSMS_Response_sd.get(i)).split("#");
                String simgDocId = sISIndex[0];
                String simgVolId1 = sISIndex[1];
                String apptype = sISIndex[2];
                String nNoOfPages = sISIndex[3];
                String lgvDocSize = sISIndex[4];
                String doctype = "";
                if (apptype == "pdf") {
                    doctype = "N";
                } else {
                    doctype = "I";
                }

                loggerCnsl.info("simgDocId --> " + simgDocId);
                loggerCnsl.info("simgVolId1 --> " + simgVolId1);
                loggerCnsl.info("apptype --> " + apptype);
                loggerCnsl.info("doctype --> " + doctype);
                if (i == 0) {
                    Docname = "HRBP_DOCS";
                }

                xmlvalues_odvalues = new HashMap<String, String>();
                xmlvalues_odvalues.put("appType", apptype);
                xmlvalues_odvalues.put("checkoutBy", "0");
                xmlvalues_odvalues.put("checkoutStatus", "no");
                xmlvalues_odvalues.put("comment", "Workitem with Document");
                xmlvalues_odvalues.put("createdByAppName", apptype);
                xmlvalues_odvalues.put("documentIndex", simgDocId);
                xmlvalues_odvalues.put("documentSize", lgvDocSize);
                xmlvalues_odvalues.put("documentType", doctype);
                xmlvalues_odvalues.put("imageIndex", simgDocId);
                xmlvalues_odvalues.put("name", Docname);
                xmlvalues_odvalues.put("noOfPages", nNoOfPages);
                xmlvalues_odvalues.put("ownerIndex", "1");
                xmlvalues_odvalues.put("versionNumber", "1");
                xmlvalues_odvalues.put("volumnIndex", simgVolId1);

                OdValues_List.add(xmlvalues_odvalues);
            }

            SOAP_inxml = CommonMethod.wfInitiatewithDocumentXML(xmlvalues, OdValues_List, Sessionid, cabinet,
                    InitiateFromActivityId, InitiateFromActivityName, ProcessDefId, ProcessName);

            loggerCnsl.info(" SOAP_inxml after framing the Tags" + SOAP_inxml);
            loggerXml.info(" SOAP_inxml after framing the Tags" + SOAP_inxml);

            String SOAPResponse_xml = "";
            String action = "wfinitiate";
            //WebService Call
            NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
            SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, WorkitemEndPointurl, action);

            loggerCnsl.info("SOAPResponse_xml--->" + SOAPResponse_xml);

            loggerXml.info("outputXML : " + SOAPResponse_xml);

            if (!CommonMethod.isNullOrEmpty(SOAPResponse_xml)) {
                int startPosition = SOAPResponse_xml.indexOf("processInstanceId>");
                int startmainPosition = SOAPResponse_xml.indexOf("mainCode>");
                processinstanceid = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("processInstanceId>") + 18,
                        SOAPResponse_xml.indexOf("</", startPosition));
                maincode = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("mainCode>") + 9,
                        SOAPResponse_xml.indexOf("</", startmainPosition));
                loggerCnsl.info("processinstanceid" + processinstanceid);
                loggerCnsl.info("processinstanceid =====> " + processinstanceid);

                if (maincode.equalsIgnoreCase("0")) {
                    result = processinstanceid;
                    loggerCnsl.info("result =====> " + result);
                    Response = result;
                    loggerCnsl.info("WorkItem Initiated Successfully");
                } else {
                    result = "Pending";
                    Response = result;
                    loggerCnsl.info("Document added to SMS  and WorkItem Initiation Unsuccessful");
                }

            } else {
                result = "Pending";
                Response = result;
                loggerCnsl.info("Document added to SMS  and WorkItem Initiation Unsuccessful");
            }

        } catch (Exception e) {
            loggerErr.error("Exception occured :" + e.getMessage());
            e.printStackTrace();
            result = "Pending";
            Response = result;
        }

        long endTime = System.currentTimeMillis();
        long totaltime = endTime - starttime;
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("Response is --->:" + Response);
        loggerCnsl.info("Total Time Taken in initiating workitem is:" + totaltime);

        return Response;
    }

    public static String wfInitiatewithDocumentXML(HashMap xmlvalues, ArrayList OdValues_List, String Sessionid,
            String cabinet, String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId,
            String ProcessName) {
        String inputXML = "";
        StringBuilder sb = new StringBuilder();

        ArrayList<HashMap<String, String>> OD_values_xml = new ArrayList<HashMap<String, String>>();
        OD_values_xml.addAll(OdValues_List);
        try {
            loggerCnsl.info("wfinitiatexml method starts...");

            sb.append(
                    "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:app=\"http://app.omni.newgen.com\" xmlns:xsd=\"http://data.omni.newgen.com/xsd\">");
            sb.append("<soapenv:Header/>");
            sb.append("<soapenv:Body>");
            sb.append("<app:wfInitiate>");
            sb.append("<app:request>");
            // sb.append("<xsd:attributes><xsd:name>Invoiceno</xsd:name><xsd:value>12345</xsd:value></xsd:attributes>");

            Iterator iter = xmlvalues.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry valuepair = (Map.Entry) iter.next();
                String a = valuepair.getKey().toString();

                sb.append("<xsd:attributes><xsd:name>" + a + "</xsd:name><xsd:value>");
                sb.append(valuepair.getValue() == null ? "" : valuepair.getValue() + "</xsd:value></xsd:attributes>");
            }

            sb.append("<xsd:documentList>");
            loggerCnsl.info("OD_values_xml -- > " + OD_values_xml.size());

            for (int i = 0; i < OdValues_List.size(); i++) // to include support
            // document
            {
                if (i == 1) {
                    sb.append("</xsd:documentList><xsd:documentList>");
                }
                HashMap<String, String> xmlvalues_odvalues = (HashMap<String, String>) OdValues_List.get(i);
                Iterator it = xmlvalues_odvalues.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry valuepair = (Map.Entry) it.next();
                    String a = valuepair.getKey().toString(); // hashmap value
                    // pair
                    String a_value = OD_values_xml.get(i).get(a).toString(); // value
                    // pair
                    // value
                    sb.append("<xsd:" + a + ">");
                    // sb.append(valuepair.getValue() == null ? "" : valuepair
                    // .getValue());
                    sb.append(a_value == null ? "" : a_value);
                    sb.append("</xsd:" + a + ">");

                }
            }
            sb.append("</xsd:documentList>");
            sb.append("<xsd:engineName>" + cabinet + "</xsd:engineName>");
            sb.append("<xsd:initiateFromActivityId>" + InitiateFromActivityId + "</xsd:initiateFromActivityId>");
            sb.append("<xsd:initiateFromActivityName>" + InitiateFromActivityName + "</xsd:initiateFromActivityName>");
            sb.append("<xsd:processDefId>" + ProcessDefId + "</xsd:processDefId>");
            sb.append("<xsd:processName>" + ProcessName + "</xsd:processName>");
            sb.append("<xsd:sessionId>" + Sessionid + "</xsd:sessionId>");
            sb.append("</app:request>");
            sb.append("</app:wfInitiate>");
            sb.append("</soapenv:Body>");
            sb.append("</soapenv:Envelope>");
            inputXML = sb.toString();
            loggerXml.info("inputXML : " + inputXML);
        } catch (Exception e) {
            loggerErr.info("Exception in wfinitiatexml:" + e.getMessage());
            e.printStackTrace();
        } finally {
            if (OD_values_xml != null) {
                OD_values_xml = null;
            }
            sb.setLength(0);
        }

        return inputXML;
    }

    public static boolean isNullOrEmpty(Object object) {
        if (object != null && !object.toString().trim().equalsIgnoreCase("")
                && !object.toString().trim().equalsIgnoreCase("null")) {
            return false;
        }
        return true;
    }

    public String initiateworkitem(HelpDeskPortalFields objHPF, String WorkitemEndPointurl,
            String Sessionid, String cabinet,
            String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId, String ProcessName) {
        long starttime = System.currentTimeMillis();
        loggerCnsl.info("initiateworkitem Method Starts...");

        String SOAP_inxml = "";
        String sessionid = "";
        String option = "";
        String result = "";
        String folderindex = "";
        String processinstanceid = "";
        String maincode = "";
        HashMap<String, String> xmlvalues = null;
        ArrayList<String> outptXMLlst = null;
        SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        String str_dateFrom = "";
        String str_dateTo = "";

        try {

            xmlvalues = new HashMap<String, String>();
            xmlvalues.put("EmployeeNumber", objHPF.getEmployeeNumber().trim());
            xmlvalues.put("EmployeeName", objHPF.getEmployeeName());
            xmlvalues.put("InitiationBy", objHPF.getInitBy());
            xmlvalues.put("CorporateFunction", objHPF.getCorporateFunction());
            xmlvalues.put("HRFunction", objHPF.getHRFunction());
            xmlvalues.put("InitiationStatus", "HP");
            xmlvalues.put("Gender", objHPF.getGender());
            xmlvalues.put("EmailID", objHPF.getEmailID());
            xmlvalues.put("WorkLocation", objHPF.getWorkLocation());
            xmlvalues.put("TicketFunction", objHPF.getTicketFunction());
            xmlvalues.put("TicketCategory", objHPF.getTicketCategory());
            xmlvalues.put("TicketSubCategory", objHPF.getTicketSubCategory());
            xmlvalues.put("TicketAssigningUser", objHPF.getTicketAssigningUser());
            xmlvalues.put("TicketSubject", objHPF.getTicketSubject());
            xmlvalues.put("TicketPriority", objHPF.getTicketPriority());
            xmlvalues.put("TicketContactNumber", objHPF.getTicketContactNumber());
            xmlvalues.put("TicketMessage", objHPF.getTicketMessage());

            xmlvalues.put("Region", objHPF.getRegion());
            xmlvalues.put("VendorCode", objHPF.getVendorCode());
            xmlvalues.put("VendorGL", objHPF.getVendorGL());
            xmlvalues.put("Designation", objHPF.getDesignation());
            xmlvalues.put("Department", objHPF.getDepartment());
            xmlvalues.put("Grade", objHPF.getGrade());
            xmlvalues.put("Category", objHPF.getCategory());
            xmlvalues.put("TicketAssigningUserFullName", objHPF.getTicketAssigningUserFullName());

            SOAP_inxml = CommonMethod.wfInitiatewithOutDocumentXML(xmlvalues, Sessionid, cabinet,
                    InitiateFromActivityId, InitiateFromActivityName, ProcessDefId, ProcessName);

            // Webservice call
            String SOAPResponse_xml = "";
            NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
            loggerCnsl.info("WorkItemEndPointURL in code:" + WorkitemEndPointurl);
            String action = "wfinitiate";
            SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, WorkitemEndPointurl, action);

            loggerXml.debug("outputXML : " + SOAPResponse_xml);
            if (!CommonMethod.isNullOrEmpty(SOAPResponse_xml)) {
                int startPosition = SOAPResponse_xml.indexOf("processInstanceId>");
                int startmainPosition = SOAPResponse_xml.indexOf("mainCode>");

                processinstanceid = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("processInstanceId>") + 18,
                        SOAPResponse_xml.indexOf("</", startPosition));

                maincode = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("mainCode>") + 9,
                        SOAPResponse_xml.indexOf("</", startmainPosition));
                loggerCnsl.info("processinstanceid" + processinstanceid);

                if (maincode.equalsIgnoreCase("0")) {
                    result = processinstanceid;
                    loggerCnsl.info("WorkItem Initiated Successfully");

                } else {
                    result = "Pending";
                }
            } else {
                result = "Pending";
            }

        } catch (Exception e) {
            loggerErr.error("Exception occured :" + e.getMessage());
            e.printStackTrace();
            result = "Pending";
        }
        long endTime = System.currentTimeMillis();
        long totaltime = endTime - starttime;
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("Total Time Taken in initiating workitem is:" + totaltime);

        return result;
    }

    public String initiateLRworkitem(LRFields objHPF, String WorkitemEndPointurl,
            String Sessionid, String cabinet,
            String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId, String ProcessName) {
        long starttime = System.currentTimeMillis();
        loggerCnsl.info("initiateworkitem Method Starts...");

        String SOAP_inxml = "";
        String sessionid = "";
        String option = "";
        String result = "";
        String folderindex = "";
        String processinstanceid = "";
        String maincode = "";
        HashMap<String, String> xmlvalues = null;
        ArrayList<String> outptXMLlst = null;
        SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        String str_dateFrom = "";
        String str_dateTo = "";

        try {

            xmlvalues = new HashMap<String, String>();
            xmlvalues.put("DateOfRequest", objHPF.getStrdateofrequest().trim());
            xmlvalues.put("ReqEmployeeCode", objHPF.getReqEmployeeNumber().trim());
            xmlvalues.put("ReqEmployeeName", objHPF.getReqEmployeeName().trim());
            xmlvalues.put("ReqEmailID", objHPF.getReqEmailID().trim());
            xmlvalues.put("ReqWorkLocation", objHPF.getReqWorkLocation().trim());
            xmlvalues.put("EmpNumber", objHPF.getEmployeeNumber().trim());
            xmlvalues.put("EmpName", objHPF.getEmployeeName());
            xmlvalues.put("EmpEmailID", objHPF.getEmailID());
            xmlvalues.put("EmpWorkLocation", objHPF.getWorkLocation());
            xmlvalues.put("EmpDOJ", objHPF.getDateOfJoining());
            xmlvalues.put("EmpPO", objHPF.getPOrg());
            xmlvalues.put("EmpPA", objHPF.getPA());
            xmlvalues.put("EmpPSA", objHPF.getPSA());
            xmlvalues.put("EmpContactNo", objHPF.getContactNumber());
            xmlvalues.put("EmpGrade", objHPF.getEmpGrade());
            xmlvalues.put("EmpDesignation", objHPF.getEmpDesignation());
            xmlvalues.put("EmpCorporateFunc", objHPF.getCorporateFunction());
            xmlvalues.put("EmpHRFunc", objHPF.getHRFunction());
            xmlvalues.put("EmpRegion", objHPF.getRegion());
            xmlvalues.put("EmpVendorCode", objHPF.getVendorCode());
            xmlvalues.put("EmpGL", objHPF.getVendorGL());
            xmlvalues.put("EmpDepartment", objHPF.getDepartment());
            xmlvalues.put("EmpRM", objHPF.getRepManager());
            xmlvalues.put("EmpHRBP", objHPF.getHiddenHRBP());
            xmlvalues.put("EmpHRBPFullName", objHPF.getHRBPName());
            xmlvalues.put("EmpHRBPEmpCode", objHPF.getHiddenHRBPEmployeeCode());
            xmlvalues.put("ComplaintRaisedBy", objHPF.getHiddenHRBP());
            xmlvalues.put("ComplaintRaisedOn", objHPF.getComplaintraisedon());
            xmlvalues.put("ComplaintAbout", objHPF.getComplaintAbout());
            xmlvalues.put("ComplaintAction", "Register");
            xmlvalues.put("ComplaintOthersFreeText", objHPF.getComplaintAboutOthers());
            xmlvalues.put("ReferenceComment", objHPF.getReferenceComments());
            xmlvalues.put("DetailsOfTheComplaint", objHPF.getDetailsOfComplaint());
            xmlvalues.put("comments", objHPF.getComments());
            xmlvalues.put("isBritEmployee", objHPF.getIsBritEmployee());
            if (objHPF.getIsBritEmployee().equalsIgnoreCase("Yes")) {
                xmlvalues.put("comRepEmployeeNumber", objHPF.getComRepEmployeeNumber());
                xmlvalues.put("comRepEmployeeName", objHPF.getComRepEmployeeName());
                xmlvalues.put("comRepEmailID", objHPF.getComRepEmailID());
                xmlvalues.put("comRepWorkLocation", objHPF.getComRepWorkLocation());
            } else if (objHPF.getIsBritEmployee().equalsIgnoreCase("No")) {
                xmlvalues.put("comRepNonEmployeeNumber", objHPF.getComRepNonEmployeeNumber());
                xmlvalues.put("comRepNonEmployeeName", objHPF.getComRepNonEmployeeName());
            }
            xmlvalues.put("LR_Initiation_By", objHPF.getStrEmployeeUID());

            SOAP_inxml = CommonMethod.wfInitiatewithOutDocumentXML(xmlvalues, Sessionid, cabinet,
                    InitiateFromActivityId, InitiateFromActivityName, ProcessDefId, ProcessName);

            // Webservice call
            String SOAPResponse_xml = "";
            NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
            loggerCnsl.info("WorkItemEndPointURL in code:" + WorkitemEndPointurl);
            String action = "wfinitiate";
            SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, WorkitemEndPointurl, action);

            loggerXml.debug("outputXML : " + SOAPResponse_xml);
            if (!CommonMethod.isNullOrEmpty(SOAPResponse_xml)) {
                int startPosition = SOAPResponse_xml.indexOf("processInstanceId>");
                int startmainPosition = SOAPResponse_xml.indexOf("mainCode>");

                processinstanceid = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("processInstanceId>") + 18,
                        SOAPResponse_xml.indexOf("</", startPosition));

                maincode = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("mainCode>") + 9,
                        SOAPResponse_xml.indexOf("</", startmainPosition));
                loggerCnsl.info("processinstanceid" + processinstanceid);

                if (maincode.equalsIgnoreCase("0")) {
                    result = processinstanceid;
                    loggerCnsl.info("WorkItem Initiated Successfully");

                } else {
                    result = "Pending";
                }
            } else {
                result = "Pending";
            }

        } catch (Exception e) {
            loggerErr.error("Exception occured :" + e.getMessage());
            e.printStackTrace();
            result = "Pending";
        }
        long endTime = System.currentTimeMillis();
        long totaltime = endTime - starttime;
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("Total Time Taken in initiating workitem is:" + totaltime);

        return result;
    }

    public String initiateGuestHouseWorkitem(GHBFields objHPF, String WorkitemEndPointurl,
            String Sessionid, String cabinet,
            String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId, String ProcessName) {
        long starttime = System.currentTimeMillis();
        loggerCnsl.info("initiateworkitem Method Starts...");

        String SOAP_inxml = "";
        String sessionid = "";
        String option = "";
        String result = "";
        String folderindex = "";
        String processinstanceid = "";
        String maincode = "";
        HashMap<String, String> xmlvalues = null;
        ArrayList<String> outptXMLlst = null;
        SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        String str_dateFrom = "";
        String str_dateTo = "";

        try {

            xmlvalues = new HashMap<String, String>();
            xmlvalues.put("EmployeeCode", objHPF.getEmployeeCode().trim());
            xmlvalues.put("EmployeeFullName", objHPF.getEmployeeName().trim());
            xmlvalues.put("EmployeeName", objHPF.getStrEmployeeUID().trim());
            xmlvalues.put("EmpEmailID", objHPF.getEmpEmailID().trim());
            xmlvalues.put("EmpContactNumber", objHPF.getEmpContactNumber());
            xmlvalues.put("RequestType", objHPF.getRequestType());
            xmlvalues.put("Region", objHPF.getRegion());
            xmlvalues.put("VendorCode", objHPF.getVendorCode());
            xmlvalues.put("VendorGL", objHPF.getVendorGL());
            xmlvalues.put("Designation", objHPF.getDesignation());
            xmlvalues.put("Department", objHPF.getDepartment());
            xmlvalues.put("Grade", objHPF.getGrade());
            xmlvalues.put("EmpCostCenter", objHPF.getCostCenter());
            if (!objHPF.getBookingBookingForOtherTxt().equalsIgnoreCase("")) {
                xmlvalues.put("BookingForOthers", objHPF.getBookingBookingForOtherTxt());
            }
            xmlvalues.put("EmpRM", objHPF.getEmpRMUserID());
            xmlvalues.put("EmpHRBP", objHPF.getEmpHRBPUserID());
            xmlvalues.put("FromDate", objHPF.getFromDate());
            xmlvalues.put("ToDate", objHPF.getToDate());
            xmlvalues.put("NoOfNights", objHPF.getNoOfNights());
            xmlvalues.put("NoOfPersons", objHPF.getNoOfPersons());
            xmlvalues.put("GuestHouseLocation", objHPF.getGuestHouseLocation());
            xmlvalues.put("cb_checkin_hh", objHPF.getCb_checkin_hh());
            xmlvalues.put("cb_checkin_mm", objHPF.getCb_checkin_mm());
            xmlvalues.put("cb_checkout_hh", objHPF.getCb_checkout_hh());
            xmlvalues.put("cb_checkout_mm", objHPF.getCb_checkout_mm());
            xmlvalues.put("IsCabRequired", objHPF.getIsCabReq());
            xmlvalues.put("IsGHAvailable", objHPF.getIsGHAvailable());
            if (!objHPF.getComments().equalsIgnoreCase("")) {
                xmlvalues.put("Comments", objHPF.getComments());
            }
            xmlvalues.put("InitiationBy", objHPF.getStrEmployeeUID());

            SOAP_inxml = CommonMethod.wfInitiatewithOutDocumentXML(xmlvalues, Sessionid, cabinet,
                    InitiateFromActivityId, InitiateFromActivityName, ProcessDefId, ProcessName);
            loggerCnsl.info("SOAP_inxml in code:" + SOAP_inxml);
            // Webservice call
            String SOAPResponse_xml = "";
            NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
            loggerCnsl.info("WorkItemEndPointURL in code:" + WorkitemEndPointurl);
            String action = "wfinitiate";
            SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, WorkitemEndPointurl, action);

            loggerXml.debug("outputXML : " + SOAPResponse_xml);
            if (!CommonMethod.isNullOrEmpty(SOAPResponse_xml)) {
                int startPosition = SOAPResponse_xml.indexOf("processInstanceId>");
                int startmainPosition = SOAPResponse_xml.indexOf("mainCode>");

                processinstanceid = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("processInstanceId>") + 18,
                        SOAPResponse_xml.indexOf("</", startPosition));

                maincode = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("mainCode>") + 9,
                        SOAPResponse_xml.indexOf("</", startmainPosition));
                loggerCnsl.info("processinstanceid" + processinstanceid);

                if (maincode.equalsIgnoreCase("0")) {
                    result = processinstanceid;
                    loggerCnsl.info("WorkItem Initiated Successfully");

                } else {
                    result = "Pending";
                }
            } else {
                result = "Pending";
            }

        } catch (Exception e) {
            loggerErr.error("Exception occured :" + e.getMessage());
            e.printStackTrace();
            result = "Pending";
        }
        long endTime = System.currentTimeMillis();
        long totaltime = endTime - starttime;
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("Total Time Taken in initiating workitem is:" + totaltime);

        return result;
    }

    public static String wfInitiatewithOutDocumentXML(HashMap xmlvalues, String Sessionid,
            String cabinet, String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId,
            String ProcessName) {
        String inputXML = "";
        StringBuilder sb = new StringBuilder();

        try {
            loggerCnsl.info("wfinitiatexml method starts...");

            sb.append(
                    "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:app=\"http://app.omni.newgen.com\" xmlns:xsd=\"http://data.omni.newgen.com/xsd\">");
            sb.append("<soapenv:Header/>");
            sb.append("<soapenv:Body>");
            sb.append("<app:wfInitiate>");
            sb.append("<app:request>");
            // sb.append("<xsd:attributes><xsd:name>Invoiceno</xsd:name><xsd:value>12345</xsd:value></xsd:attributes>");

            Iterator iter = xmlvalues.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry valuepair = (Map.Entry) iter.next();
                String a = valuepair.getKey().toString();
                loggerCnsl.info(valuepair.getKey() + " ---> " + valuepair.getValue());
                sb.append("<xsd:attributes><xsd:name>" + a + "</xsd:name><xsd:value>");
                sb.append(valuepair.getValue() == null ? "" : valuepair.getValue() + "</xsd:value></xsd:attributes>");
            }
//Added by Sivashankar KS on 28 Dec 2018 for Initiate without document starts here
//            sb.append("<xsd:documentList>");
//            sb.append("<xsd:checkoutBy>0</xsd:checkoutBy>");
//            sb.append("<xsd:ownerIndex>1</xsd:ownerIndex>");
//            sb.append("<xsd:documentType>I</xsd:documentType>");
//            sb.append("<xsd:checkoutStatus>no</xsd:checkoutStatus>");
//            sb.append("<xsd:documentSize>1</xsd:documentSize>");
//            sb.append("<xsd:createdByAppName>pdf</xsd:createdByAppName>");
//            sb.append("<xsd:versionNumber>1</xsd:versionNumber>");
//            sb.append("<xsd:volumnIndex>1</xsd:volumnIndex>");
//            sb.append("<xsd:noOfPages>1</xsd:noOfPages>");
//            sb.append("<xsd:appType>pdf</xsd:appType>");
//            sb.append("<xsd:name> </xsd:name>");
//            sb.append("<xsd:comment>Workitem with Document</xsd:comment>");
//            sb.append("<xsd:documentIndex>0</xsd:documentIndex>");
//            sb.append("<xsd:imageIndex>0</xsd:imageIndex>");
//            sb.append("</xsd:documentList>");
//Added by Sivashankar KS on 28 Dec 2018 for Initiate without document ends here
            sb.append("<xsd:engineName>" + cabinet + "</xsd:engineName>");
            sb.append("<xsd:initiateFromActivityId>" + InitiateFromActivityId + "</xsd:initiateFromActivityId>");
            sb.append("<xsd:initiateFromActivityName>" + InitiateFromActivityName + "</xsd:initiateFromActivityName>");
            sb.append("<xsd:processDefId>" + ProcessDefId + "</xsd:processDefId>");
            sb.append("<xsd:processName>" + ProcessName + "</xsd:processName>");
            sb.append("<xsd:sessionId>" + Sessionid + "</xsd:sessionId>");
            sb.append("</app:request>");
            sb.append("</app:wfInitiate>");
            sb.append("</soapenv:Body>");
            sb.append("</soapenv:Envelope>");
            inputXML = sb.toString();
            loggerXml.info("inputXML : " + inputXML);
        } catch (Exception e) {
            loggerErr.info("Exception in wfinitiatexml:" + e.getMessage());
            e.printStackTrace();
        } finally {
            sb.setLength(0);
        }

        return inputXML;
    }

    public String getUserList(String loggedInUser, String sessionId, String searchString, String minValue, String maxValue,
            String maxCount) {
        loggerCnsl.info("In inside getUserList method in CommonMethod ");
        String userQuery;
        String countQuery;
        CommonMethod commonMethod = new CommonMethod();
        ArrayList<ArrayList<String>> userCount;
        String suserCount = "";
        ArrayList<String> User_add = new ArrayList();
        String suserList = "";
        String userValues;
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse xmlResponse = null;
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse xmlResponse1 = null;
        WFXmlList wfxmllist = null;
        WFXmlList wfxmllist1 = null;
        String sCount = "";
        String strEmployee_ID = "";
        String strEmployee_Name = "";
        String strEmail_ID = "";
        String strWork_Location = "";

        String returnValue = "";
        try {
            if (searchString == null || searchString.equals("")) {
//                userQuery = "SELECT DISTINCT Employee_ID,Employee_Name,Email_ID,Work_Location FROM (SELECT  ROW_NUMBER() OVER( ORDER BY m.Employee_ID ) AS 'rownumber', m.Employee_ID,m.Employee_Name,m.Email_ID,m.Work_Location FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI m WITH (NOLOCK)  WHERE m.USERID='" + loggedInUser + "')tbl where tbl.rownumber >" + minValue + " and tbl.rownumber<=" + maxValue + "";
//                userQuery = "SELECT m.Employee_ID,m.Employee_Name,m.Email_ID,m.Work_Location FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI m WITH (NOLOCK)  WHERE m.USERID='" + loggedInUser + "'";
//                countQuery = "SELECT count(DISTINCT Employee_ID) FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI m WITH (NOLOCK) WHERE m.USERID='" + loggedInUser + "'";
                userQuery = "SELECT m.Employee_ID,m.Employee_Name,m.Email_ID,m.Work_Location FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI m WITH (NOLOCK)";
                countQuery = "SELECT count(DISTINCT Employee_ID) FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI m WITH (NOLOCK)";
            } else {
//                userQuery = "SELECT DISTINCT Employee_ID,Employee_Name,Email_ID,Work_Location FROM (SELECT  ROW_NUMBER() OVER( ORDER BY m.Employee_ID ) AS 'rownumber', m.Employee_ID,m.Employee_Name,m.Email_ID,m.Work_Location FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI m WITH (NOLOCK)  WHERE m.USERID='" + loggedInUser + "' AND (m.Employee_ID like '%" + searchString + "%' OR m.Employee_Name like '%" + searchString + "%' OR m.Email_ID like '%" + searchString + "%' OR m.Work_Location like '%" + searchString + "%'))tbl where tbl.rownumber >" + minValue + " and tbl.rownumber<=" + maxValue + "";
                userQuery = "SELECT m.Employee_ID,m.Employee_Name,m.Email_ID,m.Work_Location FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI m WITH (NOLOCK)  WHERE (m.Employee_ID like '%" + searchString + "%' OR m.Employee_Name like '%" + searchString + "%' OR m.Email_ID like '%" + searchString + "%' OR m.Work_Location like '%" + searchString + "%')";
                countQuery = "SELECT count(DISTINCT Employee_ID) FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI m WITH (NOLOCK) WHERE (m.Employee_ID like '%" + searchString + "%' OR m.Employee_Name like '%" + searchString + "%' OR m.Email_ID like '%" + searchString + "%' OR m.Work_Location like '%" + searchString + "%')";
            }
            loggerCnsl.info("Get User Query: " + userQuery);
            loggerCnsl.info("Count Query: " + countQuery);

            if (maxCount != null && maxCount.equals("0")) {
                try {
                    suserCount = commonMethod.getAPSelect(countQuery, 1, sessionId);
                    XMLParser parsergetlist = new XMLParser(suserCount);
                    xmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(suserCount);
                    if (parsergetlist.getValueOf("MainCode").equals("0")) {
                        loggerCnsl.info("########Inside mainCode 0 for Count #############");
                        wfxmllist = xmlResponse.createList("DataList", "Data");
                        wfxmllist.reInitialize(true);
                        sCount = wfxmllist.getVal("Value1").trim();

//                        wfxmllist = xmlResponse.createList("Records", "Record");
//                        wfxmllist.reInitialize(true);
//                        sCount = wfxmllist.getVal("usercount").trim();
                    } else {
                        loggerCnsl.info("########outside mainCode 0 for Count #############");
                        loggerCnsl.info("########Not Updated#############");

                    }
                    loggerCnsl.info("Count Query resutl:" + sCount);
                } catch (Exception e) {
                    loggerErr.info("Exception in getUserList ApSelect for count :: " + e);
                }
                if (sCount != null) {
                    returnValue = sCount + "&#";
                }

            } else {
                returnValue = maxCount + "&#";
            }

            try {

//                
//                strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
//            strBuff1.setLength(0);
//            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
//            parsergetlist = new XMLParser(strCompOutputXml);
//            if (parsergetlist.getValueOf("MainCode").equals("0")) {
//                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
//                wfxmllist = wfXmlResponse.createList("DataList", "Data");
//                wfxmllist.reInitialize(true);
//                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfSubCategory = wfxmllist.getVal("Value1").trim();
//                    strAssigningUser = wfxmllist.getVal("Value2").trim();
//                    strAssigningUserFullName = wfxmllist.getVal("Value3").trim();
//                    //String tCode = wfxmllist.getVal("TaxCode");
//                    typeOfCategory.add(strTypeOfSubCategory + "$#!" + strAssigningUser + "$#!" + strAssigningUserFullName);
//                    wfxmllist.skip(true);
//                }
//                loggerCnsl.info("strTypeOfSubCategory == " + strTypeOfSubCategory);
//                loggerCnsl.info("strAssigningUser == " + strAssigningUser);
//                loggerCnsl.info("strAssigningUserFullName == " + strAssigningUserFullName);
//            }
                suserList = commonMethod.getAPSelect(userQuery, 4, sessionId);

                XMLParser parsergetlist1 = new XMLParser(suserList);
                xmlResponse1 = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(suserList);

                if (parsergetlist1.getValueOf("MainCode").equals("0")) {
                    wfxmllist1 = xmlResponse1.createList("DataList", "Data");
                    wfxmllist1.reInitialize(true);
                    strEmployee_ID = wfxmllist1.getVal("Employee_ID").trim();
                    while (wfxmllist1.hasMoreElements()) {
                        strEmployee_ID = wfxmllist1.getVal("Value1").trim().replaceAll("&amp;", "and");
                        strEmployee_Name = wfxmllist1.getVal("Value2").trim().replaceAll("&amp;", "and");
                        strEmail_ID = wfxmllist1.getVal("Value3").trim().replaceAll("&amp;", "and");
                        strWork_Location = wfxmllist1.getVal("Value4").trim().replaceAll("&amp;", "and");
                        User_add.add(strEmployee_ID + "$#!" + strEmployee_Name + "$#!" + strEmail_ID + "$#!" + strWork_Location);
                        wfxmllist1.skip(true);
                    }

//                    wfxmllist1 = xmlResponse1.createList("Records", "Record");
//                    wfxmllist1.reInitialize(true);
//                    sUsername = wfxmllist1.getVal("Employee_ID").trim();
//                    System.out.println("########Employee_ID#############" + sUsername);
//                    
//                    for (; wfxmllist1.hasMoreElements(true); wfxmllist1.skip(true)) {
//                        loggerCnsl.info("****Inside For Loop****\n");
//                        sUsername = wfxmllist1.getVal("Employee_ID");
//                        sUsername = wfxmllist1.getVal("Employee_Name");
//                        sUsername = wfxmllist1.getVal("Email_ID");
//                        sUsername = wfxmllist1.getVal("Work_Location");
//                        User_add.add(sUsername);
//                        loggerCnsl.info("User_add" + User_add);
//                    }
                } else {
                    loggerCnsl.info("########outside mainCode 0#############");
                    loggerCnsl.info("########Not Updated#############");

                }

                loggerCnsl.info("query ==> " + userQuery + " :dataList ===> " + suserList);
                loggerCnsl.info("Get User Query result: " + suserList);
            } catch (Exception ex) {
                loggerErr.info("Exception in getUserList ApSelect for username :: " + ex);
                ex.printStackTrace();
            }
            if (!User_add.isEmpty()) {

                userValues = User_add.toString().replaceAll("\\[", "");
                userValues = userValues.replaceAll("\\]", "");

                loggerCnsl.info("*************** userValues" + userValues);
                returnValue = returnValue + userValues;
                loggerCnsl.info("Get User Return value: " + returnValue);
                return returnValue;
            } else {
                return "No Users Found";
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public String getAPSelect(String strQuery, int noofCols, String sessionId) {
        loggerCnsl.info("In inside getAPSelect method in CommonMethod ");
        com.newgen.omni.wf.util.xml.XMLParser parsergetlist = null;
        String strOutputXmlFI = null;
        StringBuilder strBuffFI = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponseFI = null;
        WFXmlList wfxmllistFI = null;
        String FIDocNo = "";
//        strBuffFI = strBuffFI.append("<?xmlversion=\"1.0\"?>");
//        strBuffFI = strBuffFI.append("<APSelectWithColumnNames>");
//        strBuffFI = strBuffFI.append("<Option>APSelectWithColumnNames</Option>");
//        strBuffFI = strBuffFI.append("<EngineName>").append("britbpm").append("</EngineName>");
//        strBuffFI = strBuffFI.append("<SessionId>").append(sessionId).append("</SessionId>");
//        strBuffFI = strBuffFI.append("<QueryString>").append(strQuery).append("</QueryString>");
//        strBuffFI = strBuffFI.append("<NoOfCols>").append(noofCols).append("</NoOfCols>");
//        strBuffFI = strBuffFI.append("</APSelectWithColumnNames>");                        
        strBuffFI = strBuffFI.append("<?xml version=\"1.0\"?>");
        strBuffFI = strBuffFI.append("<WFCustomBean_Input><Option>NGGetData</Option>");
        strBuffFI = strBuffFI.append("<QryOption>NGGetData</QryOption>");
        strBuffFI = strBuffFI.append("<EngineName>").append("britbpm").append("</EngineName>");
        strBuffFI = strBuffFI.append("<SessionId>").append(sessionId).append("</SessionId>");
        strBuffFI = strBuffFI.append("<QueryString>").append(strQuery).append("</QueryString>");
        strBuffFI = strBuffFI.append("<ColumnNo>").append(noofCols).append("</ColumnNo>");
        strBuffFI = strBuffFI.append("</WFCustomBean_Input>");

        loggerXml.info("Input strBuffFI for getAPSelect :: " + strBuffFI);
        try {
            strOutputXmlFI = WFCallBroker.execute(strBuffFI.toString(), "172.16.8.81", Integer.parseInt("3333"), 0);//for UAT
//            strOutputXmlFI = WFCallBroker.execute(strBuffFI.toString(), "172.16.8.97", Integer.parseInt("3333"), 0);// for PRODUCTION
//            strOutputXmlFI = WFCallBroker.execute(strBuffFI.toString(), "127.0.0.1", Integer.parseInt("3333"), 0);// for PRODUCTION
            loggerXml.info("Output strCompOutputXml for getAPSelect :: " + strOutputXmlFI);
        } catch (Exception e) {
            loggerErr.info("[Error]Error in executing APSelect " + e);
            e.printStackTrace();

        }
        return strOutputXmlFI;
    }

    public String getEmployeeDataList(String loggedInUser, String sessionId, String reqEmployeeNumber) {
        loggerCnsl.info("In inside getEmployeeDataList method in CommonMethod ");
        String userQuery = "";
        String countQuery = "";
        CommonMethod commonMethod = new CommonMethod();
        ArrayList<ArrayList<String>> userCount;
        String suserCount = "";
        ArrayList<String> User_add = new ArrayList();
        String suserList = "";
        String userValues;
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse xmlResponse = null;
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse xmlResponse1 = null;
        WFXmlList wfxmllist = null;
        WFXmlList wfxmllist1 = null;
        String sCount = "";
        String strEmployee_ID = "", strEmployee_Name = "", strUserID = "", strDOJ = "", strEmail_ID = "", strPersonnel_Area = "", strPA_Code = "",
                strPA_Subarea_Code = "", strMobile_No = "", strEmp_Subgroup = "", strDesignation = "", strCorp_Func = "",
                strHR_Func_Code = "", strRegion = "", strWork_Location = "", strReporting_Mgr_Name = "", strHRBPFullName = "", strHRBP = "", strHRBP_Emp_ID = "", strVendorCode = "", strVendorGL = "", strDepartment = "";

        String returnValue = "";
        try {
            if (!reqEmployeeNumber.equalsIgnoreCase("")) {
                userQuery = "SELECT Employee_ID AS 'Employee Number',Employee_Name AS 'Employee Name',User_ID AS 'User ID',Convert(varchar,Date_of_Joining,103) AS 'Date Of Joining',Email_ID AS 'Email ID',CompanyCode AS 'Parent Organization',Personnel_Area AS 'PA',Personnel_Subarea AS 'PSA',Mobile_No AS 'Contact Number',Emp_Subgroup AS 'Employee Grade',Designation AS 'Employee Designation',Corp_Func AS 'Corporate Function',HR_Func AS 'HR Function',Region AS 'Region',Work_Location AS 'Work Location',Reporting_Mgr_Name AS 'Reporting Manager',ENAME AS 'HRBP Name',USERID,HRBP_Emp_ID,Vendor_Code,VEN_GLCODE,Org_Unit AS 'Department' FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WITH(NOLOCK) WHERE Employee_ID='" + reqEmployeeNumber + "'";
            }
            loggerCnsl.info("Get User Query: " + userQuery);

            try {

                suserList = commonMethod.getAPSelect(userQuery, 19, sessionId);

                XMLParser parsergetlist1 = new XMLParser(suserList);
                xmlResponse1 = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(suserList);

                if (parsergetlist1.getValueOf("MainCode").equals("0")) {
                    loggerCnsl.info("########Inside mainCode 0#############");
                    wfxmllist1 = xmlResponse1.createList("DataList", "Data");
                    wfxmllist1.reInitialize(true);
                    strEmployee_ID = wfxmllist1.getVal("Employee_ID").trim();
                    System.out.println("########Employee_ID#############" + strEmployee_ID);
                    while (wfxmllist1.hasMoreElements()) {
                        strEmployee_ID = wfxmllist1.getVal("Value1").trim().replaceAll("&amp;", "and");
                        strEmployee_Name = wfxmllist1.getVal("Value2").trim().replaceAll("&amp;", "and");
                        strUserID = wfxmllist1.getVal("Value3").trim().replaceAll("&amp;", "and");
                        strDOJ = wfxmllist1.getVal("Value4").trim().replaceAll("&amp;", "and");
                        strEmail_ID = wfxmllist1.getVal("Value5").trim().replaceAll("&amp;", "and");
                        strPersonnel_Area = wfxmllist1.getVal("Value6").trim().replaceAll("&amp;", "and");
                        strPA_Code = wfxmllist1.getVal("Value7").trim().replaceAll("&amp;", "and");
                        strPA_Subarea_Code = wfxmllist1.getVal("Value8").trim().replaceAll("&amp;", "and");
                        strMobile_No = wfxmllist1.getVal("Value9").trim().replaceAll("&amp;", "and");
                        strEmp_Subgroup = wfxmllist1.getVal("Value10").trim().replaceAll("&amp;", "and");
                        strDesignation = wfxmllist1.getVal("Value11").trim().replaceAll("&amp;", "and");
                        strCorp_Func = wfxmllist1.getVal("Value12").trim().replaceAll("&amp;", "and");
                        strHR_Func_Code = wfxmllist1.getVal("Value13").trim().replaceAll("&amp;", "and");
                        strRegion = wfxmllist1.getVal("Value14").trim().replaceAll("&amp;", "and");
                        strWork_Location = wfxmllist1.getVal("Value15").trim().replaceAll("&amp;", "and");
                        strReporting_Mgr_Name = wfxmllist1.getVal("Value16").trim().replaceAll("&amp;", "and");
                        strHRBPFullName = wfxmllist1.getVal("Value17").trim().replaceAll("&amp;", "and");
                        strHRBP = wfxmllist1.getVal("Value18").trim().replaceAll("&amp;", "and");
                        strHRBP_Emp_ID = wfxmllist1.getVal("Value19").trim().replaceAll("&amp;", "and");
                        strVendorCode = wfxmllist1.getVal("Value20").trim().replaceAll("&amp;", "and");
                        strVendorGL = wfxmllist1.getVal("Value21").trim().replaceAll("&amp;", "and");
                        strDepartment = wfxmllist1.getVal("Value22").trim().replaceAll("&amp;", "and");
                        //String tCode = wfxmllist.getVal("TaxCode");
                        User_add.add(strEmployee_ID + "$#!" + strEmployee_Name + "$#!" + strUserID + "$#!" + strDOJ + "$#!" + strEmail_ID
                                + "$#!" + strPersonnel_Area + "$#!" + strPA_Code + "$#!" + strPA_Subarea_Code + "$#!" + strMobile_No
                                + "$#!" + strEmp_Subgroup + "$#!" + strDesignation + "$#!" + strCorp_Func + "$#!" + strHR_Func_Code + "$#!"
                                + strRegion + "$#!" + strWork_Location + "$#!" + strReporting_Mgr_Name + "$#!" + strHRBPFullName + "$#!"
                                + strHRBP + "$#!" + strHRBP_Emp_ID + "$#!" + strVendorCode + "$#!" + strVendorGL + "$#!" + strDepartment);
                        loggerCnsl.info("User_add" + User_add);
                        wfxmllist1.skip(true);
                    }
                } else {
                    loggerCnsl.info("########outside mainCode 0#############");
                    loggerCnsl.info("########Not Updated#############");

                }

                loggerCnsl.info("query ==> " + userQuery + " :dataList ===> " + suserList);
                loggerCnsl.info("Get User Query result: " + suserList);
            } catch (Exception ex) {
                loggerErr.info("Exception in getUserList ApSelect for username :: " + ex);
                ex.printStackTrace();
            }
            if (!User_add.isEmpty()) {

                userValues = User_add.toString().replaceAll("\\[", "");
                userValues = userValues.replaceAll("\\]", "");

                loggerCnsl.info("*************** userValues" + userValues);
                returnValue = returnValue + userValues;
                loggerCnsl.info("Get User Return value: " + returnValue);
                return returnValue;
            } else {
                return "No Users Found";
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    private static SimpleDateFormat inSDF = new SimpleDateFormat("mm/dd/yyyy");
    private static SimpleDateFormat outSDF = new SimpleDateFormat("yyyy-dd-mm");

    public static String formatDate(String inDate) {
        String outDate = "";
        if (inDate != null) {
            try {
                java.util.Date date = inSDF.parse(inDate);
                outDate = outSDF.format(date);
            } catch (ParseException ex) {
            }
        }
        return outDate;
    }
    public static String reverseFormatDate(String inDate) {
        String outDate = "";
        if (inDate != null) {
            try {
                java.util.Date date = outSDF.parse(inDate);
                outDate = inSDF.format(date);
            } catch (ParseException ex) {
            }
        }
        return outDate;
    }

    public static boolean executeUpdateQry(String sQuery, final String strSessionId) {
        loggerCnsl.info("********************Inside executeUpdateQry()********************");
        loggerCnsl.info(" sInputVals ********************" + sQuery);

        // writeToLog(2," CabinetName ::: " + CabinetName + " strSessionId ::" + strSessionId + "   strJbossIp ::: " + strJbossIp);
        final String strCabinateName = "britbpm";
        final String strJbossIp = "172.16.8.81";//for UAT
//        final String strJbossIp = "172.16.8.97";//for PRODUCTION
//        final String strJbossIp = "127.0.0.1";//for PRODUCTION

//        String strInputXml = "";
        StringBuilder strInputXml = new StringBuilder();
        String strOutputXml = "";
        WFXmlResponse xmlResponse = null;
        String sMainCode3 = null;

        try {
            strInputXml = strInputXml.append("<?xml version=\"1.0\"?>");
            strInputXml = strInputXml.append("<WFCustomBean_Input><Option>NGSetData</Option>");
            strInputXml = strInputXml.append("<QryOption>NGSetData</QryOption>");
            strInputXml = strInputXml.append("<EngineName>").append("britbpm").append("</EngineName>");
            strInputXml = strInputXml.append("<SessionId>").append(strSessionId).append("</SessionId>");
            strInputXml = strInputXml.append("<Query>").append(sQuery).append("</Query>");
            strInputXml = strInputXml.append("</WFCustomBean_Input>");

            loggerCnsl.info("executeUpdateQry inputXML :: " + strInputXml);
            strOutputXml = WFCallBroker.execute(strInputXml.toString(), strJbossIp, Integer.parseInt("3333"), 0);
            loggerCnsl.info("executeUpdateQry outputXML :: " + strOutputXml);
            xmlResponse = new WFXmlResponse(strOutputXml);
            sMainCode3 = xmlResponse.getVal("MainCode");

            if (sMainCode3.equals("0")) {

                loggerCnsl.info("sMainCode3  ::: " + sMainCode3);
                loggerCnsl.info("********************End of executeUpdateQry()********************");
                return true;
            } else {

                loggerErr.info("ERROR:: sMainCode3   :: " + sMainCode3);
                loggerErr.info("ERROR:: Error while executing EDD update query XML call... " + sQuery);
                return false;
            }

        } catch (Exception e) {
            loggerErr.info("ERROR ::: Exception occured in executeUpdateQry()... :::  " + e);
            loggerErr.info("ERROR ::: Exception occured in executeUpdateQry()...  strOutputXml ::: " + strOutputXml);
            loggerErr.info("ERROR ::: MainCode :::  " + xmlResponse.getVal("MainCode"));
            loggerErr.info("ERROR ::: Description :::  " + xmlResponse.getVal("Description"));
            loggerErr.info("ERROR ::: e :::  " + e);
            loggerErr.info("********************End of executeUpdateQry()********************");
            return false;
        } finally {
            xmlResponse = null;
            strOutputXml = null;
            strInputXml = null;
        }
    }

    public static boolean executeMailUpdateQry(String sQuery, final String strSessionId) {
        loggerCnsl.info("********************Inside executeUpdateQry()********************");
        loggerCnsl.info(" sInputVals ********************" + sQuery);

        // writeToLog(2," CabinetName ::: " + CabinetName + " strSessionId ::" + strSessionId + "   strJbossIp ::: " + strJbossIp);
        final String strCabinateName = "britbpm";
        final String strJbossIp = "172.16.8.81";//for UAT
//        final String strJbossIp = "172.16.8.97";//for PRODUCTION
//        final String strJbossIp = "127.0.0.1";//for PRODUCTION

//        String strInputXml = "";
        StringBuilder strInputXml = new StringBuilder();
        String strOutputXml = "";
        WFXmlResponse xmlResponse = null;
        String sMainCode3 = null;

        try {
            strInputXml = strInputXml.append("<?xml version=\"1.0\"?>");
            strInputXml = strInputXml.append("<WFCustomBean_Input><Option>NGSetData</Option>");
            strInputXml = strInputXml.append("<QryOption>NGSetData</QryOption>");
            strInputXml = strInputXml.append("<EngineName>").append("britbpm").append("</EngineName>");
            strInputXml = strInputXml.append("<SessionId>").append(strSessionId).append("</SessionId>");
            strInputXml = strInputXml.append("<Query><![CDATA[").append(sQuery).append("]]></Query>");
            strInputXml = strInputXml.append("</WFCustomBean_Input>");

            loggerCnsl.info("executeUpdateQry inputXML :: " + strInputXml);
            strOutputXml = WFCallBroker.execute(strInputXml.toString(), strJbossIp, Integer.parseInt("3333"), 0);
            loggerCnsl.info("executeUpdateQry outputXML :: " + strOutputXml);
            xmlResponse = new WFXmlResponse(strOutputXml);
            sMainCode3 = xmlResponse.getVal("MainCode");

            if (sMainCode3.equals("0")) {

                loggerCnsl.info("sMainCode3  ::: " + sMainCode3);
                loggerCnsl.info("********************End of executeUpdateQry()********************");
                return true;
            } else {

                loggerErr.info("ERROR:: sMainCode3   :: " + sMainCode3);
                loggerErr.info("ERROR:: Error while executing EDD update query XML call... " + sQuery);
                return false;
            }

        } catch (Exception e) {
            loggerErr.info("ERROR ::: Exception occured in executeUpdateQry()... :::  " + e);
            loggerErr.info("ERROR ::: Exception occured in executeUpdateQry()...  strOutputXml ::: " + strOutputXml);
            loggerErr.info("ERROR ::: MainCode :::  " + xmlResponse.getVal("MainCode"));
            loggerErr.info("ERROR ::: Description :::  " + xmlResponse.getVal("Description"));
            loggerErr.info("ERROR ::: e :::  " + e);
            loggerErr.info("********************End of executeUpdateQry()********************");
            return false;
        } finally {
            xmlResponse = null;
            strOutputXml = null;
            strInputXml = null;
        }
    }

    public static List<String> roomAvailabilityCheck(String ticketFunction, String sessionId, PropertyBean probBean) {
        loggerCnsl.info("Inside getTypeOfCategoryMethod==" + ticketFunction);
        String strInputXml;
        List<String> typeOfCategory = new ArrayList();
        typeOfCategory.add("Select a Category");
        String strQuery = "SELECT TypeOfCategory FROM EXT_HELPDESK_MASTER_TICKET_CATEGORY WITH(NOLOCK) WHERE TypeOfFunction='" + ticketFunction + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfCategory = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    strTypeOfCategory = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    typeOfCategory.add(strTypeOfCategory);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfCategory==" + strTypeOfCategory);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return typeOfCategory;
    }
    
    public String initiateCabRequestWorkitem(GHBFields objHPF, String WorkitemEndPointurl,
            String Sessionid, String cabinet,
            String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId, String ProcessName) {
        long starttime = System.currentTimeMillis();
        loggerCnsl.info("initiateCabRequestWorkitem Method Starts...");

        String SOAP_inxml = "";
        String sessionid = "";
        String option = "";
        String result = "";
        String folderindex = "";
        String processinstanceid = "";
        String maincode = "";
        HashMap<String, String> xmlvalues = null;
        ArrayList<String> outptXMLlst = null;
        SimpleDateFormat dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        String str_dateFrom = "";
        String str_dateTo = "";

        try {

            xmlvalues = new HashMap<String, String>();
            xmlvalues.put("EmployeeCode", objHPF.getEmployeeCode().trim());
            xmlvalues.put("EmployeeFullName", objHPF.getEmployeeName().trim());
            xmlvalues.put("EmployeeName", objHPF.getStrEmployeeUID().trim());
            xmlvalues.put("EmpEmailID", objHPF.getEmpEmailID().trim());
            xmlvalues.put("EmpContactNumber", objHPF.getEmpContactNumber());
            xmlvalues.put("Region", objHPF.getRegion());
            xmlvalues.put("VendorCode", objHPF.getVendorCode());
            xmlvalues.put("VendorGL", objHPF.getVendorGL());
            xmlvalues.put("Designation", objHPF.getDesignation());
            xmlvalues.put("Department", objHPF.getDepartment());
            xmlvalues.put("EmpWorkLocation", objHPF.getEmpWorkLocation());
            xmlvalues.put("Grade", objHPF.getGrade());
            xmlvalues.put("EmpCostCenter", objHPF.getCostCenter());
            if (!objHPF.getBookingBookingForOtherTxt().equalsIgnoreCase("")) {
                xmlvalues.put("BookingForOthers", objHPF.getBookingBookingForOtherTxt());
            }
            xmlvalues.put("EmpRM", objHPF.getEmpRMUserID());
            xmlvalues.put("EmpHRBP", objHPF.getEmpHRBPUserID());
            xmlvalues.put("InitiationBy", objHPF.getStrEmployeeUID());

            SOAP_inxml = CommonMethod.wfInitiatewithOutDocumentXML(xmlvalues, Sessionid, cabinet,
                    InitiateFromActivityId, InitiateFromActivityName, ProcessDefId, ProcessName);
            loggerCnsl.info("SOAP_inxml in code:" + SOAP_inxml);
            // Webservice call
            String SOAPResponse_xml = "";
            NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
            loggerCnsl.info("WorkItemEndPointURL in code:" + WorkitemEndPointurl);
            String action = "wfinitiate";
            SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, WorkitemEndPointurl, action);

            loggerXml.debug("outputXML : " + SOAPResponse_xml);
            if (!CommonMethod.isNullOrEmpty(SOAPResponse_xml)) {
                int startPosition = SOAPResponse_xml.indexOf("processInstanceId>");
                int startmainPosition = SOAPResponse_xml.indexOf("mainCode>");

                processinstanceid = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("processInstanceId>") + 18,
                        SOAPResponse_xml.indexOf("</", startPosition));

                maincode = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("mainCode>") + 9,
                        SOAPResponse_xml.indexOf("</", startmainPosition));
                loggerCnsl.info("processinstanceid" + processinstanceid);

                if (maincode.equalsIgnoreCase("0")) {
                    result = processinstanceid;
                    loggerCnsl.info("WorkItem Initiated Successfully");

                } else {
                    result = "Pending";
                }
            } else {
                result = "Pending";
            }

        } catch (Exception e) {
            loggerErr.error("Exception occured initiateCabRequestWorkitem :" + e.getMessage());
            e.printStackTrace();
            result = "Pending";
        }
        long endTime = System.currentTimeMillis();
        long totaltime = endTime - starttime;
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("result is --->:" + result);
        loggerCnsl.info("Total Time Taken in initiating workitem is:" + totaltime);

        return result;
    }
    
}
