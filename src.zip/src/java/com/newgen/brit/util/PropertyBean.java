package com.newgen.brit.util;

public class PropertyBean {

    public String cabinetName = "";
    public String password = "";
    public String userName = "";
    public String serverType = "";
    public String serverPort = "";
    public String protocol = "";
    public String serverIP = "";
    public String showLogOut = "";
    public String userDBId = "";
    public String userIndex = "";
    public String jtsPort = "";
    public String VolumeIndex = "";
    public String HelpDeskUserName = "";
    public String HelpDeskPassword = "";
    
    public String WorkitemEndPointurl = "";
    public String InitiateFromActivityId = "";
    public String InitiateFromActivityName = "";
    public String ProcessDefId = "";
    public String ProcessName = "";
    public String Cabinet = "";

    public String getUserDBId() {
        return userDBId;
    }

    public void setUserDBId(String userDBId) {
        this.userDBId = userDBId;
    }

    public String getUserIndex() {
        return userIndex;
    }

    public void setUserIndex(String userIndex) {
        this.userIndex = userIndex;
    }

    public String getCabinetName() {
        return cabinetName;
    }

    public void setCabinetName(String cabinetName) {
        this.cabinetName = cabinetName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getServerType() {
        return serverType;
    }

    public void setServerType(String serverType) {
        this.serverType = serverType;
    }

    public String getServerPort() {
        return serverPort;
    }

    public void setServerPort(String serverPort) {
        this.serverPort = serverPort;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getServerIP() {
        return serverIP;
    }

    public void setServerIP(String serverIP) {
        this.serverIP = serverIP;
    }

    public String getShowLogOut() {
        return showLogOut;
    }

    public void setShowLogOut(String showLogOut) {
        this.showLogOut = showLogOut;
    }

    public String getJtsPort() {
        return jtsPort;
    }

    public void setJtsPort(String jtsPort) {
        this.jtsPort = jtsPort;
    }

    public String getVolumeIndex() {
        return VolumeIndex;
    }

    public void setVolumeIndex(String VolumeIndex) {
        this.VolumeIndex = VolumeIndex;
    }

    public String getWorkitemEndPointurl() {
        return WorkitemEndPointurl;
    }

    public void setWorkitemEndPointurl(String WorkitemEndPointurl) {
        this.WorkitemEndPointurl = WorkitemEndPointurl;
    }

    public String getInitiateFromActivityId() {
        return InitiateFromActivityId;
    }

    public void setInitiateFromActivityId(String InitiateFromActivityId) {
        this.InitiateFromActivityId = InitiateFromActivityId;
    }

    public String getInitiateFromActivityName() {
        return InitiateFromActivityName;
    }

    public void setInitiateFromActivityName(String InitiateFromActivityName) {
        this.InitiateFromActivityName = InitiateFromActivityName;
    }

    public String getProcessDefId() {
        return ProcessDefId;
    }

    public void setProcessDefId(String ProcessDefId) {
        this.ProcessDefId = ProcessDefId;
    }

    public String getProcessName() {
        return ProcessName;
    }

    public void setProcessName(String ProcessName) {
        this.ProcessName = ProcessName;
    }

    public String getCabinet() {
        return Cabinet;
    }

    public void setCabinet(String Cabinet) {
        this.Cabinet = Cabinet;
    }

    public String getHelpDeskUserName() {
        return HelpDeskUserName;
    }

    public void setHelpDeskUserName(String HelpDeskUserName) {
        this.HelpDeskUserName = HelpDeskUserName;
    }

    public String getHelpDeskPassword() {
        return HelpDeskPassword;
    }

    public void setHelpDeskPassword(String HelpDeskPassword) {
        this.HelpDeskPassword = HelpDeskPassword;
    }
    
    
}
