package com.newgen.brit.util;

import org.apache.log4j.Logger;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;
import java.io.File;
import java.io.IOException;

public class AddToSMS {
    
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    public static String AddtoSms(String docName, String savedFile, String Sessionid,
            String jtsIpAddress, String cabinet, String jtsPort, String volumeIndex) throws JPISException {
        String strDocumentType = null;
        String CaseNumber = "";
        String sISIndex = "";

        try {
            File file = new File(savedFile);
            String fileName = file.getName();
            JPDBRecoverDocData docDBData = new JPDBRecoverDocData();
            ISPack.ISUtil.JPISIsIndex isIndex = new ISPack.ISUtil.JPISIsIndex();
            String simgVolId1 = "";
            String simgDocId = "";
            String OfDocType = docName;
            long lgvDocSize;
            File obvFile = file;
            lgvDocSize = obvFile.length();
            String sDocSize = Long.toString(lgvDocSize);
            int nNoOfPages = 1;
            String ISLookupBean = "com.newgen.omni.jts.txn.NGOClientServiceHandlerHome";
            String ISProviderURL = "jnp://192.168.13.93:2809";
            String ISJndiContextFactory = "org.jnp.interfaces.NamingContextFactory";
            int a = fileName.lastIndexOf(".");
            a = a + 1;
            String ss = fileName.substring(a);

           loggerCnsl.info("file in Add to SMS--" + file);
           loggerCnsl.info("fileName in Add to SMS---" + fileName);
           loggerCnsl.info("OfDocType in Add to SMS--" + OfDocType);
           loggerCnsl.info("lgvDocSize in Add to SMS--" + lgvDocSize);
           loggerCnsl.info("obvFile.length in Add to SMS--" + obvFile.length());
           loggerCnsl.info("obvFile in Add to SMS--" + obvFile);
           loggerCnsl.info("sDocSize in Add to SMS--" + sDocSize);
           loggerCnsl.info("nNoOfPages in Add to SMS--" + nNoOfPages);
           loggerCnsl.info("ISLookupBean in Add to SMS--" + ISLookupBean);
           loggerCnsl.info("ISProviderURL in Add to SMS--" + ISProviderURL);
           loggerCnsl.info("ISJndiContextFactory in Add to SMS--" + ISJndiContextFactory);
           loggerCnsl.info("a in Add to SMS--" + a);
           loggerCnsl.info("ss in Add to SMS--" + ss);

           loggerCnsl.info("savedfile in Add to SMS---->" + savedFile);
//            CPISDocumentTxn.AddDocument_MT(null, "127.0.0.1",  Short.parseShort(strPort), strCabinetName,
//                    Short.parseShort(strVolumeID), filePath, docDBData, "", isIndex);
            CPISDocumentTxn.AddDocument_MT(null, jtsIpAddress, Short.parseShort(jtsPort), cabinet,
                    Short.parseShort(volumeIndex), savedFile, docDBData, "", isIndex);
            if ((ss.equalsIgnoreCase("tif")) || (ss.equalsIgnoreCase("tiff"))) {
                nNoOfPages = com.newgen.niplj.fileformat.Tif6.getPageCount(savedFile);
            }
            simgVolId1 = simgVolId1 + isIndex.m_sVolumeId;
            simgDocId = simgDocId + isIndex.m_nDocIndex;
            // sISIndex = simgDocId + "#" + simgVolId1;
            sISIndex = simgDocId + "#" + simgVolId1 + "#" + ss + '#' + nNoOfPages + '#' + lgvDocSize;
           loggerCnsl.info("sISIndex------------->" + sISIndex);
            strDocumentType = OfDocType + (char) 21 + sISIndex + (char) 21 + nNoOfPages + (char) 21 + sDocSize
                    + (char) 21 + ss + (char) 25;
           loggerCnsl.info("strDocumentType------------->" + strDocumentType);
           loggerCnsl.info("Document addeds successfully in OD - SMS");

        } catch (Exception e) {
            e.printStackTrace();

        }
        return sISIndex;

    }

}
