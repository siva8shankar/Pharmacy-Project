package com.newgen.brit.util;
import com.newgen.brit.util.PropertyBean;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.log4j.Logger;

public class PropReader {
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");

    public static String blankString(Object object) {
        String sReturnVal = "";
        if (object != null && !object.toString().trim().equalsIgnoreCase("") && !object.toString().trim().equalsIgnoreCase("null")) {
            sReturnVal = object.toString();
        }
        return sReturnVal;
    }

    public PropertyBean readPropertyFile() {
        PropertyBean myBean = null;
        Properties reader = new Properties();
        InputStream in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/brit/util/configuration.properties");
        try {
            myBean = new PropertyBean();
            //reader = new Properties();
            reader.load(in);

            myBean.setCabinetName(blankString(reader.getProperty("CabinetName")));
            myBean.setPassword(blankString(reader.getProperty("Password")));
            myBean.setShowLogOut(blankString(reader.getProperty("ShowLogOut")));
            myBean.setUserName(blankString(reader.getProperty("UserName")));
            myBean.setServerIP(blankString(reader.getProperty("ServerIP")));
            myBean.setServerPort(blankString(reader.getProperty("ServerPort")));
            myBean.setProtocol(blankString(reader.getProperty("Protocol")));
            myBean.setJtsPort(blankString(reader.getProperty("jtsPort")));
            myBean.setVolumeIndex(blankString(reader.getProperty("VolumeIndex")));
            myBean.setHelpDeskUserName(blankString(reader.getProperty("HelpDeskUserName")));
            myBean.setHelpDeskPassword(blankString(reader.getProperty("HelpDeskPassword")));
            
            myBean.setWorkitemEndPointurl(blankString(reader.getProperty("WorkitemEndPointurl")));
            myBean.setInitiateFromActivityId(blankString(reader.getProperty("InitiateFromActivityId")));
            myBean.setInitiateFromActivityName(blankString(reader.getProperty("InitiateFromActivityName")));
            myBean.setProcessDefId(blankString(reader.getProperty("ProcessDefId")));
            myBean.setProcessName(blankString(reader.getProperty("ProcessName")));
            myBean.setCabinet(blankString(reader.getProperty("Cabinet")));
            
            
           loggerCnsl.info("Password-->" + myBean.getPassword());
           loggerCnsl.info("jtsPort-->" + blankString(reader.getProperty("jtsPort")));
           loggerCnsl.info("VolumeIndex-->" + blankString(reader.getProperty("VolumeIndex")));

        } catch (IOException ex) {
            ex.printStackTrace();
            return myBean;
        }
        return myBean;
    }
    
    public PropertyBean readPropertyFile(String strProcessName) {
        PropertyBean myBean = null;
        Properties reader = new Properties();
        InputStream in = null;
        if(strProcessName.equalsIgnoreCase("CabReqBooking")){
        in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/brit/util/cabrequest_configuration.properties");
        } else if(strProcessName.equalsIgnoreCase("HelpDesk")){
        in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/brit/util/helpdesk_configuration.properties");
        } else if(strProcessName.equalsIgnoreCase("Compliance")){
        in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/brit/util/compliance_configuration.properties");
        } else if(strProcessName.equalsIgnoreCase("GuestHouseBooking")){
        in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/brit/util/guesthouse_configuration.properties");
        } else if(strProcessName.equalsIgnoreCase("VPFRequest")){
        in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/brit/util/vpf_configuration.properties");
        } else {
        in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/brit/util/configuration.properties");
        }
        try {
            myBean = new PropertyBean();
            //reader = new Properties();
            reader.load(in);

            myBean.setCabinetName(blankString(reader.getProperty("CabinetName")));
            myBean.setPassword(blankString(reader.getProperty("Password")));
            myBean.setShowLogOut(blankString(reader.getProperty("ShowLogOut")));
            myBean.setUserName(blankString(reader.getProperty("UserName")));
            myBean.setServerIP(blankString(reader.getProperty("ServerIP")));
            myBean.setServerPort(blankString(reader.getProperty("ServerPort")));
            myBean.setProtocol(blankString(reader.getProperty("Protocol")));
            myBean.setJtsPort(blankString(reader.getProperty("jtsPort")));
            myBean.setVolumeIndex(blankString(reader.getProperty("VolumeIndex")));
            myBean.setHelpDeskUserName(blankString(reader.getProperty("HelpDeskUserName")));
            myBean.setHelpDeskPassword(blankString(reader.getProperty("HelpDeskPassword")));
            
            myBean.setWorkitemEndPointurl(blankString(reader.getProperty("WorkitemEndPointurl")));
            myBean.setInitiateFromActivityId(blankString(reader.getProperty("InitiateFromActivityId")));
            myBean.setInitiateFromActivityName(blankString(reader.getProperty("InitiateFromActivityName")));
            myBean.setProcessDefId(blankString(reader.getProperty("ProcessDefId")));
            myBean.setProcessName(blankString(reader.getProperty("ProcessName")));
            myBean.setCabinet(blankString(reader.getProperty("Cabinet")));
            
            
           loggerCnsl.info("Password-->" + myBean.getPassword());
           loggerCnsl.info("jtsPort-->" + blankString(reader.getProperty("jtsPort")));
           loggerCnsl.info("VolumeIndex-->" + blankString(reader.getProperty("VolumeIndex")));

        } catch (IOException ex) {
            ex.printStackTrace();
            return myBean;
        }
        return myBean;
    }
}