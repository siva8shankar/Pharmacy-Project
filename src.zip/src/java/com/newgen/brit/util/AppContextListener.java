package com.newgen.brit.util;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.PropertyConfigurator;

public class AppContextListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        System.out.println("Context to be initialized of customibps at " + (new java.util.Date()));
        try {
            ServletContext s_con = servletContextEvent.getServletContext();
            String log4jConfigFile = s_con.getInitParameter("log4j-config-location");
            System.out.println("server path ==> " +s_con.getRealPath(""));
            String fullPath = s_con.getRealPath("") + File.separator + log4jConfigFile;
            PropertyConfigurator.configure(fullPath);
//            PropReader propReader=new PropReader();
//            propReader.readPropertyFile();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
        // Your code here
        System.out.println("Context has been destroyed of UpdateVendorMaster at" + (new java.util.Date()));

    }
}