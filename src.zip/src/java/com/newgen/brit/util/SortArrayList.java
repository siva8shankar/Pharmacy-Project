package com.newgen.brit.util;

import com.newgen.brit.kycupload.beans.KYCMaster;
import java.util.Comparator;

public class SortArrayList implements Comparator<KYCMaster> {

	@Override
	public int compare(KYCMaster arg0, KYCMaster arg1) {
		// TODO Auto-generated method stub
		//if(arg0.getPONO() < arg1.getPONO()){
		if(Long.parseLong(arg0.getAadharAckNumber()) < Long.parseLong(arg1.getAadharAckNumber())){
            return 1;
        } else {
            return -1;
        }
	}

}
