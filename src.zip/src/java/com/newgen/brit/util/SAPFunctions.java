package com.newgen.brit.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omniforms.xmlviewerapi.IFormCallBroker;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;

public class SAPFunctions {

	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static Logger loggerXml = Logger.getLogger("xmlLogger");
	private static Logger logger = Logger.getLogger("consoleLogger");

	static NGEjbClient ejbObj = null;
        //com.newgen.omni.jts.cmgr.XMLParser
	/*
	 * private static String SAPHostName = "192.168.120.22"; private static
	 * String SAPInstanceNo = "22"; private static String SAPClient = "100";
	 * private static String SAPUserName = "NEWGEN"; private static String
	 * SAPPassword = "Welcome@123"; private static String SAPLanguage = "EN";
	 * private static String strAppserverIp = "172.24.14.10"; private static
	 * String strServerPort = "1099"; private static String strAppServerType =
	 * "JBossEAP";
	 */
	private static String SAPHostName;
	private static String SAPInstanceNo;
	private static String SAPClient;
	private static String SAPUserName;
	private static String SAPPassword;
	private static String SAPLanguage;
	private static String strAppserverIp;
	private static String strServerPort;
	private static String strAppServerType;

	public SAPFunctions() {
		readSAPConnectProperties();
	}

	public void readSAPConnectProperties() {
		Properties properties = new Properties();
		FileInputStream fileinputstream = null;
                String strIniFilepath = System.getProperty("user.dir") + "\\SAP_Details\\SAPConnections.ini";
		try {
			java.io.File fIni = new java.io.File(strIniFilepath);
			if (!(fIni.isFile() && fIni.exists())) {
				String message = "Customibps: \\SAP_Details\\SAPConnections.ini file not present.";
				loggerErr.error(message);
			}
			fileinputstream = new FileInputStream(fIni);
			properties.load(fileinputstream);                        
			SAPHostName = properties.getProperty("SAPHostName");
			SAPInstanceNo = properties.getProperty("SAPInstance");
			SAPClient = properties.getProperty("SAPClient");
			SAPUserName = properties.getProperty("SAPUserName");
			SAPPassword = properties.getProperty("SAPPassword");
			SAPLanguage = properties.getProperty("SAPLanguage");
			strAppserverIp = properties.getProperty("AppserverIp");
			strServerPort = properties.getProperty("ServerPort");
			strAppServerType = properties.getProperty("AppServerType");                        
                        
			System.out.println("SAPHostName --> " + SAPHostName);
			System.out.println("SAPInstanceNo -->  " + SAPInstanceNo);
			System.out.println("SAPClient -->  " + SAPClient);
			System.out.println("SAPUserName -->  " + SAPUserName);
			System.out.println("SAPPassword -->  " + SAPPassword);
			System.out.println("SAPLanguage -->  " + SAPLanguage);
			System.out.println("strAppserverIp -->  " + strAppserverIp);
			System.out.println("strServerPort -->  " + strServerPort);
			System.out.println("strAppServerType -->  " + strAppServerType);
			fileinputstream.close();
		} catch (FileNotFoundException ex) {
		} catch (IOException ex) {
		}
	}

	public boolean InitializeEjbClient() {
		System.out.println("Intialize Ejb Started");
		boolean bRetVal = false;
		try {
			ejbObj = NGEjbClient.getSharedInstance();
			/* ejbObj.initialize("172.24.14.10", "4447", "JBossEAP"); */
			ejbObj.initialize(strAppserverIp, strServerPort, strAppServerType);
			bRetVal = true;
			System.out.println("Intialize Ejb Successful");
		} catch (Exception e) {
			System.out.println("Intialize Ejb Failed = " + e.toString());
		}
		return bRetVal;
	}

	public String getWFSAPInvoker(String SAPFunction, String SAPParameters) throws Exception {
		// try{}catch(Exception e){}
		logger.debug("getWFSAPInvoker method starts...");
		StringBuilder strWFSAPInvoker = new StringBuilder();
		try {
			strWFSAPInvoker.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			strWFSAPInvoker.append("<WFSAPInvokeFunction_Input>");
			strWFSAPInvoker.append("<Option>WFSAPInvokeFunction</Option>");
			strWFSAPInvoker.append("<SAPConnect>");
			strWFSAPInvoker.append("<SAPHostName>").append(SAPHostName).append("</SAPHostName>");
			strWFSAPInvoker.append("<SAPInstance>").append(SAPInstanceNo).append("</SAPInstance>");
			strWFSAPInvoker.append("<SAPClient>").append(SAPClient).append("</SAPClient>");
			strWFSAPInvoker.append("<SAPUserName>").append(SAPUserName).append("</SAPUserName>");
			strWFSAPInvoker.append("<SAPPassword>").append(SAPPassword).append("</SAPPassword>");
			strWFSAPInvoker.append("<SAPLanguage>").append(SAPLanguage).append("</SAPLanguage>");
			strWFSAPInvoker.append("</SAPConnect>");
			strWFSAPInvoker.append("<SAPFunctionName>").append(SAPFunction).append("</SAPFunctionName>");
			strWFSAPInvoker.append("<Parameters>");
			strWFSAPInvoker.append("<ImportParameters>").append(SAPParameters).append("</ImportParameters>");
			strWFSAPInvoker.append("</Parameters>");
			strWFSAPInvoker.append("</WFSAPInvokeFunction_Input>");
			loggerXml.debug("getWFSAPInvoker SAP_inxml ====> " + strWFSAPInvoker);
		} catch (Exception e) {
			System.err.println("Exception occured in getWFSAPInvoker method :: " + e);
			loggerErr.error("Exception occured in getWFSAPInvoker method :: " + e);
			e.printStackTrace();
		}
		return callServer(strWFSAPInvoker.toString(), strAppserverIp, strServerPort);
	}

	public String getWFTest(String SAPFunction, String SAPParameters) throws Exception {
		logger.debug("getWFTest method starts...");
		StringBuilder strWFSAPInvoker = new StringBuilder();
		try {
			strWFSAPInvoker.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			strWFSAPInvoker.append("<WFSAPInvokeFunction_Input>");
			strWFSAPInvoker.append("<Option>WFSAPInvokeFunction</Option>");
			strWFSAPInvoker.append("<SAPConnect>");
			strWFSAPInvoker.append("<SAPHostName>").append(SAPHostName).append("</SAPHostName>");
			strWFSAPInvoker.append("<SAPInstance>").append(SAPInstanceNo).append("</SAPInstance>");
			strWFSAPInvoker.append("<SAPClient>").append(SAPClient).append("</SAPClient>");
			strWFSAPInvoker.append("<SAPUserName>").append(SAPUserName).append("</SAPUserName>");
			strWFSAPInvoker.append("<SAPPassword>").append(SAPPassword).append("</SAPPassword>");
			strWFSAPInvoker.append("<SAPLanguage>").append(SAPLanguage).append("</SAPLanguage>");
			strWFSAPInvoker.append("</SAPConnect>");
			strWFSAPInvoker.append("<SAPFunctionName>").append(SAPFunction).append("</SAPFunctionName>");
			strWFSAPInvoker.append("<Parameters>");
			strWFSAPInvoker.append("<ImportParameters>").append(SAPParameters).append("</ImportParameters>");
			strWFSAPInvoker.append("</Parameters>");
			strWFSAPInvoker.append("</WFSAPInvokeFunction_Input>");
			loggerXml.debug("getWFTest SAP_inxml ---> " + strWFSAPInvoker);
		} catch (Exception e) {
			System.err.println("Exception occured in getWFTest method :: " + e);
			loggerErr.error("Exception occured in getWFTest method :: " + e);
			e.printStackTrace();
		}
		return callServer(strWFSAPInvoker.toString(), strAppserverIp, strServerPort);
	}

	private String callServer(String xml, String strAppserverIp, String strServerPort) throws Exception {
		logger.debug("callServer method starts...");
		logger.debug("xml ==> "+xml+"  strAppserverIp ==> "+strAppserverIp+" strServerPort ==> "+strServerPort);
		String output = "";
		try {
//			ejbObj = NGEjbClient.getSharedInstance();
//			/* ejbObj.initialize("172.24.14.10", "4447", "JBossEAP"); */
//			ejbObj.initialize(strAppserverIp, strServerPort, strAppServerType);
			System.out.println("Input XML :==== " + xml);
			loggerXml.debug("callServer  xml ---> " + xml);
			logger.debug("callServer method input xml" + xml);
			// output = IFormCallBroker.execute(xml, strAppserverIp,
			// Integer.parseInt(strServerPort));
//			output = ejbObj.makeCall(xml);
                        output = WFCallBroker.execute(xml, strAppserverIp, 3333, 0);
			System.out.println("Output XML :==== " + output);
			logger.debug("callServer method output output" + output);
			logger.debug("callServer method output xml" + output);
			String mainCode = new WFXmlResponse(output).getVal("MainCode");
			if (mainCode == null || mainCode.length() == 0) {
				mainCode = new WFXmlResponse(output).getVal("Status");
			}
			if (mainCode == null || !((mainCode.equalsIgnoreCase("0")) || (mainCode.equalsIgnoreCase("18")))) {
				throw new Exception("\n Error in request\nOutput XML : \n" + output + "\n\n");
			}
		} catch (Exception e) {
			System.err.println("Exception occured in callServer method :: " + e);
			loggerErr.error("Exception occured in callServer method :: " + e);
			e.printStackTrace();
		}
		return output;

	}
}
