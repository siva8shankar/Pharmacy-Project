/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.brit.util;

import com.newgen.brit.kycupload.beans.CNFRoomDetails;
import com.newgen.brit.kycupload.beans.EmployeeGuestHouseData;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.XMLParser;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import org.apache.log4j.Logger;

/**
 *
 * @author ngappadmin
 */
public class CNFROOMCommonMethods {
    
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml = Logger.getLogger("xmlLogger");
    private static Logger loggerCnsl = Logger.getLogger("consoleLogger");
    
    public static ArrayList<EmployeeGuestHouseData> getCNFREmpDataMethod(String sessionId, PropertyBean probBean, String strEmployeeName) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        EmployeeGuestHouseData objGHouse = new EmployeeGuestHouseData();
        ArrayList<EmployeeGuestHouseData> guestDetails = new ArrayList<EmployeeGuestHouseData>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT Employee_ID AS 'Employee Number',User_ID AS 'EmployeeUserID',Employee_Name AS 'Employee Name',Email_ID AS 'Email ID',Mobile_No AS 'Contact Number',Region AS 'Region',Work_Location AS 'Work Location',RM_USERID AS 'Reporting Manager',USERID AS 'HRBPUSERID',ENAME AS 'HRBP Name',Vendor_Code AS 'Vendor Code',Designation,Emp_Subgroup AS 'Grade',Org_Unit AS 'Department',VEN_GLCODE,Cost_Centre,Personnel_Area as 'State' FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WITH(NOLOCK) WHERE User_ID='" + strEmployeeName + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objGHouse.setEmpNumber(wfxmllist.getVal("Value1").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpUserID(wfxmllist.getVal("Value2").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpName(wfxmllist.getVal("Value3").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpEmailID(wfxmllist.getVal("Value4").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpContactNum(wfxmllist.getVal("Value5").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRegion(wfxmllist.getVal("Value6").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpWorkLoc(wfxmllist.getVal("Value7").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRM(wfxmllist.getVal("Value8").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPUserID(wfxmllist.getVal("Value9").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPName(wfxmllist.getVal("Value10").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorCode(wfxmllist.getVal("Value11").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDesignation(wfxmllist.getVal("Value12").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpGrade(wfxmllist.getVal("Value13").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDepartment(wfxmllist.getVal("Value14").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorGL(wfxmllist.getVal("Value15").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpCostCenter(wfxmllist.getVal("Value16").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpState(wfxmllist.getVal("Value17").trim().replaceAll("&amp;", "and"));
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }
    
    public static ArrayList<EmployeeGuestHouseData> getCNFRContractEmpDataMethod(String sessionId, PropertyBean probBean, String strEmployeeName) {
        loggerCnsl.info("Inside getTypeOfComplaintAbountMethod ==");
        String strInputXml;
        EmployeeGuestHouseData objGHouse = new EmployeeGuestHouseData();
        ArrayList<EmployeeGuestHouseData> guestDetails = new ArrayList<EmployeeGuestHouseData>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT Employee_ID AS 'Employee Number',User_ID AS 'EmployeeUserID',Employee_Name AS 'Employee Name',Email_ID AS 'Email ID',Mobile_No AS 'Contact Number',Region AS 'Region',Work_Location AS 'Work Location',RM_USERID AS 'Reporting Manager',USERID AS 'HRBPUSERID',ENAME AS 'HRBP Name',Vendor_Code AS 'Vendor Code',Designation,Emp_Subgroup AS 'Grade',Org_Unit AS 'Department',VEN_GLCODE,Cost_Centre,Personnel_Area as 'State' FROM NG_BRIT_ACTIVE_CONTRACT_USERS_LIST WITH(NOLOCK) WHERE User_ID='" + strEmployeeName + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objGHouse.setEmpNumber(wfxmllist.getVal("Value1").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpUserID(wfxmllist.getVal("Value2").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpName(wfxmllist.getVal("Value3").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpEmailID(wfxmllist.getVal("Value4").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpContactNum(wfxmllist.getVal("Value5").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRegion(wfxmllist.getVal("Value6").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpWorkLoc(wfxmllist.getVal("Value7").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpRM(wfxmllist.getVal("Value8").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPUserID(wfxmllist.getVal("Value9").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpHRBPName(wfxmllist.getVal("Value10").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorCode(wfxmllist.getVal("Value11").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDesignation(wfxmllist.getVal("Value12").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpGrade(wfxmllist.getVal("Value13").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpDepartment(wfxmllist.getVal("Value14").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpVendorGL(wfxmllist.getVal("Value15").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpCostCenter(wfxmllist.getVal("Value16").trim().replaceAll("&amp;", "and"));
                    objGHouse.setEmpState(wfxmllist.getVal("Value17").trim().replaceAll("&amp;", "and"));
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }
    
    public static ArrayList<CNFRoomDetails> getCNFDetailsMethodForMail(String sessionId, PropertyBean probBean, String strRoomLocation) {
        loggerCnsl.info("Inside getGuestHouseDetailsMethodForMail ==");
        String strInputXml;
        CNFRoomDetails objGHouse = new CNFRoomDetails();
        ArrayList<CNFRoomDetails> guestDetails = new ArrayList<CNFRoomDetails>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT AdminEmailID,ccColumn FROM EXT_CNFROOM_REGIONALMAIL_MASTER_DETAILS WITH(NOLOCK) WHERE RoomLocation='" + strRoomLocation + "' ";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objGHouse.setAdminMailID(wfxmllist.getVal("Value1").trim());
                    objGHouse.setCcColumn(wfxmllist.getVal("Value2").trim());
                    guestDetails.add(objGHouse);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfFunction==" + strTypeOfFunction);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return guestDetails;
    }
    
    public static List<String> getCNFRoomListMethod(String sessionId, PropertyBean probBean) {
        loggerCnsl.info("Inside getCNFRoomListMethod == ");
        String strInputXml;
        List<String> typeOfLoc = new ArrayList();
        typeOfLoc.add("Select a Location");
        String strQuery = "SELECT DISTINCT(RoomLocation) FROM EXT_CNFROOM_CONFERENCEROOM_MASTER_DETAILS WITH(nolock)";//WHERE RoomLocation='Bangalore-EO'
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfLocation = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCNFRoomListMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCNFRoomListMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    strTypeOfLocation = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    typeOfLoc.add(strTypeOfLocation);
                    wfxmllist.skip(true);
                }
                loggerCnsl.info("strTypeOfLocation==" + strTypeOfLocation);
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return typeOfLoc;
    }
    
    public static ArrayList<CNFRoomDetails> getCNFRoomDetailsMethod(String sessionId, PropertyBean probBean, String strRoomLoc) {
        loggerCnsl.info("Inside getCNFRoomDetailsMethod  == "+strRoomLoc);
        String strInputXml;
        
        ArrayList<CNFRoomDetails> cnfroomDetails = new ArrayList<CNFRoomDetails>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT RoomLocation,RoomName,FullAddress,RoomType,RoomCapacity,CareTakerDetails,Remarks FROM EXT_CNFROOM_CONFERENCEROOM_MASTER_DETAILS WITH(nolock) WHERE RoomLocation='" + strRoomLoc + "' ORDER BY RoomName ASC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objCNFR.setRoomLocation(wfxmllist.getVal("Value1").trim());
                    objCNFR.setRoomName(wfxmllist.getVal("Value2").trim());
                    objCNFR.setFullAddress(wfxmllist.getVal("Value3").trim());
                    objCNFR.setRoomType(wfxmllist.getVal("Value4").trim());
                    objCNFR.setRoomCapacity(wfxmllist.getVal("Value5").trim());
                    objCNFR.setCareTakerDetails(wfxmllist.getVal("Value6").trim());
                    objCNFR.setRemarks(wfxmllist.getVal("Value7").trim());
                    cnfroomDetails.add(objCNFR);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return cnfroomDetails;
    }
    
    public static ArrayList<CNFRoomDetails> getCNFRoomMyBookingDetailsMethod(String sessionId, PropertyBean probBean, String strUserID) {
        loggerCnsl.info("Inside getCNFRoomMyBookingDetailsMethod  == "+strUserID);
        String strInputXml;
        
        ArrayList<CNFRoomDetails> cnfroomDetails = new ArrayList<CNFRoomDetails>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT RoomLocation,RoomName,AddressFloor,CONVERT(VARCHAR(10), BookingDate, 103) AS 'Booked Date', FromTime, ToTime, BookedFor, EmpDepartment FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WITH(NOLOCK) WHERE EmpUserID='" + strUserID + "' AND StatusFlag='Booked' ORDER BY RoomName ASC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCNFRoomMyBookingDetailsMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCNFRoomMyBookingDetailsMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objCNFR.setRoomLocation(wfxmllist.getVal("Value1").trim());
                    objCNFR.setRoomName(wfxmllist.getVal("Value2").trim());
                    objCNFR.setFullAddress(wfxmllist.getVal("Value3").trim());
                    objCNFR.setBookingDate(wfxmllist.getVal("Value4").trim());
                    objCNFR.setFromTime(wfxmllist.getVal("Value5").trim());
                    objCNFR.setToTime(wfxmllist.getVal("Value6").trim());
                    objCNFR.setBookedFor(wfxmllist.getVal("Value7").trim());
                    objCNFR.setEmpDepartment(wfxmllist.getVal("Value8").trim());
                    cnfroomDetails.add(objCNFR);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return cnfroomDetails;
    }
    
    public static ArrayList<CNFRoomDetails> getCNFRoomCancelBookingDetailsMethod(String sessionId, PropertyBean probBean, String strUserID) {
        loggerCnsl.info("Inside getCNFRoomMyBookingDetailsMethod  == "+strUserID);
        String strInputXml;
        
        ArrayList<CNFRoomDetails> cnfroomDetails = new ArrayList<CNFRoomDetails>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT RoomLocation,RoomName,AddressFloor,CONVERT(VARCHAR(10), BookingDate, 103) AS 'Booked Date', FromTime, ToTime, BookedFor, EmpDepartment, SNO FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WITH(NOLOCK) WHERE EmpUserID='" + strUserID + "' AND StatusFlag = 'Booked' AND BookingToTime > getdate() ORDER BY RoomName ASC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCNFRoomMyBookingDetailsMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCNFRoomMyBookingDetailsMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objCNFR.setRoomLocation(wfxmllist.getVal("Value1").trim());
                    objCNFR.setRoomName(wfxmllist.getVal("Value2").trim());
                    objCNFR.setFullAddress(wfxmllist.getVal("Value3").trim());
                    objCNFR.setBookingDate(wfxmllist.getVal("Value4").trim());
                    objCNFR.setFromTime(wfxmllist.getVal("Value5").trim());
                    objCNFR.setToTime(wfxmllist.getVal("Value6").trim());
                    objCNFR.setBookedFor(wfxmllist.getVal("Value7").trim());
                    objCNFR.setEmpDepartment(wfxmllist.getVal("Value8").trim());
                    objCNFR.setSNO(wfxmllist.getVal("Value9").trim());
                    cnfroomDetails.add(objCNFR);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return cnfroomDetails;
    }
    
    public static String getCNFRoomsAvailabilityMethod(String sessionId, String strRoomLocation, String strRoomName, String strBookingDate, String strFromTime, String strToTime) {
        loggerCnsl.info("Inside getCNFRoomsAvailabilityMethod ==");
//        String FromDate1 = CommonMethod.formatDate(FromDate);
//        String ToDate1 = CommonMethod.formatDate(ToDate);
        String strInputXml;
        final String strCabinateName = "britbpm";
        final String strJbossIp = "172.16.8.81";//for UAT
//        final String strJbossIp = "172.16.8.97";//for PRODUCTION
//        final String strJbossIp = "127.0.0.1";//for PRODUCTION
//        String strQuery = "SELECT Count(1) FROM EXT_GUESTHOUSE_OCCUPANCY_DETAILS_ACTIVE a WITH(NOLOCK), EXT_GUESTHOUSE_ROOMS_MASTER  b WITH(NOLOCK) WHERE b.RoomNumber=a.RoomNumber AND b.RoomName=a.RoomName AND a.GuestHouseLocation='" + strGuestHouseLocation + "' AND (((a.FromDate BETWEEN '" + FromDate1 + "' AND '" + ToDate1 + "') OR (a.ToDate BETWEEN '" + FromDate1 + "' AND '" + ToDate1 + "')) OR (('" + FromDate1 + "' BETWEEN FromDate AND ToDate) OR ('" + ToDate1 + "' BETWEEN FromDate AND ToDate))) AND b.RoomType='" + RoomType + "'";
        String strQuery = "SELECT count(1) FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WITH(nolock) WHERE RoomLocation='" + strRoomLocation + "' AND RoomName='" + strRoomName + "' AND BookingDate='" + strBookingDate + "' AND FromTime='" + strFromTime + "' AND ToTime='" + strToTime + "'";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strReturnVal = "";

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + strCabinateName + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCNFRoomsAvailabilityMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("strJbossIp == " + strJbossIp);
        loggerCnsl.info("strCabinateName == " + strCabinateName);
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), strJbossIp, Integer.parseInt("3333"), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCNFRoomsAvailabilityMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
//                RoomType_add.add("--Select--"+ "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    strReturnVal = wfxmllist.getVal("Value1").trim();
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return strReturnVal;
    }
    
    public static ArrayList<CNFRoomDetails> getCNFRoomStatusMethod(String sessionId, PropertyBean probBean, String strRoomLoc, String strRoomName, String strBookingDate) {
        loggerCnsl.info("Inside getCNFRoomStatusMethod  strRoomLoc == "+strRoomLoc);
        loggerCnsl.info("Inside getCNFRoomStatusMethod  strRoomName == "+strRoomName);
        loggerCnsl.info("Inside getCNFRoomStatusMethod  strBookingDate == "+strBookingDate);
        String strInputXml;
        
        ArrayList<CNFRoomDetails> cnfroomDetails = new ArrayList<CNFRoomDetails>();
//        typeOfFunc.add("Select a Category");
//        String strQuery = "SELECT RoomLocation,RoomName,FullAddress,RoomType,RoomCapacity,CareTakerDetails,Remarks FROM EXT_CNFROOM_CONFERENCEROOM_MASTER_DETAILS WITH(nolock) WHERE RoomLocation='" + strRoomLoc + "' AND RoomName='" + strRoomName + "'";
        String strQuery = "SELECT RoomLocation,RoomName,CONVERT(VARCHAR(10), BookingDate, 103) AS 'Booked Date',BookedBy,EmpDepartment,BookedFor,FromTime,ToTime,NoOfParticipants,EmpEmailID,EmpExtNumber FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WITH(NOLOCK) WHERE RoomLocation='" + strRoomLoc + "' AND RoomName='" + strRoomName + "' AND BookingDate='" + strBookingDate + "' AND StatusFlag = 'Booked' ORDER BY RoomName ASC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCNFRoomStatusMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCNFRoomStatusMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objCNFR.setRoomLocation(wfxmllist.getVal("Value1").trim());
                    objCNFR.setRoomName(wfxmllist.getVal("Value2").trim());
                    objCNFR.setBookingDate(wfxmllist.getVal("Value3").trim());
                    objCNFR.setBookedBy(wfxmllist.getVal("Value4").trim());
                    objCNFR.setEmpDepartment(wfxmllist.getVal("Value5").trim());
                    objCNFR.setBookedFor(wfxmllist.getVal("Value6").trim());
                    objCNFR.setFromTime(wfxmllist.getVal("Value7").trim());
                    objCNFR.setToTime(wfxmllist.getVal("Value8").trim());
                    objCNFR.setNoOfParticipants(wfxmllist.getVal("Value9").trim());
                    objCNFR.setEmailID(wfxmllist.getVal("Value10").trim());
                    objCNFR.setExtNumber(wfxmllist.getVal("Value11").trim());
                    cnfroomDetails.add(objCNFR);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return cnfroomDetails;
    }
    
    public static ArrayList<CNFRoomDetails> getCNFRoomStatusOnDateChangeMethod(String sessionId, PropertyBean probBean, String strBookingDate) {
        loggerCnsl.info("Inside getCNFRoomStatusMethod  strBookingDate == "+strBookingDate);
        String strInputXml;
        
        ArrayList<CNFRoomDetails> cnfroomDetails = new ArrayList<CNFRoomDetails>();
//        typeOfFunc.add("Select a Category");
//        String strQuery = "SELECT RoomLocation,RoomName,FullAddress,RoomType,RoomCapacity,CareTakerDetails,Remarks FROM EXT_CNFROOM_CONFERENCEROOM_MASTER_DETAILS WITH(nolock) WHERE RoomLocation='" + strRoomLoc + "' AND RoomName='" + strRoomName + "'";
        String strQuery = "SELECT RoomLocation,RoomName,CONVERT(VARCHAR(10), BookingDate, 103) AS 'Booked Date',BookedBy,EmpDepartment,BookedFor,FromTime,ToTime,NoOfParticipants,EmpEmailID,EmpExtNumber FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WITH(NOLOCK) WHERE BookingDate='" + strBookingDate + "' AND StatusFlag = 'Booked' ORDER BY RoomName ASC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCNFRoomStatusMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCNFRoomStatusMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objCNFR.setRoomLocation(wfxmllist.getVal("Value1").trim());
                    objCNFR.setRoomName(wfxmllist.getVal("Value2").trim());
                    objCNFR.setBookingDate(wfxmllist.getVal("Value3").trim());
                    objCNFR.setBookedBy(wfxmllist.getVal("Value4").trim());
                    objCNFR.setEmpDepartment(wfxmllist.getVal("Value5").trim());
                    objCNFR.setBookedFor(wfxmllist.getVal("Value6").trim());
                    objCNFR.setFromTime(wfxmllist.getVal("Value7").trim());
                    objCNFR.setToTime(wfxmllist.getVal("Value8").trim());
                    objCNFR.setNoOfParticipants(wfxmllist.getVal("Value9").trim());
                    objCNFR.setEmailID(wfxmllist.getVal("Value10").trim());
                    objCNFR.setExtNumber(wfxmllist.getVal("Value11").trim());
                    cnfroomDetails.add(objCNFR);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return cnfroomDetails;
    }
    
    public static ArrayList<CNFRoomDetails> getCNFRoomStatusOnLocationChangeMethod(String sessionId, PropertyBean probBean, String strRoomLoc, String strBookingDate) {
        loggerCnsl.info("Inside getCNFRoomStatusMethod  strRoomLoc == "+strRoomLoc);
        loggerCnsl.info("Inside getCNFRoomStatusMethod  strBookingDate == "+strBookingDate);
        String strInputXml;
        
        ArrayList<CNFRoomDetails> cnfroomDetails = new ArrayList<CNFRoomDetails>();
//        typeOfFunc.add("Select a Category");
//        String strQuery = "SELECT RoomLocation,RoomName,FullAddress,RoomType,RoomCapacity,CareTakerDetails,Remarks FROM EXT_CNFROOM_CONFERENCEROOM_MASTER_DETAILS WITH(nolock) WHERE RoomLocation='" + strRoomLoc + "' AND RoomName='" + strRoomName + "'";
        String strQuery = "SELECT RoomLocation,RoomName,CONVERT(VARCHAR(10), BookingDate, 103) AS 'Booked Date',BookedBy,EmpDepartment,BookedFor,FromTime,ToTime,NoOfParticipants,EmpEmailID,EmpExtNumber FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WITH(NOLOCK) WHERE BookingDate='" + strBookingDate + "' AND RoomLocation='" + strRoomLoc + "' AND StatusFlag = 'Booked' ORDER BY RoomName ASC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCNFRoomStatusMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCNFRoomStatusMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objCNFR.setRoomLocation(wfxmllist.getVal("Value1").trim());
                    objCNFR.setRoomName(wfxmllist.getVal("Value2").trim());
                    objCNFR.setBookingDate(wfxmllist.getVal("Value3").trim());
                    objCNFR.setBookedBy(wfxmllist.getVal("Value4").trim());
                    objCNFR.setEmpDepartment(wfxmllist.getVal("Value5").trim());
                    objCNFR.setBookedFor(wfxmllist.getVal("Value6").trim());
                    objCNFR.setFromTime(wfxmllist.getVal("Value7").trim());
                    objCNFR.setToTime(wfxmllist.getVal("Value8").trim());
                    objCNFR.setNoOfParticipants(wfxmllist.getVal("Value9").trim());
                    objCNFR.setEmailID(wfxmllist.getVal("Value10").trim());
                    objCNFR.setExtNumber(wfxmllist.getVal("Value11").trim());
                    cnfroomDetails.add(objCNFR);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return cnfroomDetails;
    }
    
    public static ArrayList<String> getCNFRoomStatusMethod(String sessionId, PropertyBean probBean, String strcnfRoomLocation, String strRoomName, String strBookingDate, String cnfFromTime, String cnfToTime) {
        loggerCnsl.info("Inside getCNFRoomStatusMethod ==");
        loggerCnsl.info("Inside getCNFRoomStatusMethod strBookingDate == " + strBookingDate);
        loggerCnsl.info("Inside getCNFRoomStatusMethod cnfFromTime == " + cnfFromTime);
        loggerCnsl.info("Inside getCNFRoomStatusMethod cnfToTime == " + cnfToTime);
        String strFromBookingDateTime = strBookingDate+" "+cnfFromTime+":00";
        String strToBookingDateTime = strBookingDate+" "+cnfToTime+":00";
        loggerCnsl.info("Inside getCNFRoomStatusMethod FromBookingDateTime == " + strFromBookingDateTime);
        loggerCnsl.info("Inside getCNFRoomStatusMethod ToBookingDateTime == " + strToBookingDateTime);
//        String FromDate1 = CommonMethod.formatDate(FromDate);
//        String ToDate1 = CommonMethod.formatDate(ToDate);
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
//        String strQuery = "SELECT DISTINCT(RoomStatus) FROM EXT_GUESTHOUSE_ROOMS_MASTER WITH(NOLOCK) WHERE GuestHouseLocation='" + strGuestHouseLocation + "' AND RoomType='" + RoomType + "' AND RoomName='" + RoomName + "' AND RoomNumber='" + RoomNumber + "'";
        String strQuery = "SELECT CONVERT(CHAR(10), BookingDate, 103), FromTime, ToTime FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WITH(NOLOCK) WHERE RoomLocation='" + strcnfRoomLocation + "' AND RoomName='" + strRoomName + "' AND StatusFlag = 'Booked' AND (((BookingFromTime BETWEEN '" + strFromBookingDateTime + "' AND '" + strToBookingDateTime + "') OR (BookingToTime BETWEEN '" + strFromBookingDateTime + "' AND '" + strToBookingDateTime + "')) OR (('" + strFromBookingDateTime + "' BETWEEN BookingFromTime AND BookingToTime) OR ('" + strToBookingDateTime + "' BETWEEN BookingFromTime AND BookingToTime)))" ;
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
//                RoomType_add.add("--Select--"+ "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strBookingDate1 = wfxmllist.getVal("Value1").trim();
                    String strFromTime = wfxmllist.getVal("Value2").trim();
                    String strToTime = wfxmllist.getVal("Value3").trim();
                    RoomType_add.add("Unavailable" + "$#!" + strBookingDate1 + "$#!" + strFromTime + "$#!"+ strToTime + "$#!");
                    wfxmllist.skip(true);
                }
            } else if (parsergetlist.getValueOf("MainCode").equals("18")) {
                RoomType_add.add("Available");
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }
    
    public static ArrayList<CNFRoomDetails> getCNFRoomDetailsMethod(String sessionId, PropertyBean probBean, String strRoomLoc, String strRoomName) {
        loggerCnsl.info("Inside getCNFRoomDetailsMethod  == "+strRoomLoc);
        loggerCnsl.info("Inside getCNFRoomDetailsMethod  == "+strRoomName);
        String strInputXml;
        
        ArrayList<CNFRoomDetails> cnfroomDetails = new ArrayList<CNFRoomDetails>();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT RoomLocation,RoomName,FullAddress,RoomType,RoomCapacity,CareTakerDetails,Remarks FROM EXT_CNFROOM_CONFERENCEROOM_MASTER_DETAILS WITH(nolock) WHERE RoomLocation='" + strRoomLoc + "' AND RoomName='" + strRoomName + "' ORDER BY RoomName ASC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getTypeOfFunctionMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getTypeOfFunctionMethod method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    objCNFR.setRoomLocation(wfxmllist.getVal("Value1").trim());
                    objCNFR.setRoomName(wfxmllist.getVal("Value2").trim());
                    objCNFR.setFullAddress(wfxmllist.getVal("Value3").trim());
                    objCNFR.setRoomType(wfxmllist.getVal("Value4").trim());
                    objCNFR.setRoomCapacity(wfxmllist.getVal("Value5").trim());
                    objCNFR.setCareTakerDetails(wfxmllist.getVal("Value6").trim());
                    objCNFR.setRemarks(wfxmllist.getVal("Value7").trim());
                    cnfroomDetails.add(objCNFR);
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return cnfroomDetails;
    }
    
    public static ArrayList<String> getCNFRoomNamesMethod(String sessionId, PropertyBean probBean, String strRoomLocation) {
        loggerCnsl.info("Inside getCNFRoomNamesMethod  ==");
        String strInputXml;
        ArrayList<String> RoomType_add = new ArrayList();
//        typeOfFunc.add("Select a Category");
        String strQuery = "SELECT DISTINCT(RoomName) FROM EXT_CNFROOM_CONFERENCEROOM_MASTER_DETAILS WITH(nolock) WHERE RoomLocation='" + strRoomLocation + "' ORDER BY RoomName ASC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strTypeOfFunction = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getCNFRoomNamesMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getCNFRoomNamesMethod  method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
                wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                RoomType_add.add("--Select--" + "$#!");
                while (wfxmllist.hasMoreElements()) {
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    String strRoomType = wfxmllist.getVal("Value1").trim();
                    RoomType_add.add(strRoomType + "$#!");
                    wfxmllist.skip(true);
                }
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return RoomType_add;
    }
    
    public static String cancelSelectedCNFRRoomMethod(String sessionId, PropertyBean probBean, String strRoomLocation, String strPrimaryID) {
        loggerCnsl.info("Inside cancelSelectedCNFRRoomMethod  ==");
        String strInputXml;
        String strQuery = "UPDATE EXT_CNFROOM_BOOKING_DETAILS_ACTIVE SET StatusFlag='Cancelled',LastModifiedOn=getdate() WHERE RoomLocation='" + strRoomLocation + "' AND SNO=" + strPrimaryID + "";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strFlag = "false";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In cancelSelectedCNFRRoomMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In cancelSelectedCNFRRoomMethod  method strCompOutputXml == " + strCompOutputXml);
            strFlag = "true"; 
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return strFlag;
    }
    
    public static String getExtNumberFromDBMethod(String sessionId, PropertyBean probBean, String strEmployeeName) {
        loggerCnsl.info("Inside getExtNumberFromDBMethod  ==");
        String strInputXml;
        String strQuery = "SELECT TOP 1 EmpExtNumber,BookingToTime FROM EXT_CNFROOM_BOOKING_DETAILS_ACTIVE WHERE EmpUserID='" + strEmployeeName + "' AND EmpExtNumber IS NOT NULL ORDER BY BookingToTime DESC";
        loggerCnsl.info("strQuery == " + strQuery);
        XMLParser parsergetlist = null;
        String strCompOutputXml = null;
        StringBuilder strBuff1 = new StringBuilder();
        com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse wfXmlResponse = null;
        WFXmlList wfxmllist = null;
        String strFlag = "";
        LinkedList<String> LPID = new LinkedList();

        strInputXml = "<?xml version=\"1.0\"?>";
        strInputXml = strInputXml + "<WFCustomBean_Input><Option>NGGetData</Option>";
        strInputXml = strInputXml + "<QryOption>NGGetData</QryOption>";
        strInputXml = strInputXml + "<EngineName>" + probBean.getCabinetName() + "</EngineName>";
        strInputXml = strInputXml + "<SessionId>" + sessionId + "</SessionId>";
        strInputXml = strInputXml + "<QueryString>" + strQuery + "</QueryString>";
        strInputXml = strInputXml + "<ColumnNo>1</ColumnNo>";
        strInputXml = strInputXml + "</WFCustomBean_Input>";

        loggerXml.info("In getExtNumberFromDBMethod method strBuff1 ==" + strInputXml);
        loggerCnsl.info("probBean.getServerIP() == " + probBean.getServerIP());
        loggerCnsl.info("probBean.getJtsPort() == " + probBean.getJtsPort());
        loggerCnsl.info("probBean.getCabinetName() == " + probBean.getCabinetName());
        try {
            strCompOutputXml = WFCallBroker.execute(strInputXml.toString(), probBean.getServerIP(), Integer.parseInt(probBean.getJtsPort()), 0);
            strBuff1.setLength(0);
            loggerXml.info("In getExtNumberFromDBMethod  method strCompOutputXml == " + strCompOutputXml);
            parsergetlist = new XMLParser(strCompOutputXml);
            if (parsergetlist.getValueOf("MainCode").equals("0")) {
               wfXmlResponse = new com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse(strCompOutputXml);
                wfxmllist = wfXmlResponse.createList("DataList", "Data");
                wfxmllist.reInitialize(true);
                while (wfxmllist.hasMoreElements()) {
                    CNFRoomDetails objCNFR = new CNFRoomDetails();
//                    strTypeOfFunction = wfxmllist.getVal("Value1").trim();
                    //String tCode = wfxmllist.getVal("TaxCode");
                    strFlag = wfxmllist.getVal("Value1").trim();
                    wfxmllist.skip(true);
                } 
            }
        } catch (Exception e) {
        } finally {
            if (strCompOutputXml != null) {
                strCompOutputXml = null;
            }
            if (parsergetlist != null) {
                parsergetlist = null;
            }
            if (strBuff1 != null) {
                strBuff1 = null;
            }
        }
        return strFlag;
    }
}
