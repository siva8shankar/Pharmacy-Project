
var activityName=window.parent.stractivityName;
var processName = window.parent.strprocessname;
var pid1=window.parent.strWorkitemName;
/*function eventDispatchedAP(pEvent.type)
{
	alert("inside event dispatched AP.js :"+pEvent.type);
	return true;
}*/

//alert ("In Ap.js");
function validateForm(pEvent)
{
	//alert("AP.js="+processName);
	//alert("AP.js="+activityName);
	//Below code for initiation and indexing
	if(processName=='AP')  
	{
		alert("activityName="+activityName);
		alert("Value="+getNGValue("InitSts"));
		if ((activityName=='ER_Initiation')||( (activityName=='Indexing') && (getNGValue("InitSts")=='ER') )) 
		{
			   alert("Inside indexing/Initiation");
			if (!( 
                        mandateCheck('DateOfReq', 'DATE OF REQUEST')
						&& mandateCheck('TypeOfProcess', 'TYPE OF PROCESS')
						&& mandateCheck('CompanyCode',' COMPANY CODE')
						&& mandateCheck('Region', 'REGION')
						&&mandateCheck('TypeOfInvoice', 'TYPE OF INVOICE')
						&& mandateCheck('SubCategory1', 'SUBCATEGORY1')
						&& mandateCheck('RequestFor', 'REQUEST FOR')
						&& mandateCheck('EmployeeCode', 'EMPLOYEE CODE')
						&& mandateCheck('EmployeeName', 'EMPLOYEE NAME')
						&& mandateCheck('VendorCode', 'VENDOR CODE')
						&& mandateCheck('Designation', 'DESIGNATION')
						&& mandateCheck('Department', 'DEPARTMENT')
						&& mandateCheck('Grade', 'GRADE')
						&& mandateCheck('CostCenter', 'COST CENTER')
						&& mandateCheck('BusinessArea', 'BUSINESS AREA')
						&& mandateCheck('OriginalLocation', 'ORIGINAL LOCATION')
						&& mandateCheck('TotalAmount', 'TOTAL AMOUNT')
						
						)
						) 
				
				{
					return false;
				}
				var strTypeofinvoice=getNGValue('TypeOfInvoice');
				var strSubcategory=getNGValue('SubCategory1');
				
				if(strSubcategory=='Mobile Re-Imbursements')
				{
					if (!( 
                        mandateCheck('MobileNo', 'MOBILE NUMBER')
						&& mandateCheck('BillDate', 'BILL DATE')
						&& mandateCheck('CompanyCode',' COMPANY CODE')
						&& mandateCheck('EligibleAmount_MobileClaim', 'ELIGIBLE AMOUNT')
						&&mandateCheck('BlackBerryCharges', 'BLACKBERRY CHARGES')
						&& mandateCheck('FromPeriod', 'FROM PERIOD')
						&& mandateCheck('ToPeriod', 'TO PERIOD')
						&& mandateCheck('ServiceProvider', 'SERVICE PROVIDER')
						&& mandateCheck('BillPlan', 'BILL PLAN')
						&& mandateCheck('BillValueLessTax', 'BILL VALUE LESS SERVICE TAX')
						&& mandateCheck('ServiceTax_BillValue', 'SERVICE TAX IN BILL VALUE LESS SERVICE TAX')
						&& mandateCheck('ValueOfPersonalCalls', 'VALUE OF PERSONAL CALLS')
						&& mandateCheck('ServiceTax_ValueOfPersonalCalls', 'SERVICE TAX IN VALUE OF PERSONAL CALLS')
						)
						)
					{
					return false;
					}			
				}
				if(strSubcategory=='Salary Advance'||strSubcategory=='House Rent Advance'||strSubcategory=='Exceptional Advances')
				{
					if (!( 
                        mandateCheck('BasicSalary', 'BASIC SALARY')
						&& mandateCheck('EligibleAmount', 'ELIGIBLE AMOUNT')
						&& mandateCheck('RepaymentSchedule','REYAYMENT SCHEDULE')
						&& mandateCheck('ClaimedAmount', 'CLAIMED AMOUNT')
						)
						)
						{
							return false;
						}
				}
				if(strSubcategory=='Travel Expense')
				{
						if (!( 
						/*frm_brokage_fees 
						frm_travel_fare
						frm_hotel_fare
						frm_daily_allw
						frm_convey
						frm_misc
						frm_medical_expense
						frm_summary*/
						 //BROKAGE FEE
                        mandateCheck('TypeOfTransfer', 'TYPE OF TRANSFER')
						&& mandateCheck('DateOfJoining', 'DATE OF JOINING')
						&& mandateCheck('DateOfTransfer','DATE OF TRANSFER')
						&& mandateCheck('Amount', 'AMOUNT')
						&& mandateCheck('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						&& mandateCheck('TypeOfTravel','TYPE OF TRAVEL')
						//TRAVEL FARE
						//&& mandateCheck('txt_trvl_fromloc', 'DATE OF JOINING')
						//&& mandateCheck('txt_trvl_toloc','DATE OF TRANSFER')
						//&& mandateCheck('dp_trvl_trvl', 'AMOUNT')
						//&& mandateCheck('cb_trvl_hh', 'TRAVEL REQUEST NUMBER')
						//&& mandateCheck('cb_trvl_mm','TYPE OF TRAVEL')
						//&& mandateCheck('cb_trvl_mode', 'DATE OF JOINING')
						//&& mandateCheck('cb_trvl_class','DATE OF TRANSFER')
						//&& mandateCheck('txt_trvl_tcktno', 'AMOUNT')
						//&& mandateCheck('cb_trvl_paidby', 'TRAVEL REQUEST NUMBER')
						//&& mandateCheck('txt_trvl_amnt','TYPE OF TRAVEL')
						// SUMMARY
						)
						)
						{
							return false;
						}
						if(getNGValue("Trvlcount") == 0)
						{
                            alert('Kindly add atleast one Travel Fare details');
                            return false;
                        }
						if(getNGValue("Hotelcount") == 0)
						{
                            alert('Kindly add atleast one Hotel Fare details');
                            return false;
                        } 
						if(getNGValue("Dailycount") == 0)
						{
                            alert('Kindly add atleast one Daily Allowance details');
                            return false;
                        } 
						if(getNGValue("Conveycount") == 0)
						{
                            alert('Kindly add atleast one Conveyance details');
                            return false;
                        }
						if(getNGValue("Misccount") == 0)
						{
                            alert('Kindly add atleast one Miscellaneous details');
                            return false;
                        }  
						if(getNGValue("Medcount") == 0)
						{
                            alert('Kindly add atleast one Medical Expense details');
                            return false;
                        }
						if(!(
						 mandateCheck('TicketExpense', 'TICKET EXPENSE')
						&& mandateCheck('HotelExpense','HOTEL EXPENSE')
						&& mandateCheck('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck('Conveyance', 'CONVEYANCE')
						&& mandateCheck('Miscellaneous','MISCELLANEOUS')
						&& mandateCheck('MedicalExpense', 'MEDICAL EXPENSE')
						)
						)
						{
							return false;
						}
				}	
				alert("strSubcategory"+strSubcategory);
				if(strSubcategory=='Moving of Personal Effects')
				{
					if(getNGValue('Combo1')=='Yes')
					{
						alert("Check"+mandateCheck('RoadTax', 'ROAD TAX'))
						if (!(mandateCheck('RoadTax', 'ROAD TAX')))
						{
							setNGFocus(RoadTax);
							return false;
						}
					}
					if(getNGValue('Combo2')=='Yes')
					{
						if (!( 
                        mandateCheck('LossOnPreClosureLease', 'LOSS ON PRE CLOSURE LEASE')					
						)
						)
						{
							setNGFocus(LossOnPreClosureLease);
							return false;
						}
					}
					if(getNGValue('Combo4')=='Yes')
					{
						if (!( 
                        mandateCheck('OctroiPay', 'OCTROI PAY')					
						)
						)
						{
							setNGFocus(OctroiPay);
							return false;
						}
					}
					if(getNGValue('Combo5')=='Yes')
					{
						if (!( 
                        mandateCheck('PackMove', 'PACKERS AND MOVERS')					
						)
						)
						{
							setNGFocus(PackMove);
							return false;
						}
					}
					if(getNGValue('cb_mov_schlfee_yesno')=='Yes')
					{
						if (!( 
                        mandateCheck('cb_mov_schlfee_noofchild', 'NO OF CHILDREN')					
						)
						)
						{
							setNGFocus(cb_mov_schlfee_noofchild);
							return false;
						}
							if(getNGValue('cb_mov_schlfee_noofchild')=='1')
							{
								if (!( 
								mandateCheck('NameChild1', 'NAME OF CHILDREN1')	
								&&	mandateCheck('SchlfeeElbamnt', 'ELIGIBLE AMOUNT') 
								&&	mandateCheck('SchlfeeClaimamnt', 'CLAIMED AMOUNT')
								)
								)
								{
									return false;
								}
							}	
							if(getNGValue('cb_mov_schlfee_noofchild')=='2')
							{
								if (!( 
								mandateCheck('NameChild1', 'NAME OF CHILDREN1')	
								&&	mandateCheck('NameChild2', 'NAME OF CHILDREN2')
								&&	mandateCheck('SchlfeeElbamnt', 'ELIGIBLE AMOUNT') 
								&&	mandateCheck('SchlfeeClaimamnt', 'CLAIMED AMOUNT')
								)
								)
								{
									return false;
								}
							}	
						
					}
					
				}
				if(strSubcategory=='Brokerage Fee')
				{
					if (!( 
						 //BROKAGE FEE
                        mandateCheck('TypeOfTransfer', 'TYPE OF TRANSFER')
						&& mandateCheck('DateOfJoining', 'DATE OF JOINING')
						&& mandateCheck('DateOfTransfer','DATE OF TRANSFER')
						&& mandateCheck('Amount', 'AMOUNT')
						&& mandateCheck('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						&& mandateCheck('TypeOfTravel','TYPE OF TRAVEL')
						)
						)
						{
							return false;
						}
				}
				if(strSubcategory=='Joining Expense')
				{	
					/*frm_brokage_fees 
					frm_travel_fare
					frm_convey
					frm_misc
					frm_medical_expense
					frm_summary*/
					if (!( //BROKAGE FEE
                        mandateCheck('TypeOfTransfer', 'TYPE OF TRANSFER')
						&& mandateCheck('DateOfJoining', 'DATE OF JOINING')
						&& mandateCheck('DateOfTransfer','DATE OF TRANSFER')
						&& mandateCheck('Amount', 'AMOUNT')
						&& mandateCheck('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						&& mandateCheck('TypeOfTravel','TYPE OF TRAVEL')
						)
						)
						{
							return false;
						}
						if(getNGValue("Trvlcount") == 0)
						{
                            alert('Kindly add atleast one Travel Fare details');
                            return false;
                        }
						if(getNGValue("Conveycount") == 0)
						{
                            alert('Kindly add atleast one Conveyance details');
                            return false;
                        }
						if(getNGValue("Misccount") == 0)
						{
                            alert('Kindly add atleast one Miscellaneous details');
                            return false;
                        }  
						if(getNGValue("Medcount") == 0)
						{
                            alert('Kindly add atleast one Medical Expense details');
                            return false;
                        } 
						if(!( //summary
						mandateCheck('TicketExpense', 'TICKET EXPENSE')
						//&& mandateCheck('HotelExpense','HOTEL EXPENSE')
						//&& mandateCheck('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck('Conveyance', 'CONVEYANCE')
						&& mandateCheck('Miscellaneous','MISCELLANEOUS')
						&& mandateCheck('MedicalExpense', 'MEDICAL EXPENSE')
						)
						)
						{
							return false;
						}
				}
				if(strSubcategory=='Look and See Visit')
				{
					/*
					frm_family_info
					frm_brokage_fees 
					frm_travel_fare
					frm_hotel_fare
					frm_daily_allw
					frm_convey
					frm_misc
					frm_summary*/
					if(getNGValue("FmlyCount") == 0)
						{
                            alert('Kindly add atleast one Family details');
                            return false;
                        }	 
					if (!( 
					//BROKAGE FEE
                        mandateCheck('TypeOfTransfer', 'TYPE OF TRANSFER')
						&& mandateCheck('DateOfJoining', 'DATE OF JOINING')
						&& mandateCheck('DateOfTransfer','DATE OF TRANSFER')
						&& mandateCheck('Amount', 'AMOUNT')
						&& mandateCheck('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						&& mandateCheck('TypeOfTravel','TYPE OF TRAVEL')
						)
						)
						{
							return false;
						}
						if(getNGValue("Trvlcount") == 0)
						{
                            alert('Kindly add atleast one Travel Fare details');
                            return false;
                        } 
						if(getNGValue("Hotelcount") == 0)
						{
                            alert('Kindly add atleast one Hotel Fare details');
                            return false;
                        } 
						if(getNGValue("Dailycount") == 0)
						{
                            alert('Kindly add atleast one Daily Allowance details');
                            return false;
                        } 
						if(getNGValue("Conveycount") == 0)
						{
                            alert('Kindly add atleast one Conveyance details');
                            return false;
                        }
						if(getNGValue("Misccount") == 0)
						{
                            alert('Kindly add atleast one Miscellaneous details');
                            return false;
                        }
						if(!( //summary
						mandateCheck('TicketExpense', 'TICKET EXPENSE')
						&& mandateCheck('HotelExpense','HOTEL EXPENSE')
						&& mandateCheck('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck('Conveyance', 'CONVEYANCE')
						&& mandateCheck('Miscellaneous','MISCELLANEOUS')
						//&& mandateCheck('MedicalExpense', 'MEDICAL EXPENSE')
						)
						)
						{
							return false;
						}
				}
				if((strSubcategory=='Out of Pocket Expense')||(strSubcategory=='Relocation-Travel Expense'))
				{	
					 
					/*
					frm_family_info
					frm_brokage_fees 
					frm_travel_fare
					frm_daily_allw
					frm_convey
					frm_misc
					frm_summary*/
					if(getNGValue("FmlyCount") == 0)
						{
                            alert('Kindly add atleast one Family details');
                            return false;
                        }
					if (!(
						 //BROKAGE FEE
                        mandateCheck('TypeOfTransfer', 'TYPE OF TRANSFER')
						&& mandateCheck('DateOfJoining', 'DATE OF JOINING')
						&& mandateCheck('DateOfTransfer','DATE OF TRANSFER')
						&& mandateCheck('Amount', 'AMOUNT')
						&& mandateCheck('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						&& mandateCheck('TypeOfTravel','TYPE OF TRAVEL')
						)
						)
						{
							return false;
						}
						if(getNGValue("Trvlcount") == 0)
						{
                            alert('Kindly add atleast one Travel Fare details');
                            return false;
                        } 
						if(getNGValue("Dailycount") == 0)
						{
                            alert('Kindly add atleast one Daily Allowance details');
                            return false;
                        } 
						if(getNGValue("Conveycount") == 0)
						{
                            alert('Kindly add atleast one Conveyance details');
                            return false;
                        }
						if(getNGValue("Misccount") == 0)
						{
                            alert('Kindly add atleast one Miscellaneous details');
                            return false;
                        }
						if(!( //summary
						mandateCheck('TicketExpense', 'TICKET EXPENSE')
						&& mandateCheck('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck('Conveyance', 'CONVEYANCE')
						&& mandateCheck('Miscellaneous','MISCELLANEOUS')
						)
						)
						{
							return false;
						}
				}
				if(strSubcategory=='Relocation-TravelExpense-Own Vehicle')
				{
					/*
					frm_family_info
					frm_travel_fare
					frm_daily_allw
					frm_convey
					frm_misc
					frm_summary*/
					if(getNGValue("FmlyCount") == 0)
						{
                            alert('Kindly add atleast one Family details');
                            return false;
                        }
					if(getNGValue("Trvlcount") == 0)
						{
                            alert('Kindly add atleast one Travel Fare details');
                            return false;
                        } 
						if(getNGValue("Dailycount") == 0)
						{
                            alert('Kindly add atleast one Daily Allowance details');
                            return false;
                        } 
						if(getNGValue("Conveycount") == 0)
						{
                            alert('Kindly add atleast one Conveyance details');
                            return false;
                        }
						if(getNGValue("Misccount") == 0)
						{
                            alert('Kindly add atleast one Miscellaneous details');
                            return false;
                        }
						if(!( //summary
						mandateCheck('TicketExpense', 'TICKET EXPENSE')
						//&& mandateCheck('HotelExpense','HOTEL EXPENSE')
						&& mandateCheck('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck('Conveyance', 'CONVEYANCE')
						&& mandateCheck('Miscellaneous','MISCELLANEOUS')
						)
						)
						{
							return false;
						}
				}
				if((strSubcategory=='Self Education Scheme')||(strSubcategory=='Entertainment')||(strSubcategory=='Others'))
				{
					
					/*
					frm_ent_scheme
					*/
					//com.newgen.omniforms.formviewer.getNGValue
						if(getNGValue("EntCount") == 0)
						{
							//formObject.getItemCount("list_travel");
                            alert('Kindly add atleast one Entertainment details');
                            return false;
                        }
						
				}
		   return true;
		}
		
		else if ((activityName=='Scanning')) 
		{
			
			return true;
		}
		else if((activityName=='Manual_Initiation'))
		{
			return true;
		}
		
	}
	

}



//For event handing function

function eventDispatched_AP(pId, pEvent) 
{
	// alert("inside Event Dispatched Funtion");

	window.status = pId + "_" + pEvent.type;
	// alert(pEvent.type+" "+pEvent.srcElement.id);
	switch(pEvent.type)
    {           
       case 'click':
        {
            switch(pEvent.srcElement.id)
            {
				case 'btn_cmnthsty':	
                {				
				//Session id need to be captured here
                var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				//var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ID="+Sessionid+"&ProcessInstanceId="+Sessionid;
				var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ProcessInstanceId="+Pid1;
			    window.open(url,"","width=750,height=325");
			    return true;
				break;
				}
			   case 'btn_trnsdtl':
				{
				var Emp_Code=com.newgen.omniforms.formviewer.getNGValue("EmployeeCode");
                //alert("Sessionid :"+Emp_Code);
				var url="/webdesktop/CustomJSP/Transaction.jsp?ID1="+Emp_Code;
				//var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				//var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ProcessInstanceId="+Pid1;
			    window.open(url,"","width=750,height=325");
				return true;
				break;
			   }
			   case 'btn_Reject':
			   {
				    
				   if(!(mandateCheck('Comments', 'Comments')))
				   {
					   return false;
					   break;
				   }
				   if(!(mandateCheck('RejectReason', 'RejectReason')))
				   {
					   return false;
					   break;
				   }
				   return true;
				   break;
			   }
			   
			   case 'btn_Travel':
			   {
				   alert("Inside Travel");
				   var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				   var url="/webdesktop/CustomJSP/Travel_Xcel.jsp?ID1="+Pid1;
				    window.open(url,"","width=750,height=325");
				   return true;
				   break;
			   }
				
			}
			return true;
			//break;
		}
		case 'change':
		{
			switch (pEvent.srcElement.id)
			{
				
			}
			return true;
		}
		case 'focus':
        {
            switch (pEvent.srcElement.id) 
            {
                
            }
			
			return true;
        }
	}
	
}

function setNGValue(control, value) 
{
	com.newgen.omniforms.formviewer.setNGValue(control, value);
}

/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */





/*function eventDispatched_SP(pId, pEvent)
{
 
    window.status = pId + "_" + pEvent.type;
    //  alert('Inside Event dispatched function in SP');
    // alert(pEvent.type+" "+pEvent.srcElement.id);
    switch (pEvent.type) 
    {
        case 'click':
        {
            switch (pEvent.srcElement.id) 
            {
                case 'BtnInitiate':
                {
                    if (!(
                        mandateCheck('Location', 'LOCATION') 
                        && mandateCheck('Region', 'REGION') 
                        && mandateCheck('Entity', 'ENTITY') 
                        && mandateCheck('TypeOfRequest', 'TYPE OF REQUEST') 
                        && mandateCheck('FinancialYear', 'FINANCIAL YEAR') 
                        && mandateCheck('Period', 'PERIOD') 
                       // && mandateCheck('StatutoryLegislation', 'STATUTORY LEGISLATION') 
                       // && mandateCheck('PaymentFor', 'PAYMENT FOR') 
                        //&& mandateCheck('FinancialYear', 'FINANCIALYEAR') 
                        ))
                        {
                        return false;
                    }		
                    return true;
                    break;
                }
                
            }
        }
        case 'change':
        {
            switch (pEvent.srcElement.id) 
            {
                
            }
        }   
        case 'blur':
        {
            switch (pEvent.srcElement.id) 

            {
                
            }
        }
        
    }
}*/

function setNGFocus(Value)
{
    com.newgen.omniforms.formviewer.setNGFocus(Value);

}
function getNGValue(Value)
{
    return com.newgen.omniforms.formviewer.getNGValue(Value);
}
function setNGValue(control, value)
{
    com.newgen.omniforms.formviewer.setNGValue(control, value);
}

function getTop(Control)
{
    com.newgen.omniforms.formviewer.getTop(Control);
}
function setTop(Control, Value)
{
    com.newgen.omniforms.formviewer.setTop(Control, Value);
}
function setNGListIndex(control, i)
{
    com.newgen.omniforms.formviewer.setNGListIndex(control, i);
}
function NGClearSelection(control)
{
    com.newgen.omniforms.formviewer.NGAddDefaultItem(control);
}
function clear(control)
{
    com.newgen.omniforms.formviewer.clear(control);
}
function setHeight(control,i)
{
    com.newgen.omniforms.formviewer.setHeight(control,i);
}
function showError(control, value)
{
    com.newgen.omniforms.util.showError(control, value);
}
function mandateCheck(controlName, messageString)
{
    // alert('Mandate Check Running ...');
    if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--')
    {
        alert('PLEASE ENTER THE ' + messageString);
        //showError('controlName','PLEASE ENTER THE ' + messageString);       
        setNGFocus(controlName);
        return false;
    }
    return true;

}
	
