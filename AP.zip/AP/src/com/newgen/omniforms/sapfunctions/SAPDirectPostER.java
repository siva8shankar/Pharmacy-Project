/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author Nanjundamoorthy.b
 */
public class SAPDirectPostER implements Serializable {

    SAPCall objSAPCall = new SAPCall();
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfDt = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat SAPDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat SAPDateFormat2 = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat NGDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();

    public String NONPO_DirectPosting(String strInput1) {
        String outputResult = "FAIL";
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {
            StringBuffer BAPIHeader = new StringBuffer();
            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            String strUserName = formObject.getUserName();

            CommonObj.writeToLog(1, "IN SAP Function:NONPO_DirectPosting DMS No:::>>>>" + winame, winame);
            String Newgenwiname = winame;//.replaceAll("AP-","");
            Newgenwiname = Newgenwiname.replaceAll("-Payments", "");
            Newgenwiname = Newgenwiname.replaceAll("-Process", "");
            Newgenwiname = Newgenwiname.replaceAll("AP-", "");
            int widlength = Newgenwiname.length();
            if (widlength > 15) {
                Newgenwiname = Newgenwiname.substring(widlength - 15, widlength);
            }
            Integer intNewgenwiname=Integer.parseInt(Newgenwiname);
            //winame=winame.substring(0,winame.length() -8);
            CommonObj.writeToLog(1, "IN SAP Function:NONPO_DirectPosting DMS No 2 SAP::Newgenwiname:>>>>" + Newgenwiname, winame);
            CommonObj.writeToLog(1, "IN SAP Function:NONPO_DirectPosting DMS No 2 SAP::intNewgenwiname:>>>>" + intNewgenwiname, winame);
            String strCurrentDate = formObject.getNGValue("CurrentDateTime");
            CommonObj.writeToLog(1, "IN SAP Function:strCurrentDate::" + strCurrentDate, winame);
            boolean blnExecute = false;
            String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
            String strSubcategory1 = formObject.getNGValue("SubCategory1");

            String strDateOfReq = formObject.getNGValue("DateOfReq");
            String strCompanyCode = formObject.getNGValue("CompanyCode");
            String strEmpCode = formObject.getNGValue("EmployeeCode");
            String strFiscalYr = formObject.getNGValue("FiscalYr");
            String strVendorCode = formObject.getNGValue("VendCode");
            String strPO_NO = formObject.getNGValue("PONumber");
            String strEmpName = formObject.getNGValue("EmployeeName");
            String strDesaigntion = formObject.getNGValue("Designation");
            String strDept = formObject.getNGValue("Department");
            String strGrade = formObject.getNGValue("Grade");
            String strCostCenter = formObject.getNGValue("CostCenter");
            String strBusinessArea = formObject.getNGValue("BusinessArea");
            String strOrgLoc = formObject.getNGValue("OriginalLocation");
            String strTotalAmount = formObject.getNGValue("TotalAmount");

            String strMobileNo = formObject.getNGValue("MobileNo");
            String strBillDate = formObject.getNGValue("BillDate");
            String strEligibleAmount = formObject.getNGValue("EligibleAmount");
            String strBlackBerryCharges = formObject.getNGValue("BlackBerryCharges");
            String strFromPeriod = formObject.getNGValue("FromPeriod");
            String strToPeriod = formObject.getNGValue("ToPeriod");
            String strServiceProvider = formObject.getNGValue("ServiceProvider");
            String strBillPlan = formObject.getNGValue("BillPlan");
            String strBillValueLessTax = formObject.getNGValue("BillValueLessTax");
            String strServiceTax_Billvalue = formObject.getNGValue("ServiceTax_Billvalue");
            String strValueOfPersonalCalls = formObject.getNGValue("ValueOfPersonalCalls");
            String strServiceTax_ValueOfPersonalCalls = formObject.getNGValue("ServiceTax_ValueOfPersonalCalls");

            String qryBusinessPlace = "select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='" + strBusinessArea + "'";
            String strBusinessPlace = CommonObj.DB_QueryExecuteSelect1(qryBusinessPlace);
            CommonObj.writeToLog(2, "qryBusinessPlace:" + qryBusinessPlace, winame);
            CommonObj.writeToLog(2, "strBusinessPlace:" + strBusinessPlace, winame);
            
            //objSAPCall.getconnectionstring();
            BAPIHeader.append("<DOCUMENTHEADER>");
            BAPIHeader.append("<BUS_ACT>RMRP</BUS_ACT>");
            BAPIHeader.append("<USERNAME>"+strUserName+"</USERNAME>");
            BAPIHeader.append("<HEADER_TXT>"+strEmpName+"</HEADER_TXT>");
            BAPIHeader.append("<COMP_CODE>"+strCompanyCode+"</COMP_CODE>");
            BAPIHeader.append("<DOC_DATE>"+SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq))+"</DOC_DATE>");
            BAPIHeader.append("<PSTNG_DATE>"+SAPDateFormat2.format(date)+"</PSTNG_DATE>");
            BAPIHeader.append("<FISC_YEAR>"+strFiscalYr+"</FISC_YEAR>");
            BAPIHeader.append("<FIS_PERIOD>00</FIS_PERIOD>");
            BAPIHeader.append("<DOC_TYPE>KR</DOC_TYPE>");
            BAPIHeader.append("<REF_DOC_NO>"+intNewgenwiname+"</REF_DOC_NO>");
            BAPIHeader.append("</DOCUMENTHEADER>");

            String headerdataxml = "";
            String AccGL="";
            String AccPayable="";
            String CurAmt="";
            String CurAmtCredit="";
            Integer intLineNo = 2;
            CurAmtCredit = CurAmtCredit + "<CURRENCYAMOUNT><ITEMNO_ACC>0000000001</ITEMNO_ACC>"
                    + "<CURRENCY>INR</CURRENCY>"
                    + "<AMT_DOCCUR>-" + strTotalAmount + "</AMT_DOCCUR>"                    
                    + "</CURRENCYAMOUNT>";
            
            if(strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
                
            AccPayable = AccPayable + "<ACCOUNTPAYABLE><ITEMNO_ACC>0000000001</ITEMNO_ACC>"
                    + "<VENDOR_NO>" + CommonObj.appendzeros(formObject.getNGValue("VendorCode")) + "</VENDOR_NO>"
                    + "<BUS_AREA>" + strBusinessArea + "</BUS_AREA>"
                    + "<BLINEDATE>" + SAPDateFormat2.format((Date) NGDateFormat.parse(strBillDate)) + "</BLINEDATE>"
                    + "<ITEM_TEXT>" + strEmpName +" -" +dateFormat.format((Date) NGDateFormat.parse(strFromPeriod)) + " To " + dateFormat.format((Date) NGDateFormat.parse(strToPeriod))+ "</ITEM_TEXT>"
                    //+ "<ITEM_TEXT>Reimb.of mobile-" + dateFormat.format((Date) NGDateFormat.parse(strFromPeriod)) + " To " + dateFormat.format((Date) NGDateFormat.parse(strToPeriod))+"</ITEM_TEXT>"
                    + "</ACCOUNTPAYABLE>";
                
            AccGL = AccGL + "<ACCOUNTGL><ITEMNO_ACC>0000000002</ITEMNO_ACC>"
//                    + "<GL_ACCOUNT>0000420103</GL_ACCOUNT>"
                    + "<GL_ACCOUNT>0045120103</GL_ACCOUNT>"//HANA
                    + "<ITEM_TEXT>Reimb.of mobile-" + dateFormat.format((Date) NGDateFormat.parse(strFromPeriod)) + " To " + dateFormat.format((Date) NGDateFormat.parse(strToPeriod))+ "</ITEM_TEXT>"
                    + "<COSTCENTER>"+ strCostCenter +"</COSTCENTER>"
                    + "</ACCOUNTGL>";
            
            CurAmt = CurAmt + "<CURRENCYAMOUNT><ITEMNO_ACC>0000000002</ITEMNO_ACC>"
                    + "<CURRENCY>INR</CURRENCY>"
                    + "<AMT_DOCCUR>" + strTotalAmount + "</AMT_DOCCUR>"                    
                    + "</CURRENCYAMOUNT>";
            blnExecute = true;
            }//End Of Mobile Re-Imbursement
            else if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")) {
                
                AccPayable = AccPayable + "<ACCOUNTPAYABLE><ITEMNO_ACC>0000000001</ITEMNO_ACC>"
                        + "<VENDOR_NO>" + CommonObj.appendzeros(formObject.getNGValue("VendorCode")) + "</VENDOR_NO>"
                        + "<BUS_AREA>" + strBusinessArea + "</BUS_AREA>"
                        + "<BLINEDATE>" + SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)) + "</BLINEDATE>"
                        + "<ITEM_TEXT>Cr: Entertainment-" + strEmpName +"</ITEM_TEXT>"
                        + "</ACCOUNTPAYABLE>";
                
                int Entertainment = formObject.getItemCount("list_Entertain");
                CommonObj.writeToLog(2, "Entertainment Count:" + Entertainment, winame);
                CommonObj.writeToLog(2, "list_Entertain:" + (formObject.getSelectedIndex("list_Entertain")), winame);
                CommonObj.writeToLog(2, "getNGListView:list_Entertain:" + formObject.getNGListView("list_Entertain"), winame);
                List<List<String>> ControlObject = CommonObj.getListViewValueInList(formObject, "list_Entertain");
                CommonObj.writeToLog(2, "ControlObj==" + ControlObject, winame);
                
                if (Entertainment > 0) {
                    for (Integer i = 0; i < ControlObject.size(); i++) {
                        String sValue0 = ControlObject.get(i).get(0);
                        String sValue1 = ControlObject.get(i).get(1);
                        String sValue2 = ControlObject.get(i).get(2);
                        String sValue3 = ControlObject.get(i).get(3);
                        String sValue4 = ControlObject.get(i).get(4);
                        String sValue5 = ControlObject.get(i).get(5);
                        
                        AccGL = AccGL + "<ACCOUNTGL><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<GL_ACCOUNT>"+CommonObj.appendzeros(sValue4)+"</GL_ACCOUNT>"
                        + "<ITEM_TEXT>Dr: Entertainment-" + strEmpName+ "</ITEM_TEXT>"
                        + "<COSTCENTER>" + strCostCenter + "</COSTCENTER>"
                        + "</ACCOUNTGL>";
                        
                        CurAmt = CurAmt + "<CURRENCYAMOUNT><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<CURRENCY>INR</CURRENCY>"
                        + "<AMT_DOCCUR>" + sValue5 + "</AMT_DOCCUR>"
                        + "</CURRENCYAMOUNT>";
                        
                        intLineNo++; 
                        blnExecute = true;
                    }}
            }//End of Entertainment & Others
            else if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")) {
                
                AccPayable = AccPayable + "<ACCOUNTPAYABLE><ITEMNO_ACC>0000000001</ITEMNO_ACC>"
                        + "<VENDOR_NO>" + CommonObj.appendzeros(formObject.getNGValue("VendorCode")) + "</VENDOR_NO>"
                        + "<BUS_AREA>" + strBusinessArea + "</BUS_AREA>"
                        + "<BLINEDATE>" + SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)) + "</BLINEDATE>"
                        + "<ITEM_TEXT>Re-Imbursement of Travel Expense-" + strEmpName +"</ITEM_TEXT>"
                        + "</ACCOUNTPAYABLE>";
                
                int list_travel = formObject.getItemCount("list_travel");
                CommonObj.writeToLog(2, "list_travel Count:" + list_travel, winame);
                CommonObj.writeToLog(2, "list_Entertain:" + (formObject.getSelectedIndex("list_travel")), winame);
                CommonObj.writeToLog(2, "getNGListView:list_travel:" + formObject.getNGListView("list_travel"), winame);
                List<List<String>> ControlObject = CommonObj.getListViewValueInList(formObject, "list_travel");
                CommonObj.writeToLog(2, "ControlObj==" + ControlObject, winame);
                
                if (list_travel > 0) {
                    for (Integer i = 0; i < ControlObject.size(); i++) {
                        String sValue0 = ControlObject.get(i).get(0);
                        String sValue1 = ControlObject.get(i).get(1);
                        String sValue2 = ControlObject.get(i).get(2);
                        String sValue3 = ControlObject.get(i).get(3);
                        String sValue4 = ControlObject.get(i).get(4);
                        String sValue5 = ControlObject.get(i).get(5);
                        String sValue8 = ControlObject.get(i).get(8);
                        String sValue9 = ControlObject.get(i).get(9);
                        
//                        String strGLCode = "0000420040";
                        String strGLCode = "0045090102";//HANA
                        String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                        if (strTypeOfTravel.equalsIgnoreCase("Domestic") && (sValue5.equalsIgnoreCase("Train") || sValue5.equalsIgnoreCase("Bus") || sValue5.equalsIgnoreCase("Self"))) {
//                            strGLCode = "0000420916";
                            strGLCode = "0045090101";//HANA
                        } else if (strTypeOfTravel.equalsIgnoreCase("Domestic") && sValue5.equalsIgnoreCase("Air")) {
//                            strGLCode = "0000420039";
                            strGLCode = "0045090100";//HANA
                        } else if (strTypeOfTravel.equalsIgnoreCase("Domestic") && sValue5.equalsIgnoreCase("Others")) {
//                            strGLCode = "0000420040";
                            strGLCode = "0045090102";//HANA
                        } else if (strTypeOfTravel.equalsIgnoreCase("International") && (sValue5.equalsIgnoreCase("Train") || sValue5.equalsIgnoreCase("Bus") || sValue5.equalsIgnoreCase("Self"))) {
//                            strGLCode = "0000420041";
                            strGLCode = "0045090200";//HANA
                        } else if (strTypeOfTravel.equalsIgnoreCase("International") && sValue5.equalsIgnoreCase("Air")) {
//                            strGLCode = "0000420041";
                            strGLCode = "0045090200";//HANA
                        } else if (strTypeOfTravel.equalsIgnoreCase("International") && sValue5.equalsIgnoreCase("Others")) {
//                            strGLCode = "0000420042";
                            strGLCode = "0045090201";//HANA
                        }
                        
                        if(!sValue8.equalsIgnoreCase("Company")){
                        AccGL = AccGL + "<ACCOUNTGL><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<GL_ACCOUNT>"+strGLCode+"</GL_ACCOUNT>"
                        + "<ITEM_TEXT>Dr: Travel Expense-" + strEmpName+ "</ITEM_TEXT>"
                        + "<COSTCENTER>" + strCostCenter + "</COSTCENTER>"
                        + "</ACCOUNTGL>";
                        
                        CurAmt = CurAmt + "<CURRENCYAMOUNT><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<CURRENCY>INR</CURRENCY>"
                        + "<AMT_DOCCUR>" + sValue9 + "</AMT_DOCCUR>"
                        + "</CURRENCYAMOUNT>";                        
                        }
                        intLineNo++; 
                        blnExecute = true;
                    }}//End of Travel Fare Template
                    CommonObj.writeToLog(2, "End of Travel Fare", winame);
                    
                   int list_hotel = formObject.getItemCount("list_hotel");
                    CommonObj.writeToLog(2, "list_hotel Count:" + list_hotel, winame);
                    List<List<String>> list_hotelObject = CommonObj.getListViewValueInList(formObject, "list_hotel");
                    CommonObj.writeToLog(2, "list_hotelObject==" + list_hotelObject, winame);
                    CommonObj.writeToLog(2, "list_hotelObject Count:" + list_hotelObject.size(), winame);
                    if (list_hotel > 0) {
                        for (Integer i = 0; i < list_hotelObject.size(); i++) {
                            
                        String sValue0 = list_hotelObject.get(i).get(0);
                        String sValue1 = list_hotelObject.get(i).get(1);
                        String sValue2 = list_hotelObject.get(i).get(2);
                        String sValue3 = list_hotelObject.get(i).get(3);
                        String sValue4 = list_hotelObject.get(i).get(4);
                        
//                        String strGLCode = "0000420040";
                        String strGLCode = "0045090102";//HANA
                        
                        AccGL = AccGL + "<ACCOUNTGL><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<GL_ACCOUNT>"+strGLCode+"</GL_ACCOUNT>"
                        + "<ITEM_TEXT>Dr: Travel Expense-" + strEmpName+ "</ITEM_TEXT>"
                        + "<COSTCENTER>" + strCostCenter + "</COSTCENTER>"
                        + "</ACCOUNTGL>";
                        
                        CurAmt = CurAmt + "<CURRENCYAMOUNT><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<CURRENCY>INR</CURRENCY>"
                        + "<AMT_DOCCUR>" + sValue3 + "</AMT_DOCCUR>"
                        + "</CURRENCYAMOUNT>";
                        
                        intLineNo++; 
                        blnExecute = true;
                    }
                }//End of Hotel Fare
                CommonObj.writeToLog(2, "End of Hotel Fare", winame);
                
                int list_daily = formObject.getItemCount("list_daily");
                List<List<String>> list_dailyObject = CommonObj.getListViewValueInList(formObject, "list_daily");
                if (list_daily > 0) {
                    for (Integer i = 0; i < list_dailyObject.size(); i++) {
                        
                        ListViewItems LV3 = new ListViewItems();
                        String sValue0 = list_dailyObject.get(i).get(0);
                        String sValue1 = list_dailyObject.get(i).get(1);
                        String sValue2 = list_dailyObject.get(i).get(2);
                        String sValue3 = list_dailyObject.get(i).get(3);
                        String sValue4 = list_dailyObject.get(i).get(4);
                        String sValue5 = list_dailyObject.get(i).get(5);
                        
//                        String strGLCode = "0000420040";
                        String strGLCode = "0045090102";//HANA
                        
                        AccGL = AccGL + "<ACCOUNTGL><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<GL_ACCOUNT>"+strGLCode+"</GL_ACCOUNT>"
                        + "<ITEM_TEXT>Dr: Travel Expense-" + strEmpName+ "</ITEM_TEXT>"
                        + "<COSTCENTER>" + strCostCenter + "</COSTCENTER>"
                        + "</ACCOUNTGL>";
                        
                        CurAmt = CurAmt + "<CURRENCYAMOUNT><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<CURRENCY>INR</CURRENCY>"
                        + "<AMT_DOCCUR>" + sValue3 + "</AMT_DOCCUR>"
                        + "</CURRENCYAMOUNT>";
                        
                        intLineNo++; 
                        blnExecute = true;
                    }
                }//End of DA
                CommonObj.writeToLog(2, "End of DA", winame);
                
                int list_convey = formObject.getItemCount("list_convey");
                List<List<String>> list_conveyObject = CommonObj.getListViewValueInList(formObject, "list_convey");
                if (list_convey > 0) {
                    for (Integer i = 0; i < list_conveyObject.size(); i++) {
                        String sValue0 = list_conveyObject.get(i).get(0);
                        String sValue1 = list_conveyObject.get(i).get(1);
                        String sValue2 = list_conveyObject.get(i).get(2);
                        String sValue3 = list_conveyObject.get(i).get(3);
                        String sValue4 = list_conveyObject.get(i).get(4);   
                        
//                        String strGLCode = "0000420040";
                        String strGLCode = "0045090102";//HANA
                        
                        AccGL = AccGL + "<ACCOUNTGL><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<GL_ACCOUNT>"+strGLCode+"</GL_ACCOUNT>"
                        + "<ITEM_TEXT>Dr: Travel Expense-" + strEmpName+ "</ITEM_TEXT>"
                        + "<COSTCENTER>" + strCostCenter + "</COSTCENTER>"
                        + "</ACCOUNTGL>";
                        
                        CurAmt = CurAmt + "<CURRENCYAMOUNT><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<CURRENCY>INR</CURRENCY>"
                        + "<AMT_DOCCUR>" + sValue3 + "</AMT_DOCCUR>"
                        + "</CURRENCYAMOUNT>";
                        
                        intLineNo++; 
                        blnExecute = true;                        
                    }
                }//End of Conveyance
                CommonObj.writeToLog(2, "End of Conveyance", winame);
                
                int list_misc = formObject.getItemCount("list_misc");
                List<List<String>> list_miscObject = CommonObj.getListViewValueInList(formObject, "list_misc");
                if (list_misc > 0) {
                    for (Integer i = 0; i < list_miscObject.size(); i++) {
                        
                        ListViewItems LV3 = new ListViewItems();
                        String sValue0 = list_miscObject.get(i).get(0);
                        String sValue1 = list_miscObject.get(i).get(1);
                        String sValue2 = list_miscObject.get(i).get(2);
                        String sValue3 = list_miscObject.get(i).get(3);
                        
//                        String strGLCode = "0000420040";
                        String strGLCode = "0045090102";//HANA
                        float mistamount = Float.parseFloat(sValue2);
                        CommonObj.writeToLog(2, "Misc Amount2 after convering to float:" + mistamount, winame);
                        if (mistamount >= 500) {
                            CommonObj.writeToLog(2, "Misc Amount2 >=500", winame);
//                            strGLCode = "0000420063";
                            strGLCode = "0045121912";//HANA
                        } else {
//                            strGLCode = "0000420040";
                            strGLCode = "0045090102";//HANA
                        }
                        
                        AccGL = AccGL + "<ACCOUNTGL><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<GL_ACCOUNT>"+strGLCode+"</GL_ACCOUNT>"
                        + "<ITEM_TEXT>Dr: Travel Expense-" + strEmpName+ "</ITEM_TEXT>"
                        + "<COSTCENTER>" + strCostCenter + "</COSTCENTER>"
                        + "</ACCOUNTGL>";
                        
                        CurAmt = CurAmt + "<CURRENCYAMOUNT><ITEMNO_ACC>"+CommonObj.appendzeros(Integer.toString(intLineNo))+"</ITEMNO_ACC>"
                        + "<CURRENCY>INR</CURRENCY>"
                        + "<AMT_DOCCUR>" + sValue2 + "</AMT_DOCCUR>"
                        + "</CURRENCYAMOUNT>";
                        
                        intLineNo++; 
                        blnExecute = true;                        
                    }
                }//End of MISC
                CommonObj.writeToLog(2, "End of Misc", winame);                
                
            }//End of Travel Expense
            else if (strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {
                
                AccPayable = AccPayable + "<ACCOUNTPAYABLE><ITEMNO_ACC>0000000001</ITEMNO_ACC>"
                        + "<VENDOR_NO>" + CommonObj.appendzeros(formObject.getNGValue("VendorCode")) + "</VENDOR_NO>"
                        + "<BUS_AREA>" + strBusinessArea + "</BUS_AREA>"
                        + "<BLINEDATE>" + SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)) + "</BLINEDATE>"
                        + "<ITEM_TEXT>"+ strSubcategory1 + " - " + strEmpName +"</ITEM_TEXT>"
                        + "</ACCOUNTPAYABLE>";
                
//                String strGLCode = "0000220029";
                String strGLCode = "0012070206";//HANA
                
                AccGL = AccGL + "<ACCOUNTGL><ITEMNO_ACC>0000000002</ITEMNO_ACC>"
                    + "<GL_ACCOUNT>"+strGLCode+"</GL_ACCOUNT>"
                    + "<ITEM_TEXT>"+strSubcategory1 + " - " + strEmpName+"</ITEM_TEXT>"
                    + "<COSTCENTER>"+ strCostCenter +"</COSTCENTER>"
                    + "</ACCOUNTGL>";
            
                CurAmt = CurAmt + "<CURRENCYAMOUNT><ITEMNO_ACC>0000000002</ITEMNO_ACC>"
                    + "<CURRENCY>INR</CURRENCY>"
                    + "<AMT_DOCCUR>" + strTotalAmount + "</AMT_DOCCUR>"                    
                    + "</CURRENCYAMOUNT>";
                blnExecute = true; 
            }//End of Employee Advances
            
            if (blnExecute) {   
            String strInpuBAPI="";            
            strInpuBAPI = getWFSAPInvokerwithTable(formObject, "ZBAPI_ACC_DOCUMENT_POST", BAPIHeader.toString(), AccPayable + AccGL + CurAmtCredit + CurAmt);
            CommonObj.writeToLog(1, "strInpuBAPI: NON PO Direct Posting" + strInpuBAPI, winame);
            BAPIOutput = objSAPCall.callServer(strInpuBAPI);            
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
                if (XmlResponse.getVal("MainCode").equals("0")) {
                    WFXmlList XMLListMessage = XmlResponse.createList("Parameters", "ExportParameters");
                    String strFIDOC_NO = XMLListMessage.getVal("OBJ_KEY").trim();
                    strFIDOC_NO=strFIDOC_NO.substring(0, Math.min(strFIDOC_NO.length(), 10));
                    CommonObj.writeToLog(1, "strFIDOC_NO:"+strFIDOC_NO, winame);
                    
                    WFXmlList XMLListMessage2 = XmlResponse.createList("TableParameters", "RETURN");
                    String SAPMESSAGE="Error in SAP Posting";
                    SAPMESSAGE=XMLListMessage2.getVal("MESSAGE").trim();                    
                    CommonObj.writeToLog(1, "SAPMESSAGE>>>:"+SAPMESSAGE, winame);
                    
                    if (SAPMESSAGE.contains("Document posted successfully") && !strFIDOC_NO.equalsIgnoreCase("") && !strFIDOC_NO.equalsIgnoreCase("$") ) {
                        formObject.setNGValue("SAPDocRefNo", strFIDOC_NO);
                        formObject.setNGValue("PostBySAP", formObject.getUserName());
                        formObject.setNGValue("PostingDate", NGDateFormat.format(date));
                        formObject.RaiseEvent("WFSave");
                        outputResult = "SUCCESS";
                    }
                    else{
                        outputResult = SAPMESSAGE;
                    }
                    
                } else {
                    CommonObj.writeToLog(1, "BAPIInput ZBAPI_ACC_DOCUMENT_POST:Failed Execution", winame);
                    outputResult="Exception";
                    throw new ValidatorException(new FacesMessage("Parking Failed..!!!!", "Comments"));
                }
            }
            return outputResult;
            
            } catch (Exception e) {
            CommonObj.writeToLog(3,"Error In SAPFunc=SAPDirectPostER :" + e.getMessage(), winame);
            return e.getMessage();
        }
    }
    
    public String getWFSAPInvokerwithTable(FormReference formObject, String SAPFunction, String strHeaderData, String strTableData) {

        StringBuilder strWFSAPInvoker = new StringBuilder();
        
        try {        
            strWFSAPInvoker.append(objSAPCall.getconnectionstring());
        } catch (IOException ex) {
            Logger.getLogger(SAPDirectPostER.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        strWFSAPInvoker.append("<SAPFunctionName>").append(SAPFunction).append("</SAPFunctionName>");
        strWFSAPInvoker.append("<Parameters>");
        strWFSAPInvoker.append("<ImportParameters>").append(strHeaderData).append("</ImportParameters>");
        strWFSAPInvoker.append("<TableParameters>").append(strTableData).append("</TableParameters>");
        strWFSAPInvoker.append("</Parameters>");
        strWFSAPInvoker.append("</WFSAPInvokeFunction_Input>");

        return strWFSAPInvoker.toString();
    }
}
