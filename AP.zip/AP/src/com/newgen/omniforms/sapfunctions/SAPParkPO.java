/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Nanjudamoorthy.b
 */
public class SAPParkPO implements Serializable {

    SAPCall objSAPCall = new SAPCall();
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfDt = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat SAPDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat SAPDateFormat2 = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat NGDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();

    public String PO_Parking(String strInput1) {
        String outputResult = "FAIL";
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            String winame = formConfig.getConfigElement("ProcessInstanceId");
            
        try {
            
            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            CommonObj.writeToLog(1, "IN SAP Function:PO_Parking DMS No:::>>>>" + winame, winame);
            String Newgenwiname = winame;//.replaceAll("AP-","");
            Newgenwiname = Newgenwiname.replaceAll("-Payments", "");
            Newgenwiname = Newgenwiname.replaceAll("-Process", "");
            Newgenwiname = Newgenwiname.replaceAll("AP-", "");
            int widlength = Newgenwiname.length();
            if (widlength > 15) {
                Newgenwiname = Newgenwiname.substring(widlength - 15, widlength);
            }            
            //double dNewgenwiname=Double.parseDouble(Newgenwiname);
            CommonObj.writeToLog(1, "IN SAP Function:PO_Parking DMS No 2 SAP::Newgenwiname:>>>>" + Newgenwiname, winame);
            String strCurrentDate = formObject.getNGValue("CurrentDateTime");
            CommonObj.writeToLog(1, "IN SAP Function:strCurrentDate::" + strCurrentDate, winame);
            String strCompanyCode = formObject.getNGValue("CompanyCode");
            String strFiscalYr = formObject.getNGValue("FiscalYr");
            String strVendorCode = formObject.getNGValue("VendCode");
            String strPO_NO = formObject.getNGValue("PONumber");
            String strEmpName = formObject.getNGValue("EmployeeName");
            String strDesaigntion = formObject.getNGValue("Designation");
            String strDept = formObject.getNGValue("Department");
            String strGrade = formObject.getNGValue("Grade");
            String strCostCenter = formObject.getNGValue("CostCenter");
            String strBusinessArea = formObject.getNGValue("BusinessArea");
            String strOrgLoc = formObject.getNGValue("OriginalLocation");
            
            String strRegion = formObject.getNGValue("Region");
            
            
            String strBusiSec = formObject.getNGValue("BusiSec");
            String strStateCode = formObject.getNGValue("StateCode");            
            String strTotalAmount = formObject.getNGValue("TotInvoiceAmnt");            
            String strInvoiceNo = formObject.getNGValue("InvoiceNo");
            String strInvoiceDate= formObject.getNGValue("InvoiceDate");
            String strBaselineDt= formObject.getNGValue("BaselineDt");
            String strText= formObject.getNGValue("Text");
            String strPORef= formObject.getNGValue("PORef");
            String strIndicate= formObject.getNGValue("Indicate");
            String sCurrency="INR";
            
            int LineitemPO = formObject.getItemCount("list_po_invoice");
            CommonObj.writeToLog(2, "LineitemPO Count:" + LineitemPO, winame);
            CommonObj.writeToLog(2, "list_PO:" + (formObject.getSelectedIndex("list_po_invoice")), winame);
            CommonObj.writeToLog(2, "getNGListView:list_PO:" + formObject.getNGListView("list_po_invoice"), winame);
            if(LineitemPO>0){ 
            String LineItem[] = CommonObj.getRowValue(formObject, "list_po_invoice", 0);
            strBusiSec=LineItem[9].trim();
            strBusinessArea=LineItem[10].trim();
            sCurrency=LineItem[19].trim();
            }
            
            BAPIInput.append(objSAPCall.getconnectionstring());
            CommonObj.writeToLog(1, "IN SAP Function:PO_Parking:SAPClient:" + objSAPCall.SAPClient, winame);
            BAPIInput.append("<SAPFunctionName>ZMM_SIMULATE_PARK</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            //BAPIInput.append("<GS_INPUT>MIRO</GS_INPUT>");
            BAPIInput.append("<GS_INPUT>");
            BAPIInput.append("<BUKRS>"+strCompanyCode+"</BUKRS>");
            BAPIInput.append("<BLDAT>"+SAPDateFormat2.format((Date) NGDateFormat.parse(strInvoiceDate))+"</BLDAT>");
            //BAPIInput.append("<BLDAT>"+SAPDateFormat2.format(date)+"</BLDAT>");
            BAPIInput.append("<XBLNR>"+strInvoiceNo+"</XBLNR>");
            BAPIInput.append("<BUPLA>"+strBusiSec+"</BUPLA>");
            //BAPIInput.append("<SECCO>"+strBusiSec+"</SECCO>");
            BAPIInput.append("<ZFBDT>"+SAPDateFormat2.format((Date) NGDateFormat.parse(strBaselineDt))+"</ZFBDT>");
            BAPIInput.append("<GSBER>"+strBusinessArea+"</GSBER>");
            BAPIInput.append("<BKTXT>"+strText+"</BKTXT>");
            BAPIInput.append("<MWSKZ></MWSKZ>");
            //BAPIInput.append("<WAERS>INR</WAERS>");
            BAPIInput.append("<WAERS>"+sCurrency+"</WAERS>");
            BAPIInput.append("<CATEGORY>"+strPORef+"</CATEGORY>");
            BAPIInput.append("<INDICATOR>"+strIndicate+"</INDICATOR>");
            BAPIInput.append("</GS_INPUT>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("<TableParameters>");
                
                if(LineitemPO>0){
                Integer intLineNo = 001;
                for (int li = 0; li < LineitemPO; li++) {
                String LineItemData[] = CommonObj.getRowValue(formObject, "list_po_invoice", li);
                
                        String sValue0 = LineItemData[0].trim();
                        String sValue1 = LineItemData[1].trim();
                        String sValue2 = LineItemData[2].trim();
                        String sValue3 = LineItemData[3].trim();
                        String sValue4 = LineItemData[4].trim();
                        String sValue5 = LineItemData[5].trim();
                        String sValue6 = LineItemData[6].trim();
                        String sValue7 = LineItemData[7].trim();
                        String sValue8 = LineItemData[8].trim();
                        String sValue9 = LineItemData[9].trim();
                        String sValue10 = LineItemData[10].trim();
                        String sValue11 = LineItemData[11].trim();
                        String sValue12 = LineItemData[12].trim();
                        String sValue13 = LineItemData[13].trim();
                        String sValue14 = LineItemData[14].trim();
                        String sValue15 = LineItemData[15].trim();
                        String sValue16 = LineItemData[16].trim();
                        String sValue17 = LineItemData[17].trim();
                        String sValue18 = LineItemData[18].trim();
                        String sValue19 = LineItemData[19].trim();
                        String sValue20 = LineItemData[20].trim();
                        String sValue21 = LineItemData[21].trim();
                        
                        BAPIInput.append("<GT_GRN>");
                        ListViewItems LV3 = new ListViewItems();
                        
                        LV3.addColumn(sValue0, "EBELN");
                        LV3.addColumn(sValue3, "EBELP");
                        LV3.addColumn(sValue1, "REF_DOC");
                        LV3.addColumn(strFiscalYr, "REF_DOC_YEAR");
                        //LV3.addColumn("2017", "REF_DOC_YEAR");
                        LV3.addColumn(CommonObj.appendzerosN(Integer.toString(intLineNo),4), "REF_DOC_IT");
                        intLineNo++;
                        LV3.addColumn(sValue11, "TAX_CODE");
                        //LV3.addColumn("IR", "TAX_CODE");
                        LV3.addColumn(sValue7, "ITEM_AMOUNT");
                        LV3.addColumn(sValue5, "QUANTITY");
                        //LV3.addColumn("KG", "PO_UNIT");
                        LV3.addColumn(sValue18, "PO_UNIT");
                        LV3.addColumn("PO PARKING", "SGTXT");
                        //LV3.addColumn("", "SHEET_NO");
                        LV3.addColumn("0000000000", "SHEET_ITEM");
                        LV3.addColumn(sValue20, "KSCHL");
                        LV3.addColumn(sValue21, "POTYPE");
                        BAPIInput.append(LV3.builder.toString());
                        BAPIInput.append("</GT_GRN>");
                        
                }//End of For
                }//End of IF
                /*
                List<List<String>> list_selected_po = CommonObj.getListViewValueInList2(formObject, "list_po_invoice");
                CommonObj.writeToLog(2, "list_PO in Btn Park==" + list_selected_po, winame);
                
                if(LineitemPO>0){
                Integer intLineNo = 001;
                    for (Integer i = 0; i < list_selected_po.size(); i++) {
                        CommonObj.writeToLog(2, "intLineNo:" + intLineNo, winame);
                        BAPIInput.append("<GT_GRN>");
                        ListViewItems LV3 = new ListViewItems();

                        String sValue0 = list_selected_po.get(i).get(0);
                        String sValue1 = list_selected_po.get(i).get(1);
                        String sValue2 = list_selected_po.get(i).get(2);
                        String sValue3 = list_selected_po.get(i).get(3);
                        String sValue4 = list_selected_po.get(i).get(4);
                        String sValue5 = list_selected_po.get(i).get(5);
                        String sValue6 = list_selected_po.get(i).get(6);
                        String sValue11 = list_selected_po.get(i).get(11);
                        String sValue12 = list_selected_po.get(i).get(12);
                        String sValue18 = list_selected_po.get(i).get(18);

                        LV3.addColumn(sValue0, "EBELN");
                        LV3.addColumn(CommonObj.appendzerosN(Integer.toString(intLineNo),5), "EBELP");
                        LV3.addColumn(sValue1, "REF_DOC");
                        LV3.addColumn(strFiscalYr, "REF_DOC_YEAR");
                        LV3.addColumn(CommonObj.appendzerosN(Integer.toString(intLineNo),4), "REF_DOC_IT");
                        intLineNo++;
                        //LV3.addColumn(sValue11, "TAX_CODE");
                        LV3.addColumn("IR", "TAX_CODE");
                        LV3.addColumn(strTotalAmount, "ITEM_AMOUNT");
                        LV3.addColumn(sValue5, "QUANTITY");
                        //LV3.addColumn("KG", "PO_UNIT");
                        LV3.addColumn(sValue18, "PO_UNIT");
                        LV3.addColumn("PO PARKING", "SGTXT");
                        //LV3.addColumn("", "SHEET_NO");
                        LV3.addColumn("0000000000", "SHEET_ITEM");                        
                        BAPIInput.append(LV3.builder.toString());
                        BAPIInput.append("</GT_GRN>");                       
                    }
                }
                */
            
            BAPIInput.append("</TableParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            CommonObj.writeToLog(1, "BAPIInput PO_Parking:" + BAPIInput.toString(), winame);
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("Parameters", "ExportParameters");                
                String strFIDOC_NO = XMLListMessage.getVal("GS_FIDOC").trim();                    
                    CommonObj.writeToLog(1,"strFIDOC_NO==" + strFIDOC_NO, winame);
                    if (!strFIDOC_NO.equalsIgnoreCase("")) {
                        formObject.setNGValue("SAPDocRefNo", strFIDOC_NO);
                        formObject.setNGValue("ParkedBy", formObject.getUserName());
                        formObject.setNGValue("ParkingDate", NGDateFormat.format(date));
                        formObject.RaiseEvent("WFSave");
                        outputResult = "SUCCESS";
                    }
                
            }
            return outputResult;
        } catch (Exception e) {
            CommonObj.writeToLog(3,"Error In SAPPark: PO_Parking =" + e.getMessage(), winame);
            return e.getMessage();
        }
    }

    public boolean PO_Parking_DocumentNo(String strInput1) throws IOException {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            String winame = formConfig.getConfigElement("ProcessInstanceId");
            
        try {
            
            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            CommonObj.writeToLog(1, "IN SAP Function:Parking_DocumentNo:::>>>>", winame);
            CommonObj.writeToLog(1, "strUserName:" + strInput1, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZFI_FETCH_DOCUMENT_NO</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<GS_BELNR>" + strInput1 + "</GS_BELNR>");
            BAPIInput.append("<GS_GJAHR>" + strInput1 + "</GS_GJAHR>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "GT_OUTPUT");
                String strSAPDocNo = XMLListMessage.getVal("GT_OUTPUT").trim();
                CommonObj.writeToLog(1,"strSAPDocNo==" + strSAPDocNo, winame);
            }
            return true;
        } catch (Exception e) {
            CommonObj.writeToLog(3,"Error In SAPFunc =" + e.getMessage(), winame);
            return false;
        }
    }

    public boolean Parking_DueDate(String strInput1) throws IOException {
        
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            String winame = formConfig.getConfigElement("ProcessInstanceId");
            
        try {
            
            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            CommonObj.writeToLog(1, "IN SAP Function:Parking_DueDate:::>>>>", winame);
            CommonObj.writeToLog(1, "strUserName:" + strInput1, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZFI_CALCULATE_DUE_DATE</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<GS_MBLNR>" + strInput1 + "</GS_MBLNR>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "GT_OUTPUT");
                String strSAPDueDate = XMLListMessage.getVal("GS_DUEDATE").trim();
                CommonObj.writeToLog(1,"strSAPDueDate==" + strSAPDueDate, winame);
            }
            return true;
        } catch (Exception e) {
            CommonObj.writeToLog(3,"Error In SAPFunc =" + e.getMessage(), winame);
            return false;
        }
    }
}
