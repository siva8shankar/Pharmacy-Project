/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

/**
 *
 * @author
 */
public class ListViewItems {

    StringBuilder builder = new StringBuilder();

    public ListViewItems() {
    }

    public void addColumnvalue(String value) {
        if (value == null) {
            value = "";
        }
        builder.append("<SubItem>");
        builder.append(value);
        builder.append("</SubItem>");
    }

    public void addColumn(String value, String fieldname) {
        if (value == null) {
            value = "";
        }
        builder.append("<" + fieldname + ">");
        builder.append(value);
        builder.append("</" + fieldname + ">");
    }

    public String getXML() {
        return "<ListItem>" + builder.toString() + "</ListItem>";
    }

    public String getPOSTINGXML() {
        return builder.toString();
    }

    public String getXML(String Fieldname) {
        return "<" + Fieldname + ">" + builder.toString() + "</" + Fieldname + ">";
    }

    public static String getSampleXMLOfColumns(int value) {
        StringBuilder sb = new StringBuilder();
        sb.append("<ListItems><ListItem><Tag></Tag>");
        while (value-- > 0) {
            sb.append("<SubItem></SubItem>");
        }
        sb.append("</ListItem></ListItems>");
        return sb.toString();
    }
}
