/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;

import com.newgen.dmsapi.DMSXmlList;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author
 */
public class SAPApprovalMatrix implements Serializable {

    SAPCall objSAPCall = new SAPCall();
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    
    public String ERApprovalMatrix(String strUserName) throws IOException{
            String outputResult = "F";
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {
            
            String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
            String strSubcategory=formObject.getNGValue("SubCategory1");
            if(strSubcategory.equalsIgnoreCase("Travel Request"))
            strSubcategory="Travel Expense";    
            String sTotalAmount=formObject.getNGValue("TotalAmount");
            Float fTotal = 0.0f;
            if(!sTotalAmount.equalsIgnoreCase(""))
            fTotal = Float.parseFloat(sTotalAmount);
            int i = 1;
            int maxlevel = 0;
            String Squery_Grade_Limit="";
            String GradeAmount="";
//            Map<String, String> Appr_Matrix = new HashMap<String, String>();
//            Appr_Matrix.clear();
            String sApproversName = "";
            String sApproversGrade="";
            String Squery = "";
            String UserIndex = "";
            sApproversName=formObject.getNGValue("SAPApprovers");
            sApproversGrade=formObject.getNGValue("SAPApproversGr");
            
            String arrayApproversName[] = sApproversName.split("~");
            maxlevel = arrayApproversName.length;
            CommonObj.writeToLog(2,"Approver matrix maxlevel=" + maxlevel,winame);
            formObject.setNGValue("MaxAppLevel", maxlevel);
            Squery = "SELECT UserIndex,MailId FROM PDBUser WITH(NOLOCK) WHERE UserName=";
            for (String a : arrayApproversName) 
            {
                UserIndex = CommonObj.DB_QueryExecute1(Squery + "'" + a.trim() + "'");
                CommonObj.writeToLog(2,"Squery:" + Squery + "'" + a.trim() + "'",winame);
                try{
                    
                String[] FieldValue_array=CommonObj.DB_QueryExecute(Squery + "'" + a.trim() + "'");
                CommonObj.writeToLog(2,"FieldValue_array[1]:" + FieldValue_array[1],winame);       
                if(FieldValue_array[1].contains("null")){
                    //formObject.setNGValue("Appr"+i+"email", "");
                }else{
                formObject.setNGValue("Appr"+i+"email", FieldValue_array[1]);
                }
                formObject.setNGValue("App" + i+ "index", a.trim().trim());
                CommonObj.writeToLog(2,"Appr"+i+"email ID:" + FieldValue_array[1],winame);
                }catch(Exception e){
                    CommonObj.writeToLog(3,"Approver:"+a.trim()+" is Not Present in DMS",winame);
                    return "Approver:"+a.trim()+" is Not Present in DMS";
                }
                i++;
            }
          
            //ApproverMatrix GradeText Amount passing Query added by bala G on 24-12-2016
            String[] arrayApproversGrade=sApproversGrade.split("~");
            //Squery_Grade_Limit="SELECT ApproverLimit from ext_ap_amountcalculation where grade=";
            Squery_Grade_Limit="SELECT ApproverLimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='"+strSubcategory+"' and grade=";
            i=0;
            String S_Amount="";    
            Float fGradeAmount0=0.0f;
            Float fGradeAmount1=0.0f;
            Float fGradeAmount2=0.0f;
            Float fGradeAmount3=0.0f;
            Float fGradeAmount4=0.0f;
            Float fGradeAmount5=0.0f;
            Float fGradeAmount6=0.0f;
            Float fGradeAmount7=0.0f;
            CommonObj.writeToLog(2,"fGradeAmount1="+fGradeAmount1,winame);
            for (String Amt_val:arrayApproversGrade)
            {   
                try{
                //S_Amount = CommonObj.DB_QueryExecuteFloat(Squery_Grade_Limit + "'" + Amt_val.trim() + "'");
                S_Amount = CommonObj.DB_QueryExecuteSelect1(Squery_Grade_Limit + "'" + Amt_val.trim() + "'");
                //if (maxlevel == i) // Last element
                //{
                //    GradeAmount += S_Amount.toString();
                //} else // Other elements
                //{
                    GradeAmount += S_Amount.toString() + "~";
                //}                
                if(i==0)fGradeAmount0=Float.parseFloat(S_Amount);
                if(i==1)fGradeAmount1=Float.parseFloat(S_Amount);
                if(i==2)fGradeAmount2=Float.parseFloat(S_Amount);
                if(i==3)fGradeAmount3=Float.parseFloat(S_Amount);
                if(i==4)fGradeAmount4=Float.parseFloat(S_Amount);
                if(i==5)fGradeAmount5=Float.parseFloat(S_Amount);
                if(i==6)fGradeAmount6=Float.parseFloat(S_Amount);
                if(i==7)fGradeAmount7=Float.parseFloat(S_Amount); 
                }catch(Exception e){
                    CommonObj.writeToLog(3,"Approver="+arrayApproversName[i]+", ApproverGrade:"+Amt_val.trim()+" is Not Present in DMS",winame);
                    return "Approver="+arrayApproversName[i]+", Approver Grade:"+Amt_val.trim()+" is Not Present in DMS";
                }                
                i++;
            }            
            CommonObj.writeToLog(2,"fGradeAmount0="+fGradeAmount0,winame);
            CommonObj.writeToLog(2,"fGradeAmount1="+fGradeAmount1,winame);
            CommonObj.writeToLog(2,"fGradeAmount2="+fGradeAmount2,winame);
            CommonObj.writeToLog(2,"fGradeAmount3="+fGradeAmount3,winame);
            CommonObj.writeToLog(2,"fGradeAmount4="+fGradeAmount4,winame);
            CommonObj.writeToLog(2,"fGradeAmount5="+fGradeAmount5,winame);
            CommonObj.writeToLog(2,"fGradeAmount6="+fGradeAmount6,winame);
            CommonObj.writeToLog(2,"GradeAmount="+GradeAmount,winame);
            formObject.setNGValue("Grade_Test", GradeAmount);
            String[] arrayGradeAmount=GradeAmount.split("~");
            
            if (strTypeofinvoice.equalsIgnoreCase("Travel Request") || strTypeofinvoice.equalsIgnoreCase("Travel Expense")){
                formObject.setNGValue("MaxAppLevel", "1");
                outputResult="S";
            }
            else if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")){
                int j=0;
                for (j=0; j<maxlevel; j++) {
                Float fGradeAmount=Float.parseFloat(arrayGradeAmount[j]);
                if(fTotal<fGradeAmount ||fTotal.equals(fGradeAmount) ){  
                    CommonObj.writeToLog(2,"fTotal<fGradeAmount or equal,Total="+fTotal+" GradeAmount="+arrayGradeAmount[j],winame);
                    formObject.setNGValue("MaxAppLevel", j+1);
                    break;
                }
                else if(fTotal>fGradeAmount){
                    CommonObj.writeToLog(2,"fTotal>fGradeAmount,Total="+fTotal+" GradeAmount="+arrayGradeAmount[j],winame);
                    formObject.setNGValue("MaxAppLevel", j+1);   
                    
                }
                else {
                CommonObj.writeToLog(2,"else,Total="+fTotal+" GradeAmount="+arrayGradeAmount[j],winame);
                }
                
                }
                outputResult="S";
            }
            //Added by Nanjunda Moorthy to skip same approval limit user id
            else if(strTypeofinvoice.equalsIgnoreCase("Employee Advances") ||strTypeofinvoice.equalsIgnoreCase("Relocation")){
                CommonObj.writeToLog(2,"Inside Skip Logic:::",winame);
                int j=0;
                int k=1;
                String sApprovers[] = sApproversName.split("~");
                String sGrades[]=sApproversGrade.split("~");
                
                String sGradeAmount2="";
                String query_Grade_Limit="SELECT ApproverLimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='"+strSubcategory+"' and grade="; 
                
                CommonObj.writeToLog(2,"Inside Skip Logic: Before For Loop maxlevel:"+maxlevel,winame);
                for (j=0; j<maxlevel; j++) {
                    CommonObj.writeToLog(2,"Inside Skip Logic: For Loop",winame);
                    CommonObj.writeToLog(2,"sGradeAmount[j]="+arrayGradeAmount[j],winame);
                        Float fGradeAmount=Float.parseFloat(arrayGradeAmount[j]);
                        
                        if(fTotal<=fGradeAmount){
                            formObject.setNGValue("App" + k+ "index", sApprovers[j].trim());
                            formObject.setNGValue("MaxAppLevel", k); 
                        break;
                        }
                        else if(fTotal>fGradeAmount){                            
                            if (j == 0) {
                                formObject.setNGValue("App" + k + "index", sApprovers[j].trim());
                                formObject.setNGValue("MaxAppLevel", k);
                                k++;
                            }
                            else{
                                int m=j;
                                Float fPrevGradeAmount=Float.parseFloat(arrayGradeAmount[m-1]);
                                CommonObj.writeToLog(2, "fPrevGradeAmount::=" + fPrevGradeAmount, winame);
                                CommonObj.writeToLog(2, "fGradeAmount::" + fGradeAmount, winame);
                                //if(fPrevGradeAmount == fGradeAmount){
                                if(fPrevGradeAmount.equals(fGradeAmount)){
                                    CommonObj.writeToLog(2, "Next Current Approval Amount is equal to Previus Level Approval Amount" , winame);
                                }
                                else
                                {
                                    CommonObj.writeToLog(2, "Current Approval Amount and Previus Level Approval Amount is Different" , winame);
                                    formObject.setNGValue("App" + k+ "index", sApprovers[j].trim());
                                    formObject.setNGValue("MaxAppLevel", k);
                                    k++;
                                }
                            }
                        }
                       CommonObj.writeToLog(2, "End of for Loop j==" + j, winame);                    
                       CommonObj.writeToLog(2, "End of for Loop k==" + k, winame);                
                    //k++;
                   
                }
                outputResult="S";
            }
            else{
                outputResult="Approval matrix not found for the Type of Invoice";
            }
            
            return outputResult;
        }
         catch (Exception e) {
            //System.out.println("Error ERApprovalMatrix=" + e.getMessage());
             CommonObj.writeToLog(3, "Error ERApprovalMatrix=" + e.getMessage(), winame); 
            return e.getMessage();
        }
    }
    public boolean BAPI_ERApprovalMatrix(String strUserName) throws IOException {
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            String winame = formConfig.getConfigElement("ProcessInstanceId");
        
        try {
            
            String strSubcategory=formObject.getNGValue("SubCategory1");
            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse xmlResponse = null;
            CommonObj.writeToLog(1, "IN SAP Function:SAPApprovalMatrix:::", winame);
            CommonObj.writeToLog(1, "strUserName:" + strUserName, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZHR_ENTERTAINMENT_EXPENSES</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<USR_ID>" + strUserName + "</USR_ID>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            CommonObj.writeToLog(1, "Input for SAPApprovalMatrix: " + BAPIInput.toString(), winame);
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            CommonObj.writeToLog(1, "BAPI: SAPApprovalMatrix Output:::::" + BAPIOutput, winame);
            WFXmlResponse xmlresponse = new WFXmlResponse(BAPIOutput.trim());
            WFXmlList XMLListMessage = xmlresponse.createList("TableParameters", "IT_PERNR_DET");
            int i = 0;
            int maxlevel = 0;
            String Appr_name = "";
            String sGrade_Text=""; //Added Bala G  on 24-12-2016 
            String sGrade_TextName="";
            String Squery_Grade_Limit="";
            String GradeAmount="";
            Map<String, String> Appr_Matrix = new HashMap<String, String>();
            Appr_Matrix.clear();
            String Approvers_name = "";
            String Squery = "";
     
            String OtherValues = "";
            String L1 = "";
            String L2 = "";
            String L3 = "";
            String L4 = "";
            String L5 = "";
            String L6 = "";
            String L7 = "";
            String L8 = "";
            String UserIndex = "";
            String UserIndexRet[] = null;
            String list12 = "";
            CommonObj.writeToLog(1, "BAPI: SAPApprovalMatrix xmlList:" + XMLListMessage, winame);
            for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) 
            {
                if (i == 0) 
                {
                    CommonObj.writeToLog(2,"Logged user info need to skip this step", winame);
                } 
                else 
                {
                    CommonObj.writeToLog(1,"level=" + i + "***Corresponding ApproverLevel=" + XMLListMessage.getVal("LEVEL1") + "****And Approver ID=" + XMLListMessage.getVal("REPORT_MNGR_NAME"),winame);
                    Appr_name = XMLListMessage.getVal("USERID");
                    if (Appr_name != null && !Appr_name.equalsIgnoreCase("")) //Normal case
                    {
                        Approvers_name += XMLListMessage.getVal("USERID") + "~";
                        OtherValues += XMLListMessage.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + XMLListMessage.getVal("USERID") + "~~Designation" + XMLListMessage.getVal("GRADE_TEXT") + ";;;";
                    } else //in case approver is null it would be consider as no approver
                    {
                        CommonObj.writeToLog(2,"Inside No Approvers", winame);
                        Appr_name = "NoApprovers";
                        Approvers_name += Appr_name + "~";
                        OtherValues += XMLListMessage.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + Appr_name + "~~Designation" + XMLListMessage.getVal("GRADE_TEXT") + ";;;";
                    }
                    //Added Bala G on 24-12-2016 for Apporver Matrix limit check for each level of approver
                    sGrade_Text= XMLListMessage.getVal("GRADE_TEXT"); //It will return GRADE_TEXT List
                    if(sGrade_Text!=null && !sGrade_Text.equalsIgnoreCase("")) //normal case
                    {
                        sGrade_TextName+= sGrade_Text+"~";
                    }
                    else
                    {
                       sGrade_Text="NoEntry" ;
                       sGrade_TextName+= sGrade_Text+"~";
                    }
                    
                }

                i++;
            }

            CommonObj.writeToLog(2,"Aprpovers Name=" + Approvers_name, winame);
            CommonObj.writeToLog(2,"Others Details=" + OtherValues, winame);
            CommonObj.writeToLog(2,"sGrade_TextName="+sGrade_TextName, winame);
            String a1[] = Approvers_name.split("~");
            maxlevel = a1.length;
            CommonObj.writeToLog(2,"Approver matrix maxlevel=" + maxlevel, winame);
            formObject.setNGValue("MaxAppLevel", maxlevel);
            Squery = "SELECT userindex FROM PDBUser WITH (NOLOCK) WHERE UserName=";
            for (String a : a1) 
            {
                UserIndex = CommonObj.DB_QueryExecute1(Squery + "'" + a.trim() + "'");
                if (maxlevel == i) // Last element
                {
                    list12 += UserIndex.toString();
                } else // Other elements
                {
                    list12 += UserIndex.toString() + "~";
                }
                i++;
            }
            CommonObj.writeToLog(2,"list of index=" + list12, winame);
            String App_Index[] = list12.split("~");
            //
            //ApproverMatrix GradeText Amount passing Query added by bala G on 24-12-2016
            String Grade_Amount[]=sGrade_TextName.split("~");
            //Squery_Grade_Limit="SELECT ApproverLimit from ext_ap_amountcalculation where grade=";
            Squery_Grade_Limit="SELECT ApproverLimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='"+strSubcategory+"' and grade=";
            i=0;
            String S_Amount="";
            for (String Amt_val:Grade_Amount)
            {
                S_Amount = CommonObj.DB_QueryExecute1(Squery_Grade_Limit + "'" + Amt_val.trim() + "'");
                if (maxlevel == i) // Last element
                {
                    GradeAmount += S_Amount.toString();
                } else // Other elements
                {
                    GradeAmount += S_Amount.toString() + "~";
                }
                i++;
            }
            CommonObj.writeToLog(2,"GradeAmount="+GradeAmount, winame);
            formObject.setNGValue("Grade_Test", GradeAmount);
            CommonObj.writeToLog(2,"After GradeAmount set", winame);
            //
            
            int j = 1;
            CommonObj.writeToLog(2,"App_Index size=" + App_Index.length, winame);
            for (String Index1 : App_Index) //Approval MATRIX Assign
            {
                CommonObj.writeToLog(2,"Inside App Matrix set function=" + Index1, winame);
                if (j == 1) {
                    formObject.setNGValue("App1index", Index1);
                } else if (j == 2) {
                    formObject.setNGValue("App2index", Index1);
                } else if (j == 3) {
                    formObject.setNGValue("App3index", Index1);
                } else if (j == 4) {
                    formObject.setNGValue("App4index", Index1);
                } else if (j == 5) {
                    formObject.setNGValue("App5index", Index1);
                } else if (j == 6) {
                    formObject.setNGValue("App6index", Index1);
                } else if (j == 7) {
                    formObject.setNGValue("App7index", Index1);
                } else if (j == 8) {
                    formObject.setNGValue("App8index", Index1);
                }
                j++;
            }
            CommonObj.writeToLog(2, "After Approval matrix set", winame);
            return true;

        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error inApproval Matrix=" + e.getMessage(), winame);
            return false;
        }
    }//End ofBAPI_ERApprovalMatrix
}
