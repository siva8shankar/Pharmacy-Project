/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.cabinet.IFormCabinetList;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import com.newgen.omniforms.xmlviewerapi.IFormCallBroker;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Properties;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;

/**
 *
 * @author NanjundaMoorthy
 */
public class SAPCall implements Serializable {

    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    public static String SAPHostName = "";
    public static String SAPInstance = "";
    public static String SAPClient = "";
    public static String SAPUserName = "";
    public static String SAPPassword = "";
    public static String SAPLanguage = "";

    public String getconnectionstring() throws FileNotFoundException, IOException {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        CommonObj.writeToLog(2,"In getconnectionstring SAP", winame);
        String strIniFilepath = System.getProperty("user.dir") + "\\SAP_Details\\SAPConnections.ini";
        CommonObj.writeToLog(2,"strIniFilepath: " + strIniFilepath, winame);
        File fileinipath = new File(strIniFilepath);
        String InstanceName = "";
        FileInputStream fistream = new FileInputStream(fileinipath);
        Properties prop = new Properties();
        prop.load(fistream);
        SAPHostName = prop.getProperty(InstanceName + "SAPHostName").trim();
        SAPInstance = prop.getProperty(InstanceName + "SAPInstance").trim();
        SAPClient = prop.getProperty(InstanceName + "SAPClient").trim();
        SAPUserName = prop.getProperty(InstanceName + "SAPUserName").trim();
        SAPPassword = prop.getProperty(InstanceName + "SAPPassword").trim();
        SAPLanguage = prop.getProperty(InstanceName + "SAPLanguage").trim();
        StringBuffer connectionstring = new StringBuffer();
        connectionstring.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        connectionstring.append("<WFSAPInvokeFunction_Input>");
        connectionstring.append("<Option>WFSAPInvokeFunction</Option>");
        //SAP Connection String
        connectionstring.append("<SAPConnect>");
        connectionstring.append("<SAPHostName>").append(SAPHostName).append("</SAPHostName>");
        connectionstring.append("<SAPInstance>").append(SAPInstance).append("</SAPInstance>");
        connectionstring.append("<SAPClient>").append(SAPClient).append("</SAPClient>");
        connectionstring.append("<SAPUserName>").append(SAPUserName).append("</SAPUserName>");
        connectionstring.append("<SAPPassword>").append(SAPPassword).append("</SAPPassword>");
        connectionstring.append("<SAPLanguage>").append(SAPLanguage).append("</SAPLanguage>");
        connectionstring.append("</SAPConnect>");
        return connectionstring.toString();
    }

    public String callServer(String xml) throws Exception {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String output = "";
        xml=xml.replaceAll("&", "&amp;");
        //System.out.println("Input XML :==== " + xml);
        CommonObj.writeToLog(1, "BAPI Call Execution Start============================================================================================:", winame);
        CommonObj.writeToLog(1, "BAPI Input:" + xml, winame);
        CommonObj.writeToLog(1,"Input XML Engine Name:==== " + formObject.getWFEngineName(), winame);
        CommonObj.writeToLog(1,"Input XML Port:==== " + IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName()).getM_strServerIP(), winame);
        CommonObj.writeToLog(1,"Input XML Port:==== " + Integer.parseInt(IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName()).getM_strServerPort()), winame);
        IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName());
        output = IFormCallBroker.execute(xml, IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName()).getM_strServerIP(), Integer.parseInt(IFormCabinetList.GetCabinetDetails(formObject.getWFEngineName()).getM_strServerPort()));

        CommonObj.writeToLog(1, "BAPI Output:" + output, winame);
        CommonObj.writeToLog(1, "BAPI Call Execution End==============================================================================================:", winame);
        String mainCode = new WFXmlResponse(output).getVal("MainCode");
        if (mainCode == null || mainCode.length() == 0) {
            mainCode = new WFXmlResponse(output).getVal("Status");
        }
        if (mainCode == null || !((mainCode.equalsIgnoreCase("0")) || (mainCode.equalsIgnoreCase("18")))) {
            /* throw new Exception("\n Error in request\nOutput XML : \n"
             + output + "\n\n");*/
        }
        output = output.replaceAll("&amp;", "&");
        output = output.replaceAll("'", "`");
        //System.out.println("Output XML  AFTER SPL CHAR CHECK:::: " + output);
        return output;

    }
}
