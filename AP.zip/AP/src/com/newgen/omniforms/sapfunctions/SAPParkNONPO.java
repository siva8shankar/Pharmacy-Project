/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author Nanjundamoorthy.b
 */
public class SAPParkNONPO implements Serializable {

    SAPCall objSAPCall = new SAPCall();
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfDt = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat SAPDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat SAPDateFormat2 = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat NGDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();

    public String ParkingNONPO_VP(String strInput1){
        String outputResult = "FAIL";
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {
            
            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            String steUserName = formObject.getUserName();

            CommonObj.writeToLog(1, "IN SAP Function:NONPO_Parking DMS No:::>>>>" + winame, winame);
            String Newgenwiname = winame;//.replaceAll("AP-","");
            Newgenwiname = Newgenwiname.replaceAll("-Payments", "");
            Newgenwiname = Newgenwiname.replaceAll("-Process", "");
            int widlength = Newgenwiname.length();
            if (widlength > 15) {
                Newgenwiname = Newgenwiname.substring(widlength - 15, widlength);
            }
            //winame=winame.substring(0,winame.length() -8);
            CommonObj.writeToLog(1, "IN SAP Function:NONPO_Parking DMS No 2 SAP::Newgenwiname:>>>>" + Newgenwiname, winame);
            String strCurrentDate = formObject.getNGValue("CurrentDateTime");
            CommonObj.writeToLog(1, "IN SAP Function:strCurrentDate::" + strCurrentDate, winame);
            boolean blnExecute=false;
            String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
            String strSubcategory1 = formObject.getNGValue("SubCategory1");
            
            String strDateOfReq= formObject.getNGValue("DateOfReq");     
            String strCompanyCode = formObject.getNGValue("CompanyCode");
            String strEmpCode = formObject.getNGValue("EmployeeCode");
            String strFiscalYr = formObject.getNGValue("FiscalYr");
            String strVendorCode = formObject.getNGValue("VendCode");
            String strPO_NO = formObject.getNGValue("PONumber");
            String strEmpName = formObject.getNGValue("EmployeeName");
            String strDesaigntion = formObject.getNGValue("Designation");
            String strDept = formObject.getNGValue("Department");
            String strGrade = formObject.getNGValue("Grade");
            String strCostCenter = formObject.getNGValue("CostCenter");
            String strBusinessArea = formObject.getNGValue("BusinessArea");
            String strOrgLoc = formObject.getNGValue("OriginalLocation"); 
            
            String strTotalAmount = formObject.getNGValue("TotInvoiceAmnt");            
            String strBillDate= formObject.getNGValue("InvoiceDate");
            
            
            String qryBusinessPlace="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+strBusinessArea+"'";
            String strBusinessPlace=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlace); 
            CommonObj.writeToLog(2, "qryBusinessPlace:" + qryBusinessPlace, winame);
            CommonObj.writeToLog(2, "strBusinessPlace:" + strBusinessPlace, winame);

            BAPIInput.append(objSAPCall.getconnectionstring());
            CommonObj.writeToLog(1, "IN SAP Function:NONPO_Parking:SAPClient:" + objSAPCall.SAPClient, winame);
            BAPIInput.append("<SAPFunctionName>ZPRELIMINARY_POSTING_FB01</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<I_TCODE>FV60</I_TCODE>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("<TableParameters>");
            BAPIInput.append("<T_BKPF>");
            ListViewItems LVI = new ListViewItems();
            LVI.addColumn(strCompanyCode, "BUKRS");
            LVI.addColumn(strFiscalYr, "GJAHR");
            LVI.addColumn("AD", "BLART");
            
            LVI.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strBillDate)), "BLDAT");
            LVI.addColumn(SAPDateFormat2.format(date), "BUDAT");
            LVI.addColumn("00", "MONAT");
            LVI.addColumn("FV60", "TCODE");
            LVI.addColumn(Newgenwiname, "XBLNR");
            LVI.addColumn(steUserName, "BKTXT");
            LVI.addColumn("INR", "WAERS");
            LVI.addColumn("INR", "HWAER");
            LVI.addColumn("V", "BSTAT");            
            BAPIInput.append(LVI.builder.toString());
            BAPIInput.append("</T_BKPF>");
            
            int Entertainment = formObject.getItemCount("list_nonpo");
            CommonObj.writeToLog(2, "Entertainment Count:" + Entertainment, winame); 
            CommonObj.writeToLog(2,"list_Entertain:"+(formObject.getSelectedIndex("list_nonpo")),winame);
            CommonObj.writeToLog(2,"getNGListView:list_Entertain:"+formObject.getNGListView("list_nonpo"),winame);
            List<List<String>> ControlObject = CommonObj.getListViewValueInList(formObject, "list_nonpo");                         
            CommonObj.writeToLog(2,"ControlObj=="+ControlObject,winame);
            
            if(Entertainment>0){
            for (Integer i = 0; i < ControlObject.size(); i++) { 
            String sValue0=ControlObject.get(i).get(0);
            String sValue1=ControlObject.get(i).get(1);
            String sValue2=ControlObject.get(i).get(2);
            String sValue3=ControlObject.get(i).get(3);
            String sValue4=ControlObject.get(i).get(4);
            String sValue5=ControlObject.get(i).get(5); 
//            
//            System.out.println("sValue0=="+sValue0);
//            System.out.println("sValue1=="+sValue1);
//            System.out.println("sValue2=="+sValue2);
//            System.out.println("sValue3=="+sValue3);
//            System.out.println("sValue4=="+sValue4);
//            System.out.println("sValue5=="+sValue5);
                
            BAPIInput.append("<T_BSEG>");            
            ListViewItems LV2 = new ListViewItems();
            LV2.addColumn(objSAPCall.SAPClient, "MANDT");
            LV2.addColumn(strCompanyCode, "BUKRS");
            LV2.addColumn(strFiscalYr, "GJAHR");
            LV2.addColumn("001", "BUZEI");
            LV2.addColumn("31", "BSCHL");
            LV2.addColumn("K", "KOART");
            LV2.addColumn("H", "SHKZG");
            LV2.addColumn(sValue4, "GSBER");
            LV2.addColumn(strTotalAmount, "DMBTR");
            LV2.addColumn(strTotalAmount, "WRBTR");
            LV2.addColumn(strTotalAmount, "PSWBT");            
            LV2.addColumn("NON PO Parking", "SGTXT");
//            LV2.addColumn("0000420103", "HKONT");
            LV2.addColumn("0045120103", "HKONT");//HANA
//            CommonObj.writeToLog(2,"strBillDate:"+strBillDate,winame); 
//            CommonObj.writeToLog(2,"VendorCode:"+CommonObj.appendzeros(formObject.getNGValue("VendorCode")),winame); 
//            CommonObj.writeToLog(2,"strBillDate in SAP Format:"+SAPDateFormat2.format((Date) NGDateFormat.parse(strBillDate)),winame); 
            LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "LIFNR");
            LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strBillDate)), "ZFBDT");
            String qryBusinessPlaceLI="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+sValue4+"'";
            String strBusinessPlaceLI=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlaceLI);
            LV2.addColumn(strBusinessPlaceLI, "BUPLA");
            LV2.addColumn(strBusinessPlaceLI, "SECCO");
            BAPIInput.append(LV2.builder.toString());
            BAPIInput.append("</T_BSEG>");
            break;
            }
            
            Integer intLineNo=2;
            for (Integer i = 0; i < ControlObject.size(); i++) { 
            CommonObj.writeToLog(2,"intLineNo:"+intLineNo,winame); 
            BAPIInput.append("<T_BSEG>");
            ListViewItems LV3 = new ListViewItems();
            
            String sValue0=ControlObject.get(i).get(0);
            String sValue1=ControlObject.get(i).get(1);
            String sValue2=ControlObject.get(i).get(2);
            String sValue3=ControlObject.get(i).get(3);
            String sValue4=ControlObject.get(i).get(4);
            String sValue5=ControlObject.get(i).get(5); 
            String sValue6=ControlObject.get(i).get(6);
            String sValue7=ControlObject.get(i).get(7);
            String sValue8=ControlObject.get(i).get(8);
            
//            System.out.println("sValue0=="+sValue0);
//            System.out.println("sValue1=="+sValue1);
//            System.out.println("sValue2=="+sValue2);
//            System.out.println("sValue3=="+sValue3);
//            System.out.println("sValue4=="+sValue4);
//            System.out.println("sValue5=="+sValue5);
//            System.out.println("sValue6=="+sValue6);
            
            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
            LV3.addColumn(strCompanyCode, "BUKRS");
            LV3.addColumn(strFiscalYr, "GJAHR");
            CommonObj.writeToLog(2,"intLineNo:appendzerosN(Integer.toString(intLineNo),3)="+CommonObj.appendzerosN(Integer.toString(intLineNo),3),winame); 
            LV3.addColumn(CommonObj.appendzerosN(Integer.toString(intLineNo),3), "BUZEI");
            intLineNo++;
            LV3.addColumn("40", "BSCHL");
            LV3.addColumn("S", "KOART");
            LV3.addColumn("S", "SHKZG");
            LV3.addColumn(sValue4, "GSBER");
            LV3.addColumn(sValue2, "DMBTR");
            LV3.addColumn(sValue2, "WRBTR");
            LV3.addColumn(sValue2, "PSWBT");            
            LV3.addColumn(steUserName, "SGTXT");
            LV3.addColumn(strCompanyCode, "KOKRS");
            LV3.addColumn(sValue8, "KOSTL");
            LV3.addColumn(CommonObj.appendzeros(sValue7), "SAKNR");
            LV3.addColumn(CommonObj.appendzeros(sValue7), "HKONT");
            String qryBusinessPlaceLI="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+sValue4+"'";
            String strBusinessPlaceLI=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlaceLI);
            LV3.addColumn(strBusinessPlaceLI, "BUPLA");
            BAPIInput.append(LV3.builder.toString());
            BAPIInput.append("</T_BSEG>");            
            blnExecute=true;            
            }
            }            
      
        
            BAPIInput.append("</TableParameters>");            
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            //CommonObj.writeToLog(1, "BAPIInput PRELIMINARY_POSTING_FB01:" + BAPIInput.toString(), winame);
            
            if(blnExecute){
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("Parameters", "ExportParameters");

                String strFIDOC_NO = XMLListMessage.getVal("GS_FIDOC").trim();
                CommonObj.writeToLog(1,"strFIDOC_NO==" + strFIDOC_NO, winame);
                if(!strFIDOC_NO.equalsIgnoreCase("")){
                formObject.setNGValue("SAPDocRefNo", strFIDOC_NO);
                formObject.setNGValue("ParkedBy", formObject.getUserName());
                formObject.setNGValue("ParkingDate", NGDateFormat.format(date));
                formObject.RaiseEvent("WFSave");
                outputResult = "SUCCESS";
                }
            }
            else{
                CommonObj.writeToLog(1, "BAPIInput ZPRELIMINARY_POSTING_FB01:Failed Execution", winame);
            throw new ValidatorException(new FacesMessage("Parking Failed..!!!!","Comments"));
            }
            }
            return outputResult;
        } catch (Exception e) {
            
            CommonObj.writeToLog(3, "Error In SAPPark:VP NONPO_Parking ="+ e.getMessage(), winame);
            
            return outputResult;
        }
    }

    
    
}
