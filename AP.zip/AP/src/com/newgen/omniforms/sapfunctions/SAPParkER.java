/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.IOException;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author Nanjundamoorthy.b
 */
public class SAPParkER implements Serializable {

    SAPCall objSAPCall = new SAPCall();
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfDt = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat SAPDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat SAPDateFormat2 = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat NGDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    DecimalFormat decimalformat = new DecimalFormat("0");

    public String NONPO_Parking(String strInput1) {
        String outputResult = "FAIL";
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            String steUserName = formObject.getUserName();

            CommonObj.writeToLog(1, "IN SAP Function:NONPO_Parking DMS No:::>>>>" + winame, winame);
            String Newgenwiname = winame;//.replaceAll("AP-","");
            Newgenwiname = Newgenwiname.replaceAll("-Payments", "");
            Newgenwiname = Newgenwiname.replaceAll("-Process", "");
            Newgenwiname = Newgenwiname.replaceAll("AP-", "");
            int widlength = Newgenwiname.length();
            if (widlength > 15) {
                Newgenwiname = Newgenwiname.substring(widlength - 15, widlength);
            }
            //Integer intNewgenwiname=Integer.parseInt(Newgenwiname);
            double dNewgenwiname = Double.parseDouble(Newgenwiname);
            //winame=winame.substring(0,winame.length() -8);
            CommonObj.writeToLog(1, "IN SAP Function:NONPO_Parking DMS No 2 SAP::Newgenwiname:>>>>" + Newgenwiname, winame);
            String strCurrentDate = formObject.getNGValue("CurrentDateTime");
            CommonObj.writeToLog(1, "IN SAP Function:strCurrentDate::" + strCurrentDate, winame);
            boolean blnExecute = false;
            String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
            String strSubcategory1 = formObject.getNGValue("SubCategory1");

            String strDateOfReq = formObject.getNGValue("DateOfReq");
            String strCompanyCode = formObject.getNGValue("CompanyCode");
            String strEmpCode = formObject.getNGValue("EmployeeCode");
            String strFiscalYr = formObject.getNGValue("FiscalYr");
            String strVendorCode = formObject.getNGValue("VendorCode");
            //Added by SandeepKN on 23Dec2019 for vendor code error as per girish--start
            CommonObj.writeToLog(2, "strVendorCode000==> " + formObject.getNGValue("VendorCode"), winame);
            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")
                    || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                if (Character.isDigit(strVendorCode.charAt(0))) {// if vendor code starts with numeric then append zero
                    int intVendorCode = Integer.parseInt(strVendorCode);
                    CommonObj.writeToLog(2, "intVendorCode if starting with numeric==> " + intVendorCode, winame);
                    strVendorCode = String.format("%010d", intVendorCode);
                    CommonObj.writeToLog(2, "strVendorCode11111==> " + strVendorCode, winame);
                } else {
                    strVendorCode = formObject.getNGValue("VendorCode");
                    CommonObj.writeToLog(2, "else strVendorCode11111==> " + strVendorCode, winame);
                }
            } //Added by SandeepKN on 23Dec2019 for vendor code error as per girish--end  

            String strPO_NO = formObject.getNGValue("PONumber");
            String strEmpName = formObject.getNGValue("EmployeeName");
            String strDesaigntion = formObject.getNGValue("Designation");
            String strDept = formObject.getNGValue("Department");
            String strGrade = formObject.getNGValue("Grade");
            String strCostCenter = formObject.getNGValue("CostCenter");
            String strBusinessArea = formObject.getNGValue("BusinessArea");
            String strOrgLoc = formObject.getNGValue("OriginalLocation");
            //String strTotalAmount = formObject.getNGValue("TotalAmount");//Commented by Sandeepkn on 10Jan for Asfi changes
            String strTotalAmount = "";
            //Added by SandeepKN on 11Dec2019 for ASFI three decimal changes as per SAP team confirmatiom from mail --Start
            if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                CommonObj.writeToLog(2, "TotalAmount in ASFI ==> " + formObject.getNGValue("TotalAmount"), winame);
                //Added by SandeepKN on 18Dec2019 as per SAP girish confirmation
                double fAmount = (Double.parseDouble(formObject.getNGValue("TotalAmount")) * 10);
                NumberFormat formatter = new DecimalFormat("#0.000");// if it mupltiplies with decimal the value of decimal increases more than 3 dec value
                strTotalAmount = (formatter.format(fAmount));
                CommonObj.writeToLog(2, "The TotalAmount Decimal Value is  ==> " + strTotalAmount, winame);
            } else {
                strTotalAmount = formObject.getNGValue("TotalAmount");
                CommonObj.writeToLog(2, "TotalAmount in else part ==> " + strTotalAmount, winame);
            }//Added by SandeepKN on 11Dec2019 for ASFI three decimal changes as per SAP team confirmatiom from mail --End

            String strMobileNo = formObject.getNGValue("MobileNo");
            String strBillDate = formObject.getNGValue("BillDate");
            String strEligibleAmount = formObject.getNGValue("EligibleAmount");
            String strBlackBerryCharges = formObject.getNGValue("BlackBerryCharges");
            String strFromPeriod = formObject.getNGValue("FromPeriod");
            String strToPeriod = formObject.getNGValue("ToPeriod");
            String strServiceProvider = formObject.getNGValue("ServiceProvider");
            String strBillPlan = formObject.getNGValue("BillPlan");
            String strBillValueLessTax = formObject.getNGValue("BillValueLessTax");
            String strServiceTax_Billvalue = formObject.getNGValue("ServiceTax_Billvalue");
            String strValueOfPersonalCalls = formObject.getNGValue("ValueOfPersonalCalls");
            String strServiceTax_ValueOfPersonalCalls = formObject.getNGValue("ServiceTax_ValueOfPersonalCalls");
            String strKOKRS = "";

            //Modified by Sivashankar KS on 31-May-2019 for Nepal Company Code starts here
//            if(strCompanyCode.equalsIgnoreCase("BCFL")){
//                strKOKRS="BCFL";
//            }else{
//                strKOKRS="BIL1";
//            }
//            
            //Modified on 29-MAR-21 for HANA changes
//            if (strCompanyCode.equalsIgnoreCase("BCFL")) {
//                strKOKRS = "BCFL";
//            } else if (strCompanyCode.equalsIgnoreCase("BNP1")) {
//                strKOKRS = "BNPL";
//                //Financial year changes
//                CommonObj.writeToLog(2, "In Nepal strFiscalYr:" + strFiscalYr, winame);
//                Integer intNewgenwiname = Integer.parseInt(strFiscalYr);
//                CommonObj.writeToLog(2, "In Nepal intNewgenwiname:" + intNewgenwiname, winame);
//                intNewgenwiname = intNewgenwiname - 1;
//                CommonObj.writeToLog(2, "In Nepal intNewgenwiname:" + intNewgenwiname, winame);
//                strFiscalYr = Integer.toString(intNewgenwiname);
//                CommonObj.writeToLog(2, "In Nepal strFiscalYr:" + strFiscalYr, winame);
//            }//Added by sandeepKn on 10Jan2020 for ASFI and SFIC chnages-Start
//            else if (strCompanyCode.equalsIgnoreCase("SFIC") || strCompanyCode.equalsIgnoreCase("ASFI")) {
//                strKOKRS = "BII";
//            } //Added by sandeepKn on 10Jan2020 for ASFI and SFIC chnages-End
//            //Added by SandeepKN 0n 30Mar2020 for Other companyines exte- Start
//            else if (strCompanyCode.equalsIgnoreCase("SBCL")) {
//                strKOKRS = "SBCL";
//            } else if (strCompanyCode.equalsIgnoreCase("MFL1")) {
//                strKOKRS = "MFL1";
//            } else if (strCompanyCode.equalsIgnoreCase("JBM1")) {
//                strKOKRS = "JBM1";
//            } else if (strCompanyCode.equalsIgnoreCase("IBPL")) {
//                strKOKRS = "IBPL";
//            } //Added by SandeepKN 0n 30Mar2020 for Other companyines exte- End
//            else {
//                strKOKRS = "BIL1";
//            }
//Modified by Sivashankar KS on 31-May-2019 for Nepal Company Code ends here 
            strKOKRS = "BRIT";
            CommonObj.writeToLog(2, "Controlling Area ::: " + strKOKRS, winame);
            //End on 29-MAR-21

            String qryBusinessPlace = "select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='" + strBusinessArea + "' and compcode='" + strCompanyCode + "'";
            String strBusinessPlace = CommonObj.DB_QueryExecuteSelect1(qryBusinessPlace);
            CommonObj.writeToLog(2, "qryBusinessPlace:" + qryBusinessPlace, winame);
            CommonObj.writeToLog(2, "strBusinessPlace:" + strBusinessPlace, winame);

            BAPIInput.append(objSAPCall.getconnectionstring());
            CommonObj.writeToLog(1, "IN SAP Function:NONPO_Parking:SAPClient:" + objSAPCall.SAPClient, winame);
            BAPIInput.append("<SAPFunctionName>ZPRELIMINARY_POSTING_FB01</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<I_TCODE>FBV0</I_TCODE>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("<TableParameters>");
            BAPIInput.append("<T_BKPF>");
            ListViewItems LVI = new ListViewItems();
            //LVI.addColumnParkvalue(objSAPCall.SAPClient, "MANDT");
            LVI.addColumn(strCompanyCode, "BUKRS");
            LVI.addColumn(strFiscalYr, "GJAHR");
            LVI.addColumn("NG", "BLART");
            if (strSubcategory1.equalsIgnoreCase("Mobile Re-Imbursements")) {

                LVI.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strBillDate)), "BLDAT");
                LVI.addColumn(SAPDateFormat2.format(date), "BUDAT");
                LVI.addColumn("00", "MONAT");
                LVI.addColumn("FBV0", "TCODE");
                //LVI.addColumn(Integer.toString(intNewgenwiname), "XBLNR");
                LVI.addColumn(decimalformat.format(dNewgenwiname), "XBLNR");
                //LVI.addColumn(strSubcategory1 + " - " + strEmpName, "BKTXT");
                LVI.addColumn(strEmpName, "BKTXT");

                /*Modified by sivashankar ks on 31-May-2019 for Nepal change starts*/
                /* 
                 LVI.addColumn("INR", "WAERS");
                 LVI.addColumn("INR", "HWAER");
                 */
                //Added By SandeepKn on 10Jan2020 for ASFI and SFIC Changes
                if (strCompanyCode.equalsIgnoreCase("SFIC")) {
                    LVI.addColumn("AED", "WAERS");
                    LVI.addColumn("AED", "HWAER");
                } else if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                    LVI.addColumn("OMR", "WAERS");
                    LVI.addColumn("OMR", "HWAER");
                } else if (strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LVI.addColumn("NPR", "WAERS");
                    LVI.addColumn("NPR", "HWAER");
                } else {
                    LVI.addColumn("INR", "WAERS");
                    LVI.addColumn("INR", "HWAER");
                }
                /*Modified by sivashankar ks on 31-May-2019 for Nepal change ends*/

                LVI.addColumn("V", "BSTAT");
                //LVI.addColumnParkvalue("000", "NUMPG");
                BAPIInput.append(LVI.builder.toString());
                BAPIInput.append("</T_BKPF>");

                BAPIInput.append("<T_BSEG>");
                ListViewItems LV2 = new ListViewItems();
                LV2.addColumn(objSAPCall.SAPClient, "MANDT");
                LV2.addColumn(strCompanyCode, "BUKRS");
                LV2.addColumn(strFiscalYr, "GJAHR");
                LV2.addColumn("001", "BUZEI");
                LV2.addColumn("31", "BSCHL");
                LV2.addColumn("K", "KOART");
                LV2.addColumn("H", "SHKZG");

                LV2.addColumn(strBusinessArea, "GSBER");
                LV2.addColumn(strTotalAmount, "DMBTR");
                LV2.addColumn(strTotalAmount, "WRBTR");
                LV2.addColumn(strTotalAmount, "PSWBT");
                //LV2.addColumnParkvalue("000", "TXGRP");
                //LV2.addColumn("Reimb.of mobile-" + dateFormat.format((Date) NGDateFormat.parse(strFromPeriod)) + " To " + dateFormat.format((Date) NGDateFormat.parse(strToPeriod)), "SGTXT");
                LV2.addColumn(strEmpName + " - " + dateFormat.format((Date) NGDateFormat.parse(strFromPeriod)) + " To " + dateFormat.format((Date) NGDateFormat.parse(strToPeriod)), "SGTXT");
                //LV2.addColumnParkvalue("000", "FKONT");
                //LV2.addColumn("0000420103", "HKONT");
                LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorGL")), "HKONT");
                //Added by sandeepKn on 10Jan2020 for ASFI and SFIC Changes --Start
                if (strCompanyCode.equalsIgnoreCase("SFIC") || strCompanyCode.equalsIgnoreCase("ASFI")) {
                    LV2.addColumn(formObject.getNGValue("VendorCode"), "LIFNR");
                } else {
                    LV2.addColumn(CommonObj.appendzero(0, "VendorCode"), "LIFNR");
                }
                //Added by SandeepKn on 10Jan2020 for ASFI and SFIC changes -End
                //LV2.addColumn(CommonObj.appendzero(0, "VendorCode"), "LIFNR");
                //LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strBillDate)), "ZFBDT");
                LV2.addColumn(SAPDateFormat2.format(date), "ZFBDT");
                LV2.addColumn(strBusinessPlace, "BUPLA");

                if (!strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LV2.addColumn(strBusinessPlace, "SECCO");
                }
//                LV2.addColumn(strBusinessPlace, "SECCO");
                LV2.addColumn(strMobileNo, "ZUONR");
                BAPIInput.append(LV2.builder.toString());
                BAPIInput.append("</T_BSEG>");

                BAPIInput.append("<T_BSEG>");
                ListViewItems LV3 = new ListViewItems();
                //LV3=null;
                LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                LV3.addColumn(strCompanyCode, "BUKRS");
                LV3.addColumn(strFiscalYr, "GJAHR");
                LV3.addColumn("002", "BUZEI");
                LV3.addColumn("40", "BSCHL");
                LV3.addColumn("S", "KOART");
                LV3.addColumn("S", "SHKZG");
                LV3.addColumn(strBusinessArea, "GSBER");
                LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                LV3.addColumn(strTotalAmount, "DMBTR");
                LV3.addColumn(strTotalAmount, "WRBTR");
                LV3.addColumn(strTotalAmount, "PSWBT");
                //LV3.addColumnParkvalue("000", "TXGRP");
                //LV3.addColumn(strEmpName + " - " + dateFormat.format((Date) NGDateFormat.parse(strFromPeriod)) + " To " + dateFormat.format((Date) NGDateFormat.parse(strToPeriod)) + " - " + strMobileNo, "SGTXT");
                LV3.addColumn("Reimb.of mobil-" + dateFormat.format((Date) NGDateFormat.parse(strFromPeriod)) + " To " + dateFormat.format((Date) NGDateFormat.parse(strToPeriod)) + "-" + strMobileNo, "SGTXT");
                //LV3.addColumnParkvalue("000", "FKONT");
                LV3.addColumn(strKOKRS, "KOKRS");
                LV3.addColumn(strCostCenter, "KOSTL");
//                LV3.addColumn("0000420103", "SAKNR");
                LV3.addColumn("0045120103", "SAKNR");//HANA
//                LV3.addColumn("0000420103", "HKONT");
                LV3.addColumn("0045120103", "HKONT");//HANA
                LV3.addColumn(strBusinessPlace, "BUPLA");
                LV3.addColumn(strVendorCode, "ZUONR");
                //LV3.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "ZUONR");                
                BAPIInput.append(LV3.builder.toString());
                BAPIInput.append("</T_BSEG>");
                //CommonObj.writeToLog(1, "BAPIInput 3:" + BAPIInput.toString(), winame); 
                blnExecute = true;
            }//End Of Mobile Re-Imbursement        
            else if (strSubcategory1.equalsIgnoreCase("Entertainment") || strSubcategory1.equalsIgnoreCase("Others") || strSubcategory1.equalsIgnoreCase("Gift & Complimentary")) {
                LVI.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)), "BLDAT");
                LVI.addColumn(SAPDateFormat2.format(date), "BUDAT");
                LVI.addColumn("00", "MONAT");
                LVI.addColumn("FBV0", "TCODE");
                //LVI.addColumn(Integer.toString(intNewgenwiname), "XBLNR");
                LVI.addColumn(decimalformat.format(dNewgenwiname), "XBLNR");
                //LVI.addColumn(strSubcategory1 + " - " + strEmpName, "BKTXT");
                LVI.addColumn(strEmpName, "BKTXT");

                /*Modified by sivashankar ks on 31-May-2019 for Nepal change starts*/
                /* 
                 LVI.addColumn("INR", "WAERS");
                 LVI.addColumn("INR", "HWAER");
                 */
                //Added by SandeepKn on 10Jan2020 for ASFI and SFIC chnages
                if (strCompanyCode.equalsIgnoreCase("SFIC")) {
                    LVI.addColumn("AED", "WAERS");
                    LVI.addColumn("AED", "HWAER");
                } else if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                    LVI.addColumn("OMR", "WAERS");
                    LVI.addColumn("OMR", "HWAER");
                } else if (strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LVI.addColumn("NPR", "WAERS");
                    LVI.addColumn("NPR", "HWAER");
                } else {
                    LVI.addColumn("INR", "WAERS");
                    LVI.addColumn("INR", "HWAER");
                }
                /*Modified by sivashankar ks on 31-May-2019 for Nepal change ends*/

                LVI.addColumn("V", "BSTAT");
                BAPIInput.append(LVI.builder.toString());
                BAPIInput.append("</T_BKPF>");

                int Entertainment = formObject.getItemCount("list_Entertain");
                CommonObj.writeToLog(2, "Entertainment Count:" + Entertainment, winame);
                CommonObj.writeToLog(2, "list_Entertain:" + (formObject.getSelectedIndex("list_Entertain")), winame);
                CommonObj.writeToLog(2, "getNGListView:list_Entertain:" + formObject.getNGListView("list_Entertain"), winame);
                List<List<String>> ControlObject = CommonObj.getListViewValueInList(formObject, "list_Entertain");
                CommonObj.writeToLog(2, "ControlObj==" + ControlObject, winame);

                if (Entertainment > 0) {
                    String EntertainmentLineItemData[] = CommonObj.getRowValue(formObject, "list_Entertain", 0);
                    String sValue0 = EntertainmentLineItemData[0].trim();
                    String sValue1 = EntertainmentLineItemData[1].trim();
                    String sValue2 = EntertainmentLineItemData[2].trim();
                    String sValue3 = EntertainmentLineItemData[3].trim();
                    String sValue4 = EntertainmentLineItemData[4].trim();
                    String sValue5 = EntertainmentLineItemData[5].trim();

                    BAPIInput.append("<T_BSEG>");
                    ListViewItems LV2 = new ListViewItems();
                    LV2.addColumn(objSAPCall.SAPClient, "MANDT");
                    LV2.addColumn(strCompanyCode, "BUKRS");
                    LV2.addColumn(strFiscalYr, "GJAHR");
                    LV2.addColumn("001", "BUZEI");
                    LV2.addColumn("31", "BSCHL");
                    LV2.addColumn("K", "KOART");
                    LV2.addColumn("H", "SHKZG");
                    LV2.addColumn(strBusinessArea, "GSBER");
                    LV2.addColumn(strTotalAmount, "DMBTR");
                    LV2.addColumn(strTotalAmount, "WRBTR");
                    LV2.addColumn(strTotalAmount, "PSWBT");
                        //LV2.addColumnParkvalue("000", "TXGRP");
                    //LV2.addColumn("Entertainment-" + strEmpName, "SGTXT");//Credit
                    LV2.addColumn("Reimb#-" + decimalformat.format(dNewgenwiname) + "-" + strDateOfReq, "SGTXT");//Credit
                    //LV2.addColumnParkvalue("000", "FKONT");
                    //LV2.addColumnParkvalue("0000420103", "HKONT");
                    LV2.addColumn(CommonObj.appendzeros(sValue4), "HKONT");
                    CommonObj.writeToLog(2, "strBillDate:" + strBillDate, winame);
                    CommonObj.writeToLog(2, "VendorCode:" + CommonObj.appendzeros(formObject.getNGValue("VendorCode")), winame);
                    CommonObj.writeToLog(2, "strBillDate in SAP Format:" + SAPDateFormat2.format((Date) NGDateFormat.parse(sValue2)), winame);
                        //LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "LIFNR");
                    //Added by SAndeepKn on 10Jan2020 for ASFIC and SFIC changes
                    if (strCompanyCode.equalsIgnoreCase("SFIC") || strCompanyCode.equalsIgnoreCase("ASFI")) {
                        LV2.addColumn(formObject.getNGValue("VendorCode"), "LIFNR");
                    } else {
                        LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "LIFNR");
                    }

                    //LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(sValue2)), "ZFBDT");
                    LV2.addColumn(SAPDateFormat2.format(date), "ZFBDT");
                    LV2.addColumn(strBusinessPlace, "BUPLA");
//                    LV2.addColumn(strBusinessPlace, "SECCO");
                    if (!strCompanyCode.equalsIgnoreCase("BNP1")) {
                        LV2.addColumn(strBusinessPlace, "SECCO");
                    }
                    BAPIInput.append(LV2.builder.toString());
                    BAPIInput.append("</T_BSEG>");

                    /*for (Integer i = 0; i < ControlObject.size(); i++) {
                     String sValue0 = ControlObject.get(i).get(0);
                     String sValue1 = ControlObject.get(i).get(1);
                     String sValue2 = ControlObject.get(i).get(2);
                     String sValue3 = ControlObject.get(i).get(3);
                     String sValue4 = ControlObject.get(i).get(4);
                     String sValue5 = ControlObject.get(i).get(5);

                     BAPIInput.append("<T_BSEG>");
                     ListViewItems LV2 = new ListViewItems();
                     LV2.addColumn(objSAPCall.SAPClient, "MANDT");
                     LV2.addColumn(strCompanyCode, "BUKRS");
                     LV2.addColumn(strFiscalYr, "GJAHR");
                     LV2.addColumn("001", "BUZEI");
                     LV2.addColumn("31", "BSCHL");
                     LV2.addColumn("K", "KOART");
                     LV2.addColumn("H", "SHKZG");                        
                     LV2.addColumn(strBusinessArea, "GSBER");                        
                     LV2.addColumn(strTotalAmount, "DMBTR");
                     LV2.addColumn(strTotalAmount, "WRBTR");
                     LV2.addColumn(strTotalAmount, "PSWBT");
                     //LV2.addColumnParkvalue("000", "TXGRP");
                     //LV2.addColumn("Entertainment-" + strEmpName, "SGTXT");//Credit
                     LV2.addColumn("Reimb#-" + decimalformat.format(dNewgenwiname) +"-"+SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)), "SGTXT");//Credit
                     //LV2.addColumnParkvalue("000", "FKONT");
                     //LV2.addColumnParkvalue("0000420103", "HKONT");
                     LV2.addColumn(CommonObj.appendzeros(sValue4), "HKONT");
                     CommonObj.writeToLog(2, "strBillDate:" + strBillDate, winame);
                     CommonObj.writeToLog(2, "VendorCode:" + CommonObj.appendzeros(formObject.getNGValue("VendorCode")), winame);
                     CommonObj.writeToLog(2, "strBillDate in SAP Format:" + SAPDateFormat2.format((Date) NGDateFormat.parse(sValue2)), winame);
                     LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "LIFNR");
                     LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(sValue2)), "ZFBDT");
                     LV2.addColumn(strBusinessPlace, "BUPLA");
                     LV2.addColumn(strBusinessPlace, "SECCO");
                     BAPIInput.append(LV2.builder.toString());
                     BAPIInput.append("</T_BSEG>");
                     break;
                     }*/
                    Integer intLineNo = 002;
                    for (Integer i = 0; i < Entertainment; i++) {
                        String EntertanLineItemData[] = CommonObj.getRowValue(formObject, "list_Entertain", i);
                        CommonObj.writeToLog(2, "intLineNo:" + intLineNo, winame);
                        BAPIInput.append("<T_BSEG>");
                        ListViewItems LV3 = new ListViewItems();
                        String ssValue0 = EntertanLineItemData[0].trim();
                        CommonObj.writeToLog(2, "ssValue0:" + ssValue0, winame);
                        String ssValue1 = EntertanLineItemData[1].trim();
                        CommonObj.writeToLog(2, "ssValue1:" + ssValue1, winame);
                        String ssValue2 = EntertanLineItemData[2].trim();
                        CommonObj.writeToLog(2, "ssValue2:" + ssValue2, winame);
                        String ssValue3 = EntertanLineItemData[3].trim();
                        CommonObj.writeToLog(2, "ssValue3:" + ssValue3, winame);
                        String ssValue4 = EntertanLineItemData[4].trim();
                        CommonObj.writeToLog(2, "ssValue4:" + ssValue4, winame);
                            //String ssValue5 = EntertanLineItemData[5].trim();
                        //Sandeep --Start
                        String ssValue5 = "";
                        //Added by SandeepKN on 11Dec2019 for ASFI three decimal changes as per SAP team confirmatiom from mail --Start
                        if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                            CommonObj.writeToLog(2, "TotalAmount ent in ASFI11 ==> " + EntertanLineItemData[5].trim(), winame);
                            //added by sandeepKN on 18Dec2019 as per SAP Girish confirmation
                            double fAmount = (Double.parseDouble(formObject.getNGValue("TotalAmount")) * 10);
                            NumberFormat formatter = new DecimalFormat("#0.000");//added by sandeepkn on 23Dec2019
                            ssValue5 = (formatter.format(fAmount));// if it mupltiplies with decimal the value of decimal increases more than 3 dec value
                            //ssValue5 = Float.toString(fAmount);
                            CommonObj.writeToLog(2, "The TotalAmount Decimal Value is ASFI ==> " + ssValue5, winame);
                        } else {
                            ssValue5 = EntertanLineItemData[5].trim();
                            CommonObj.writeToLog(2, "TotalAmount in else part111 ==> " + ssValue5, winame);
                        }//Added by SandeepKN on 11Dec2019 for ASFI three decimal changes as per SAP team confirmatiom from mail --End
                        //Sandeep-- end

                        LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                        LV3.addColumn(strCompanyCode, "BUKRS");
                        LV3.addColumn(strFiscalYr, "GJAHR");
                        LV3.addColumn("00" + intLineNo, "BUZEI");
                        intLineNo++;
                        LV3.addColumn("40", "BSCHL");
                        LV3.addColumn("S", "KOART");
                        LV3.addColumn("S", "SHKZG");
                        LV3.addColumn(strBusinessArea, "GSBER");
                        //addedon 26-04-2017 for fuel expense to ignore the taxcode value for the below GL
//                        if (ssValue4.equalsIgnoreCase("410080") || ssValue4.equalsIgnoreCase("0000410080")
                        if (ssValue4.equalsIgnoreCase("42040600") || ssValue4.equalsIgnoreCase("0042040600")//HANA
                                //                                || ssValue4.equalsIgnoreCase("420008") || ssValue4.equalsIgnoreCase("0000420008")
                                || ssValue4.equalsIgnoreCase("45121906") || ssValue4.equalsIgnoreCase("0045121906")//HANA
                                //                                || ssValue4.equalsIgnoreCase("410100") || ssValue4.equalsIgnoreCase("0000410100")) {
                                || ssValue4.equalsIgnoreCase("45090101") || ssValue4.equalsIgnoreCase("0045090101")) {//HANA
                            LV3.addColumn("", "MWSKZ");//debit line entry added on 10/02/2017
                        } else {
                            LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                        }
                        LV3.addColumn(ssValue5, "DMBTR");
                        LV3.addColumn(ssValue5, "WRBTR");
                        LV3.addColumn(ssValue5, "PSWBT");
                            //LV3.addColumnParkvalue("000", "TXGRP");
                        //LV3.addColumn("Entertainment-" + strEmpName, "SGTXT");//Debit
                        LV3.addColumn(ssValue0 + "-" + ssValue1 + "-" + ssValue2, "SGTXT");//Debit
                        CommonObj.writeToLog(2, "SGTXT ==> " + ssValue0 + "-" + ssValue1 + "-" + ssValue2, winame);
                        //LV3.addColumnParkvalue("000", "FKONT");
                        LV3.addColumn(strKOKRS, "KOKRS");
                        LV3.addColumn(strCostCenter, "KOSTL");
                        LV3.addColumn(CommonObj.appendzeros(ssValue4), "SAKNR");
                        LV3.addColumn(CommonObj.appendzeros(ssValue4), "HKONT");
                        LV3.addColumn(strBusinessPlace, "BUPLA");
                        LV3.addColumn(strVendorCode, "ZUONR");
                        BAPIInput.append(LV3.builder.toString());
                        BAPIInput.append("</T_BSEG>");
                        blnExecute = true;
                    }
                }

                //blnExecute=true;
            }//End of Entertainment & Others
            else if (strSubcategory1.equalsIgnoreCase("Travel Expense")) {
                LVI.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)), "BLDAT");
                LVI.addColumn(SAPDateFormat2.format(date), "BUDAT");
                LVI.addColumn("00", "MONAT");
                LVI.addColumn("FBV0", "TCODE");
                //LVI.addColumn(Newgenwiname, "XBLNR");
                LVI.addColumn(decimalformat.format(dNewgenwiname), "XBLNR");
                //LVI.addColumn(strSubcategory1 + " - " + strEmpName, "BKTXT");
                LVI.addColumn(strEmpName, "BKTXT");

                /*Modified by sivashankar ks on 31-May-2019 for Nepal change starts*/
                /* 
                 LVI.addColumn("INR", "WAERS");
                 LVI.addColumn("INR", "HWAER");
                 */
                //Added by sandeepkn on 10Jan2020 for ASFI and SFIC changes
                if (strCompanyCode.equalsIgnoreCase("SFIC")) {
                    LVI.addColumn("AED", "WAERS");
                    LVI.addColumn("AED", "HWAER");
                } else if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                    LVI.addColumn("OMR", "WAERS");
                    LVI.addColumn("OMR", "HWAER");
                } else if (strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LVI.addColumn("NPR", "WAERS");
                    LVI.addColumn("NPR", "HWAER");
                } else {
                    LVI.addColumn("INR", "WAERS");
                    LVI.addColumn("INR", "HWAER");
                }
                /*Modified by sivashankar ks on 31-May-2019 for Nepal change ends*/

                LVI.addColumn("V", "BSTAT");
                BAPIInput.append(LVI.builder.toString());
                BAPIInput.append("</T_BKPF>");

                Integer intLineNo = 2;

                BAPIInput.append("<T_BSEG>");
                ListViewItems LV2 = new ListViewItems();
                LV2.addColumn(objSAPCall.SAPClient, "MANDT");
                LV2.addColumn(strCompanyCode, "BUKRS");
                LV2.addColumn(strFiscalYr, "GJAHR");
                LV2.addColumn("001", "BUZEI");
                LV2.addColumn("31", "BSCHL");
                LV2.addColumn("K", "KOART");
                LV2.addColumn("H", "SHKZG");
                LV2.addColumn(strBusinessArea, "GSBER");
                LV2.addColumn(strTotalAmount, "DMBTR");
                LV2.addColumn(strTotalAmount, "WRBTR");
                LV2.addColumn(strTotalAmount, "PSWBT");
                //LV2.addColumnParkvalue("Re-Imbursement of "+ sValue1+" tour expn-"+dateFormat.format((Date) NGDateFormat.parse(sValue2)), "SGTXT");            
                LV2.addColumn("Re-Imbursement of Travel Exps-" + strDateOfReq, "SGTXT");
//                String strGLCodeHeader = "0000420040";
                String strGLCodeHeader = "0045090102";//HANA

                //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes starts here
                String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                if (strTypeOfTravel.equalsIgnoreCase("Domestic")) {
//                    strGLCodeHeader = "0000420040";
                    strGLCodeHeader = "0045090102";//HANA
                } else if (strTypeOfTravel.equalsIgnoreCase("International")
                        || strTypeOfTravel.equalsIgnoreCase("International - Business Travel") //Added by SandeepKN on 05Dec2019 for SFIC and ASFI Changes
                        || strTypeOfTravel.equalsIgnoreCase("International - Annual Leave travel")) {
//                    strGLCodeHeader = "0000420042";
                    strGLCodeHeader = "0045090201";//HANA
                }
                //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes ends here

                LV2.addColumn(strGLCodeHeader, "HKONT");
                //LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "LIFNR");
                //Added by SandeepKn on 10JAn2020 for ASFI and SFIC changes
                if (strCompanyCode.equalsIgnoreCase("SFIC") || strCompanyCode.equalsIgnoreCase("ASFI")) {
                    LV2.addColumn(formObject.getNGValue("VendorCode"), "LIFNR");
                } else {
                    LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "LIFNR");
                }

                //LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)), "ZFBDT");
                LV2.addColumn(SAPDateFormat2.format(date), "ZFBDT");
                LV2.addColumn(strBusinessPlace, "BUPLA");
//                LV2.addColumn(strBusinessPlace, "SECCO");
                if (!strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LV2.addColumn(strBusinessPlace, "SECCO");
                }
                BAPIInput.append(LV2.builder.toString());
                BAPIInput.append("</T_BSEG>");

                int list_travel = formObject.getItemCount("list_travel");
                CommonObj.writeToLog(2, "list_travel Count:" + list_travel, winame);
                CommonObj.writeToLog(2, "list_Entertain:" + (formObject.getSelectedIndex("list_travel")), winame);
                CommonObj.writeToLog(2, "getNGListView:list_travel:" + formObject.getNGListView("list_travel"), winame);

                if (list_travel > 0) {
                    for (Integer i = 0; i < list_travel; i++) {
                        String TravelLineItemData[] = CommonObj.getRowValue(formObject, "list_travel", i);
                        CommonObj.writeToLog(2, "intLineNo:" + intLineNo, winame);

                        String sValue0 = TravelLineItemData[0].trim();
                        String sValue1 = TravelLineItemData[1].trim();
                        String sValue2 = TravelLineItemData[2].trim();
                        String sValue3 = TravelLineItemData[3].trim();
                        String sValue4 = TravelLineItemData[4].trim();
                        String sValue5 = TravelLineItemData[5].trim();
                        String sValue8 = TravelLineItemData[8].trim();
                        String sValue9 = TravelLineItemData[9].trim();
                        //added by sandeepkn on 23Dec2019 ASFI chnages-start
                        if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                            CommonObj.writeToLog(2, "TotalAmount sValue9 ASFI11 ==> " + TravelLineItemData[9].trim(), winame);
                            double fAmount = (Double.parseDouble(TravelLineItemData[9].trim()) * 10);
                            NumberFormat formatter = new DecimalFormat("#0.000");//added by sandeepkn on 23Dec2019
                            sValue9 = (formatter.format(fAmount));
                            CommonObj.writeToLog(2, "The TotalAmount sValue9 Value is ASFI ==> " + sValue9, winame);
                        } else {
                            sValue9 = TravelLineItemData[9].trim();
                            CommonObj.writeToLog(2, "TotalAmount in else part111 ==> " + sValue9, winame);
                        }//added by sandeepkn on 23Dec2019 ASFI chnages-end
                        CommonObj.writeToLog(2, "sValue8:" + sValue8, winame);

                        if (!sValue8.equalsIgnoreCase("Company")) {
                            CommonObj.writeToLog(2, "Other Than Company:", winame);

                            BAPIInput.append("<T_BSEG>");
                            ListViewItems LV3 = new ListViewItems();

                            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                            LV3.addColumn(strCompanyCode, "BUKRS");
                            LV3.addColumn(strFiscalYr, "GJAHR");
                            LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                            intLineNo++;
                            LV3.addColumn("40", "BSCHL");
                            LV3.addColumn("S", "KOART");
                            LV3.addColumn("S", "SHKZG");
                            LV3.addColumn(strBusinessArea, "GSBER");
                            LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                            LV3.addColumn(sValue9, "DMBTR");
                            LV3.addColumn(sValue9, "WRBTR");
                            LV3.addColumn(sValue9, "PSWBT");
                            //LV3.addColumn("Re-Imbursement:Travel Fare", "SGTXT");
                            LV3.addColumn(sValue0 + "-" + sValue1 + "-" + sValue2, "SGTXT");
                            LV3.addColumn(strKOKRS, "KOKRS");
                            LV3.addColumn(strCostCenter, "KOSTL");

//                            String strGLCode = "0000420040";
                            String strGLCode = "0045090102";//HANA
                            //String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");  Note:- Commented by Sivashankar KS on 27 Dec 2018 as per mail from sivaram
                            if (strTypeOfTravel.equalsIgnoreCase("Domestic") && (sValue5.equalsIgnoreCase("Train") || sValue5.equalsIgnoreCase("Bus") || sValue5.equalsIgnoreCase("Self"))) {
//                                strGLCode = "0000420916";
                                strGLCode = "0045090101";//HANA
                            } else if (strTypeOfTravel.equalsIgnoreCase("Domestic") && sValue5.equalsIgnoreCase("Air")) {
//                                strGLCode = "0000420039";
                                strGLCode = "0045090100";//HANA
                            } else if (strTypeOfTravel.equalsIgnoreCase("Domestic") && sValue5.equalsIgnoreCase("Others")) {
//                                strGLCode = "0000420040";
                                strGLCode = "0045090102";//HANA
                            } else if (strTypeOfTravel.equalsIgnoreCase("International") && (sValue5.equalsIgnoreCase("Train") || sValue5.equalsIgnoreCase("Bus") || sValue5.equalsIgnoreCase("Self"))) {
//                                strGLCode = "0000420041";
                                strGLCode = "0045090200";//HANA
                            } //                            else if (strTypeOfTravel.equalsIgnoreCase("International") && sValue5.equalsIgnoreCase("Air")) {
                            //                                strGLCode = "0000420041";
                            //                            } else if (strTypeOfTravel.equalsIgnoreCase("International") && sValue5.equalsIgnoreCase("Others")) {
                            //                                strGLCode = "0000420042";
                            //       String strGLCode = "0000420040";                     }//Added by SAndeepkn on 10Jan2020 for ASFI and SFIC changes
                            else if ((strTypeOfTravel.equalsIgnoreCase("International")
                                    || strTypeOfTravel.equalsIgnoreCase("International - Business Travel") //Added by SandeepKN on 05Dec2019 for SFIC and ASFI Changes
                                    || strTypeOfTravel.equalsIgnoreCase("International - Annual Leave travel"))
                                    && sValue5.equalsIgnoreCase("Air")) {
//                                strGLCode = "0000420041";
                                strGLCode = "0045090200";//HANA
                            } else if ((strTypeOfTravel.equalsIgnoreCase("International")
                                    || strTypeOfTravel.equalsIgnoreCase("International - Business Travel") //Added by SandeepKN on 05Dec2019 for SFIC and ASFI Changes
                                    || strTypeOfTravel.equalsIgnoreCase("International - Annual Leave travel"))
                                    && sValue5.equalsIgnoreCase("Others")) {
//                                strGLCode = "0000420042";
                                strGLCode = "0045090201";//HANA
                            }
                            LV3.addColumn(strGLCode, "SAKNR");
                            LV3.addColumn(strGLCode, "HKONT");
                            LV3.addColumn(strBusinessPlace, "BUPLA");
                            LV3.addColumn(strVendorCode, "ZUONR");
                            BAPIInput.append(LV3.builder.toString());
                            BAPIInput.append("</T_BSEG>");
                        }
                        blnExecute = true;
                    }

                }

                /*
                 List<List<String>> ControlObject = CommonObj.getListViewValueInList(formObject, "list_travel");
                 CommonObj.writeToLog(2, "ControlObj==" + ControlObject, winame);

                 if (list_travel > 0) {

                 for (Integer i = 0; i < ControlObject.size(); i++) {
                 CommonObj.writeToLog(2, "intLineNo:" + intLineNo, winame);
                        
                 String sValue0 = ControlObject.get(i).get(0);
                 String sValue1 = ControlObject.get(i).get(1);
                 String sValue2 = ControlObject.get(i).get(2);
                 String sValue3 = ControlObject.get(i).get(3);
                 String sValue4 = ControlObject.get(i).get(4);
                 String sValue5 = ControlObject.get(i).get(5);
                 String sValue8 = ControlObject.get(i).get(8);
                 String sValue9 = ControlObject.get(i).get(9);
                 CommonObj.writeToLog(2, "sValue8:" + sValue8, winame);
                        
                 if(!sValue8.equalsIgnoreCase("Company")){
                 CommonObj.writeToLog(2, "Other Than Company:", winame);
                        
                 BAPIInput.append("<T_BSEG>");
                 ListViewItems LV3 = new ListViewItems();

                 LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                 LV3.addColumn(strCompanyCode, "BUKRS");
                 LV3.addColumn(strFiscalYr, "GJAHR");
                 LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                 intLineNo++;
                 LV3.addColumn("40", "BSCHL");
                 LV3.addColumn("S", "KOART");
                 LV3.addColumn("S", "SHKZG");
                 LV3.addColumn(strBusinessArea, "GSBER");
                 LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                 LV3.addColumn(sValue9, "DMBTR");
                 LV3.addColumn(sValue9, "WRBTR");
                 LV3.addColumn(sValue9, "PSWBT");
                 //LV3.addColumn("Re-Imbursement:Travel Fare", "SGTXT");
                 LV3.addColumn(sValue0+"-"+sValue1+"-"+sValue2, "SGTXT");
                 LV3.addColumn("BIL1", "KOKRS");
                 LV3.addColumn(strCostCenter, "KOSTL");

                 String strGLCode = "0000420040";
                 String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                 if (strTypeOfTravel.equalsIgnoreCase("Domestic") && (sValue5.equalsIgnoreCase("Train") || sValue5.equalsIgnoreCase("Bus") || sValue5.equalsIgnoreCase("Self"))) {
                 strGLCode = "0000420916";
                 } else if (strTypeOfTravel.equalsIgnoreCase("Domestic") && sValue5.equalsIgnoreCase("Air")) {
                 strGLCode = "0000420039";
                 } else if (strTypeOfTravel.equalsIgnoreCase("Domestic") && sValue5.equalsIgnoreCase("Others")) {
                 strGLCode = "0000420040";
                 } else if (strTypeOfTravel.equalsIgnoreCase("International") && (sValue5.equalsIgnoreCase("Train") || sValue5.equalsIgnoreCase("Bus") || sValue5.equalsIgnoreCase("Self"))) {
                 strGLCode = "0000420041";
                 } else if (strTypeOfTravel.equalsIgnoreCase("International") && sValue5.equalsIgnoreCase("Air")) {
                 strGLCode = "0000420041";
                 } else if (strTypeOfTravel.equalsIgnoreCase("International") && sValue5.equalsIgnoreCase("Others")) {
                 strGLCode = "0000420042";
                 }
                 LV3.addColumn(strGLCode, "SAKNR");
                 LV3.addColumn(strGLCode, "HKONT");
                 LV3.addColumn(strBusinessPlace, "BUPLA");
                 BAPIInput.append(LV3.builder.toString());
                 BAPIInput.append("</T_BSEG>");
                 }
                 blnExecute = true;
                 }
                    
                    
                 }*/
                //End of Travel Fare Template
                CommonObj.writeToLog(2, "End of Travel Fare", winame);

                int list_hotel = formObject.getItemCount("list_hotel");
                CommonObj.writeToLog(2, "list_hotel Count:" + list_hotel, winame);
                List<List<String>> list_hotelObject = CommonObj.getListViewValueInList(formObject, "list_hotel");
                CommonObj.writeToLog(2, "list_hotelObject==" + list_hotelObject, winame);
                CommonObj.writeToLog(2, "list_hotelObject Count:" + list_hotelObject.size(), winame);
                if (list_hotel > 0) {
                    for (Integer i = 0; i < list_hotel; i++) {
                        String HotellLineItemData[] = CommonObj.getRowValue(formObject, "list_hotel", i);
                        CommonObj.writeToLog(2, "list_hotel:intLineNo:" + intLineNo, winame);
                        String sValue0 = HotellLineItemData[0].trim();
                        String sValue1 = HotellLineItemData[1].trim();
                        String sValue2 = HotellLineItemData[2].trim();
                        String sValue3 = HotellLineItemData[3].trim();
                        String sValue4 = HotellLineItemData[4].trim();
                        String sValue5 = HotellLineItemData[5].trim();
                        String sValue6 = HotellLineItemData[6].trim();
                        String sValue7 = HotellLineItemData[7].trim();
                        String sValue8 = HotellLineItemData[8].trim();
                        //Added by sandeepkn on 10Jan2020 -Start
                        //added by sandeepkn on 23Dec2019 ASFI chnages-start
                        if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                            CommonObj.writeToLog(2, "TotalAmount sValue8 ASFI11 ==> " + HotellLineItemData[15].trim(), winame);
                            double fAmount = (Double.parseDouble(HotellLineItemData[8].trim()) * 10);
                            NumberFormat formatter = new DecimalFormat("#0.000");//added by sandeepkn on 23Dec2019
                            sValue8 = (formatter.format(fAmount));
                            CommonObj.writeToLog(2, "The TotalAmount sValue8 Value is ASFI ==> " + sValue8, winame);
                        } else {
                            sValue8 = HotellLineItemData[8].trim();
                            CommonObj.writeToLog(2, "TotalAmount in else sValue8 part111 ==> " + sValue8, winame);
                        }//added by sandeepkn on 23Dec2019 ASFI chnages-
                        //10Jan2020 End
                        String sValue9 = HotellLineItemData[9].trim();
                        String sValue10 = HotellLineItemData[10].trim();
                        String sValue11 = HotellLineItemData[11].trim();
                        String sValue12 = HotellLineItemData[12].trim();
                        String sValue13 = HotellLineItemData[13].trim();
                        String sValue14 = HotellLineItemData[14].trim();
                        String sValue15 = HotellLineItemData[15].trim();
                        //10JAn2020-- Start
                        //added by sandeepkn on 23Dec2019 ASFI chnages-start
                        if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                            CommonObj.writeToLog(2, "TotalAmount sValue15 ASFI11 ==> " + HotellLineItemData[15].trim(), winame);
                            double fAmount = (Double.parseDouble(HotellLineItemData[15].trim()) * 10);
                            NumberFormat formatter = new DecimalFormat("#0.000");//added by sandeepkn on 23Dec2019
                            sValue15 = (formatter.format(fAmount));
                            CommonObj.writeToLog(2, "The TotalAmount sValue15 Value is ASFI ==> " + sValue15, winame);
                        } else {
                            sValue15 = HotellLineItemData[15].trim();
                            CommonObj.writeToLog(2, "TotalAmount in else sValue15 part111 ==> " + sValue15, winame);
                        }//added by sandeepkn on 23Dec2019 ASFI chnages-end
                        //10JAn2020-- End
                        String sValue16 = HotellLineItemData[16].trim();
                        String sValue17 = HotellLineItemData[17].trim();
                        String sValue18 = HotellLineItemData[18].trim();
                        String sValue19 = HotellLineItemData[19].trim();
                        String sValue20 = HotellLineItemData[20].trim();
                        String sValue21 = HotellLineItemData[21].trim();
                        CommonObj.writeToLog(2, "list_hotel: sValue0:" + sValue0, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue1:" + sValue1, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue2:" + sValue2, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue3:" + sValue3, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue4:" + sValue4, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue5:" + sValue5, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue6:" + sValue6, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue7:" + sValue7, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue8:" + sValue8, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue9:" + sValue9, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue10:" + sValue10, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue11:" + sValue11, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue12:" + sValue12, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue13:" + sValue13, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue14:" + sValue14, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue15:" + sValue15, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue16:" + sValue16, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue17:" + sValue17, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue18:" + sValue18, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue19:" + sValue19, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue20:" + sValue20, winame);
                        CommonObj.writeToLog(2, "list_hotel: sValue21:" + sValue21, winame);

                        /*if (!sValue2.equalsIgnoreCase("Company")) {
                         CommonObj.writeToLog(2, "Other Than Company:", winame);

                         BAPIInput.append("<T_BSEG>");
                         ListViewItems LV3 = new ListViewItems();

                         LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                         LV3.addColumn(strCompanyCode, "BUKRS");
                         LV3.addColumn(strFiscalYr, "GJAHR");
                         LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                         intLineNo++;
                         LV3.addColumn("40", "BSCHL");
                         LV3.addColumn("S", "KOART");
                         LV3.addColumn("S", "SHKZG");
                         LV3.addColumn(strBusinessArea, "GSBER");
                         LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                         LV3.addColumn(sValue3, "DMBTR");
                         LV3.addColumn(sValue3, "WRBTR");
                         LV3.addColumn(sValue3, "PSWBT");
                         //LV3.addColumn("Re-Imbursement: Hotel Fare", "SGTXT");
                         LV3.addColumn("Hotel Fare-" + sValue4 + "-" + sValue0 + "-" + sValue1, "SGTXT");
                         LV3.addColumn(strKOKRS, "KOKRS");
                         LV3.addColumn(strCostCenter, "KOSTL");

                         String strGLCode = "0000420040";
                         //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes starts here
                         //                String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                         if (strTypeOfTravel.equalsIgnoreCase("Domestic")) {
                         strGLCode = "0000420040";
                         } else if (strTypeOfTravel.equalsIgnoreCase("International")) {
                         strGLCode = "0000420042";
                         }
                         //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes ends here

                         LV3.addColumn(strGLCode, "SAKNR");
                         LV3.addColumn(strGLCode, "HKONT");
                         LV3.addColumn(strBusinessPlace, "BUPLA");
                         LV3.addColumn(strVendorCode, "ZUONR");

                         BAPIInput.append(LV3.builder.toString());
                         BAPIInput.append("</T_BSEG>");
                         }*/
                        if (sValue16.equalsIgnoreCase("Self")) {
                            CommonObj.writeToLog(2, "Other Than Company:", winame);

                            if (!sValue17.equalsIgnoreCase("Yes")) {
                                BAPIInput.append("<T_BSEG>");
                                ListViewItems LV3 = new ListViewItems();

                                LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                                LV3.addColumn(strCompanyCode, "BUKRS");
                                LV3.addColumn(strFiscalYr, "GJAHR");
                                LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                intLineNo++;
                                LV3.addColumn("40", "BSCHL");
                                LV3.addColumn("S", "KOART");
                                LV3.addColumn("S", "SHKZG");
                                LV3.addColumn(strBusinessArea, "GSBER");
                                LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                LV3.addColumn(sValue15, "DMBTR");
                                LV3.addColumn(sValue15, "WRBTR");
                                LV3.addColumn(sValue15, "PSWBT");
                                //LV3.addColumn("Re-Imbursement: Hotel Fare", "SGTXT");
                                LV3.addColumn("Hotel Fare-" + sValue14 + "-" + sValue0 + "-" + sValue1, "SGTXT");
//                            LV3.addColumn("Hotel Fare-" + sValue14, "SGTXT");
                                LV3.addColumn(strKOKRS, "KOKRS");
                                LV3.addColumn(strCostCenter, "KOSTL");

                                if (sValue17.equalsIgnoreCase("Yes")) {
//                                    LV3.addColumn(sValue5, "XREF1");//Britannia GST No/VAT
//                                    LV3.addColumn(sValue6, "XREF2");//Vendor GST No
                                    LV3.addColumn(sValue18, "HSN_SAC");//SAC Code
                                }

//                                String strGLCode = "0000420040";
                                String strGLCode = "0045090102";//HANA
                                //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes starts here
//                String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                                if (strTypeOfTravel.equalsIgnoreCase("Domestic")) {
//                                    strGLCode = "0000420040";
                                    strGLCode = "0045090102";//HANA
                                } else if (strTypeOfTravel.equalsIgnoreCase("International")
                                        || strTypeOfTravel.equalsIgnoreCase("International - Business Travel") //Added by SandeepKN on 05Dec2019 for SFIC and ASFI Changes
                                        || strTypeOfTravel.equalsIgnoreCase("International - Annual Leave travel")) {
//                                    strGLCode = "0000420042";
                                    strGLCode = "0045090201";//HANA
                                }
                                //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes ends here
//                                LV3.addColumn(strGLCode, "SAKNR");
                                LV3.addColumn(strGLCode, "HKONT");
                                LV3.addColumn(strBusinessPlace, "BUPLA");
                                LV3.addColumn(strVendorCode, "ZUONR");
                                BAPIInput.append(LV3.builder.toString());
                                BAPIInput.append("</T_BSEG>");
                            } else {
                                //Amount before tax
                                BAPIInput.append("<T_BSEG>");
                                ListViewItems LV3 = new ListViewItems();

                                LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                                LV3.addColumn(strCompanyCode, "BUKRS");
                                LV3.addColumn(strFiscalYr, "GJAHR");
                                LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                intLineNo++;
                                LV3.addColumn("40", "BSCHL");
                                LV3.addColumn("S", "KOART");
                                LV3.addColumn("S", "SHKZG");
                                LV3.addColumn(strBusinessArea, "GSBER");
                                LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                LV3.addColumn(sValue8, "DMBTR");
                                LV3.addColumn(sValue8, "WRBTR");
                                LV3.addColumn(sValue8, "PSWBT");
                                //LV3.addColumn("Re-Imbursement: Hotel Fare", "SGTXT");
//                                LV3.addColumn(sValue7 + " - Hotel Fare-" + sValue14 + "-" + sValue0 + "-" + sValue1, "SGTXT");
                                LV3.addColumn(sValue3 + ";" + sValue18 + ";" + sValue2, "SGTXT");
//                            LV3.addColumn("Hotel Fare-" + sValue14, "SGTXT");
                                LV3.addColumn(strKOKRS, "KOKRS");
                                LV3.addColumn(strCostCenter, "KOSTL");

                                if (sValue17.equalsIgnoreCase("Yes")) {
//                                    LV3.addColumn(sValue5, "XREF1");//Britannia GST No/VAT
//                                    LV3.addColumn(sValue6, "XREF2");//Vendor GST No moved to ZUONR
                                    LV3.addColumn(sValue18, "HSN_SAC");//SAC Code
                                }

//                                String strGLCode = "0000420040";
                                String strGLCode = "0045090102";//HANA
                                //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes starts here
//                String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                                if (strTypeOfTravel.equalsIgnoreCase("Domestic")) {
//                                    strGLCode = "0000420040";
                                    strGLCode = "0045090102";//HANA
                                } else if (strTypeOfTravel.equalsIgnoreCase("International")
                                        || strTypeOfTravel.equalsIgnoreCase("International - Business Travel") //Added by SandeepKN on 05Dec2019 for SFIC and ASFI Changes
                                        || strTypeOfTravel.equalsIgnoreCase("International - Annual Leave travel")) {
//                                    strGLCode = "0000420042";
                                    strGLCode = "0045090201";//HANA
                                }
                                //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes ends here
//                                LV3.addColumn(strGLCode, "SAKNR");
                                LV3.addColumn(strGLCode, "HKONT");
//                                LV3.addColumn(strBusinessPlace, "BUPLA");
                                LV3.addColumn(sValue19, "BUPLA");
                                LV3.addColumn(sValue6, "ZUONR");////Vendor GST No
                                BAPIInput.append(LV3.builder.toString());
                                BAPIInput.append("</T_BSEG>");

                                //SGST line-item
                                BAPIInput.append("<T_BSEG>");
                                ListViewItems LV31 = new ListViewItems();

                                LV31.addColumn(objSAPCall.SAPClient, "MANDT");
                                LV31.addColumn(strCompanyCode, "BUKRS");
                                LV31.addColumn(strFiscalYr, "GJAHR");
                                LV31.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                intLineNo++;
                                LV31.addColumn("40", "BSCHL");
                                LV31.addColumn("S", "KOART");
                                LV31.addColumn("S", "SHKZG");
                                LV31.addColumn(strBusinessArea, "GSBER");
                                LV31.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                LV31.addColumn(sValue10, "DMBTR");
                                LV31.addColumn(sValue10, "WRBTR");
                                LV31.addColumn(sValue10, "PSWBT");
                                //LV31.addColumn("Re-Imbursement: Hotel Fare", "SGTXT");
//                                LV31.addColumn(sValue7 + " - Hotel Fare-" + sValue14 + "-" + sValue0 + "-" + sValue1, "SGTXT");
                                LV3.addColumn(sValue3 + ";" + sValue18 + ";" + sValue2, "SGTXT");
//                            LV31.addColumn("Hotel Fare-" + sValue14, "SGTXT");
                                LV31.addColumn(strKOKRS, "KOKRS");
                                LV31.addColumn(strCostCenter, "KOSTL");

                                if (sValue17.equalsIgnoreCase("Yes")) {
//                                    LV31.addColumn(sValue5, "XREF1");//Britannia GST No/VAT
//                                    LV31.addColumn(sValue6, "XREF2");//Vendor GST No Moved to ZUONR
                                    LV31.addColumn(sValue18, "HSN_SAC");//SAC Code
                                }

                                String strGLCode1 = sValue20;
//                                LV31.addColumn(strGLCode1, "SAKNR");
                                LV31.addColumn(strGLCode1, "HKONT");
                                LV31.addColumn(sValue19, "BUPLA");
                                LV31.addColumn(sValue6, "ZUONR");////Vendor GST No
                                BAPIInput.append(LV31.builder.toString());
                                BAPIInput.append("</T_BSEG>");
                                //CGST line-item
                                BAPIInput.append("<T_BSEG>");
                                ListViewItems LV32 = new ListViewItems();

                                LV32.addColumn(objSAPCall.SAPClient, "MANDT");
                                LV32.addColumn(strCompanyCode, "BUKRS");
                                LV32.addColumn(strFiscalYr, "GJAHR");
                                LV32.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                intLineNo++;
                                LV32.addColumn("40", "BSCHL");
                                LV32.addColumn("S", "KOART");
                                LV32.addColumn("S", "SHKZG");
                                LV32.addColumn(strBusinessArea, "GSBER");
                                LV32.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                LV32.addColumn(sValue11, "DMBTR");
                                LV32.addColumn(sValue11, "WRBTR");
                                LV32.addColumn(sValue11, "PSWBT");
                                //LV32.addColumn("Re-Imbursement: Hotel Fare", "SGTXT");
//                                LV32.addColumn(sValue7 + " - Hotel Fare-" + sValue14 + "-" + sValue0 + "-" + sValue1, "SGTXT");
                                LV3.addColumn(sValue3 + ";" + sValue18 + ";" + sValue2, "SGTXT");
//                            LV32.addColumn("Hotel Fare-" + sValue14, "SGTXT");
                                LV32.addColumn(strKOKRS, "KOKRS");
                                LV32.addColumn(strCostCenter, "KOSTL");

                                if (sValue17.equalsIgnoreCase("Yes")) {
//                                    LV32.addColumn(sValue5, "XREF1");//Britannia GST No/VAT
//                                    LV32.addColumn(sValue6, "XREF2");//Vendor GST No Moved to ZUONR
                                    LV32.addColumn(sValue18, "HSN_SAC");//SAC Code
                                }

                                String strGLCode2 = sValue21;
//                                LV32.addColumn(strGLCode2, "SAKNR");
                                LV32.addColumn(strGLCode2, "HKONT");
                                LV32.addColumn(sValue19, "BUPLA");
                                LV32.addColumn(sValue6, "ZUONR");////Vendor GST No
                                BAPIInput.append(LV32.builder.toString());
                                BAPIInput.append("</T_BSEG>");
                            }

                        }

                        blnExecute = true;
                    }
                }//End of Hotel Fare
                CommonObj.writeToLog(2, "End of Hotel Fare", winame);

                //Addedby SandeepKN on 10JAn for ASFI and SFIC Changes-Start
                //SFIC and ASFI company codes Other Expenses starts
                if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                    int list_OtherExpenses = formObject.getItemCount("list_OtherExpenses");
                    CommonObj.writeToLog(2, "list_OtherExpenses Count:" + list_OtherExpenses, winame);
                    List<List<String>> list_OtherExpObject = CommonObj.getListViewValueInList(formObject, "list_OtherExpenses");
                    CommonObj.writeToLog(2, "list_OtherExpObject==" + list_OtherExpObject, winame);
                    CommonObj.writeToLog(2, "list_OtherExpObject Count:" + list_OtherExpObject.size(), winame);
                    if (list_OtherExpenses > 0) {
                        for (Integer i = 0; i < list_OtherExpObject.size(); i++) {
                            String OtherExpLineItemData[] = CommonObj.getRowValue(formObject, "list_OtherExpenses", i);
                            CommonObj.writeToLog(2, "list_OtherExpenses:intLineNo:" + intLineNo, winame);
                            String sValue0 = list_OtherExpObject.get(i).get(0).trim();
                            String sValue1 = OtherExpLineItemData[1].trim();
                            String sValue2 = OtherExpLineItemData[2].trim();
                            String sValue3 = OtherExpLineItemData[3].trim();
                            String sValue4 = OtherExpLineItemData[4].trim();
                            String sValue5 = OtherExpLineItemData[5].trim();
                            String sValue6 = OtherExpLineItemData[6].trim();
                            String sValue7 = OtherExpLineItemData[7].trim();
                            String sValue8 = OtherExpLineItemData[8].trim();
                            String sValue9 = OtherExpLineItemData[9].trim();
                            String sValue10 = OtherExpLineItemData[10].trim();
                            //added by sandeepkn on 23Dec2019 ASFI chnages-start
                            if (strCompanyCode.equalsIgnoreCase("ASFI")) {
                                CommonObj.writeToLog(2, "TotalAmount sValue10 ASFI11 ==> " + OtherExpLineItemData[10].trim(), winame);
                                double fAmount = (Double.parseDouble(OtherExpLineItemData[10].trim()) * 10);
                                NumberFormat formatter = new DecimalFormat("#0.000");//added by sandeepkn on 23Dec2019
                                sValue10 = (formatter.format(fAmount));
                                CommonObj.writeToLog(2, "The TotalAmount sValue10 Value is ASFI ==> " + sValue10, winame);
                            } else {
                                sValue10 = OtherExpLineItemData[10].trim();
                                CommonObj.writeToLog(2, "TotalAmount in else sValue10 part111 ==> " + sValue10, winame);
                            }//added by sandeepkn on 23Dec2019 ASFI chnages-end

                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue0:" + sValue0, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue1:" + sValue1, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue2:" + sValue2, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue3:" + sValue3, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue4:" + sValue4, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue5:" + sValue5, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue6:" + sValue6, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue7:" + sValue7, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue8:" + sValue8, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue9:" + sValue9, winame);
                            CommonObj.writeToLog(2, "list_OtherExpenses: sValue10:" + sValue10, winame);
                            CommonObj.writeToLog(2, "Other Than Company:", winame);

                            BAPIInput.append("<T_BSEG>");
                            ListViewItems LVOE3 = new ListViewItems();

                            LVOE3.addColumn(objSAPCall.SAPClient, "MANDT");
                            LVOE3.addColumn(strCompanyCode, "BUKRS");
                            LVOE3.addColumn(strFiscalYr, "GJAHR");
                            LVOE3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                            intLineNo++;
                            LVOE3.addColumn("40", "BSCHL");
                            LVOE3.addColumn("S", "KOART");
                            LVOE3.addColumn("S", "SHKZG");
                            LVOE3.addColumn(strBusinessArea, "GSBER");
                            LVOE3.addColumn("Y0", "MWSKZ");
                            LVOE3.addColumn(sValue10, "DMBTR");
                            LVOE3.addColumn(sValue10, "WRBTR");
                            LVOE3.addColumn(sValue10, "PSWBT");
                            LVOE3.addColumn("Other Expenses Fare-" + sValue7 + "-" + sValue0 + "-" + sValue1, "SGTXT");
                            LVOE3.addColumn(strKOKRS, "KOKRS");
                            LVOE3.addColumn(strCostCenter, "KOSTL");
//                            String strGLCode = "0000420040";
                            String strGLCode = "0045090102";//HANA
                            if (strTypeOfTravel.equalsIgnoreCase("Domestic")) {
//                                strGLCode = "0000420040";
                                strGLCode = "0045090102";//HANA
                            } //added by SandeepKN on 11Dec2019 as per NVIJAYA mail for CAB GL CODE updation--Start
                            else if (strTypeOfTravel.equalsIgnoreCase("International - Business Travel")
                                    || strTypeOfTravel.equalsIgnoreCase("International - Annual Leave travel")
                                    && sValue6.equalsIgnoreCase("Cab")) {
//                                strGLCode = "0000420914";
                                strGLCode = "0045090501";//HANA
                                CommonObj.writeToLog(2, "International Cab strGLCode---->" + strGLCode, winame);
                            }//added by SandeepKN on 11Dec2019 as per NVIJAYA mail for CAB GL CODE updation--ENd 
                            else if (strTypeOfTravel.equalsIgnoreCase("International - Business Travel")
                                    || strTypeOfTravel.equalsIgnoreCase("International - Annual Leave travel")
                                    && sValue6.equalsIgnoreCase("Food")) {//added by SandeepKN on 11Dec2019 as per NVIJAYA mail for FOOD GL CODE updation
//                                strGLCode = "0000420042";
                                strGLCode = "0045090201";//HANA
                                CommonObj.writeToLog(2, "International FOOD strGLCode---->" + strGLCode, winame);
                            }
//                                LVOE3.addColumn(strGLCode, "SAKNR");
                            LVOE3.addColumn(strGLCode, "HKONT");
                            LVOE3.addColumn(strBusinessPlace, "BUPLA");
                            LVOE3.addColumn(strVendorCode, "ZUONR");
                            BAPIInput.append(LVOE3.builder.toString());
                            BAPIInput.append("</T_BSEG>");
                            blnExecute = true;
                        }
                    }
                    CommonObj.writeToLog(2, "End of Other Expenses Fare", winame);
                }
                //SFIC and ASFI company codes Other Expenses ends

                //Addedby SandeepKN on 10JAn for ASFI and SFIC Changes-END
                int list_daily = formObject.getItemCount("list_daily");
                List<List<String>> list_dailyObject = CommonObj.getListViewValueInList(formObject, "list_daily");
                if (list_daily > 0) {
                    for (Integer i = 0; i < list_daily; i++) {
                        String DALineItemData[] = CommonObj.getRowValue(formObject, "list_daily", i);
                        CommonObj.writeToLog(2, "list_daily:intLineNo:" + intLineNo, winame);
                        BAPIInput.append("<T_BSEG>");
                        ListViewItems LV3 = new ListViewItems();
                        String sValue0 = DALineItemData[0].trim();
                        String sValue1 = DALineItemData[1].trim();
                        String sValue2 = DALineItemData[2].trim();
                        String sValue3 = DALineItemData[3].trim();
                        String sValue4 = DALineItemData[4].trim();
                        String sValue5 = DALineItemData[5].trim();

                        LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                        LV3.addColumn(strCompanyCode, "BUKRS");
                        LV3.addColumn(strFiscalYr, "GJAHR");
                        LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                        intLineNo++;
                        LV3.addColumn("40", "BSCHL");
                        LV3.addColumn("S", "KOART");
                        LV3.addColumn("S", "SHKZG");
                        LV3.addColumn(strBusinessArea, "GSBER");
                        LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                        LV3.addColumn(sValue5, "DMBTR");
                        LV3.addColumn(sValue5, "WRBTR");
                        LV3.addColumn(sValue5, "PSWBT");
                        //LV3.addColumn("Re-Imbursement:DA", "SGTXT");
                        LV3.addColumn("DA-" + sValue0 + "-" + sValue1, "SGTXT");
                        LV3.addColumn(strKOKRS, "KOKRS");//changed on 26-04-017 as for BDPL the parent companycode is still BIL1
                        LV3.addColumn(strCostCenter, "KOSTL");

//                        String strGLCode = "0000420040";
                        String strGLCode = "0045090102";//HANA
                        //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes starts here
//                String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                        if (strTypeOfTravel.equalsIgnoreCase("Domestic")) {
//                                strGLCode = "0000420040";//Modified by Sivashankar KS on 01-April-2019 as per mail from Jestus
//                            strGLCode = "0000420044";
                            strGLCode = "0045090700";//HANA
                        } else if (strTypeOfTravel.equalsIgnoreCase("International")) {
//                            strGLCode = "0000420042";
                            strGLCode = "0045090201";//HANA
                        }
                        //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes ends here

                        LV3.addColumn(strGLCode, "SAKNR");
                        LV3.addColumn(strGLCode, "HKONT");
                        LV3.addColumn(strBusinessPlace, "BUPLA");
                        LV3.addColumn(strVendorCode, "ZUONR");

                        BAPIInput.append(LV3.builder.toString());
                        BAPIInput.append("</T_BSEG>");
                        blnExecute = true;
                    }
                }//End of DA
                CommonObj.writeToLog(2, "End of DA", winame);

                int list_convey = formObject.getItemCount("list_convey");
                List<List<String>> list_conveyObject = CommonObj.getListViewValueInList(formObject, "list_convey");
                if (list_convey > 0) {
                    for (Integer i = 0; i < list_convey; i++) {
                        String ConvLineItemData[] = CommonObj.getRowValue(formObject, "list_convey", i);
                        CommonObj.writeToLog(2, "list_convey:intLineNo:" + intLineNo, winame);
                        BAPIInput.append("<T_BSEG>");
                        ListViewItems LV3 = new ListViewItems();
                        String sValue0 = ConvLineItemData[0].trim();
                        String sValue1 = ConvLineItemData[1].trim();
                        String sValue2 = ConvLineItemData[2].trim();
                        String sValue3 = ConvLineItemData[3].trim();
                        String sValue4 = ConvLineItemData[4].trim();

                        CommonObj.writeToLog(2, "Conveyance Amount:" + sValue3, winame);

                        LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                        LV3.addColumn(strCompanyCode, "BUKRS");
                        LV3.addColumn(strFiscalYr, "GJAHR");
                        LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                        intLineNo++;
                        LV3.addColumn("40", "BSCHL");
                        LV3.addColumn("S", "KOART");
                        LV3.addColumn("S", "SHKZG");
                        LV3.addColumn(strBusinessArea, "GSBER");
                        LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                        LV3.addColumn(sValue3, "DMBTR");
                        LV3.addColumn(sValue3, "WRBTR");
                        LV3.addColumn(sValue3, "PSWBT");
                        //LV3.addColumn("Re-Imbursement:Conveyance", "SGTXT");
                        LV3.addColumn("Conveyances-" + sValue4 + "-" + sValue0 + "-" + sValue1, "SGTXT");
                        LV3.addColumn(strKOKRS, "KOKRS");
                        LV3.addColumn(strCostCenter, "KOSTL");

//                        String strGLCode = "0000420914";
                        String strGLCode = "0045090501";//HANA
                        //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes starts here
//                String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                        if (strTypeOfTravel.equalsIgnoreCase("Domestic")) {
//                            strGLCode = "0000420914";
                            strGLCode = "0045090501";//HANA
                        } else if (strTypeOfTravel.equalsIgnoreCase("International")) {
//                            strGLCode = "0000420042";
                            strGLCode = "0045090201";//HANA
                        }
                        //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes ends here

                        LV3.addColumn(strGLCode, "SAKNR");
                        LV3.addColumn(strGLCode, "HKONT");
                        LV3.addColumn(strBusinessPlace, "BUPLA");
                        LV3.addColumn(strVendorCode, "ZUONR");
                        BAPIInput.append(LV3.builder.toString());
                        BAPIInput.append("</T_BSEG>");
                        blnExecute = true;
                    }
                }//End of Conveyance
                CommonObj.writeToLog(2, "End of Conveyance", winame);

                int list_misc = formObject.getItemCount("list_misc");
                List<List<String>> list_miscObject = CommonObj.getListViewValueInList(formObject, "list_misc");
                if (list_misc > 0) {
                    for (Integer i = 0; i < list_misc; i++) {
                        String MiscLineItemData[] = CommonObj.getRowValue(formObject, "list_misc", i);
                        CommonObj.writeToLog(2, "list_misc:intLineNo:" + intLineNo, winame);
                        BAPIInput.append("<T_BSEG>");
                        ListViewItems LV3 = new ListViewItems();
                        //Modified by Sivashankar ON 11-July-2019 as per mail from sivaram starts here
                        String sValue0 = MiscLineItemData[0].trim();//Bill Date
                        String sValue1 = MiscLineItemData[1].trim();//Amount
                        String sValue2 = MiscLineItemData[2].trim();//Particulars
                        String sValue3 = MiscLineItemData[3].trim();//Bill Number

                        CommonObj.writeToLog(2, "Misc Amount:" + sValue1, winame);

                        LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                        LV3.addColumn(strCompanyCode, "BUKRS");
                        LV3.addColumn(strFiscalYr, "GJAHR");
                        LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                        intLineNo++;
                        LV3.addColumn("40", "BSCHL");
                        LV3.addColumn("S", "KOART");
                        LV3.addColumn("S", "SHKZG");
                        LV3.addColumn(strBusinessArea, "GSBER");
                        LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                        LV3.addColumn(sValue1, "DMBTR");
                        LV3.addColumn(sValue1, "WRBTR");
                        LV3.addColumn(sValue1, "PSWBT");
                        //LV3.addColumn("Re-Imbursement:MISC", "SGTXT");
                        LV3.addColumn("MISC-" + sValue3 + "-" + sValue0 + "-" + sValue2, "SGTXT");
                        LV3.addColumn(strKOKRS, "KOKRS");
                        LV3.addColumn(strCostCenter, "KOSTL");

//                        String strGLCode = "0000420040";
                        String strGLCode = "0045090102";//HANA
                        //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes starts here
//                String strTypeOfTravel = formObject.getNGValue("TypeOfTravel");
                        if (strTypeOfTravel.equalsIgnoreCase("Domestic")) {
//                                strGLCode = "0000420040";//Modified by Sivashankar KS on 01-April-2019 as per mail from Jestus
//                            strGLCode = "0000420016";
                            strGLCode = "0045090600";//HANA
                        } else if (strTypeOfTravel.equalsIgnoreCase("International")) {
//                            strGLCode = "0000420042";
                            strGLCode = "0045090201";//HANA
                        }
                        //Added by Sivashankar KS on 27-Dec-2018 as per mail from sivaram on GL Code changes ends here

                        float mistamount = Float.parseFloat(sValue1);
                        CommonObj.writeToLog(2, "Misc Amount2 after convering to float:" + mistamount, winame);
                        //Modified by Sivashankar ON 11-July-2019 as per mail from sivaram ends here

                        //Modified by Harinatha R 2017/09/05   NOTE :: To park all the MISC lineitems under GLCode=0000420040, Confirmed by NVIJAYA
                        // strGLCode = "0000420040"; Note:- Commented by Sivashankar KS on 27-Dec-2018 confirmed by NVIJAYA
                        /*
                         if (mistamount >= 500) {
                         CommonObj.writeToLog(2, "Misc Amount2 >=500", winame);
                         strGLCode = "0000420063";
                            
                         } else {
                         strGLCode = "0000420040";
                         }
                         */
                        //Ended by Harinatha R 2017/09/05 
                        LV3.addColumn(strGLCode, "SAKNR");
                        LV3.addColumn(strGLCode, "HKONT");
                        LV3.addColumn(strBusinessPlace, "BUPLA");
                        LV3.addColumn(strVendorCode, "ZUONR");
                        BAPIInput.append(LV3.builder.toString());
                        BAPIInput.append("</T_BSEG>");
                        blnExecute = true;
                    }
                }//End of MISC
                CommonObj.writeToLog(2, "End of Misc", winame);

            }//End of Travel Expense
            //Modified By Harinath on 2017/03/22
            else if (strSubcategory1.equalsIgnoreCase("House Rent Advance") || strSubcategory1.equalsIgnoreCase("Salary Advance") || strSubcategory1.equalsIgnoreCase("Exceptional Advances") || strSubcategory1.equalsIgnoreCase("Imprest Cash")) {
                //Ended By Harinath on 2017/03/22

                LVI.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)), "BLDAT");
                LVI.addColumn(SAPDateFormat2.format(date), "BUDAT");
                LVI.addColumn("00", "MONAT");
                LVI.addColumn("FBV0", "TCODE");
                LVI.addColumn(decimalformat.format(dNewgenwiname), "XBLNR");
                LVI.addColumn(strSubcategory1 + " - " + strEmpName, "BKTXT");

                /*Modified by sivashankar ks on 31-May-2019 for Nepal change starts*/
                /* 
                 LVI.addColumn("INR", "WAERS");
                 LVI.addColumn("INR", "HWAER");
                 */
                if (strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LVI.addColumn("NPR", "WAERS");
                    LVI.addColumn("NPR", "HWAER");
                } else {
                    LVI.addColumn("INR", "WAERS");
                    LVI.addColumn("INR", "HWAER");
                }
                /*Modified by sivashankar ks on 31-May-2019 for Nepal change ends*/

                LVI.addColumn("V", "BSTAT");
                BAPIInput.append(LVI.builder.toString());
                BAPIInput.append("</T_BKPF>");

                BAPIInput.append("<T_BSEG>");
                ListViewItems LV2 = new ListViewItems();
                LV2.addColumn(objSAPCall.SAPClient, "MANDT");
                LV2.addColumn(strCompanyCode, "BUKRS");
                LV2.addColumn(strFiscalYr, "GJAHR");
                LV2.addColumn("001", "BUZEI");
                LV2.addColumn("31", "BSCHL");
                LV2.addColumn("K", "KOART");
                LV2.addColumn("H", "SHKZG");
                LV2.addColumn(strBusinessArea, "GSBER");
                LV2.addColumn(strTotalAmount, "DMBTR");
                LV2.addColumn(strTotalAmount, "WRBTR");
                LV2.addColumn(strTotalAmount, "PSWBT");
                LV2.addColumn(strSubcategory1 + " - " + strEmpName, "SGTXT");
//                String strGLCodeHeader = "0000220029";
                String strGLCodeHeader = "0012070206";//HANA
                LV2.addColumn(strGLCodeHeader, "HKONT");
                LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "LIFNR");
                //LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)), "ZFBDT");
                LV2.addColumn(SAPDateFormat2.format(date), "ZFBDT");
                LV2.addColumn(strBusinessPlace, "BUPLA");
//                LV2.addColumn(strBusinessPlace, "SECCO");
                if (!strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LV2.addColumn(strBusinessPlace, "SECCO");
                }
                BAPIInput.append(LV2.builder.toString());
                BAPIInput.append("</T_BSEG>");

                String DebitAmount = formObject.getNGValue("ClaimedAmount");
                CommonObj.writeToLog(2, "Employee Advances Amount:" + DebitAmount, winame);

                BAPIInput.append("<T_BSEG>");
                ListViewItems LV3 = new ListViewItems();
                LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                LV3.addColumn(strCompanyCode, "BUKRS");
                LV3.addColumn(strFiscalYr, "GJAHR");
                LV3.addColumn("002", "BUZEI");
                LV3.addColumn("40", "BSCHL");
                LV3.addColumn("S", "KOART");
                LV3.addColumn("S", "SHKZG");
                LV3.addColumn(strBusinessArea, "GSBER");
                //LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                LV3.addColumn(DebitAmount, "DMBTR");
                LV3.addColumn(DebitAmount, "WRBTR");
                LV3.addColumn(DebitAmount, "PSWBT");
                LV3.addColumn(strSubcategory1 + " - " + strEmpName, "SGTXT");
                LV3.addColumn(strKOKRS, "KOKRS");
                LV3.addColumn(strCostCenter, "KOSTL");

//                String strGLCode = "0000220029";
                String strGLCode = "0012070206";//HANA
                LV3.addColumn(strGLCode, "SAKNR");
                LV3.addColumn(strGLCode, "HKONT");
                LV3.addColumn(strBusinessPlace, "BUPLA");
                LV3.addColumn(strVendorCode, "ZUONR");
                BAPIInput.append(LV3.builder.toString());
                BAPIInput.append("</T_BSEG>");
                blnExecute = true;
                CommonObj.writeToLog(2, "End of Employee Advances", winame);
            }//End of Employee Advances
            else if (strTypeofinvoice.equalsIgnoreCase("Relocation")) {
                LVI.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)), "BLDAT");
                //LVI.addColumn(SAPDateFormat2.format(date), "BLDAT");
                LVI.addColumn(SAPDateFormat2.format(date), "BUDAT");
                LVI.addColumn("00", "MONAT");
                LVI.addColumn("FBV0", "TCODE");
                //LVI.addColumn(Newgenwiname, "XBLNR");
                LVI.addColumn(decimalformat.format(dNewgenwiname), "XBLNR");
                //LVI.addColumn(strSubcategory1 + " - " + strEmpName, "BKTXT");
                LVI.addColumn(strEmpName, "BKTXT");

                /*Modified by sivashankar ks on 31-May-2019 for Nepal change starts*/
                /* 
                 LVI.addColumn("INR", "WAERS");
                 LVI.addColumn("INR", "HWAER");
                 */
                if (strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LVI.addColumn("NPR", "WAERS");
                    LVI.addColumn("NPR", "HWAER");
                } else {
                    LVI.addColumn("INR", "WAERS");
                    LVI.addColumn("INR", "HWAER");
                }
                /*Modified by sivashankar ks on 31-May-2019 for Nepal change ends*/

                LVI.addColumn("V", "BSTAT");
                BAPIInput.append(LVI.builder.toString());
                BAPIInput.append("</T_BKPF>");

                BAPIInput.append("<T_BSEG>");
                ListViewItems LV2 = new ListViewItems();
                LV2.addColumn(objSAPCall.SAPClient, "MANDT");
                LV2.addColumn(strCompanyCode, "BUKRS");
                LV2.addColumn(strFiscalYr, "GJAHR");
                LV2.addColumn("001", "BUZEI");
                LV2.addColumn("31", "BSCHL");
                LV2.addColumn("K", "KOART");
                LV2.addColumn("H", "SHKZG");
                LV2.addColumn(strBusinessArea, "GSBER");
                LV2.addColumn(strTotalAmount, "DMBTR");
                LV2.addColumn(strTotalAmount, "WRBTR");
                LV2.addColumn(strTotalAmount, "PSWBT");
                LV2.addColumn(strSubcategory1 + " - " + strEmpName, "SGTXT");
//                String strGLCodeHeader = "0000420027";
                String strGLCodeHeader = "0045120501";//HANA
                LV2.addColumn(strGLCodeHeader, "HKONT");
                LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendorCode")), "LIFNR");
                //LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strDateOfReq)), "ZFBDT");
                LV2.addColumn(SAPDateFormat2.format(date), "ZFBDT");
                LV2.addColumn(strBusinessPlace, "BUPLA");
//                LV2.addColumn(strBusinessPlace, "SECCO");
                if (!strCompanyCode.equalsIgnoreCase("BNP1")) {
                    LV2.addColumn(strBusinessPlace, "SECCO");
                }
                BAPIInput.append(LV2.builder.toString());
                BAPIInput.append("</T_BSEG>");

                if (strSubcategory1.equalsIgnoreCase("Brokerage Fee")) {
                    String DebitAmount = formObject.getNGValue("Amount");
                    CommonObj.writeToLog(2, "Brokerage Fee Amount:" + DebitAmount, winame);
                    BAPIInput.append("<T_BSEG>");
                    ListViewItems LV3 = new ListViewItems();
                    LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                    LV3.addColumn(strCompanyCode, "BUKRS");
                    LV3.addColumn(strFiscalYr, "GJAHR");
                    LV3.addColumn("002", "BUZEI");
                    LV3.addColumn("40", "BSCHL");
                    LV3.addColumn("S", "KOART");
                    LV3.addColumn("S", "SHKZG");
                    LV3.addColumn(strBusinessArea, "GSBER");
                    LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                    LV3.addColumn(DebitAmount, "DMBTR");
                    LV3.addColumn(DebitAmount, "WRBTR");
                    LV3.addColumn(DebitAmount, "PSWBT");
                    LV3.addColumn(strSubcategory1 + " - " + strEmpName, "SGTXT");
                    LV3.addColumn(strKOKRS, "KOKRS");
                    LV3.addColumn(strCostCenter, "KOSTL");
//                    String strGLCode = "0000420027";
                    String strGLCode = "0045120501";//HANA
                    LV3.addColumn(strGLCode, "SAKNR");
                    LV3.addColumn(strGLCode, "HKONT");
                    LV3.addColumn(strBusinessPlace, "BUPLA");
                    LV3.addColumn(strVendorCode, "ZUONR");

                    BAPIInput.append(LV3.builder.toString());
                    BAPIInput.append("</T_BSEG>");
                    blnExecute = true;
                    CommonObj.writeToLog(2, "End of Brokerage Fee", winame);
                }//End of Brokerage Fee
                else if (strSubcategory1.equalsIgnoreCase("Moving of Personal Effects")) {
                    String DebitAmount = formObject.getNGValue("TotalAmount");
                    CommonObj.writeToLog(2, "Brokerage Fee Amount:" + DebitAmount, winame);
                    BAPIInput.append("<T_BSEG>");
                    ListViewItems LV3 = new ListViewItems();
                    LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                    LV3.addColumn(strCompanyCode, "BUKRS");
                    LV3.addColumn(strFiscalYr, "GJAHR");
                    LV3.addColumn("002", "BUZEI");
                    LV3.addColumn("40", "BSCHL");
                    LV3.addColumn("S", "KOART");
                    LV3.addColumn("S", "SHKZG");
                    LV3.addColumn(strBusinessArea, "GSBER");
                    LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                    LV3.addColumn(DebitAmount, "DMBTR");
                    LV3.addColumn(DebitAmount, "WRBTR");
                    LV3.addColumn(DebitAmount, "PSWBT");
                    LV3.addColumn(strSubcategory1 + " - " + strEmpName, "SGTXT");
                    LV3.addColumn(strKOKRS, "KOKRS");
                    LV3.addColumn(strCostCenter, "KOSTL");
//                    String strGLCode = "0000420910";
                    String strGLCode = "0042040701";//HANA

                    LV3.addColumn(strGLCode, "SAKNR");
                    LV3.addColumn(strGLCode, "HKONT");
                    LV3.addColumn(strBusinessPlace, "BUPLA");
                    LV3.addColumn(strVendorCode, "ZUONR");

                    BAPIInput.append(LV3.builder.toString());
                    BAPIInput.append("</T_BSEG>");
                    blnExecute = true;
                    CommonObj.writeToLog(2, "End of Moving of Personal Effects", winame);
                } else if (strSubcategory1.equalsIgnoreCase("Self Education Scheme")) {
                    Integer intLineNo = 2;
                    int Entertainment = formObject.getItemCount("list_Entertain");
                    CommonObj.writeToLog(2, "Entertainment Count:" + Entertainment, winame);
                    CommonObj.writeToLog(2, "list_Entertain:" + (formObject.getSelectedIndex("list_Entertain")), winame);
                    CommonObj.writeToLog(2, "getNGListView:list_Entertain:" + formObject.getNGListView("list_Entertain"), winame);
                    List<List<String>> ControlObject = CommonObj.getListViewValueInList(formObject, "list_Entertain");
                    CommonObj.writeToLog(2, "ControlObj==" + ControlObject, winame);

                    if (Entertainment > 0) {
                        for (Integer i = 0; i < Entertainment; i++) {
                            String EntertainLineItemData[] = CommonObj.getRowValue(formObject, "list_Entertain", i);
                            CommonObj.writeToLog(2, "intLineNo:" + intLineNo, winame);
                            String sValue0 = EntertainLineItemData[0].trim();
                            String sValue1 = EntertainLineItemData[1].trim();
                            String sValue2 = EntertainLineItemData[2].trim();
                            String sValue3 = EntertainLineItemData[3].trim();
                            String sValue4 = EntertainLineItemData[4].trim();
                            String sValue5 = EntertainLineItemData[5].trim();

                            BAPIInput.append("<T_BSEG>");
                            ListViewItems LV3 = new ListViewItems();

                            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                            LV3.addColumn(strCompanyCode, "BUKRS");
                            LV3.addColumn(strFiscalYr, "GJAHR");
                            LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                            intLineNo++;
                            LV3.addColumn("40", "BSCHL");
                            LV3.addColumn("S", "KOART");
                            LV3.addColumn("S", "SHKZG");
                            LV3.addColumn(strBusinessArea, "GSBER");
                            //LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                            LV3.addColumn(sValue5, "DMBTR");
                            LV3.addColumn(sValue5, "WRBTR");
                            LV3.addColumn(sValue5, "PSWBT");
                            LV3.addColumn("Re-Imbursement:Travel Fare", "SGTXT");
                            LV3.addColumn(strKOKRS, "KOKRS");
                            LV3.addColumn(strCostCenter, "KOSTL");

//                            String strGLCode = "0000409024";
                            String strGLCode = "0042040301";//HANA
                            LV3.addColumn(strGLCode, "SAKNR");
                            LV3.addColumn(strGLCode, "HKONT");
                            LV3.addColumn(strBusinessPlace, "BUPLA");
                            LV3.addColumn(strVendorCode, "ZUONR");

                            BAPIInput.append(LV3.builder.toString());
                            BAPIInput.append("</T_BSEG>");
                            blnExecute = true;
                        }
                    }//End of Self Education Scheme
                    blnExecute = true;
                    CommonObj.writeToLog(2, "Self Education Scheme", winame);

                } else if (strSubcategory1.equalsIgnoreCase("Joining Expense") || strSubcategory1.equalsIgnoreCase("Look and See Visit") || strSubcategory1.equalsIgnoreCase("Out of Pocket Expense") || strSubcategory1.equalsIgnoreCase("Relocation-TravelExpense-Own Vehicle") || strSubcategory1.equalsIgnoreCase("Relocation-Travel Expense")) {
                    CommonObj.writeToLog(2, "ER:ER:strSubcategory1>>>>>>:" + strSubcategory1, winame);

//                    String DebitGLCode = "0000420908";
                    String DebitGLCode = "0045121001";//HANA
                    if (strSubcategory1.equalsIgnoreCase("Joining Expense")) {
//                        DebitGLCode = "0000420908";
                        DebitGLCode = "0045121001";//HANA
                    } else if (strSubcategory1.equalsIgnoreCase("Look and See Visit")) {
//                        DebitGLCode = "0000420908";
                        DebitGLCode = "0045121001";//HANA
                    } else if (strSubcategory1.equalsIgnoreCase("Out of Pocket Expense")) {
//                        DebitGLCode = "0000420908";
                        DebitGLCode = "0045121001";//HANA
                    } else if (strSubcategory1.equalsIgnoreCase("Relocation-TravelExpense-Own Vehicle")) {
//                        DebitGLCode = "0000420908";
                        DebitGLCode = "0045121001";//HANA
                    } else if (strSubcategory1.equalsIgnoreCase("Relocation-Travel Expense")) {
//                        DebitGLCode = "0000420908";
                        DebitGLCode = "0045121001";//HANA
                    } else {
                        CommonObj.writeToLog(3, "GL Code not found for Debit", winame);
                    }

                    Integer intLineNo = 2;
                    int list_travel = formObject.getItemCount("list_travel");
                    CommonObj.writeToLog(2, "list_travel Count:" + list_travel, winame);
                    CommonObj.writeToLog(2, "list_Entertain:" + (formObject.getSelectedIndex("list_travel")), winame);
                    CommonObj.writeToLog(2, "getNGListView:list_travel:" + formObject.getNGListView("list_travel"), winame);
                    List<List<String>> ControlObject = CommonObj.getListViewValueInList(formObject, "list_travel");
                    CommonObj.writeToLog(2, "ControlObj==" + ControlObject, winame);

                    if (list_travel > 0) {
                        for (Integer i = 0; i < list_travel; i++) {
                            String TravelLineItemData[] = CommonObj.getRowValue(formObject, "list_travel", i);
                            CommonObj.writeToLog(2, "intLineNo:" + intLineNo, winame);

                            String sValue0 = TravelLineItemData[0].trim();
                            String sValue1 = TravelLineItemData[1].trim();
                            String sValue2 = TravelLineItemData[2].trim();
                            String sValue3 = TravelLineItemData[3].trim();
                            String sValue4 = TravelLineItemData[4].trim();
                            String sValue5 = TravelLineItemData[5].trim();
                            String sValue8 = TravelLineItemData[8].trim();
                            String sValue9 = TravelLineItemData[9].trim();
                            CommonObj.writeToLog(2, "sValue8:" + sValue8, winame);

                            if (!sValue8.equalsIgnoreCase("Company")) {
                                CommonObj.writeToLog(2, "Other Than Company:", winame);

                                BAPIInput.append("<T_BSEG>");
                                ListViewItems LV3 = new ListViewItems();

                                LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                                LV3.addColumn(strCompanyCode, "BUKRS");
                                LV3.addColumn(strFiscalYr, "GJAHR");
                                LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                intLineNo++;
                                LV3.addColumn("40", "BSCHL");
                                LV3.addColumn("S", "KOART");
                                LV3.addColumn("S", "SHKZG");
                                LV3.addColumn(strBusinessArea, "GSBER");
                                LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                LV3.addColumn(sValue9, "DMBTR");
                                LV3.addColumn(sValue9, "WRBTR");
                                LV3.addColumn(sValue9, "PSWBT");
                                LV3.addColumn("Re-Imbursement:Travel Fare", "SGTXT");
                                LV3.addColumn(strKOKRS, "KOKRS");
                                LV3.addColumn(strCostCenter, "KOSTL");

                                LV3.addColumn(DebitGLCode, "SAKNR");
                                LV3.addColumn(DebitGLCode, "HKONT");
                                LV3.addColumn(strBusinessPlace, "BUPLA");
                                LV3.addColumn(strVendorCode, "ZUONR");

                                BAPIInput.append(LV3.builder.toString());
                                BAPIInput.append("</T_BSEG>");
                            }
                            blnExecute = true;
                        }
                    }//End of Travel Fare Template
                    CommonObj.writeToLog(2, "End of Travel Fare", winame);

                    int list_hotel = formObject.getItemCount("list_hotel");
                    CommonObj.writeToLog(2, "list_hotel Count:" + list_hotel, winame);
                    List<List<String>> list_hotelObject = CommonObj.getListViewValueInList(formObject, "list_hotel");
                    CommonObj.writeToLog(2, "list_hotelObject==" + list_hotelObject, winame);
                    CommonObj.writeToLog(2, "list_hotelObject Count:" + list_hotelObject.size(), winame);
                    if (list_hotel > 0) {
                        for (Integer i = 0; i < list_hotel; i++) {
                            String HotellLineItemData[] = CommonObj.getRowValue(formObject, "list_hotel", i);
                            CommonObj.writeToLog(2, "list_hotel:intLineNo:" + intLineNo, winame);

                            String sValue0 = HotellLineItemData[0].trim();
                            String sValue1 = HotellLineItemData[1].trim();
                            String sValue2 = HotellLineItemData[2].trim();
                            String sValue3 = HotellLineItemData[3].trim();
                            String sValue4 = HotellLineItemData[4].trim();
                            String sValue5 = HotellLineItemData[5].trim();
                            String sValue6 = HotellLineItemData[6].trim();
                            String sValue7 = HotellLineItemData[7].trim();
                            String sValue8 = HotellLineItemData[8].trim();
                            String sValue9 = HotellLineItemData[9].trim();
                            String sValue10 = HotellLineItemData[10].trim();
                            String sValue11 = HotellLineItemData[11].trim();
                            String sValue12 = HotellLineItemData[12].trim();
                            String sValue13 = HotellLineItemData[13].trim();
                            String sValue14 = HotellLineItemData[14].trim();
                            String sValue15 = HotellLineItemData[15].trim();
                            String sValue16 = HotellLineItemData[16].trim();
                            String sValue17 = HotellLineItemData[17].trim();
                            String sValue18 = HotellLineItemData[18].trim();
                            String sValue19 = HotellLineItemData[19].trim();
                            String sValue20 = HotellLineItemData[20].trim();
                            String sValue21 = HotellLineItemData[21].trim();
                            CommonObj.writeToLog(2, "list_hotel: sValue0:" + sValue0, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue1:" + sValue1, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue2:" + sValue2, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue3:" + sValue3, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue4:" + sValue4, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue5:" + sValue5, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue6:" + sValue6, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue7:" + sValue7, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue8:" + sValue8, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue9:" + sValue9, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue10:" + sValue10, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue11:" + sValue11, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue12:" + sValue12, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue13:" + sValue13, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue14:" + sValue14, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue15:" + sValue15, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue16:" + sValue16, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue17:" + sValue17, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue18:" + sValue18, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue19:" + sValue19, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue20:" + sValue20, winame);
                            CommonObj.writeToLog(2, "list_hotel: sValue21:" + sValue21, winame);
                            /*
                             if (!sValue2.equalsIgnoreCase("Company")) {
                             CommonObj.writeToLog(2, "Other Than Company:", winame);

                             BAPIInput.append("<T_BSEG>");
                             ListViewItems LV3 = new ListViewItems();

                             LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                             LV3.addColumn(strCompanyCode, "BUKRS");
                             LV3.addColumn(strFiscalYr, "GJAHR");
                             LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                             intLineNo++;
                             LV3.addColumn("40", "BSCHL");
                             LV3.addColumn("S", "KOART");
                             LV3.addColumn("S", "SHKZG");
                             LV3.addColumn(strBusinessArea, "GSBER");
                             LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                             LV3.addColumn(sValue3, "DMBTR");
                             LV3.addColumn(sValue3, "WRBTR");
                             LV3.addColumn(sValue3, "PSWBT");
                             LV3.addColumn("Re-Imbursement: Hotel Fare", "SGTXT");
                             LV3.addColumn(strKOKRS, "KOKRS");
                             LV3.addColumn(strCostCenter, "KOSTL");

                             LV3.addColumn(DebitGLCode, "SAKNR");
                             LV3.addColumn(DebitGLCode, "HKONT");
                             LV3.addColumn(strBusinessPlace, "BUPLA");
                             LV3.addColumn(strVendorCode, "ZUONR");

                             BAPIInput.append(LV3.builder.toString());
                             BAPIInput.append("</T_BSEG>");
                             }
                             */
                            //Starts
                            if (sValue16.equalsIgnoreCase("Self")) {
                                CommonObj.writeToLog(2, "Other Than Company:", winame);

                                if (!sValue17.equalsIgnoreCase("Yes")) {
                                    BAPIInput.append("<T_BSEG>");
                                    ListViewItems LV3 = new ListViewItems();

                                    LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                                    LV3.addColumn(strCompanyCode, "BUKRS");
                                    LV3.addColumn(strFiscalYr, "GJAHR");
                                    LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                    intLineNo++;
                                    LV3.addColumn("40", "BSCHL");
                                    LV3.addColumn("S", "KOART");
                                    LV3.addColumn("S", "SHKZG");
                                    LV3.addColumn(strBusinessArea, "GSBER");
                                    LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                    LV3.addColumn(sValue15, "DMBTR");
                                    LV3.addColumn(sValue15, "WRBTR");
                                    LV3.addColumn(sValue15, "PSWBT");
                                    LV3.addColumn("Hotel Fare-" + sValue14 + "-" + sValue0 + "-" + sValue1, "SGTXT");
                                    LV3.addColumn(strKOKRS, "KOKRS");
                                    LV3.addColumn(strCostCenter, "KOSTL");
                                    if (sValue17.equalsIgnoreCase("Yes")) {
                                        LV3.addColumn(sValue18, "HSN_SAC");//SAC Code
                                    }
                                    LV3.addColumn(DebitGLCode, "SAKNR");
                                    LV3.addColumn(DebitGLCode, "HKONT");
                                    LV3.addColumn(strBusinessPlace, "BUPLA");
                                    LV3.addColumn(strVendorCode, "ZUONR");
                                    BAPIInput.append(LV3.builder.toString());
                                    BAPIInput.append("</T_BSEG>");
                                } else {
                                    //Amount before tax
                                    BAPIInput.append("<T_BSEG>");
                                    ListViewItems LV3 = new ListViewItems();

                                    LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                                    LV3.addColumn(strCompanyCode, "BUKRS");
                                    LV3.addColumn(strFiscalYr, "GJAHR");
                                    LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                    intLineNo++;
                                    LV3.addColumn("40", "BSCHL");
                                    LV3.addColumn("S", "KOART");
                                    LV3.addColumn("S", "SHKZG");
                                    LV3.addColumn(strBusinessArea, "GSBER");
                                    LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                    LV3.addColumn(sValue8, "DMBTR");
                                    LV3.addColumn(sValue8, "WRBTR");
                                    LV3.addColumn(sValue8, "PSWBT");
                                    LV3.addColumn(sValue3 + ";" + sValue18 + ";" + sValue2, "SGTXT");
                                    LV3.addColumn(strKOKRS, "KOKRS");
                                    LV3.addColumn(strCostCenter, "KOSTL");

                                    if (sValue17.equalsIgnoreCase("Yes")) {
                                        LV3.addColumn(sValue18, "HSN_SAC");//SAC Code
                                    }
                                    LV3.addColumn(DebitGLCode, "SAKNR");
                                    LV3.addColumn(DebitGLCode, "HKONT");
                                    LV3.addColumn(sValue19, "BUPLA");
                                    LV3.addColumn(sValue6, "ZUONR");
                                    BAPIInput.append(LV3.builder.toString());
                                    BAPIInput.append("</T_BSEG>");

                                    //SGST line-item
                                    BAPIInput.append("<T_BSEG>");
                                    ListViewItems LV31 = new ListViewItems();

                                    LV31.addColumn(objSAPCall.SAPClient, "MANDT");
                                    LV31.addColumn(strCompanyCode, "BUKRS");
                                    LV31.addColumn(strFiscalYr, "GJAHR");
                                    LV31.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                    intLineNo++;
                                    LV31.addColumn("40", "BSCHL");
                                    LV31.addColumn("S", "KOART");
                                    LV31.addColumn("S", "SHKZG");
                                    LV31.addColumn(strBusinessArea, "GSBER");
                                    LV31.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                    LV31.addColumn(sValue10, "DMBTR");
                                    LV31.addColumn(sValue10, "WRBTR");
                                    LV31.addColumn(sValue10, "PSWBT");
                                    LV3.addColumn(sValue3 + ";" + sValue18 + ";" + sValue2, "SGTXT");
                                    LV31.addColumn(strKOKRS, "KOKRS");
                                    LV31.addColumn(strCostCenter, "KOSTL");

                                    if (sValue17.equalsIgnoreCase("Yes")) {
                                        LV31.addColumn(sValue18, "HSN_SAC");//SAC Code
                                    }

                                    String strGLCode1 = sValue20;
                                    LV31.addColumn(strGLCode1, "SAKNR");
                                    LV31.addColumn(strGLCode1, "HKONT");
                                    LV31.addColumn(sValue19, "BUPLA");
                                    LV31.addColumn(sValue6, "ZUONR");
                                    BAPIInput.append(LV31.builder.toString());
                                    BAPIInput.append("</T_BSEG>");
                                    //CGST line-item
                                    BAPIInput.append("<T_BSEG>");
                                    ListViewItems LV32 = new ListViewItems();

                                    LV32.addColumn(objSAPCall.SAPClient, "MANDT");
                                    LV32.addColumn(strCompanyCode, "BUKRS");
                                    LV32.addColumn(strFiscalYr, "GJAHR");
                                    LV32.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                                    intLineNo++;
                                    LV32.addColumn("40", "BSCHL");
                                    LV32.addColumn("S", "KOART");
                                    LV32.addColumn("S", "SHKZG");
                                    LV32.addColumn(strBusinessArea, "GSBER");
                                    LV32.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                                    LV32.addColumn(sValue11, "DMBTR");
                                    LV32.addColumn(sValue11, "WRBTR");
                                    LV32.addColumn(sValue11, "PSWBT");
                                    LV3.addColumn(sValue3 + ";" + sValue18 + ";" + sValue2, "SGTXT");
                                    LV32.addColumn(strKOKRS, "KOKRS");
                                    LV32.addColumn(strCostCenter, "KOSTL");

                                    if (sValue17.equalsIgnoreCase("Yes")) {
                                        LV32.addColumn(sValue18, "HSN_SAC");//SAC Code
                                    }

                                    String strGLCode2 = sValue21;
                                    LV32.addColumn(strGLCode2, "SAKNR");
                                    LV32.addColumn(strGLCode2, "HKONT");
                                    LV32.addColumn(sValue19, "BUPLA");
                                    LV32.addColumn(sValue6, "ZUONR");
                                    BAPIInput.append(LV32.builder.toString());
                                    BAPIInput.append("</T_BSEG>");
                                }

                            }
                            //Ends

                            blnExecute = true;
                        }
                    }//End of Hotel Fare
                    CommonObj.writeToLog(2, "End of Hotel Fare", winame);

                    int list_daily = formObject.getItemCount("list_daily");
                    List<List<String>> list_dailyObject = CommonObj.getListViewValueInList(formObject, "list_daily");
                    if (list_daily > 0) {
                        for (Integer i = 0; i < list_daily; i++) {
                            String DALineItemData[] = CommonObj.getRowValue(formObject, "list_daily", i);
                            CommonObj.writeToLog(2, "list_daily:intLineNo:" + intLineNo, winame);

                            String sValue0 = DALineItemData[0].trim();
                            String sValue1 = DALineItemData[1].trim();
                            String sValue2 = DALineItemData[2].trim();
                            String sValue3 = DALineItemData[3].trim();
                            String sValue4 = DALineItemData[4].trim();
                            String sValue5 = DALineItemData[5].trim();

                            BAPIInput.append("<T_BSEG>");
                            ListViewItems LV3 = new ListViewItems();

                            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                            LV3.addColumn(strCompanyCode, "BUKRS");
                            LV3.addColumn(strFiscalYr, "GJAHR");
                            LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                            intLineNo++;
                            LV3.addColumn("40", "BSCHL");
                            LV3.addColumn("S", "KOART");
                            LV3.addColumn("S", "SHKZG");
                            LV3.addColumn(strBusinessArea, "GSBER");
                            LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                            LV3.addColumn(sValue5, "DMBTR");
                            LV3.addColumn(sValue5, "WRBTR");
                            LV3.addColumn(sValue5, "PSWBT");
                            LV3.addColumn("Re-Imbursement:DA", "SGTXT");
                            LV3.addColumn(strKOKRS, "KOKRS");
                            LV3.addColumn(strCostCenter, "KOSTL");

                            LV3.addColumn(DebitGLCode, "SAKNR");
                            LV3.addColumn(DebitGLCode, "HKONT");
                            LV3.addColumn(strBusinessPlace, "BUPLA");
                            LV3.addColumn(strVendorCode, "ZUONR");

                            BAPIInput.append(LV3.builder.toString());
                            BAPIInput.append("</T_BSEG>");
                            blnExecute = true;
                        }
                    }//End of DA
                    CommonObj.writeToLog(2, "End of DA", winame);

                    int list_convey = formObject.getItemCount("list_convey");
                    List<List<String>> list_conveyObject = CommonObj.getListViewValueInList(formObject, "list_convey");
                    if (list_convey > 0) {
                        for (Integer i = 0; i < list_convey; i++) {
                            String ConeyLineItemData[] = CommonObj.getRowValue(formObject, "list_convey", i);
                            CommonObj.writeToLog(2, "list_convey:intLineNo:" + intLineNo, winame);

                            String sValue0 = ConeyLineItemData[0].trim();
                            String sValue1 = ConeyLineItemData[1].trim();
                            String sValue2 = ConeyLineItemData[2].trim();
                            String sValue3 = ConeyLineItemData[3].trim();
                            String sValue4 = ConeyLineItemData[4].trim();

                            BAPIInput.append("<T_BSEG>");
                            ListViewItems LV3 = new ListViewItems();

                            CommonObj.writeToLog(2, "Conveyance Amount:" + sValue3, winame);
                            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                            LV3.addColumn(strCompanyCode, "BUKRS");
                            LV3.addColumn(strFiscalYr, "GJAHR");
                            LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                            intLineNo++;
                            LV3.addColumn("40", "BSCHL");
                            LV3.addColumn("S", "KOART");
                            LV3.addColumn("S", "SHKZG");
                            LV3.addColumn(strBusinessArea, "GSBER");
                            LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                            LV3.addColumn(sValue3, "DMBTR");
                            LV3.addColumn(sValue3, "WRBTR");
                            LV3.addColumn(sValue3, "PSWBT");
                            LV3.addColumn("Re-Imbursement:Conveyance", "SGTXT");
                            LV3.addColumn(strKOKRS, "KOKRS");
                            LV3.addColumn(strCostCenter, "KOSTL");

                            LV3.addColumn(DebitGLCode, "SAKNR");
                            LV3.addColumn(DebitGLCode, "HKONT");
                            LV3.addColumn(strBusinessPlace, "BUPLA");
                            LV3.addColumn(strVendorCode, "ZUONR");

                            BAPIInput.append(LV3.builder.toString());
                            BAPIInput.append("</T_BSEG>");
                            blnExecute = true;
                        }
                    }//End of Conveyance
                    CommonObj.writeToLog(2, "End of Conveyance", winame);

                    int list_misc = formObject.getItemCount("list_misc");
                    List<List<String>> list_miscObject = CommonObj.getListViewValueInList(formObject, "list_misc");
                    if (list_misc > 0) {
                        for (Integer i = 0; i < list_misc; i++) {
                            String MiscLineItemData[] = CommonObj.getRowValue(formObject, "list_misc", i);
                            CommonObj.writeToLog(2, "list_misc:intLineNo:" + intLineNo, winame);
                            //Modified by Sivashankar ON 11-July-2019 as per mail from sivaram starts here
                            String sValue0 = MiscLineItemData[0].trim();//Bill Date
                            String sValue1 = MiscLineItemData[1].trim();//Amount
                            String sValue2 = MiscLineItemData[2].trim();//Particulars
                            String sValue3 = MiscLineItemData[3].trim();//Bill Number
                            CommonObj.writeToLog(2, "Misc Amount:" + sValue1, winame);

                            BAPIInput.append("<T_BSEG>");
                            ListViewItems LV3 = new ListViewItems();
                            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                            LV3.addColumn(strCompanyCode, "BUKRS");
                            LV3.addColumn(strFiscalYr, "GJAHR");
                            LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                            intLineNo++;
                            LV3.addColumn("40", "BSCHL");
                            LV3.addColumn("S", "KOART");
                            LV3.addColumn("S", "SHKZG");
                            LV3.addColumn(strBusinessArea, "GSBER");
                            LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                            LV3.addColumn(sValue1, "DMBTR");
                            LV3.addColumn(sValue1, "WRBTR");
                            LV3.addColumn(sValue1, "PSWBT");
                            LV3.addColumn("Re-Imbursement:MISC", "SGTXT");
                            LV3.addColumn(strKOKRS, "KOKRS");
                            LV3.addColumn(strCostCenter, "KOSTL");

                            LV3.addColumn(DebitGLCode, "SAKNR");
                            LV3.addColumn(DebitGLCode, "HKONT");
                            LV3.addColumn(strBusinessPlace, "BUPLA");
                            LV3.addColumn(strVendorCode, "ZUONR");

                            BAPIInput.append(LV3.builder.toString());
                            BAPIInput.append("</T_BSEG>");
                            blnExecute = true;
                            //Modified by Sivashankar ON 11-July-2019 as per mail from sivaram ends here
                        }
                    }//End of MISC
                    CommonObj.writeToLog(2, "End of Misc", winame);

                    int list_medical = formObject.getItemCount("list_medical");
                    List<List<String>> list_medicalObject = CommonObj.getListViewValueInList(formObject, "list_medical");
                    if (list_medical > 0) {
                        for (Integer i = 0; i < list_medical; i++) {
                            String MediLineItemData[] = CommonObj.getRowValue(formObject, "list_medical", i);
                            CommonObj.writeToLog(2, "list_misc:intLineNo:" + intLineNo, winame);

                            String sValue0 = MediLineItemData[0].trim();
                            String sValue1 = MediLineItemData[1].trim();
                            String sValue2 = MediLineItemData[2].trim();
                            //String sValue3 = MediLineItemData[3].trim();
                            CommonObj.writeToLog(2, "list_medicalObject Amount:" + sValue2, winame);

                            BAPIInput.append("<T_BSEG>");
                            ListViewItems LV3 = new ListViewItems();
                            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
                            LV3.addColumn(strCompanyCode, "BUKRS");
                            LV3.addColumn(strFiscalYr, "GJAHR");
                            LV3.addColumn(CommonObj.appendzeros3(Integer.toString(intLineNo)), "BUZEI");
                            intLineNo++;
                            LV3.addColumn("40", "BSCHL");
                            LV3.addColumn("S", "KOART");
                            LV3.addColumn("S", "SHKZG");
                            LV3.addColumn(strBusinessArea, "GSBER");
                            LV3.addColumn("Y0", "MWSKZ");//debit line entry added on 10/02/2017
                            LV3.addColumn(sValue1, "DMBTR");
                            LV3.addColumn(sValue1, "WRBTR");
                            LV3.addColumn(sValue1, "PSWBT");
                            LV3.addColumn("Re-Imbursement:Medical", "SGTXT");
                            LV3.addColumn(strKOKRS, "KOKRS");
                            LV3.addColumn(strCostCenter, "KOSTL");

                            LV3.addColumn(DebitGLCode, "SAKNR");
                            LV3.addColumn(DebitGLCode, "HKONT");
                            LV3.addColumn(strBusinessPlace, "BUPLA");
                            LV3.addColumn(strVendorCode, "ZUONR");

                            BAPIInput.append(LV3.builder.toString());
                            BAPIInput.append("</T_BSEG>");
                            blnExecute = true;
                        }
                    }//End of Medical
                    CommonObj.writeToLog(2, "End of Medical", winame);

                }//End of Joining Expense and Others 
                //                else if (strSubcategory1.equalsIgnoreCase("Look and See Visit")) {
                //
                //                } else if (strSubcategory1.equalsIgnoreCase("Out of Pocket Expense")) {
                //
                //                } else if (strSubcategory1.equalsIgnoreCase("Relocation-TravelExpense-Own Vehicle")) {
                //
                //                } else if (strSubcategory1.equalsIgnoreCase("Relocation-Travel Expense")) {
                //
                //                } 
                else {
                    CommonObj.writeToLog(3, "strSubcategory1 is not matched", winame);
                    blnExecute = false;
                }
                CommonObj.writeToLog(2, "End of Invoice Type: Employee Re-Imbursement", winame);
            }//End of Invoice Type: Employee Re-Imbursement

            BAPIInput.append("</TableParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            //CommonObj.writeToLog(1, "BAPIInput PRELIMINARY_POSTING_FB01:" + BAPIInput.toString(), winame);

            if (blnExecute) {
                BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
                WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
                if (XmlResponse.getVal("MainCode").equals("0")) {
                    WFXmlList XMLListMessage = XmlResponse.createList("Parameters", "ExportParameters");

                    String strFIDOC_NO = XMLListMessage.getVal("GS_FIDOC").trim();
                    CommonObj.writeToLog(1, "strFIDOC_NO==" + strFIDOC_NO, winame);
                    if (strFIDOC_NO != "") {
                        formObject.setNGValue("SAPDocRefNo", strFIDOC_NO);
                        formObject.setNGValue("ParkedBy", formObject.getUserName());
                        formObject.setNGValue("ParkingDate", NGDateFormat.format(date));
                        formObject.RaiseEvent("WFSave");
                        outputResult = "SUCCESS";
                    }

                } else {
                    CommonObj.writeToLog(1, "BAPIInput ZPRELIMINARY_POSTING_FB01:Failed Execution", winame);
                    throw new ValidatorException(new FacesMessage("Parking Failed..!!!!", "Comments"));
                }
            }
            return outputResult;
        } catch (Exception e) {

            CommonObj.writeToLog(3, "Error In SAPPark: NONPO_Parking =" + e.getMessage(), winame);
            return outputResult;
        }
    }

    /**
     * --------------------------------------------------------------------//
     * Function Name :Parking_DocumentNo Input Parameters :strInput1,strInput2
     * Output parameters : Return Values :boolean Description :This function
     * used to retrieve parking document number Global variables : Author
     * :Nanjunda Moorthy B. Date :13-Dec-2016
     * --------------------------------------------------------------------
     */
    //Modified By Harinath on 2017/06/14
    public boolean Parking_DocumentNo(String strInput1, String strInput2, String strInput3) throws IOException {

        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();

            CommonObj.writeToLog(1, "IN SAP Function:Parking_DocumentNo:::>>>>", winame);
            CommonObj.writeToLog(1, "strUserName:" + strInput1, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZFI_FETCH_DOCUMENT_NO</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<GS_BELNR>" + strInput1 + "</GS_BELNR>");
            BAPIInput.append("<GS_GJAHR>" + strInput2 + "</GS_GJAHR>");
            BAPIInput.append("<GS_BUKRS>" + strInput3 + "</GS_BUKRS>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            CommonObj.writeToLog(1, "XmlResponse:" + XmlResponse, winame);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "GT_OUTPUT");

                String strSAPDocNo = XMLListMessage.getVal("BELNR").trim();
                String strPostDate = XMLListMessage.getVal("BUDAT").trim();
                String strPostedBy = XMLListMessage.getVal("USNAM").trim();
                CommonObj.writeToLog(1, "strSAPDocNo==" + strSAPDocNo, winame);
                CommonObj.writeToLog(1, "strPostDate==" + strPostDate, winame);
                CommonObj.writeToLog(1, "strPostedBy==" + strPostedBy, winame);
                //formObject.setNGValue("SAPDocRefNo", strSAPDocNo);                
                if (strPostDate != "") {
                    formObject.setNGValue("PostingDate", NGDateFormat.format((Date) SAPDateFormat.parse(strPostDate)));
                    formObject.setNGValue("PostBySAP", strPostedBy);
                }
                formObject.RaiseEvent("WFSave");
                return true;
            }

        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc =" + e.getMessage(), winame);
            return false;
        }
        return false;
    }

    //Ended By Harinath on 2017/06/14
    public String Parking_DueDate(String strBaseLineDate) {
        String outputResult = "FAIL";
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();

            CommonObj.writeToLog(1, "IN SAP Function:Parking_DueDate:::>>>>", winame);
            CommonObj.writeToLog(1, "strBaseLineDate:" + strBaseLineDate, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZFI_CALCULATE_DUE_DATE</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            //BAPIInput.append("<GS_MBLNR>" + formObject.getNGValue("MMDocNo") + "</GS_MBLNR>");
            BAPIInput.append("<GS_MBLNR>" + strBaseLineDate + "</GS_MBLNR>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("Parameters", "ExportParameters");

                String strSAPDueDate = XMLListMessage.getVal("GS_DUEDATE").trim();
                CommonObj.writeToLog(1, "strSAPDueDate==" + strSAPDueDate, winame);
                if (strSAPDueDate != "") {
                    formObject.setNGValue("DueDate", NGDateFormat.format((Date) SAPDateFormat.parse(strSAPDueDate)));
                    formObject.RaiseEvent("WFSave");
                    outputResult = "SUCCESS";
                }
            }
            return outputResult;
        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc =" + e.getMessage(), winame);
            return outputResult;
        }
    }

    /**
     * --------------------------------------------------------------------//
     * Function Name :updateLoanDataInSAP Input Parameters :formObject Output
     * parameters :true/false Return Values :boolean Description :This function
     * is used to post loan(employee advances) data into SAP Global variables :
     * Author :Harinatha R Date :13-Feb-2018
     * -------------------------------------------------------------------
     *
     * @param formObject-
     * @return
     */
    public boolean updateLoanDataInSAP(FormReference formObject) throws IOException, Exception {

        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        AP_CommonFunctions.writeToLog(2, "Inside updateLoanData() method..... ", winame);

        try {

            final String strSL = "BASA";
            final String strHRA = "BAHR";
            final String strEA = "BAEA";

            StringBuffer strIPXML = new StringBuffer();
            String strOPXML = null;
            String strApprvdDate = CommonObj.DB_QueryExecuteSelect1("select convert(VARCHAR(10),ParkingDate,104) from EXT_AP with(nolock) where WorkID='" + winame + "'");
            //Added on 06-NOV-20 for EMI caln based on submission date a/c SIRISHA
            String strSubmissionDate = CommonObj.DB_QueryExecuteSelect1("select convert(VARCHAR(10),InitEt,104) from EXT_AP with(nolock) where WorkID='" + winame + "'");
            //End on 06-NOV-20
            if (!strApprvdDate.equalsIgnoreCase("")) {

                String emiVal = String.valueOf(String.format("%.2f", ((Float.parseFloat(formObject.getNGValue("TotalAmount"))) / (Float.parseFloat(formObject.getNGValue("RepaymentSchedule"))))));
                AP_CommonFunctions.writeToLog(1, "strApprvdDate........................" + strApprvdDate + "  emiVal::: " + emiVal, winame);
                //CommonObj.writeToLog(1, "dateFormat.format(loanRepaymentDate(strApprvdDate))........................" + loanRepaymentDate(strApprvdDate), winame);

                //AP_CommonFunctions.writeToLog(1, "EMI Amount ::: " + emiVal, "");commented by sandeep.n on 09Jan2020
                AP_CommonFunctions.writeToLog(1, "EMI Amount ::: " + emiVal, winame);//added by sandeep.n on 09Jan2020
                strIPXML.append(objSAPCall.getconnectionstring());
                strIPXML.append("<SAPFunctionName>ZHR_RFC_LOAN_UPDATE</SAPFunctionName>");
                strIPXML.append("<Parameters>");
                strIPXML.append("<ImportParameters>");
                strIPXML.append("<IM_LOAN>");

                ListViewItems lv_IMLOANData = new ListViewItems();
                lv_IMLOANData.addColumn(formObject.getNGValue("EmployeeCode"), "PERNR");
                if (formObject.getNGValue("SubCategory1").equalsIgnoreCase("Salary Advance")) {
                    lv_IMLOANData.addColumn(strSL.trim(), "SUBTY");
                    lv_IMLOANData.addColumn(strSL.trim(), "DLART");
                    lv_IMLOANData.addColumn(dateFormat.format(loanRepaymentDate(strSubmissionDate)), "TILBG");//Modified on 06-NOV-20 for EMI caln based on submission date for Salary Advance
//                    lv_IMLOANData.addColumn(dateFormat.format(loanRepaymentDate(strApprvdDate)), "TILBG");
//                    lv_IMLOANData.addColumn(formObject.getNGValue("RepaymentSchedule"), "TILBT");
                } else if (formObject.getNGValue("SubCategory1").equalsIgnoreCase("House Rent Advance")) {
                    lv_IMLOANData.addColumn(strHRA.trim(), "SUBTY");
                    lv_IMLOANData.addColumn(strHRA.trim(), "DLART");
                    lv_IMLOANData.addColumn(dateFormat.format(loanRepaymentDate(strApprvdDate)), "TILBG");
//                    lv_IMLOANData.addColumn(formObject.getNGValue("RepaymentSchedule"), "TILBT");
                } else if (formObject.getNGValue("SubCategory1").equalsIgnoreCase("Exceptional Advances")) {
                    lv_IMLOANData.addColumn(strEA.trim(), "SUBTY");
                    lv_IMLOANData.addColumn(strEA.trim(), "DLART");
                    lv_IMLOANData.addColumn(dateFormat.format(loanRepaymentDate(strApprvdDate)), "TILBG");
//                    lv_IMLOANData.addColumn(formObject.getNGValue("RepaymentSchedule"), "TILBT");
                }
//                lv_IMLOANData.addColumn(dateFormat.format(loanRepaymentDate(strApprvdDate)), "TILBG");
                lv_IMLOANData.addColumn(String.valueOf(String.format("%.2f", (Float.parseFloat(formObject.getNGValue("TotalAmount"))) / (Float.parseFloat(formObject.getNGValue("RepaymentSchedule"))))), "TILBT");
                lv_IMLOANData.addColumn(strApprvdDate, "DATBW");
                lv_IMLOANData.addColumn(formObject.getNGValue("TotalAmount"), "DARBT");
                lv_IMLOANData.addColumn(strApprvdDate, "ZAHLD");
                lv_IMLOANData.addColumn("", "ZAHLA");
                lv_IMLOANData.addColumn(strApprvdDate, "BEGDA");
                lv_IMLOANData.addColumn("31.12.9999", "ENDDA");
                lv_IMLOANData.addColumn(formObject.getNGValue("SAPDocRefNo"), "EXTDL");

                strIPXML.append(lv_IMLOANData.builder.toString());
                strIPXML.append("</IM_LOAN>");
                strIPXML.append("</ImportParameters>");
                strIPXML.append("</Parameters>");
                strIPXML.append("</WFSAPInvokeFunction_Input>");

                strOPXML = objSAPCall.callServer(strIPXML.toString());
                WFXmlResponse XmlResponse = new WFXmlResponse(strOPXML);
                AP_CommonFunctions.writeToLog(1, "ZHR_RFC_LOAN_UPDATE function Main Code........................>>>>" + XmlResponse.getVal("MainCode"), winame);
                //Commented by SandeepKn on 12Mar2020 for Employee Advances request status
//                if (XmlResponse.getVal("MainCode").equals("0")) {
//                    AP_CommonFunctions.writeToLog(2, "updateLoanData() method sucess.....Main Code is zero", winame);
//                    AP_CommonFunctions.writeToLog(2, "End of updateLoanData() method..... ", winame);
//                    return true;
//                } 
                if (XmlResponse.getVal("MainCode").equals("0")
                        && XmlResponse.getVal("LV_RETURN").equals("Loan Updated Sucessfully")) {// Added by SandeepKN on 06Mar2020 for Employee Advances request status
                    AP_CommonFunctions.writeToLog(2, "Loan Updated Sucessfully --updateLoanData() method sucess.....Main Code is zero", winame);
                    AP_CommonFunctions.writeToLog(2, "End of updateLoanData() method..... ", winame);
                    return true;
                    // Added by SandeepKN on 06Mar2020 for Employee Advances request status--Start
                } else if (XmlResponse.getVal("LV_RETURN").equals("Loan Already updated for this employee")) {// Added by SandeepKN on 06Mar2020 for Employee Advances request status
                    AP_CommonFunctions.writeToLog(2, "Loan Already updated for this employee.....Main Code is zero", winame);
                    AP_CommonFunctions.writeToLog(2, "End of updateLoanData() method..... ", winame);
                    return true;
                } else if (XmlResponse.getVal("LV_RETURN").equals("Loan Not Updated For The Employee")) {// Added by SandeepKN on 06Mar2020 for Employee Advances request status
                    AP_CommonFunctions.writeToLog(2, "Loan Not Updated For The Employee", winame);
                    AP_CommonFunctions.writeToLog(2, "End of updateLoanData() method..... ", winame);
                    return false;
                } else {// Added by SandeepKN on 06Mar2020 for Employee Advances request status--End
                    AP_CommonFunctions.writeToLog(3, "ERROR:: In updateLoanData() method..... Main Code" + XmlResponse.getVal("MainCode"), winame);
                    AP_CommonFunctions.writeToLog(2, "End of updateLoanData() method..... ", winame);
                    return false;
                }
            } else {
                AP_CommonFunctions.writeToLog(3, "ERROR:: Error in updateLoanData() method..... " + strApprvdDate, winame);
                AP_CommonFunctions.writeToLog(2, "End of updateLoanData() method..... ", winame);
                return false;
            }
        } catch (Exception e) {

            AP_CommonFunctions.writeToLog(3, "ERROR:: Exception in updateLoanData() method..... " + e.getMessage(), winame);
            AP_CommonFunctions.writeToLog(3, "ERROR:: Exception in updateLoanData() method..... " + e.getStackTrace(), winame);
            AP_CommonFunctions.writeToLog(2, "End of updateLoanData() method..... ", winame);
            return false;
        }
    }

    private Date loanRepaymentDate(String strIPDate) throws ParseException {

        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        AP_CommonFunctions.writeToLog(2, "Inside  loanRepaymentDate() method...", winame);
        Date retrnDate = null;
        try {
            AP_CommonFunctions.writeToLog(2, "strIPDate...  " + strIPDate, winame);
            if (!strIPDate.equalsIgnoreCase("")) {
                Date ipDate = dateFormat.parse(strIPDate);
                AP_CommonFunctions.writeToLog(2, "ipDate :: " + dateFormat.format(ipDate), winame);
                Calendar cal1 = Calendar.getInstance();
                cal1.setTime(ipDate);
                int dayNum = cal1.get(Calendar.DAY_OF_MONTH);
                AP_CommonFunctions.writeToLog(2, "dayNum::: " + dayNum + " monthNum:::" + Calendar.MONTH + "   date:: " + dateFormat.format(cal1.getTime()), winame);
                if (dayNum <= 20) {
                    //cal1.add(Calendar.DATE, 20 - dayNum);
                    //cal1.add(Calendar.DATE, dayNum);
                    AP_CommonFunctions.writeToLog(2, " after incrementing date :: " + dateFormat.format(ipDate), winame);
                    retrnDate = dateFormat.parse(dateFormat.format(cal1.getTime()));
                } else {
                    cal1.set(Calendar.DATE, 01);
                    cal1.add(Calendar.MONTH, 1);
                    AP_CommonFunctions.writeToLog(2, " after incrementing month :: " + dateFormat.format(cal1.getTime()), winame);
                    retrnDate = dateFormat.parse(dateFormat.format(cal1.getTime()));
                }
            } else {
                AP_CommonFunctions.writeToLog(3, "ERROR:: strIPDate is null..... " + strIPDate, winame);
            }

        } catch (Exception e) {
            AP_CommonFunctions.writeToLog(3, "ERROR:: Exception in loanRepaymentDate() method..... " + e.getMessage(), winame);
            AP_CommonFunctions.writeToLog(3, "ERROR:: Exception in loanRepaymentDate() method..... " + e.getStackTrace(), winame);
            AP_CommonFunctions.writeToLog(2, "End of  loanRepaymentDate() method...", winame);
            retrnDate = null;
        }
        AP_CommonFunctions.writeToLog(2, "End of  loanRepaymentDate() method...", winame);
        return retrnDate;
    }
}
