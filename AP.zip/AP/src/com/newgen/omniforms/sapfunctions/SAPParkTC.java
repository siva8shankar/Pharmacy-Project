/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.IOException;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author Nanjundamoorthy.b
 */
public class SAPParkTC implements Serializable {

    SAPCall objSAPCall = new SAPCall();
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfDt = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat SAPDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat SAPDateFormat2 = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat NGDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    DecimalFormat decimalformat = new DecimalFormat("0");

    public String ParkingTCCab(String strInput1){
        String outputResult = "FAIL";
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {
            
            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            String steUserName = formObject.getUserName();

            CommonObj.writeToLog(1, "IN SAP Function:TC Parking DMS No:::>>>>" + winame, winame);
            String Newgenwiname = winame;//.replaceAll("AP-","");
            Newgenwiname = Newgenwiname.replaceAll("-Payments", "");
            Newgenwiname = Newgenwiname.replaceAll("-Process", "");
            Newgenwiname = Newgenwiname.replaceAll("AP-", "");
            int widlength = Newgenwiname.length();
            if (widlength > 15) {
                Newgenwiname = Newgenwiname.substring(widlength - 15, widlength);
            }
            //winame=winame.substring(0,winame.length() -8);
            double dNewgenwiname=Double.parseDouble(Newgenwiname);
            CommonObj.writeToLog(1, "IN SAP Function:TC Parking DMS No 2 SAP::Newgenwiname:>>>>" + Newgenwiname, winame);
            String strCurrentDate = formObject.getNGValue("CurrentDateTime");
            CommonObj.writeToLog(1, "IN SAP Function:strCurrentDate::" + strCurrentDate, winame);
            boolean blnExecute=false;
            String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
            String strSubcategory1 = formObject.getNGValue("SubCategory1");
            
            String strDateOfReq= formObject.getNGValue("DateOfReq");     
            String strCompanyCode = formObject.getNGValue("CompanyCode");
            String strEmpCode = formObject.getNGValue("EmployeeCode");
            String strFiscalYr = formObject.getNGValue("FiscalYr");
            String strVendorCode = formObject.getNGValue("VendCode");
            String strPO_NO = formObject.getNGValue("PONumber");
            String strEmpName = formObject.getNGValue("EmployeeName");
            String strDesaigntion = formObject.getNGValue("Designation");
            String strDept = formObject.getNGValue("Department");
            String strGrade = formObject.getNGValue("Grade");
            String strCostCenter = formObject.getNGValue("CostCenter");
            String strBusinessArea = formObject.getNGValue("BusinessArea");
            String strOrgLoc = formObject.getNGValue("OriginalLocation"); 
            
            String strTotalAmount = formObject.getNGValue("TotInvoiceAmnt");            
            String strInvoiceDate= formObject.getNGValue("InvoiceDate");
            
            
            String qryBusinessPlace="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+strBusinessArea+"'";
            String strBusinessPlace=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlace); 
            CommonObj.writeToLog(2, "qryBusinessPlace:" + qryBusinessPlace, winame);
            CommonObj.writeToLog(2, "strBusinessPlace:" + strBusinessPlace, winame);
            
            

            BAPIInput.append(objSAPCall.getconnectionstring());
            CommonObj.writeToLog(1, "IN SAP Function:TC Parking:SAPClient:" + objSAPCall.SAPClient, winame);
            BAPIInput.append("<SAPFunctionName>ZPRELIMINARY_POSTING_FB01</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<I_TCODE>FBV0</I_TCODE>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("<TableParameters>");
            BAPIInput.append("<T_BKPF>");
            ListViewItems LVI = new ListViewItems();
            LVI.addColumn(strCompanyCode, "BUKRS");
            LVI.addColumn(strFiscalYr, "GJAHR");
            LVI.addColumn("AD", "BLART");
            
            LVI.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strInvoiceDate)), "BLDAT");
            LVI.addColumn(SAPDateFormat2.format(date), "BUDAT");
            LVI.addColumn("00", "MONAT");
            //LVI.addColumn("FV60", "TCODE");
            LVI.addColumn("FBV0", "TCODE");
            LVI.addColumn(decimalformat.format(dNewgenwiname), "XBLNR");
            LVI.addColumn(formObject.getNGValue("VendName"), "BKTXT");
            LVI.addColumn("INR", "WAERS");
            LVI.addColumn("INR", "HWAER");
            LVI.addColumn("V", "BSTAT");            
            BAPIInput.append(LVI.builder.toString());
            BAPIInput.append("</T_BKPF>");
            
            if(strTypeofinvoice.equalsIgnoreCase("Cab")){
            
//            String qryTravelLI="select PID, ItemAmount, InvoiceNo, vendorcode, costcenter, busarea from EXT_AP_Travel_Lineitems with(nolock) where PID='"+winame+"'";
//            String strTravelLIArray[]=CommonObj.DB_QueryExecute(qryTravelLI);
//            CommonObj.writeToLog(2, "Travel LI Count:" + Arrays.toString(strTravelLIArray), winame); 
            
            String qryCablLI="SELECT Bus_Area,InvoiceDate, Vendor_Code, Trip_Date, PlacesVisited, Net_Amount, Cost_Center FROM EXT_AP_Cab_Lineitems WITH(NOLOCK) WHERE PID='"+winame+"'";
            CommonObj.writeToLog(2, "Cab qryCablLI:" + qryCablLI, winame); 
            //String strCabLIArray[]=CommonObj.DB_QueryExecute(qryCablLI);
            //CommonObj.writeToLog(2, "Cab LI Count:" + Arrays.toString(strCabLIArray), winame); 
            List<List<String>> ListCabLI= CommonObj.DB_QuerySelectMultiLine(qryCablLI);
            CommonObj.writeToLog(2, "ListCabLI in PARK TC:" + ListCabLI, winame); 
            
            for (Integer i = 0; i < ListCabLI.size(); i++) { 
            String sValue0=ListCabLI.get(i).get(0);
            String sValue1=ListCabLI.get(i).get(1);
            String sValue2=ListCabLI.get(i).get(2);
            String sValue3=ListCabLI.get(i).get(3);
            String sValue4=ListCabLI.get(i).get(4);
            String sValue5=ListCabLI.get(i).get(5); 
            String sValue6=ListCabLI.get(i).get(6);
            
//            System.out.println("sValue0=="+sValue0);
//            System.out.println("sValue1=="+sValue1);
//            System.out.println("sValue2=="+sValue2);
//            System.out.println("sValue3=="+sValue3);
//            System.out.println("sValue4=="+sValue4);
//            System.out.println("sValue5=="+sValue5);
//            System.out.println("sValue6=="+sValue6);
                
            BAPIInput.append("<T_BSEG>");            
            ListViewItems LV2 = new ListViewItems();
            LV2.addColumn(objSAPCall.SAPClient, "MANDT");
            LV2.addColumn(strCompanyCode, "BUKRS");
            LV2.addColumn(strFiscalYr, "GJAHR");
            LV2.addColumn("001", "BUZEI");
            LV2.addColumn("31", "BSCHL");
            LV2.addColumn("K", "KOART");
            LV2.addColumn("H", "SHKZG");
            
            LV2.addColumn(sValue0, "GSBER");
            LV2.addColumn(strTotalAmount, "DMBTR");
            LV2.addColumn(strTotalAmount, "WRBTR");
            LV2.addColumn(strTotalAmount, "PSWBT");            
            LV2.addColumn(formObject.getNGValue("DocHeadText"), "SGTXT");
            LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendCode")), "HKONT");
            LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("Assignment")), "LIFNR");
            LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strInvoiceDate)), "ZFBDT");
            String qryBusinessPlaceLI="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+sValue0+"'";
            String strBusinessPlaceLI=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlaceLI);
            LV2.addColumn(strBusinessPlaceLI, "BUPLA");
            LV2.addColumn(strBusinessPlaceLI, "SECCO");
            BAPIInput.append(LV2.builder.toString());
            BAPIInput.append("</T_BSEG>");
            break;
            }
            
            Integer intLineNo=2;
            for (Integer i = 0; i < ListCabLI.size(); i++) { 
            CommonObj.writeToLog(2,"intLineNo:"+intLineNo,winame); 
            BAPIInput.append("<T_BSEG>");
            ListViewItems LV3 = new ListViewItems();
            
            String sValue0=ListCabLI.get(i).get(0);
            String sValue1=ListCabLI.get(i).get(1);
            String sValue2=ListCabLI.get(i).get(2);
            String sValue3=ListCabLI.get(i).get(3);
            String sValue4=ListCabLI.get(i).get(4);
            String sValue5=ListCabLI.get(i).get(5); 
            String sValue6=ListCabLI.get(i).get(6);
            
//            
//            System.out.println("sValue0=="+sValue0);
//            System.out.println("sValue1=="+sValue1);
//            System.out.println("sValue2=="+sValue2);
//            System.out.println("sValue3=="+sValue3);
//            System.out.println("sValue4=="+sValue4);
//            System.out.println("sValue5=="+sValue5);
//            System.out.println("sValue6=="+sValue6);
            String sItemText="";
            sItemText=sValue2+"-"+sValue3+"-"+sValue4;
            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
            LV3.addColumn(strCompanyCode, "BUKRS");
            LV3.addColumn(strFiscalYr, "GJAHR");
            CommonObj.writeToLog(2,"intLineNo:appendzerosN(Integer.toString(intLineNo),3)="+CommonObj.appendzerosN(Integer.toString(intLineNo),3),winame); 
            LV3.addColumn(CommonObj.appendzerosN(Integer.toString(intLineNo),3), "BUZEI");
            intLineNo++;
            LV3.addColumn("40", "BSCHL");
            LV3.addColumn("S", "KOART");
            LV3.addColumn("S", "SHKZG");
            LV3.addColumn(sValue0, "GSBER");
            LV3.addColumn(sValue5, "DMBTR");
            LV3.addColumn(sValue5, "WRBTR");
            LV3.addColumn(sValue5, "PSWBT");            
            LV3.addColumn(sItemText, "SGTXT");
            LV3.addColumn(strCompanyCode, "KOKRS");
            LV3.addColumn(sValue6, "KOSTL");
            LV3.addColumn("0000420004", "SAKNR");
            LV3.addColumn("0000420004", "HKONT");
            String qryBusinessPlaceLI="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+sValue0+"'";
            String strBusinessPlaceLI=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlaceLI);
            LV3.addColumn(strBusinessPlaceLI, "BUPLA");
            BAPIInput.append(LV3.builder.toString());
            BAPIInput.append("</T_BSEG>");            
            blnExecute=true;            
            }
            
            }//End of Cab
            else if(strTypeofinvoice.equalsIgnoreCase("Travel")){
            
            String qryTravelLI="select busarea, BookDate,vendorcode, FlightDate, Sector, BaseFare, FlightNo, ItemAmount, InvoiceNo, costcenter from EXT_AP_Travel_Lineitems with(nolock) where PID='"+winame+"'";
            CommonObj.writeToLog(2, "Cab qryTravelLI:" + qryTravelLI, winame);             
            List<List<String>> ListTravelLI= CommonObj.DB_QuerySelectMultiLine(qryTravelLI);
            CommonObj.writeToLog(2, "ListTravelLI in PARK TC:" + ListTravelLI, winame); 
            
            for (Integer i = 0; i < ListTravelLI.size(); i++) { 
            String sValue0=ListTravelLI.get(i).get(0);
            String sValue1=ListTravelLI.get(i).get(1);
            String sValue2=ListTravelLI.get(i).get(2);
            String sValue3=ListTravelLI.get(i).get(3);
            String sValue4=ListTravelLI.get(i).get(4);
            String sValue5=ListTravelLI.get(i).get(5); 
            String sValue6=ListTravelLI.get(i).get(6);
//            
//            System.out.println("sValue0=="+sValue0);
//            System.out.println("sValue1=="+sValue1);
//            System.out.println("sValue2=="+sValue2);
//            System.out.println("sValue3=="+sValue3);
//            System.out.println("sValue4=="+sValue4);
//            System.out.println("sValue5=="+sValue5);
//            System.out.println("sValue6=="+sValue6);
                
            BAPIInput.append("<T_BSEG>");            
            ListViewItems LV2 = new ListViewItems();
            LV2.addColumn(objSAPCall.SAPClient, "MANDT");
            LV2.addColumn(strCompanyCode, "BUKRS");
            LV2.addColumn(strFiscalYr, "GJAHR");
            LV2.addColumn("001", "BUZEI");
            LV2.addColumn("31", "BSCHL");
            LV2.addColumn("K", "KOART");
            LV2.addColumn("H", "SHKZG");
            
            LV2.addColumn(sValue0, "GSBER");
            LV2.addColumn(strTotalAmount, "DMBTR");
            LV2.addColumn(strTotalAmount, "WRBTR");
            LV2.addColumn(strTotalAmount, "PSWBT");            
            LV2.addColumn(formObject.getNGValue("DocHeadText"), "SGTXT");
            LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("VendCode")), "HKONT");
            LV2.addColumn(CommonObj.appendzeros(formObject.getNGValue("Assignment")), "LIFNR");
            LV2.addColumn(SAPDateFormat2.format((Date) NGDateFormat.parse(strInvoiceDate)), "ZFBDT");
            String qryBusinessPlaceLI="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+sValue0+"'";
            String strBusinessPlaceLI=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlaceLI);
            LV2.addColumn(strBusinessPlaceLI, "BUPLA");
            LV2.addColumn(strBusinessPlaceLI, "SECCO");
            BAPIInput.append(LV2.builder.toString());
            BAPIInput.append("</T_BSEG>");
            break;
            }
            
            Integer intLineNo=2;
            for (Integer i = 0; i < ListTravelLI.size(); i++) { 
            CommonObj.writeToLog(2,"intLineNo:"+intLineNo,winame); 
            BAPIInput.append("<T_BSEG>");
            ListViewItems LV3 = new ListViewItems();
            
            String sValue0=ListTravelLI.get(i).get(0);
            String sValue1=ListTravelLI.get(i).get(1);
            String sValue2=ListTravelLI.get(i).get(2);
            String sValue3=ListTravelLI.get(i).get(3);
            String sValue4=ListTravelLI.get(i).get(4);
            String sValue5=ListTravelLI.get(i).get(5); 
            String sValue6=ListTravelLI.get(i).get(6);
//            
//            
//            System.out.println("sValue0=="+sValue0);
//            System.out.println("sValue1=="+sValue1);
//            System.out.println("sValue2=="+sValue2);
//            System.out.println("sValue3=="+sValue3);
//            System.out.println("sValue4=="+sValue4);
//            System.out.println("sValue5=="+sValue5);
//            System.out.println("sValue6=="+sValue6);
            String sItemText="";
            sItemText=sValue2+"-"+sValue3+"-"+sValue4;
            LV3.addColumn(objSAPCall.SAPClient, "MANDT");
            LV3.addColumn(strCompanyCode, "BUKRS");
            LV3.addColumn(strFiscalYr, "GJAHR");
            CommonObj.writeToLog(2,"intLineNo:appendzerosN(Integer.toString(intLineNo),3)="+CommonObj.appendzerosN(Integer.toString(intLineNo),3),winame); 
            LV3.addColumn(CommonObj.appendzerosN(Integer.toString(intLineNo),3), "BUZEI");
            intLineNo++;
            LV3.addColumn("40", "BSCHL");
            LV3.addColumn("S", "KOART");
            LV3.addColumn("S", "SHKZG");
            LV3.addColumn(sValue0, "GSBER");
            LV3.addColumn(sValue5, "DMBTR");
            LV3.addColumn(sValue5, "WRBTR");
            LV3.addColumn(sValue5, "PSWBT");            
            LV3.addColumn(sItemText, "SGTXT");
            LV3.addColumn(strCompanyCode, "KOKRS");
            LV3.addColumn(sValue6, "KOSTL");
            LV3.addColumn("0000420004", "SAKNR");
            LV3.addColumn("0000420004", "HKONT");
            String qryBusinessPlaceLI="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+sValue0+"'";
            String strBusinessPlaceLI=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlaceLI);
            LV3.addColumn(strBusinessPlaceLI, "BUPLA");
            BAPIInput.append(LV3.builder.toString());
            BAPIInput.append("</T_BSEG>");            
            blnExecute=true;            
            }
                
            }
            
            else
            {
            blnExecute=false;   
            
            }
                       
      
        
            BAPIInput.append("</TableParameters>");            
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            //CommonObj.writeToLog(1, "BAPIInput PRELIMINARY_POSTING_FB01:" + BAPIInput.toString(), winame);
            
            if(blnExecute){
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("Parameters", "ExportParameters");

                String strFIDOC_NO = XMLListMessage.getVal("GS_FIDOC").trim();
                CommonObj.writeToLog(1,"strFIDOC_NO==" + strFIDOC_NO, winame);
                if(!strFIDOC_NO.equalsIgnoreCase("")){
                formObject.setNGValue("SAPDocRefNo", strFIDOC_NO);
                formObject.setNGValue("ParkedBy", formObject.getUserName());
                formObject.setNGValue("ParkingDate", NGDateFormat.format(date));
                formObject.RaiseEvent("WFSave");
                outputResult = "SUCCESS";
                }
            }
            else{
                CommonObj.writeToLog(1, "BAPIInput ZPRELIMINARY_POSTING_FB01:Failed Execution", winame);
                throw new ValidatorException(new FacesMessage("Parking Failed..!!!!","Comments"));
            }
            }
            return outputResult;
        } catch (Exception e) {
            
            CommonObj.writeToLog(3, "Error In SAPPark:TC Parking ="+ e.getMessage(), winame);
            
            return outputResult;
        }
    }

    
    
}
