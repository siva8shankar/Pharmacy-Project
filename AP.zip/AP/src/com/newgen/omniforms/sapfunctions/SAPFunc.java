/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;

import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;

import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import java.io.IOException;
import java.io.Serializable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author NanjundaMoorthy
 */
public class SAPFunc implements Serializable {

    SAPCall objSAPCall = new SAPCall();
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfDt = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat SAPDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat SAPDateFormat2 = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat NGDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();

    public boolean BAPI_Test(String strBAPIInputTest) throws Exception {

        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            CommonObj.writeToLog(1, "IN SAP Function:BAPI_PODetailsOnload:::", winame);
            CommonObj.writeToLog(1, "strBAPIInputTest:" + strBAPIInputTest, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append(strBAPIInputTest);
            CommonObj.writeToLog(1, "Input for BAPI Test : " + BAPIInput.toString(), winame);
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            CommonObj.writeToLog(1, "BAPIOutput>>>>>>>>>>>>::::::::" + BAPIOutput, winame);
            CommonObj.writeToLog(1, "BAPI: ZBAPI_PO_GR_PENDING Output:" + BAPIOutput, winame);
            formObject.setNGValue("Text_SAP_Output", BAPIOutput);
            return true;
        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc =" + e.getMessage(), winame);
            return false;
        }
    }

    public String BAPI_POGETDETAILS(FormReference formObject, String sPONumber, String sCompanyCode) throws Exception {
        StringBuffer BAPIInput = new StringBuffer();
        String BAPIOutput = new String();

        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        try {
            BAPIInput.append(objSAPCall.getconnectionstring());
        } catch (IOException ex) {
            //Logger.getLogger(APSAPIntegration.class.getName()).log(Level.SEVERE, null, ex);
        }
        BAPIInput.append("<SAPFunctionName>ZBAPI_PO_GR_PENDING</SAPFunctionName>");
        BAPIInput.append("<Parameters><ImportParameters>");
        BAPIInput.append("<GS_LIFNR>" + sPONumber + "</GS_LIFNR>");
        BAPIInput.append("</ImportParameters>");
        BAPIInput.append("</Parameters>");
        BAPIInput.append("</WFSAPInvokeFunction_Input>");
        CommonObj.writeToLog(1, "Input for PO Get details : " + BAPIInput.toString(), winame);
        BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
        CommonObj.writeToLog(1, "BAPIOutput" + BAPIOutput, winame);
        return BAPIOutput;
    }

    public String ZBAPI_VENDOR_WITH_TAXCODE(FormReference formObject, String sPONumber, String sCompanyCode) throws Exception {
        StringBuffer BAPIInput = new StringBuffer();
        String BAPIOutput = new String();

        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        try {
            BAPIInput.append(objSAPCall.getconnectionstring());
        } catch (IOException ex) {
            //Logger.getLogger(APSAPIntegration.class.getName()).log(Level.SEVERE, null, ex);
        }
        BAPIInput.append("<SAPFunctionName>ZBAPI_VENDOR_WITH_TAXCODE</SAPFunctionName>");
        BAPIInput.append("<Parameters><ImportParameters>");
        BAPIInput.append("<IV_VENDOR>" + sPONumber + "</IV_VENDOR>");
        BAPIInput.append("</ImportParameters>");
        BAPIInput.append("</Parameters>");
        BAPIInput.append("</WFSAPInvokeFunction_Input>");
        CommonObj.writeToLog(1, "Input for PO Get details : " + BAPIInput.toString(), winame);
        //BAPIOutput = executeXmlGeneric(BAPIInput.toString());
        BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
        CommonObj.writeToLog(1, "BAPIOutput" + BAPIOutput, winame);
        return BAPIOutput;
    }

    public String ZHR_ENTERTAINMENT_EXPENSES(FormReference formObject, String sPONumber, String sCompanyCode) throws Exception {
        StringBuffer BAPIInput = new StringBuffer();
        String BAPIOutput = new String();

        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {
            BAPIInput.append(objSAPCall.getconnectionstring());
        } catch (IOException ex) {
            //Logger.getLogger(APSAPIntegration.class.getName()).log(Level.SEVERE, null, ex);
        }

        BAPIInput.append("<SAPFunctionName>ZHR_ENTERTAINMENT_EXPENSES</SAPFunctionName>");
        BAPIInput.append("<Parameters><ImportParameters>");
        BAPIInput.append("<USR_PERNR>" + sPONumber + "</USR_PERNR>");
        BAPIInput.append("</ImportParameters>");

        BAPIInput.append("</Parameters>");
        BAPIInput.append("</WFSAPInvokeFunction_Input>");

        CommonObj.writeToLog(1, "Input for PO Get details : " + BAPIInput.toString(), winame);

        //BAPIOutput = executeXmlGeneric(BAPIInput.toString());
        BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
        CommonObj.writeToLog(1, "BAPIOutput" + BAPIOutput, winame);
        return BAPIOutput;
    }

    public String ZHR_SOBIS_CHNG_EMPDET_ALL(FormReference formObject, String strUserName) throws Exception {
        formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        StringBuffer BAPIInput = new StringBuffer();
        String BAPIOutput = new String();

        CommonObj.writeToLog(1, "IN SAP Function>>>>>>>>>>>>>>>>>>>>>>>>", winame);
        CommonObj.writeToLog(1, "strUserName:" + strUserName, winame);

        try {
            BAPIInput.append(objSAPCall.getconnectionstring());
        } catch (IOException ex) {
            //Logger.getLogger(APSAPIntegration.class.getName()).log(Level.SEVERE, null, ex);
        }

        BAPIInput.append("<SAPFunctionName>ZHR_SOBIS_CHNG_EMPDET_ALL</SAPFunctionName>");
        BAPIInput.append("<Parameters><ImportParameters>");
        BAPIInput.append("<USR_PERNR>" + strUserName + "</USR_PERNR>");
        BAPIInput.append("</ImportParameters>");

        BAPIInput.append("</Parameters>");
        BAPIInput.append("</WFSAPInvokeFunction_Input>");

        CommonObj.writeToLog(1, "Input for PO Get details : " + BAPIInput.toString(), winame);

        //BAPIOutput = executeXmlGeneric(BAPIInput.toString());
        BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
        CommonObj.writeToLog(1, "BAPIOutput>>>>>>>>>>>>::::::::" + BAPIOutput, winame);
        CommonObj.writeToLog(1, "BAPI: ZHR_SOBIS_CHNG_EMPDET_ALL Output:" + BAPIOutput, winame);

        WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
        CommonObj.writeToLog(1, "XmlResponse==" + XmlResponse, winame);
        CommonObj.writeToLog(1, "====" + XmlResponse.getVal("MainCode"), winame);
        if (XmlResponse.getVal("MainCode").equals("0")) {
            WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "IT_DISP");
            String ParkDocNoNPO = XMLListMessage.getVal("PBTXT").trim();
            CommonObj.writeToLog(1, "Designation==" + ParkDocNoNPO, winame);
            formObject.setNGValue("Designation", ParkDocNoNPO);

        }
        return BAPIOutput;
    }

    public String BAPI_EmployeeDetailsOnload(String strUserName) throws IOException {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String retVal = "";

        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            String Request = formObject.getNGValue("RequestFor");

            CommonObj.writeToLog(1, "IN SAP Function:BAPI_EmployeeDetailsOnload:::>>>>", winame);
            CommonObj.writeToLog(1, "strUserName:" + strUserName, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZHR_NEWGEN_EMP_EXP</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            if (Request.equalsIgnoreCase("Others")) {
                BAPIInput.append("<USR_PERNR>" + strUserName + "</USR_PERNR>");
            } else {
                BAPIInput.append("<USR_ID>" + strUserName + "</USR_ID>");
            }
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);

            if (XmlResponse.getVal("MainCode").equals("0")) {
                //Modified By Harinatha R on 2017/09/20
                String strResult = XmlResponse.getVal("RESULT").trim();
                String strResult1 = XmlResponse.getVal("RESULT_HIERARCHY").trim();
                CommonObj.writeToLog(1, "RESULT value:" + strResult + " \n   strResult1  value :::: " + strResult1, winame);
                //MD claims raise Code changes  starts here 12/Aug/2019
                WFXmlList XMLListMessageMD = XmlResponse.createList("TableParameters", "IT_PERNR_DET");
                String strGradeMD = XMLListMessageMD.getVal("GRADE").trim();
                String strMDCheck = "";
                if (strGradeMD.equalsIgnoreCase("AA")) {
                    strMDCheck = "True";
                } else {
                    strMDCheck = "False";
                }
                //MD claims raise Code changes ends
                if (strResult.equalsIgnoreCase("EMPLOYEE NOT FOUND") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                    retVal = "Please contact HR team to create/update employee details in SAP master";
                } else if (strResult.equalsIgnoreCase("VENDOR CODE NOT FOUND") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                    retVal = "Please contact HR team to update VendorCode in SAP master";
                } else if (strMDCheck.equalsIgnoreCase("False") && (strResult1.equalsIgnoreCase("REPORTING HIERARCHY MISSING.") && !formObject.getUserName().equalsIgnoreCase("admin"))) {

                    retVal = "Please contact HR team to update reporting manager details in SAP master";
                } else {

                    WFXmlList XMLListMessage1 = XmlResponse.createList("TableParameters", "IT_PERNR_DET");
                    if (strMDCheck.equalsIgnoreCase("False")) {
                        int j = 0;
                        String strReportError = "";
                        String strEmpGrp = XMLListMessage1.getVal("EMPLOYEE_GRP").trim();

                        for (; XMLListMessage1.hasMoreElements(true); XMLListMessage1.skip(true)) {
                            //CommonObj.writeToLog(1, "For Loop XMLListMessage1 :: " +XMLListMessage1, winame);
                            if (j == 0) {
                                CommonObj.writeToLog(1, "Logged user info need to skip this step", winame);
                                CommonObj.writeToLog(1, "J=0 ERROR_DETAIL ::: " + XMLListMessage1.getVal("ERROR_DETAIL").trim(), winame);
                                strReportError = strReportError + XMLListMessage1.getVal("ERROR_DETAIL").trim() + "~~";
                            } else {
                                CommonObj.writeToLog(1, "level=" + j + "***Corresponding ApproverLevel=" + XMLListMessage1.getVal("LEVEL1") + "****And ERROR_DETAIL ::: " + XMLListMessage1.getVal("ERROR_DETAIL").trim(), winame);
                                strReportError = strReportError + XMLListMessage1.getVal("ERROR_DETAIL").trim() + "~~";
                            }
                            j++;
                        }
                        CommonObj.writeToLog(1, "Before replace ~~ strReportError :: " + strReportError, winame);
                        strReportError = strReportError.replaceAll("~~", "");

                        if (strReportError.contains("REPORTING HIERARCHY NOT FOUND") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                            retVal = "Please contact HR team to correct reporting manager details/reporting hierarchy in SAP master";
                        } else if (strReportError.contains("REPORTING MANAGER NOT ASSIGNED IN LEVEL") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                            retVal = "Please contact HR team to correct reporting manager details/reporting hierarchy in SAP master";
                        } else if (strEmpGrp.equalsIgnoreCase("2") && formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Entertainment & Others") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                            retVal = "Retainee employees cannot claim Entertainment & Others as per the COA";
                        }
                    }
                    WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "IT_PERNR_DET");
                    String strEmployeeCode = XMLListMessage.getVal("PERNR").trim();
                    String strCompanyCode = XMLListMessage.getVal("BUKRS").trim();
                    String strRegion = XMLListMessage.getVal("PERSONNEL_AREA").trim();
                    String strEmpName = XMLListMessage.getVal("NAME").trim();
                    String strVendorCode = XMLListMessage.getVal("VENDOR_CODE").trim();
                    String strVendorGL = XMLListMessage.getVal("VEN_GLCODE").trim();
                    String strDesaigntion = XMLListMessage.getVal("DESIGNATION").trim();
                    String strDept = XMLListMessage.getVal("DEPARTMENT").trim();
                    String strGrade = XMLListMessage.getVal("LEVEL").trim();
                    String strCostCenter = XMLListMessage.getVal("COSTCENTER").trim();
                    String strBusinessArea = XMLListMessage.getVal("BUSINESS_AREA").trim();
                    String strOrgLoc = XMLListMessage.getVal("PERSONNEL_SUBAREA").trim();
                    String strBasicSal = XMLListMessage.getVal("BET01").trim();
                    String strDOJ = XMLListMessage.getVal("BEGDA").trim();
                    String strDtOfTransfer = XMLListMessage.getVal("T_BEGDA").trim();
                    String strPLoc = XMLListMessage.getVal("P_WERKS").trim();
                    String strPSubLoc = XMLListMessage.getVal("P_BTRTL").trim();
                    String strDtOfConfirm = XMLListMessage.getVal("C_BEGDA").trim();
//                    String strEmpGrp = XMLListMessage.getVal("EMPLOYEE_GRP").trim();

                    //Added by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period
                    String strResigDate = XMLListMessage.getVal("RESIG_DATE").trim();
                    String strLWDate = XMLListMessage.getVal("LWD").trim();
                    //Ended by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period

                    CommonObj.writeToLog(1, "strDOJ:" + strDOJ, winame);
                    CommonObj.writeToLog(1, "strDtOfTransfer:" + strDtOfTransfer, winame);
                    CommonObj.writeToLog(1, "strDtOfConfirm:" + strDtOfConfirm, winame);
                    CommonObj.writeToLog(1, "strPLoc:" + strPLoc, winame);
                    CommonObj.writeToLog(1, "strPSubLoc:" + strPSubLoc, winame);

                    formObject.setNGValue("EmployeeCode", strEmployeeCode);
                    formObject.setNGValue("CompanyCode", strCompanyCode);
                    formObject.setNGValue("Region", strRegion);
                    formObject.setNGValue("EmployeeName", strEmpName);
                    formObject.setNGValue("VendorCode", strVendorCode);
                    formObject.setNGValue("VendorGL", strVendorGL);
                    formObject.setNGValue("Designation", strDesaigntion);
                    formObject.setNGValue("Department", strDept);
                    formObject.setNGValue("Grade", strGrade);
                    formObject.setNGValue("CostCenter", strCostCenter);
                    formObject.setNGValue("BusinessArea", strBusinessArea);
                    formObject.setNGValue("OriginalLocation", strOrgLoc);
                    formObject.setNGValue("BasicSalary", strBasicSal);
                    formObject.setNGValue("PrevLoc", strPLoc);
                    formObject.setNGValue("PrevSubLoc", strPSubLoc);
                    formObject.setNGValue("MDCheck", strMDCheck);
                    if (strMDCheck.equalsIgnoreCase("False")) {
                        if (strDOJ != "") {
                            formObject.setNGValue("DateOfJoining", NGDateFormat.format((Date) SAPDateFormat.parse(strDOJ)));
                        }
                        if (strDtOfTransfer != "") {
                            formObject.setNGValue("DateOfTransfer", NGDateFormat.format((Date) SAPDateFormat.parse(strDtOfTransfer)));
                        }
                        if (strDtOfConfirm != "") {
                            formObject.setNGValue("DateOfConfirm", NGDateFormat.format((Date) SAPDateFormat.parse(strDtOfConfirm)));
                        }
                        //Added by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period
                        if (strResigDate != "") {
                            formObject.setNGValue("ResigDate", NGDateFormat.format((Date) SAPDateFormat.parse(strResigDate)));
                        }
                        if (strLWDate != "") {
                            formObject.setNGValue("LastWorkngDate", NGDateFormat.format((Date) SAPDateFormat.parse(strLWDate)));
                        }
                            //Ended by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period

                        //Added for ER Process to capture Approver Name and Approver Grades
                        int i = 0;
                        int maxlevel = 0;
                        String Appr_name = "";
                        String sGrade_Text = ""; //Added Bala G  on 24-12-2016 
                        String sGrade_TextName = "";
                        String Squery_Grade_Limit = "";
                        String GradeAmount = "";
                        Map<String, String> Appr_Matrix = new HashMap<String, String>();
                        Appr_Matrix.clear();
                        String Approvers_name = "";
                        String Approvers_level = "";
                        String Squery = "";

                        String OtherValues = "";

                        String UserIndex = "";
                        String UserIndexRet[] = null;
                        String list12 = "";
                        //Addedby SandeepKn on 10Jan2020 for ASFI and SFIC chnages-Start
                        //added by KS on 26Nov2019 for dubai and oman changes-- Start
                        String sRM = "NoEntry";
                        String sHRBP = "NoEntry";
                        String sCFO = "NoEntry";
                        String sFUNCIB = "NoEntry";
                        String sHRCM = "NoEntry";
                        String sMD = "NoEntry";

                        String sRMGr = "NoEntry";
                        String sHRBPGr = "NoEntry";
                        String sCFOGr = "NoEntry";
                        String sFUNCIBGr = "NoEntry";
                        String sHRCMGr = "NoEntry";
                        String sMDGr = "NoEntry";
                        String sHRLevel = "";
                        //added by KS on 26Nov2019 for dubai and oman changes-- End
                        //10Jan2020-- End
                        int ks = 0;
                        //Added by SAndeepkn on 10Jan2020 for ASFI and SFIC changes- Start
                        for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) {
                            ks = ks + 1;
                            if (i == 0) {
                                CommonObj.writeToLog(1, "Logged user info need to skip this step", winame);
                            } else {
                                CommonObj.writeToLog(1, "level=" + i + "***Corresponding ApproverLevel=" + XMLListMessage.getVal("LEVEL1") + "****And Approver ID=" + XMLListMessage.getVal("REPORT_MNGR_NAME"), winame);
                                Appr_name = XMLListMessage.getVal("USERID").trim();
                                if (Appr_name != null && !Appr_name.equalsIgnoreCase("")) //Normal case
                                {
                                    CommonObj.writeToLog(1, "Inside Approvers", winame);
                                    //formObject.setNGValue("App"+i+"index", XMLListMessage.getVal("USERID").trim());
                                    Approvers_name += XMLListMessage.getVal("USERID").trim() + "~";
                                    if (ks == 2) {
                                        sRM = Appr_name;
                                    }
                                    Approvers_level += XMLListMessage.getVal("LEVEL1").trim() + "~";
                                    OtherValues += XMLListMessage.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + XMLListMessage.getVal("USERID") + "~~Designation" + XMLListMessage.getVal("GRADE_TEXT") + ";;;";
                                } else //in case approver is null it would be consider as no approver
                                {
                                    CommonObj.writeToLog(1, "Inside No Approvers", winame);
                                    //Appr_name = "NoApprovers";
                                    Appr_name = "NoEntry";
                                    //formObject.setNGValue("App"+i+"index","admin");
                                    Approvers_name += Appr_name + "~";
                                    if (ks == 2) {
                                        sRM = "NoEntry";
                                    }
                                    Approvers_level += "NoEntry~";
                                    OtherValues += XMLListMessage.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + Appr_name + "|| Designation=" + XMLListMessage.getVal("GRADE_TEXT") + ";;;";
                                }
                                //Added Bala G on 24-12-2016 for Apporver Matrix limit check for each level of approver
                                sGrade_Text = XMLListMessage.getVal("GRADE_TEXT").trim(); //It will return GRADE_TEXT List
                                if (sGrade_Text != null && !sGrade_Text.equalsIgnoreCase("")) //normal case
                                {
                                    sGrade_TextName += sGrade_Text + "~";
                                    if (ks == 2) {
                                        sRMGr = sGrade_Text;
                                    }
                                } else {
                                    sGrade_Text = "NoEntry";
                                    if (ks == 2) {
                                        sRMGr = "NoEntry";
                                    }
                                    sGrade_TextName += sGrade_Text + "~";
                                }
                                CommonObj.writeToLog(1, "Initial approver name " + Approvers_name, winame);

                            }

                            //starts
                            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {

                                formObject.setNGValue("MaxAppLevel", i);

                                sHRLevel = XMLListMessage.getVal("LEVEL1").trim();
                                if (sHRLevel.equalsIgnoreCase("HRBP")) {
                                    sHRBP = XMLListMessage.getVal("USERID").trim();
                                    sHRBPGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                } else if (sHRLevel.equalsIgnoreCase("CFO")) {
                                    sCFO = XMLListMessage.getVal("USERID").trim();
                                    sCFOGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                } else if (sHRLevel.equalsIgnoreCase("FUNCIB")) {
                                    sFUNCIB = XMLListMessage.getVal("USERID").trim();
                                    sFUNCIBGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                } else if (sHRLevel.equalsIgnoreCase("LEVEL1")) {
                                    sMD = XMLListMessage.getVal("USERID").trim();
                                    sMDGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                }
                                i++;

                            } else {
                                formObject.setNGValue("MaxAppLevel", i);
                                i++;
                                if (XMLListMessage.getVal("LEVEL1").equalsIgnoreCase("LEVEL1")) {
                                    break;
                                }
                            }
                        }//added by KS on 26Nov2019 for dubai and oman changes-- Start
                        if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                            CommonObj.writeToLog(1, "Initial approver name1 " + Approvers_name, winame);
                            if (!sRM.equalsIgnoreCase("")) {
                                Approvers_name = sRM + "~";
                            } else {
                                Approvers_name = "NoEntry" + "~";
                            }
                            if (!sRMGr.equalsIgnoreCase("")) {
                                sGrade_TextName = sRMGr + "~";
                            } else {
                                sGrade_TextName = "NoEntry" + "~";
                            }
                            if (!sHRBP.equalsIgnoreCase("")) {
                                Approvers_name += sHRBP + "~";
                            } else {
                                Approvers_name += "NoEntry" + "~";
                            }
                            if (!sHRBPGr.equalsIgnoreCase("")) {
                                sGrade_TextName += sHRBPGr + "~";
                            } else {
                                sGrade_TextName += "NoEntry" + "~";
                            }
                            if (!sCFO.equalsIgnoreCase("")) {
                                //commented for ASFI, SFIC Workflow changes only for Travel claims - Skip for CFO - VishalB 
                                //Approvers_name += sCFO + "~";
                            } else {
                                Approvers_name += "NoEntry" + "~";
                            }
                            if (!sCFOGr.equalsIgnoreCase("")) {
                                //commented for ASFI, SFIC Workflow changes only for Travel claims - Skip for CFO - VishalB
                                //sGrade_TextName += sCFOGr + "~";
                            } else {
                                sGrade_TextName += "NoEntry" + "~";
                            }
                            if (!sFUNCIB.equalsIgnoreCase("")) {
                                Approvers_name += sFUNCIB + "~";
                            } else {
                                Approvers_name += "NoEntry" + "~";
                            }
                            if (!sFUNCIBGr.equalsIgnoreCase("")) {
                                sGrade_TextName += sFUNCIBGr + "~";
                            } else {
                                sGrade_TextName += "NoEntry" + "~";
                            }
                            if (!sMD.equalsIgnoreCase("")) {
                                Approvers_name += sMD + "~";
                            } else {
                                Approvers_name += "NoEntry" + "~";
                            }
                            if (!sMDGr.equalsIgnoreCase("")) {
                                sGrade_TextName += sMDGr + "~";
                            } else {
                                sGrade_TextName += "NoEntry" + "~";
                            }
                        }//added by KS on 26Nov2019 for dubai and oman changes-- End

                        CommonObj.writeToLog(2, "Aprpovers Name=" + Approvers_name, winame);
                        CommonObj.writeToLog(2, "Others Details=" + OtherValues, winame);
                        CommonObj.writeToLog(2, "sGrade_TextName=" + sGrade_TextName, winame);
                        CommonObj.writeToLog(2, "Approvers_level=" + Approvers_level, winame);
                        formObject.setNGValue("SAPApprovers", Approvers_name);
                        formObject.setNGValue("SAPApproversGr", sGrade_TextName);
                        String[] arrayApproversLevel = Approvers_level.split("~");
                        //formObject.setNGValue("apprsts2", arrayApproversLevel[0]);

                        //Modified by Harinath on 2017/11/08 NOTE: To display an alert igf LEVEL1/Grade is missing for the reporting manager in SAP master
                        if (arrayApproversLevel[0].equalsIgnoreCase("") || arrayApproversLevel[0].equalsIgnoreCase(null)) {

                            retVal = "Please contact HR team to update grade for reporting manager in SAP master data";
                        } else {

                            formObject.setNGValue("apprsts2", arrayApproversLevel[0]);
                            retVal = "SUCCESS";
                        }
                    } else {
                        retVal = "SUCCESS";
                    }
                        //Ended by Harinath on 2017/11/08 NOTE: To display an alert igf LEVEL1/Grade is missing for the reporting manager in SAP master

                    //retVal = "SUCCESS";
                }

            }
            //Ended By Harinatha R on 2017/09/20
//            return true;
        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc:BAPI_EmployeeDetailsOnload =" + e.getMessage(), winame);
            retVal = "FAIL";
            //return false;
        }
        CommonObj.writeToLog(1, "strRetrnVal BAPI_EmployeeDetailsOnload :::  " + retVal, winame);
        return retVal;
    }

    /*
     public boolean BAPI_EmployeeDetailsOnload(String strUserName) throws IOException {
     FormReference formObject = FormContext.getCurrentInstance().getFormReference();
     FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
     String winame = formConfig.getConfigElement("ProcessInstanceId");
     try {
            
     StringBuffer BAPIInput = new StringBuffer();
     String BAPIOutput = new String();
     String Request = formObject.getNGValue("RequestFor");
                    
     CommonObj.writeToLog(1, "IN SAP Function:BAPI_EmployeeDetailsOnload:::>>>>", winame);
     CommonObj.writeToLog(1, "strUserName:" + strUserName, winame);
     BAPIInput.append(objSAPCall.getconnectionstring());
     BAPIInput.append("<SAPFunctionName>ZHR_ENTERTAINMENT_EXPENSES</SAPFunctionName>");
     BAPIInput.append("<Parameters><ImportParameters>");
     if (Request .equalsIgnoreCase("Others")) {
     BAPIInput.append("<USR_PERNR>" + strUserName + "</USR_PERNR>");
     }else{
     BAPIInput.append("<USR_ID>" + strUserName + "</USR_ID>");
     }
     BAPIInput.append("</ImportParameters>");
     BAPIInput.append("</Parameters>");
     BAPIInput.append("</WFSAPInvokeFunction_Input>");
     BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
     WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
     if (XmlResponse.getVal("MainCode").equals("0")) {
     WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "IT_PERNR_DET");
     String strEmployeeCode = XMLListMessage.getVal("PERNR").trim();
     String strCompanyCode = XMLListMessage.getVal("BUKRS").trim();
     String strRegion = XMLListMessage.getVal("PERSONNEL_AREA").trim();
     String strEmpName = XMLListMessage.getVal("NAME").trim();
     String strVendorCode = XMLListMessage.getVal("VENDOR_CODE").trim();
     String strVendorGL = XMLListMessage.getVal("VEN_GLCODE").trim();
     String strDesaigntion = XMLListMessage.getVal("DESIGNATION").trim();
     String strDept = XMLListMessage.getVal("DEPARTMENT").trim();
     String strGrade = XMLListMessage.getVal("LEVEL").trim();
     String strCostCenter = XMLListMessage.getVal("COSTCENTER").trim();
     String strBusinessArea = XMLListMessage.getVal("BUSINESS_AREA").trim();
     String strOrgLoc = XMLListMessage.getVal("PERSONNEL_SUBAREA").trim();
     String strBasicSal = XMLListMessage.getVal("BET01").trim();
     String strDOJ = XMLListMessage.getVal("BEGDA").trim();
     String strDtOfTransfer = XMLListMessage.getVal("T_BEGDA").trim();
     String strPLoc = XMLListMessage.getVal("P_WERKS").trim();
     String strPSubLoc = XMLListMessage.getVal("P_BTRTL").trim();
     CommonObj.writeToLog(1, "strDOJ:" + strDOJ, winame);
     CommonObj.writeToLog(1, "strDtOfTransfer:" + strDtOfTransfer, winame);
     CommonObj.writeToLog(1, "strPLoc:" + strPLoc, winame);
     CommonObj.writeToLog(1, "strPSubLoc:" + strPSubLoc, winame);
     formObject.setNGValue("EmployeeCode", strEmployeeCode);
     formObject.setNGValue("CompanyCode", strCompanyCode);
                
     formObject.setNGValue("Region", strRegion);
     formObject.setNGValue("EmployeeName", strEmpName);
     formObject.setNGValue("VendorCode", strVendorCode);
     formObject.setNGValue("VendorGL", strVendorGL);
     formObject.setNGValue("Designation", strDesaigntion);
     formObject.setNGValue("Department", strDept);
     formObject.setNGValue("Grade", strGrade);
     formObject.setNGValue("CostCenter", strCostCenter);
     formObject.setNGValue("BusinessArea", strBusinessArea);
     formObject.setNGValue("OriginalLocation", strOrgLoc);
     formObject.setNGValue("BasicSalary", strBasicSal);
     if(strDOJ !="")
     formObject.setNGValue("DateOfJoining", NGDateFormat.format((Date)SAPDateFormat.parse(strDOJ)));
     if(strDtOfTransfer !="")
     formObject.setNGValue("DateOfTransfer", NGDateFormat.format((Date)SAPDateFormat.parse(strDtOfTransfer)));
     formObject.setNGValue("PrevLoc", strPLoc);
     formObject.setNGValue("PrevSubLoc", strPSubLoc);
                
                
     //Added for ER Process to capture Approver Name and Approver Grades
     int i = 0;
     int maxlevel = 0;
     String Appr_name = "";
     String sGrade_Text=""; //Added Bala G  on 24-12-2016 
     String sGrade_TextName="";
     String Squery_Grade_Limit="";
     String GradeAmount="";
     Map<String, String> Appr_Matrix = new HashMap<String, String>();
     Appr_Matrix.clear();
     String Approvers_name = "";
     String Squery = "";
     
     String OtherValues = "";
           
     String UserIndex = "";
     String UserIndexRet[] = null;
     String list12 = "";            
     for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) 
     {
     if (i == 0) 
     {
     System.out.println("Logged user info need to skip this step");
     } 
     else 
     {
     CommonObj.writeToLog(1,"level=" + i + "***Corresponding ApproverLevel=" + XMLListMessage.getVal("LEVEL1") + "****And Approver ID=" + XMLListMessage.getVal("REPORT_MNGR_NAME"),winame);
     Appr_name = XMLListMessage.getVal("USERID").trim();
     if (Appr_name != null && !Appr_name.equalsIgnoreCase("")) //Normal case
     {
     //formObject.setNGValue("App"+i+"index", XMLListMessage.getVal("USERID").trim());
     Approvers_name += XMLListMessage.getVal("USERID").trim() + "~";
     OtherValues += XMLListMessage.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + XMLListMessage.getVal("USERID") + "~~Designation" + XMLListMessage.getVal("GRADE_TEXT") + ";;;";
     } else //in case approver is null it would be consider as no approver
     {
     System.out.println("Inside No Approvers");
     //Appr_name = "NoApprovers";
     Appr_name = "NoEntry";
     //formObject.setNGValue("App"+i+"index","admin");
     Approvers_name += Appr_name + "~";
     OtherValues += XMLListMessage.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + Appr_name + "~~Designation" + XMLListMessage.getVal("GRADE_TEXT") + ";;;";
     }
     //Added Bala G on 24-12-2016 for Apporver Matrix limit check for each level of approver
     sGrade_Text= XMLListMessage.getVal("GRADE_TEXT").trim(); //It will return GRADE_TEXT List
     if(sGrade_Text!=null && !sGrade_Text.equalsIgnoreCase("")) //normal case
     {
     sGrade_TextName+= sGrade_Text+"~";
     }
     else
     {
     sGrade_Text="NoEntry" ;
     sGrade_TextName+= sGrade_Text+"~";
     }
                    
     }
     formObject.setNGValue("MaxAppLevel", i);
     i++;
     }
     CommonObj.writeToLog(2,"Aprpovers Name=" + Approvers_name,winame);
     CommonObj.writeToLog(2,"Others Details=" + OtherValues,winame);
     CommonObj.writeToLog(2,"sGrade_TextName="+sGrade_TextName,winame);
     formObject.setNGValue("SAPApprovers", Approvers_name);
     formObject.setNGValue("SAPApproversGr", sGrade_TextName);
                
     }
     return true;
     } catch (Exception e) {
     CommonObj.writeToLog(3,"Error In SAPFunc:BAPI_EmployeeDetailsOnload =" + e.getMessage(),winame);
     return false;
     }
     }*/
    public String BAPI_EmployeeDetailsOnloadHR(String strUserName) throws IOException {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String strRetrnVal = "";

        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            String Request = formObject.getNGValue("RequestFor");
            String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
            String strSubCategory1 = formObject.getNGValue("SubCategory1");
            String strRentDepLoan = "";
            //Added by Harinath on 2017/03/20
            String strSalAdv = "";
            String strExcep = "";

            //Ended by Harinath on 2017/03/20
            AP_CommonFunctions.writeToLog(1, "IN SAP Function:BAPI_EmployeeDetailsOnloadHR:::>>>>", winame);
            AP_CommonFunctions.writeToLog(1, "strUserName:" + strUserName, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZHR_NEWGEN_EMP_EXP</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            if (Request.equalsIgnoreCase("Others")) {
                BAPIInput.append("<USR_PERNR>" + strUserName + "</USR_PERNR>");
            } else {
                BAPIInput.append("<USR_ID>" + strUserName + "</USR_ID>");
            }
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {

                //Modified By Harinatha R on 2017/09/20
                String strResult = XmlResponse.getVal("RESULT").trim();
                String strResult1 = XmlResponse.getVal("RESULT_HIERARCHY").trim();
                String strResult2 = XmlResponse.getVal("RESULT_HRBP").trim();
                CommonObj.writeToLog(1, "RESULT value:" + strResult + "\n   strResult1 value ::: " + strResult1 + " \n  strResult2 value ::: " + strResult2, winame);

                if (strResult.equalsIgnoreCase("EMPLOYEE NOT FOUND") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                    strRetrnVal = "Please contact HR team to create/update employee details in SAP master";
                } else if (strResult.equalsIgnoreCase("VENDOR CODE NOT FOUND") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                    strRetrnVal = "Please contact HR team to update VendorCode in SAP master";
                } else if (strResult1.equalsIgnoreCase("REPORTING HIERARCHY MISSING.") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                    strRetrnVal = "Please contact HR team to update reporting manager details in SAP master";
                } else if (strResult2.equalsIgnoreCase("HRBP NOT ASSIGNED") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                    strRetrnVal = "Please contact HR team to update HRBP details in SAP master";
                } /*else if (strSubCategory1.equalsIgnoreCase("House Rent Advance") || strSubCategory1.equalsIgnoreCase("Exceptional Advances") || strSubCategory1.equalsIgnoreCase("Salary Advance")) {

                 strRetrnVal = "Due to SAP master maintainance House Rent Advance is blocked  and will be available April 15th onwards.";
                 } */ else {

                    WFXmlList XMLListMessage1 = XmlResponse.createList("TableParameters", "IT_PERNR_DET");

                    int j = 0;
                    String strReportError = "";
                    for (; XMLListMessage1.hasMoreElements(true); XMLListMessage1.skip(true)) {
                        if (j == 0) {
                            CommonObj.writeToLog(1, "Logged user info need to skip this step", winame);
                            CommonObj.writeToLog(1, "J=0 ERROR_DETAIL ::: " + XMLListMessage1.getVal("ERROR_DETAIL").trim(), winame);
                            strReportError = strReportError + XMLListMessage1.getVal("ERROR_DETAIL").trim() + "~~";
                        } else if (j == 1) {
                            CommonObj.writeToLog(1, "level=" + j + "***Corresponding ApproverLevel=" + XMLListMessage1.getVal("LEVEL1") + "****And ERROR_DETAIL ::: " + XMLListMessage1.getVal("ERROR_DETAIL"), winame);
                            strReportError = strReportError + XMLListMessage1.getVal("ERROR_DETAIL").trim() + "~~";
                        }
                    }

                    //CommonObj.writeToLog(1, "Before replace ~~ strReportError :: " +strReportError, winame);
                    strReportError = strReportError.replaceAll("~~", "");
                    //CommonObj.writeToLog(1, " strReportError :: " +strReportError, winame);

                    if (strReportError.contains("REPORTING HIERARCHY NOT FOUND") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                        strRetrnVal = "Please contact HR team to correct reporting manager details/reporting hierarchy in SAP master";
                    } else if (strReportError.contains("REPORTING MANAGER NOT ASSIGNED IN LEVEL") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                        strRetrnVal = "Please contact HR team to correct reporting manager details/reporting hierarchy in SAP master";
                    } else if (strReportError.contains("HR HEAD NOT ASSIGNED") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                        strRetrnVal = "Please contact HR team to assign HR Head in SAP master";
                    } else if (strReportError.contains("COMP. OFFICER NOT ASSIGNED") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                        strRetrnVal = "Please contact HR team to assign Comp. Officer in SAP master";
                    } else if (strReportError.contains("HR HEAD NOT ASSIGNED") && !formObject.getUserName().equalsIgnoreCase("admin")) {

                        strRetrnVal = "Please contact HR team to assign Comp. Head in SAP master";
                    }/* else if(strSubCategory1.equalsIgnoreCase("House Rent Advance") && (XMLListMessage1.getVal("WERKS").equalsIgnoreCase("IN03") || XMLListMessage1.getVal("WERKS").equalsIgnoreCase("BDPL") || XMLListMessage1.getVal("WERKS").equalsIgnoreCase("PA13"))){
                        
                     strRetrnVal = "Due to SAP master maintainance House Rent Advance is blocked  and will be available April 15th onwards.";
                     }*/ else {

                        CommonObj.writeToLog(1, "No error codes found in RESULT  ::: " + strResult, winame);
                        WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "IT_PERNR_DET");
                        String strEmployeeCode = XMLListMessage.getVal("PERNR").trim();
                        String strCompanyCode = XMLListMessage.getVal("BUKRS").trim();
                        String strRegion = XMLListMessage.getVal("PERSONNEL_AREA").trim();
                        String strEmpName = XMLListMessage.getVal("NAME").trim();
                        String strVendorCode = XMLListMessage.getVal("VENDOR_CODE").trim();
                        String strVendorGL = XMLListMessage.getVal("VEN_GLCODE").trim();
                        String strDesaigntion = XMLListMessage.getVal("DESIGNATION").trim();
                        String strDept = XMLListMessage.getVal("DEPARTMENT").trim();
                        String strGrade = XMLListMessage.getVal("LEVEL").trim();
                        String strCostCenter = XMLListMessage.getVal("COSTCENTER").trim();
                        String strBusinessArea = XMLListMessage.getVal("BUSINESS_AREA").trim();
                        String strOrgLoc = XMLListMessage.getVal("PERSONNEL_SUBAREA").trim();
                        String strBasicSal = XMLListMessage.getVal("BET01").trim();
                        String strDOJ = XMLListMessage.getVal("BEGDA").trim();
                        String strDtOfTransfer = XMLListMessage.getVal("T_BEGDA").trim();
                        String strPLoc = XMLListMessage.getVal("P_WERKS").trim();
                        String strPSubLoc = XMLListMessage.getVal("P_BTRTL").trim();
                        //Added by Harinath on 2017/03/20
                        strRentDepLoan = XMLListMessage.getVal("RENT_DEPOSIT_LOAN").trim();
                        strSalAdv = XMLListMessage.getVal("SALARY_ADVANCE").trim();
                        strExcep = XMLListMessage.getVal("EXCEPTIONAL_ADVANCES").trim();
                        String strDtOfConfirm = XMLListMessage.getVal("C_BEGDA").trim();
                        String strEmpGrp = XMLListMessage.getVal("EMPLOYEE_GRP").trim();

                        //Added by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period
                        String strResigDate = XMLListMessage.getVal("RESIG_DATE").trim();
                        String strLWDate = XMLListMessage.getVal("LWD").trim();
                        //Ended by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period                        

                        //Ended by Harinath on 2017/03/20
                        AP_CommonFunctions.writeToLog(1, "strDOJ:" + strDOJ, winame);
                        AP_CommonFunctions.writeToLog(1, "strDtOfTransfer:" + strDtOfTransfer, winame);
                        AP_CommonFunctions.writeToLog(1, "strDtOfConfirm:" + strDtOfConfirm, winame);
                        AP_CommonFunctions.writeToLog(1, "strPLoc:" + strPLoc, winame);
                        AP_CommonFunctions.writeToLog(1, "strPSubLoc:" + strPSubLoc, winame);

                        //Added on 07-NOV-20 to restrict Salary Advance for new joinees until 6months of DOJ
                        CommonObj.writeToLog(1, " Salary Advance Eligibility:: " + strSubCategory1, winame);
                        String strEmpGrade = XMLListMessage.getVal("GRADE").trim();
                        // AP_CommonFunctions.writeToLog(1, "strEmpSubGroupCode:" + strEmpSubGroupCode, winame);
                        String res = CommonObj.salaryAdvanceEligible(formObject, strDOJ, strEmployeeCode, strGrade, strEmpGrade);
                        AP_CommonFunctions.writeToLog(1, "result :" + res, winame);
                        //End on 07-NOV-20
                        CommonObj.writeToLog(1, "strEmpGrp :::  " + strEmpGrp + "  strGrade ::: " + strGrade, winame);
                        CommonObj.writeToLog(1, "strRentDepLoan :::  " + strRentDepLoan + "  strSalAdv ::: " + strSalAdv + "  strExcep ::: " + strExcep, winame);

                        if (strEmpGrp.equalsIgnoreCase("2")) {

                            strRetrnVal = "Retainee employees cannot claim relocation/employee advances as per the COA";
                        }/* else if (strTypeofinvoice.equalsIgnoreCase("Relocation") && strGrade.equalsIgnoreCase("Management Trainee") && strDtOfConfirm.equalsIgnoreCase("")) {

                         strRetrnVal = "Please contact HR team to update Date of Confirmation in SAP master";
                         }*/ else if (strSubCategory1.equalsIgnoreCase("House Rent Advance") && strRentDepLoan.equalsIgnoreCase("Y")) {

                            strRetrnVal = "Advance exists. Hence cant apply for House Rent Advance";
                        } else if (strSubCategory1.equalsIgnoreCase("House Rent Advance") && strRentDepLoan.equalsIgnoreCase("NE")) {

                            strRetrnVal = "User is not eligible for House Rent Advance";
                        } else if (strSubCategory1.equalsIgnoreCase("Salary Advance") && strSalAdv.equalsIgnoreCase("Y")) {

                            strRetrnVal = "Advance exists. Hence cant apply for  Salary Advance";
                        } else if (strSubCategory1.equalsIgnoreCase("Exceptional Advances") && strExcep.equalsIgnoreCase("Y")) {

                            strRetrnVal = "Advance exists. Hence cant apply for Exceptional Advances";
                        } else if (strSubCategory1.equalsIgnoreCase("Imprest Cash") && (!strGrade.equalsIgnoreCase("Fld Sales Off Gr III") && !strGrade.equalsIgnoreCase("Fld Sales Off Gr II")
                                && !strGrade.equalsIgnoreCase("Fld Sales Off Gr I") && !strGrade.equalsIgnoreCase("Territory Sales IC") && !strGrade.equalsIgnoreCase("TSI Trainee")
                                && !strGrade.equalsIgnoreCase("Executive-Sales"))) {

                            strRetrnVal = "User is not eligible for Imprest Cash";
                        } //Added on 07-NOV-20 to restrict Salary Advance for new joinees until 6months of DOJ
                        else if ((strSubCategory1.equalsIgnoreCase("Salary Advance")) && (res.equalsIgnoreCase("FAIL"))) {
                            strRetrnVal = "Employee is not eligible for Salary Advance within 6 months of Joining/Promotion Date";
                        } else if ((strSubCategory1.equalsIgnoreCase("Salary Advance")) && (res.equalsIgnoreCase("NODATA"))) {
                            strRetrnVal = "Data is not available. Please contact HR.";
                        } //End on 07-NOV-20 
                        else {

                            CommonObj.writeToLog(1, "No error codes found in Employee details  ::: " + strResult, winame);

                            formObject.setNGValue("EmployeeCode", strEmployeeCode);
                            formObject.setNGValue("CompanyCode", strCompanyCode);

                            formObject.setNGValue("Region", strRegion);
                            formObject.setNGValue("EmployeeName", strEmpName);
                            formObject.setNGValue("VendorCode", strVendorCode);
                            formObject.setNGValue("VendorGL", strVendorGL);
                            formObject.setNGValue("Designation", strDesaigntion);
                            formObject.setNGValue("Department", strDept);
                            formObject.setNGValue("Grade", strGrade);
                            formObject.setNGValue("CostCenter", strCostCenter);
                            formObject.setNGValue("BusinessArea", strBusinessArea);
                            formObject.setNGValue("OriginalLocation", strOrgLoc);
                            formObject.setNGValue("BasicSalary", strBasicSal);
                            formObject.setNGValue("PrevLoc", strPLoc);
                            formObject.setNGValue("PrevSubLoc", strPSubLoc);
                            formObject.setNGValue("BankAcctStastus", XMLListMessage.getVal("ZLSCH").trim());
                            formObject.setNGValue("PersonalArea", XMLListMessage.getVal("WERKS").trim());
                            formObject.setNGValue("PersonalSubArea", XMLListMessage.getVal("BTRTL").trim());

                            if (strDOJ != "") {
                                formObject.setNGValue("DateOfJoining", NGDateFormat.format((Date) SAPDateFormat.parse(strDOJ)));
                                formObject.setNGValue("Txt_DOJ", NGDateFormat.format((Date) SAPDateFormat.parse(strDOJ)));
                            }

                            if (strDtOfTransfer != "") {
                                formObject.setNGValue("DateOfTransfer", NGDateFormat.format((Date) SAPDateFormat.parse(strDtOfTransfer)));
                            }

                            if (strDtOfConfirm != "" /* && strGrade.equalsIgnoreCase("Management Trainee") */) {
                                formObject.setNGValue("DateOfConfirm", NGDateFormat.format((Date) SAPDateFormat.parse(strDtOfConfirm)));
                            }
                            //Added by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period
                            if (strResigDate != "") {
                                formObject.setNGValue("ResigDate", NGDateFormat.format((Date) SAPDateFormat.parse(strResigDate)));
                            }
                            if (strLWDate != "") {
                                formObject.setNGValue("LastWorkngDate", NGDateFormat.format((Date) SAPDateFormat.parse(strLWDate)));
                            }
                            //Ended by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period

                            int i = 0;
                            String Appr_name = "";
                            String sGrade_Text = "";
                            String sGrade_TextName = "";
                            String Approvers_name = "";
                            String Approvers_level = "";
                            String OtherValues = "";
                            String UserIndexRet[] = null;

                            String sHRBP = "NoEntry";
                            String sHRVP = "NoEntry";
                            String sHRCO = "NoEntry";
                            String sHRCM = "NoEntry";
                            String sMD = "NoEntry";

                            String sHRBPGr = "NoEntry";
                            String sHRVPGr = "NoEntry";
                            String sHRCOGr = "NoEntry";
                            String sHRCMGr = "NoEntry";
                            String sMDGr = "NoEntry";

                            String sHRLevel = "";

                            for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) {
                                if (i == 0) {
                                    CommonObj.writeToLog(1, "Logged user info need to skip this step", winame);
                                } else if (i == 1) {
                                    CommonObj.writeToLog(1, "level=" + i + "***Corresponding ApproverLevel=" + XMLListMessage.getVal("LEVEL1") + "****And Approver ID=" + XMLListMessage.getVal("REPORT_MNGR_NAME"), winame);
                                    Appr_name = XMLListMessage.getVal("USERID").trim();
                                    if (Appr_name != null && !Appr_name.equalsIgnoreCase("")) //Normal case
                                    {
                                        Approvers_name += XMLListMessage.getVal("USERID").trim() + "~";
                                        Approvers_level += XMLListMessage.getVal("LEVEL1").trim() + "~";
                                        OtherValues += XMLListMessage.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + XMLListMessage.getVal("USERID") + "~~Designation" + XMLListMessage.getVal("GRADE_TEXT") + ";;;";
                                    } else //in case approver is null it would be consider as no approver
                                    {
                                        CommonObj.writeToLog(1, "Inside No Approvers", winame);
                                        Approvers_name += "NoEntry" + "~";
                                        Approvers_level += "NoEntry~";
                                        OtherValues += XMLListMessage.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + Appr_name + "~~Designation" + XMLListMessage.getVal("GRADE_TEXT") + ";;;";
                                    }
                                    //Added Bala G on 24-12-2016 for Apporver Matrix limit check for each level of approver
                                    sGrade_Text = XMLListMessage.getVal("GRADE_TEXT").trim(); //It will return GRADE_TEXT List
                                    if (sGrade_Text != null && !sGrade_Text.equalsIgnoreCase("")) //normal case
                                    {
                                        sGrade_TextName += sGrade_Text + "~";
                                    } else {
                                        sGrade_TextName += "NoEntry" + "~";
                                    }

                                }

                                sHRLevel = "";
                                sHRLevel = XMLListMessage.getVal("LEVEL1").trim();
                                if (sHRLevel.equalsIgnoreCase("HRBP")) {
                                    sHRBP = XMLListMessage.getVal("USERID").trim();
                                    sHRBPGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                } else if (sHRLevel.equalsIgnoreCase("VICE PRESIDENT - HR")) {
                                    sHRVP = XMLListMessage.getVal("USERID").trim();
                                    sHRVPGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                } else if (sHRLevel.equalsIgnoreCase("HR OFFICER - OPERATIONS")) {
                                    sHRCO = XMLListMessage.getVal("USERID").trim();
                                    sHRCOGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                } else if (sHRLevel.equalsIgnoreCase("MANAGER - COMPENSATION & HR OPERATIONS")) {
                                    sHRCM = XMLListMessage.getVal("USERID").trim();
                                    sHRCMGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                } else if (sHRLevel.equalsIgnoreCase("LEVEL1")) {
                                    sMD = XMLListMessage.getVal("USERID").trim();
                                    sMDGr = XMLListMessage.getVal("GRADE_TEXT").trim();
                                }

                                i++;
                            }

                            if (strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {
                                //HRBP
                                if (!sHRBP.equalsIgnoreCase("")) {
                                    Approvers_name += sHRBP + "~";
                                } else {
                                    Approvers_name += "NoEntry" + "~";
                                }
                                if (!sHRBPGr.equalsIgnoreCase("")) {
                                    sGrade_TextName += sHRBPGr + "~";
                                } else {
                                    sGrade_TextName += "NoEntry" + "~";
                                }

                                //HRVP
                                if (!sHRVP.equalsIgnoreCase("")) {
                                    Approvers_name += sHRVP + "~";
                                } else {
                                    Approvers_name += "NoEntry" + "~";
                                }
                                if (!sHRVPGr.equalsIgnoreCase("")) {
                                    sGrade_TextName += sHRVPGr + "~";
                                } else {
                                    sGrade_TextName += "NoEntry" + "~";
                                }
                            } else if (strTypeofinvoice.equalsIgnoreCase("Relocation")) {
                                //HRCO
                                if (!sHRCO.equalsIgnoreCase("")) {
                                    Approvers_name += sHRCO + "~";
                                } else {
                                    Approvers_name += "NoEntry" + "~";
                                }
                                if (!sHRCOGr.equalsIgnoreCase("")) {
                                    sGrade_TextName += sHRCOGr + "~";
                                } else {
                                    sGrade_TextName += "NoEntry" + "~";
                                }
                                /*
                                 //HRCM
                                 if (!sHRCM.equalsIgnoreCase(""))
                                 {
                                 Approvers_name += sHRCM + "~";
                                 }else{
                                 Approvers_name += "NoEntry" + "~";
                                 }
                                 if (!sHRCMGr.equalsIgnoreCase(""))
                                 {
                                 sGrade_TextName += sHRCMGr + "~";
                                 }else{
                                 sGrade_TextName += "NoEntry" + "~";
                                 }
                                 */
                                //HRVP
                                if (!sHRVP.equalsIgnoreCase("")) {
                                    Approvers_name += sHRVP + "~";
                                } else {
                                    Approvers_name += "NoEntry" + "~";
                                }
                                if (!sHRVPGr.equalsIgnoreCase("")) {
                                    sGrade_TextName += sHRVPGr + "~";
                                } else {
                                    sGrade_TextName += "NoEntry" + "~";
                                }
                            } else {
                                Approvers_name += "NoEntry" + "~";
                                Approvers_name += "NoEntry" + "~";
                                sGrade_TextName += "NoEntry" + "~";
                                sGrade_TextName += "NoEntry" + "~";
                            }
                            //MD
                            if (!sMD.equalsIgnoreCase("")) {
                                Approvers_name += sMD + "~";
                            } else {
                                Approvers_name += "NoEntry" + "~";
                            }
                            if (!sMDGr.equalsIgnoreCase("")) {
                                sGrade_TextName += sMDGr + "~";
                            } else {
                                sGrade_TextName += "NoEntry" + "~";
                            }

                            CommonObj.writeToLog(2, "Aprpovers Name=" + Approvers_name, winame);
                            CommonObj.writeToLog(2, "Others Details=" + OtherValues, winame);
                            CommonObj.writeToLog(2, "sGrade_TextName=" + sGrade_TextName, winame);
                            formObject.setNGValue("SAPApprovers", Approvers_name);
                            formObject.setNGValue("SAPApproversGr", sGrade_TextName);
                            String[] arrayApproversLevel = Approvers_level.split("~");
                            formObject.setNGValue("apprsts2", arrayApproversLevel[0]);

                            strRetrnVal = "SUCCESS";
                        }
                        /*
                         if (strSubCategory1.equalsIgnoreCase("House Rent Advance")) {
                         strRetrnVal = strRentDepLoan;
                         } else if (strSubCategory1.equalsIgnoreCase("Salary Advance")) {
                         strRetrnVal = strSalAdv;
                         } else if (strSubCategory1.equalsIgnoreCase("Exceptional Advances")) {
                         strRetrnVal = strExcep;
                         }
                         */
                    }
                }

                //Ended by Harinath on 2017/09/20
            }

        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc:BAPI_EmployeeDetailsOnloadHR =" + e.getMessage(), winame);
            CommonObj.writeToLog(3, "Error In SAPFunc:BAPI_EmployeeDetailsOnloadHR =" + e, winame);
            strRetrnVal = "FAIL";
        }
        CommonObj.writeToLog(1, "strRetrnVal BAPI_EmployeeDetailsOnloadHR :::  " + strRetrnVal, winame);
        return strRetrnVal;
    }

    public String BAPI_PODetailsOnload(String strVendorCode, String strPoNo, String strIndicate) {
        String outputResult = "FAIL";
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            CommonObj.writeToLog(1, "IN SAP Function:BAPI_PODetailsOnload:::!!!!!!!!###!!!", winame);
            CommonObj.writeToLog(1, "strVendorCode:" + strVendorCode, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZBAPI_PO_GR_PENDING</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<GS_LIFNR>" + strVendorCode + "</GS_LIFNR>");
            BAPIInput.append("<GS_INDICATOR>" + strIndicate + "</GS_INDICATOR>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("<TableParameters>");
            //BAPIInput.append("<IT_EBELN>" + strPoNo + "</IT_EBELN>");
            BAPIInput.append("<IT_EBELN>");
            BAPIInput.append("<EBELN>" + strPoNo + "</EBELN>");
            BAPIInput.append("</IT_EBELN>");

            BAPIInput.append("</TableParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            CommonObj.writeToLog(1, "Input for PO Get details : " + BAPIInput.toString(), winame);
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "GT_OUTPUT");
                CommonObj.writeToLog(1, "XMLListMessage::" + XMLListMessage.toString(), winame);
                for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) {
                    String strSAPPO_NO = XMLListMessage.getVal("EBELN").trim();
                    CommonObj.writeToLog(1, "strSAPPO_NO==" + strSAPPO_NO, winame);
                    if (strSAPPO_NO.matches(strPoNo)) {
                        CommonObj.writeToLog(1, "PO NO matched", winame);
                        String strName = XMLListMessage.getVal("NAME1").trim();
                        String strGroup = XMLListMessage.getVal("EKGRP").trim();
                        String strFiscalYear = XMLListMessage.getVal("MJAHR").trim();
                        String strStateCode = XMLListMessage.getVal("GSBER").trim();
                        String strCompanyCode = XMLListMessage.getVal("BUKRS").trim();
                        String strPlantCode = XMLListMessage.getVal("WERKS").trim();
                        String strRegion = XMLListMessage.getVal("BUPLA").trim();
                        String SAPGRNDate = XMLListMessage.getVal("ZFBDT").trim();
                        formObject.setNGValue("VendName", strName);
                        formObject.setNGValue("PurchaseGrp", strGroup);
                        //formObject.setNGValue("FiscalYr", strFiscalYear);
                        formObject.setNGValue("StateCode", strStateCode);
                        formObject.setNGValue("CompanyCode", strCompanyCode);
                        formObject.setNGValue("Region", strRegion);
                        if (SAPGRNDate != "") {
                            formObject.setNGValue("InvoiceDate", NGDateFormat.format((Date) SAPDateFormat.parse(SAPGRNDate)));
                            formObject.setNGValue("BaseLineDt", NGDateFormat.format((Date) SAPDateFormat.parse(SAPGRNDate)));
                        }
                        break;
                    }
                }
                for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) {
                    String strSAPPO_NO = XMLListMessage.getVal("EBELN").trim();
                    CommonObj.writeToLog(1, "strSAPPO_NO2==" + strSAPPO_NO, winame);
                    if (strSAPPO_NO.matches(strPoNo)) {
                        String SAPGRNNO = XMLListMessage.getVal("MBLNR").trim();
                        String SAPEntrySheetNo = XMLListMessage.getVal("ITEM").trim();
                        String SAPPOLineitemText = XMLListMessage.getVal("MATNR").trim();
                        String SAPItemQuantity = XMLListMessage.getVal("MENGE").trim();
                        String SAPAmount = XMLListMessage.getVal("DMBTR").trim();
                        String SAPUnit = XMLListMessage.getVal("MEINS").trim();
                        String SAPStatus = XMLListMessage.getVal("VCODE").trim();
                        String SAPBusinessArea = XMLListMessage.getVal("GSBER").trim();
                        String SAPBusinessPlace = XMLListMessage.getVal("BUPLA").trim();
                        String SAPCurrency = XMLListMessage.getVal("WAERS").trim();
                        String SAPFreightConditionType = XMLListMessage.getVal("KSCHL").trim();
                        String SAPPOType = XMLListMessage.getVal("POTYPE").trim();
                        String SAPLi = XMLListMessage.getVal("EBELP").trim();
                        String SAPGRNDate = XMLListMessage.getVal("ZFBDT").trim();
                        String SAPTaxCode = XMLListMessage.getVal("MWSKZ").trim();
                        CommonObj.writeToLog(1, "SAPTaxCode:" + SAPTaxCode, winame);
                        CommonObj.writeToLog(1, "SAPUnit==" + SAPUnit, winame);
                        CommonObj.writeToLog(1, "SAPEntrySheetNo==" + SAPEntrySheetNo, winame);
                        ListViewItems LVI = new ListViewItems();
                        //LVI.addColumnvalue("");
                        LVI.addColumnvalue(strSAPPO_NO);
                        LVI.addColumnvalue(SAPGRNNO);
                        if (SAPGRNDate != "") {
                            LVI.addColumnvalue(NGDateFormat.format((Date) SAPDateFormat.parse(SAPGRNDate)));
                        } else {
                            LVI.addColumnvalue("");
                        }
                        //LVI.addColumnvalue(SAPEntrySheetNo);
                        LVI.addColumnvalue(SAPLi);
                        LVI.addColumnvalue(SAPPOLineitemText);
                        LVI.addColumnvalue(SAPItemQuantity);
                        LVI.addColumnvalue("");
                        LVI.addColumnvalue(SAPAmount);
                        LVI.addColumnvalue("");
                        LVI.addColumnvalue(SAPBusinessPlace);
                        LVI.addColumnvalue(SAPBusinessArea);
                        LVI.addColumnvalue(SAPTaxCode);
                        LVI.addColumnvalue("");
                        LVI.addColumnvalue("");
                        LVI.addColumnvalue("");
                        LVI.addColumnvalue("");
                        LVI.addColumnvalue(SAPStatus);
                        LVI.addColumnvalue("");
                        LVI.addColumnvalue(SAPUnit);
                        LVI.addColumnvalue(SAPCurrency);
                        LVI.addColumnvalue(SAPFreightConditionType);
                        LVI.addColumnvalue(SAPPOType);
                        CommonObj.writeToLog(1, "flag true########" + LVI.getXML(), winame);
                        formObject.NGAddListItem("list_po", LVI.getXML());
                        outputResult = "SUCCESS";
                    }
                }
            }
            CommonObj.writeToLog(2, "outputResult:" + outputResult, winame);
            return outputResult;
        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc =" + e.getMessage(), winame);
            return outputResult;
        }
    }

    public boolean BAPI_VendorDetailsOnload(String strVendorCode) throws Exception {

        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            CommonObj.writeToLog(1, "IN SAP Function:BAPI_VendorDetailsOnload:::!!!!!!!!###!", winame);
            CommonObj.writeToLog(1, "strVendorCode:" + strVendorCode, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZBAPI_PO_GR_PENDING</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<GS_LIFNR>" + strVendorCode + "</GS_LIFNR>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            CommonObj.writeToLog(1, "Input for PO Get details : " + BAPIInput.toString(), winame);
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "GT_OUTPUT");
                CommonObj.writeToLog(1, "XMLListMessage::" + XMLListMessage.toString(), winame);
                for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) {
                    CommonObj.writeToLog(1, "PO NO matched", winame);
                    String strName = XMLListMessage.getVal("NAME1").trim();
                    String strGroup = XMLListMessage.getVal("EKGRP").trim();
                    String strFiscalYear = XMLListMessage.getVal("MJAHR").trim();
                    formObject.setNGValue("VendName", strName);
                    formObject.setNGValue("PurchaseGrp", strGroup);
                    formObject.setNGValue("FiscalYr", strFiscalYear);
                    break;
                }
            }
            return true;
        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc =" + e.getMessage(), winame);
            return false;
        }
    }

    public boolean ZBAPI_VENDOR_WITH_TAXCODE(String strVendorCode) throws Exception {

        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        try {

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            CommonObj.writeToLog(1, "strVendorCode>>>>>>>>>>:" + strVendorCode, winame);
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZBAPI_VENDOR_WITH_TAXCODE</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<IV_VENDOR>" + strVendorCode + "</IV_VENDOR>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            CommonObj.writeToLog(1, "BAPIOutput>>>>>>>>>>>>::::::::##########:" + BAPIOutput, winame);
            CommonObj.writeToLog(1, "BAPI: ZBAPI_PO_GR_PENDING Output:" + BAPIOutput, winame);
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                formObject.clear("WHTCode");
                formObject.clear("StateCode");
                WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "ET_TAXCODE");
                for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) {
                    String SAPTaxCode = XMLListMessage.getVal("WT_WITHCD").trim();
                    String SAPStateCode = XMLListMessage.getVal("BUKRS").trim();
                    String SAPWHTType = XMLListMessage.getVal("WITHT").trim();
                    formObject.setNGValue("CompanyCode", SAPStateCode);
                    formObject.setNGValue("Region", SAPStateCode);
                    formObject.setNGValue("txt_SAP_taxcode", SAPTaxCode);
                    formObject.setNGValue("txt_line_taxcode", SAPTaxCode);
                    if (!SAPTaxCode.equalsIgnoreCase("")) {
                        formObject.addItem("WHTCode", SAPTaxCode);
                    }
                }
            }
            return true;
        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc =" + e.getMessage(), winame);
            return false;
        }
    }

    public String ZFI_DOCUMENT_REVERSE(String strVendorCode) {
        String outputResult = "F";
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {
            String strCompanyCode = formObject.getNGValue("CompanyCode");
            String strFiscalYr = formObject.getNGValue("FiscalYr");
            String strSAPDocNo = formObject.getNGValue("SAPDocRefNo");
            //String strSAPDocNo=formObject.getNGValue("SAPDocRefNo");
            String strCurrentDate = formObject.getNGValue("CurrentDateTime");
            CommonObj.writeToLog(1, "IN SAP Function:strCurrentDate::" + strCurrentDate, winame);
            CommonObj.writeToLog(1, "IN SAP Function:SAPDateFormat::" + SAPDateFormat.format((Date) NGDateFormat.parse(strCurrentDate)), winame);
            CommonObj.writeToLog(1, "IN SAP Function:date::" + date, winame);
            CommonObj.writeToLog(1, "IN SAP Function:SAPDateFormat2::" + SAPDateFormat2.format((Date) NGDateFormat.parse(strCurrentDate)), winame);
            CommonObj.writeToLog(1, "IN SAP Function:SAPDateFormat3::" + SAPDateFormat2.format(date), winame);

            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZFI_DOCUMENT_REVERSE</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<IV_COMPANYCODE>" + strCompanyCode + "</IV_COMPANYCODE>");
            BAPIInput.append("<IV_YEAR>" + strFiscalYr + "</IV_YEAR>");
            BAPIInput.append("<IV_DOCUMENT>" + strSAPDocNo + "</IV_DOCUMENT>");
            //BAPIInput.append("<IV_DATE_OF_REVERSAL>" + SAPDateFormat2.format(date) + "</IV_DATE_OF_REVERSAL>");                        
            BAPIInput.append("<IV_PERIOD_OF_REVERSAL>00</IV_PERIOD_OF_REVERSAL>");
            BAPIInput.append("<IV_REASON_FOR_REVERSAL>01</IV_REASON_FOR_REVERSAL>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
            if (XmlResponse.getVal("MainCode").equals("0")) {
                WFXmlList XMLListMessage = XmlResponse.createList("Parameters", "ExportParameters");
                for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) {
                    String SAPReversalDocNo = XMLListMessage.getVal("EX_DOCNO").trim();
                    String SAPReversedBy = XMLListMessage.getVal("EX_USER").trim();
                    String SAPReversedDate = XMLListMessage.getVal("EX_DATE").trim();
                    formObject.setNGValue("ReversalDocNo", SAPReversalDocNo);
                    //formObject.setNGValue("ReversalDocNo", "Test");
                    if (!formObject.getNGValue("ReversalDocNo").equalsIgnoreCase("")) {
                        formObject.setNGValue("ReversalDocNo", SAPReversalDocNo);

                        formObject.RaiseEvent("WFSave");
                        outputResult = "S";
                    }

                }
            }
            return outputResult;
        } catch (Exception e) {
            CommonObj.writeToLog(3, "Error In SAPFunc =" + e.getMessage(), winame);
            CommonObj.writeToLog(3, "IN SAP Function:ZFI_DOCUMENT_REVERSE::" + e.getMessage(), winame);
            return e.getMessage();
        }
    }
}
