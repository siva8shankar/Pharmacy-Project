/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.sapfunctions;

import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author Nanjundamoorthy.b
 */
public class SAPAdvancesPost implements Serializable {

    SAPCall objSAPCall = new SAPCall();
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfDt = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat SAPDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat SAPDateFormat2 = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat NGDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();

    public String AdvancesPost(String strInput1) {
        String outputResult = "FAIL";
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {
            
            StringBuffer BAPIInput = new StringBuffer();
            String BAPIOutput = new String();
            String steUserName = formObject.getUserName();

            CommonObj.writeToLog(1, "IN SAP Function:AdvancesPost DMS No:::>>>>" + winame, winame);
            String Newgenwiname = winame;//.replaceAll("AP-","");
            Newgenwiname = Newgenwiname.replaceAll("-Payments", "");
            Newgenwiname = Newgenwiname.replaceAll("-Process", "");
            int widlength = Newgenwiname.length();
            if (widlength > 15) {
                Newgenwiname = Newgenwiname.substring(widlength - 15, widlength);
            }
            
            
            boolean blnExecute=false;
            String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");
            String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
            String strSubcategory1 = formObject.getNGValue("SubCategory1");
            
            String strDateOfReq= formObject.getNGValue("DateOfReq");     
            String strCompanyCode = formObject.getNGValue("CompanyCode");
            String strEmpCode = formObject.getNGValue("EmployeeCode");
            String strFiscalYr = formObject.getNGValue("FiscalYr");
            String strVendorCode = formObject.getNGValue("VendCode");
            String strPO_NO = formObject.getNGValue("PONumber");
            String strEmpName = formObject.getNGValue("EmployeeName");
            String strDesaigntion = formObject.getNGValue("Designation");
            String strDept = formObject.getNGValue("Department");
            String strGrade = formObject.getNGValue("Grade");
            String strCostCenter = formObject.getNGValue("CostCenter");
            String strBusinessArea = formObject.getNGValue("StateCode");
            String strOrgLoc = formObject.getNGValue("OriginalLocation"); 
            
            String strTotalAmount = formObject.getNGValue("TotInvoiceAmnt");            
            String strBillDate= formObject.getNGValue("InvoiceDate");
            String strBaseLineDate= formObject.getNGValue("BaseLineDt");
            String strPONumber= formObject.getNGValue("PONumber");
            
            
            String qryBusinessPlace="select BISS_PLACE from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA='"+strBusinessArea+"'";
            String strBusinessPlace=CommonObj.DB_QueryExecuteSelect1(qryBusinessPlace); 
            CommonObj.writeToLog(2, "qryBusinessPlace:" + qryBusinessPlace, winame);
            CommonObj.writeToLog(2, "strBusinessPlace:" + strBusinessPlace, winame);
           
            BAPIInput.append(objSAPCall.getconnectionstring());
            BAPIInput.append("<SAPFunctionName>ZFI_VENDOR_DP_REQUEST</SAPFunctionName>");
            BAPIInput.append("<Parameters><ImportParameters>");
            BAPIInput.append("<IV_BKPF>");
            
            BAPIInput.append("<BUKRS>"+strCompanyCode+"</BUKRS>");
            BAPIInput.append("<BLART>"+"KA"+"</BLART>");
            BAPIInput.append("<BLDAT>"+SAPDateFormat2.format((Date) NGDateFormat.parse(strBillDate))+"</BLDAT>");
            BAPIInput.append("<BUDAT>"+SAPDateFormat2.format(date)+"</BUDAT>");
            BAPIInput.append("<MONAT>00</MONAT>");
            BAPIInput.append("<XBLNR>"+"ADVANCES POSTING"+"</XBLNR>");
            BAPIInput.append("<WAERS>"+"INR"+"</WAERS>");
            BAPIInput.append("<BKTXT>"+"ADVANCES POSTING"+"</BKTXT>");
            BAPIInput.append("<ZUMSK>A</ZUMSK>");
            BAPIInput.append("<NEWKO>"+CommonObj.appendzerosN(strVendorCode,10)+"</NEWKO>");
            BAPIInput.append("<GSBER>"+strBusinessArea+"</GSBER>");
            BAPIInput.append("<WRBTR>"+strTotalAmount+"</WRBTR>");
            BAPIInput.append("<ZFBDT>"+SAPDateFormat2.format((Date) NGDateFormat.parse(strBaseLineDate))+"</ZFBDT>");            
            BAPIInput.append("<EBELN>"+strPONumber+"</EBELN>");
            BAPIInput.append("<EBELP>"+"00001"+"</EBELP>");
            BAPIInput.append("<SGTXT>"+"NON PO ADVANCES"+"</SGTXT>");
            BAPIInput.append("<BUPLA>"+strBusinessPlace+"</BUPLA>");
            BAPIInput.append("<SECCO>"+strBusinessPlace+"</SECCO>");
            
            BAPIInput.append("</IV_BKPF>");
            BAPIInput.append("</ImportParameters>");
            BAPIInput.append("</Parameters>");
            BAPIInput.append("</WFSAPInvokeFunction_Input>");
            
            BAPIOutput = objSAPCall.callServer(BAPIInput.toString());            
            WFXmlResponse XmlResponse = new WFXmlResponse(BAPIOutput);
                if (XmlResponse.getVal("MainCode").equals("0")) {
                    WFXmlList XMLListMessage = XmlResponse.createList("TableParameters", "ET_RETURN");
                    if(strTypeOfprocess.equalsIgnoreCase("NONPO")){
                    String strFIDOC_NO = XMLListMessage.getVal("MESSAGE_V1").trim();                    
                    CommonObj.writeToLog(1, "strFIDOC_NO:"+strFIDOC_NO, winame);                    
                    String SAPMESSAGE="Error in SAP Posting";
                    SAPMESSAGE=XMLListMessage.getVal("MESSAGE").trim();                    
                    CommonObj.writeToLog(1, "SAPMESSAGE>>>:"+SAPMESSAGE, winame);                    
                    if (SAPMESSAGE.contains("was posted in company code") && !strFIDOC_NO.equalsIgnoreCase("") && !strFIDOC_NO.equalsIgnoreCase("$") ) {
                        formObject.setNGValue("SAPDocRefNo", strFIDOC_NO);
                        formObject.setNGValue("PostBySAP", formObject.getUserName());
                        formObject.setNGValue("PostingDate", NGDateFormat.format(date));
                        formObject.RaiseEvent("WFSave");
                        outputResult = "SUCCESS";
                    }else{outputResult = SAPMESSAGE;}
                    }//End of NON PO
                    else{
                        int i=0;
                    for (; XMLListMessage.hasMoreElements(true); XMLListMessage.skip(true)) {
                    i++;
                    if(i==3){
                    String strFIDOC_NO = XMLListMessage.getVal("MESSAGE_V1").trim();                    
                    CommonObj.writeToLog(1, "strFIDOC_NO:"+strFIDOC_NO, winame);                    
                    String SAPMESSAGE="Error in SAP Posting";
                    SAPMESSAGE=XMLListMessage.getVal("MESSAGE").trim();                    
                    CommonObj.writeToLog(1, "SAPMESSAGE>>>:"+SAPMESSAGE, winame);                    
                    if (SAPMESSAGE.contains("was posted in company code") && !strFIDOC_NO.equalsIgnoreCase("") && !strFIDOC_NO.equalsIgnoreCase("$") ) {
                        formObject.setNGValue("SAPDocRefNo", strFIDOC_NO);
                        formObject.setNGValue("PostBySAP", formObject.getUserName());
                        formObject.setNGValue("PostingDate", NGDateFormat.format(date));
                        formObject.RaiseEvent("WFSave");
                        outputResult = "SUCCESS";
                    }else{outputResult = SAPMESSAGE;}
                    }//Enf of i==3
                    }                    
                    }//End of PO
                    
                    
                } else {
                    CommonObj.writeToLog(1, "BAPIInput ZFI_VENDOR_DP_REQUEST:Failed Execution", winame);
                    outputResult="Exception";
                    throw new ValidatorException(new FacesMessage("Parking Failed..!!!!", "Comments"));
                }
            
            return outputResult;
            
            } catch (Exception e) {
            CommonObj.writeToLog(3,"Error In SAPFunc=SAPDirectPostER :" + e.getMessage(), winame);
            return e.getMessage();
        }
    }
    
    
}
