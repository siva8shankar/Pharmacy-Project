/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

/**
 *
 * @author deva.r
 */
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.approvalmatrix.ApprovalMatrix_ER;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.sapfunctions.SAPApprovalMatrix;
import com.newgen.omniforms.sapfunctions.SAPFunc;
import static com.newgen.omniforms.user.AP_CommonFunctions.daysBetween;
import static com.newgen.omniforms.user.AP_CommonFunctions.writeToLog;
import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author deva.r
 */
class ER_Initiation implements FormListener {

    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    SAPFunc objSAPFunc = new SAPFunc();
    SAPApprovalMatrix objSAPApprovalMatrix = new SAPApprovalMatrix();
    ApprovalMatrix_ER objApprovalMatrix_ER = new ApprovalMatrix_ER();
    private static FacesMessage fm;
    public boolean flagonload = false;
    String sApprvalMatrixCheck = "";
    //SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private Date inputDate;
    private Date startDate;
    private Date endDate;
    private Date inputDate1;
    private Date fromDate;
    private Date toDate;
    FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
    String strprcsinstid = formConfig.getConfigElement("ProcessInstanceId");
    String strActivityName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
    //Current Date
    Calendar cal = Calendar.getInstance();
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    String strCurDate = sdf.format(cal.getTime());
    static public boolean strBankAccntStatus = false;
    //45DaysChange
    String srtDate = "01/02/2022";

    public ER_Initiation() {
    }

    @Override
    public void formLoaded(FormEvent fe) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        //FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        //String winame = formConfig.getConfigElement("ProcessInstanceId");

        formObject.setNGValue("Comments", "");
        //formObject.setNGValue("RejectReason","");
        formObject.setVisible("btn_load", true);
        formObject.setVisible("btn_ImportDoc", true);
        formObject.setVisible("btn_Approve", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Rescan", false);
        formObject.setVisible("btn_Travel", false); // Cehck and delete the  button
        //End
        formObject.setVisible("lbl_vp", false);
        formObject.setVisible("lbl_trcab", false);
        formObject.setVisible("Label10", false);
        formObject.setVisible("Label9", false);
        formObject.setVisible("QueryName", false);
        formObject.setVisible("QueryMail", false);
        formObject.setVisible("Combo6", false);
        formObject.setVisible("Label11", false);
        // formObject.setHeight("frm_approval", 90);
        formObject.setVisible("frm_salary_adv", false);
        formObject.setVisible("frm_ent_scheme", false);
        formObject.setVisible("frm_mobile_claims", false);
        formObject.setVisible("frm_moving_personal_effects", false);
        formObject.setVisible("frm_brokage_fees", false);
        formObject.setVisible("frm_summary", false);
        formObject.setVisible("frm_family_info", false);
        formObject.setVisible("frm_travel_fare", false);
        formObject.setVisible("frm_hotel_fare", false);
        formObject.setVisible("frm_daily_allw", false);
        formObject.setVisible("frm_convey", false);
        formObject.setVisible("frm_misc", false);
        formObject.setVisible("frm_medical_expense", false);
        formObject.setVisible("lbl_appr_rejresn", false);

        //formObject.setVisible("RejectReason", false);
        //formObject.setTop("frm_approval", 490);
        // formObject.setTop("frm_comments", 590);
        // Hding Fileds of subcat2 AND subcat3
        formObject.setVisible("SubCat2", false);
        formObject.setVisible("Label5", false);
        formObject.setVisible("SubCat3", false);
        formObject.setVisible("Label1", false);
        formObject.setVisible("frm_invoice_details", false);
        formObject.setEnabled("frm_tran_details2", true);
        formObject.setEnabled("frm_invoice_details", true);

        //formObject.getHeight("frm_tran_details2");
        formObject.setHeight("frm_tran_details2", 130);
        formObject.setTop("frm_tran_details2", formObject.getTop("frm_tran_details2") + 10);
        //formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
        formObject.setHeight("Main", 400 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
        formObject.setVisible("frm_po_line", false);
        formObject.setVisible("frm_nonpo_line", false);
        formObject.setVisible("frm_trnsdtl_po", false);
        formObject.setVisible("frm_venddtl_po", false);
        formObject.setVisible("frm_accndtl_po", false);
        formObject.setVisible("frm_parkdtl_po", false);
        formObject.setEnabled("DateOfReq", false);
        formObject.setEnabled("TypeOfProcess", false);
        formObject.setLocked("EmployeeName", true);
        formObject.setLocked("VendorCode", true);
        formObject.setLocked("Designation", true);
        formObject.setLocked("Department", true);
        formObject.setLocked("Grade", true);
        formObject.setLocked("CostCenter", true);
        formObject.setLocked("BusinessArea", true);
        formObject.setLocked("OriginalLocation", true);
        formObject.setLocked("TotalAmount", true);
        formObject.setLocked("BasicSalary", true);
        formObject.setLocked("EligibleAmount", true);
        formObject.setLocked("ServiceTax_BillValue", true);
        formObject.setLocked("ServiceTax_ValueOfPersonalCalls", true);
        //added 26-04-2017 for making the field greyed out.
        formObject.setNGBackColor("ServiceTax_BillValue", new Color(225, 225, 225));
        formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(225, 225, 225));
        formObject.setLocked("TotalAmount", true);
        //formObject.setVisible("btn_sub", true);
        formObject.setVisible("btn_sub", false);

        formObject.setVisible("btn_emp_detail", true);

    }

    @Override
    public void formPopulated(FormEvent fe) throws ValidatorException {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1");

        //Added by sandeep.n on 05Dec2019 for SFIC and ASFI Type of Invoice enable disable changes --Start
//        String Username1= formObject.getUserName();
//        CommonObj.writeToLog(2, "Username1 ==> " + Username1, winame);
//        String sqlQuery1= "SELECT count(1) FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WHERE CompanyCode IN ('SFIC', 'ASFI') AND user_id='" + Username1 + "'";
//        CommonObj.writeToLog(2, "sqlQuery ==> " + sqlQuery1, winame);
//        String strUserCount = CommonObj.DB_QueryExecuteSelect1(sqlQuery1);
//        CommonObj.writeToLog(2, "strUserCount ==> " + strUserCount, winame);
//        if (strUserCount.equalsIgnoreCase("1")) {
//            CommonObj.writeToLog(2, "Inside IF strUserCount ==> " + strUserCount, winame);
//            formObject.clear("TypeOfInvoice");
//            formObject.addItem("TypeOfInvoice", "Entertainment & Others");
//            formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
//            formObject.addItem("TypeOfInvoice", "Travel Request");
//            formObject.addItem("TypeOfInvoice", "Travel Expense");
//        } else {
//             CommonObj.writeToLog(2, "Inside IF3333 strUserCount ==> " + strUserCount, winame);
//            formObject.clear("TypeOfInvoice");
//            formObject.addItem("TypeOfInvoice", "Employee Advances");
//            formObject.addItem("TypeOfInvoice", "Entertainment & Others");
//            formObject.addItem("TypeOfInvoice", "Relocation");
//            formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
//            formObject.addItem("TypeOfInvoice", "Travel Request");
//            formObject.addItem("TypeOfInvoice", "Travel Expense");
//            CommonObj.DBValues_Combo("select distinct TypeofInv from EXT_AP_ER_InvoiceSub with(nolock) where process='ER' and TypeofInv IS NOT NULL and TypeofInv !=''", "TypeOfInvoice");
//        }
        //Added by sandeep.n on 05Dec2019 for SFIC and ASFI changes --End
        //Added on 22-APR-20 enabling Type Of Invoice based on Company code as per Varalakshmi
        String Username1 = formObject.getUserName();
        CommonObj.writeToLog(2, "Username1 ==> " + Username1, winame);
        String sqlQuery1 = "SELECT TOP(1) CompanyCode FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WHERE user_id='" + Username1 + "'";
        CommonObj.writeToLog(2, "sqlQuery ==> " + sqlQuery1, winame);
        String strUserCount = CommonObj.DB_QueryExecuteSelect1(sqlQuery1);
        CommonObj.writeToLog(2, "strUserCount ==> " + strUserCount, winame);
        if (strUserCount.equalsIgnoreCase("ASFI") || strUserCount.equalsIgnoreCase("SFIC") || strUserCount.equalsIgnoreCase("MFPL")) {//Modified on 15-APR-21 for HANA system as per mail confirmation from Jestus
            CommonObj.writeToLog(2, "Inside IF strUserCount ==> " + strUserCount, winame);
            if (!WorkstepName.equalsIgnoreCase("Rework")) {
                CommonObj.writeToLog(2, "Inside ASFI IF WorkstepName Rewor clearing TypeofInvoice ==> " + WorkstepName, winame);
                //formObject.clear("TypeOfInvoice");
            }
            formObject.addItem("TypeOfInvoice", "Entertainment & Others");
            formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
            formObject.addItem("TypeOfInvoice", "Travel Request");
            formObject.addItem("TypeOfInvoice", "Travel Expense");

            formObject.addItem("SubCategory1", "Brokerage Fee");
            formObject.addItem("SubCategory1", "Entertainment");
            formObject.addItem("SubCategory1", "Gift & Complimentary");
            formObject.addItem("SubCategory1", "Imprest Cash");
            formObject.addItem("SubCategory1", "Joining Expense");
            formObject.addItem("SubCategory1", "Look and See Visit");
            formObject.addItem("SubCategory1", "Mobile Re-Imbursements");
            formObject.addItem("SubCategory1", "Moving of Personal Effects");
            formObject.addItem("SubCategory1", "Others");
            formObject.addItem("SubCategory1", "Relocation-Travel Expense");
            formObject.addItem("SubCategory1", "Salary Advance");
            formObject.addItem("SubCategory1", "Self Education Scheme");
            formObject.addItem("SubCategory1", "Travel Request");
            formObject.addItem("SubCategory1", "Travel Expense");

        } else if (strUserCount.equalsIgnoreCase("SBCL")) {
            CommonObj.writeToLog(2, "Inside SBCL IF strUserCount ==> " + strUserCount, winame);
            if (!WorkstepName.equalsIgnoreCase("Rework")) {
                CommonObj.writeToLog(2, "Inside IF WorkstepName Rewor clearing TypeofInvoice ==> " + WorkstepName, winame);
                formObject.clear("TypeOfInvoice");
            }
            formObject.addItem("TypeOfInvoice", "Travel Request");
            formObject.addItem("TypeOfInvoice", "Travel Expense");
        } else if (strUserCount.equalsIgnoreCase("JBML")) {//Modified on 15-APR-21 for HANA system as per mail confirmation from Jestus
            CommonObj.writeToLog(2, "Inside JBML IF strUserCount ==> " + strUserCount, winame);
            if (!WorkstepName.equalsIgnoreCase("Rework")) {
                CommonObj.writeToLog(2, "Inside IF WorkstepName Rewor clearing TypeofInvoice ==> " + WorkstepName, winame);
                formObject.clear("TypeOfInvoice");
            }
            formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
            formObject.addItem("TypeOfInvoice", "Travel Request");
            formObject.addItem("TypeOfInvoice", "Travel Expense");
        } else if (strUserCount.equalsIgnoreCase("IBPL")) {
            CommonObj.writeToLog(2, "Inside IF strUserCount ==> " + strUserCount, winame);

            String sqlQryLoc = "SELECT TOP(1) Work_location FROM NG_BRIT_ACTIVE_USERS_LIST_FROM_BAPI WHERE user_id='" + Username1 + "' and CompanyCode='IBPL'";
            CommonObj.writeToLog(2, "sqlQryLoc ==> " + sqlQryLoc, winame);
            String strLoc = CommonObj.DB_QueryExecuteSelect1(sqlQryLoc);
            CommonObj.writeToLog(2, "strLoc ==> " + strLoc, winame);
            if (strLoc.equalsIgnoreCase("PONDICHERY")) {
                if (!WorkstepName.equalsIgnoreCase("Rework")) {
                    CommonObj.writeToLog(2, "Inside PONDICHERY IF WorkstepName Rewor clearing TypeofInvoice ==> " + WorkstepName, winame);
                    formObject.clear("TypeOfInvoice");
                }
                formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
                formObject.addItem("TypeOfInvoice", "Travel Request");
                formObject.addItem("TypeOfInvoice", "Travel Expense");
            } else if (strLoc.equalsIgnoreCase("ORAGADAM")) {
                if (!WorkstepName.equalsIgnoreCase("Rework")) {
                    CommonObj.writeToLog(2, "Inside ORAGADAM IF WorkstepName Rewor clearing TypeofInvoice ==> " + WorkstepName, winame);
                    formObject.clear("TypeOfInvoice");
                }
                formObject.addItem("TypeOfInvoice", "Entertainment & Others");
                formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
                formObject.addItem("TypeOfInvoice", "Travel Request");
                formObject.addItem("TypeOfInvoice", "Travel Expense");
            }

        } else {
            CommonObj.writeToLog(2, "Inside IF3333 strUserCount ==> " + strUserCount, winame);
            if (!WorkstepName.equalsIgnoreCase("Rework")) {
                CommonObj.writeToLog(2, "Inside IF IF3333 WorkstepName Rewor clearing TypeofInvoice ==> " + WorkstepName, winame);
                formObject.clear("TypeOfInvoice");
            }
            formObject.addItem("TypeOfInvoice", "Employee Advances");
            formObject.addItem("TypeOfInvoice", "Entertainment & Others");
            formObject.addItem("TypeOfInvoice", "Relocation");
            formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
            formObject.addItem("TypeOfInvoice", "Travel Request");
            formObject.addItem("TypeOfInvoice", "Travel Expense");
            if (WorkstepName.equalsIgnoreCase("Rework")) {
                CommonObj.writeToLog(2, "Inside IF IF3333 WorkstepName Rewor adding SubCategory1 ==> " + WorkstepName, winame);
                formObject.addItem("SubCategory1", "Brokerage Fee");
                formObject.addItem("SubCategory1", "Entertainment");
                formObject.addItem("SubCategory1", "Gift & Complimentary");
                formObject.addItem("SubCategory1", "Imprest Cash");
                formObject.addItem("SubCategory1", "Joining Expense");
                formObject.addItem("SubCategory1", "Look and See Visit");
                formObject.addItem("SubCategory1", "Mobile Re-Imbursements");
                formObject.addItem("SubCategory1", "Moving of Personal Effects");
                formObject.addItem("SubCategory1", "Others");
                formObject.addItem("SubCategory1", "Relocation-Travel Expense");
                formObject.addItem("SubCategory1", "Salary Advance");
                formObject.addItem("SubCategory1", "Self Education Scheme");
                formObject.addItem("SubCategory1", "Travel Request");
                formObject.addItem("SubCategory1", "Travel Expense");
            }
            if (!WorkstepName.equalsIgnoreCase("Rework")) {
                CommonObj.writeToLog(2, "Inside IF IF3333 WorkstepName Rewor clearing TypeofInvoice ==> " + WorkstepName, winame);
                CommonObj.DBValues_Combo("select distinct TypeofInv from EXT_AP_ER_InvoiceSub with(nolock) where process='ER' and TypeofInv IS NOT NULL and TypeofInv !=''", "TypeOfInvoice");
            }
        }

        //End on 22-APR-20
        //Added started by Sivashankar for hiding the Grade 29-June-2018
        String strFlag = "";
        String sqlQuery = "SELECT Value FROM EXT_AP_ER_MASTER_EXTERNALCONSTANTS WITH(NOLOCK) WHERE ColumnName='BLOCKPORTAL'";
        List<List<String>> Flag = formObject.getDataFromDataSource(sqlQuery);
        strFlag = Flag.get(0).get(0);
        CommonObj.writeToLog(2, "sqlQuery ==> " + sqlQuery, winame);
        CommonObj.writeToLog(2, "strFlag ==> " + strFlag, winame);
        if (strFlag.equalsIgnoreCase("YES")) {
            formObject.setVisible("lbl_inv_grade", false);
            formObject.setVisible("Grade", false);
            formObject.setVisible("lbl_inv_design", false);
            formObject.setVisible("Designation", false);
        }
        //Added ended by Sivashankar for hiding the Grade
        flagonload = true;
        if (formObject.getNGValue("WorkID").equalsIgnoreCase("")) {
            formObject.setNGValue("WorkID", winame);
        }
        CommonObj.writeToLog(2, "WorkItemName:" + formObject.getNGValue("WorkItemName"), winame);

        if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") || strTypeofinvoice.equalsIgnoreCase("Travel Expense") || strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
            formObject.setEnabled("RequestFor", true);

        } else {
            formObject.setEnabled("RequestFor", false);
        }
        if (strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
            formObject.setNGValue("TypeOfTravel", "Domestic");
//            formObject.addItem("RequestFor", "Consultant"); 
            formObject.addItem("RequestFor", "Consultant/New Joinee"); // Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram
        }
        if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")) {

//            formObject.addItem("RequestFor", "Consultant");
            formObject.addItem("RequestFor", "Consultant/New Joinee"); // Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram
        }
//        if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Self") || formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant")) {
        if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Self") || formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant/New Joinee")) {// Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram
            formObject.setLocked("EmployeeCode", true);
        } else {
            formObject.setLocked("EmployeeCode", false);
        }
        if (formObject.getNGValue("BillPlan").equalsIgnoreCase("") || formObject.getNGValue("BillPlan").equalsIgnoreCase("--Select--")) {
            formObject.setEnabled("BillPlanOthers", false);
            formObject.setLocked("BillPlanOthers", true);
            formObject.setNGBackColor("BillPlanOthers", new Color(225, 225, 225));
        } else if (formObject.getNGValue("BillPlan").equalsIgnoreCase("Others")) {
            formObject.setEnabled("BillPlanOthers", true);
            formObject.setLocked("BillPlanOthers", false);
            formObject.setNGBackColor("BillPlanOthers", Color.white);
        } else {
            formObject.setEnabled("BillPlanOthers", false);
            formObject.setLocked("BillPlanOthers", true);
            formObject.setNGBackColor("BillPlanOthers", new Color(225, 225, 225));
        }
        // System.out.println("form Populated in the ER_Initiation");
        CommonObj.writeToLog(2, "form Populated in the ER_Initiation", winame);//Success Log
        //Check below PID captured in the form comments histrory fetch query
        //formObject.setNGValue("PostSts", formObject.getWFWorkitemName());
        //Below line commented by SandeepKn on 10Jan2020 for ASFI and SFIC changes
        // CommonObj.DBValues_Combo("select distinct TypeofInv from EXT_AP_ER_InvoiceSub with(nolock) where process='ER' and TypeofInv IS NOT NULL and TypeofInv !=''", "TypeOfInvoice");
        formObject.setNGValue("TypeOfProcess", "NONPO");
        CommonObj.writeToLog(2, "form Populated in the ER_Initiation strTypeofinvoice--" + strTypeofinvoice, winame);
        if (WorkstepName.equalsIgnoreCase("Rework") && strTypeofinvoice.equalsIgnoreCase("Travel Request") && formObject.getNGValue("ApprSts1").equalsIgnoreCase("Approved")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage", winame);
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage strTypeofinvoice--" + strTypeofinvoice, winame);
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage ApprSts1--" + formObject.getNGValue("ApprSts1"), winame);
            //formObject.setNGValue("SubCategory1", "");
            //Added By IBPS Support for type of invoice null value
            formObject.addItem("TypeOfInvoice", "Travel Expense");
            formObject.addItem("SubCategory1", "Travel Expense");
            //End of Added By IBPS Support for type of invoice null value
            formObject.setNGValue("TypeOfInvoice", "Travel Expense");
            formObject.setNGValue("SubCategory1", "Travel Expense");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation after setting values--" + strTypeofinvoice, winame);
        }
        //Added By IBPS Support for type of invoice null value
        if (WorkstepName.equalsIgnoreCase("Rework") && strTypeofinvoice.equalsIgnoreCase("Travel Expense") && formObject.getNGValue("ApprSts1").equalsIgnoreCase("Approved")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage1", winame);
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage1 strTypeofinvoice--" + strTypeofinvoice, winame);
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage1 ApprSts1--" + formObject.getNGValue("ApprSts1"), winame);
            //formObject.setNGValue("SubCategory1", "");
            formObject.addItem("TypeOfInvoice", "Travel Expense");
            formObject.addItem("SubCategory1", "Travel Expense");
            formObject.setNGValue("TypeOfInvoice", "Travel Expense");
            formObject.setNGValue("SubCategory1", "Travel Expense");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation after setting values1--" + strTypeofinvoice, winame);
        }

        if (WorkstepName.equalsIgnoreCase("ER_Initiation") && strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation stage12--" + WorkstepName, winame);
            formObject.addItem("TypeOfInvoice", "Travel Request");
            formObject.addItem("SubCategory1", "Travel Request");
            formObject.setNGValue("TypeOfInvoice", "Travel Request");
            formObject.setNGValue("SubCategory1", "Travel Request");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation12 after setting values1--" + strTypeofinvoice, winame);
        }
        if (WorkstepName.equalsIgnoreCase("ER_Initiation") && strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation stage123--" + WorkstepName, winame);
            formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
            formObject.addItem("SubCategory1", "Mobile Re-Imbursements");
            formObject.setNGValue("TypeOfInvoice", "Mobile Re-Imbursements");
            formObject.setNGValue("SubCategory1", "Mobile Re-Imbursements");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 after setting values1--" + strTypeofinvoice, winame);
        }
        if (WorkstepName.equalsIgnoreCase("ER_Initiation") && strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation stage123--" + WorkstepName, winame);
            formObject.addItem("TypeOfInvoice", "Entertainment & Others");
            formObject.setNGValue("TypeOfInvoice", "Entertainment & Others");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 after setting values1--" + strTypeofinvoice, winame);
        }
        if (WorkstepName.equalsIgnoreCase("ER_Initiation") && strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && strSubcategory.equalsIgnoreCase("Entertainment")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense Entertainment at ER_Initiation stage123--" + WorkstepName, winame);
            formObject.addItem("SubCategory1", "Entertainment");
            formObject.setNGValue("SubCategory1", "Entertainment");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Entertainment after setting values1--" + strTypeofinvoice, winame);
        }
        if (WorkstepName.equalsIgnoreCase("ER_Initiation") && strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && strSubcategory.equalsIgnoreCase("Others")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense Others at ER_Initiation stage123--" + WorkstepName, winame);
            formObject.addItem("SubCategory1", "Others");
            formObject.setNGValue("SubCategory1", "Others");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Others after setting values1--" + strTypeofinvoice, winame);
        }
        if (WorkstepName.equalsIgnoreCase("ER_Initiation") && strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && strSubcategory.equalsIgnoreCase("Gift & Complimentary")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation Gift & Complimentary stage123--" + WorkstepName, winame);
            formObject.addItem("SubCategory1", "Gift & Complimentary");
            formObject.setNGValue("SubCategory1", "Gift & Complimentary");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Gift & Complimentary after setting values1--" + strTypeofinvoice, winame);
        }
        if (WorkstepName.equalsIgnoreCase("ER_Initiation") && strTypeofinvoice.equalsIgnoreCase("Relocation")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation Relocation stage123--" + WorkstepName, winame);
            formObject.addItem("TypeOfInvoice", "Relocation");
            formObject.setNGValue("TypeOfInvoice", "Relocation");
            if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
                formObject.addItem("SubCategory1", "Brokerage Fee");
                formObject.setNGValue("SubCategory1", "Brokerage Fee");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Brokerage Fee after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Joining Expense")) {
                formObject.addItem("SubCategory1", "Joining Expense");
                formObject.setNGValue("SubCategory1", "Joining Expense");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Joining Expense after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {
                formObject.addItem("SubCategory1", "Look and See Visit");
                formObject.setNGValue("SubCategory1", "Look and See Visit");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Look and See Visit after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Moving of Personal Effects")) {
                formObject.addItem("SubCategory1", "Moving of Personal Effects");
                formObject.setNGValue("SubCategory1", "Moving of Personal Effects");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Moving of Personal Effects after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
                formObject.addItem("SubCategory1", "Relocation-Travel Expense");
                formObject.setNGValue("SubCategory1", "Relocation-Travel Expense");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Relocation-Travel Expense after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Self Education Scheme")) {
                formObject.addItem("SubCategory1", "Self Education Scheme");
                formObject.setNGValue("SubCategory1", "Self Education Scheme");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Moving of Personal Effects after setting values1--" + strTypeofinvoice, winame);
            }

        }
        if (WorkstepName.equalsIgnoreCase("ER_Initiation") && strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation Employee Advances stage123--" + WorkstepName, winame);
            formObject.addItem("TypeOfInvoice", "Employee Advances");
            formObject.setNGValue("TypeOfInvoice", "Employee Advances");
            if (strSubcategory.equalsIgnoreCase("Salary Advance")) {
                formObject.addItem("SubCategory1", "Salary Advance");
                formObject.setNGValue("SubCategory1", "Salary Advance");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Salary Advance after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Imprest Cash")) {
                formObject.addItem("SubCategory1", "Imprest Cash");
                formObject.setNGValue("SubCategory1", "Imprest Cash");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Imprest Cash after setting values1--" + strTypeofinvoice, winame);
            }
        }

        //End of Added By IBPS Support for type of invoice null value
        // Added by Deva on 10-12-2016 19:25
        //Begin
        CommonObj.ER_Frames();
        formObject.setVisible("btn_sub", true);
        formObject.setVisible("btn_Cab", false);
        formObject.setVisible("btn_cmnthsty", false);
        formObject.setNGValue("FiscalYr", CommonObj.Cur_FinanicalYr());

        //Added by Sivashankar KS on 11-Mar-2019 starts here
        formObject.clear("cb_hotelfare_britannia_statename");
        formObject.setNGValue("cb_hotelfare_britannia_statename", "");
        writeToLog(2, "formObject.getNGValue(\"CompanyCode\")  ::: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
        CommonObj.DBValues_Combo("SELECT DISTINCT(StateName) FROM EXT_AP_ER_GST_MASTER WITH(NOLOCK) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "'", "cb_hotelfare_britannia_statename");
        formObject.clear("cb_hotelfare_gst_percentage");
        formObject.setNGValue("cb_hotelfare_gst_percentage", "");
        CommonObj.DBValues_Combo("SELECT GSTVALUE FROM EXT_AP_ER_GST_VALUE_MASTER WITH(NOLOCK)", "cb_hotelfare_gst_percentage");
        //Added by Sivashankar KS on 11-Mar-2019 ends here

        //Added by SandeepKN on 10Jan2020 for ASFI and SFIC changes -- Start
        if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
            formObject.clear("oe_drpdwn_location");
            formObject.setNGValue("oe_drpdwn_location", "");
            writeToLog(2, "formObject.getNGValue(\"CompanyCode\")  ::: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
            CommonObj.DBValues_Combo("SELECT DISTINCT(Location) FROM EXT_FromLoc WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC", "oe_drpdwn_location");
            formObject.clear("dp_hotelfare_location");
            formObject.setNGValue("dp_hotelfare_location", "");
            writeToLog(2, "formObject.getNGValue(\"CompanyCode\")  ::: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
            CommonObj.DBValues_Combo("SELECT DISTINCT(Location) FROM EXT_FromLoc WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC", "dp_hotelfare_location");
        }
        //Added by SandeepKN on 10Jan2020 for ASFI and SFIC changes -- End

        strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        if (strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
            formObject.setNGValue("SubCategory1", "Travel Request");
            //formObject.setEnabled("cb_trvl_hh", false);
            //formObject.setEnabled("cb_trvl_mm", false);
            //formObject.setEnabled("cb_trvl_class", false);
            //formObject.setEnabled("btn_trvl_class", false);
            formObject.setEnabled("txt_trvl_tcktno", false);
            formObject.setEnabled("cb_trvl_paidby", false);
            formObject.setEnabled("txt_trvl_amnt", false);
            //formObject.setNGBackColor("cb_trvl_hh", new Color(225, 225, 225));
            //formObject.setNGBackColor("cb_trvl_mm", new Color(225, 225, 225));
            //formObject.setNGBackColor("cb_trvl_class", new Color(225, 225, 225));
            //formObject.setNGBackColor("btn_trvl_class", new Color(225, 225, 225));
            formObject.setNGBackColor("txt_trvl_tcktno", new Color(225, 225, 225));
            formObject.setNGBackColor("cb_trvl_paidby", new Color(225, 225, 225));
            formObject.setNGBackColor("txt_trvl_amnt", new Color(225, 225, 225));
        }

        if (WorkstepName.equalsIgnoreCase("Rework")) {
//            formObject.setNGValue("CurrAppLevel", "");
//            formObject.setNGValue("MaxAppLevel", "");
//            formObject.setNGValue("App1index", "");
//            formObject.setNGValue("App2index", "");
//            formObject.setNGValue("App3index", "");
//            formObject.setNGValue("App4index", "");
//            formObject.setNGValue("App5index", "");
//            formObject.setNGValue("App6index", "");
//            formObject.setNGValue("App7index", "");
//            formObject.setNGValue("App8index", "");
            formObject.setNGValue("Comments", "");

            formObject.setLeft("btn_submit", 210);
            formObject.setLeft("btn_Reject", 350);
            formObject.setVisible("btn_Reject", true);
            formObject.setCaption("btn_Reject", "Reject");
            formObject.setVisible("btn_cmnthsty", true);

            /*if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")) {
             formObject.setVisible("btn_add_trvl", false);
             formObject.setVisible("btn_del_trvl", false);
             }*/
        } else {
            formObject.setLeft("btn_submit", 272);
            formObject.setLeft("btn_Reject", 500);
            formObject.setVisible("btn_Reject", true);
            formObject.setCaption("btn_Reject", "Reject");
        }

        if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Travel Request") || strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {
            formObject.setVisible("lbl_note", false);
        } else {
            formObject.setVisible("lbl_note", true);
            //Added by Sivashankar KS on 29-Aug-2019 Code to display Go-Air Feddback Link & Note starts here
            if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")) {
                writeToLog(1, "inside formpopulate goair check starts ..... ", winame);
                int list_travel = formObject.getItemCount("list_travel");
                CommonObj.writeToLog(2, "list_travel Count:" + list_travel, winame);
                CommonObj.writeToLog(2, "list_Entertain:" + (formObject.getSelectedIndex("list_travel")), winame);
                CommonObj.writeToLog(2, "getNGListView:list_travel:" + formObject.getNGListView("list_travel"), winame);
                String strGoAirSts = "False";
                if (list_travel > 0) {
                    for (Integer i = 0; i < list_travel; i++) {
                        String TravelLineItemData[] = CommonObj.getRowValue(formObject, "list_travel", i);
                        CommonObj.writeToLog(2, "intLineNo:" + i, winame);
                        String sValue5 = TravelLineItemData[5].trim();
                        CommonObj.writeToLog(2, "sValue5 - Mode :" + sValue5, winame);
                        if (sValue5.equalsIgnoreCase("Air")) {
                            String sValue12 = TravelLineItemData[12].trim();
                            CommonObj.writeToLog(2, "sValue12 Flight Number :" + sValue12, winame);
                            if (sValue12.contains("G8")) {
                                strGoAirSts = "True";
                            }
                        }
                    }
                }
                // visibility code here
                if (strGoAirSts.equalsIgnoreCase("True")) {
                    formObject.setVisible("lbl_goairnote", true);
                    formObject.setVisible("btn_goair", true);
                    formObject.setLeft("btn_goair", 452);
                    formObject.setTop("btn_goair", 154);
                    formObject.setLeft("lbl_goairnote", 11);
                    formObject.setTop("lbl_goairnote", 158);
                }
                writeToLog(1, "inside formpopulate goair check ends ..... ", winame);

                //Added by Sandeep KN on 30Dec2019 Code to display GHB Feddback Link --start
                if ((formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")
                        || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI"))) {
                    writeToLog(2, "SFIC AND ASFI Company, hence no validation for GHB FEEDBACK..... ", winame);
                } else {
                    // if (strSubcategory.equalsIgnoreCase("Travel Expense")) {// modified on 31Dec2019 as per Mr.SivaRam to fill the feedback in any case
                    String strGHBFeedbackSts = "False";

                    writeToLog(1, "inside form pop up click GHBFeedbackSts starts ..... ", winame);
                    String strGHBWorkID1 = "";
                    try {
                        String strGHBUsername = formObject.getUserName();
                        CommonObj.writeToLog(2, "strGHBUsername ==> " + strGHBUsername, winame);
                        String sqlQueryyy2 = "SELECT top(1)e.WorkID FROM EXT_GHB e WITH(NOLOCK),WFINSTRUMENTTABLE w WITH(NOLOCK),EXT_GUESTHOUSE_OCCUPANCY_DETAILS_ACTIVE c "
                                + "WITH(NOLOCK) WHERE e.WorkID=w.Processinstanceid AND e.WorkID=c.PID AND w.ActivityId IN(SELECT activityid FROM ACTIVITYTABLE "
                                + "WITH(NOLOCK)  WHERE ProcessDefId=6 AND ActivityId=11) AND e.EmployeeName='" + strGHBUsername + "' ORDER BY e.WorkID DESC";
                        List<List<String>> GHBWorkID = formObject.getDataFromDataSource(sqlQueryyy2);
                        if (!GHBWorkID.get(0).get(0).equalsIgnoreCase("")) {
                            strGHBWorkID1 = GHBWorkID.get(0).get(0);
                            CommonObj.writeToLog(2, "sqlQueryyy2 ==> " + sqlQueryyy2, winame);
                            CommonObj.writeToLog(2, "strGHBWorkID1 ==> " + strGHBWorkID1, winame);
                            if (!strGHBWorkID1.equalsIgnoreCase("")) {
                                String strGHBWicount = "";
                                String sql1Query3 = "SELECT (CAST(count(1) AS INT)) AS Count FROM EXT_GuestHouse_Feedback_Details WITH(NOLOCK) WHERE WorkID = '" + strGHBWorkID1 + "'";
                                List<List<String>> GHBWicount = formObject.getDataFromDataSource(sql1Query3);
                                strGHBWicount = GHBWicount.get(0).get(0);
                                CommonObj.writeToLog(2, "sql1Query3 ==> " + sql1Query3, winame);
                                CommonObj.writeToLog(2, "strGHBWicount ==> " + strGHBWicount, winame);
                                if (strGHBWicount.equalsIgnoreCase("0")) {
                                    strGHBFeedbackSts = "True";
                                }
                            }
                        }
                    } catch (Exception e) {
                        CommonObj.writeToLog(3, "Exception In GHBFeedbackSts populate==" + e.getMessage(), winame);
                    }

                    // visibility code here
                    if (strGHBFeedbackSts.equalsIgnoreCase("True")) {
                        formObject.setVisible("btn_ghb_feedbk", true);
                        formObject.setLeft("btn_ghb_feedbk", 252);
                        formObject.setTop("btn_ghb_feedbk", 154);
                    }
                    writeToLog(1, "inside form pop button click goair check ends ..... ", winame);
                    //}//Added by Sandeep KN on 30Dec2019 Code to display GHB Feddback Link --End
                }//Added by Sandeep KN on 30Dec2019 Code to display GHB Feddback Link --End
            }
            //Added by Sivashankar KS on 29-Aug-2019 Code to display Go-Air Feddback Link & Note ends here
        }
        flagonload = true;

        //Added by sandeepKn on 10JAN2020 for ASFI and SFIC changes- Start
        if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
            //Added by Sivashankar KS on 05-Nov-2019 ServiceProvided loading from master starts here
            if (formObject.getNGValue("ServiceProvider").equalsIgnoreCase("")) {
                formObject.clear("ServiceProvider");
                formObject.setNGValue("ServiceProvider", "");
                String sQuery = "SELECT ServiceProvider FROM EXT_Mobile_ServiceProvider_Master WITH(NOLOCK) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY ServiceProvider ASC";
                CommonObj.DBValues_Combo(sQuery, "ServiceProvider");
            } else {
                String sQuery = "SELECT ServiceProvider FROM EXT_Mobile_ServiceProvider_Master WITH(NOLOCK) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY ServiceProvider ASC";
                CommonObj.DBValues_Combo(sQuery, "ServiceProvider");
            }
            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                formObject.setLocked("ServiceTax_BillValue", false);
                formObject.setLocked("ServiceTax_ValueOfPersonalCalls", false);
                formObject.setEnabled("ServiceTax_BillValue", true);
                formObject.setEnabled("ServiceTax_ValueOfPersonalCalls", true);
                formObject.setNGBackColor("ServiceTax_BillValue", new Color(250, 250, 250));
                formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(250, 250, 250));
            } else {
                formObject.setLocked("ServiceTax_BillValue", true);
                formObject.setLocked("ServiceTax_ValueOfPersonalCalls", true);
                formObject.setEnabled("ServiceTax_BillValue", false);
                formObject.setEnabled("ServiceTax_ValueOfPersonalCalls", false);
                formObject.setNGBackColor("ServiceTax_BillValue", new Color(225, 225, 225));
                formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(225, 225, 225));
            }
        }
        //Added by Sivashankar KS on 05-Nov-2019 ServiceProvided loading from master ends here
        if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
            formObject.setVisible("lbl_paidto", true);
            formObject.setVisible("ToBePaid", true);
            formObject.setVisible("btn_ghouse_check", false);
            formObject.clear("TypeOfTravel");
//            formObject.addItem("TypeOfTravel", "Domestic");
            formObject.addItem("TypeOfTravel", "International - Business Travel");
            formObject.addItem("TypeOfTravel", "International - Annual Leave travel");
            formObject.clear("cb_trvl_paidby");
            formObject.addItem("cb_trvl_paidby", "Self");
            formObject.addItem("cb_trvl_paidby", "Company");//added by SandeepKN on 03Dec2019 as per Vijayalakshmi testing
        } else {
            formObject.setVisible("btn_ghouse_check", true);
            formObject.setVisible("lbl_paidto", false);
            formObject.setVisible("ToBePaid", false);
            formObject.clear("TypeOfTravel");
            formObject.addItem("TypeOfTravel", "Domestic");
            formObject.addItem("TypeOfTravel", "International");
            formObject.clear("cb_trvl_paidby");
            formObject.addItem("cb_trvl_paidby", "Company");
            formObject.addItem("cb_trvl_paidby", "Self");
        }

        //Added by sandeepkn on 10JAn2020 for ASFI anD SFIC changes - End
        if (!WorkstepName.equalsIgnoreCase("Rework")) {
            CommonObj.writeToLog(2, "Inside IF for enabling frame frm_tran_details2==> " + WorkstepName, winame);
            //formObject.setEnabled("frm_tran_details2", true);
        }
        CommonObj.enableDORMailBtn(formObject);
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException {
        //System.out.println("form saveFormStarted in the ER_Initiation");
        //CommonObj.writeToLog(2,"form saveFormStarted in the ER_Initiation",winame);
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException {
        //System.out.println("form saveFormCompleted in the ER_Initiation");
        // CommonObj.writeToLog(2,"form saveFormCompleted in the ER_Initiation",winame);
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        // CommonObj.writeToLog(2,"form submitFormStarted in the ER_Initiation",winame); 
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        CommonObj.writeToLog(2, "Inside submitFormCompleted", winame);
        CommonObj.InserComments();

    }

    @Override
    public void eventDispatched(ComponentEvent pEvent) throws ValidatorException {
        //System.out.println("In eventDispatched");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String fieldName = pEvent.getSource().getName();
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1");
        String Grade1 = formObject.getNGValue("Grade");
        String WorkstepName1 = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
        CommonObj.writeToLog(2, "Type-->" + pEvent.getType(), winame);
        CommonObj.writeToLog(2, "Name-->" + pEvent.getSource().getName(), winame);
        switch (pEvent.getType()) {
            case MOUSE_CLICKED: {

                //System.out.println("Inside Mouse Click");
                CommonObj.writeToLog(2, "Inside Mouse Click", winame);
                if (pEvent.getSource().getName().equalsIgnoreCase("btn_load")) {
                    String bapires = "";
                    CommonObj.writeToLog(2, "strSubcategory:" + strSubcategory, winame);

                    if (formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("")) {
                        throw new ValidatorException(new FacesMessage("Please select the type of invoice", "TypeOfInvoice"));
                    }
                    FormReference formObject2 = FormContext.getCurrentInstance().getFormReference();
                    if (formObject2.getNGValue("SubCategory1").equalsIgnoreCase("")) {
                        throw new ValidatorException(new FacesMessage("Please select the subcategory", "SubCategory1"));
                    }
                    //CommonObj.ER_Frames();

                    //For HANA Migration on 28-MAR-21
//                    if (strTypeofinvoice.equalsIgnoreCase("Employee Advances")
//                            || strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")
//                            || strTypeofinvoice.equalsIgnoreCase("Relocation")
//                            || strTypeofinvoice.equalsIgnoreCase("Travel Expense")
//                            || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")) {
//                        writeToLog(2, "HANA Migration :: " + strTypeofinvoice, strprcsinstid);
//                        throw new ValidatorException(new FacesMessage("Only Travel Request are allowed to raise due to HANA migartion", "TypeOfInvoice"));
//                    }
                    //End on 28-MAR-21
                    if ((strSubcategory.equalsIgnoreCase("Joining Expense"))
                            || (strSubcategory.equalsIgnoreCase("Look and See Visit"))
                            || (strSubcategory.equalsIgnoreCase("Travel Expense"))) {
                        formObject.setVisible("frm_invoice_details", true);
                    }

                    formObject.setNGValue("RequestFor", "Self");
                    formObject.setLocked("EmployeeCode", true);

                    if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") || strTypeofinvoice.equalsIgnoreCase("Travel Expense") || strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
                        formObject.setEnabled("RequestFor", true);
                        formObject.setLocked("EmployeeCode", false);
                    } else {
                        formObject.setEnabled("RequestFor", false);
                    }

                    if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
                        formObject.setNGValue("SubCategory1", "Mobile Re-Imbursements");

                    } else if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")) {
                        formObject.setNGValue("SubCategory1", "Travel Expense");
//                        formObject.addItem("RequestFor", "Consultant");
                        formObject.addItem("RequestFor", "Consultant/New Joinee"); // Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram
                        //formObject.setEnabled("SubCategory1",false);
                    } else if (strTypeofinvoice.equalsIgnoreCase("Travel Request")) {

                        formObject.setNGValue("SubCategory1", "Travel Request");
//                        formObject.addItem("RequestFor", "Consultant");
                        formObject.addItem("RequestFor", "Consultant/New Joinee"); // Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram
                        //formObject.setEnabled("cb_trvl_hh", false);
                        //formObject.setEnabled("cb_trvl_mm", false);
                        //formObject.setEnabled("cb_trvl_class", false);
                        //formObject.setEnabled("btn_trvl_class", false);
                        formObject.setEnabled("txt_trvl_tcktno", false);
                        formObject.setEnabled("cb_trvl_paidby", false);
                        formObject.setEnabled("txt_trvl_amnt", false);
                        //formObject.setNGBackColor("cb_trvl_hh", new Color(225, 225, 225));
                        // formObject.setNGBackColor("cb_trvl_mm", new Color(225, 225, 225));
                        //formObject.setNGBackColor("cb_trvl_class", new Color(225, 225, 225));
                        //formObject.setNGBackColor("btn_trvl_class", new Color(225, 225, 225));
                        formObject.setNGBackColor("txt_trvl_tcktno", new Color(225, 225, 225));
                        formObject.setNGBackColor("cb_trvl_paidby", new Color(225, 225, 225));
                        formObject.setNGBackColor("txt_trvl_amnt", new Color(225, 225, 225));
                    }
                    formObject.setVisible("btn_sub", false);
                    formObject.setVisible("btn_cmnthsty", false);
                    formObject.setLeft("btn_submit", 272);

                    //Added by NanjundaMoorthy for BAPI Calls  
                    if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") || strTypeofinvoice.equalsIgnoreCase("Travel Expense") || strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
                        try {
                            CommonObj.writeToLog(2, "BAPI_EmployeeDetailsOnload calling", winame);
                            bapires = objSAPFunc.BAPI_EmployeeDetailsOnload(formObject.getUserName());
                        } catch (Exception e) {
                            CommonObj.writeToLog(3, "Exception In BAPI_EmployeeDetailsOnload Click, ER_initiation=" + e.getMessage(), winame);
                        }

                        //Added By Harinatha R on 2017/09/20
                        if (bapires.equalsIgnoreCase("FAIL")) {
                            throw new ValidatorException(new FacesMessage("Please contact administrator.. Exception while fetching employee details", "TypeOfInvoice"));
                        } else if (!bapires.equalsIgnoreCase("") && !bapires.equalsIgnoreCase("SUCCESS")) {

                            throw new ValidatorException(new FacesMessage(bapires, "TypeOfInvoice"));
                        }
                        //Ended By Harinatha R on 2017/09/20

                    } else if (strTypeofinvoice.equalsIgnoreCase("Employee Advances") || strTypeofinvoice.equalsIgnoreCase("Relocation") || strTypeofinvoice.equalsIgnoreCase("Self Education Scheme")) {
                        //Modified By Harinath on 2017/03/20

                        //Added on 25-NOV-20 for disabling salary advance policy
                        if (strSubcategory.equalsIgnoreCase("Salary Advance")) {
                            throw new ValidatorException(new FacesMessage("Salary Advance Policy has been discontinued wef 25-Nov-2020. "));
                        }
                        //End on 25-NOV-20
                        try {
                            CommonObj.writeToLog(2, "BAPI_EmployeeDetailsOnloadHR calling", winame);
                            bapires = objSAPFunc.BAPI_EmployeeDetailsOnloadHR(formObject.getUserName());
                            CommonObj.writeToLog(2, "BAPI_EmployeeDetailsOnloadHR.. BAPI result==>> bapires :: " + bapires, winame);
                        } catch (Exception e) {
                            CommonObj.writeToLog(3, "Exception In BAPI_EmployeeDetailsOnloadHR Click, ER_initiation=" + e.getMessage(), winame);
                        }
                        //Ended By Harinath on 2017/03/20

                        //Added By Harinatha R on 2017/09/20
                        if (bapires.equalsIgnoreCase("FAIL")) {
                            throw new ValidatorException(new FacesMessage("Please contact administrator.. Exception while fetching employee details", "TypeOfInvoice"));
                        } else if (!bapires.equalsIgnoreCase("") && !bapires.equalsIgnoreCase("SUCCESS")) {

                            throw new ValidatorException(new FacesMessage(bapires, "TypeOfInvoice"));
                        }
                        //Ended By Harinatha R on 2017/09/20

                    } else {
                        throw new ValidatorException(new FacesMessage("Please select valid type of invoice", "TypeOfInvoice"));
                    }
                    formObject.RaiseEvent("WFSave");

                    if (bapires.equalsIgnoreCase("SUCCESS")) {
                        CommonObj.ER_EligibleAmount();

                        //Added By Harinath on 2017/03/20
                        CommonObj.writeToLog(2, "BAPI result==>> bapires :: " + bapires, winame);
                        if (strSubcategory.equalsIgnoreCase("House Rent Advance")) {
                            if (bapires.equalsIgnoreCase("Y")) {
                                throw new ValidatorException(new FacesMessage("Advance exists. Hence cant apply for House Rent Advance", "SubCategory1"));
                            } else if (bapires.equalsIgnoreCase("NE")) {
                                throw new ValidatorException(new FacesMessage("User is not eligible for House Rent Advance", "SubCategory1"));
                            }
                        } else if (strSubcategory.equalsIgnoreCase("Salary Advance") && bapires.equalsIgnoreCase("Y")) {

                            throw new ValidatorException(new FacesMessage("Advance exists. Hence cant apply for  Salary Advance", "SubCategory1"));
                        } else if (strSubcategory.equalsIgnoreCase("Exceptional Advances") && bapires.equalsIgnoreCase("Y")) {

                            throw new ValidatorException(new FacesMessage("Advance exists. Hence cant apply for Exceptional Advances", "SubCategory1"));
                        } else if (strSubcategory.equalsIgnoreCase("Imprest Cash")) {
                            String queryhouse = "SELECT Claimlimit FROM EXT_AP_ER_ClaimLimit with(nolock) WHERE Grade='" + Grade1 + "' and Subcategory1='" + strSubcategory + "'";
                            String[] FieldValue_array = CommonObj.DB_QueryExecute(queryhouse);
                            String claimval = FieldValue_array[0];
                            AP_CommonFunctions.writeToLog(2, "Imprest Cash:", winame);
                            CommonObj.writeToLog(2, "claimval ::: " + claimval, winame);
                            if (claimval.equalsIgnoreCase("0.00")) {
                                throw new ValidatorException(new FacesMessage("Not Eligible for claim", "SubCategory1"));
                            }
                        } else {
                            formObject.setNGValue("FiscalYr", CommonObj.Cur_FinanicalYr());
                            //Ended By Harinath on 2017/03/20

                            CommonObj.ER_Frames();
                            formObject.RaiseEvent("WFSave");
                        }
                    }
                    //Added by SandeepKn on 10Jan2020 for ASFI ans SFIC Changes - Start
                    //Added by Sivashankar KS on 05-Nov-2019 ServiceProvided loading from master starts here
//                    formObject.clear("ServiceProvider");
//                    formObject.setNGValue("ServiceProvider", "");
//                    String sQuery = "SELECT ServiceProvider FROM EXT_Mobile_ServiceProvider_Master WITH(NOLOCK) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "'";
//                    CommonObj.DBValues_Combo(sQuery, "ServiceProvider");
                    if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
                        //Added by Sivashankar KS on 05-Nov-2019 ServiceProvided loading from master starts here
                        formObject.clear("ServiceProvider");
                        formObject.setNGValue("ServiceProvider", "");
                        String sQuery = "SELECT ServiceProvider FROM EXT_Mobile_ServiceProvider_Master WITH(NOLOCK) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "'";
                        CommonObj.DBValues_Combo(sQuery, "ServiceProvider");
                        if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                            formObject.setLocked("ServiceTax_BillValue", false);
                            formObject.setLocked("ServiceTax_ValueOfPersonalCalls", false);
                            formObject.setEnabled("ServiceTax_BillValue", true);
                            formObject.setEnabled("ServiceTax_ValueOfPersonalCalls", true);
                            formObject.setNGBackColor("ServiceTax_BillValue", new Color(250, 250, 250));
                            formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(250, 250, 250));
                        } else {
                            formObject.setLocked("ServiceTax_BillValue", true);
                            formObject.setLocked("ServiceTax_ValueOfPersonalCalls", true);
                            formObject.setEnabled("ServiceTax_BillValue", false);
                            formObject.setEnabled("ServiceTax_ValueOfPersonalCalls", false);
                            formObject.setNGBackColor("ServiceTax_BillValue", new Color(225, 225, 225));
                            formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(225, 225, 225));
                        }
                    }

                    if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                        formObject.setVisible("btn_ghouse_check", false);
                        formObject.setVisible("lbl_paidto", true);
                        formObject.setVisible("ToBePaid", true);
                        formObject.clear("TypeOfTravel");
//            formObject.addItem("TypeOfTravel", "Domestic");
                        formObject.addItem("TypeOfTravel", "International - Business Travel");
                        formObject.addItem("TypeOfTravel", "International - Annual Leave travel");
//            formObject.setNGValue("TypeOfTravel", "Domestic");
                        formObject.clear("cb_trvl_paidby");
                        formObject.addItem("cb_trvl_paidby", "Self");
                        formObject.addItem("cb_trvl_paidby", "Company");//Added by SandeepKN on 04Dec2019 for Paidby changes Varalakshmie
                    } else {
                        formObject.setVisible("btn_ghouse_check", true);
                        formObject.setVisible("lbl_paidto", false);
                        formObject.setVisible("ToBePaid", false);
                        formObject.clear("TypeOfTravel");
                        formObject.addItem("TypeOfTravel", "Domestic");
                        formObject.addItem("TypeOfTravel", "International");
                        formObject.clear("cb_trvl_paidby");
                        formObject.addItem("cb_trvl_paidby", "Company");
                        formObject.addItem("cb_trvl_paidby", "Self");
                    }
                    if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                        formObject.clear("oe_drpdwn_location");
                        formObject.setNGValue("oe_drpdwn_location", "");
                        writeToLog(2, "formObject.getNGValue(\"CompanyCode\")  ::: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
                        CommonObj.DBValues_Combo("SELECT DISTINCT(Location) FROM EXT_FromLoc WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC", "oe_drpdwn_location");
                        formObject.clear("dp_hotelfare_location");
                        formObject.setNGValue("dp_hotelfare_location", "");
                        writeToLog(2, "formObject.getNGValue(\"CompanyCode\")  ::: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
                        CommonObj.DBValues_Combo("SELECT DISTINCT(Location) FROM EXT_FromLoc WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC", "dp_hotelfare_location");
                    }
                    //Added by Sivashankar KS on 05-Nov-2019 ServiceProvided loading from master ends here
                    //Added by SandeepKn on 10Jan2020 for ASFI ans SFIC Changes - End

                    //added by Deva on 25/12/2016
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_emp_detail")) {
                    String bapires = "";
                    formObject.setNGValue("CurrAppLevel", "");
                    formObject.setNGValue("MaxAppLevel", "");
                    formObject.setNGValue("App1index", "");
                    formObject.setNGValue("App2index", "");
                    formObject.setNGValue("App3index", "");
                    formObject.setNGValue("App4index", "");
                    formObject.setNGValue("App5index", "");
                    formObject.setNGValue("App6index", "");
                    formObject.setNGValue("App7index", "");
                    formObject.setNGValue("App8index", "");
                    String Sapuserid = "";
                    String Request = formObject.getNGValue("RequestFor");
                    if (Request.equalsIgnoreCase("Others")) {
                        Sapuserid = formObject.getNGValue("EmployeeCode");
                    } else {
                        Sapuserid = formObject.getUserName();
                    }

                    if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") || strTypeofinvoice.equalsIgnoreCase("Travel Expense") || strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
                        try {
                            CommonObj.writeToLog(2, "BAPI_EmployeeDetailsOnload calling", winame);
                            //objSAPFunc.BAPI_EmployeeDetailsOnload(formObject.getUserName());
                            bapires = objSAPFunc.BAPI_EmployeeDetailsOnload(Sapuserid);
                            CommonObj.ER_EligibleAmount();
                        } catch (Exception e) {
                            CommonObj.writeToLog(3, "Exception In BAPI_EmployeeDetailsOnload Click, ER_initiation=" + e.getMessage(), winame);
                        }

                        //Added By Harinatha R on 2017/09/20
                        if (bapires.equalsIgnoreCase("FAIL")) {
                            throw new ValidatorException(new FacesMessage("Please contact administrator.. Exception while fetching employee details", "TypeOfInvoice"));
                        } else if (!bapires.equalsIgnoreCase("") && !bapires.equalsIgnoreCase("SUCCESS")) {

                            throw new ValidatorException(new FacesMessage(bapires, "TypeOfInvoice"));
                        }
                        //Ended By Harinatha R on 2017/09/20

                    } else if (strTypeofinvoice.equalsIgnoreCase("Employee Advances") || strTypeofinvoice.equalsIgnoreCase("Relocation") || strTypeofinvoice.equalsIgnoreCase("Self Education Scheme")) {
                        //Modified By Harinath on 2017/03/20
                        try {

                            CommonObj.writeToLog(2, "BAPI_EmployeeDetailsOnloadHR calling", winame);
                            bapires = objSAPFunc.BAPI_EmployeeDetailsOnloadHR(formObject.getUserName());
                            CommonObj.ER_EligibleAmount();
                        } catch (Exception e) {
                            CommonObj.writeToLog(3, "Exception In BAPI_EmployeeDetailsOnloadHR Click, ER_initiation=" + e.getMessage(), winame);
                        }
                        //Ended By Harinath on 2017/03/20

                        //Added By Harinatha R on 2017/09/20
                        if (bapires.equalsIgnoreCase("FAIL")) {
                            throw new ValidatorException(new FacesMessage("Please contact administrator.. Exception while fetching employee details", "TypeOfInvoice"));
                        } else if (!bapires.equalsIgnoreCase("") && !bapires.equalsIgnoreCase("SUCCESS")) {

                            throw new ValidatorException(new FacesMessage(bapires, "TypeOfInvoice"));
                        }
                        //Ended By Harinatha R on 2017/09/20

                    } else {
                        throw new ValidatorException(new FacesMessage("Please select valid type of invoice", "TypeOfInvoice"));
                    }

                    if (bapires.equalsIgnoreCase("SUCCESS")) {
                        //Added By Harinath on 2017/03/20
                        if (strSubcategory.equalsIgnoreCase("House Rent Advance")) {
                            if (bapires.equalsIgnoreCase("Y")) {
                                throw new ValidatorException(new FacesMessage("User Can't apply for House Rent Advance", "SubCategory1"));
                            } else if (bapires.equalsIgnoreCase("NE")) {
                                throw new ValidatorException(new FacesMessage("User is not eligible for House Rent Advance", "SubCategory1"));
                            }
                        } else if (strSubcategory.equalsIgnoreCase("Salary Advance") && bapires.equalsIgnoreCase("Y")) {

                            throw new ValidatorException(new FacesMessage("User Can't apply for for Salary Advance", "SubCategory1"));
                        } else if (strSubcategory.equalsIgnoreCase("Exceptional Advances") && bapires.equalsIgnoreCase("Y")) {

                            throw new ValidatorException(new FacesMessage("User Can't apply for for Exceptional Advances", "SubCategory1"));

                        } else if (strSubcategory.equalsIgnoreCase("Imprest Cash")) {
                            String queryhouse = "SELECT Claimlimit FROM EXT_AP_ER_ClaimLimit with(nolock) WHERE Grade='" + Grade1 + "' and Subcategory1='" + strSubcategory + "'";
                            String[] FieldValue_array = CommonObj.DB_QueryExecute(queryhouse);
                            String claimval = FieldValue_array[0];
                            AP_CommonFunctions.writeToLog(2, "Imprest Cash:", winame);
                            CommonObj.writeToLog(2, "claimval ::: " + claimval, winame);
                            if (claimval.equalsIgnoreCase("0.00")) {
                                throw new ValidatorException(new FacesMessage("Not Eligible for claim", "SubCategory1"));
                            }
                        } else {

                            CommonObj.ER_EligibleAmount();
                            formObject.setNGValue("FiscalYr", CommonObj.Cur_FinanicalYr());

                            CommonObj.ER_Frames();
                            formObject.RaiseEvent("WFSave");
                        }

                    }
                    //Added by SandeepKN on 10Jan2020 for ASFI and SFIC changes -- Start
                    if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
                        //Added by Sivashankar KS on 05-Nov-2019 ServiceProvided loading from master starts here
                        formObject.clear("ServiceProvider");
                        formObject.setNGValue("ServiceProvider", "");
                        String sQuery = "SELECT ServiceProvider FROM EXT_Mobile_ServiceProvider_Master WITH(NOLOCK) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "'";
                        CommonObj.DBValues_Combo(sQuery, "ServiceProvider");
                        if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                            formObject.setLocked("ServiceTax_BillValue", false);
                            formObject.setLocked("ServiceTax_ValueOfPersonalCalls", false);
                            formObject.setEnabled("ServiceTax_BillValue", true);
                            formObject.setEnabled("ServiceTax_ValueOfPersonalCalls", true);
                            formObject.setNGBackColor("ServiceTax_BillValue", new Color(250, 250, 250));
                            formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(250, 250, 250));
                        } else {
                            formObject.setLocked("ServiceTax_BillValue", true);
                            formObject.setLocked("ServiceTax_ValueOfPersonalCalls", true);
                            formObject.setEnabled("ServiceTax_BillValue", false);
                            formObject.setEnabled("ServiceTax_ValueOfPersonalCalls", false);
                            formObject.setNGBackColor("ServiceTax_BillValue", new Color(225, 225, 225));
                            formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(225, 225, 225));
                        }
                    }

                    if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                        formObject.setVisible("btn_ghouse_check", false);
                        formObject.setVisible("lbl_paidto", true);
                        formObject.setVisible("ToBePaid", true);
                        formObject.clear("TypeOfTravel");
//            formObject.addItem("TypeOfTravel", "Domestic");
                        formObject.addItem("TypeOfTravel", "International - Business Travel");
                        formObject.addItem("TypeOfTravel", "International - Annual Leave travel");
//            formObject.setNGValue("TypeOfTravel", "Domestic");
                        formObject.clear("cb_trvl_paidby");
                        formObject.addItem("cb_trvl_paidby", "Self");
                        formObject.addItem("cb_trvl_paidby", "Company");// Added by SandeepKN on 04Dec2019 for Paidby Changes
                    } else {
                        formObject.setVisible("btn_ghouse_check", true);
                        formObject.setVisible("lbl_paidto", false);
                        formObject.setVisible("ToBePaid", false);
                        formObject.clear("TypeOfTravel");
                        formObject.addItem("TypeOfTravel", "Domestic");
                        formObject.addItem("TypeOfTravel", "International");
                        formObject.clear("cb_trvl_paidby");
                        formObject.addItem("cb_trvl_paidby", "Company");
                        formObject.addItem("cb_trvl_paidby", "Self");
                    }
                    //Added by Sivashankar KS on 05-Nov-2019 ServiceProvided loading from master ends here                    
                    //Added by SandeepKN on 10Jan2020 for ASFI and SFIC changes -- END

                    //Ended By Harinath on 2017/03/20
                    //Added the below lines for HANA Project change the Cost Center on 13-Nov-2019 starts
                    if (formObject.getNGValue("EmployeeCode").equalsIgnoreCase("1003404")) {
                        if (!formObject.getNGValue("RequestFor").equalsIgnoreCase("Self")) {
                            formObject.setNGValue("CostCenter", "PSNBILHANA");
                        } else {
                            formObject.setNGValue("CostCenter", "DYEOITISDN");
                        }
                    }
                    //Added the below lines for HANA Project change the Cost Center on 13-Nov-2019 
                    //Added by SandeepKN on 10Jan2020 for ASFI and SFIC changes -- Start
                    if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                        writeToLog(2, "formObject.getNGValue(\"CompanyCode\")  ::: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
                        CommonObj.DBValues_Combo("SELECT DISTINCT(Location) FROM EXT_FromLoc WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC", "oe_drpdwn_location");
                        formObject.clear("oe_drpdwn_location");
                        formObject.setNGValue("oe_drpdwn_location", "");
                        writeToLog(2, "formObject.getNGValue(\"CompanyCode\")  ::: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
                        CommonObj.DBValues_Combo("SELECT DISTINCT(Location) FROM EXT_FromLoc WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC", "oe_drpdwn_location");
                        formObject.clear("dp_hotelfare_location");
                        formObject.setNGValue("dp_hotelfare_location", "");
                        writeToLog(2, "formObject.getNGValue(\"CompanyCode\")  ::: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
                        CommonObj.DBValues_Combo("SELECT DISTINCT(Location) FROM EXT_FromLoc WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC", "dp_hotelfare_location");
                    }//Added by SandeepKN on 10Jan2020 for ASFI and SFIC changes -- END

                } //Commented By Harinath on 2017/03/27
                /*
                 else if (pEvent.getSource().getName().equalsIgnoreCase("btn_trvl_class")) {
                 //System.out.println("Inside TOLocation load");
                 if ((formObject.getNGValue("cb_trvl_mode") == "") || (formObject.getNGValue("cb_trvl_mode") == "--Select--")) {
                 throw new ValidatorException(new FacesMessage("Please Select Travel Mode", "cb_trvl_mode"));
                 } else {
                 formObject.clear("cb_trvl_class");
                 formObject.setNGValue("cb_trvl_class", "");
                 String mode = formObject.getNGValue("cb_trvl_mode");
                 CommonObj.writeToLog(2, "Inside TOLocation load", winame);
                 String queryMode = "SELECT class FROM EXT_AP_ER_TravelClass WITH (NOLOCK) WHERE mode='" + mode + "'";
                 CommonObj.writeToLog(2, "queryloc--------------" + queryMode, winame);
                 //System.out.println("queryloc--------------" + sQuery);
                 PickList objPickList1 = formObject.getNGPickList("btn_trvl_class", "Class", true, 20, false);
                 objPickList1.setVisible(true);
                 objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                 objPickList1.setWidth(350);
                 objPickList1.setWidth(350);
                 objPickList1.populateData(queryMode);
                 }
                 } // Added newly on 24/12/2016
                 */ //Ended By Harinath on 2017/03/27
                //Commented By Harinath on 2017/03/27
                /*
                 else if (pEvent.getSource().getName().equalsIgnoreCase("btn_sub")) {
                 String strTypeOfInvoive = formObject.getNGValue("TypeOfInvoice");
                 formObject.clear("SubCategory1");
                 formObject.setNGValue("SubCategory1", "");
                 String querySubCat = "select SubCat1 from EXT_AP_ER_InvoiceSub with(nolock) where TYPEOFINV='" + strTypeOfInvoive + "' and Process='ER' and SubCat1 IS NOT NULL and SubCat1 !=''";
                 //CommonObj.DBValues_Combo(querySubCat, "SubCategory1"); 
                 PickList objPickList1 = formObject.getNGPickList("btn_sub", "Sub Category1", true, 20, false);
                 objPickList1.setVisible(true);
                 objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                 objPickList1.setWidth(350);
                 objPickList1.setWidth(350);
                 objPickList1.populateData(querySubCat);
                 }
               
                 else if (pEvent.getSource().getName().equalsIgnoreCase("btn_fromloc")) 
                 {
                 formObject.setNGValue("txt_trvl_toloc","");
                 CommonObj.writeToLog(2,"Inside FromLocation load",winame); 
                 //System.out.println("Inside FromLocation load");
                 String sQuery = "SELECT location FROM EXT_FromLoc with(nolock)";
                 CommonObj.writeToLog(2,"queryloc--------------" + sQuery,winame); 
                 //System.out.println("queryloc--------------" + sQuery);
                 PickList objPickList1 = formObject.getNGPickList("btn_fromloc", "FromLocation", true, 20, false);
                 objPickList1.setVisible(true);
                 objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                 objPickList1.setWidth(350);
                 objPickList1.setWidth(350);
                 objPickList1.populateData(sQuery);
                 } 
                 */ //Ended By Harinath on 2017/03/27
                //Commented By Harinath on 2017/03/27
                /*
                 else if (pEvent.getSource().getName().equalsIgnoreCase("btn_toloc")) {
                 //System.out.println("Inside TOLocation load");
                 //                 if(formObject.getNGValue("txt_trvl_fromloc")==""){
                 //                 throw new ValidatorException(new FacesMessage("Please Select From Location","txt_trvl_fromloc"));   
                 //                 }else{
                 CommonObj.writeToLog(2,"Inside TOLocation load",winame); 
                 //String sQuery = "SELECT location FROM EXT_FromLoc where location!='"+formObject.getNGValue("txt_trvl_fromloc")+"'";
                 String sQuery = "SELECT location FROM EXT_FromLoc with(nolock) where location!='"+formObject.getNGValue("txt_trvl_fromloc")+"'";
                 CommonObj.writeToLog(2,"queryloc--------------" + sQuery,winame); 
                 //System.out.println("queryloc--------------" + sQuery);
                 PickList objPickList1 = formObject.getNGPickList("btn_toloc", "To Location", true, 20, false);
                 objPickList1.setVisible(true);
                 objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                 objPickList1.setWidth(350);
                 objPickList1.setWidth(350);
                 objPickList1.populateData(sQuery);
                 //}
                 }
                 */ //Ended By Harinath on 2017/03/27
                //String strSubcategory = formObject.getNGValue("SubCategory1");
                else if (pEvent.getSource().getName().equalsIgnoreCase("btn_add_ent")) {
                    CommonObj.writeToLog(2, "Entertainment Add Button", winame);
                    //CommonObj.addRow(formObject, "list_Entertain");
                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_entschm_billdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
//                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_entschm_billdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } else {
                        //Added By Ashwin on 2019/01/10
                        String ddate = "";
                        ddate = formObject.getNGValue("dp_entschm_billdate");

                        String qryDuplicateent1 = "";
                        qryDuplicateent1 = "Select Count(ITEMINDEX) from EXT_Entertainment,ext_ap with(nolock) where EXT_Entertainment.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Entertainment.BillNumber='" + formObject.getNGValue("txt_entschm_billno") + "' and "
                                + "EXT_Entertainment.BillDate=CONVERT(date,'" + formObject.getNGValue("dp_entschm_billdate") + "',103) and  EXT_Entertainment.Amount=" + formObject.getNGValue("txt_entschm_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y')";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number,Date and Amount", "txt_entschm_billno"));

                        }
                        //Ended By Ashwin on 2019/01/10
                        CommonObj.addRow(formObject, "list_Entertain");
                    }
                    //Ended by Harinatha on 2017/10/26
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_mod_ent")) {
                    CommonObj.writeToLog(2, "Entertainment modify Button", winame);
                    //CommonObj.modifyRow(formObject, "list_Entertain");

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_entschm_billdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_entschm_billdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } else {
                        //CommonObj.addRow(formObject, "list_Entertain"); Commented by Sivashankar KS on 20-09-2018
                        //Added By Ashwin on 2019/01/10
                        String ddate = "";
                        ddate = formObject.getNGValue("dp_entschm_billdate");

                        String qryDuplicateent1 = "";
                        qryDuplicateent1 = "Select Count(ITEMINDEX) from EXT_Entertainment,ext_ap with(nolock) where EXT_Entertainment.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Entertainment.BillNumber='" + formObject.getNGValue("txt_entschm_billno") + "' and "
                                + "EXT_Entertainment.BillDate=CONVERT(date,'" + formObject.getNGValue("dp_entschm_billdate") + "',103) and  EXT_Entertainment.Amount=" + formObject.getNGValue("txt_entschm_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number,Date and Amount", "txt_entschm_billno"));

                        }
                        //Ended By Ashwin on 2019/01/10
                        CommonObj.modifyRow(formObject, "list_Entertain"); //Modified by Sivashankar KS on 20-09-2018
                    }
                    //Ended by Harinatha on 2017/10/26

                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_del_ent")) {
                    CommonObj.writeToLog(2, "Entertainment delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_Entertain");
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_add_trvl")) {

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_trvl_trvl"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    writeToLog(2, "diiffdays ::::  " + diiffdays + "   strApprvl :: " + strApprvl, winame);
                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_trvl_trvl");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Travel date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Travel date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Travel date can not be more than 90 days...", ""));
                    } //Ended by Harinatha on 2017/10/26
                    //Added By Sivashankar KS on 05-April-2019
                    else {

                        //Modified By Harinath on 2017/05/22
                        int rowCount = formObject.getLVWRowCount("list_travel");
                        if (!formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others") && !formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                            for (int i = 0; i < rowCount; i++) {
                                if (formObject.getNGValue("list_travel", i, 0).equalsIgnoreCase(formObject.getNGValue("txt_trvl_fromloc")) && formObject.getNGValue("list_travel", i, 1).equalsIgnoreCase(formObject.getNGValue("txt_trvl_toloc"))
                                        && formObject.getNGValue("list_travel", i, 2).equalsIgnoreCase(formObject.getNGValue("dp_trvl_trvl"))) {
                                    throw new ValidatorException(new FacesMessage("There is already a details of entered From Location : " + formObject.getNGValue("txt_trvl_fromloc") + " To Location : " + formObject.getNGValue("txt_trvl_toloc") + "  Travel Date : " + formObject.getNGValue("dp_trvl_trvl") + " in travel details template.", ""));
                                }
                            }
                        }
                        //Ended By Harinath on 2017/05/22

                        //Added By Harinath on 2017/05/02
                        if (formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others")) {
                            CommonObj.mandatoryCheck(formObject, "txt_trvl_OthFrom", "Please enter From location");
                        }
                        if (formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                            CommonObj.mandatoryCheck(formObject, "txt_trvl_OthTo", "Please enter To location");
                        }
                        //Ended By Harinath on 2017/05/02
                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";

                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_TravelFare1 with(nolock),EXT_AP with(nolock) where EXT_TravelFare1.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_TravelFare1.DateofTra=convert(datetime,'" + formObject.getNGValue("dp_trvl_trvl") + "',103) and "
                                + "EXT_TravelFare1.FromLoc= '" + formObject.getNGValue("txt_trvl_fromloc") + "' and EXT_TravelFare1.ToLoc= '" + formObject.getNGValue("txt_trvl_toloc") + "' and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        CommonObj.writeToLog(2, "EmployeeCode" + formObject.getNGValue("EmployeeCode"), winame);
                        //Added by Sivashankar KS on 11-Nov-2019 for HANA implementation purpose
                        if (!formObject.getNGValue("EmployeeCode").equalsIgnoreCase("1003404")) {
                            if (dupCOUNT2 >= 1) {
                                CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                                CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                                throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination:  From Location, To Location and Date of Travel", "dp_trvl_trvl"));

                            }
                        }

                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            // If condition added by sandeepKn on 8Jan2020 to remove Ticket number validation at Rework for typeofinvoive=Travelrequest
                            if (!(formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Travel Request")
                                    && formObject.getNGValue("SubCategory1").equalsIgnoreCase("Travel Request")
                                    && formObject.getNGValue("ApprSts1").equalsIgnoreCase("Approved"))) {
                                CommonObj.writeToLog(2, "Rework Validation start at modfiy", winame);

                                if (formObject.getNGValue("txt_trvl_tcktno").equalsIgnoreCase("")) {
                                    throw new ValidatorException(new FacesMessage("Please enter the ticket number", "txt_trvl_tcktno"));
                                } else if (formObject.getNGValue("txt_trvl_amnt").equalsIgnoreCase("")) {
                                    throw new ValidatorException(new FacesMessage("Please enter the amount.", "txt_trvl_amnt"));
                                } else {
                                    qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_TravelFare1 with(nolock),ext_ap with(nolock) where EXT_TravelFare1.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_TravelFare1.TcktNo='" + formObject.getNGValue("txt_trvl_tcktno") + "' and "
                                            + "EXT_TravelFare1.Amount=" + formObject.getNGValue("txt_trvl_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                                    CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                                    int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                                    CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                                    if (dupCOUNT1 >= 1) {
                                        CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                                        throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Ticket Number and Amount", "txt_trvl_tcktno"));

                                    }
                                }
                            }
                        }
                        /*
                         String strWorkId = "";

                         strWorkId = CommonObj.SelectQuery("select WorkId from EXT_TravelFare1 with(nolock),EXT_AP with(nolock) where EXT_TravelFare1.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_hotelfare_checkindt") + "',103) between convert(varchar(10),EXT_TravelFare1.CheckInDate,126) and convert(varchar(10),EXT_TravelFare1.CheckoutDate,126) and WorkId !='" + winame + "'");
                         if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                         throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_hotelfare_checkindt") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_hotelfare_checkindt"));
                         }

                         strWorkId = CommonObj.SelectQuery("select WorkId from EXT_TravelFare1 with(nolock),EXT_AP with(nolock) where EXT_TravelFare1.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_hotelfare_checkoutdt") + "',103) between convert(varchar(10),EXT_TravelFare1.CheckInDate,126) and convert(varchar(10),EXT_TravelFare1.CheckoutDate,126) and WorkId !='" + winame + "'");
                         if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                         throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_hotelfare_checkoutdt") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_hotelfare_checkoutdt"));
                         }
                         */
                        CommonObj.writeToLog(2, "Travel Add Button", winame);
                        CommonObj.addRow(formObject, "list_travel");
                        CommonObj.getDateFromList_TravelOld(formObject, winame);
                        float trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_travel", 9, 8);
                        formObject.setNGValue("TicketExpense", trvlsum);
                        formObject.setNGValue("TotalAmount", "");
                    }
                    //Ended By Sivashankar KS on 05-April-2019 

//Old code commented by Sivashankar KS on 5th April 2019.
                    /*
                     //Modified By Harinath on 2017/05/22
                     int rowCount = formObject.getLVWRowCount("list_travel");
                     if (!formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others") && !formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                     for (int i = 0; i < rowCount; i++) {
                     if (formObject.getNGValue("list_travel", i, 0).equalsIgnoreCase(formObject.getNGValue("txt_trvl_fromloc")) && formObject.getNGValue("list_travel", i, 1).equalsIgnoreCase(formObject.getNGValue("txt_trvl_toloc"))
                     && formObject.getNGValue("list_travel", i, 2).equalsIgnoreCase(formObject.getNGValue("dp_trvl_trvl"))) {
                     throw new ValidatorException(new FacesMessage("There is already a details of entered From Location : " + formObject.getNGValue("txt_trvl_fromloc") + " To Location : " + formObject.getNGValue("txt_trvl_toloc") + "  Travel Date : " + formObject.getNGValue("dp_trvl_trvl") + " in travel details template.", ""));
                     }
                     }
                     }
                     //Ended By Harinath on 2017/05/22

                     //Added By Harinath on 2017/05/02
                     if (formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others")) {
                     CommonObj.mandatoryCheck(formObject, "txt_trvl_OthFrom", "Please enter From location");
                     }
                     if (formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                     CommonObj.mandatoryCheck(formObject, "txt_trvl_OthTo", "Please enter To location");
                     }
                     //Ended By Harinath on 2017/05/02

                     // System.out.println("Travel Add Button");
                     CommonObj.writeToLog(2, "Travel Add Button", winame);
                     CommonObj.addRow(formObject, "list_travel");
                     CommonObj.getDateFromList_TravelOld(formObject, winame);//added by Sivashankar KS on 23-Oct-2018 for disabling the other than travel date in DA & Hotel fares template
                     float trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_travel", 9, 8);
                     formObject.setNGValue("TicketExpense", trvlsum);
                     formObject.setNGValue("TotalAmount", "");*/
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_mod_trvl")) {
                    //System.out.println("Travel modify Button");

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_trvl_trvl"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_trvl_trvl");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Travel date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Travel date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Travel date can not be more than 90 days...", ""));
                    } //Ended by Harinatha on 2017/10/26
                    //Added By Sivashankar KS on 05-April-2019
                    else {

                        //Modified By Harinath on 2017/05/22
                        int dupRowC = 0;
                        int rowCount = formObject.getLVWRowCount("list_travel");
                        if (!formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others") && !formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                            for (int i = 0; i < rowCount; i++) {
                                if (formObject.getNGValue("list_travel", i, 0).equalsIgnoreCase(formObject.getNGValue("txt_trvl_fromloc")) && formObject.getNGValue("list_travel", i, 1).equalsIgnoreCase(formObject.getNGValue("txt_trvl_toloc"))
                                        && formObject.getNGValue("list_travel", i, 2).equalsIgnoreCase(formObject.getNGValue("dp_trvl_trvl"))) {
                                    dupRowC = dupRowC + 1;
                                    if (dupRowC >= 2) {
                                        throw new ValidatorException(new FacesMessage("There is already a details of entered From Location : " + formObject.getNGValue("txt_trvl_fromloc") + " To Location : " + formObject.getNGValue("txt_trvl_toloc") + "  Travel Date : " + formObject.getNGValue("dp_trvl_trvl") + " in travel details template.", ""));
                                    }
                                }
                            }
                        }
                        //Ended By Harinath on 2017/05/22

                        //Added By Harinath on 2017/05/02
                        if (formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others")) {
                            CommonObj.mandatoryCheck(formObject, "txt_trvl_OthFrom", "Please enter From location");
                        }
                        if (formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                            CommonObj.mandatoryCheck(formObject, "txt_trvl_OthTo", "Please enter To location");
                        }

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";

                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_TravelFare1 with(nolock),EXT_AP with(nolock) where EXT_TravelFare1.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_TravelFare1.DateofTra=convert(datetime,'" + formObject.getNGValue("dp_trvl_trvl") + "',103) and "
                                + "EXT_TravelFare1.FromLoc= '" + formObject.getNGValue("txt_trvl_fromloc") + "' and EXT_TravelFare1.ToLoc= '" + formObject.getNGValue("txt_trvl_toloc") + "' and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);
                        CommonObj.writeToLog(2, "EmployeeCode" + formObject.getNGValue("EmployeeCode"), winame);
                        //Added by Sivashankar KS on 11-Nov-2019 for HANA implementation purpose
                        if (!formObject.getNGValue("EmployeeCode").equalsIgnoreCase("1003404")) {
                            if (dupCOUNT2 >= 1) {
                                CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                                CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                                throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination:  From Location, To Location and Date of Travel", "dp_trvl_trvl"));

                            }
                        }

                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            // If condition added by sandeepKn on 8Jan2020 to remove Ticket number validation at Rework for typeofinvoive=Travelrequest
                            if (!(formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Travel Request")
                                    && formObject.getNGValue("SubCategory1").equalsIgnoreCase("Travel Request")
                                    && formObject.getNGValue("ApprSts1").equalsIgnoreCase("Approved"))) {
                                CommonObj.writeToLog(2, "Rework Validation start at modfiy", winame);

                                if (formObject.getNGValue("txt_trvl_tcktno").equalsIgnoreCase("")) {
                                    throw new ValidatorException(new FacesMessage("Please enter the ticket number", "txt_trvl_tcktno"));
                                } else if (formObject.getNGValue("txt_trvl_amnt").equalsIgnoreCase("")) {
                                    throw new ValidatorException(new FacesMessage("Please enter the amount.", "txt_trvl_amnt"));
                                } else {
                                    qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_TravelFare1 with(nolock),ext_ap with(nolock) where EXT_TravelFare1.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_TravelFare1.TcktNo='" + formObject.getNGValue("txt_trvl_tcktno") + "' and "
                                            + "EXT_TravelFare1.Amount=" + formObject.getNGValue("txt_trvl_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                                    CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                                    int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                                    CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                                    if (dupCOUNT1 >= 1) {
                                        CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                                        throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Ticket Number and Amount", "txt_trvl_tcktno"));

                                    }
                                }
                            }
                        }
                        /*
                         String strWorkId = "";

                         strWorkId = CommonObj.SelectQuery("select WorkId from EXT_TravelFare1 with(nolock),EXT_AP with(nolock) where EXT_TravelFare1.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_hotelfare_checkindt") + "',103) between convert(varchar(10),EXT_TravelFare1.CheckInDate,126) and convert(varchar(10),EXT_TravelFare1.CheckoutDate,126) and WorkId !='" + winame + "'");
                         if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                         throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_hotelfare_checkindt") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_hotelfare_checkindt"));
                         }

                         strWorkId = CommonObj.SelectQuery("select WorkId from EXT_TravelFare1 with(nolock),EXT_AP with(nolock) where EXT_TravelFare1.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_hotelfare_checkoutdt") + "',103) between convert(varchar(10),EXT_TravelFare1.CheckInDate,126) and convert(varchar(10),EXT_TravelFare1.CheckoutDate,126) and WorkId !='" + winame + "'");
                         if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                         throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_hotelfare_checkoutdt") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_hotelfare_checkoutdt"));
                         }
                         */
                        CommonObj.writeToLog(2, "Travel modify Button", winame);
                        CommonObj.modifyRow(formObject, "list_travel");
                        CommonObj.getDateFromList_TravelOld(formObject, winame);
                        float trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_travel", 9, 8);
                        formObject.setNGValue("TicketExpense", trvlsum);
                        formObject.setNGValue("TotalAmount", "");
                    }
                    //Ended By Sivashankar KS on 05-April-2019  

// Commented by Sivashankar KS on 5th April 2019
                    /*
                     //Modified By Harinath on 2017/05/22
                     int dupRowC = 0;
                     int rowCount = formObject.getLVWRowCount("list_travel");
                     if (!formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others") && !formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                     for (int i = 0; i < rowCount; i++) {
                     if (formObject.getNGValue("list_travel", i, 0).equalsIgnoreCase(formObject.getNGValue("txt_trvl_fromloc")) && formObject.getNGValue("list_travel", i, 1).equalsIgnoreCase(formObject.getNGValue("txt_trvl_toloc"))
                     && formObject.getNGValue("list_travel", i, 2).equalsIgnoreCase(formObject.getNGValue("dp_trvl_trvl"))) {
                     dupRowC = dupRowC + 1;
                     if (dupRowC >= 2) {
                     throw new ValidatorException(new FacesMessage("There is already a details of entered From Location : " + formObject.getNGValue("txt_trvl_fromloc") + " To Location : " + formObject.getNGValue("txt_trvl_toloc") + "  Travel Date : " + formObject.getNGValue("dp_trvl_trvl") + " in travel details template.", ""));
                     }
                     }
                     }
                     }
                     //Ended By Harinath on 2017/05/22

                     //Added By Harinath on 2017/05/02
                     if (formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others")) {
                     CommonObj.mandatoryCheck(formObject, "txt_trvl_OthFrom", "Please enter From location");
                     }
                     if (formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                     CommonObj.mandatoryCheck(formObject, "txt_trvl_OthTo", "Please enter To location");
                     }
                     //Ended By Harinath on 2017/05/02

                     CommonObj.writeToLog(2, "Travel modify Button", winame);
                     CommonObj.modifyRow(formObject, "list_travel");
                     CommonObj.getDateFromList_TravelOld(formObject, winame);//added by Sivashankar KS on 23-Oct-2018 for disabling the other than travel date in DA & Hotel fares template
                     float trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_travel", 9, 8);
                     formObject.setNGValue("TicketExpense", trvlsum);
                     formObject.setNGValue("TotalAmount", "");*/
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_del_trvl")) {
                    //System.out.println("Travel delete Button");
                    CommonObj.writeToLog(2, "Travel delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_travel");
                    CommonObj.getDateFromList_TravelOld(formObject, winame);////added by Sivashankar KS on 23-Oct-2018 for disabling the other than travel date in DA & Hotel fares template
                    float trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_travel", 9, 8);
                    formObject.setNGValue("TicketExpense", trvlsum);
                    formObject.setNGValue("TotalAmount", "");
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_add_fmly")) {
                    //System.out.println("Family Add Button");
                    CommonObj.writeToLog(2, "Family Add Button", winame);
                    CommonObj.addRow(formObject, "list_family");
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_mod_fmly")) {
                    // System.out.println("Family Modify Button");
                    CommonObj.writeToLog(2, "Family Modify Button", winame);
                    CommonObj.modifyRow(formObject, "list_family");
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_del_fmly")) {
                    //System.out.println(" Familydelete Button");
                    CommonObj.writeToLog(2, "Familydelete Button", winame);
                    CommonObj.deleteRow(formObject, "list_family");
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_add_htl")) {

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_hotelfare_checkindt"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_hotelfare_checkindt");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } //Ended by Harinatha on 2017/10/26
                    //Added By Sivashankar KS on 05-April-2019
                    else {
                        if (!Grade1.equalsIgnoreCase("Fld Sales Off Gr III") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr II") && !Grade1.equalsIgnoreCase("Executive")
                                && !Grade1.equalsIgnoreCase("Officer Grade II") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr I") && !Grade1.equalsIgnoreCase("Territory Sales IC")
                                && !Grade1.equalsIgnoreCase("Officer Grade IV") && !Grade1.equalsIgnoreCase("Selection Grade") && !Grade1.equalsIgnoreCase("Officer Grade I")
                                && !Grade1.equalsIgnoreCase("Officer Grade III") && !Grade1.equalsIgnoreCase("Executive-Sales") && !Grade1.equalsIgnoreCase("Assistant Manager")
                                && !Grade1.equalsIgnoreCase("Asst. Manager-Sales")) {//Modified by Sivashankar KS on 24-Oct-2018 for allowing DA and Hotel Fares for Asst. Manager-Sales as per the mail from sivaram

                            int rowCount1 = formObject.getLVWRowCount("list_daily");
                            for (int i = 0; i < rowCount1; i++) {
                                try {
                                    startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                                    endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                                    inputDate = sdf.parse(formObject.getNGValue("dp_hotelfare_checkindt"));
                                } catch (ParseException ex) {
                                    Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                                }

                                if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkindt")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkindt"))
                                        || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                                    throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_hotelfare_checkindt") + " is added in Daily Allowance bills, Please select other date", ""));
                                }

                            }
                            for (int i = 0; i < rowCount1; i++) {
                                try {
                                    startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                                    endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                                    inputDate = sdf.parse(formObject.getNGValue("dp_hotelfare_checkoutdt"));
                                } catch (ParseException ex) {
                                    Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                                }

                                if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkoutdt")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkoutdt"))
                                        || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                                    throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_hotelfare_checkoutdt") + " is added in Daily Allowance bills, Please select other date", ""));
                                }
                            }
                        }

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";
                        qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_HotelFare with(nolock),ext_ap with(nolock) where EXT_HotelFare.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_HotelFare.BillNo='" + formObject.getNGValue("HF_BillNo") + "' and "
                                + "EXT_HotelFare.Amount=" + formObject.getNGValue("txt_hotelfare_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number and Amount", "HF_BillNo"));

                        }
                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_HotelFare with(nolock),EXT_AP with(nolock) where EXT_HotelFare.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_HotelFare.CheckInDate=convert(datetime,'" + formObject.getNGValue("dp_hotelfare_checkindt") + "',103) and "
                                + "EXT_HotelFare.CheckoutDate= convert(datetime,'" + formObject.getNGValue("dp_hotelfare_checkoutdt") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        if (dupCOUNT2 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination:  CheckIn Date and CheckOut Date", "HF_BillNo"));

                        }
                        String strWorkId = "";

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_HotelFare with(nolock),EXT_AP with(nolock) where EXT_HotelFare.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_hotelfare_checkindt") + "',103) between convert(varchar(10),EXT_HotelFare.CheckInDate,126) and convert(varchar(10),EXT_HotelFare.CheckoutDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_hotelfare_checkindt") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_hotelfare_checkindt"));
                        }

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_HotelFare with(nolock),EXT_AP with(nolock) where EXT_HotelFare.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_hotelfare_checkoutdt") + "',103) between convert(varchar(10),EXT_HotelFare.CheckInDate,126) and convert(varchar(10),EXT_HotelFare.CheckoutDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_hotelfare_checkoutdt") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_hotelfare_checkoutdt"));
                        }
                        //Added By IBPS Support for Hotel Name Mandatory
//                        if (formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Travel Expense")
//                                && formObject.getNGValue("SubCategory1").equalsIgnoreCase("Travel Expense")) {
//                            CommonObj.writeToLog(2, "Before Hotel Name Mandatory call..", winame);
//                            if (formObject.getNGValue("txt_hotelfare_hotelname").equalsIgnoreCase("")) {
//                                CommonObj.writeToLog(2, "In IF After Hotel Name Mandatory..", winame);
//                                throw new ValidatorException(new FacesMessage("Hotel Name is Mandatory", ""));
//                            }
//                        }
                        //End of Added By IBPS Support for Hotel Name Mandatory
                        float trvlsum = 0.f;
                        CommonObj.writeToLog(2, "Hotel Add Button", winame);
                        CommonObj.addRow(formObject, "list_hotel");
                        //trvlsum = (float) CommonObj.listViewColumnSum("list_hotel", 3);
                        trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_hotel", 15, 2);//Modified by Sivashanakr KS on 15 July 2019
                        formObject.setNGValue("HotelExpense", trvlsum);
                        formObject.setNGValue("TotalAmount", "");
                    }
                    //Ended By Sivashankar KS on 05-April-2019
                    // Commented by Sivashankar KS on 5th April 2019
/*
                     //Modified by Harinath on 2017/05/25
                     if (!Grade1.equalsIgnoreCase("Fld Sales Off Gr III") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr II") && !Grade1.equalsIgnoreCase("Executive")
                     && !Grade1.equalsIgnoreCase("Officer Grade II") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr I") && !Grade1.equalsIgnoreCase("Territory Sales IC")
                     && !Grade1.equalsIgnoreCase("Officer Grade IV") && !Grade1.equalsIgnoreCase("Selection Grade") && !Grade1.equalsIgnoreCase("Officer Grade I")
                     && !Grade1.equalsIgnoreCase("Officer Grade III") && !Grade1.equalsIgnoreCase("Executive-Sales") && !Grade1.equalsIgnoreCase("Assistant Manager")
                     && !Grade1.equalsIgnoreCase("Asst. Manager-Sales")) {//Modified by Sivashankar KS on 24-Oct-2018 for allowing DA and Hotel Fares for Asst. Manager-Sales as per the mail from sivaram

                     int rowCount1 = formObject.getLVWRowCount("list_daily");
                     for (int i = 0; i < rowCount1; i++) {
                     try {
                     startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                     endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                     inputDate = sdf.parse(formObject.getNGValue("dp_hotelfare_checkindt"));
                     } catch (ParseException ex) {
                     Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                     }

                     if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkindt")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkindt"))
                     || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                     throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_hotelfare_checkindt") + " is added in Daily Allowance bills, Please select other date", ""));
                     }

                     }
                     for (int i = 0; i < rowCount1; i++) {
                     try {
                     startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                     endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                     inputDate = sdf.parse(formObject.getNGValue("dp_hotelfare_checkoutdt"));
                     } catch (ParseException ex) {
                     Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                     }

                     if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkoutdt")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkoutdt"))
                     || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                     throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_hotelfare_checkoutdt") + " is added in Daily Allowance bills, Please select other date", ""));
                     }
                     }
                     }*/
                    //Ended by Harinath on 2017/05/25

                    //Modified by Harinath on 2017/03/20
                    /*
                     if ((strSubcategory.equalsIgnoreCase("Look and See Visit"))
                     || (strSubcategory.equalsIgnoreCase("Travel Expense"))) 
                     {
                     int Daily1 = formObject.getItemCount("list_daily");
                     if (Daily1 != 0)
                     {
                     throw new ValidatorException(new FacesMessage("Hotel fare is not allowed. ", "list_hotel"));
                     } 
                     else 
                     {
                     float trvlsum = 0.f;
                     CommonObj.writeToLog(2, "Hotel Add Add Button", winame);
                     CommonObj.addRow(formObject, "list_hotel");
                     //trvlsum = (float) CommonObj.listViewColumnSum("list_hotel", 3);
                     trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_hotel", 3, 2);                            
                     formObject.setNGValue("HotelExpense", trvlsum);
                     formObject.setNGValue("TotalAmount", "");
                     }
                     }
                     else
                     {
                     */
                    //Ended by Harinath on 2017/03/20
                    /*  float trvlsum = 0.f;
                     // System.out.println("Hotel Add Button");
                     CommonObj.writeToLog(2, "Hotel Add Button", winame);
                     CommonObj.addRow(formObject, "list_hotel");
                     //trvlsum = (float) CommonObj.listViewColumnSum("list_hotel", 3);
                     trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_hotel", 3, 2);
                     formObject.setNGValue("HotelExpense", trvlsum);
                     formObject.setNGValue("TotalAmount", "");*/
                    // }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_mod_htl")) {

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_hotelfare_checkindt"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_hotelfare_checkindt");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } //Ended by Harinatha on 2017/10/26
                    //Added By Sivashankar KS on 03-April-2019
                    else {
                        if (!Grade1.equalsIgnoreCase("Fld Sales Off Gr III") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr II") && !Grade1.equalsIgnoreCase("Executive")
                                && !Grade1.equalsIgnoreCase("Officer Grade II") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr I") && !Grade1.equalsIgnoreCase("Territory Sales IC")
                                && !Grade1.equalsIgnoreCase("Officer Grade IV") && !Grade1.equalsIgnoreCase("Selection Grade") && !Grade1.equalsIgnoreCase("Officer Grade I")
                                && !Grade1.equalsIgnoreCase("Officer Grade III") && !Grade1.equalsIgnoreCase("Executive-Sales") && !Grade1.equalsIgnoreCase("Assistant Manager")
                                && !Grade1.equalsIgnoreCase("Asst. Manager-Sales")) {//Modified by Sivashankar KS on 24-Oct-2018 for allowing DA and Hotel Fares for Asst. Manager-Sales as per the mail from sivaram

                            int rowCount1 = formObject.getLVWRowCount("list_daily");
                            for (int i = 0; i < rowCount1; i++) {
                                try {
                                    startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                                    endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                                    inputDate = sdf.parse(formObject.getNGValue("dp_hotelfare_checkindt"));
                                } catch (ParseException ex) {
                                    Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                                }

                                if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkindt")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkindt"))
                                        || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                                    throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_hotelfare_checkindt") + " is added in Daily Allowance bills, Please select other date", ""));
                                }

                            }
                            for (int i = 0; i < rowCount1; i++) {
                                try {
                                    startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                                    endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                                    inputDate = sdf.parse(formObject.getNGValue("dp_hotelfare_checkoutdt"));
                                } catch (ParseException ex) {
                                    Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                                }

                                if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkoutdt")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkoutdt"))
                                        || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                                    throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_hotelfare_checkoutdt") + " is added in Daily Allowance bills, Please select other date", ""));
                                }
                            }
                        }

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";
                        qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_HotelFare with(nolock),ext_ap with(nolock) where EXT_HotelFare.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_HotelFare.BillNo='" + formObject.getNGValue("HF_BillNo") + "' and "
                                + "EXT_HotelFare.Amount=" + formObject.getNGValue("txt_hotelfare_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number and Amount", "HF_BillNo"));

                        }
                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_HotelFare with(nolock),EXT_AP with(nolock) where EXT_HotelFare.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_HotelFare.CheckInDate=convert(datetime,'" + formObject.getNGValue("dp_hotelfare_checkindt") + "',103) and "
                                + "EXT_HotelFare.CheckoutDate= convert(datetime,'" + formObject.getNGValue("dp_hotelfare_checkoutdt") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        if (dupCOUNT2 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination:  CheckIn Date and CheckOut Date", "HF_BillNo"));

                        }
                        String strWorkId = "";

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_HotelFare with(nolock),EXT_AP with(nolock) where EXT_HotelFare.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_hotelfare_checkindt") + "',103) between convert(varchar(10),EXT_HotelFare.CheckInDate,126) and convert(varchar(10),EXT_HotelFare.CheckoutDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_hotelfare_checkindt") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_hotelfare_checkindt"));
                        }

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_HotelFare with(nolock),EXT_AP with(nolock) where EXT_HotelFare.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_hotelfare_checkoutdt") + "',103) between convert(varchar(10),EXT_HotelFare.CheckInDate,126) and convert(varchar(10),EXT_HotelFare.CheckoutDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_hotelfare_checkoutdt") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_hotelfare_checkoutdt"));
                        }

                        //Added By IBPS Support for Hotel Name Mandatory
//                        if (formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Travel Expense")
//                                && formObject.getNGValue("SubCategory1").equalsIgnoreCase("Travel Expense")) {
//                            CommonObj.writeToLog(2, "Before Hotel Name Mandatory call..", winame);
//                            if (formObject.getNGValue("txt_hotelfare_hotelname").equalsIgnoreCase("")) {
//                                CommonObj.writeToLog(2, "In IF After Hotel Name Mandatory..", winame);
//                                throw new ValidatorException(new FacesMessage("Hotel Name is Mandatory", ""));
//                            }
//                        }
                        //End of Added By IBPS Support for Hotel Name Mandatory
                        float trvlsum = 0.f;
                        CommonObj.writeToLog(2, "Hotel Modify Button", winame);
                        CommonObj.modifyRow(formObject, "list_hotel");
                        trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_hotel", 15, 2);//Modified by Sivashanakr KS on 15 July 2019
                        formObject.setNGValue("HotelExpense", trvlsum);
                        formObject.setNGValue("TotalAmount", "");
                    }
                    //Ended By Sivashankar KS on 03-April-2019
/*
                     // Commented by Sivashankar KS on 5th April 2019
                     float trvlsum = 0.f;
                     CommonObj.writeToLog(2, "Hotel Modify Button", winame);

                     //Modified by Harinath on 2017/05/25
                     if (!Grade1.equalsIgnoreCase("Fld Sales Off Gr III") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr II") && !Grade1.equalsIgnoreCase("Executive")
                     && !Grade1.equalsIgnoreCase("Officer Grade II") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr I") && !Grade1.equalsIgnoreCase("Territory Sales IC")
                     && !Grade1.equalsIgnoreCase("Officer Grade IV") && !Grade1.equalsIgnoreCase("Selection Grade") && !Grade1.equalsIgnoreCase("Officer Grade I")
                     && !Grade1.equalsIgnoreCase("Officer Grade III") && !Grade1.equalsIgnoreCase("Executive-Sales") && !Grade1.equalsIgnoreCase("Assistant Manager")
                     && !Grade1.equalsIgnoreCase("Asst. Manager-Sales")) {//Modified by Sivashankar KS on 24-Oct-2018 for allowing DA and Hotel Fares for Asst. Manager-Sales as per the mail from sivaram
                     int rowCount1 = formObject.getLVWRowCount("list_daily");
                     for (int i = 0; i < rowCount1; i++) {
                     try {
                     startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                     endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                     inputDate = sdf.parse(formObject.getNGValue("dp_hotelfare_checkindt"));
                     } catch (ParseException ex) {
                     Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                     }

                     if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkindt")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkindt"))
                     || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                     throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_hotelfare_checkindt") + " is added in Daily Allowance bills, Please select other date", ""));
                     }

                     }
                     for (int i = 0; i < rowCount1; i++) {
                     try {
                     startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                     endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                     inputDate = sdf.parse(formObject.getNGValue("dp_hotelfare_checkoutdt"));
                     } catch (ParseException ex) {
                     Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                     }
                     if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkoutdt")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_hotelfare_checkoutdt"))
                     || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                     throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_hotelfare_checkoutdt") + " is added in Daily Allowance bills, Please select other date", ""));
                     }
                     }
                     }
                     //Ended by Harinath on 2017/05/25

                     CommonObj.modifyRow(formObject, "list_hotel");
                     trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_hotel", 3, 2);
                     formObject.setNGValue("HotelExpense", trvlsum);
                     formObject.setNGValue("TotalAmount", "");
                     */
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_del_htl")) {
                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "hotel delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_hotel");
                    trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_hotel", 15, 2);//Modified by Sivashanakr KS on 15 July 2019
                    formObject.setNGValue("HotelExpense", trvlsum);
                    formObject.setNGValue("TotalAmount", "");
                } //Added by SandeepKN on 10Jan2020 for ASFI and SFIC changes OtherExpense -- Start
                // Added by SivaShankar for DUBAI and OMAN Changes-- Start
                else if (pEvent.getSource().getName().equalsIgnoreCase("oe_btn_add")) {
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("oe_dp_fromdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("oe_dp_fromdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } else {

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";
                        qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_OtherExpenses with(nolock),ext_ap with(nolock) where EXT_OtherExpenses.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_OtherExpenses.BillNo='" + formObject.getNGValue("oe_txt_billnumber") + "' and "
                                + "EXT_OtherExpenses.TotalAmount=" + formObject.getNGValue("oe_txt_totamount") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number and Amount", "oe_txt_billnumber"));

                        }
                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_OtherExpenses with(nolock),EXT_AP with(nolock) where EXT_OtherExpenses.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_OtherExpenses.FromDate=convert(datetime,'" + formObject.getNGValue("oe_dp_fromdate") + "',103) and "
                                + "EXT_OtherExpenses.ToDate= convert(datetime,'" + formObject.getNGValue("oe_dp_todate") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        if (dupCOUNT2 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination:  From Date and To Date", "oe_txt_billnumber"));

                        }
                        String strWorkId = "";

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_OtherExpenses with(nolock),EXT_AP with(nolock) where EXT_OtherExpenses.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("oe_dp_fromdate") + "',103) between convert(varchar(10),EXT_OtherExpenses.FromDate,126) and convert(varchar(10),EXT_OtherExpenses.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("oe_dp_fromdate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "oe_dp_fromdate"));
                        }

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_OtherExpenses with(nolock),EXT_AP with(nolock) where EXT_OtherExpenses.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("oe_dp_todate") + "',103) between convert(varchar(10),EXT_OtherExpenses.FromDate,126) and convert(varchar(10),EXT_OtherExpenses.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("oe_dp_todate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "oe_dp_todate"));
                        }
                        float trvlsum = 0.f;
                        CommonObj.writeToLog(2, "Other Expense Add Button", winame);
                        CommonObj.addRow(formObject, "list_otherexpenses");
                        //trvlsum = (float) CommonObj.listViewColumnSum("list_hotel", 3);
                        trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_otherexpenses", 10, 2);//Modified by Sivashanakr KS on 15 July 2019
                        formObject.setNGValue("OtherExpenses", trvlsum);
                        formObject.setNGValue("TotalAmount", "");
                    }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("oe_btn_modify")) {
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("oe_dp_fromdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("oe_dp_fromdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } else {

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";
                        qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_OtherExpenses with(nolock),ext_ap with(nolock) where EXT_OtherExpenses.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_OtherExpenses.BillNo='" + formObject.getNGValue("oe_txt_billnumber") + "' and "
                                + "EXT_OtherExpenses.TotalAmount=" + formObject.getNGValue("oe_txt_totamount") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number and Amount", "oe_txt_billnumber"));

                        }
                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_OtherExpenses with(nolock),EXT_AP with(nolock) where EXT_OtherExpenses.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_OtherExpenses.FromDate=convert(datetime,'" + formObject.getNGValue("oe_dp_fromdate") + "',103) and "
                                + "EXT_OtherExpenses.ToDate= convert(datetime,'" + formObject.getNGValue("oe_dp_todate") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        if (dupCOUNT2 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination:  From Date and To Date", "oe_txt_billnumber"));

                        }
                        String strWorkId = "";

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_OtherExpenses with(nolock),EXT_AP with(nolock) where EXT_OtherExpenses.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("oe_dp_fromdate") + "',103) between convert(varchar(10),EXT_OtherExpenses.FromDate,126) and convert(varchar(10),EXT_OtherExpenses.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("oe_dp_fromdate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "oe_dp_fromdate"));
                        }

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_OtherExpenses with(nolock),EXT_AP with(nolock) where EXT_OtherExpenses.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("oe_dp_todate") + "',103) between convert(varchar(10),EXT_OtherExpenses.FromDate,126) and convert(varchar(10),EXT_OtherExpenses.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("oe_dp_todate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "oe_dp_todate"));
                        }
                        float trvlsum = 0.f;
                        CommonObj.writeToLog(2, "Other Expense Modify Button", winame);
                        CommonObj.modifyRow(formObject, "list_otherexpenses");
                        //trvlsum = (float) CommonObj.listViewColumnSum("list_hotel", 3);
                        trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_otherexpenses", 10, 2);//Modified by Sivashanakr KS on 15 July 2019
                        formObject.setNGValue("OtherExpenses", trvlsum);
                        formObject.setNGValue("TotalAmount", "");
                    }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("oe_btn_delete")) {
                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "Other expenses delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_otherexpenses");
                    trvlsum = (float) CommonObj.listViewColumnIgnorePaidBy("list_otherexpenses", 10, 2);//Modified by Sivashanakr KS on 15 July 2019
                    formObject.setNGValue("OtherExpenses", trvlsum);
                    formObject.setNGValue("TotalAmount", "");
                } // Added by SivaShankar for DUBAI and OMAN Changes-- END
                //Added by SandeepKN on 10Jan2020 for ASFI and SFIC changes OtherExpense -- End
                else if (pEvent.getSource().getName().equalsIgnoreCase("btn_add_dly")) {
                    if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                        formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                        CommonObj.writeToLog(2, "In if setting txt_dailyallw_actualdaclaim greater than txt_dailyallw_calcda" + formObject.getNGValue("txt_dailyallw_actualdaclaim"), winame);
                        throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                    }

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_dailyallw_fromdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_dailyallw_fromdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    }
                    //Ended by Harinatha on 2017/10/26

                    //Modified by Harinath on 2017/05/25
                    if (!Grade1.equalsIgnoreCase("Fld Sales Off Gr III") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr II") && !Grade1.equalsIgnoreCase("Executive")
                            && !Grade1.equalsIgnoreCase("Officer Grade II") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr I") && !Grade1.equalsIgnoreCase("Territory Sales IC")
                            && !Grade1.equalsIgnoreCase("Officer Grade IV") && !Grade1.equalsIgnoreCase("Selection Grade") && !Grade1.equalsIgnoreCase("Officer Grade I")
                            && !Grade1.equalsIgnoreCase("Officer Grade III") && !Grade1.equalsIgnoreCase("Executive-Sales") && !Grade1.equalsIgnoreCase("Assistant Manager")
                            && !Grade1.equalsIgnoreCase("Asst. Manager-Sales")) {//Modified by Sivashankar KS on 24-Oct-2018 for allowing DA and Hotel Fares for Asst. Manager-Sales as per the mail from sivaram
                        int rowCount1 = formObject.getLVWRowCount("list_hotel");
                        for (int i = 0; i < rowCount1; i++) {
                            try {
                                startDate = sdf.parse(formObject.getNGValue("list_hotel", i, 0));
                                endDate = sdf.parse(formObject.getNGValue("list_hotel", i, 1));
                                inputDate = sdf.parse(formObject.getNGValue("dp_dailyallw_fromdate"));
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            if (formObject.getNGValue("list_hotel", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_fromdate")) || formObject.getNGValue("list_hotel", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_fromdate"))
                                    || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                                CommonObj.writeToLog(2, "From date is duplicate", winame);
                                throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_dailyallw_fromdate") + " is added in Hotels Fare Template, Please select other date", ""));
                            }
                        }
                        for (int i = 0; i < rowCount1; i++) {
                            try {
                                startDate = sdf.parse(formObject.getNGValue("list_hotel", i, 0));
                                endDate = sdf.parse(formObject.getNGValue("list_hotel", i, 1));
                                inputDate = sdf.parse(formObject.getNGValue("dp_dailyallw_todate"));
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            if (formObject.getNGValue("list_hotel", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_todate")) || formObject.getNGValue("list_hotel", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_todate"))
                                    || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                                CommonObj.writeToLog(2, "To date is duplicate", winame);
                                throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_dailyallw_todate") + " is added in Hotels Fare Template, Please select other date", ""));
                            }
                        }
                    }
                    //Ended by Harinath on 2017/05/25

                    //Added by Harinath on 2017/07/11
                    for (int i = 0; i < formObject.getLVWRowCount("list_daily"); i++) {
                        try {
                            startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                            endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                            fromDate = sdf.parse(formObject.getNGValue("dp_dailyallw_fromdate"));
                            toDate = sdf.parse(formObject.getNGValue("dp_dailyallw_todate"));
                        } catch (ParseException ex) {
                            Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                        }

                        if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_fromdate")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_fromdate"))
                                || ((fromDate.after(startDate)) && (fromDate.before(endDate)))) {
                            CommonObj.writeToLog(2, "From date is duplicate", winame);
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_dailyallw_fromdate") + " is already entered in daily allowances template", "dp_dailyallw_fromdate"));
                        }

                        if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_todate")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_todate"))
                                || ((toDate.after(startDate)) && (toDate.before(endDate)))) {
                            CommonObj.writeToLog(2, "From date is duplicate", winame);
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_dailyallw_todate") + " is already entered in daily allowances template", "dp_dailyallw_todate"));
                        }

                    }

                    String strWorkId = "";
                    strWorkId = CommonObj.SelectQuery("select WorkId from EXT_DailyAllow,ext_ap where VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_DailyAllow.PID=WorkId and ER_IniSts!='Reject' and WorkId !='" + winame + "' and CONVERT(date,'" + formObject.getNGValue("dp_dailyallw_fromdate") + "',103) between convert(varchar(10),FromDate,126) and convert(varchar(10),ToDate,126)");
                    if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                        throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_dailyallw_fromdate") + " is already claimed under daily allowances. Transaction No : " + strWorkId + " ", "dp_dailyallw_fromdate"));
                    }
                    strWorkId = CommonObj.SelectQuery("select WorkId from EXT_DailyAllow,ext_ap where VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_DailyAllow.PID=WorkId and ER_IniSts!='Reject' and WorkId !='" + winame + "' and CONVERT(date,'" + formObject.getNGValue("dp_dailyallw_todate") + "',103) between convert(varchar(10),FromDate,126) and convert(varchar(10),ToDate,126)");
                    if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                        throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_dailyallw_todate") + " is already claimed under daily allowances. Transaction No : " + strWorkId + " ", "dp_dailyallw_todate"));
                    }
                    //Ended by Harinath on 2017/07/11

                    //Modified by Harinath on 2017/03/20
                    /*
                     if ((strSubcategory.equalsIgnoreCase("Look and See Visit"))
                     || (strSubcategory.equalsIgnoreCase("Travel Expense"))) {
                     int Hotel1 = formObject.getItemCount("list_hotel");
                     if (Hotel1 != 0) {
                     throw new ValidatorException(new FacesMessage("Daily allowance is not allowed. ", "list_daily"));
                     } else {
                     float trvlsum = 0.f;
                     CommonObj.writeToLog(2, "Daily Add Add Button", winame);
                     CommonObj.addRow(formObject, "list_daily");
                     trvlsum = (float) CommonObj.listViewColumnSum("list_daily", 5);
                     formObject.setNGValue("DailyAllowance", trvlsum);
                     }
                     //if(strSubcategory.equalsIgnoreCase("Entertainment"))
                     } else {
                     */
                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "Daily Add Add Button", winame);
                    CommonObj.addRow(formObject, "list_daily");
                    trvlsum = (float) CommonObj.listViewColumnSum("list_daily", 5);
                    formObject.setNGValue("DailyAllowance", trvlsum);
                    // }
                    //Ended by Harinath on 2017/03/20
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_mod_dly")) {
                    if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                        formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                        CommonObj.writeToLog(2, "In if setting txt_dailyallw_actualdaclaim greater than txt_dailyallw_calcda" + formObject.getNGValue("txt_dailyallw_actualdaclaim"), winame);
                        throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                    }
                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_dailyallw_fromdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_dailyallw_fromdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    }
                    //Ended by Harinatha on 2017/10/26

                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "Daily Modify Button", winame);

                    //Modified by Harinath on 2017/05/25
                    if (!Grade1.equalsIgnoreCase("Fld Sales Off Gr III") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr II") && !Grade1.equalsIgnoreCase("Executive")
                            && !Grade1.equalsIgnoreCase("Officer Grade II") && !Grade1.equalsIgnoreCase("Fld Sales Off Gr I") && !Grade1.equalsIgnoreCase("Territory Sales IC")
                            && !Grade1.equalsIgnoreCase("Officer Grade IV") && !Grade1.equalsIgnoreCase("Selection Grade") && !Grade1.equalsIgnoreCase("Officer Grade I")
                            && !Grade1.equalsIgnoreCase("Officer Grade III") && !Grade1.equalsIgnoreCase("Executive-Sales") && !Grade1.equalsIgnoreCase("Assistant Manager")
                            && !Grade1.equalsIgnoreCase("Asst. Manager-Sales")) {//Modified by Sivashankar KS on 24-Oct-2018 for allowing DA and Hotel Fares for Asst. Manager-Sales as per the mail from sivaram
                        int rowCount1 = formObject.getLVWRowCount("list_hotel");
                        for (int i = 0; i < rowCount1; i++) {
                            try {
                                startDate = sdf.parse(formObject.getNGValue("list_hotel", i, 0));
                                endDate = sdf.parse(formObject.getNGValue("list_hotel", i, 1));
                                inputDate = sdf.parse(formObject.getNGValue("dp_dailyallw_fromdate"));
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            if (formObject.getNGValue("list_hotel", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_fromdate")) || formObject.getNGValue("list_hotel", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_fromdate"))
                                    || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                                throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_dailyallw_fromdate") + " is added in Hotels Fare Template, Please select other date", ""));
                            }
                        }
                        for (int i = 0; i < rowCount1; i++) {
                            try {
                                startDate = sdf.parse(formObject.getNGValue("list_hotel", i, 0));
                                endDate = sdf.parse(formObject.getNGValue("list_hotel", i, 1));
                                inputDate = sdf.parse(formObject.getNGValue("dp_dailyallw_todate"));
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }

                            if (formObject.getNGValue("list_hotel", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_todate")) || formObject.getNGValue("list_hotel", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_todate"))
                                    || ((inputDate.after(startDate)) && (inputDate.before(endDate)))) {
                                throw new ValidatorException(new FacesMessage("Selected date : " + formObject.getNGValue("dp_dailyallw_todate") + " is added in Hotels Fare Template, Please select other date", ""));
                            }
                        }
                    }
                    //Ended by Harinath on 2017/05/25

                    //Added by Harinath on 2017/07/11
                    for (int i = 0; i < formObject.getLVWRowCount("list_daily"); i++) {
                        try {

                            startDate = sdf.parse(formObject.getNGValue("list_daily", i, 0));
                            endDate = sdf.parse(formObject.getNGValue("list_daily", i, 1));
                            fromDate = sdf.parse(formObject.getNGValue("dp_dailyallw_fromdate"));
                            toDate = sdf.parse(formObject.getNGValue("dp_dailyallw_todate"));
                        } catch (ParseException ex) {
                            Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        if (formObject.getSelectedIndex("list_daily") != i) {
                            if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_fromdate")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_fromdate"))
                                    || ((fromDate.after(startDate)) && (fromDate.before(endDate)))) {

                                throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_dailyallw_fromdate") + " is already entered in daily allowances template", "dp_dailyallw_fromdate"));
                            }

                            if (formObject.getNGValue("list_daily", i, 0).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_todate")) || formObject.getNGValue("list_daily", i, 1).equalsIgnoreCase(formObject.getNGValue("dp_dailyallw_todate"))
                                    || ((toDate.after(startDate)) && (toDate.before(endDate)))) {

                                throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_dailyallw_todate") + " is already entered in daily allowances template", "dp_dailyallw_todate"));
                            }
                        }
                    }

                    String strWorkId = "";
                    strWorkId = CommonObj.SelectQuery("select WorkId from EXT_DailyAllow,ext_ap WITH (NOLOCK) where VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_DailyAllow.PID=WorkId and ER_IniSts!='Reject' and WorkId !='" + winame + "' and CONVERT(date,'" + formObject.getNGValue("dp_dailyallw_fromdate") + "',103) between convert(varchar(10),FromDate,126) and convert(varchar(10),ToDate,126)");
                    if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                        throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_dailyallw_fromdate") + " is already claimed under daily allowances. Transaction No : " + strWorkId + " ", "dp_dailyallw_fromdate"));
                    }
                    strWorkId = CommonObj.SelectQuery("select WorkId from EXT_DailyAllow,ext_ap WITH (NOLOCK) where VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_DailyAllow.PID=WorkId and ER_IniSts!='Reject' and WorkId !='" + winame + "' and CONVERT(date,'" + formObject.getNGValue("dp_dailyallw_todate") + "',103) between convert(varchar(10),FromDate,126) and convert(varchar(10),ToDate,126)");
                    if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                        throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_dailyallw_todate") + " is already claimed under daily allowances. Transaction No : " + strWorkId + " ", "dp_dailyallw_todate"));
                    }
                    //Ended by Harinath on 2017/07/11

                    CommonObj.modifyRow(formObject, "list_daily");
                    trvlsum = (float) CommonObj.listViewColumnSum("list_daily", 5);
                    formObject.setNGValue("DailyAllowance", trvlsum);
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_del_dly")) {
                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "Delete Daily Button", winame);
                    CommonObj.deleteRow(formObject, "list_daily");
                    trvlsum = (float) CommonObj.listViewColumnSum("list_daily", 5);
                    formObject.setNGValue("DailyAllowance", trvlsum);
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_add_con")) {

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_convey_fromdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_convey_fromdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } //Ended by Harinatha on 2017/10/26
                    //Added By Sivashankar KS on 05-April-2019
                    else {

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";
                        qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_Convey with(nolock),ext_ap with(nolock) where EXT_Convey.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Convey.BillNo='" + formObject.getNGValue("Con_BillNo") + "' and "
                                + "EXT_Convey.Amount=" + formObject.getNGValue("txt_convey_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number and Amount", "Con_BillNo"));

                        }
                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_Convey with(nolock),EXT_AP with(nolock) where EXT_Convey.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Convey.FromDate=convert(datetime,'" + formObject.getNGValue("dp_convey_fromdate") + "',103) and "
                                + "EXT_Convey.ToDate= convert(datetime,'" + formObject.getNGValue("dp_convey_todate") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        if (dupCOUNT2 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination: From Period and To Period", "Con_BillNo"));

                        }
                        String strWorkId = "";

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_Convey with(nolock),EXT_AP with(nolock) where EXT_Convey.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_convey_fromdate") + "',103) between convert(varchar(10),EXT_Convey.FromDate,126) and convert(varchar(10),EXT_Convey.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_convey_fromdate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_convey_fromdate"));
                        }

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_Convey with(nolock),EXT_AP with(nolock) where EXT_Convey.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_convey_todate") + "',103) between convert(varchar(10),EXT_Convey.FromDate,126) and convert(varchar(10),EXT_Convey.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_convey_todate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_convey_todate"));
                        }
                        float trvlsum = 0.f;
                        CommonObj.writeToLog(2, "Convey Add Button", winame);
                        CommonObj.addRow(formObject, "list_convey");
                        trvlsum = (float) CommonObj.listViewColumnSum("list_convey", 3);
                        formObject.setNGValue("Conveyance", trvlsum);
                    }
                    //Ended By Sivashankar KS on 05-April-2019
                    // Commented by Sivashankar KS on 5th April 2019
                    /*float trvlsum = 0.f;
                     CommonObj.writeToLog(2, "Convey Add Button", winame);
                     CommonObj.addRow(formObject, "list_convey");
                     trvlsum = (float) CommonObj.listViewColumnSum("list_convey", 3);
                     formObject.setNGValue("Conveyance", trvlsum);*/
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_mod_con")) {

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_convey_fromdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_convey_fromdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } //Ended by Harinatha on 2017/10/26
                    //Added By Sivashankar KS on 05-April-2019
                    else {

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";
                        qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_Convey with(nolock),ext_ap with(nolock) where EXT_Convey.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Convey.BillNo='" + formObject.getNGValue("Con_BillNo") + "' and "
                                + "EXT_Convey.Amount=" + formObject.getNGValue("txt_convey_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number and Amount", "Con_BillNo"));

                        }
                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_Convey with(nolock),EXT_AP with(nolock) where EXT_Convey.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Convey.FromDate=convert(datetime,'" + formObject.getNGValue("dp_convey_fromdate") + "',103) and "
                                + "EXT_Convey.ToDate= convert(datetime,'" + formObject.getNGValue("dp_convey_todate") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        if (dupCOUNT2 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination: From Period and To Period", "Con_BillNo"));

                        }
                        String strWorkId = "";

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_Convey with(nolock),EXT_AP with(nolock) where EXT_Convey.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_convey_fromdate") + "',103) between convert(varchar(10),EXT_Convey.FromDate,126) and convert(varchar(10),EXT_Convey.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_convey_fromdate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_convey_fromdate"));
                        }

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_Convey with(nolock),EXT_AP with(nolock) where EXT_Convey.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_convey_todate") + "',103) between convert(varchar(10),EXT_Convey.FromDate,126) and convert(varchar(10),EXT_Convey.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_convey_todate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_convey_todate"));
                        }
                        float trvlsum = 0.f;
                        CommonObj.writeToLog(2, "convey modify Button", winame);
                        CommonObj.modifyRow(formObject, "list_convey");
                        trvlsum = (float) CommonObj.listViewColumnSum("list_convey", 3);
                        formObject.setNGValue("Conveyance", trvlsum);
                    }
                    //Ended By Sivashankar KS on 05-April-2019
                    // Commented by Sivashankar KS on 5th April 2019
                    /*
                     float trvlsum = 0.f;
                     CommonObj.writeToLog(2, "convey modify Button", winame);
                     CommonObj.modifyRow(formObject, "list_convey");
                     trvlsum = (float) CommonObj.listViewColumnSum("list_convey", 3);
                     formObject.setNGValue("Conveyance", trvlsum);*/
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_del_con")) {
                    //System.out.println("Convey Delete Button");
                    CommonObj.writeToLog(2, "Convey Delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_convey");
                    float trvlsum = (float) CommonObj.listViewColumnSum("list_convey", 3);
                    formObject.setNGValue("Conveyance", trvlsum);
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_add_misc")) {

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_misc_fromdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_misc_fromdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } //Ended by Harinatha on 2017/10/26
                    //Added By Sivashankar KS on 05-April-2019
                    else {

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";
                        qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_Misc with(nolock),ext_ap with(nolock) where EXT_Misc.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Misc.BillNo='" + formObject.getNGValue("Mis_BillNo") + "' and "
                                + "EXT_Misc.Amount=" + formObject.getNGValue("txt_misc_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number and Amount", "Mis_BillNo"));

                        }
                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_Misc with(nolock),EXT_AP with(nolock) where EXT_Misc.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Misc.FromDate=convert(datetime,'" + formObject.getNGValue("dp_misc_fromdate") + "',103) and "
                                + "EXT_Misc.ToDate= convert(datetime,'" + formObject.getNGValue("dp_misc_todate") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        if (dupCOUNT2 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination: From Period and To Period", "Mis_BillNo"));

                        }
                        String strWorkId = "";

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_Misc with(nolock),EXT_AP with(nolock) where EXT_Misc.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_misc_fromdate") + "',103) between convert(varchar(10),EXT_Misc.FromDate,126) and convert(varchar(10),EXT_Misc.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("dp_misc_fromdate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_misc_fromdate"));
                        }

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_Misc with(nolock),EXT_AP with(nolock) where EXT_Misc.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_misc_todate") + "',103) between convert(varchar(10),EXT_Misc.FromDate,126) and convert(varchar(10),EXT_Misc.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("dp_misc_todate") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_misc_todate"));
                        }
                        float trvlsum = 0.f;
                        CommonObj.writeToLog(2, "Misc Add Button", winame);
                        CommonObj.addRow(formObject, "list_misc");
                        trvlsum = (float) CommonObj.listViewColumnSum("list_misc", 1);
                        formObject.setNGValue("Miscellaneous", trvlsum);
                    }
                    //Ended By Sivashankar KS on 05-April-2019

// Commented by Sivashankar KS on 5th April 2019
                    /*
                     float trvlsum = 0.f;
                     CommonObj.writeToLog(2, "Misc Add Button", winame);
                     CommonObj.addRow(formObject, "list_misc");
                     trvlsum = (float) CommonObj.listViewColumnSum("list_misc", 2);
                     formObject.setNGValue("Miscellaneous", trvlsum);*/
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_mod_misc")) {

                    //Modified by Harinatha on 2017/10/26
                    String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                    int diiffdays = 0;
                    try {
                        diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("dp_misc_fromdate"), strCurDate));
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                    //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                    //                    45DaysChange
                    Date strDate = new Date();
                    Date billDate = new Date();
                    String bilDate = formObject.getNGValue("dp_misc_fromdate");
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        strDate = sdf.parse(srtDate);
                        billDate = sdf.parse(bilDate);
                    } catch (Exception e) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                    }
//                    todayDate.before(futureDate)
                    String days = "";
                    if (billDate.before(strDate)) {
                        days = "90";
                    } else {
                        if (strActivityName.equalsIgnoreCase("Rework")) {
                            days = "60";
                        } else {
                            days = "45";
                        }
                    }
                    if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                    } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                    } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                        throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                    } //Ended by Harinatha on 2017/10/26
                    //Added By Sivashankar KS on 05-April-2019
                    else {

                        String qryDuplicateent1 = "";
                        String qryDuplicate2 = "";
                        qryDuplicateent1 = "Select Count(InsertionOrderID) from EXT_Misc with(nolock),ext_ap with(nolock) where EXT_Misc.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Misc.BillNo='" + formObject.getNGValue("Mis_BillNo") + "' and "
                                + "EXT_Misc.Amount=" + formObject.getNGValue("txt_misc_amnt") + " and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicateent1, winame);
                        int dupCOUNT1 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicateent1));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT1, winame);

                        if (dupCOUNT1 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number and Amount", "Mis_BillNo"));

                        }
                        qryDuplicate2 = "Select Count(InsertionOrderID) from EXT_Misc with(nolock),EXT_AP with(nolock) where EXT_Misc.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and EXT_Misc.FromDate=convert(datetime,'" + formObject.getNGValue("dp_misc_fromdate") + "',103) and "
                                + "EXT_Misc.ToDate= convert(datetime,'" + formObject.getNGValue("dp_misc_todate") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "' ";

                        CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                        int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                        CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                        if (dupCOUNT2 >= 1) {
                            CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                            CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                            throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination: From Period and To Period", "Mis_BillNo"));

                        }
                        String strWorkId = "";

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_Misc with(nolock),EXT_AP with(nolock) where EXT_Misc.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_misc_fromdate") + "',103) between convert(varchar(10),EXT_Misc.FromDate,126) and convert(varchar(10),EXT_Misc.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("FromPeriod") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_misc_fromdate"));
                        }

                        strWorkId = CommonObj.SelectQuery("select WorkId from EXT_Misc with(nolock),EXT_AP with(nolock) where EXT_Misc.PID=WorkId and VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') and CONVERT(date,'" + formObject.getNGValue("dp_misc_todate") + "',103) between convert(varchar(10),EXT_Misc.FromDate,126) and convert(varchar(10),EXT_Misc.ToDate,126) and WorkId !='" + winame + "' AND EXT_AP.RequestFor='" + formObject.getNGValue("RequestFor") + "'");
                        if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                            throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("ToPeriod") + " is already entered in other claim... Transaction No : " + strWorkId + " ", "dp_misc_todate"));
                        }
                        float trvlsum = 0.f;
                        CommonObj.writeToLog(2, "Misc Modify Button", winame);
                        CommonObj.modifyRow(formObject, "list_misc");
                        trvlsum = (float) CommonObj.listViewColumnSum("list_misc", 1);
                        formObject.setNGValue("Miscellaneous", trvlsum);
                    }
                    //Ended By Sivashankar KS on 05-April-2019
                    // Commented by Sivashankar KS on 5th April 2019
                    /*
                     float trvlsum = 0.f;
                     CommonObj.writeToLog(2, "Misc Modify Button", winame);
                     CommonObj.modifyRow(formObject, "list_misc");
                     trvlsum = (float) CommonObj.listViewColumnSum("list_misc", 2);
                     formObject.setNGValue("Miscellaneous", trvlsum);*/
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_del_misc")) {
                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "Misc Delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_misc");
                    trvlsum = (float) CommonObj.listViewColumnSum("list_misc", 1);
                    formObject.setNGValue("Miscellaneous", trvlsum);
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_add_med")) {
                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "Medical Add Button", winame);
                    CommonObj.addRow(formObject, "list_medical");
                    trvlsum = (float) CommonObj.listViewColumnSum("list_medical", 1);
                    formObject.setNGValue("MedicalExpense", trvlsum);
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_mod_med")) {
                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "Modify Button", winame);
                    CommonObj.modifyRow(formObject, "list_medical");
                    trvlsum = (float) CommonObj.listViewColumnSum("list_medical", 1);
                    formObject.setNGValue("MedicalExpense", trvlsum);
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_del_med")) {
                    float trvlsum = 0.f;
                    CommonObj.writeToLog(2, "Medical Delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_medical");
                    trvlsum = (float) CommonObj.listViewColumnSum("list_medical", 1);
                    formObject.setNGValue("MedicalExpense", trvlsum);
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_calc_totamnt")) {
                    if (strSubcategory.equalsIgnoreCase("Moving of Personal Effects")) {
                        if (formObject.getNGValue("SchlfeeYN").equalsIgnoreCase("Yes")) {
                            CommonObj.mandatoryCheck(formObject, "SchlfeeElbamnt", "Please enter eligible amount");
                            CommonObj.mandatoryCheck(formObject, "SchlfeeClaimamnt", "Please enter claimed amount");
                            Float fClaimedAmount = Float.parseFloat(formObject.getNGValue("SchlfeeClaimamnt"));
                            Float fEligibleAmount = Float.parseFloat(formObject.getNGValue("SchlfeeElbamnt"));
                            if (formObject.getNGValue("SchlfeeClaimamnt") != "") {
//Modified on 23-Oct-2018 for removing validation for manager grade I and above as per jestus mail
                                if (Grade1.equalsIgnoreCase("Vice President") || Grade1.equalsIgnoreCase("Manager Grade I") || Grade1.equalsIgnoreCase("Managing Director")) {
                                    //
                                } else {
                                    if (fClaimedAmount > fEligibleAmount) {
                                        formObject.setNGValue("SchlfeeClaimamnt", "");
                                        formObject.setNGFocus("SchlfeeClaimamnt");
                                        //fm = new FacesMessage("Claimed amount cannot be greater the eligible amount", "EligibleAmount");  
                                        throw new ValidatorException(new FacesMessage("Claimed amount cannot be greater the eligible amount", "EligibleAmount"));
                                    }
                                }
                            }
                        }
                    }
                    writeToLog(1, " AmountCalc on btn_calc_totamnt button click..... ", winame);
                    CommonObj.AmountCalc();
                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_Reject")) {
                    String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
                    formObject.setNGValue("ER_IniSts", "Reject");
                    formObject.RaiseEvent("WFDone");
                    break;

                } else if (pEvent.getSource().getName().equalsIgnoreCase("btn_submit")) {
                    String strGoAirSts = "False";
                    String strGHBFeedbackSts = "False";
                    String strGHBWorkID = "";
                    try {
                        writeToLog(1, " btn_submit button click starts ..... ", winame);
                        //Added by Sivashankar KS on 29-Aug-2019 Code to display Go-Air Feddback Link & Note starts here

                        //For HANA Migration on 28-MAR-21
//                        if (strTypeofinvoice.equalsIgnoreCase("Employee Advances")
//                                || strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")
//                                || strTypeofinvoice.equalsIgnoreCase("Relocation")
//                                || strTypeofinvoice.equalsIgnoreCase("Travel Expense")
//                                || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")) {
//                            throw new ValidatorException(new FacesMessage("Only Travel Request are allowed to raise due to HANA migartion", "TypeOfInvoice"));
//                        }
                        //End on 28-MAR-21
                        if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")) {
                            writeToLog(1, "inside btn_submit button click goair check starts ..... ", winame);
                            writeToLog(2, "..........................stmt1..................... ", winame);
                            int list_travel = formObject.getItemCount("list_travel");
                            CommonObj.writeToLog(2, "list_travel Count:" + list_travel, winame);
                            CommonObj.writeToLog(2, "list_Entertain:" + (formObject.getSelectedIndex("list_travel")), winame);
                            CommonObj.writeToLog(2, "getNGListView:list_travel:" + formObject.getNGListView("list_travel"), winame);
                            if (list_travel > 0) {
                                for (Integer i = 0; i < list_travel; i++) {
                                    String TravelLineItemData[] = CommonObj.getRowValue(formObject, "list_travel", i);
                                    CommonObj.writeToLog(2, "intLineNo:" + i, winame);
                                    String sValue5 = TravelLineItemData[5].trim();
                                    CommonObj.writeToLog(2, "sValue5 - Mode :" + sValue5, winame);
                                    if (sValue5.equalsIgnoreCase("Air")) {
                                        String sValue12 = TravelLineItemData[12].trim();
                                        CommonObj.writeToLog(2, "sValue12 Flight Number :" + sValue12, winame);
                                        if (sValue12.contains("G8")) {
                                            strGoAirSts = "True";
                                        }
                                    }
                                }
                            }
                            // visibility code here
                            if (strGoAirSts.equalsIgnoreCase("True")) {
                                formObject.setVisible("lbl_goairnote", true);
                                formObject.setVisible("btn_goair", true);
                                formObject.setLeft("btn_goair", 452);
                                formObject.setTop("btn_goair", 154);
                                formObject.setLeft("lbl_goairnote", 11);
                                formObject.setTop("lbl_goairnote", 158);
                            }
                            writeToLog(1, "inside btn_submit button click goair check ends ..... ", winame);

                            // Added by SandeepKn on 30Dec2019 for GHB Feedback form -- Start
                            if ((formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")
                                    || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI"))) {
                                writeToLog(2, "SFIC AND ASFI Company, hence no validation for GHB FEEDBACK..... ", winame);
                            } else {
                                // Added by SandeepKn on 30Dec2019 for GHB Feedback form -- Start
                                CommonObj.writeToLog(2, "inside btn_submit button click GHBFeedbackSts starts ..... ", winame);
                                String strGHBUsername = formObject.getUserName();
                                writeToLog(1, "strGHBUsername .....= ", strGHBUsername);
                                CommonObj.writeToLog(2, "strGHBUsername ==> " + strGHBUsername, winame);
                                try {
                                    writeToLog(2, "..........................stmt2..................... ", winame);
                                    CommonObj.writeToLog(2, "strGHBUsername111 ==> " + strGHBUsername, winame);
                                    String sqlQueryy = "SELECT top(1)e.WorkID FROM EXT_GHB e WITH(NOLOCK),WFINSTRUMENTTABLE w WITH(NOLOCK),EXT_GUESTHOUSE_OCCUPANCY_DETAILS_ACTIVE c "
                                            + "WITH(NOLOCK) WHERE e.WorkID=w.Processinstanceid AND e.WorkID=c.PID AND w.ActivityId IN(SELECT activityid FROM ACTIVITYTABLE "
                                            + "WITH(NOLOCK)  WHERE ProcessDefId=6 AND ActivityId=11) AND e.EmployeeName='" + strGHBUsername + "' ORDER BY e.WorkID DESC";
                                    CommonObj.writeToLog(2, "sqlQueryy ==> " + sqlQueryy, winame);
                                    List<List<String>> GHBWorkID = formObject.getDataFromDataSource(sqlQueryy);
                                    if (!GHBWorkID.get(0).get(0).equalsIgnoreCase("")) {
                                        writeToLog(2, "..........................stmt3..................... ", winame);
                                        strGHBWorkID = GHBWorkID.get(0).get(0);
                                        CommonObj.writeToLog(2, "sqlQueryy1111 ==> " + sqlQueryy, winame);
                                        CommonObj.writeToLog(2, "strGHBWorkID ==> " + strGHBWorkID, winame);
                                        if (!strGHBWorkID.equalsIgnoreCase("")) {
                                            writeToLog(2, "..........................stmt4..................... ", winame);
                                            String strGHBWicount = "";
                                            String sqlQuery1 = "SELECT (CAST(count(1) AS INT)) AS Count FROM EXT_GuestHouse_Feedback_Details WITH(NOLOCK) WHERE WorkID = '" + strGHBWorkID + "'";
                                            List<List<String>> GHBWicount = formObject.getDataFromDataSource(sqlQuery1);
                                            strGHBWicount = GHBWicount.get(0).get(0);
                                            CommonObj.writeToLog(2, "sqlQuery1 ==> " + sqlQuery1, winame);
                                            CommonObj.writeToLog(2, "strGHBWicount ==> " + strGHBWicount, winame);
                                            if (strGHBWicount.equalsIgnoreCase("0")) {
                                                strGHBFeedbackSts = "True";
                                                CommonObj.writeToLog(2, "strGHBFeedbackSts ==> " + strGHBFeedbackSts, winame);
                                                writeToLog(2, "..........................stmt7..................... ", winame);
                                            }
                                            writeToLog(2, "..........................stmt8..................... ", winame);
                                        }
                                        writeToLog(2, "..........................stmt6..................... ", winame);
                                    }
                                    writeToLog(2, "..........................stmt5..................... ", winame);
                                } catch (Exception e) {
                                    CommonObj.writeToLog(3, "Exception In GHBFeedbackSts Click==" + e.getMessage(), winame);
                                }
                                // visibility code here
                                if (strGHBFeedbackSts.equalsIgnoreCase("True")) {
                                    formObject.setVisible("btn_ghb_feedbk", true);
                                    formObject.setLeft("btn_ghb_feedbk", 252);
                                    formObject.setTop("btn_ghb_feedbk", 154);
                                }
                                writeToLog(1, "inside btn_submit button click goair check ends ..... ", winame);
                            }
                            // Added by SandeepKn on 30Dec2019 for GHB Feedback form -- END

                        }

                        if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
                            writeToLog(2, "..........................stmt9..................... ", winame);
                            CommonObj.writeToLog(2, "**** strEmpCode00 ***" + formObject.getNGValue("EmployeeCode"), winame);
                            String strEmpCode = formObject.getNGValue("EmployeeCode");
                            CommonObj.writeToLog(2, "**** strEmpCode ***" + strEmpCode, winame);
                            //Added by SAndeepKn on 10JAn2020 for ASFI and SFIC changes - Start
                            if ((formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI"))) {
                                if (formObject.getNGValue("ToBePaid").equalsIgnoreCase("") || formObject.getNGValue("ToBePaid").isEmpty()) {
                                    CommonObj.writeToLog(2, "**** ToBePaid is empty ***", winame);
                                    throw new ValidatorException(new FacesMessage("Please select Paid To", "ToBePaid"));
                                }
                            }//Added by SAndeepKn on 10JAn2020 for ASFI and SFIC changes - End
                            //Added by Sivashankar KS on 27-Nov-2019 for Mobile eligibility changes received from HRTeam & SSC Team starts
                            //Condition added by SandeepKn on 8Jan2020 to remove validation on 299 for VP and MD as per Sirisha
                            if (Grade1.equalsIgnoreCase("Vice President")
                                    || Grade1.equalsIgnoreCase("Managing Director")
                                    // Added by sandeepkn on 21Jan2020 to remove validation for International team as per Sivram mail confirmation
                                    || strEmpCode.contains("1007844") || strEmpCode.contains("1009633")
                                    || strEmpCode.contains("1010013") || strEmpCode.contains("1010235")
                                    || strEmpCode.contains("1010351")) {
                                CommonObj.writeToLog(2, "**** VP grade employees are eligible for actual bill as per mail on 08JAN2020 by sirisha ***", winame);
                            } else {
                                if ((formObject.getNGValue("CompanyCode").equalsIgnoreCase("BIL1")
                                        || formObject.getNGValue("CompanyCode").equalsIgnoreCase("BDPL")
                                        || formObject.getNGValue("CompanyCode").equalsIgnoreCase("BCFL"))) {
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                    CommonObj.writeToLog(2, "**** Bill Date ***" + formObject.getNGValue("BillDate"), winame);
                                    Date dateForm = sdf.parse(formObject.getNGValue("BillDate"));
                                    Date dateActual = sdf.parse("30/11/2019");
                                    if (dateForm.after(dateActual)) {
                                        CommonObj.writeToLog(2, "Bill Date is After 30-Nov-2019 ", winame);
                                        if (formObject.getNGValue("OriginalLocation").equalsIgnoreCase("Bangalore - EO")
                                                || formObject.getNGValue("OriginalLocation").equalsIgnoreCase("BIDADI")
                                                || formObject.getNGValue("OriginalLocation").equalsIgnoreCase("BIDADI R & D")
                                                || formObject.getNGValue("OriginalLocation").equalsIgnoreCase("Chennai Office")//Modified by Sandeep.n on 06Dec2019 as per HR Sirisha Mail
                                                || formObject.getNGValue("OriginalLocation").equalsIgnoreCase("Delhi Office")
                                                || formObject.getNGValue("OriginalLocation").equalsIgnoreCase("Kolkata Office")
                                                || formObject.getNGValue("OriginalLocation").equalsIgnoreCase("Mumbai Office")) {
                                            CommonObj.writeToLog(2, "**** OriginalLocation  ***" + formObject.getNGValue("OriginalLocation"), winame);
                                            String sTotalAmount = formObject.getNGValue("TotalAmount");
                                            Float fTotal = 0.0f;
                                            if (!sTotalAmount.equalsIgnoreCase("")) {
                                                fTotal = Float.parseFloat(sTotalAmount);
                                            }
                                            if (fTotal > Float.parseFloat("299")) {
                                                throw new ValidatorException(new FacesMessage("As per policy you are eligible to claim Mobile Re-Imbursements upto Rs.299 only", "TotalAmount"));
                                            }
                                        }
                                    }
                                }
                            }
                            //Added by Sivashankar KS on 27-Nov-2019 for Mobile eligibility changes received from HRTeam & SSC Team ends
                        }

                        // added by sandeepkn on 30Dec2019 for GHB FEEDBACK-- start
                        if (strGHBFeedbackSts.equalsIgnoreCase("True")) {
                            if (!formObject.getNGValue("GHBFeedbackflag").equalsIgnoreCase("Y")) {
                                CommonObj.writeToLog(2, "Guest House Feedback Form is Mandatory to claim your expenses. ==> ", winame);
                                throw new ValidatorException(new FacesMessage("Guest House Feedback Form is Mandatory to claim your expenses.", "btn_ghb_feedbk"));
                            }
                        }

                        if (strGHBFeedbackSts.equalsIgnoreCase("True")) {
                            CommonObj.writeToLog(2, "updateGHBFeedback starts ==> ", winame);
                            String updateGHBFeedback = "UPDATE EXT_GuestHouse_Feedback_Details SET WorkID='" + strGHBWorkID + "' , "
                                    + "EmployeeEmail=(SELECT EmpEmailID FROM EXT_GUESTHOUSE_OCCUPANCY_DETAILS_ACTIVE "
                                    + "WHERE PID='" + strGHBWorkID + " ') WHERE PraentPID='" + strprcsinstid + "'";
                            CommonObj.writeToLog(2, "updateGHBFeedback. ==> " + updateGHBFeedback, winame);
                            formObject.saveDataIntoDataSource(updateGHBFeedback);
                        }
                        // added by sandeepkn on 30Dec2019 for GHB FEEDBACK-- end

                        //Added by Sivashankar KS on 29-Aug-2019 Code to display Go-Air Feddback Link & Note ends here
                        if (strGoAirSts.equalsIgnoreCase("True")) {
                            if (!formObject.getNGValue("GoAirFlag").equalsIgnoreCase("Y")) {
                                throw new ValidatorException(new FacesMessage("GoAir Feedback Form is Mandatory to claim your expenses.", "btn_goair"));
                            }
                        }
                        //Loading RFA details before submitting the claim written by Sivashankar KS on 29-Oct-2019 starts
                        String Sapuserid = "";
                        String Request = formObject.getNGValue("RequestFor");
                        if (Request.equalsIgnoreCase("Others")) {
                            Sapuserid = formObject.getNGValue("EmployeeCode");
                        } else {
                            Sapuserid = formObject.getUserName();
                        }
                        String bapires = "";
                        if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") || strTypeofinvoice.equalsIgnoreCase("Travel Expense") || strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
                            writeToLog(2, "..........................stmt10..................... ", winame);
                            try {
                                CommonObj.writeToLog(2, "BAPI_EmployeeDetailsOnload calling", winame);
                                bapires = objSAPFunc.BAPI_EmployeeDetailsOnload(Sapuserid);
                                writeToLog(2, "..........................stmt13..................... ", winame);
                            } catch (Exception e) {
                                CommonObj.writeToLog(3, "Exception In BAPI_EmployeeDetailsOnload Click, ER_initiation=" + e.getMessage(), winame);
                            }
                            writeToLog(2, "..........................stmt11..................... ", winame);
                            if (bapires.equalsIgnoreCase("FAIL")) {
                                throw new ValidatorException(new FacesMessage("Please contact administrator.. Exception while fetching employee details", "TypeOfInvoice"));
                            } else if (!bapires.equalsIgnoreCase("") && !bapires.equalsIgnoreCase("SUCCESS")) {

                                throw new ValidatorException(new FacesMessage(bapires, "TypeOfInvoice"));
                            }
                            writeToLog(2, "..........................stmt12..................... ", winame);
                        } else if (strTypeofinvoice.equalsIgnoreCase("Employee Advances") || strTypeofinvoice.equalsIgnoreCase("Relocation") || strTypeofinvoice.equalsIgnoreCase("Self Education Scheme")) {
                            try {
                                writeToLog(2, "..........................stmt14..................... ", winame);
                                CommonObj.writeToLog(2, "BAPI_EmployeeDetailsOnloadHR calling", winame);
                                bapires = objSAPFunc.BAPI_EmployeeDetailsOnloadHR(Sapuserid);
                                CommonObj.writeToLog(2, "BAPI_EmployeeDetailsOnloadHR.. BAPI result==>> bapires :: " + bapires, winame);
                            } catch (Exception e) {
                                CommonObj.writeToLog(3, "Exception In BAPI_EmployeeDetailsOnloadHR Click, ER_initiation=" + e.getMessage(), winame);
                            }

                            if (bapires.equalsIgnoreCase("FAIL")) {
                                throw new ValidatorException(new FacesMessage("Please contact administrator.. Exception while fetching employee details", "TypeOfInvoice"));
                            } else if (!bapires.equalsIgnoreCase("") && !bapires.equalsIgnoreCase("SUCCESS")) {

                                throw new ValidatorException(new FacesMessage(bapires, "TypeOfInvoice"));
                            }

                        } else {
                            throw new ValidatorException(new FacesMessage("Please select valid type of invoice", "TypeOfInvoice"));
                        }
                        formObject.RaiseEvent("WFSave");
                        //Loading RFA details before submitting the claim written by Sivashankar KS on 29-Oct-2019 ends
                        writeToLog(1, " AmountCalc on btn_submit button click..... ", winame);
                        CommonObj.AmountCalc();
                        CommonObj.writeToLog(2, "Inside ngfuser:btn_submit>>>", winame);
                        String qryDuplicate = "";
                        String qryDuplicate1 = "";
                        String qryDuplicate2 = "";
                        String qryDuplicate3 = "";
                        writeToLog(2, "..........................stmt15..................... ", winame);
                        if (strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
                            CommonObj.mandatoryCheck(formObject, "Txt_MobilNo", "Please enter mobile no");
                            formObject.setNGValue("MobileNo", formObject.getNGValue("Txt_MobilNo"));

//                            if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant")) {
                            if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant/New Joinee")) {// Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram
                                CommonObj.mandatoryCheck(formObject, "OthrPasngr", "Please enter consultant OR new joinee name");
                            }

                            int Travel = formObject.getItemCount("list_travel");
                            if (Travel == 0) {
                                throw new ValidatorException(new FacesMessage("Please include travel request details into the travel request list", "list_travel"));
                            }
                            writeToLog(2, "..........................stmt16..................... ", winame);
                        } else if (strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {

                            if ((formObject.getNGValue("SubCategory1").equalsIgnoreCase("Salary Advance") || formObject.getNGValue("SubCategory1").equalsIgnoreCase("House Rent Advance") || formObject.getNGValue("SubCategory1").equalsIgnoreCase("Exceptional Advances"))
                                    && (!formObject.getNGValue("BankAcctStastus").trim().equalsIgnoreCase("L")) && ER_Initiation.strBankAccntStatus == false) {

                                ER_Initiation.strBankAccntStatus = true;
                                CommonObj.writeToLog(3, "Bank account details are not mapped with vendor code...\n ZLSCH values ::: " + formObject.getNGValue("BankAcctStastus").trim(), winame);
                                throw new ValidatorException(new FacesMessage("Please contact HR team to map bank account details with vendor code in SAP master... Close the window and submit the claim", ""));

                            }

                            qryDuplicate3 = "Select Count(ITEMINDEX) from EXT_AP with(nolock),wfinstrumenttable WITH (NOLOCK) where itemindex=var_rec_1 and VendorCode='" + formObject.getNGValue("VendorCode") + "' and SubCategory1='" + formObject.getNGValue("SubCategory1") + "' and "
                                    + "TypeOfInvoice='" + strTypeofinvoice + "' and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') and activityname not in ('Er_Initiation','Audit','Exit')";

                            CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate3, winame);
                            int dupCOUNT3 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate3));
                            CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT3, winame);
                            if (dupCOUNT3 >= 1) {
                                throw new ValidatorException(new FacesMessage("A request in process and hence cannot raise one more transaction", "list_travel"));
                            }
                            writeToLog(2, "..........................stmt17..................... ", winame);
                        } else if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
                            /*String diffDaysresult = "";
                             try {
                             diffDaysresult = CommonObj.diffDays(formObject.getNGValue("FromPeriod"), formObject.getNGValue("ToPeriod"));
                             } catch (ParseException ex) {
                             Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                             }
                             if (Integer.parseInt(diffDaysresult) >= 32) {
                             throw new ValidatorException(new FacesMessage("From Period and To Period can't be more than 31 days", "ToPeriod"));
                             }*/

                            String strApprvl = CommonObj.DB_QueryExecuteSelect1("SELECT Flag FROM EXT_ER_MASTER_APPRV90DAYS WITH (NOLOCK) WHERE EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice") + "'");
                            int diiffdays = 0;
                            try {
                                //diiffdays = Integer.parseInt(CommonObj.diffDays(strCurDate, formObject.getNGValue("BillDate")));
                                diiffdays = Integer.parseInt(CommonObj.diffDays(formObject.getNGValue("BillDate"), strCurDate));
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            writeToLog(2, "..........................stmt18..................... ", winame);
                            //Modified by Sivashankar KS on 22-Oct-2018 for Addinng validation to Travel Expense
                            //if ( strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {
                            //                    45DaysChange
                            Date strDate = new Date();
                            Date billDate = new Date();
                            String bilDate = formObject.getNGValue("BillDate");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            try {
                                strDate = sdf.parse(srtDate);
                                billDate = sdf.parse(bilDate);
                            } catch (Exception e) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, e);
                            }
//                    todayDate.before(futureDate)
                            String days = "";
                            if (billDate.before(strDate)) {
                                days = "90";
                            } else {
                                if (strActivityName.equalsIgnoreCase("Rework")) {
                                    days = "60";
                                } else {
                                    days = "45";
                                }
                            }
                            if (days.equalsIgnoreCase("45") && strActivityName.equalsIgnoreCase("ER_Initiation") && diiffdays > 45 && !strApprvl.equalsIgnoreCase("Y")) {
                                throw new ValidatorException(new FacesMessage("Bill date can not be more than 45 days...", ""));
                            } else if (days.equalsIgnoreCase("60") && strActivityName.equalsIgnoreCase("Rework") && diiffdays > 60 && !strApprvl.equalsIgnoreCase("Y")) {
                                throw new ValidatorException(new FacesMessage("Bill date can not be more than 60 days...", ""));
                            } else if ((strActivityName.equalsIgnoreCase("ER_Initiation") || strActivityName.equalsIgnoreCase("Rework")) && diiffdays > 92 && !strApprvl.equalsIgnoreCase("Y")) {

                                throw new ValidatorException(new FacesMessage("Bill date can not be more than 90 days...", ""));
                            } else {

                                qryDuplicate3 = "Select Count(ITEMINDEX) from EXT_AP with(nolock) where VendorCode='" + formObject.getNGValue("VendorCode") + "' and MBillNo='" + formObject.getNGValue("MBillNo") + "' and "
                                        + "TypeOfInvoice='" + strTypeofinvoice + "' and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                                CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate3, winame);
                                int dupCOUNT3 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate3));
                                CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT3, winame);

                                if (dupCOUNT3 >= 1) {
                                    CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                                    CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                                    throw new ValidatorException(new FacesMessage("Duplicate claim found with the same Bill Number.", "MBillNo"));

                                }
                                qryDuplicate1 = "Select Count(ITEMINDEX) from EXT_AP with(nolock) where VendorCode='" + formObject.getNGValue("VendorCode") + "' and MBillNo='" + formObject.getNGValue("MBillNo") + "' and TotalAmount='" + formObject.getNGValue("TotalAmount") + "' and "
                                        + "BillDate= convert(datetime,'" + formObject.getNGValue("BillDate") + "',103) and TypeOfInvoice='" + strTypeofinvoice + "' and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                                CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate1, winame);
                                int dupCOUNT = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate1));
                                CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT, winame);

                                if (dupCOUNT >= 1) {
                                    CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                                    CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                                    throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination:Mobile Number,BillDate and Total Amount", "MBillNo"));
                                    //throw new ValidatorException(new FacesMessage("Duplicate claim found and will not be allowed", "MBillNo"));

                                }

                                qryDuplicate2 = "Select Count(ITEMINDEX) from EXT_AP with(nolock) where VendorCode='" + formObject.getNGValue("VendorCode") + "' and FromPeriod=convert(datetime,'" + formObject.getNGValue("FromPeriod") + "',103) and "
                                        + "ToPeriod= convert(datetime,'" + formObject.getNGValue("ToPeriod") + "',103) and TypeOfInvoice='" + strTypeofinvoice + "' and WorkID IS NOT NULL and WorkID !='" + winame + "' and (RejectSts IS NULL OR RejectSts !='Y') AND CurrWorkstep is not null and CurrWorkstep !='Initiation'";

                                CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate2, winame);
                                int dupCOUNT2 = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate2));
                                CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT2, winame);

                                if (dupCOUNT2 >= 1) {
                                    CommonObj.writeToLog(2, "Duplicate claim found and will not be allowed", winame);
                                    CommonObj.writeToLog(3, "Duplicate claim found and will not be allowed", winame);
                                    throw new ValidatorException(new FacesMessage("Duplicate claim found with the combination: From Period and To Period", "MBillNo"));

                                }
                                //Added By Harinath on 2017/07/24
                                String strWorkId = "";

                                strWorkId = CommonObj.SelectQuery("select WorkId from EXT_AP WITH (NOLOCK) where VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') AND TypeOfInvoice='" + strTypeofinvoice + "' and CONVERT(date,'" + formObject.getNGValue("FromPeriod") + "',103) between convert(varchar(10),FromPeriod,126) and convert(varchar(10),ToPeriod,126) and WorkId !='" + winame + "'");
                                if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                                    throw new ValidatorException(new FacesMessage("Selected From date : " + formObject.getNGValue("FromPeriod") + " is already entered in other mobile claim... Transaction No : " + strWorkId + " ", "FromPeriod"));
                                }

                                strWorkId = CommonObj.SelectQuery("select WorkId from EXT_AP WITH (NOLOCK) where VendorCode='" + formObject.getNGValue("VendorCode") + "' and ER_IniSts!='Reject' and (RejectSts IS NULL OR RejectSts !='Y') AND TypeOfInvoice='" + strTypeofinvoice + "' and CONVERT(date,'" + formObject.getNGValue("ToPeriod") + "',103) between convert(varchar(10),FromPeriod,126) and convert(varchar(10),ToPeriod,126) and WorkId !='" + winame + "'");
                                if (!strWorkId.equalsIgnoreCase("") && !strWorkId.equalsIgnoreCase(null)) {
                                    throw new ValidatorException(new FacesMessage("Selected To date : " + formObject.getNGValue("ToPeriod") + " is already entered in other mobile claim... Transaction No : " + strWorkId + " ", "ToPeriod"));
                                }
                                //Ended By Harinath on 2017/07/24
                            }

                        } //else if (strTypeofinvoice.equalsIgnoreCase("Travel Expense") && (formObject.getNGValue("TicketExpense").equalsIgnoreCase("") || formObject.getNGValue("TicketExpense").equalsIgnoreCase("0.00"))){
                        /*else if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")) {
                         if (formObject.getNGValue("TypeOfTravel").equalsIgnoreCase("") || formObject.getNGValue("TypeOfTravel").equalsIgnoreCase("--Select--") ) {
                         throw new ValidatorException(new FacesMessage("Please select type of travel", "TypeOfTravel"));
                         }
                            
                         float trvlsum = (float) CommonObj.listViewColumnSum("list_travel", 9);
                         if (trvlsum == 0.00) {
                         throw new ValidatorException(new FacesMessage("Please include travel fare amount into the travel fare list", "txt_trvl_amnt"));
                         }

                         }*/ else if (strSubcategory.equalsIgnoreCase("Travel Expense")) {
                            writeToLog(2, "..........................stmt19..................... ", winame);
                            if (formObject.getNGValue("TypeOfTravel").equalsIgnoreCase("") || formObject.getNGValue("TypeOfTravel").equalsIgnoreCase("--Select--")) {
                                throw new ValidatorException(new FacesMessage("Please select Type of travel", "TypeOfTravel"));
                            }

                            float trvlsum = (float) CommonObj.listViewColumnSum("list_travel", 9);
                            if (trvlsum == 0.00) {
                                throw new ValidatorException(new FacesMessage("Please include travel fare amount into the travel fare list", "txt_trvl_amnt"));
                            }

                            int Travel = formObject.getItemCount("list_travel");
                            int Hotel = formObject.getItemCount("list_hotel");
                            int DailyAllow = formObject.getItemCount("list_daily");
                            int Convey = formObject.getItemCount("list_convey");
                            int Misc = formObject.getItemCount("list_misc");

                            /*if ((Travel == 0) && (Hotel == 0) && (DailyAllow == 0) && (Convey == 0) && (Misc == 0)) {
                             throw new ValidatorException(new FacesMessage("Please add atleast one expense", "list_travel"));
                             }
                             if ((Hotel == 0) && (DailyAllow == 0)) {
                             throw new ValidatorException(new FacesMessage("Please add atleast one hotel/daily expense", "list_hotel"));
                             }
                             if (Hotel != 0) {
                             if (DailyAllow == 0) {
                             //return true;
                             } else {
                             throw new ValidatorException(new FacesMessage("Daily Allowance is not allowed", "list_travel"));
                             }
                             }*/
                        }/*else if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
                         if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("Transfer") ) {
                         throw new ValidatorException(new FacesMessage("No value is present in SAP for the date of transfer", "TypeOfTravel"));
                         }
                         }*/ else if (strSubcategory.equalsIgnoreCase("Joining Expense")) {
                            int Travel = formObject.getItemCount("list_travel");
                            int Hotel = formObject.getItemCount("list_hotel");
                            int Convey = formObject.getItemCount("list_convey");
                            int Medical = formObject.getItemCount("list_medical");

                            //Modified By Harinatha R on 2017/05/18
                            /*
                             if (Travel == 0) {
                             throw new ValidatorException(new FacesMessage("Kindly add atleast one travel fare details", "list_travel"));
                             }
                             if (Hotel == 0) {
                             throw new ValidatorException(new FacesMessage("Kindly add atleast one hotel fare details", "list_hotel"));
                             }
                             //Ended By Harinatha R on 2017/05/18
                            
                             */
 /*if (Convey == 0) {
                             throw new ValidatorException(new FacesMessage("Kindly add atleast one conveyance fare details", "list_convey"));
                             }
                             if (Medical == 0) {
                             throw new ValidatorException(new FacesMessage("KINDLY ADD ATLEAST ONE MEDICAL DETAILS", "list_medical"));
                             }*/
                        } /*else if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {
                            
                         int Hotel = formObject.getItemCount("list_hotel");
                         int DailyAllow = formObject.getItemCount("list_daily");
                         int Convey = formObject.getItemCount("list_convey");
                         int Misc = formObject.getItemCount("list_misc");

                         if (Hotel == 0) 
                         {
                         if (DailyAllow == 0)
                         {
                         throw new ValidatorException(new FacesMessage("Kindly add atleast one hotel or Daily Allowance details", "list_hotel"));
                         }
                         }
                         if (DailyAllow == 0) {
                         if (Hotel == 0) {
                         throw new ValidatorException(new FacesMessage("Kindly add atleast one hotel or Daily Allowance details", "list_daily"));
                         }
                         }
                         /*if (Convey == 0) {
                         throw new ValidatorException(new FacesMessage("KINDLY ADD ATLEAST ONE CONVEYANCE DETAILS", "list_convey"));
                         }
                         if (Misc == 0) {
                         throw new ValidatorException(new FacesMessage("KINDLY ADD ATLEAST ONE MISCELLANEOUS DETAILS", "list_misc"));
                         }
                         }*/ else if (strSubcategory.equalsIgnoreCase("Out of Pocket Expense") || strSubcategory.equalsIgnoreCase("Relocation-Travel Expense") || (strSubcategory.equalsIgnoreCase("Relocation-TravelExpense-Own Vehicle"))) {
                            int FamilyInfo = formObject.getItemCount("list_family");
                            int Travel = formObject.getItemCount("list_travel");
                            int DailyAllow = formObject.getItemCount("list_daily");
                            int Convey = formObject.getItemCount("list_convey");
                            int Misc = formObject.getItemCount("list_misc");

                            //Modified By Harinatha R on 2017/07/28
                            /*
                             if (FamilyInfo == 0) {
                             throw new ValidatorException(new FacesMessage("Kindly add alteast one family details", "list_family"));
                             }
                             */
                            //Ended By Harinatha R on 2017/07/28
                            //Modified By Harinatha R on 2017/05/18
                            /*
                             if (Travel == 0) {
                             throw new ValidatorException(new FacesMessage("Kindly add atleast one travel fare details", "list_travel"));
                             }*/
                            //Ended By Harinatha R on 2017/05/18
                            /*if (DailyAllow == 0) {
                             throw new ValidatorException(new FacesMessage("Kindly add atleast one Daily Allowance details", "list_daily"));
                             }
                             if (Convey == 0) {
                             throw new ValidatorException(new FacesMessage("KINDLY ADD ATLEAST ONE CONVEYANCE DETAILS", "list_convey"));
                             }
                             if (Misc == 0) {
                             throw new ValidatorException(new FacesMessage("KINDLY ADD ATLEAST ONE MISCELLANEOUS DETAILS", "list_misc"));
                             }*/
                        } else if (strSubcategory.equalsIgnoreCase("Self Education Scheme") || strSubcategory.equalsIgnoreCase("Entertainment") || strSubcategory.equalsIgnoreCase("Others") || strSubcategory.equalsIgnoreCase("GIFT & COMPLIMENTARY")) {
                            int Entertainment = formObject.getItemCount("list_Entertain");
                            if (Entertainment == 0) {
                                throw new ValidatorException(new FacesMessage("Kindly add atleast one entry", "list_Entertain"));
                            }
                        }

                        //Added By Harinath on 2017/03/21
                        if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
                            if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("New Joinee")) {
                                String joinDate = formObject.getNGValue("DateOfJoining");
                                //Added By Harinatha R on 2017/05/26
                                if (!joinDate.equalsIgnoreCase("")) {
                                    Long noOfDays = CommonObj.getNoOfDaysFromCurDate(joinDate);
//                                    if (noOfDays > 365) {
                                    if (noOfDays > 600) {//Exceptional case with Business approval
                                        throw new ValidatorException(new FacesMessage("User cannot apply for Brokerage Fee after 365 days of the Joining", "TypeOfTransfer"));
                                    }
                                } else {
                                    throw new ValidatorException(new FacesMessage("Contact HR to update Date of Joining", "DateOfJoining"));
                                }
                                //Ended By Harinatha R on 2017/05/26
                            }
                            if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("Transfer")) {
                                String trnsfrDate = formObject.getNGValue("DateOfTransfer");
                                //Added By Harinatha R on 2017/05/26
                                if (!trnsfrDate.equalsIgnoreCase("")) {
                                    Long noOfDays = CommonObj.getNoOfDaysFromCurDate(trnsfrDate);
//                                    if (noOfDays > 365) {
                                    if (noOfDays > 600) {//Exceptional case with Business approval
                                        throw new ValidatorException(new FacesMessage("User cannot apply for Brokerage Fee after 365 days of the transfer", "TypeOfTransfer"));
                                    }
                                } else {
                                    throw new ValidatorException(new FacesMessage("Contact HR to update Date of Transfer", "DateOfTransfer"));
                                }
                                //Ended By Harinatha R on 2017/05/26
                            }

                            //Added By Harinatha R on 2017/09/20
                            if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("Confirmation") && !formObject.getNGValue("DateOfConfirm").equalsIgnoreCase("")) {
                                String confrmDate = formObject.getNGValue("DateOfConfirm");

                                if (!confrmDate.equalsIgnoreCase("")) {

                                    Long noOfDays = CommonObj.getNoOfDaysFromCurDate(confrmDate);
                                    if (noOfDays > 365) {
                                        throw new ValidatorException(new FacesMessage("User cannot apply for Brokerage Fee after 365 days of the transfer", "TypeOfTransfer"));
                                    }
                                }
                            } else if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("Confirmation") && formObject.getNGValue("DateOfConfirm").equalsIgnoreCase("")) {

                                throw new ValidatorException(new FacesMessage("Please contact HR to update Date of Confirmation", "DateOfConfirm"));
                            }
                            //Ended By Harinatha R on 2017/09/20
                        }
                        writeToLog(2, "..........................stmt21..................... ", winame);
                        if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {
                            if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("New Joinee")) {
                                String joinDate = formObject.getNGValue("DateOfJoining");
                                //Added By Harinatha R on 2017/05/26
                                if (!joinDate.equalsIgnoreCase("")) {
                                    Long noOfDays = CommonObj.getNoOfDaysFromCurDate(joinDate);
                                    if (noOfDays > 365) {
                                        throw new ValidatorException(new FacesMessage("User cannot apply for Brokerage Fee after 365 days of the Joining", "TypeOfTransfer"));
                                    }
                                } else {
                                    throw new ValidatorException(new FacesMessage("Contact HR to update Date of Joining", "DateOfJoining"));
                                }
                                //Ended By Harinatha R on 2017/05/26
                            }
                            if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("Transfer")) {
                                String trnsfrDate = formObject.getNGValue("DateOfTransfer");
                                //Added By Harinatha R on 2017/05/26
                                if (!trnsfrDate.equalsIgnoreCase("")) {
                                    Long noOfDays = CommonObj.getNoOfDaysFromCurDate(trnsfrDate);
                                    if (noOfDays > 365) {
                                        throw new ValidatorException(new FacesMessage("User cannot apply for Brokerage Fee after 365 days of the transfer", "TypeOfTransfer"));
                                    }
                                } else {
                                    throw new ValidatorException(new FacesMessage("Contact HR to update Date of Transfer", "DateOfTransfer"));
                                }
                                //Ended By Harinatha R on 2017/05/26
                            }
                            //Added By Harinatha R on 2017/09/20
                            if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("Confirmation") && !formObject.getNGValue("DateOfConfirm").equalsIgnoreCase("")) {

                                String confrmDate = formObject.getNGValue("DateOfConfirm");
                                if (!confrmDate.equalsIgnoreCase("")) {

                                    Long noOfDays = CommonObj.getNoOfDaysFromCurDate(confrmDate);
                                    if (noOfDays > 365) {
                                        throw new ValidatorException(new FacesMessage("User cannot apply for Brokerage Fee after 365 days of the transfer", "TypeOfTransfer"));
                                    }
                                }
                            } else if (formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("Confirmation") && formObject.getNGValue("DateOfConfirm").equalsIgnoreCase("")) {

                                throw new ValidatorException(new FacesMessage("Please contact HR to update Date of Confirmation", "DateOfConfirm"));
                            }
                            //Ended By Harinatha R on 2017/09/20
                        }

                        if (strSubcategory.equalsIgnoreCase("House Rent Advance")) {
                            /*
                             String joinDate = formObject.getNGValue("Txt_DOJ");
                             Long noOfDays = CommonObj.getNoOfDaysFromCurDate(joinDate);
                             if (noOfDays > 365) {
                             throw new ValidatorException(new FacesMessage("User cannot apply for House Rent Advance after 365 days of the Joining", "TypeOfTransfer"));
                             }
                             */

                            CommonObj.mandatoryCheck(formObject, "TypeOfTransfer1", "Please select type of transfer");

                            if (formObject.getNGValue("TypeOfTransfer1").equalsIgnoreCase("New Joinee")) {
                                String joinDate = formObject.getNGValue("Txt_DOJ");

                                if (!joinDate.equalsIgnoreCase("")) {
                                    Long noOfDays = CommonObj.getNoOfDaysFromCurDate(joinDate);
                                    if (noOfDays > 365) {
                                        throw new ValidatorException(new FacesMessage("User cannot apply for House Rent Advance after 365 days of the Joining", "TypeOfTransfer"));
                                    }
                                } else {
                                    throw new ValidatorException(new FacesMessage("Contact HR to update Date of Joining", "DateOfJoining"));
                                }

                            }

                            if (formObject.getNGValue("TypeOfTransfer1").equalsIgnoreCase("Transfer")) {
                                String trnsfrDate = formObject.getNGValue("Txt_DOT");

                                if (!trnsfrDate.equalsIgnoreCase("")) {
                                    Long noOfDays = CommonObj.getNoOfDaysFromCurDate(trnsfrDate);
                                    if (noOfDays > 365) {
                                        throw new ValidatorException(new FacesMessage("User cannot apply for House Rent Advance after 365 days of the transfer", "TypeOfTransfer"));
                                    }
                                } else {
                                    throw new ValidatorException(new FacesMessage("Contact HR to update Date of Transfer", "DateOfTransfer"));
                                }

                            }

                        }

                        //Ended By Harinath on 2017/03/21
                        if (formObject.getNGValue("SAPApprovers").equalsIgnoreCase("") && formObject.getNGValue("MDCheck").equalsIgnoreCase("False")) {
                            throw new ValidatorException(new FacesMessage("Approvers names not found for the transaction", ""));
                        }
                        if (formObject.getNGValue("SAPApproversGr").equalsIgnoreCase("") && formObject.getNGValue("MDCheck").equalsIgnoreCase("False")) {
                            throw new ValidatorException(new FacesMessage("Approvers grades not found for the transaction", ""));
                        }

                        formObject.setNGValue("InitSts", "ER");
                        if (formObject.getNGValue("Comments").equalsIgnoreCase("")) {
                            throw new ValidatorException(new FacesMessage("Please Enter the Comments", "Comments"));
                        }

                        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
                        if (WorkstepName.equalsIgnoreCase("Rework")) {
                            //Added By Harinatha R on 2017/07/04 NOTE : To route transactions directly to HR Dept with out reporting manager approval for the below typeof invoice or subcatergories
                            //Added By Harinatha R on 2017/07/10 NOTE : To route transaction from Rework to Parking stage directly to avoid delay in processeing minor changes
                            if (formObject.getNGValue("ParkSts").equalsIgnoreCase("Exception")) {
                                formObject.setNGValue("ER_IniSts", "Park");
                            }//Ended By Harinatha R on 2017/07/10 
                            //Added By Harinatha R on 2017/07/16 NOTE : To route transactions directly to Parking stage when claims raised for Vice President or Managing Director grades 
                            else if ((Grade1.equalsIgnoreCase("Vice President") || Grade1.equalsIgnoreCase("Managing Director")) && !strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
                                formObject.setNGValue("ER_IniSts", "SelfApprovedPark");
                            }//Ended By Harinatha R on 2017/07/16
                            else {
                                if (strTypeofinvoice.equalsIgnoreCase("Relocation") /*|| strSubcategory.equalsIgnoreCase("Salary Advance") || strSubcategory.equalsIgnoreCase("House Rent Advance")
                                         || strSubcategory.equalsIgnoreCase("Exceptional Advances")*/) {

                                    formObject.setNGValue("ER_IniSts", "HR");
                                } else if (strSubcategory.equalsIgnoreCase("Salary Advance") || strSubcategory.equalsIgnoreCase("House Rent Advance")
                                        || strSubcategory.equalsIgnoreCase("Exceptional Advances")) {

                                    formObject.setNGValue("ER_IniSts", "HeadHR");
                                } else if ((formObject.getNGValue("ParkSts").equalsIgnoreCase("Exception") && WorkstepName1.equalsIgnoreCase("Rework")) && (strTypeofinvoice.equalsIgnoreCase("Relocation") || strTypeofinvoice.equalsIgnoreCase("Employee Advances") /* strSubcategory.equalsIgnoreCase("Salary Advance") || strSubcategory.equalsIgnoreCase("House Rent Advance")
                                         || strSubcategory.equalsIgnoreCase("Exceptional Advances")*/)) {

                                    formObject.setNGValue("ER_IniSts", "Park");
                                } else {
                                    formObject.setNGValue("ER_IniSts", "Yes");
                                }
                            }
                            //Added by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period
                            if (!formObject.getNGValue("ResigDate").equalsIgnoreCase("") || !formObject.getNGValue("LastWorkngDate").equalsIgnoreCase("")) {

                                formObject.saveDataIntoDataSource("Update WFINSTRUMENTTABLE set PriorityLevel=4 where processInstanceId='" + strprcsinstid + "'");
                            }
                            //Ended by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period                                                      
                            //Ended By Harinatha R on 2017/07/04  
                        }

                        //Get the Initiator Email ID
                        if (formObject.getNGValue("Initiatoremail").equalsIgnoreCase("")) {
                            CommonObj.getInitiatorMailId(formObject.getUserName());
                        }

                        if ((formObject.getNGValue("SAPApprovers").equalsIgnoreCase("") || formObject.getNGValue("SAPApprovers").contains("admin") || formObject.getNGValue("SAPApprovers").contains("NoEntry")) && formObject.getNGValue("MDCheck").equalsIgnoreCase("False")) {
                            throw new ValidatorException(new FacesMessage("Approvers user id not present in DMS...!!!", ""));
                        }
                        if ((formObject.getNGValue("SAPApproversGr").equalsIgnoreCase("") || formObject.getNGValue("SAPApproversGr").contains("NoEntry")) && formObject.getNGValue("MDCheck").equalsIgnoreCase("False")) {
                            throw new ValidatorException(new FacesMessage("Approvers Grade not present in DMS...!!!", ""));
                        }

                        CommonObj.writeToLog(2, "Before SAP read call..", winame);
                        //ojt_Apprvl.SapReadXml(); 
                        //objSAPApprovalMatrix.BAPI_ERApprovalMatrix(formObject.getUserName());//Added by NanjundaMoorthy for BAPI Calls
//                        boolean bAppmatrixResult=objSAPApprovalMatrix.ERApprovalMatrix(formObject.getUserName());//Added by NanjundaMoorthy for BAPI Calls
//                        if(bAppmatrixResult==false){
//                            throw new ValidatorException(new FacesMessage("Exception in approval matrix calculation...!!!", "Comments"));
//                        }  
                        //sApprvalMatrixCheck=objSAPApprovalMatrix.ERApprovalMatrix(formObject.getUserName());//Added by NanjundaMoorthy for BAPI Calls
                        writeToLog(2, "..........................stmt21..................... ", winame);
                        sApprvalMatrixCheck = objApprovalMatrix_ER.ApprovalMatrixER(formObject.getUserName());//Added by NanjundaMoorthy for BAPI Calls
                        CommonObj.writeToLog(2, "sApprvalMatrixCheck:" + sApprvalMatrixCheck, winame);
                        if (formObject.getNGValue("MDCheck").equalsIgnoreCase("False") && (sApprvalMatrixCheck == null || !sApprvalMatrixCheck.equalsIgnoreCase("S"))) {
                            CommonObj.writeToLog(2, "sApprvalMatrixCheck result !=SUCCESS in ER_Initiation.java@btn_submit:" + sApprvalMatrixCheck, winame);
                            throw new ValidatorException(new FacesMessage("Exception in approval matrix calculation...!!!\nError Message:" + sApprvalMatrixCheck, ""));
                        }
                        CommonObj.writeToLog(2, "After SAP read call", winame);
                        writeToLog(2, "..........................stmt22..................... ", winame);

                        //Added by sandeepKn on 10Jan2020 for ASFi and SFIC changes Approval matrix -- Start
                        //need to write code for SFIC and ASFI to do approval matrix calculation starts 27-Nov-2019
                        if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                            writeToLog(2, "..........................stmt23..................... ", winame);
                            CommonObj.writeToLog(2, " Travel Expenses - ASFI and SFIC ", winame);
                            String strEligibleAmt = "0.0";
                            String strQryEligibleAmt = "";
                            String strHotelEligibleAmt = "0.0";
                            String strQryHotelEligibleAmt = "";
                            String strOtherExpEligibleAmt = "0.0";
                            String strQryOtherExpEligibleAmt = "";
                            String qryClaimedlimit = "";
                            Float fTotal1 = .20f;
                            int hotel_noofnightsval = 0;
                            float hotel_totamountval = 0.0f;
                            float hotel_acteligibletotamountval = 0.0f;
                            int oe_noofdaysval = 0;
                            float oe_totamountval = 0.0f;
                            float oe_acteligibletotamountval = 0.0f;
                            String hotel_strMaxAppLevel1 = "";
                            String oe_strMaxAppLevel1 = "";
                            String strMaxAppLevel1 = "";
                            if (formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Travel Expense")
                                    && formObject.getNGValue("SubCategory1").equalsIgnoreCase("Travel Expense")) {
                                //Hotel starts
                                writeToLog(2, "..........................stmt24..................... ", winame);
                                int list_hotel = formObject.getItemCount("list_hotel");
                                CommonObj.writeToLog(2, "list_hotel Count:" + list_hotel, winame);
                                List<List<String>> list_hotelObject = CommonObj.getListViewValueInList(formObject, "list_hotel");
                                CommonObj.writeToLog(2, "list_hotelObject==" + list_hotelObject, winame);
                                CommonObj.writeToLog(2, "list_hotelObject Count:" + list_hotelObject.size(), winame);
                                String hotel_location = "";
                                String hotel_strCountry = "";
                                String hotel_strLocAr[] = null;
                                writeToLog(2, "..........................stmt24..................... ", winame);
                                if (list_hotel > 0) {
                                    for (Integer i = 0; i < list_hotelObject.size(); i++) {
                                        String HotellLineItemData[] = CommonObj.getRowValue(formObject, "list_hotel", i);
                                        String sValue0 = list_hotelObject.get(i).get(0).trim();
                                        String sValue15 = HotellLineItemData[15].trim();
                                        String sValue21 = HotellLineItemData[21].trim();
                                        String sValue22 = HotellLineItemData[22].trim();
                                        String sValue23 = HotellLineItemData[23].trim();
                                        CommonObj.writeToLog(2, "list_hotel: sValue15:" + sValue15, winame);
                                        CommonObj.writeToLog(2, "list_hotel: sValue21:" + sValue21, winame);
                                        CommonObj.writeToLog(2, "list_hotel: sValue22:" + sValue22, winame);
                                        CommonObj.writeToLog(2, "list_hotel: sValue23:" + sValue23, winame);
                                        hotel_noofnightsval = Integer.parseInt(sValue22);
                                        if (hotel_noofnightsval == 0) {
                                            hotel_noofnightsval = 1;
                                        }
//                                        hotel_totamountval += (Float.parseFloat(sValue15)) * (hotel_noofnightsval);
                                        hotel_totamountval += (Float.parseFloat(sValue15));//Modified on 17-Mar-21 as sValue15 contains total amount of no.of days. Hence no need to multiply again to calculate
                                        hotel_location = sValue23;
                                        CommonObj.writeToLog(2, "list_hotel: location:" + hotel_location, winame);
                                        hotel_strLocAr = sValue23.split("-");
                                        hotel_strCountry = hotel_strLocAr[0];
                                        //sandeep 02Dec2019
                                        strQryHotelEligibleAmt = "SELECT TOP 1 claimlimit FROM EXT_AP_ER_DubaiOman_ClaimLimit WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' AND TypeofInvoice='" + strTypeofinvoice + "' AND Subcategory1='Hotel Expense' AND Grade='" + formObject.getNGValue("Grade") + "' AND Country=(SELECT DISTINCT(FL.Region) FROM EXT_AP_ER_DubaiOman_ClaimLimit DO INNER JOIN EXT_FromLoc FL ON DO.CompanyCode=FL.CompanyCode WHERE FL.location='" + sValue23 + "')";
                                        strHotelEligibleAmt = CommonObj.DB_QueryExecuteSelect1(strQryHotelEligibleAmt);
                                        hotel_acteligibletotamountval += (Float.parseFloat(strHotelEligibleAmt)) * (hotel_noofnightsval);
                                    }
                                }
                                //Hotel ends
                                writeToLog(2, "..........................stmt25..................... ", winame);
                                //Other starts
                                int list_otherexpense = formObject.getItemCount("list_OtherExpenses");
                                CommonObj.writeToLog(2, "list_OtherExpenses Count:" + list_otherexpense, winame);
                                List<List<String>> list_OtherExpensesObject = CommonObj.getListViewValueInList(formObject, "list_OtherExpenses");
                                CommonObj.writeToLog(2, "list_OtherExpensesObject==" + list_OtherExpensesObject, winame);
                                CommonObj.writeToLog(2, "list_OtherExpensesObject Count:" + list_OtherExpensesObject.size(), winame);
                                String location = "";
                                String strCountry = "";
                                String strLocAr[] = null;
                                if (list_otherexpense > 0) {
                                    for (Integer i = 0; i < list_OtherExpensesObject.size(); i++) {
                                        String OtherExpensesLineItemData[] = CommonObj.getRowValue(formObject, "list_OtherExpenses", i);
                                        String sValue0 = list_OtherExpensesObject.get(i).get(0).trim();
                                        String sValue4 = OtherExpensesLineItemData[4].trim();
                                        String sValue5 = OtherExpensesLineItemData[5].trim();
                                        String sValue10 = OtherExpensesLineItemData[10].trim();
                                        CommonObj.writeToLog(2, "list_OtherExpenses: sValue4:" + sValue4, winame);
                                        CommonObj.writeToLog(2, "list_OtherExpenses: sValue5:" + sValue5, winame);
                                        CommonObj.writeToLog(2, "list_OtherExpenses: sValue10:" + sValue10, winame);
                                        oe_noofdaysval = Integer.parseInt(sValue5);
                                        CommonObj.writeToLog(2, "list_OtherExpenses: oe_noofdaysval:" + oe_noofdaysval, winame);
                                        if (oe_noofdaysval == 0) {
                                            oe_noofdaysval = 1;
                                        }
//                                        oe_totamountval += (Float.parseFloat(sValue10)) * (oe_noofdaysval);
                                        oe_totamountval += (Float.parseFloat(sValue10));//Modified on 17-Mar-21 as sValue10 contains total amount of no.of days. Hence no need to multiply again to calculate
                                        location = sValue4;
                                        CommonObj.writeToLog(2, "list_OtherExpenses: location:" + location, winame);
                                        strLocAr = sValue4.split("-");
                                        strCountry = strLocAr[0];
                                        //sandeep on 02Dec2019
                                        strQryOtherExpEligibleAmt = "SELECT TOP 1 claimlimit FROM EXT_AP_ER_DubaiOman_ClaimLimit WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' AND TypeofInvoice='" + strTypeofinvoice + "' AND Subcategory1='Other Expenses' AND Grade='" + formObject.getNGValue("Grade") + "' AND Country=(SELECT DISTINCT(FL.Region) FROM EXT_AP_ER_DubaiOman_ClaimLimit DO INNER JOIN EXT_FromLoc FL ON DO.CompanyCode=FL.CompanyCode WHERE FL.location='" + sValue4 + "')";
                                        strOtherExpEligibleAmt = CommonObj.DB_QueryExecuteSelect1(strQryOtherExpEligibleAmt);
                                        oe_acteligibletotamountval += (Float.parseFloat(strOtherExpEligibleAmt)) * (oe_noofdaysval);
                                    }
                                }
                                //Other ends
                                //Hotel & Other approval calculation starts
                                Float hotel_str20PerElig = 0.0f;
                                hotel_str20PerElig = ((hotel_acteligibletotamountval * fTotal1) + hotel_acteligibletotamountval);
                                CommonObj.writeToLog(2, "hotel_noofnightsval:" + hotel_noofnightsval, winame);
                                CommonObj.writeToLog(2, "hotel_acteligibletotamountval:" + hotel_acteligibletotamountval, winame);
                                CommonObj.writeToLog(2, "str20PerElig:" + hotel_str20PerElig, winame);
                                CommonObj.writeToLog(2, "hotel_totamountval:" + hotel_totamountval, winame);
                                if (hotel_totamountval <= hotel_acteligibletotamountval) {
//                                    formObject.setNGValue("MaxAppLevel", "1");
                                    hotel_strMaxAppLevel1 = "1";
                                } else if (hotel_totamountval > hotel_acteligibletotamountval && hotel_totamountval <= hotel_str20PerElig) {
//                                    formObject.setNGValue("MaxAppLevel", "3");
                                    hotel_strMaxAppLevel1 = "2";
                                } else if (hotel_totamountval > hotel_str20PerElig) {
//                                    formObject.setNGValue("MaxAppLevel", "4");
                                    hotel_strMaxAppLevel1 = "3";
                                }
                                CommonObj.writeToLog(2, "hotel_strMaxAppLevel1:" + hotel_strMaxAppLevel1, winame);
                                Float oe_str20PerElig = 0.0f;
                                oe_str20PerElig = ((oe_acteligibletotamountval * fTotal1) + oe_acteligibletotamountval);
                                CommonObj.writeToLog(2, "oe_noofdaysval:" + oe_noofdaysval, winame);
                                CommonObj.writeToLog(2, "oe_acteligibletotamountval:" + oe_acteligibletotamountval, winame);
                                CommonObj.writeToLog(2, "str20PerElig:" + oe_str20PerElig, winame);
                                CommonObj.writeToLog(2, "oe_totamountval:" + oe_totamountval, winame);
                                if (oe_totamountval <= oe_acteligibletotamountval) {
//                                    formObject.setNGValue("MaxAppLevel", "1");
                                    oe_strMaxAppLevel1 = "1";
                                } else if (oe_totamountval > oe_acteligibletotamountval && oe_totamountval <= oe_str20PerElig) {
//                                    formObject.setNGValue("MaxAppLevel", "3");
                                    oe_strMaxAppLevel1 = "2";
                                } else if (oe_totamountval > oe_str20PerElig) {
//                                    formObject.setNGValue("MaxAppLevel", "4");
                                    oe_strMaxAppLevel1 = "3";
                                }
                                CommonObj.writeToLog(2, "oe_strMaxAppLevel1:" + oe_strMaxAppLevel1, winame);
                                if (Integer.parseInt(hotel_strMaxAppLevel1) > Integer.parseInt(oe_strMaxAppLevel1)) {
                                    strMaxAppLevel1 = hotel_strMaxAppLevel1;
                                } else {
                                    strMaxAppLevel1 = oe_strMaxAppLevel1;
                                }
                                CommonObj.writeToLog(2, "strMaxAppLevel1:" + strMaxAppLevel1, winame);
                                formObject.setNGValue("MaxAppLevel", strMaxAppLevel1);
//                                formObject.RaiseEvent("WFDOne");

                                //Hotel & Other approval calculation ends
                            } else if (formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Mobile Re-Imbursements")
                                    && formObject.getNGValue("SubCategory1").equalsIgnoreCase("Mobile Re-Imbursements")) {
                                writeToLog(2, "..........................stmt26..................... ", winame);
                                String sTotalAmount = formObject.getNGValue("TotalAmount");
                                Float fTotal = 0.0f;
                                if (!sTotalAmount.equalsIgnoreCase("")) {
                                    fTotal = Float.parseFloat(sTotalAmount);
                                }
//                                strQryEligibleAmt = "SELECT Claimlimit FROM EXT_AP_ER_ClaimLimit with(nolock) WHERE Grade='" + formObject.getNGValue("Grade") + "' and Subcategory1='" + strSubcategory + "' AND CompanyCode='" + formObject.getNGValue("CompanyCode") + "'";
                                strQryEligibleAmt = "SELECT TOP 1 claimlimit FROM EXT_AP_ER_ClaimLimit WITH(nolock) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' AND TypeofInvoice='" + strTypeofinvoice + "' AND Subcategory1='" + strSubcategory + "' AND Grade='" + formObject.getNGValue("Grade") + "'";
                                strEligibleAmt = CommonObj.DB_QueryExecuteSelect1(strQryEligibleAmt);
                                Float str20PerElig = (Float.parseFloat(strEligibleAmt) * fTotal1) + Float.parseFloat(strEligibleAmt);
                                CommonObj.writeToLog(2, "strEligibleAmt:" + strEligibleAmt, winame);
                                CommonObj.writeToLog(2, "str20PerElig:" + str20PerElig, winame);
                                CommonObj.writeToLog(2, "fTotal:" + fTotal, winame);
                                if (fTotal <= Float.parseFloat(strEligibleAmt)) {
                                    formObject.setNGValue("MaxAppLevel", "1");
                                } else if (fTotal > Float.parseFloat(strEligibleAmt) && fTotal <= str20PerElig) {
                                    formObject.setNGValue("MaxAppLevel", "2");
                                } else if (fTotal > str20PerElig) {
                                    formObject.setNGValue("MaxAppLevel", "3");
                                }
                            }
                        }
                        //need to write code for SFIC and ASFI to do approval matrix calculation ends

                        //Added by sandeepKn on 10Jan2020 for ASFi and SFIC changes Approval matrix -- END
                        //Below code added for approver matrix 
                        //CurrAppLevel
                        //Integer Cur_Appr_Lvl=0;
                        Integer Max_Appr_Lvl = 0;
                        //Cur_Appr_Lvl=Integer.parseInt(formObject.getNGValue("CurrAppLevel"));
                        Max_Appr_Lvl = Integer.parseInt(formObject.getNGValue("MaxAppLevel"));
                        CommonObj.writeToLog(2, "Max Appr_Level=" + Max_Appr_Lvl, winame);
                        writeToLog(2, "..........................stmt27..................... ", winame);
                        if (Max_Appr_Lvl >= 1) //App1index
                        {
                            CommonObj.writeToLog(2, "Inside app matrix", winame);
                            if (formObject.getNGValue("App1index") != null && !formObject.getNGValue("App1index").equalsIgnoreCase("NoEntry")) {
                                formObject.setNGValue("ApprSts1", "Approved");
                                writeToLog(2, "..........................stmt28..................... ", winame);
                                //Added By Harinatha R on 2017/05/18 NOTE : To do the self approval for Vice President and Manager Grade I Whem Type of Invoice is "Travel Requets"
                                if (strTypeofinvoice.equalsIgnoreCase("Travel Request") && WorkstepName1.equalsIgnoreCase("ER_Initiation")) {
                                    if (Grade1.equalsIgnoreCase("Vice President") || Grade1.equalsIgnoreCase("Manager Grade I") || Grade1.equalsIgnoreCase("Managing Director")) {
                                        formObject.setNGValue("ER_IniSts", "SelfApproved");
                                    } else {
                                        formObject.setNGValue("ER_IniSts", "Yes");
                                    }
                                    //Added By Harinatha R on 2017/07/04 NOTE : To route transactions directly to HR Dept with out reporting manager approval for the below typeof invoice or subcatergories
                                }//Added By Harinatha R on 2017/07/16 NOTE : To route transactions directly to Parking stage when claims raised for Vice President or Managing Director grades                                 
                                else if (Grade1.equalsIgnoreCase("Vice President") || Grade1.equalsIgnoreCase("Managing Director")) {
                                    formObject.setNGValue("ER_IniSts", "SelfApprovedPark");
                                }//Ended By Harinatha R on 2017/07/16 
                                else if ((formObject.getNGValue("ParkSts").equalsIgnoreCase("Exception") && WorkstepName1.equalsIgnoreCase("Rework")) && (strTypeofinvoice.equalsIgnoreCase("Relocation") || strTypeofinvoice.equalsIgnoreCase("Employee Advances") /* strSubcategory.equalsIgnoreCase("Salary Advance") || strSubcategory.equalsIgnoreCase("House Rent Advance")
                                         || strSubcategory.equalsIgnoreCase("Exceptional Advances")*/)) {

                                    formObject.setNGValue("ER_IniSts", "Park");
                                } else if (formObject.getNGValue("ParkSts").equalsIgnoreCase("Exception") && WorkstepName1.equalsIgnoreCase("Rework")) {

                                    formObject.setNGValue("ER_IniSts", "Park");
                                } else if (strTypeofinvoice.equalsIgnoreCase("Relocation") /*|| strSubcategory.equalsIgnoreCase("Salary Advance") || strSubcategory.equalsIgnoreCase("House Rent Advance")
                                         || strSubcategory.equalsIgnoreCase("Exceptional Advances")*/) {

                                    formObject.setNGValue("ER_IniSts", "HR");
                                } else if (strSubcategory.equalsIgnoreCase("Salary Advance") || strSubcategory.equalsIgnoreCase("House Rent Advance")
                                        || strSubcategory.equalsIgnoreCase("Exceptional Advances")) {

                                    formObject.setNGValue("ER_IniSts", "HeadHR");
                                } //Ended By Harinatha R on 2017/07/04
                                else {
                                    formObject.setNGValue("ER_IniSts", "Yes");
                                }
                                //Ended By Harinatha R on 2017/05/18
                                CommonObj.writeToLog(2, "Inside mid app matrix", winame);
                                writeToLog(2, "..........................stmt29..................... ", winame);
                                //Added by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period
                                if (!formObject.getNGValue("ResigDate").equalsIgnoreCase("") || !formObject.getNGValue("LastWorkngDate").equalsIgnoreCase("")) {

                                    formObject.saveDataIntoDataSource("Update WFINSTRUMENTTABLE set PriorityLevel=4 where processInstanceId='" + strprcsinstid + "'");
                                }
                                //Ended by Harinath on 2017/11/08 NOTE: To set the priority for the claims of employee who is working in notice period                                
                                writeToLog(2, "..........................stmt28..................... ", winame);

                                if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")
                                        || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")
                                        || strTypeofinvoice.equalsIgnoreCase("Relocation")) {
                                    //Added By iBPSAdmin on 20-01-2022
                                    //DeclChange
                                    String comCode = formObject.getNGValue("CompanyCode");
                                    writeToLog(2, "..........................comCode..................... "+comCode, winame);
                                    if ((comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) && !formObject.getNGValue("isDeclared").equalsIgnoreCase("true")) {
//                                    if () {
                                        throw new ValidatorException(new FacesMessage("Declaration is mandatory please read the declaration and accept it.", "isDeclared"));
                                    } else {
                                        formObject.RaiseEvent("WFDone");
                                    }
                                    //Added By iBPSAdmin on 20-01-2022
                                } else {
                                    formObject.RaiseEvent("WFDone");
                                }
                                writeToLog(2, "..........................stmt30..................... ", winame);
                            } else {
                                CommonObj.writeToLog(3, "Approver ID invalid", winame);
                                throw new ValidatorException(new FacesMessage(" First Level Approver ID Not Available in DMS", ""));
                            }
                            CommonObj.writeToLog(2, "if Inside app matrix end", winame);
                        } else {
                            CommonObj.writeToLog(3, "No Approvers found", winame);
                            throw new ValidatorException(new FacesMessage(" No Approvers Found", ""));
                        }
                        //End
                    } catch (FileNotFoundException ex) {
                        CommonObj.writeToLog(3, "Exception in btn_submit" + ex.getMessage(), winame);
                        throw new ValidatorException(new FacesMessage("Exception in button submit...!!!\nError Message=" + ex.getMessage(), ""));
                    } catch (IOException ex) {
                        CommonObj.writeToLog(3, "Exception in btn_submit" + ex.getMessage(), winame);
                    } catch (ParseException ex) {
                        Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    //COde for Mail Approval changes - Start
                    if (strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
                        formObject.setNGValue("TotalAmount", "0");
                        StringBuffer template = new StringBuffer();
                        String Emailbody = "<TR style=\"font-weight:bold; background-color:yellow\">\n"
                                + "	<TD>From Location</TD> \n"
                                + "    <TD>To Location</TD> \n"
                                + "    <TD>Date of Travel</TD>  \n"
                                + "    <TD>Time of Travel</TD> \n"
                                + "    <TD>Mode</TD> \n"
                                + "    <TD>Class</TD> \n"
                                + "    <TD>Ticket Number</TD>\n"
                                + "    <TD>Paid By</TD>\n"
                                + "    <TD>Amount</TD>\n"
                                + "    <TD>Flight No.</TD>\n"
                                + "</TR>";
                        String Emailbody_grid = "";
                        int rowCounttravelreq = formObject.getLVWRowCount("list_travel");
                        //int selectedIndex = formObject.getSelectedIndex("q_invest_dedofinterest");
                        CommonObj.writeToLog(2, "Emailbody Travel Request-->" + Emailbody, winame);
                        CommonObj.writeToLog(2, "rowCounttravelreq Travel Request rowCount-->" + rowCounttravelreq, winame);

                        for (int i = 0; i < rowCounttravelreq; i++) {
                            CommonObj.writeToLog(2, "In for Emailbody_grid Travel Request -->" + Emailbody_grid, winame);
                            Emailbody_grid = Emailbody_grid + "<TR>\n"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 0) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 1) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 2) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 3) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 5) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 6) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 7) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 8) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 9) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 12) + "</TD>\n"
                                    + "</TR>";

                        }
                        CommonObj.writeToLog(2, "Emailbody_grid Travel Request total-->" + Emailbody_grid, winame);
                        String Emailbodytotal = Emailbody + Emailbody_grid;
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request value-->" + Emailbodytotal, winame);
                        Emailbodytotal = Emailbodytotal.replaceAll("<TD></TD>", "<TD>NA</TD>");

                        //For Approval sequence and Already approved by frame - Start
                        Emailbodytotal = Emailbodytotal + "</table><div style=\"margin-top:20px;width:100%\"><table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
                                + "<thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
                                + "<td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow;\">All Approvers</td>\n"
                                + "</tr></thead><tbody style=\"border-spacing:0px\">";
//                        String approved = "<table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
//                                + "        <thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
//                                + "            <td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow\">Already Approved By</td>\n"
//                                + "            </tr></thead><tbody style=\"border-spacing:0px\">";
                        //String appQry = "select  APPROVERNAME, APPROVERDECISION from cmplx_inv_invoiceApprdetails where PID='" + pid + "'";
                        String CurrentAppLevel = formObject.getNGValue("CurrAppLevel");
                        String MaxApproverLevel = formObject.getNGValue("MaxAppLevel");
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request CurrentAppLevel value-->" + CurrentAppLevel, winame);
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request MaxApproverLevel value-->" + MaxApproverLevel, winame);

//                        for (int i = 1; i <= Integer.parseInt(CurrentAppLevel); i++) {
//
//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>";
//
////                            Emailbodytotal.append("<tr style=\"height:40px;padding:0px\">"
////                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>");
//                        }
                        //CommonObj.writeToLog(2, "Emailbodytotal Travel Request approved value-->" + approved, winame);
                        for (int i = 1; i <= Integer.parseInt(MaxApproverLevel); i++) {

//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>";
                            Emailbodytotal = Emailbodytotal + "<tr style=\"height:40px;padding:0px\">"
                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>\n";

                        }
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request Emailbodytotal value-->" + Emailbodytotal, winame);
                        //Emailbodytotal = Emailbodytotal + "</tbody></table>";
                        //Emailbodytotal = Emailbodytotal + approved + "</tbody></table>";
                        //For Approval sequence and Already approved by frame - End

                        formObject.setNGValue("Email_Body", Emailbodytotal);

                    }

                    if (strTypeofinvoice.equalsIgnoreCase("Travel Expense")) {
                        String Emailbody = "<TR style=\"font-weight:bold; background-color:yellow\">\n"
                                + "	<TD>From Location</TD> \n"
                                + "    <TD>To Location</TD> \n"
                                + "    <TD>Date of Travel</TD>  \n"
                                + "    <TD>Time of Travel</TD> \n"
                                + "    <TD>Mode</TD> \n"
                                + "    <TD>Class</TD> \n"
                                + "    <TD>Ticket Number</TD>\n"
                                + "    <TD>Paid By</TD>\n"
                                + "    <TD>Amount</TD>\n"
                                + "    <TD>Flight No.</TD>\n"
                                + "</TR>";
                        String Emailbody_grid = "";
                        int rowCounttravelreq = formObject.getLVWRowCount("list_travel");
                        //int selectedIndex = formObject.getSelectedIndex("q_invest_dedofinterest");
                        CommonObj.writeToLog(2, "Emailbody Travel Expense-->" + Emailbody, winame);
                        CommonObj.writeToLog(2, "rowCounttravelreq Travel Expense rowCount-->" + rowCounttravelreq, winame);

                        for (int i = 0; i < rowCounttravelreq; i++) {
                            CommonObj.writeToLog(2, "In for Emailbody_grid Travel Expense-->" + Emailbody_grid, winame);
                            Emailbody_grid = Emailbody_grid + "<TR>\n"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 0) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 1) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 2) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 3) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 5) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 6) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 7) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 8) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_travel", i, 9) + "</TD><TD>" + formObject.getNGValue("list_travel", i, 12) + "</TD>\n"
                                    + "</TR>";

                        }
                        CommonObj.writeToLog(2, "Emailbody_grid Travel Expense total-->" + Emailbody_grid, winame);
                        String Emailbodytotal = Emailbody + Emailbody_grid;
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Expense value-->" + Emailbodytotal, winame);

                        String Emailbodytotal1 = "<TR style=\"font-weight:bold; background-color:yellow\">\n"
                                + "	<TD>Ticket expenses</TD> \n"
                                + "    <TD>Hotel Expenses</TD> \n"
                                + "    <TD>Daily alowances</TD>  \n"
                                + "    <TD>Conveyance</TD> \n"
                                + "    <TD>Miscellaneous</TD> \n"
                                + "    <TD>Employee Comments</TD> \n"
                                + "</TR>\n"
                                + "<TR>\n"
                                + "	<TD>" + formObject.getNGValue("TicketExpense") + "</TD><TD>" + formObject.getNGValue("HotelExpense") + "</TD>"
                                + "<TD>" + formObject.getNGValue("DailyAllowance") + "</TD><TD>" + formObject.getNGValue("Conveyance") + "</TD> "
                                + "<TD>" + formObject.getNGValue("Miscellaneous") + "</TD><TD>" + formObject.getNGValue("Comments") + "</TD>\n"
                                + "</TR>";
                        Emailbodytotal = Emailbodytotal + Emailbodytotal1;
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Expense value-->" + Emailbodytotal, winame);
                        Emailbodytotal = Emailbodytotal.replaceAll("<TD></TD>", "<TD>NA</TD>");

                        //For Approval sequence and Already approved by frame - Start
                        Emailbodytotal = Emailbodytotal + "</table><div style=\"margin-top:20px;width:100%\"><table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
                                + "<thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
                                + "<td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow;\">All Approvers</td>\n"
                                + "</tr></thead><tbody style=\"border-spacing:0px\">";
//                        String approved = "<table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
//                                + "        <thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
//                                + "            <td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow\">Already Approved By</td>\n"
//                                + "            </tr></thead><tbody style=\"border-spacing:0px\">";
                        //String appQry = "select  APPROVERNAME, APPROVERDECISION from cmplx_inv_invoiceApprdetails where PID='" + pid + "'";
                        String CurrentAppLevel = formObject.getNGValue("CurrAppLevel");
                        String MaxApproverLevel = formObject.getNGValue("MaxAppLevel");
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request CurrentAppLevel value-->" + CurrentAppLevel, winame);
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request MaxApproverLevel value-->" + MaxApproverLevel, winame);
//                        if(!CurrentAppLevel.equalsIgnoreCase("")){
//                        for (int i = 1; i < Integer.parseInt(CurrentAppLevel); i++) {
//
//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>\n";
//
////                            Emailbodytotal.append("<tr style=\"height:40px;padding:0px\">"
////                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>");
//                        }
//                        }
                        //CommonObj.writeToLog(2, "Emailbodytotal Travel Request approved value-->" + approved, winame);
                        for (int i = 1; i <= Integer.parseInt(MaxApproverLevel); i++) {

//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>";
                            Emailbodytotal = Emailbodytotal + "<tr style=\"height:40px;padding:0px\">"
                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>\n";

                        }
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request Emailbodytotal value-->" + Emailbodytotal, winame);
                        //Emailbodytotal = Emailbodytotal + "</tbody></table>";
                        //Emailbodytotal = Emailbodytotal + approved + "</tbody></table>";
                        //For Approval sequence and Already approved by frame - End

                        formObject.setNGValue("Email_Body", Emailbodytotal);

                    }

                    if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")) {
                        String Emailbody = "<TR style=\"font-weight:bold; background-color:yellow\">\n"
                                + "	<TD>Details of expense</TD> \n"
                                + "    <TD>Bill number</TD> \n"
                                + "    <TD>Bill date</TD>  \n"
                                + "    <TD>Account reference</TD> \n"
                                + "    <TD>GL Code</TD> \n"
                                + "    <TD>Amount</TD> \n"
                                + "    <TD>Employee Comments</TD>\n"
                                + "</TR>";
                        String Emailbody_grid = "";
                        int rowCounttravelreq = formObject.getLVWRowCount("list_Entertain");
                        //int selectedIndex = formObject.getSelectedIndex("q_invest_dedofinterest");
                        CommonObj.writeToLog(2, "Emailbody Entertainment & Others-->" + Emailbody, winame);
                        CommonObj.writeToLog(2, "rowCounttravelreq Entertainment & Others rowCount-->" + rowCounttravelreq, winame);

                        for (int i = 0; i < rowCounttravelreq; i++) {
                            CommonObj.writeToLog(2, "In for Emailbody_grid Entertainment & Others -->" + Emailbody_grid, winame);
                            Emailbody_grid = Emailbody_grid + "<TR>\n"
                                    + "<TD>" + formObject.getNGValue("list_Entertain", i, 0) + "</TD><TD>" + formObject.getNGValue("list_Entertain", i, 1) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_Entertain", i, 2) + "</TD><TD>" + formObject.getNGValue("list_Entertain", i, 3) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("list_Entertain", i, 4) + "</TD><TD>" + formObject.getNGValue("list_Entertain", i, 5) + "</TD>"
                                    + "<TD>" + formObject.getNGValue("Comments") + "</TD>\n"
                                    + "</TR>";

                        }
                        CommonObj.writeToLog(2, "Emailbody_grid Entertainment & Others total-->" + Emailbody_grid, winame);
                        String Emailbodytotal = Emailbody + Emailbody_grid;
                        CommonObj.writeToLog(2, "Emailbodytotal Entertainment & Others value-->" + Emailbodytotal, winame);
                        Emailbodytotal = Emailbodytotal.replaceAll("<TD></TD>", "<TD>NA</TD>");

                        //For Approval sequence and Already approved by frame - Start
                        Emailbodytotal = Emailbodytotal + "</table><div style=\"margin-top:20px;width:100%\"><table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
                                + "<thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
                                + "<td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow;\">All Approvers</td>\n"
                                + "</tr></thead><tbody style=\"border-spacing:0px\">";
//                        String approved = "<table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
//                                + "        <thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
//                                + "            <td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow\">Already Approved By</td>\n"
//                                + "            </tr></thead><tbody style=\"border-spacing:0px\">";
                        //String appQry = "select  APPROVERNAME, APPROVERDECISION from cmplx_inv_invoiceApprdetails where PID='" + pid + "'";
                        String CurrentAppLevel = formObject.getNGValue("CurrAppLevel");
                        String MaxApproverLevel = formObject.getNGValue("MaxAppLevel");
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request CurrentAppLevel value-->" + CurrentAppLevel, winame);
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request MaxApproverLevel value-->" + MaxApproverLevel, winame);
//                        if(!CurrentAppLevel.equalsIgnoreCase("")){
//                        for (int i = 1; i < Integer.parseInt(CurrentAppLevel); i++) {
//
//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>";
//
////                            Emailbodytotal.append("<tr style=\"height:40px;padding:0px\">"
////                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>");
//                        }
//                        }
                        //CommonObj.writeToLog(2, "Emailbodytotal Travel Request approved value-->" + approved, winame);
                        for (int i = 1; i <= Integer.parseInt(MaxApproverLevel); i++) {

//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>";
                            Emailbodytotal = Emailbodytotal + "<tr style=\"height:40px;padding:0px\">"
                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>\n";

                        }
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request Emailbodytotal value-->" + Emailbodytotal, winame);
                        //Emailbodytotal = Emailbodytotal + "</tbody></table>";
                        //Emailbodytotal = Emailbodytotal + approved + "</tbody></table>";
                        //For Approval sequence and Already approved by frame - End

                        formObject.setNGValue("Email_Body", Emailbodytotal);

                    }

                    if (strTypeofinvoice.equalsIgnoreCase("Relocation")) {

                        String Emailbodytotal = "";
                        CommonObj.writeToLog(2, "Emailbodytotal Relocation value-->" + Emailbodytotal, winame);

                        String Emailbodytotal1 = "<TR style=\"font-weight:bold; background-color:yellow\">\n"
                                + "	<TD>Ticket expenses</TD> \n"
                                + "    <TD>Hotel Expenses</TD> \n"
                                + "    <TD>Daily alowances</TD>  \n"
                                + "    <TD>Conveyance</TD> \n"
                                + "    <TD>Miscellaneous</TD> \n"
                                + "    <TD>Medical Expenses</TD> \n"
                                + "    <TD>Employee Comments</TD> \n"
                                + "</TR>\n"
                                + "<TR>\n"
                                + "	<TD>" + formObject.getNGValue("TicketExpense") + "</TD><TD>" + formObject.getNGValue("HotelExpense") + "</TD>"
                                + "<TD>" + formObject.getNGValue("DailyAllowance") + "</TD><TD>" + formObject.getNGValue("Conveyance") + "</TD> "
                                + "<TD>" + formObject.getNGValue("Miscellaneous") + "</TD><TD>" + formObject.getNGValue("MedicalExpense") + "</TD>"
                                + "<TD>" + formObject.getNGValue("Comments") + "</TD>\n"
                                + "</TR>";
                        Emailbodytotal = Emailbodytotal + Emailbodytotal1;
                        CommonObj.writeToLog(2, "Emailbodytotal Relocation value-->" + Emailbodytotal, winame);
                        Emailbodytotal = Emailbodytotal.replaceAll("<TD></TD>", "<TD>NA</TD>");

                        //For Approval sequence and Already approved by frame - Start
                        Emailbodytotal = Emailbodytotal + "</table><div style=\"margin-top:20px;width:100%\"><table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
                                + "<thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
                                + "<td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow;\">All Approvers</td>\n"
                                + "</tr></thead><tbody style=\"border-spacing:0px\">";
//                        String approved = "<table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
//                                + "        <thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
//                                + "            <td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow\">Already Approved By</td>\n"
//                                + "            </tr></thead><tbody style=\"border-spacing:0px\">";
                        //String appQry = "select  APPROVERNAME, APPROVERDECISION from cmplx_inv_invoiceApprdetails where PID='" + pid + "'";
                        String CurrentAppLevel = formObject.getNGValue("CurrAppLevel");
                        String MaxApproverLevel = formObject.getNGValue("MaxAppLevel");
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request CurrentAppLevel value-->" + CurrentAppLevel, winame);
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request MaxApproverLevel value-->" + MaxApproverLevel, winame);
//                        if(!CurrentAppLevel.equalsIgnoreCase("")){
//                        for (int i = 1; i < Integer.parseInt(CurrentAppLevel); i++) {
//
//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>\n";
//
////                            Emailbodytotal.append("<tr style=\"height:40px;padding:0px\">"
////                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>");
//                        }
//                        }
                        //CommonObj.writeToLog(2, "Emailbodytotal Travel Request approved value-->" + approved, winame);
                        for (int i = 1; i <= Integer.parseInt(MaxApproverLevel); i++) {

//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>";
                            Emailbodytotal = Emailbodytotal + "<tr style=\"height:40px;padding:0px\">"
                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>\n";

                        }
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request Emailbodytotal value-->" + Emailbodytotal, winame);
                        //Emailbodytotal = Emailbodytotal + "</tbody></table>";
                        //Emailbodytotal = Emailbodytotal + approved + "</tbody></table>";
                        //For Approval sequence and Already approved by frame - End

                        formObject.setNGValue("Email_Body", Emailbodytotal);

                    }

                    if (strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {

                        String Emailbodytotal = "";
                        CommonObj.writeToLog(2, "Emailbodytotal Relocation value-->" + Emailbodytotal, winame);

                        String Emailbodytotal1 = "<TR style=\"font-weight:bold; background-color:yellow\">\n"
                                + "	<TD>Basic Salary</TD> \n"
                                + "    <TD>Eligible Amount</TD> \n"
                                + "    <TD>Repayment Schedule</TD>  \n"
                                + "    <TD>Claimed Amount</TD> \n"
                                + "    <TD>Reason</TD> \n"
                                + "    <TD>Comments</TD> \n"
                                + "</TR>\n"
                                + "<TR>\n"
                                + "	<TD>" + formObject.getNGValue("BasicSalary") + "</TD><TD>" + formObject.getNGValue("EligibleAmount") + "</TD>"
                                + "<TD>" + formObject.getNGValue("RepaymentSchedule") + "</TD><TD>" + formObject.getNGValue("ClaimedAmount") + "</TD> "
                                + "<TD>" + formObject.getNGValue("SalaryAdvanceReason") + "</TD>"
                                + "<TD>" + formObject.getNGValue("Comments") + "</TD>\n"
                                + "</TR>";
                        Emailbodytotal = Emailbodytotal + Emailbodytotal1;
                        CommonObj.writeToLog(2, "Emailbodytotal Relocation value-->" + Emailbodytotal, winame);
                        Emailbodytotal = Emailbodytotal.replaceAll("<TD></TD>", "<TD>NA</TD>");

                        //For Approval sequence and Already approved by frame - Start
                        Emailbodytotal = Emailbodytotal + "</table><div style=\"margin-top:20px;width:100%\"><table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
                                + "<thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
                                + "<td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow;\">All Approvers</td>\n"
                                + "</tr></thead><tbody style=\"border-spacing:0px\">";
//                        String approved = "<table style=\"width:40%;border-spacing:0px;display:inline-table\">\n"
//                                + "        <thead style=\"border-spacing:0px\"><tr style=\"height:40px;padding:0px\">\n"
//                                + "            <td style=\"text-align:center;font-weight:700;font-weight:bold; background-color:yellow\">Already Approved By</td>\n"
//                                + "            </tr></thead><tbody style=\"border-spacing:0px\">";
                        //String appQry = "select  APPROVERNAME, APPROVERDECISION from cmplx_inv_invoiceApprdetails where PID='" + pid + "'";
                        String CurrentAppLevel = formObject.getNGValue("CurrAppLevel");
                        String MaxApproverLevel = formObject.getNGValue("MaxAppLevel");
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request CurrentAppLevel value-->" + CurrentAppLevel, winame);
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request MaxApproverLevel value-->" + MaxApproverLevel, winame);
//                        if(!CurrentAppLevel.equalsIgnoreCase("")){
//                        for (int i = 1; i < Integer.parseInt(CurrentAppLevel); i++) {
//
//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>\n";
//
////                            Emailbodytotal.append("<tr style=\"height:40px;padding:0px\">"
////                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>");
//                        }
//                        }
//                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request approved value-->" + approved, winame);
                        for (int i = 1; i <= Integer.parseInt(MaxApproverLevel); i++) {

//                            approved = approved + "<tr style=\"height:40px;padding:0px\">"
//                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + xmlListQuery.getVal("APPROVERNAME") + "</td></tr>";
                            Emailbodytotal = Emailbodytotal + "<tr style=\"height:40px;padding:0px\">"
                                    + "<td style=\"text-align:center;font-size:13px;font-weight:700\">" + formObject.getNGValue("Appr" + i + "email") + "</td></tr>\n";

                        }
                        CommonObj.writeToLog(2, "Emailbodytotal Travel Request Emailbodytotal value-->" + Emailbodytotal, winame);
                        //Emailbodytotal = Emailbodytotal + "</tbody></table>";
                        //Emailbodytotal = Emailbodytotal + approved + "</tbody></table>";
                        //For Approval sequence and Already approved by frame - End

                        formObject.setNGValue("Email_Body", Emailbodytotal);

                    }

                    //COde for Mail Approval changes - End
                }

                break;
            }//End of mouse clicked
            case KEY_PRESSED: {
                //CommonObj.writeToLog(2,"KEY_PRESSED",winame);                
                break;
            }
            case FOCUS_GAINED: {
                //CommonObj.writeToLog(2,"FOCUS_GAINED",winame);                
                break;
            }
            case VALUE_CHANGED: {
                CommonObj.writeToLog(2, "Name123--> --> " + pEvent.getSource().getName(), winame);
                writeToLog(2, "Change Name-->" + pEvent.getSource().getName(), strprcsinstid);
                if (pEvent.getSource().getName().equalsIgnoreCase("dp_dailyallw_todate")) {
                    writeToLog(2, "78678Change Name-->" + pEvent.getSource().getName(), strprcsinstid);
                    String strDesig = formObject.getNGValue("Designation");
                    writeToLog(2, "78678Change Name-->" + formObject.getNGValue("dp_dailyallw_fromdate"), strprcsinstid);
                    writeToLog(2, "78678Change Name-->" + formObject.getNGValue("dp_dailyallw_todate"), strprcsinstid);
                    if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                        writeToLog(2, "Testing 78678Change Name-->" + formObject.getNGValue("dp_dailyallw_fromdate"), strprcsinstid);
                        String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                        String strToDate = formObject.getNGValue("dp_dailyallw_todate");
                        String toDate = "";
                        toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
//                            ibpsadmin end
                        /*
                             //Added By Harinath on 2017/03/28
                             //String Grade1 = formObject.getNGValue("Grade");
                             String queryDA = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='DailyAllowance' and grade='" + Grade1 + "'";
                             CommonObj.DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                             formObject.setEnabled("txt_dailyallw_entilperday", false);
                             //Ended By Harinath on 2017/03/28
                         */
                        try {
                            Long noOfDays = CommonObj.getNoOfDaysBTWDates(formObject.getNGValue("dp_dailyallw_fromdate"), formObject.getNGValue("dp_dailyallw_todate"));
                            CommonObj.writeToLog(2, " In try noOfDays" + noOfDays, winame);
                            formObject.setNGValue("txt_dailyallw_noofdays", noOfDays);
                            formObject.setLocked("txt_dailyallw_noofdays", true);

                            //Added by SandeepKn on 08Jan2020 for entilperday value -- Start                                
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                CommonObj.writeToLog(2, " In Amount If txt_dailyallw_entilperday1" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                CommonObj.DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                                formObject.setEnabled("txt_dailyallw_entilperday", false);
                                CommonObj.writeToLog(2, "txt_dailyallw_entilperday1" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);

                            }
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                CommonObj.writeToLog(2, " In Amount If txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                if (CommonObj.SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                        || CommonObj.SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                    CommonObj.writeToLog(2, " In Designation If txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                    //Entire grade having citytype DA(Ex: Management Trainee)
                                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                    formObject.setEnabled("txt_dailyallw_CityType", true);
                                    formObject.setEnabled("txt_dailyallw_City", true);
                                    CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                                    formObject.setNGValue("txt_dailyallw_entilperday", "");
                                    CommonObj.writeToLog(2, "txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                }

                            }
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                                //Entire grade having citytype DA(Ex: Managers)
                                CommonObj.writeToLog(2, "In If Amount txt_dailyallw_entilperday123" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                formObject.setEnabled("txt_dailyallw_CityType", true);
                                formObject.setEnabled("txt_dailyallw_City", true);
                                CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                formObject.setEnabled("txt_dailyallw_entilperday", false);
                                formObject.setNGValue("txt_dailyallw_entilperday", "");
                                CommonObj.writeToLog(2, "txt_dailyallw_entilperday123" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                            }
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                CommonObj.writeToLog(2, "In if txt_dailyallw_entilperday1234" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                formObject.setNGBackColor("txt_dailyallw_Loc", Color.white);
                                formObject.setEnabled("txt_dailyallw_CityType", true);
                                formObject.setEnabled("txt_dailyallw_City", true);
                                formObject.setEnabled("txt_dailyallw_Loc", true);
                                CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock) WHERE  '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                formObject.setEnabled("txt_dailyallw_entilperday", false);
                                formObject.setNGValue("txt_dailyallw_entilperday", "");
                                CommonObj.writeToLog(2, "txt_dailyallw_entilperday1234" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);

                            }
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                CommonObj.writeToLog(2, "In if txt_dailyallw_entilperday1235" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                //String queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WHERE DAType='Grade' AND Grade='" + Grade1 + "'";
                                CommonObj.DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                                formObject.setEnabled("txt_dailyallw_entilperday", false);

                                formObject.setNGBackColor("txt_dailyallw_CityType", new Color(255, 255, 255));
                                formObject.setNGBackColor("txt_dailyallw_City", new Color(255, 255, 255));
                                formObject.setNGBackColor("txt_dailyallw_Loc", new Color(255, 255, 255));
                                formObject.setNGBackColor("txt_dailyallw_OthrLoc", new Color(225, 225, 225));
                                formObject.setEnabled("txt_dailyallw_CityType", false);
                                formObject.setEnabled("txt_dailyallw_City", false);
                                formObject.setEnabled("txt_dailyallw_Loc", false);
                                formObject.setEnabled("txt_dailyallw_OthrLoc", false);
                                CommonObj.writeToLog(2, "txt_dailyallw_entilperday1235" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                            }

                            //Added by SandeepKn on 08Jan2020 for entilperday value -- End                               
                            if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("0")) {
                                formObject.setNGValue("txt_dailyallw_calcda", (Float.parseFloat(formObject.getNGValue("txt_dailyallw_entilperday")) * Float.parseFloat(formObject.getNGValue("txt_dailyallw_noofdays"))));
                                formObject.setLocked("txt_dailyallw_calcda", true);
                                CommonObj.writeToLog(2, "In if setting txt_dailyallw_calcda" + formObject.getNGValue("txt_dailyallw_calcda"), winame);
                            }
                            if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                                formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                                CommonObj.writeToLog(2, "In if setting txt_dailyallw_actualdaclaim greater than txt_dailyallw_calcda" + formObject.getNGValue("txt_dailyallw_actualdaclaim"), winame);
                                throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                            }
                        } catch (ParseException ex) {
                            Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                if (flagonload) {
                    //CommonObj.writeToLog(2,"VALUE_CHANGED",winame);
                    if (pEvent.getSource().getName().equalsIgnoreCase("TypeOfInvoice")) {

                        String strTypeofinvoice1 = formObject.getNGValue("TypeOfInvoice");
                        String strSubcategory1 = formObject.getNGValue("SubCategory1");
                        if (strTypeofinvoice1.equalsIgnoreCase("Mobile Re-Imbursements")) {
                            formObject.clear("SubCategory1");
                            formObject.addItem("SubCategory1", "Mobile Re-Imbursements");
                            formObject.setNGValue("SubCategory1", "Mobile Re-Imbursements");
//                            formObject.setEnabled("SubCategory1", false);
                        } else if (strTypeofinvoice1.equalsIgnoreCase("Travel Expense")) {
                            //Added by SandeepKn on 23Jan2020 for Syed bug on 23jan2020- start
                            formObject.clear("SubCategory1");
                            formObject.addItem("SubCategory1", "Travel Expense");
                            //Added by SandeepKn on 23Jan2020 for Syed bug on 23jan2020- start
                            formObject.setNGValue("SubCategory1", "Travel Expense");
                            //formObject.setEnabled("SubCategory1", false);
                        } else if (strTypeofinvoice1.equalsIgnoreCase("Travel Request")) {
                            formObject.clear("SubCategory1");
                            formObject.addItem("SubCategory1", "Travel Request");
                            formObject.setNGValue("SubCategory1", "Travel Request");
//                            formObject.setEnabled("SubCategory1", false);
                        } else {
                            formObject.setEnabled("SubCategory1", true);
//                            formObject.setNGValue("SubCategory1", "");
                            formObject.clear("SubCategory1");
                            formObject.setNGValue("SubCategory1", "");
                            String querySubCat = "select SubCat1 from EXT_AP_ER_InvoiceSub with(nolock) where TYPEOFINV='" + strTypeofinvoice1 + "' and Process='ER' and SubCat1 IS NOT NULL and SubCat1 !=''";
                            CommonObj.DBValues_Combo(querySubCat, "SubCategory1");

                        }
                    }//Added by SAndeepKn on 10JAn2020 for ASFI and SFIC cahnges --Start
                    else if (pEvent.getSource().getName().equalsIgnoreCase("ServiceProvider")) {
                        if (formObject.getNGValue("ServiceProvider").equalsIgnoreCase("") || formObject.getNGValue("ServiceProvider").equalsIgnoreCase("--Select--")) {
                            formObject.setNGValue("ServiceProviderOthers", "");
                            formObject.setEnabled("ServiceProviderOthers", false);
                            formObject.setLocked("ServiceProviderOthers", true);
                            formObject.setNGBackColor("ServiceProviderOthers", new Color(225, 225, 225));
                        } else if (formObject.getNGValue("ServiceProvider").equalsIgnoreCase("Others")) {
                            formObject.setLocked("ServiceProviderOthers", false);
                            formObject.setEnabled("ServiceProviderOthers", true);
                            //formObject.setNGBackColor("ServiceProviderOthers", new Color(225, 225, 255));
                            formObject.setNGBackColor("ServiceProviderOthers", Color.white);
                        } else {
                            formObject.setNGValue("ServiceProviderOthers", "");
                            formObject.setEnabled("ServiceProviderOthers", false);
                            formObject.setLocked("ServiceProviderOthers", true);
                            formObject.setNGBackColor("ServiceProviderOthers", new Color(225, 225, 225));
                        }
                    }//Added by SAndeepKn on 10JAn2020 for ASFI and SFIC cahnges --END
                    else if (pEvent.getSource().getName().equalsIgnoreCase("BillPlan")) {
                        if (formObject.getNGValue("BillPlan").equalsIgnoreCase("") || formObject.getNGValue("BillPlan").equalsIgnoreCase("--Select--")) {
                            formObject.setNGValue("BillPlanOthers", "");
                            formObject.setEnabled("BillPlanOthers", false);
                            formObject.setLocked("BillPlanOthers", true);
                            formObject.setNGBackColor("BillPlanOthers", new Color(225, 225, 225));
                        } else if (formObject.getNGValue("BillPlan").equalsIgnoreCase("Others")) {
                            formObject.setLocked("BillPlanOthers", false);
                            formObject.setEnabled("BillPlanOthers", true);
                            //formObject.setNGBackColor("BillPlanOthers", new Color(225, 225, 255));
                            formObject.setNGBackColor("BillPlanOthers", Color.white);
                        } else {
                            formObject.setNGValue("BillPlanOthers", "");
                            formObject.setEnabled("BillPlanOthers", false);
                            formObject.setLocked("BillPlanOthers", true);
                            formObject.setNGBackColor("BillPlanOthers", new Color(225, 225, 225));
                        }
                    } else if (pEvent.getSource().getName().equalsIgnoreCase("RequestFor")) {
                        //Added the below lines for HANA Project change the Cost Center on 13-Nov-2019 starts
                        if (formObject.getNGValue("EmployeeCode").equalsIgnoreCase("1003404")) {
                            if (!formObject.getNGValue("RequestFor").equalsIgnoreCase("Self")) {
                                formObject.setNGValue("CostCenter", "PSNBILHANA");
                            } else {
                                formObject.setNGValue("CostCenter", "DYEOITISDN");
                            }
                        }
                        //Added the below lines for HANA Project change the Cost Center on 13-Nov-2019 ends
//                        if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant")) {
                        if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant/New Joinee")) {// Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram                

                            if (strSubcategory.equalsIgnoreCase("Travel Request")) {
                                formObject.setLeft("Label3", 345);
                                formObject.setLeft("OthrPasngr", 475);
                                formObject.setTop("Label3", 175);
                                formObject.setTop("OthrPasngr", 175);

                            }

                            formObject.setVisible("Label3", true);
                            formObject.setVisible("OthrPasngr", true);

                        } else {

                            formObject.setVisible("Label3", false);
                            formObject.setVisible("OthrPasngr", false);
                        }
                    } //Modified By Harinatha on 2017/05/29
                    else if (pEvent.getSource().getName().equalsIgnoreCase("cb_trvl_mode")) {
                        formObject.clear("cb_trvl_class");
                        formObject.setNGValue("cb_trvl_class", "");
                        String queryMode = "SELECT class FROM EXT_AP_ER_TravelClass with(nolock) WHERE mode='" + formObject.getNGValue("cb_trvl_mode") + "'";
                        CommonObj.DBValues_Combo(queryMode, "cb_trvl_class");
                        CommonObj.writeToLog(2, "cb_trvl_mode --> " + formObject.getNGValue("cb_trvl_mode"), winame);
                        CommonObj.writeToLog(2, "Grade --> " + formObject.getNGValue("Grade"), winame);
                        if (formObject.getNGValue("cb_trvl_mode").equalsIgnoreCase("Bus")) {
                            formObject.addItem("cb_trvl_class", "Bus");
                            formObject.setNGValue("cb_trvl_class", "Bus");
                            formObject.setEnabled("txt_trvl_FlightNo", false);
                            formObject.setNGValue("txt_trvl_FlightNo", "");
                            formObject.setNGBackColor("txt_trvl_FlightNo", new Color(225, 225, 225));
                        } else if (formObject.getNGValue("cb_trvl_mode").equalsIgnoreCase("Train") && formObject.getNGValue("Grade").equalsIgnoreCase("Territory Sales IC")) {
                            formObject.clear("cb_trvl_class");
                            formObject.addItem("cb_trvl_class", "III AC");
                            formObject.addItem("cb_trvl_class", "SL");
                            formObject.addItem("cb_trvl_class", "EC");
                            formObject.addItem("cb_trvl_class", "FC");
                            formObject.addItem("cb_trvl_class", "CC");
                            formObject.setEnabled("txt_trvl_FlightNo", false);
                            formObject.setNGValue("txt_trvl_FlightNo", "");
                            formObject.setNGBackColor("txt_trvl_FlightNo", new Color(225, 225, 225));
                        } else if (formObject.getNGValue("cb_trvl_mode").equalsIgnoreCase("Self")) {

                            //Added By Harinatha on 2017/07/03
                            formObject.addItem("cb_trvl_paidby", "Self");
                            formObject.setNGValue("cb_trvl_paidby", "Self");
                            //Ended By Harinatha on 2017/07/03
                            formObject.setEnabled("txt_trvl_FlightNo", false);
                            formObject.setNGValue("txt_trvl_FlightNo", "");
                            formObject.setNGBackColor("txt_trvl_FlightNo", new Color(225, 225, 225));
                        } //Commneted by  SandeepKN on 09March for Changes as per SYED-start
                        //else if (formObject.getNGValue("cb_trvl_mode").equalsIgnoreCase("Air")) {
                        //Added By Harinatha on 2017/06/21
                        //  formObject.setNGValue("cb_trvl_class", "Economy");
                        //Ended By Harinatha on 2017/06/21
                        // formObject.setEnabled("txt_trvl_FlightNo", true);
                        // formObject.setNGBackColor("txt_trvl_FlightNo", Color.white);
                        //} //Commneted by  SandeepKN on 09March for Changes as per SYED-start
                        else if (formObject.getNGValue("cb_trvl_mode").equalsIgnoreCase("Air")) {
                            //Added by Sandeep.n on 20Feb2020 for SFIC and ASFIC changes-- Start
                            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")
                                    || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                                //String queryVisible = "SELECT COUNT(1) FROM EXT_AP_ER_ASFICSFIC_TravelClass WHERE UserName='SYEDKAZMI' AND Visibility ='YES'";
                                // CommonObj.writeToLog(2, "queryVisible ==> " + queryVisible, winame);
                                //String strUserCountVisible = CommonObj.DB_QueryExecuteSelect1(queryVisible);
                                //CommonObj.writeToLog(2, "strUserCountVisible ==> " + strUserCountVisible, winame);
                                CommonObj.writeToLog(2, "Grade before ==> " + Grade1, winame);
                                if (Grade1.equalsIgnoreCase("Vice President") || Grade1.equalsIgnoreCase("Manager Grade I")
                                        || Grade1.equalsIgnoreCase("Managing Director")) {
                                    CommonObj.writeToLog(2, "Grade1 ==> " + Grade1, winame);
                                    formObject.clear("cb_trvl_class");
                                    formObject.addItem("cb_trvl_class", "Economy");
                                    formObject.addItem("cb_trvl_class", "Business");
                                    formObject.setEnabled("txt_trvl_FlightNo", true);
                                    formObject.setNGBackColor("txt_trvl_FlightNo", Color.white);
                                } else {
                                    formObject.clear("cb_trvl_class");
                                    formObject.addItem("cb_trvl_class", "Economy");
                                    formObject.setNGValue("cb_trvl_class", "Economy");
                                    formObject.setEnabled("txt_trvl_FlightNo", true);
                                    formObject.setNGBackColor("txt_trvl_FlightNo", Color.white);
                                }
                            } else { //Added by Sandeep.n on 20Feb2020 for SFIC and ASFIC changes-- END                       
                                //Added By Harinatha on 2017/06/21
                                formObject.setNGValue("cb_trvl_class", "Economy");
                                //Ended By Harinatha on 2017/06/21
                                formObject.setEnabled("txt_trvl_FlightNo", true);
                                formObject.setNGBackColor("txt_trvl_FlightNo", Color.white);
                            }
                        } else {
                            formObject.setEnabled("txt_trvl_FlightNo", false);
                            formObject.setNGValue("txt_trvl_FlightNo", "");
                            formObject.setNGBackColor("txt_trvl_FlightNo", new Color(225, 225, 225));
                        }
                    } else if (pEvent.getSource().getName().equalsIgnoreCase("cb_trvl_class")) {
                        if (formObject.getNGValue("cb_trvl_mode") == "" || formObject.getNGValue("cb_trvl_mode") == "--Select--") {
                            throw new ValidatorException(new FacesMessage("Please Select Mode of Travel", "cb_trvl_mode"));
                        }
                    } //Ended By Harinatha on 2017/03/29
                    /* Below code written in AP.js
                     else if (pEvent.getSource().getName().equalsIgnoreCase("RequestFor")) {
                     CommonObj.writeToLog(2, "Inside RequestFor Value changed start:" + formObject.getNGValue("RequestFor"), winame);
                     String Request = formObject.getNGValue("RequestFor");
                     formObject.setNGValue("CompanyCode", "");
                     formObject.setNGValue("Region", "");
                     formObject.setNGValue("EmployeeName", "");
                     formObject.setNGValue("VendorCode", "");
                     formObject.setNGValue("Designation", "");
                     formObject.setNGValue("Department", "");
                     formObject.setNGValue("Grade", "");
                     formObject.setNGValue("CostCenter", "");
                     formObject.setNGValue("BusinessArea", "");
                     formObject.setNGValue("OriginalLocation", "");
                     formObject.setNGValue("BasicSalary", "");
                     formObject.setNGValue("DateOfJoining", "");
                     formObject.setNGValue("DateOfTransfer", "");
                     formObject.setNGValue("PrevLoc", "");
                     formObject.setNGValue("PrevSubLoc", "");

                     if (Request.equalsIgnoreCase("Others")) {
                     formObject.setNGValue("EmployeeCode", "");
                     formObject.setLocked("EmployeeCode", false);
                     }
                     if (Request.equalsIgnoreCase("Self")) {
                     formObject.setNGValue("EmployeeCode", "");
                     formObject.setLocked("EmployeeCode", true);
                     }
                     CommonObj.writeToLog(2, "Inside RequestFor Value changed End:", winame);
                     }*/ else if (pEvent.getSource().getName().equalsIgnoreCase("cb_entschm_accref")) {
                        String ACCRef = formObject.getNGValue("cb_entschm_accref");
                        //formObject.clear("txt_entschm_glcode");
                        formObject.setNGValue("txt_entschm_glcode", "");

                        //Modified for fetching GLCode based on CompanyCode on 03-SEP-20 
                        //String queryMode = "SELECT glcode FROM EXT_AP_ER_GLcode with(nolock) WHERE ACCRef='" + ACCRef + "'";
                        String strCompanyCode = formObject.getNGValue("CompanyCode");
                        String queryMode = "SELECT top(1) glcode FROM EXT_AP_GLcode with(nolock) WHERE ACCRef ='" + ACCRef + "' and CompanyCode ='" + strCompanyCode + "'";
                        CommonObj.writeToLog(2, "queryMode " + queryMode, winame);
                        //End on 03-SEP-20

                        CommonObj.DBValues_Field(queryMode, "txt_entschm_glcode");
                        formObject.setLocked("txt_entschm_glcode", true);
                    } //Modified By Harinath on 2017/07/21
                    else if (pEvent.getSource().getName().equalsIgnoreCase("dp_dailyallw_fromdate")) {
                        if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {

                            try {
                                Long noOfDays = CommonObj.getNoOfDaysBTWDates(formObject.getNGValue("dp_dailyallw_fromdate"), formObject.getNGValue("dp_dailyallw_todate"));
                                formObject.setNGValue("txt_dailyallw_noofdays", noOfDays);
                                formObject.setLocked("txt_dailyallw_noofdays", true);
                                if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("0")) {
                                    formObject.setNGValue("txt_dailyallw_calcda", (Float.parseFloat(formObject.getNGValue("txt_dailyallw_entilperday")) * Float.parseFloat(formObject.getNGValue("txt_dailyallw_noofdays"))));
                                    formObject.setLocked("txt_dailyallw_calcda", true);
                                }
                                if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                                    formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                                    throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                                }
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } else if (pEvent.getSource().getName().equalsIgnoreCase("dp_dailyallw_todate")) {
                        String strDesig = formObject.getNGValue("Designation");
                        if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                            String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                            String strToDate = formObject.getNGValue("dp_dailyallw_todate");
//                            String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
//                        String strToDate = formObject.getNGValue("dp_dailyallw_todate");
                            String toDate = "";
                            toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
//                            ibpsadmin end
                            /*
                             //Added By Harinath on 2017/03/28
                             //String Grade1 = formObject.getNGValue("Grade");
                             String queryDA = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='DailyAllowance' and grade='" + Grade1 + "'";
                             CommonObj.DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                             formObject.setEnabled("txt_dailyallw_entilperday", false);
                             //Ended By Harinath on 2017/03/28
                             */
                            try {
                                Long noOfDays = CommonObj.getNoOfDaysBTWDates(formObject.getNGValue("dp_dailyallw_fromdate"), formObject.getNGValue("dp_dailyallw_todate"));
                                CommonObj.writeToLog(2, " In try noOfDays" + noOfDays, winame);
                                formObject.setNGValue("txt_dailyallw_noofdays", noOfDays);
                                formObject.setLocked("txt_dailyallw_noofdays", true);

                                //Added by SandeepKn on 08Jan2020 for entilperday value -- Start                                
                                if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                        && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                    CommonObj.writeToLog(2, " In Amount If txt_dailyallw_entilperday1" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                    CommonObj.DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                                    CommonObj.writeToLog(2, "txt_dailyallw_entilperday1" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);

                                }
                                if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                        && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                    CommonObj.writeToLog(2, " In Amount If txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                    if (CommonObj.SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                            || CommonObj.SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                        CommonObj.writeToLog(2, " In Designation If txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                        //Entire grade having citytype DA(Ex: Management Trainee)
                                        formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                        formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                        formObject.setEnabled("txt_dailyallw_CityType", true);
                                        formObject.setEnabled("txt_dailyallw_City", true);
                                        CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                        formObject.setEnabled("txt_dailyallw_entilperday", false);
                                        formObject.setNGValue("txt_dailyallw_entilperday", "");
                                        CommonObj.writeToLog(2, "txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                    }

                                }
                                if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                        && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                                    //Entire grade having citytype DA(Ex: Managers)
                                    CommonObj.writeToLog(2, "In If Amount txt_dailyallw_entilperday123" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                    formObject.setEnabled("txt_dailyallw_CityType", true);
                                    formObject.setEnabled("txt_dailyallw_City", true);
                                    CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)   WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                                    formObject.setNGValue("txt_dailyallw_entilperday", "");
                                    CommonObj.writeToLog(2, "txt_dailyallw_entilperday123" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                }
                                if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                        && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                    CommonObj.writeToLog(2, "In if txt_dailyallw_entilperday1234" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                    formObject.setNGBackColor("txt_dailyallw_Loc", Color.white);
                                    formObject.setEnabled("txt_dailyallw_CityType", true);
                                    formObject.setEnabled("txt_dailyallw_City", true);
                                    formObject.setEnabled("txt_dailyallw_Loc", true);
                                    CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                                    formObject.setNGValue("txt_dailyallw_entilperday", "");
                                    CommonObj.writeToLog(2, "txt_dailyallw_entilperday1234" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);

                                }
                                if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                        && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                    CommonObj.writeToLog(2, "In if txt_dailyallw_entilperday1235" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                    //String queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WHERE DAType='Grade' AND Grade='" + Grade1 + "'";
                                    CommonObj.DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                                    formObject.setEnabled("txt_dailyallw_entilperday", false);

                                    formObject.setNGBackColor("txt_dailyallw_CityType", new Color(255, 255, 255));
                                    formObject.setNGBackColor("txt_dailyallw_City", new Color(255, 255, 255));
                                    formObject.setNGBackColor("txt_dailyallw_Loc", new Color(255, 255, 255));
                                    formObject.setNGBackColor("txt_dailyallw_OthrLoc", new Color(225, 225, 225));
                                    formObject.setEnabled("txt_dailyallw_CityType", false);
                                    formObject.setEnabled("txt_dailyallw_City", false);
                                    formObject.setEnabled("txt_dailyallw_Loc", false);
                                    formObject.setEnabled("txt_dailyallw_OthrLoc", false);
                                    CommonObj.writeToLog(2, "txt_dailyallw_entilperday1235" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                }

                                //Added by SandeepKn on 08Jan2020 for entilperday value -- End                               
                                if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("0")) {
                                    formObject.setNGValue("txt_dailyallw_calcda", (Float.parseFloat(formObject.getNGValue("txt_dailyallw_entilperday")) * Float.parseFloat(formObject.getNGValue("txt_dailyallw_noofdays"))));
                                    formObject.setLocked("txt_dailyallw_calcda", true);
                                    CommonObj.writeToLog(2, "In if setting txt_dailyallw_calcda" + formObject.getNGValue("txt_dailyallw_calcda"), winame);
                                }
                                if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                                    formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                                    CommonObj.writeToLog(2, "In if setting txt_dailyallw_actualdaclaim greater than txt_dailyallw_calcda" + formObject.getNGValue("txt_dailyallw_actualdaclaim"), winame);
                                    throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                                }
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } else if (pEvent.getSource().getName().equalsIgnoreCase("txt_dailyallw_actualdaclaim")) {

                        if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                            formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                            throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                        }
                    } //Modified By Harinatha R on 2017/09/21
                    else if (pEvent.getSource().getName().equalsIgnoreCase("txt_dailyallw_CityType")) {

                        String strDesig = formObject.getNGValue("Designation");
                        String queryCity = "";

                        formObject.clear("txt_dailyallw_City");
                        formObject.setNGValue("txt_dailyallw_City", "");
                        String toDate = "";
                        if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                            String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                            String strToDate = formObject.getNGValue("dp_dailyallw_todate");
                            // String toDate = "";
                            toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
                        }
                        /*
                         if(Grade1.equalsIgnoreCase("Management Trainee") || Grade1.equalsIgnoreCase("Executive-Sales")){
                            
                         queryCity = "SELECT City FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE  Grade='"+Grade1+"' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "'";
                         } else if ((Grade1.equalsIgnoreCase("Manager Band III") && (strDesig.equalsIgnoreCase("Sales Operation Manager") || strDesig.equalsIgnoreCase("Sales Operations Manager") || strDesig.equalsIgnoreCase("Sales Operations Manager-TN(North)")))
                         || (Grade1.equalsIgnoreCase("Manager Grade IV") && (strDesig.equalsIgnoreCase("Senior Area Sales Manager") || strDesig.equalsIgnoreCase("Senior Area Sales Manager - Bread") || strDesig.equalsIgnoreCase("Sr. Area Sales Manager")))
                         || (Grade1.equalsIgnoreCase("Manager Grade V") && (strDesig.equalsIgnoreCase("Area Sales Manager") || strDesig.equalsIgnoreCase("Area Sales Manager - Fresh Dairy (South)") || strDesig.equalsIgnoreCase("Area Sales Manager - Modern Trade")))){  
                                
                         queryCity = "SELECT City FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE  Grade='"+Grade1+"' AND Designation='"+strDesig+"' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "'";                        
                         }
                         */
                        if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                            //Entire grade having citytype DA(Ex: Management Trainee)                            
                            queryCity = "SELECT City FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND '" + toDate + "' between validFrom and validUntil";

                        }
                        if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                            //Entire grade having citytype DA(Ex: Managers)
                            queryCity = "SELECT City FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE  DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND '" + toDate + "' between validFrom and validUntil";

                        }
                        if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                            queryCity = "SELECT City FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND '" + toDate + "' between validFrom and validUntil";
                        }

                        CommonObj.DBValues_Combo(queryCity, "txt_dailyallw_City");
                        formObject.setNGValue("txt_dailyallw_entilperday", "");
                        formObject.setNGValue("txt_dailyallw_calcda", "");
                        formObject.setNGValue("txt_dailyallw_actualdaclaim", "");

                        formObject.clear("txt_dailyallw_Loc");
                        formObject.addItem("txt_dailyallw_Loc", "HQ");
                        formObject.addItem("txt_dailyallw_Loc", "Ex-HQ");
                    } else if (pEvent.getSource().getName().equalsIgnoreCase("txt_dailyallw_City")) {

                        String queryDA = "";
                        String strDesig = formObject.getNGValue("Designation");
                        String toDate = "";
                        if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                            String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                            String strToDate = formObject.getNGValue("dp_dailyallw_todate");
//                        String toDate = "";
                            toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
                        }
                        /*
                         if(Grade1.equalsIgnoreCase("Management Trainee") || Grade1.equalsIgnoreCase("Executive-Sales")){
                            
                         queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE Grade='"+Grade1+"' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND City='" + formObject.getNGValue("txt_dailyallw_City") + "'";
                         } else if ((Grade1.equalsIgnoreCase("Manager Band III") && (strDesig.equalsIgnoreCase("Sales Operation Manager") || strDesig.equalsIgnoreCase("Sales Operations Manager") || strDesig.equalsIgnoreCase("Sales Operations Manager-TN(North)")))
                         || (Grade1.equalsIgnoreCase("Manager Grade IV") && (strDesig.equalsIgnoreCase("Senior Area Sales Manager") || strDesig.equalsIgnoreCase("Senior Area Sales Manager - Bread") || strDesig.equalsIgnoreCase("Sr. Area Sales Manager")))
                         || (Grade1.equalsIgnoreCase("Manager Grade V") && (strDesig.equalsIgnoreCase("Area Sales Manager") || strDesig.equalsIgnoreCase("Area Sales Manager - Fresh Dairy (South)") || strDesig.equalsIgnoreCase("Area Sales Manager - Modern Trade")))){  
                                
                         queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE  Grade='"+Grade1+"' AND Designation='"+strDesig+"' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND City='" + formObject.getNGValue("txt_dailyallw_City") + "'";
                         }
                         */
                        if (formObject.getNGValue("txt_dailyallw_City").equalsIgnoreCase("Others")) {

                            formObject.setNGBackColor("txt_dailyallw_OthrLoc", Color.white);
                            formObject.setEnabled("txt_dailyallw_OthrLoc", true);

                            formObject.clear("txt_dailyallw_Loc");
                            formObject.addItem("txt_dailyallw_Loc", "HQ");
                            formObject.addItem("txt_dailyallw_Loc", "Ex-HQ");
                        } else {

                            formObject.setNGBackColor("txt_dailyallw_OthrLoc", new Color(225, 225, 225));
                            formObject.setEnabled("txt_dailyallw_OthrLoc", false);
                            formObject.setNGValue("txt_dailyallw_OthrLoc", "");

                            formObject.clear("txt_dailyallw_Loc");
                            formObject.addItem("txt_dailyallw_Loc", "HQ");
                            formObject.addItem("txt_dailyallw_Loc", "Ex-HQ");
                        }

                        if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                            //Entire grade having citytype DA(Ex: Management Trainee)                            
                            queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND City='" + formObject.getNGValue("txt_dailyallw_City") + "' AND '" + toDate + "' between validFrom and validUntil";

                        }
                        if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                            //Entire grade having citytype DA(Ex: Managers)
                            queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE  DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND City='" + formObject.getNGValue("txt_dailyallw_City") + "' AND '" + toDate + "' between validFrom and validUntil";

                        }

                        //queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WHERE CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND City='" + formObject.getNGValue("txt_dailyallw_City") + "'";
                        CommonObj.DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                        formObject.setEnabled("txt_dailyallw_entilperday", false);

                        if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
                            try {
                                Long noOfDays = CommonObj.getNoOfDaysBTWDates(formObject.getNGValue("dp_dailyallw_fromdate"), formObject.getNGValue("dp_dailyallw_todate"));
                                formObject.setNGValue("txt_dailyallw_noofdays", noOfDays);
                                formObject.setLocked("txt_dailyallw_noofdays", true);
                                if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("")) {
                                    formObject.setNGValue("txt_dailyallw_calcda", (Float.parseFloat(formObject.getNGValue("txt_dailyallw_entilperday")) * Float.parseFloat(formObject.getNGValue("txt_dailyallw_noofdays"))));
                                    formObject.setLocked("txt_dailyallw_calcda", true);
                                }
                                if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                                    formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                                    throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                                }
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } //Ended By Harinath on 2017/07/24
                    else if (pEvent.getSource().getName().equalsIgnoreCase("txt_dailyallw_Loc")) {
                        String toDate = "";
                        if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                            String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                            String strToDate = formObject.getNGValue("dp_dailyallw_todate");
//                        String toDate = "";
                            toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
                        }
                        String strDesig = formObject.getNGValue("Designation");
                        String queryDA = "";
                        if (formObject.getNGValue("txt_dailyallw_Loc").equalsIgnoreCase("HQ")) {
                            queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND City='" + formObject.getNGValue("txt_dailyallw_City") + "' AND '" + toDate + "' between validFrom and validUntil";
                        } else if (formObject.getNGValue("txt_dailyallw_Loc").equalsIgnoreCase("Ex-HQ")) {
                            queryDA = "SELECT EmpAmount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND CityType='" + formObject.getNGValue("txt_dailyallw_CityType") + "' AND City='" + formObject.getNGValue("txt_dailyallw_City") + "' AND '" + toDate + "' between validFrom and validUntil";
                        }

                        CommonObj.DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                        formObject.setEnabled("txt_dailyallw_entilperday", false);

                        if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
                            try {
                                Long noOfDays = CommonObj.getNoOfDaysBTWDates(formObject.getNGValue("dp_dailyallw_fromdate"), formObject.getNGValue("dp_dailyallw_todate"));
                                formObject.setNGValue("txt_dailyallw_noofdays", noOfDays);
                                formObject.setLocked("txt_dailyallw_noofdays", true);
                                if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("")) {
                                    formObject.setNGValue("txt_dailyallw_calcda", (Float.parseFloat(formObject.getNGValue("txt_dailyallw_entilperday")) * Float.parseFloat(formObject.getNGValue("txt_dailyallw_noofdays"))));
                                    formObject.setLocked("txt_dailyallw_calcda", true);
                                }
                                if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                                    formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                                    throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                                }
                            } catch (ParseException ex) {
                                Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }

                    } //Ended By Harinatha R on 2017/12/04
                    /*else if (pEvent.getSource().getName().equalsIgnoreCase("TypeOfTransfer")) {
                     if(formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("New Joinee")){                    
                     formObject.setNGValue("DateOfTransfer", "");
                     formObject.setEnabled("DateOfTransfer", false);
                     formObject.setNGBackColor("DateOfTransfer", new Color(225, 225, 225));
                     formObject.setNGValue("PrevLoc", "");
                     formObject.setEnabled("PrevLoc", false);
                     formObject.setNGBackColor("PrevLoc", new Color(225, 225, 225));
                     formObject.setNGValue("PrevSubLoc", "");
                     formObject.setEnabled("PrevSubLoc", false);
                     formObject.setNGBackColor("PrevSubLoc", new Color(225, 225, 225));
                     }else{
                     formObject.setEnabled("DateOfTransfer", true);
                     formObject.setNGBackColor("DateOfTransfer", Color.white);                    
                     formObject.setEnabled("PrevLoc", true);
                     formObject.setNGBackColor("PrevLoc", Color.white);                    
                     formObject.setEnabled("PrevSubLoc", true);
                     formObject.setNGBackColor("PrevSubLoc", Color.white);
                    
                     }                    
                     }*/ //Added By Haarinath 2017/03/27
                    else if (pEvent.getSource().getName().equalsIgnoreCase("TypeOfTravel")) {

                        //formObject.clear("txt_trvl_fromloc");
                        //formObject.setNGValue("txt_trvl_fromloc", "");
                        //Coomneted nad added by SandeepKn on 10JAn2020 for ASFI and SFIC changes
                        //String sQuery = "SELECT location FROM EXT_FromLoc with(nolock) where TypeofTravel='" + formObject.getNGValue("TypeOfTravel") + "'";
                        String sQuery = "SELECT location FROM EXT_FromLoc WITH(NOLOCK) WHERE TypeofTravel='" + formObject.getNGValue("TypeOfTravel") + "' AND CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC";
                        CommonObj.DBValues_Combo(sQuery, "txt_trvl_fromloc");
                        //Added By Ashwin BM 2017/05/02
                        String sQueryto = "SELECT location FROM EXT_FromLoc WITH(NOLOCK) WHERE TypeofTravel='" + formObject.getNGValue("TypeOfTravel") + "' AND CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC";
                        CommonObj.DBValues_Combo(sQueryto, "txt_trvl_toloc");
                    } //Added By Ashwin BM 2017/05/02
                    else if (pEvent.getSource().getName().equalsIgnoreCase("txt_trvl_fromloc")) {
                        if (formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others")) {
                            formObject.setEnabled("txt_trvl_OthFrom", true);
                            formObject.setNGBackColor("txt_trvl_OthFrom", Color.white);
                        } else if (!formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase("Others")) {
                            formObject.setEnabled("txt_trvl_OthFrom", false);
                            formObject.setNGValue("txt_trvl_OthFrom", "");
                            formObject.setNGBackColor("txt_trvl_OthFrom", new Color(225, 225, 225));
                        }  //End By Ashwin BM 2017/05/02
                    } /*else if (pEvent.getSource().getName().equalsIgnoreCase("txt_trvl_fromloc")) {
                     formObject.clear("txt_trvl_toloc");
                     formObject.setNGValue("txt_trvl_toloc", "");
                     String sQuery = "SELECT location FROM EXT_FromLoc with(nolock) where location!='" + formObject.getNGValue("txt_trvl_fromloc") + "' and TypeofTravel='" + formObject.getNGValue("TypeOfTravel") + "'";
                     CommonObj.DBValues_Combo(sQuery, "txt_trvl_toloc");
                     } */ else if (pEvent.getSource().getName().equalsIgnoreCase("txt_trvl_toloc")) {
                        //Added By Ashwin BM 2017/05/02
                        if (formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                            formObject.setEnabled("txt_trvl_OthTo", true);
                            formObject.setNGBackColor("txt_trvl_OthTo", Color.white);
                        } else if (!formObject.getNGValue("txt_trvl_toloc").equalsIgnoreCase("Others")) {
                            formObject.setEnabled("txt_trvl_OthTo", false);
                            formObject.setNGValue("txt_trvl_OthTo", "");
                            formObject.setNGBackColor("txt_trvl_OthTo", new Color(225, 225, 225));
                        } //End By Ashwin BM 2017/05/02

                        if (formObject.getNGValue("txt_trvl_fromloc") == "" || formObject.getNGValue("txt_trvl_fromloc") == "--Select--") {
                            throw new ValidatorException(new FacesMessage("Please Select From Location", "txt_trvl_fromloc"));
                        } else if (formObject.getNGValue("txt_trvl_fromloc").equalsIgnoreCase(formObject.getNGValue("txt_trvl_toloc"))) {
                            throw new ValidatorException(new FacesMessage("From and To Location are same", ""));
                        }
                    } //Ended By Harinath 2017/03/27
                    //Added By Harinath 2017/05/29
                    else if (pEvent.getSource().getName().equalsIgnoreCase("txt_trvl_tcktno")) {

                        if (!formObject.getNGValue("txt_trvl_tcktno").equalsIgnoreCase("")) {
                            int rowCount = formObject.getLVWRowCount("list_travel");
                            for (int i = 0; i < rowCount; i++) {

                                if (formObject.getSelectedIndex("list_travel") != i && formObject.getNGValue("list_travel", i, 7).equalsIgnoreCase(formObject.getNGValue("txt_trvl_tcktno"))) {
                                    fm = new FacesMessage("Same ticket number is already entered for other travel...", "");
                                    throw new ValidatorException(fm);
                                }
                            }
                        }
                    }
                    //Ended By Harinath 2017/05/29

                } //CommonObj.writeToLog(2,"VALUE_CHANGED END>",winame);

                if (pEvent.getSource().getName().equalsIgnoreCase("TypeOfTravel")) {
                    CommonObj.writeToLog(2, "TypeOfTravel $$$$$ :: " + formObject.getNGValue("TypeOfTravel"), winame);

                    //formObject.clear("txt_trvl_fromloc");
                    //formObject.setNGValue("txt_trvl_fromloc", "");
                    //Commented and added by sandeepkn on 10Jan2020 for ASFI and SFIC changes
                    //String sQuery = "SELECT location FROM EXT_FromLoc with(nolock) where TypeofTravel='" + formObject.getNGValue("TypeOfTravel") + "'";
                    String sQuery = "SELECT location FROM EXT_FromLoc WITH(NOLOCK) WHERE TypeofTravel='" + formObject.getNGValue("TypeOfTravel") + "' AND CompanyCode='" + formObject.getNGValue("CompanyCode") + "' ORDER BY Location ASC";
                    CommonObj.writeToLog(2, "sQuery  ::: " + sQuery, winame);
                    CommonObj.DBValues_Combo(sQuery, "txt_trvl_fromloc");
                    //Added By Ashwin BM 2017/05/02
                    CommonObj.DBValues_Combo(sQuery, "txt_trvl_toloc");
                }
                //Added by Sivashankar KS on 11-Mar-2019 starts here  
                if (pEvent.getSource().getName().equalsIgnoreCase("cb_hotelfare_britannia_statename")) {
                    writeToLog(2, "cb_hotelfare_britannia_statename $$$$$ :: " + formObject.getNGValue("CompanyCode"), strprcsinstid);
                    writeToLog(2, "cb_hotelfare_britannia_statename $$$$$ :: " + formObject.getNGValue("cb_hotelfare_britannia_statename"), strprcsinstid);
                    formObject.setNGValue("txt_hotelfare_britannia_gst", "");
                    String sQuery1 = "SELECT GSTNumber FROM EXT_AP_ER_GST_MASTER WITH(NOLOCK) WHERE CompanyCode='" + formObject.getNGValue("CompanyCode") + "' AND StateName='" + formObject.getNGValue("cb_hotelfare_britannia_statename") + "'";
                    writeToLog(2, "sQuery1  ::: " + sQuery1, strprcsinstid);
                    CommonObj.DBValues_Field(sQuery1, "txt_hotelfare_britannia_gst");
                    formObject.setNGValue("txt_hotelfare_britannia_bplace", "");
                    String sQuery12 = "SELECT BusinessPlace FROM EXT_AP_ER_GST_BUSINESSPLACE_WITH_GLCODE_MASTER WITH(NOLOCK) WHERE StateName='" + formObject.getNGValue("cb_hotelfare_britannia_statename") + "'";
                    writeToLog(2, "sQuery12  ::: " + sQuery12, strprcsinstid);
                    CommonObj.DBValues_Field(sQuery12, "txt_hotelfare_britannia_bplace");
                    formObject.setNGValue("txt_hotelfare_britannia_sgstno", "");
                    String sQuery13 = "SELECT SGST FROM EXT_AP_ER_GST_BUSINESSPLACE_WITH_GLCODE_MASTER WITH(NOLOCK) WHERE StateName='" + formObject.getNGValue("cb_hotelfare_britannia_statename") + "'";
                    writeToLog(2, "sQuery13  ::: " + sQuery13, strprcsinstid);
                    CommonObj.DBValues_Field(sQuery13, "txt_hotelfare_britannia_sgstno");
                    formObject.setNGValue("txt_hotelfare_britannia_cgstno", "");
                    String sQuery14 = "SELECT CGST FROM EXT_AP_ER_GST_BUSINESSPLACE_WITH_GLCODE_MASTER WITH(NOLOCK) WHERE StateName='" + formObject.getNGValue("cb_hotelfare_britannia_statename") + "'";
                    writeToLog(2, "sQuery14  ::: " + sQuery14, strprcsinstid);
                    CommonObj.DBValues_Field(sQuery14, "txt_hotelfare_britannia_cgstno");
                }
                writeToLog(2, "Change Name-->" + pEvent.getSource().getName(), strprcsinstid);
                if (pEvent.getSource().getName().equalsIgnoreCase("dp_dailyallw_todate")) {

                    String strDesig = formObject.getNGValue("Designation");
                    if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                        String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                        String strToDate = formObject.getNGValue("dp_dailyallw_todate");
                        String toDate = "";
                        toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
//                            ibpsadmin end
                        /*
                             //Added By Harinath on 2017/03/28
                             //String Grade1 = formObject.getNGValue("Grade");
                             String queryDA = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='DailyAllowance' and grade='" + Grade1 + "'";
                             CommonObj.DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                             formObject.setEnabled("txt_dailyallw_entilperday", false);
                             //Ended By Harinath on 2017/03/28
                         */
                        try {
                            Long noOfDays = CommonObj.getNoOfDaysBTWDates(formObject.getNGValue("dp_dailyallw_fromdate"), formObject.getNGValue("dp_dailyallw_todate"));
                            CommonObj.writeToLog(2, " In try noOfDays" + noOfDays, winame);
                            formObject.setNGValue("txt_dailyallw_noofdays", noOfDays);
                            formObject.setLocked("txt_dailyallw_noofdays", true);

                            //Added by SandeepKn on 08Jan2020 for entilperday value -- Start                                
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                CommonObj.writeToLog(2, " In Amount If txt_dailyallw_entilperday1" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                CommonObj.DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                                formObject.setEnabled("txt_dailyallw_entilperday", false);
                                CommonObj.writeToLog(2, "txt_dailyallw_entilperday1" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);

                            }
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                CommonObj.writeToLog(2, " In Amount If txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                if (CommonObj.SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                        || CommonObj.SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                    CommonObj.writeToLog(2, " In Designation If txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                    //Entire grade having citytype DA(Ex: Management Trainee)
                                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                    formObject.setEnabled("txt_dailyallw_CityType", true);
                                    formObject.setEnabled("txt_dailyallw_City", true);
                                    CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                                    formObject.setNGValue("txt_dailyallw_entilperday", "");
                                    CommonObj.writeToLog(2, "txt_dailyallw_entilperday12" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                }

                            }
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                                //Entire grade having citytype DA(Ex: Managers)
                                CommonObj.writeToLog(2, "In If Amount txt_dailyallw_entilperday123" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                formObject.setEnabled("txt_dailyallw_CityType", true);
                                formObject.setEnabled("txt_dailyallw_City", true);
                                CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                formObject.setEnabled("txt_dailyallw_entilperday", false);
                                formObject.setNGValue("txt_dailyallw_entilperday", "");
                                CommonObj.writeToLog(2, "txt_dailyallw_entilperday123" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                            }
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                CommonObj.writeToLog(2, "In if txt_dailyallw_entilperday1234" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                                formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                                formObject.setNGBackColor("txt_dailyallw_Loc", Color.white);
                                formObject.setEnabled("txt_dailyallw_CityType", true);
                                formObject.setEnabled("txt_dailyallw_City", true);
                                formObject.setEnabled("txt_dailyallw_Loc", true);
                                CommonObj.DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                                formObject.setEnabled("txt_dailyallw_entilperday", false);
                                formObject.setNGValue("txt_dailyallw_entilperday", "");
                                CommonObj.writeToLog(2, "txt_dailyallw_entilperday1234" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);

                            }
                            if (!CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                                    && !CommonObj.SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {
                                CommonObj.writeToLog(2, "In if txt_dailyallw_entilperday1235" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                                //String queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WHERE DAType='Grade' AND Grade='" + Grade1 + "'";
                                CommonObj.DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                                formObject.setEnabled("txt_dailyallw_entilperday", false);

                                formObject.setNGBackColor("txt_dailyallw_CityType", new Color(255, 255, 255));
                                formObject.setNGBackColor("txt_dailyallw_City", new Color(255, 255, 255));
                                formObject.setNGBackColor("txt_dailyallw_Loc", new Color(255, 255, 255));
                                formObject.setNGBackColor("txt_dailyallw_OthrLoc", new Color(225, 225, 225));
                                formObject.setEnabled("txt_dailyallw_CityType", false);
                                formObject.setEnabled("txt_dailyallw_City", false);
                                formObject.setEnabled("txt_dailyallw_Loc", false);
                                formObject.setEnabled("txt_dailyallw_OthrLoc", false);
                                CommonObj.writeToLog(2, "txt_dailyallw_entilperday1235" + formObject.getNGValue("txt_dailyallw_entilperday"), winame);
                            }

                            //Added by SandeepKn on 08Jan2020 for entilperday value -- End                               
                            if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("0")) {
                                formObject.setNGValue("txt_dailyallw_calcda", (Float.parseFloat(formObject.getNGValue("txt_dailyallw_entilperday")) * Float.parseFloat(formObject.getNGValue("txt_dailyallw_noofdays"))));
                                formObject.setLocked("txt_dailyallw_calcda", true);
                                CommonObj.writeToLog(2, "In if setting txt_dailyallw_calcda" + formObject.getNGValue("txt_dailyallw_calcda"), winame);
                            }
                            if (Float.parseFloat(formObject.getNGValue("txt_dailyallw_actualdaclaim")) > Float.parseFloat(formObject.getNGValue("txt_dailyallw_calcda"))) {
                                formObject.setNGValue("txt_dailyallw_actualdaclaim", "");
                                CommonObj.writeToLog(2, "In if setting txt_dailyallw_actualdaclaim greater than txt_dailyallw_calcda" + formObject.getNGValue("txt_dailyallw_actualdaclaim"), winame);
                                throw new ValidatorException(new FacesMessage("Actual DA Claimed amount cannot be greater the Calculated DA", "EligibleAmount"));
                            }
                        } catch (ParseException ex) {
                            Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                //Added by Sivashankar KS on 11-Mar-2019 ends here

                break;
            }
            case KEY_DOWN: {
                //CommonObj.writeToLog(2, "KEY_DOWN", winame);                
                break;
            }
            case FOCUS_LOST: {
                //CommonObj.writeToLog(2,"FOCUS_LOST"+pEvent.getSource().getName()+"in ER Initiation",winame);                
                if (strSubcategory.equalsIgnoreCase("Mobile Re-Imbursements")) {
                    if (fieldName.equalsIgnoreCase("BillValueLessTax") || fieldName.equalsIgnoreCase("ValueOfPersonalCalls")) {
                        break;
                    }
                    //if(fieldName.equalsIgnoreCase("BillValueLessTax")||fieldName.equalsIgnoreCase("ValueOfPersonalCalls")||fieldName.equalsIgnoreCase("ServiceTax_BillValue")||fieldName.equalsIgnoreCase("ServiceTax_ValueOfPersonalCalls"))
                    /*  if (fieldName.equalsIgnoreCase("BillValueLessTax") || fieldName.equalsIgnoreCase("ValueOfPersonalCalls")) 
                     {
                     Float billval = 0.00F;
                     Float perCall = 0.00F;
                     Float serTaxBill = 0.00F;
                     Float serTaxPerCall = 0.00F;
                     Float TotalBill = 0.00F;
                     String strBillVal=formObject.getNGValue("BillValueLessTax");
                     String strPerCall=formObject.getNGValue("ValueOfPersonalCalls");
                     CommonObj.writeToLog(2,"FOCUS_LOST:strBillVal:"+strBillVal,winame);  
                     CommonObj.writeToLog(2,"FOCUS_LOST:strPerCall:"+strPerCall,winame); 
                     formObject.setNGValue("TotalAmount", "");                            
                             
                     if (fieldName.equalsIgnoreCase("BillValueLessTax")) {
                     if (!formObject.getNGValue("BillValueLessTax").equalsIgnoreCase("")) {
                     billval = Float.parseFloat(formObject.getNGValue("BillValueLessTax"));
                     //if (billval>0.0) {
                     CommonObj.writeToLog(2,"FOCUS_LOST:billval>0",winame); 
                     formObject.setNGValue("ServiceTax_BillValue", billval * 0.15);
                     } else {
                     formObject.setNGValue("ServiceTax_BillValue", "0.00");
                     }
                     } else if (fieldName.equalsIgnoreCase("ValueOfPersonalCalls")) {
                     if (!formObject.getNGValue("ValueOfPersonalCalls").equalsIgnoreCase("")) {
                     perCall = Float.parseFloat(formObject.getNGValue("ValueOfPersonalCalls"));
                     //if (perCall>0.0) {
                     CommonObj.writeToLog(2,"FOCUS_LOST:perCall>0",winame); 
                     formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", perCall * 0.15);
                     } else {
                     formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", "0.00");
                     }
                     }
                     billval = Float.parseFloat(formObject.getNGValue("BillValueLessTax"));
                     perCall = Float.parseFloat(formObject.getNGValue("ValueOfPersonalCalls"));
                     serTaxBill = Float.parseFloat(formObject.getNGValue("ServiceTax_BillValue"));
                     serTaxPerCall = Float.parseFloat(formObject.getNGValue("ServiceTax_ValueOfPersonalCalls"));
                     TotalBill = billval - perCall + (serTaxBill - serTaxPerCall);
                     formObject.setNGValue("TotalAmount", TotalBill);
                     break;                           
                     }
                     */
                }
//                    if (pEvent.getSource().getName().equalsIgnoreCase("BillPlan")) 
//                    {
//                        if(formObject.getNGValue("BillPlan").equalsIgnoreCase("Others"))
//                        {
//                            formObject.setVisible("Label106", true);
//                            formObject.setVisible("BillPlanOthers", true);
//                            formObject.setEnabled("BillPlanOthers", true);
//                        }
//                        else
//                        {
//                            formObject.setVisible("Label106", false);
//                            formObject.setVisible("BillPlanOthers", false);
//                        }
//                        
//                    }
                /* if (pEvent.getSource().getName().equalsIgnoreCase("ClaimedAmount")) 
                 {
                 Float fClaimedAmount = Float.parseFloat(formObject.getNGValue("ClaimedAmount"));
                 Float fEligibleAmount = Float.parseFloat(formObject.getNGValue("EligibleAmount"));
                 if (formObject.getNGValue("ClaimedAmount") != "") {
                 if (fClaimedAmount > fEligibleAmount) {
                 formObject.setNGValue("ClaimedAmount", "");
                 formObject.setNGFocus("ClaimedAmount");
                 //fm = new FacesMessage("Claimed amount cannot be greater the eligible amount", "EligibleAmount");  
                 throw new ValidatorException(new FacesMessage("Claimed amount cannot be greater the eligible amount", "EligibleAmount"));
                 } else {
                 formObject.setNGValue("TotalAmount", formObject.getNGValue("ClaimedAmount"));
                 }
                 }
                 }*/

                if (pEvent.getSource().getName().equalsIgnoreCase("RoadtaxYN")) {
                    CommonObj.writeToLog(2, "FOCUS_LOST RoadtaxYN", winame);
                    //formObject.setEnabled("frm_moving_personal_effects", true);
                    if (formObject.getNGValue("RoadtaxYN").equalsIgnoreCase("Yes")) {
                        formObject.setEnabled("RoadTax", true);
                    } else {
                        formObject.setEnabled("RoadTax", false);
                    }

                } else if (pEvent.getSource().getName().equalsIgnoreCase("LossYN")) {
                    CommonObj.writeToLog(2, "FOCUS_LOST LossYN", winame);
                    //formObject.setEnabled("frm_moving_personal_effects", true);
                    if (formObject.getNGValue("LossYN").equalsIgnoreCase("Yes")) {
                        formObject.setEnabled("LossOnPreClosureLease", true);
                    } else {
                        formObject.setEnabled("LossOnPreClosureLease", false);
                    }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("OctroiYN")) {
                    CommonObj.writeToLog(2, "FOCUS_LOST OctroiYN", winame);
                    //formObject.setEnabled("frm_moving_personal_effects", true);
                    if (formObject.getNGValue("OctroiYN").equalsIgnoreCase("Yes")) {
                        formObject.setEnabled("OctroiPay", true);
                    } else {
                        formObject.setEnabled("OctroiPay", false);
                    }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("PackYN")) {
                    CommonObj.writeToLog(2, "FOCUS_LOST PackYN", winame);
                    //formObject.setEnabled("frm_moving_personal_effects", true);
                    if (formObject.getNGValue("PackYN").equalsIgnoreCase("Yes")) {
                        formObject.setEnabled("PackMove", true);
                    } else {
                        formObject.setEnabled("PackMove", false);
                    }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("SchlfeeYN")) {
                    CommonObj.writeToLog(2, "FOCUS_LOST SchlfeeYN", winame);
                    //formObject.setEnabled("frm_moving_personal_effects", true);
                    if (formObject.getNGValue("SchlfeeYN").equalsIgnoreCase("Yes")) {
                        CommonObj.writeToLog(2, "FOCUS_LOST SchlfeeYN if", winame);
                        formObject.setEnabled("SchlfeenoYN", true);;
                    } else {
                        CommonObj.writeToLog(2, "FOCUS_LOST SchlfeeYN else", winame);
                        formObject.setEnabled("SchlfeenoYN", false);
                        formObject.setNGValue("SchlfeeElbamnt", "");
                        formObject.setNGValue("NameChild1", "");
                        formObject.setNGValue("NameChild2", "");
                        formObject.setNGValue("SchlfeenoYN", "--Select--");
                        formObject.setNGValue("SchlfeeClaimamnt", "");
                        formObject.setEnabled("SchlfeeElbamnt", false);
                        formObject.setEnabled("NameChild1", false);
                        formObject.setEnabled("NameChild2", false);
                        formObject.setEnabled("SchlfeeClaimamnt", false);
                    }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("SchlfeeClaimamnt")) {
                    CommonObj.writeToLog(2, "FOCUS_LOST SchlfeeClaimamnt else", winame);
                    Float fClaimedAmount = Float.parseFloat(formObject.getNGValue("SchlfeeClaimamnt"));
                    Float fEligibleAmount = Float.parseFloat(formObject.getNGValue("SchlfeeElbamnt"));

                    if (formObject.getNGValue("SchlfeeClaimamnt") != "") {
//Modified on 23-Oct-2018 for removing validation for manager grade I and above as per jestus mail
                        if (Grade1.equalsIgnoreCase("Vice President") || Grade1.equalsIgnoreCase("Manager Grade I") || Grade1.equalsIgnoreCase("Managing Director")) {
                            //
                        } else {
                            if (fClaimedAmount > fEligibleAmount) {
                                formObject.setNGValue("SchlfeeClaimamnt", "");
                                formObject.setNGFocus("SchlfeeClaimamnt");
                                //fm = new FacesMessage("Claimed amount cannot be greater the eligible amount", "EligibleAmount");  
                                throw new ValidatorException(new FacesMessage("Claimed amount cannot be greater the eligible amount", "EligibleAmount"));
                            }
                        }
                    }

//                    if (formObject.getNGValue("SchlfeeClaimamnt") != "") {
//                        if (fClaimedAmount > fEligibleAmount) {
//                            formObject.setNGValue("SchlfeeClaimamnt", "");
//                            formObject.setNGFocus("SchlfeeClaimamnt");
//                            //fm = new FacesMessage("Claimed amount cannot be greater the eligible amount", "EligibleAmount");  
//                            throw new ValidatorException(new FacesMessage("Claimed amount cannot be greater the eligible amount", "EligibleAmount"));
//                        } else {
//                            //formObject.setNGValue("TotalAmount", formObject.getNGValue("SchlfeeClaimamnt"));
//                        }
//                    }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("SchlfeenoYN")) {
                    // formObject.setEnabled("frm_moving_personal_effects", true);

                    if (formObject.getNGValue("SchlfeenoYN").equalsIgnoreCase("1")) {
                        String querymobile = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where TypeofInvoice='Relocation' and Subcategory1='SchoolFee' and grade='" + Grade1 + "'";
                        CommonObj.DBValues_Field(querymobile, "SchlfeeElbamnt");
                        formObject.setEnabled("SchlfeeElbamnt", false);
                        formObject.setEnabled("NameChild1", true);
                        formObject.setEnabled("SchlfeeClaimamnt", true);
                    } else if (formObject.getNGValue("SchlfeenoYN").equalsIgnoreCase("2")) {
                        formObject.setEnabled("SchlfeeElbamnt", false);
                        formObject.setEnabled("NameChild1", true);
                        formObject.setEnabled("NameChild2", true);
                        formObject.setEnabled("SchlfeeClaimamnt", true);
                        String querymobile = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where TypeofInvoice='Relocation' and Subcategory1='SchoolFee' and grade='" + Grade1 + "'";
                        CommonObj.DBValues_Field(querymobile, "SchlfeeElbamnt");
                        formObject.setNGValue("SchlfeeElbamnt", 2 * Float.parseFloat(formObject.getNGValue("SchlfeeElbamnt")));

                    } else {
                        formObject.setNGValue("SchlfeeElbamnt", "");
                        formObject.setNGValue("NameChild1", "");
                        formObject.setNGValue("NameChild2", "");
                        formObject.setNGValue("SchlfeenoYN", "--Select--");
                        formObject.setNGValue("SchlfeeClaimamnt", "");
                        formObject.setEnabled("SchlfeeElbamnt", false);
                        formObject.setEnabled("NameChild1", false);
                        formObject.setEnabled("NameChild2", false);
                        formObject.setEnabled("SchlfeeClaimamnt", false);
                    }
                } else if (pEvent.getSource().getName().equalsIgnoreCase("Txt_MobilNo")) {
                    formObject.setNGValue("MobileNo", formObject.getNGValue("Txt_MobilNo"));
                }

                break;
            }
        }
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) {

    }

    @Override
    public void initialize() {
        //DOnt add any code over here.....

    }

}
