/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import java.util.HashMap;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author ngappadmin
 */
public class HR_Approval implements FormListener
{
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    @Override
    public void formLoaded(FormEvent fe) {
        
    }

    @Override
    public void formPopulated(FormEvent fe) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        CommonObj.writeToLog(2, "Inside formLoaded Approver1", winame);
        formObject.setNGValue("Comments", "");
        if ((WorkstepName.equalsIgnoreCase("HR_Verification")|| WorkstepName.equalsIgnoreCase("HR_Approval")) && (formObject.getNGValue("SubCategory1").equalsIgnoreCase("Exceptional Advances")))
        {
            formObject.setEnabled("RepaymentSchedule", true);
            formObject.setLocked("RepaymentSchedule", false);
            
            formObject.setVisible("lbl_sal_repay", true); 
            formObject.setVisible("RepaymentSchedule", true);
        }
        formObject.setVisible("btn_submit", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Travel", false);
        formObject.setVisible("btn_Rescan", false);
        formObject.setVisible("Label10", false);
        formObject.setVisible("Label9", false);
        formObject.setVisible("Label11", false);
        formObject.setVisible("Text25", false);
        formObject.setVisible("Text26", false);
        formObject.setVisible("Combo6", false);
        formObject.setVisible("txt_totalamount", true);
        formObject.setVisible("TotalAmount", true);
        
        //Added started by Sivashankar for hiding the Grade 29-June-2018
        String strFlag = "";
        String sqlQuery = "SELECT Value FROM EXT_AP_ER_MASTER_EXTERNALCONSTANTS WITH(NOLOCK) WHERE ColumnName='BLOCKPORTAL'";
        List<List<String>> Flag = formObject.getDataFromDataSource(sqlQuery);
        strFlag = Flag.get(0).get(0);
        CommonObj.writeToLog(2, "sqlQuery ==> " + sqlQuery, winame);
        CommonObj.writeToLog(2, "strFlag ==> " + strFlag, winame);
        if (strFlag.equalsIgnoreCase("YES")) {
            formObject.setVisible("lbl_inv_grade", false);
            formObject.setVisible("Grade", false);
            formObject.setVisible("lbl_inv_design", false);
            formObject.setVisible("Designation", false);
        }
        //Added ended by Sivashankar for hiding the Grade
        
        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        CommonObj.writeToLog(2, "ER WS Status=" + ER_WS, winame);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) 
        {
            CommonObj.HideFrames_Init();
            CommonObj.Approval_lock();
            if (WorkstepName.equalsIgnoreCase("HR_Verification"))
            formObject.setCaption("btn_Approve", "Verify");
            formObject.setLeft("btn_Approve", 220);
            formObject.setLeft("btn_Reject", 350);
            
        }
        
        CommonObj.enableDORMailBtn(formObject);
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException {
       CommonObj.InserComments(); 
    }

    @Override
    public void eventDispatched(ComponentEvent ce) throws ValidatorException 
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
        switch (ce.getType()) 
        {
            case MOUSE_CLICKED: 
            {   
                if (ce.getSource().getName().equalsIgnoreCase("Btn_Approve")) 
                {
                    if ((WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval")) && formObject.getNGValue("SubCategory1").equalsIgnoreCase("Exceptional Advances") && formObject.getNGValue("RepaymentSchedule").equalsIgnoreCase(""))
                    {
                        throw new ValidatorException(new FacesMessage("Please eneter the repayment schedule", "RepaymentSchedule"));
                    
                    }
                    
                    formObject.setNGValue("ApprSts1", "Approved");
                    formObject.RaiseEvent("WFDone");
                    
                    /*
                    String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
                    if(WorkstepName.equalsIgnoreCase("HR_Verification"))
                    {
                        formObject.setNGValue("HR_Verf_Sts","Approve");
                        formObject.RaiseEvent("WFDone");
                    }
                  else if(WorkstepName.equalsIgnoreCase("HR_Approval"))
                    {
                        formObject.setNGValue("HR_Appr_Sts","Approve");
                        formObject.RaiseEvent("WFDone");
                    }*/
                }
                else if (ce.getSource().getName().equalsIgnoreCase("btn_Reject")) 
                {
                    formObject.setNGValue("ApprSts1", "Reject");
                    formObject.RaiseEvent("WFDone");
                    
                    /*
                    String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
                    if(WorkstepName.equalsIgnoreCase("HR_Verification"))
                    {
                        formObject.setNGValue("HR_Verf_Sts","Reject");
                        formObject.RaiseEvent("WFDone");
                    }
                    else if(WorkstepName.equalsIgnoreCase("HR_Approval"))
                    {
                        formObject.setNGValue("HR_Appr_Sts","Reject");
                        formObject.RaiseEvent("WFDone");
                    }*/
                }
            break;    
            }
        }
        
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) {
        
    }

    @Override
    public void initialize() {
        
    }
    
}
