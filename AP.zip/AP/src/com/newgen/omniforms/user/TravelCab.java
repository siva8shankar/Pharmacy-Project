/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.component.PickList;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.sapfunctions.SAPFunc;
import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author deva.r
 */
public class TravelCab implements FormListener
{
      AP_CommonFunctions CommonObj = new AP_CommonFunctions();
       SAPFunc Sap_obj=new SAPFunc();
      String typeofInvoice1="";
      public boolean flagonload = false;
    @Override
    public void formLoaded(FormEvent fe) 
    {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        
        formObject.setVisible("btn_load", true);   
        formObject.setEnabled("btn_load", true);
        formObject.setLocked("VendName", false);
        formObject.setVisible("btn_ImportDoc", true);
        formObject.setVisible("btn_trnsdtl", false);
        formObject.setEnabled("TypeOfProcess", false);
        formObject.setVisible("btn_sub", true);
        formObject.setEnabled("frm_invdtl_po", true);
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName"); 
        //formObject.setNGValue("PostSts", formObject.getWFWorkitemName());
       // System.out.println("WorkstepName in Travel Cab Initiation " + WorkstepName);
        CommonObj.writeToLog(2,"WorkstepName in Travel Cab Initiation " + WorkstepName,winame);
        flagonload = true;
        
        if(formObject.getNGValue("WorkID").equalsIgnoreCase(""))
        formObject.setNGValue("WorkID", winame);    
        formObject.setNGValue("TypeOfProcess", "NONPO");
        formObject.setEnabled("TypeOfProcess", false);        
        
        formObject.setNGValue("CompanyCode", "BIL1");
        formObject.setNGValue("Region", "KA01"); 
        formObject.setNGValue("FiscalYr",CommonObj.Cur_FinanicalYr()); //logic need to change
        
        
        String TypeOfInvoice_val=formObject.getNGValue("TypeOfInvoice");
        CommonObj.writeToLog(2,"Type of invoice"+TypeOfInvoice_val, winame);
        if (TypeOfInvoice_val.equalsIgnoreCase("--Select--") ||TypeOfInvoice_val.equalsIgnoreCase("")|| TypeOfInvoice_val==null)
        {
            CommonObj.TravelCab_Initaition();     
        }
        else
        {
             CommonObj.TravelCab_Frames();
            
        }
        
         
    }
 
    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException {
        CommonObj.InserComments();  
        
    }

    @Override
    public void eventDispatched(ComponentEvent pEvent) throws ValidatorException 
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String strTypeOfProcess=formObject.getNGValue("TypeOfProcess");
        String strTypeOfInvoice=formObject.getNGValue("TypeOfInvoice");
        String strSubCategory1=formObject.getNGValue("SubCategory1");
        String strSubCat2=formObject.getNGValue("SubCat2");
        String strSubCat3=formObject.getNGValue("SubCat3");
            switch (pEvent.getType()) 
           {
                        
            case MOUSE_CLICKED:
            {
                FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
                String winame = formConfig.getConfigElement("ProcessInstanceId");

                if (pEvent.getSource().getName().equalsIgnoreCase("btn_submit")) 
                       {
                           String S_query="";
                           String S_count="";
                               CommonObj.writeToLog(2,"Inside ngfuser:btn_submit",winame); 
                               formObject.setNGValue("InitSts", "TC");
                               typeofInvoice1=formObject.getNGValue("TypeofInvoice");
                               if(typeofInvoice1.equalsIgnoreCase("Cab"))
                               {
                                   S_query="SELECT count(PID) FROM EXT_AP_Cab_Lineitems WITH (NOLOCK) where PID='"+formObject.getWFWorkitemName()+"'";
                               }
                               else if(typeofInvoice1.equalsIgnoreCase("Travel"))
                               {
                                   S_query="SELECT count(PID) FROM EXT_AP_Travel_Lineitems WITH (NOLOCK) where PID='"+formObject.getWFWorkitemName()+"'";
                               }
                               CommonObj.writeToLog(2,"Travel/Cab Query="+S_query, winame);
                               S_count=CommonObj.DB_QueryExecute1(S_query);
                               CommonObj.writeToLog(2,"S_count="+S_count, winame);
                               if(S_count.equalsIgnoreCase("NoEntry") || S_count.equalsIgnoreCase("0") )
                               {
                                    throw new ValidatorException(new FacesMessage("Kindly Add "+typeofInvoice1+"Details","TypeOfInvoice"));
                               }
                               else
                               {
                               formObject.setNGValue("MaxAppLevel", "1");
                               formObject.setNGValue("TCsts", "Approvel");
                               formObject.setNGValue("ApprSts1", "Pending");
                               formObject.RaiseEvent("WFDone"); 
                               break;
                               }

                       }
                else if (pEvent.getSource().getName().equalsIgnoreCase("btn_Reject")) {                    
                    formObject.setNGValue("TCsts", "Reject");
                    formObject.RaiseEvent("WFDone");
                    break;
                    
                }
               else if (pEvent.getSource().getName().equalsIgnoreCase("btn_load")) 
                       {
                           if (formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("")|| formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("--Select--")) {
                                throw new ValidatorException(new FacesMessage("Please select the type of invoice", "TypeOfInvoice"));
                            }
                            FormReference formObject2 = FormContext.getCurrentInstance().getFormReference();
                            if (formObject2.getNGValue("SubCategory1").equalsIgnoreCase("")|| formObject2.getNGValue("SubCategory1").equalsIgnoreCase("--Select--")) {
                                throw new ValidatorException(new FacesMessage("Please select the subcategory1", "SubCategory1"));
                            } 
                            if (formObject2.getNGValue("SubCat2").equalsIgnoreCase("")|| formObject2.getNGValue("SubCat2").equalsIgnoreCase("--Select--")) {
                                throw new ValidatorException(new FacesMessage("Please select the subcategory2", "SubCategory1"));
                            } 
                            if (formObject2.getNGValue("SubCat3").equalsIgnoreCase("")||formObject2.getNGValue("SubCat3").equalsIgnoreCase("--Select--")) {
                                throw new ValidatorException(new FacesMessage("Please select the subcategory3", "SubCategory1"));
                            } 
                            CommonObj.TravelCab_Frames();
                            formObject.setNGValue("FiscalYr",CommonObj.Cur_FinanicalYr()); //logic need to change
                            formObject.setLocked("FiscalYr", true);                            
                            
                            formObject.RaiseEvent("WFSave");
                       }
                else if (pEvent.getSource().getName().equalsIgnoreCase("btn_sub")) {
                    String strTypeOfInvoive = formObject.getNGValue("TypeOfInvoice");
                    formObject.clear("SubCategory1");
                    formObject.setNGValue("SubCategory1", "");
                    String querySubCat = "select DISTINCT(SubCat1) from EXT_AP_ER_InvoiceSub with(nolock) where TYPEOFINV='" + strTypeOfInvoive + "' and Process='TC' and SubCat1 IS NOT NULL and SubCat1 !=''";
                    //CommonObj.DBValues_Combo(querySubCat, "SubCategory1"); 
                    PickList objPickList1 = formObject.getNGPickList("btn_sub", "Sub Category1", true, 20, false);
                    objPickList1.setVisible(true);
                    objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                    objPickList1.setWidth(350);
                    objPickList1.setWidth(350);
                    objPickList1.populateData(querySubCat);
                }
                break;
            }
            case VALUE_CHANGED:
            {
                if (flagonload) {
               
                if (pEvent.getSource().getName().equalsIgnoreCase("SubCat2")) 
                {
                    String strSubcategory=formObject.getNGValue("SubCat2");
                    if (strSubcategory.equalsIgnoreCase("Not Applicable"))
                    {
                        formObject.setNGValue("SubCat3","Not Applicable");
                        formObject.setLocked("SubCat3", true);
                        
                    }
                }
               
            }
            break;
            }//End of Value Changed
            case FOCUS_LOST: {
               /* FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
                String winame = formConfig.getConfigElement("ProcessInstanceId");
                CommonObj.writeToLog(2, "FOCUS_LOST", winame);
                if (pEvent.getSource().getName().equalsIgnoreCase("TotInvoiceAmnt"))
                {
                    Float currtemp = Float.parseFloat(formObject.getNGValue("TotInvoiceAmnt"));
                    String curr = formObject.getNGValue("Currency");
                    if (curr.equalsIgnoreCase("INR"))
                    {
                        Float currtemp1=(float)((currtemp)*(1.00));
                        
                        CommonObj.writeToLog(2, "FOCUS_LOST  TotInvoiceAmnt:"+currtemp1, winame);
                        formObject.setNGValue("AmntLocCurrency", currtemp1);
                        formObject.setLocked("AmntLocCurrency", true);
                    }
                }*/
            }//End of Focus lost

        }//End of Switch
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) {
        
    }

    @Override
    public void initialize() {
        
    }
    
}

