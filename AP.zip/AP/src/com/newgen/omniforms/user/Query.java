/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import java.util.HashMap;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author ngappadmin
 */
public class Query implements FormListener {
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    

    @Override
    public void formLoaded(FormEvent fe) {
        
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        AP_CommonFunctions CommonObj = new AP_CommonFunctions();
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        formObject.setNGValue("Comments", "");
        String ER_WS = formObject.getNGValue("InitSts");
        if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) {
            CommonObj.VP_Frame_Height();
            CommonObj.VP_Frame_lock();
        }
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException {
     CommonObj.InserComments();     
    }

    @Override
    public void eventDispatched(ComponentEvent ce) throws ValidatorException 
    {
        switch (ce.getType()) 
        {
            case MOUSE_CLICKED: 
            {
             if (ce.getSource().getName().equalsIgnoreCase("btn_submit"))
             {
                FormContext.getCurrentInstance().getFormReference().RaiseEvent("WFDone");
             }
             break;
            }
        }
        
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) {
        
    }

    @Override
    public void initialize() {
        
    }
    
}
