/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.sapfunctions.SAPFunc;
import java.util.HashMap;
import java.util.List;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author balasubiramani.g
 * This file for handling SAP Posting functionality
 */
public class Audit implements FormListener
{
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
     
     SAPFunc objSAPFunc= new SAPFunc();

    @Override
    public void formLoaded(FormEvent fe) 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        //System.out.println("Inside Post FormPopulated");
        CommonObj.writeToLog(2,"Inside Post FormPopulated",winame);        
        //Below line added bala on 09-12-2016 for clearing Commets on each workstep
        formObject.setNGValue("Comments", "");
        String sMode=formConfig.getConfigElement("Mode");
        if(sMode.equalsIgnoreCase("R"))
        {
            formObject.setEnabled("btn_cmnthsty", true);
            formObject.setEnabled("btn_trnsdt1",true);
        }
        //formObject.setNGValue("RejectReason","");
        formObject.setVisible("btn_Approve", false);
        formObject.setVisible("btn_Reject", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Rescan", false);
        formObject.setVisible("btn_Travel", false);
        //End
        
        //Added started by Sivashankar for hiding the Grade 29-June-2018
        String strFlag = "";
        String sqlQuery = "SELECT Value FROM EXT_AP_ER_MASTER_EXTERNALCONSTANTS WITH(NOLOCK) WHERE ColumnName='BLOCKPORTAL'";
        List<List<String>> Flag = formObject.getDataFromDataSource(sqlQuery);
        strFlag = Flag.get(0).get(0);
        CommonObj.writeToLog(2, "sqlQuery ==> " + sqlQuery, winame);
        CommonObj.writeToLog(2, "strFlag ==> " + strFlag, winame);
        if (strFlag.equalsIgnoreCase("YES")) {
            formObject.setVisible("lbl_inv_grade", false);
            formObject.setVisible("Grade", false);
            formObject.setVisible("lbl_inv_design", false);
            formObject.setVisible("Designation", false);
        }
        //Added ended by Sivashankar for hiding the Grade
        
        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        //System.out.println("ER WS Status=" + ER_WS);
        CommonObj.writeToLog(2,"ER WS Status=" + ER_WS,winame);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) 
        {
            CommonObj.HideFrames_Init();
            CommonObj.Approval_lock();
            formObject.setVisible("txt_totalamount", true);
            formObject.setVisible("TotalAmount", true);
        } 
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) 
        {
            CommonObj.VP_Frame_Height();
            CommonObj.VP_Frame_lock();
        }
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("TC")) 
        {
         //CommonObj.TravelCab_Initaition_frm_visible();
         //CommonObj.TravelCab_Park_Post_frm_height();
         //CommonObj.Travel_Cab_ButtonView();  // to view button based on invoice type TRAVEL/CAB
         CommonObj.TravelCab_Frames();
        }
        formObject.setEnabled("frm_parkdtl_po", true);//edited on 03-01-2017 (Deva)
        formObject.setVisible("btn_Reject", true);//edited on 03-01-2017 (Deva)
        formObject.setEnabled("btn_Reject", true);//edited on 03-01-2017 (Deva)
        formObject.setLeft("btn_submit", 328);
        formObject.setLeft("btn_Reject", 208);
        
        CommonObj.enableDORMailBtn(formObject);
        
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1");
        if (strTypeofinvoice.equalsIgnoreCase("Travel Request") && formObject.getNGValue("ApprSts1").equalsIgnoreCase("Approved")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage", winame);
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage strTypeofinvoice--" + strTypeofinvoice, winame);
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage ApprSts1--" + formObject.getNGValue("ApprSts1"), winame);
            //formObject.setNGValue("SubCategory1", "");
            //Added By IBPS Support for type of invoice null value
            formObject.addItem("TypeOfInvoice", "Travel Expense");
            formObject.addItem("SubCategory1", "Travel Expense");
            //End of Added By IBPS Support for type of invoice null value
            formObject.setNGValue("TypeOfInvoice", "Travel Expense");
            formObject.setNGValue("SubCategory1", "Travel Expense");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation after setting values--" + strTypeofinvoice, winame);
        }
        //Added By IBPS Support for type of invoice null value
        if (strTypeofinvoice.equalsIgnoreCase("Travel Expense") && formObject.getNGValue("ApprSts1").equalsIgnoreCase("Approved")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage1", winame);
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage1 strTypeofinvoice--" + strTypeofinvoice, winame);
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at Rework stage1 ApprSts1--" + formObject.getNGValue("ApprSts1"), winame);
            //formObject.setNGValue("SubCategory1", "");
            formObject.addItem("TypeOfInvoice", "Travel Expense");
            formObject.addItem("SubCategory1", "Travel Expense");
            formObject.setNGValue("TypeOfInvoice", "Travel Expense");
            formObject.setNGValue("SubCategory1", "Travel Expense");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation after setting values1--" + strTypeofinvoice, winame);
        }

        if (strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation stage12--", winame);
            formObject.addItem("TypeOfInvoice", "Travel Request");
            formObject.addItem("SubCategory1", "Travel Request");
            formObject.setNGValue("TypeOfInvoice", "Travel Request");
            formObject.setNGValue("SubCategory1", "Travel Request");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation12 after setting values1--" + strTypeofinvoice, winame);
        }
        if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation stage123--", winame);
            formObject.addItem("TypeOfInvoice", "Mobile Re-Imbursements");
            formObject.addItem("SubCategory1", "Mobile Re-Imbursements");
            formObject.setNGValue("TypeOfInvoice", "Mobile Re-Imbursements");
            formObject.setNGValue("SubCategory1", "Mobile Re-Imbursements");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 after setting values1--" + strTypeofinvoice, winame);
        }
        if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation stage123--", winame);
            formObject.addItem("TypeOfInvoice", "Entertainment & Others");
            //formObject.addItem("SubCategory1", "Entertainment");
            //formObject.addItem("SubCategory1", "Others");
            //formObject.addItem("SubCategory1", "Gift & Complimentary");
            formObject.setNGValue("TypeOfInvoice", "Entertainment & Others");
            //formObject.setNGValue("SubCategory1", "Entertainment");
            //formObject.setNGValue("SubCategory1", "Others");
            //formObject.setNGValue("SubCategory1", "Gift & Complimentary");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 after setting values1--" + strTypeofinvoice, winame);
        }        
        if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && strSubcategory.equalsIgnoreCase("Entertainment")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense Entertainment at ER_Initiation stage123--", winame);
            //formObject.addItem("TypeOfInvoice", "Entertainment & Others");
            formObject.addItem("SubCategory1", "Entertainment");
            //formObject.addItem("SubCategory1", "Others");
            //formObject.addItem("SubCategory1", "Gift & Complimentary");
            //formObject.setNGValue("TypeOfInvoice", "Entertainment & Others");
            formObject.setNGValue("SubCategory1", "Entertainment");
            //formObject.setNGValue("SubCategory1", "Others");
            //formObject.setNGValue("SubCategory1", "Gift & Complimentary");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Entertainment after setting values1--" + strTypeofinvoice, winame);
        }
        if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && strSubcategory.equalsIgnoreCase("Others")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense Others at ER_Initiation stage123--", winame);
            //formObject.addItem("TypeOfInvoice", "Entertainment & Others");
            //formObject.addItem("SubCategory1", "Entertainment");
            formObject.addItem("SubCategory1", "Others");
            //formObject.addItem("SubCategory1", "Gift & Complimentary");
            //formObject.setNGValue("TypeOfInvoice", "Entertainment & Others");
            //formObject.setNGValue("SubCategory1", "Entertainment");
            formObject.setNGValue("SubCategory1", "Others");
            //formObject.setNGValue("SubCategory1", "Gift & Complimentary");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Others after setting values1--" + strTypeofinvoice, winame);
        }
        if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && strSubcategory.equalsIgnoreCase("Gift & Complimentary")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation Gift & Complimentary stage123--", winame);
            //formObject.addItem("TypeOfInvoice", "Entertainment & Others");
            //formObject.addItem("SubCategory1", "Entertainment");
            //formObject.addItem("SubCategory1", "Others");
            formObject.addItem("SubCategory1", "Gift & Complimentary");
            //formObject.setNGValue("TypeOfInvoice", "Entertainment & Others");
            //formObject.setNGValue("SubCategory1", "Entertainment");
            //formObject.setNGValue("SubCategory1", "Others");
            formObject.setNGValue("SubCategory1", "Gift & Complimentary");
            CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Gift & Complimentary after setting values1--" + strTypeofinvoice, winame);
        }
        if (strTypeofinvoice.equalsIgnoreCase("Relocation")) {
            CommonObj.writeToLog(2, "Travel Request is getting updated as Travel Expense at ER_Initiation Relocation stage123--", winame);
            formObject.addItem("TypeOfInvoice", "Relocation");
            formObject.setNGValue("TypeOfInvoice", "Relocation");
            if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
                formObject.addItem("SubCategory1", "Brokerage Fee");
                formObject.setNGValue("SubCategory1", "Brokerage Fee");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Brokerage Fee after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Joining Expense")) {
                formObject.addItem("SubCategory1", "Joining Expense");
                formObject.setNGValue("SubCategory1", "Joining Expense");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Joining Expense after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {
                formObject.addItem("SubCategory1", "Look and See Visit");
                formObject.setNGValue("SubCategory1", "Look and See Visit");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Look and See Visit after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Moving of Personal Effects")) {
                formObject.addItem("SubCategory1", "Moving of Personal Effects");
                formObject.setNGValue("SubCategory1", "Moving of Personal Effects");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Moving of Personal Effects after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
                formObject.addItem("SubCategory1", "Relocation-Travel Expense");
                formObject.setNGValue("SubCategory1", "Relocation-Travel Expense");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Relocation-Travel Expense after setting values1--" + strTypeofinvoice, winame);
            }
            if (strSubcategory.equalsIgnoreCase("Self Education Scheme")) {
                formObject.addItem("SubCategory1", "Self Education Scheme");
                formObject.setNGValue("SubCategory1", "Self Education Scheme");
                CommonObj.writeToLog(2, "form Populated in the ER_Initiation123 Moving of Personal Effects after setting values1--" + strTypeofinvoice, winame);
            }

        }
        //End of Added By IBPS Support for type of invoice null value
        
        //Added by IBPS Support for populating Dropdowns in GRID
        formObject.setEnabled("txt_trvl_fromloc", true);
        String txt_trvl_fromlocsQuery = "select fromloc from EXT_TravelFare1 WITH(NOLOCK) where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery fromloc $$$$$ :: " + txt_trvl_fromlocsQuery, winame);
        String txt_trvl_fromlocval = formObject.getDataFromDataSource(txt_trvl_fromlocsQuery).toString();
        CommonObj.DBValues_Combo(txt_trvl_fromlocsQuery, "txt_trvl_fromloc");
        CommonObj.writeToLog(2, "fromloc val1 $$$$$ :: " + txt_trvl_fromlocval, winame);
        formObject.setEnabled("txt_trvl_fromloc", false);

        formObject.setEnabled("txt_trvl_toloc", true);
        String txt_trvl_tolocsQuery = "select ToLoc from EXT_TravelFare1 WITH(NOLOCK) where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery ToLoc $$$$$ :: " + txt_trvl_tolocsQuery, winame);
        String txt_trvl_tolocval = formObject.getDataFromDataSource(txt_trvl_tolocsQuery).toString();
        CommonObj.DBValues_Combo(txt_trvl_tolocsQuery, "txt_trvl_toloc");
        CommonObj.writeToLog(2, "ToLoc val1 $$$$$ :: " + txt_trvl_tolocval, winame);
        formObject.setEnabled("txt_trvl_toloc", false);
        
        formObject.setEnabled("cb_hotelfare_britannia_statename", true);
        String hotelfare_statenamesQuery = "select BritStateName from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery BritStateName $$$$$ :: " + hotelfare_statenamesQuery, winame);
        String hotelfare_statenameval = formObject.getDataFromDataSource(hotelfare_statenamesQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_statenamesQuery, "cb_hotelfare_britannia_statename");
        CommonObj.writeToLog(2, "BritStateName val1 $$$$$ :: " + hotelfare_statenameval, winame);
        formObject.setEnabled("cb_hotelfare_britannia_statename", false);
        
        formObject.setEnabled("cb_hotelfare_gst_percentage", true);
        String hotelfare_gstsQuery = "select GSTPercentage from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery GSTPercentage $$$$$ :: " + hotelfare_gstsQuery, winame);
        String hotelfare_gstsQueryval = formObject.getDataFromDataSource(hotelfare_gstsQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_gstsQuery, "cb_hotelfare_gst_percentage");
        CommonObj.writeToLog(2, "GSTPercentage val1 $$$$$ :: " + hotelfare_gstsQueryval, winame);
        formObject.setEnabled("cb_hotelfare_gst_percentage", false);
        
        formObject.setEnabled("dp_hotelfare_location", true);
        String hotelfare_locsQuery = "select Location from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery Location $$$$$ :: " + hotelfare_locsQuery, winame);
        String hotelfare_locsQueryval = formObject.getDataFromDataSource(hotelfare_locsQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_locsQuery, "dp_hotelfare_location");
        CommonObj.writeToLog(2, "Location val1 $$$$$ :: " + hotelfare_locsQueryval, winame);
        formObject.setEnabled("dp_hotelfare_location", false);
        //End of Added by IBPS Support for populating Dropdowns in GRID
        
        
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException 
    {
        
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
        CommonObj.InserComments();
    }

    @Override
    public void eventDispatched(ComponentEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String fieldName = fe.getSource().getName();
        
        switch (fe.getType()) {
            case MOUSE_CLICKED:
            {
               if(fieldName.equalsIgnoreCase("btn_reverse")){
                   CommonObj.writeToLog(2,"In btn_reverse Click",winame);
                   try {                        
                        objSAPFunc.ZFI_DOCUMENT_REVERSE("btn_reverse"); 
                    } catch (Exception ex) {                        
                        CommonObj.writeToLog(3,"Exception in btn_park: "+ex.getMessage(),winame);
                    }
               } 
               if(fieldName.equalsIgnoreCase("btn_submit")){
                   CommonObj.writeToLog(2,"In btn_submit Click",winame);                                        
                        if(!formObject.getNGValue("ReversalDocNo").equalsIgnoreCase("")){                           
                        formObject.setNGValue("AuditSts", "Reject");                                                     
                        formObject.RaiseEvent("WFDone");                              
                        }
                        else if(formObject.getNGValue("ReversalDocNo").equalsIgnoreCase("")){                           
                        formObject.setNGValue("AuditSts", "Yes");                                                     
                        formObject.RaiseEvent("WFDone");                              
                        }
               }
               if(fieldName.equalsIgnoreCase("btn_Reject"))
               {
                    formObject.setNGValue("AuditSts", "Reject");                                                     
                    formObject.RaiseEvent("WFDone");
                    break;
               } 
               break;
            } 
            case KEY_PRESSED:{break;}
            case FOCUS_GAINED:{break;}
            case FOCUS_LOST:{break;}
            case VALUE_CHANGED:{break;}
            case KEY_DOWN:{break;}            
        }//End of Switch
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) 
    {
       // throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void initialize() 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
