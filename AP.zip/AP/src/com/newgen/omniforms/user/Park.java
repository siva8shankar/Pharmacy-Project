/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import java.util.HashMap;
import javax.faces.validator.ValidatorException;
import com.newgen.omniforms.sapfunctions.*;
import java.awt.Color;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;

/**
 *
 * @author balasubiramani.g
 * This class contains SAP_Park functionality
 */
public class Park implements FormListener
{
     AP_CommonFunctions CommonObj = new AP_CommonFunctions();
//     SAPParkER objSAPPark = new SAPParkER();
     SAPParkER objSAPParkk = new SAPParkER();
     SAPParkNONPO objSAPParkNONPO = new SAPParkNONPO();
     SAPParkPO objSAPParkPO = new SAPParkPO();
     SAPFunc objSAPFunc= new SAPFunc();
     SAPDirectPostER objSAPDirectPostER = new SAPDirectPostER();
     SAPAdvancesPost objSAPAdvancesPost = new SAPAdvancesPost();
     SAPParkTC objSAPParkTC = new SAPParkTC();
     
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SimpleDateFormat sdfDt = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat SAPDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat SAPDateFormat2 = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat NGDateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    DecimalFormat decimalFormat = new DecimalFormat("#.##");

     
   @Override
    public void formLoaded(FormEvent fe) 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
                
        formObject.setVisible("Btn_SAP", true);
        formObject.setVisible("Text_SAP_Input", true);
        formObject.setVisible("Text_SAP_Output", true);
        formObject.setEnabled("btn_reverse", false);
        
        formObject.setVisible("Label33", false);
        formObject.setVisible("ReversalDocNo", false);
        formObject.setVisible("btn_reverse", false);
        formObject.setVisible("Label36", false);
        formObject.setVisible("SapErrorMsg", false);        
        formObject.setVisible("Label34", false);
        formObject.setVisible("ClearedBy", false);
        formObject.setVisible("Label30", false);
        formObject.setVisible("ClearingDate", false);
        formObject.setVisible("Label31", false);
        formObject.setVisible("ClearingDocNo", false);
        formObject.setVisible("Label32", false);
        formObject.setVisible("ClearedAmnt", false);
        formObject.setHeight("frm_parkdtl_po", formObject.getTop("PostBySAP") + 30 );
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1");
        //Below line added bala on 09-12-2016 for clearing Commets on each workstep
        formObject.setNGValue("Comments", "");
        //formObject.setNGValue("RejectReason","");
        formObject.setVisible("btn_Approve", false);
        formObject.setVisible("btn_Reject", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Rescan", false);
        formObject.setVisible("btn_Travel", false);
        
        //Added started by Sivashankar for hiding the Grade 29-June-2018
        String strFlag = "";
        String sqlQuery = "SELECT Value FROM EXT_AP_ER_MASTER_EXTERNALCONSTANTS WITH(NOLOCK) WHERE ColumnName='BLOCKPORTAL'";
        List<List<String>> Flag = formObject.getDataFromDataSource(sqlQuery);
        strFlag = Flag.get(0).get(0);
        CommonObj.writeToLog(2, "sqlQuery ==> " + sqlQuery, winame);
        CommonObj.writeToLog(2, "strFlag ==> " + strFlag, winame);
        if (strFlag.equalsIgnoreCase("YES")) {
            formObject.setVisible("lbl_inv_grade", false);
            formObject.setVisible("Grade", false);
            formObject.setVisible("lbl_inv_design", false);
            formObject.setVisible("Designation", false);
        }
        //Added ended by Sivashankar for hiding the Grade
        
        
        //End
        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        //System.out.println("ER WS Status=" + ER_WS);
        CommonObj.writeToLog(2,"ER WS Status=" + ER_WS,winame);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) 
        {
            CommonObj.HideFrames_Init();
            CommonObj.Approval_lock();
            formObject.setNGValue("FiscalYr",CommonObj.Cur_FinanicalYr());
            formObject.setVisible("txt_totalamount", true);
            formObject.setVisible("TotalAmount", true);
            formObject.setCaption("btn_Approve", "Park");
            formObject.setCaption("btn_submit", "Post");            
            //Added By Harinatha R on 2017/07/10 NOTE : To route transaction from Rework to Parking stage directly to avoid delay in processeing minor changes
            formObject.setLeft("btn_Reject", 280);
            formObject.setVisible("btn_Reject", true);
            formObject.setVisible("btn_Exception", true);
            formObject.setLeft("btn_Exception", 370);
            formObject.setTop("btn_Exception", 128);
            //Ended By Harinatha R on 2017/07/10 
            
            formObject.setNGBackColor("MMDocNo", new Color(225, 225, 225));            
        } 
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) 
        {
            formObject.setVisible("Label59", false);
            formObject.setVisible("BaseAmnt", false);
            formObject.setVisible("Label67", false);
            formObject.setVisible("ExciseDuty", false);
            formObject.setVisible("Label61", false);
            formObject.setVisible("SalesTax", false);
            formObject.setVisible("Label63", false);
            formObject.setVisible("ServiceTax", false);
            formObject.setVisible("Label62", false);
            formObject.setVisible("Freight", false);
            formObject.setVisible("Label64", false);
            formObject.setVisible("Octri", false);
            
            //formObject.setVisible("frm_approval", true);
            
            formObject.setLeft("Label60", 25);
            formObject.setLeft("CalcTax", 155);
            formObject.setTop("Label66", 30);
            formObject.setTop("CashDiscount", 30);
            formObject.setTop("Label65", 60);
            formObject.setTop("CashDisAmnt", 60);
            formObject.setHeight("frm_trnsdtl_po",90);
            
            CommonObj.VP_Frame_Height();
            CommonObj.VP_Frame_lock();
            formObject.setCaption("btn_Approve", "Park");
            formObject.setVisible("btn_Approve", true);
            formObject.setVisible("btn_submit", false);
            formObject.setLeft("btn_Approve", 220);
            formObject.setLeft("btn_Reject", 350);
            
            formObject.setEnabled("frm_approval", true);
            CommonObj.DBValues_Combo("select distinct  QueryType  from EXT_AP_Query WITH (NOLOCK) where QueryType is not null", "QueryType");
            formObject.setVisible("frm_approval", true);
            String strVendorCode=formObject.getNGValue("VendCode");
            int intVendorCode=strVendorCode.length();
            if(intVendorCode<10){
                    strVendorCode=CommonObj.appendzero(intVendorCode, "VendCode");
                    }
            try{
            objSAPFunc.ZBAPI_VENDOR_WITH_TAXCODE(strVendorCode);
            }catch(Exception ex){
                CommonObj.writeToLog(3,"Exception:"+ex.getMessage(), winame);
            }
            //CommonObj.DBValues_Combo("select distinct Place from EXT_BUSINESS_PLACE with(nolock) where  Place IS NOT NULL and Place !=''", "BusiSec");
            CommonObj.DBValues_Combo("select distinct biss_place from EXT_AP_BUSINESS_AREA with(nolock) where  biss_place IS NOT NULL and biss_place !=''", "BusiSec");
            String strStateCode=formObject.getNGValue("StateCode");
            CommonObj.DBValues_Combo("select distinct Ltrim(Rtrim(BISS_AREA)) from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA IS NOT NULL and BISS_AREA !=''", "StateCode");
            if(strStateCode!="")formObject.setNGValue("StateCode",strStateCode);
            //CommonObj.DBValues_Combo("select distinct Ltrim(Rtrim(WHTCode)) from EXT_AP_VENDOR_MASTER with(nolock) where WHTCode IS NOT NULL and WHTCode !=''", "WHTCode");
            //CommonObj.DBValues_Combo("select distinct Ltrim(Rtrim(WHTBaseAmt)) from EXT_AP_VENDOR_MASTER with(nolock) where  WHTBaseAmt IS NOT NULL and WHTBaseAmt !=''", "WHTBaseAmnt");
            //formObject.addItem("StateCode", "KA01");
            //formObject.addItem("WHTBaseAmnt", "1000");
            //formObject.addItem("SusiSec", "BIL1");
            //formObject.addItem("WHTCode", "D");
            
            try{            
            formObject.setNGValue("DocHeadText","Rs "+formObject.getNGValue("TotInvoiceAmnt")+" / "+CommonObj.DMSSAPNO());
            formObject.setNGValue("Text","Bill # "+formObject.getNGValue("InvoiceNo"));
            formObject.setNGValue("ItemText","Bill # "+formObject.getNGValue("InvoiceNo")+" "+formObject.getNGValue("Text"));
            formObject.setNGValue("WorkIDSAP",CommonObj.DMSSAPNO());   
            formObject.setNGValue("DocDtSAP", dateFormat.format((Date) NGDateFormat.parse(formObject.getNGValue("InvoiceDate"))));
            formObject.setNGValue("BaseLineDtSAP", dateFormat.format((Date) NGDateFormat.parse(formObject.getNGValue("BaseLineDt"))));
            
            }catch(Exception ex){}
            
                    String strVendoeCode = formObject.getNGValue("VendCode").trim();
                    if (strVendoeCode != null && strVendoeCode != "") 
                    {                        
                        String query1 = "select TOP 1 TanNo, StateName, TinNo, ServiceTaxRegNo, WHTCode, WHTType, WHTBaseAmt from EXT_AP_VENDOR_MASTER with(nolock) where VendorCode='" + strVendoeCode + "' and VendorCode IS NOT NULL and VendorCode !=''";
                        String[] FieldValue_array=CommonObj.DB_QueryExecute(query1);
                        
                        formObject.setNGValue("TanNo", FieldValue_array[0]);
                        //formObject.setNGValue("StateCode", FieldValue_array[1]);
                        formObject.setNGValue("TINNO", FieldValue_array[2]);
                        formObject.setNGValue("ServiceTaxRegNo", FieldValue_array[3]);
                        //formObject.setNGValue("WHTCode", FieldValue_array[4]);
                        formObject.setNGValue("WHTType", FieldValue_array[5]);
                        //formObject.setNGValue("WHTBaseAmnt", FieldValue_array[6]);
                    }
                    
                    if (strTypeOfprocess.equalsIgnoreCase("PO")){
                    int po_GRN = formObject.getItemCount("list_po_invoice");
                       List<List<String>> list_po_invoice = CommonObj.getListViewValueInList(formObject, "list_po_invoice");
                       CommonObj.writeToLog(2, "list_PO in Onload form==" + list_po_invoice, winame);
                       if (po_GRN > 0) {     
                           String LineItemData[] = CommonObj.getRowValue(formObject, "list_po_invoice", 0);
                               //String sValue1 = list_po_invoice.get(0).get(1);
                               //String sValue2 = list_po_invoice.get(0).get(2);                               
                                String sValue0 = LineItemData[0].trim();
                                String sValue1 = LineItemData[1].trim();
                               formObject.setNGValue("Assignment", sValue1);
                               CommonObj.writeToLog(2, "GRN No:"+sValue1, winame);
                               String BapiResult=objSAPParkk.Parking_DueDate(sValue1);
                               if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                                   CommonObj.writeToLog(3, "BAPI result !=SUCCESS in Park.java@btn_cal_due_date"+BapiResult, winame);
                                   //throw new ValidatorException(new FacesMessage("Due Date is not available in SAP", ""));
                               }                          
                       }
                    }
            
            
            
        }
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("TC")) 
        {
         CommonObj.TravelCab_Frames();
         formObject.setEnabled("frm_accndtl_po", true);
         formObject.setLeft("btn_Reject", 350);
         
        }
        /*
        //Direct Posting
        if (strTypeofinvoice.equalsIgnoreCase("Advances") || strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") || strTypeofinvoice.equalsIgnoreCase("Travel Expense") || strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {
            formObject.setVisible("btn_submit", true);
            formObject.setVisible("btn_Approve", false);
            formObject.setLeft("btn_submit", 220);
        } else {
            formObject.setVisible("btn_submit", false);
            formObject.setVisible("btn_Approve", true);
            formObject.setLeft("btn_Approve", 220);
        }
        */
        formObject.setVisible("btn_submit", false);
        formObject.setVisible("btn_Approve", true);
        formObject.setLeft("btn_Approve", 170);    
        formObject.setCaption("btn_Approve", "Park");
        formObject.setCaption("btn_submit", "Post"); 
        //formObject.setVisible("btn_SAP_Doc_No", true);
        //formObject.setEnabled("btn_SAP_Doc_No", true);
        //formObject.setVisible("btn_park", true);
        formObject.setVisible("btn_cal_due_date", true);        
        //formObject.setEnabled("btn_park", true);
        formObject.setEnabled("btn_cal_due_date", true);
        formObject.setEnabled("ParkingDate", false);
        formObject.setEnabled("PostingDate", false);
        formObject.setEnabled("ClearingDate", false);
        formObject.setCaption("btn_Approve", "Park");        
        //formObject.setLeft("btn_Approve", 220);
        //formObject.setLeft("btn_Reject", 350);
        formObject.setVisible("btn_Reject", true);
        
        formObject.setEnabled("TypeOfInvoice", true);
        String sQuery2 = "SELECT TypeOfInvoice FROM EXT_AP WITH(NOLOCK) WHERE workid = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery2 $$$$$ :: " + sQuery2, winame);
        String val = formObject.getDataFromDataSource(sQuery2).toString();
        val = val.replace("[", "").replace("]", "").trim();
        CommonObj.writeToLog(2, "Val $$$$$ :: " + val, winame);
        formObject.addItem("TypeOfInvoice", val);
        formObject.setNGValue("TypeOfInvoice", val);
        formObject.setEnabled("TypeOfInvoice", false);
        
        formObject.setEnabled("SubCategory1", true);
        String sQuery = "SELECT SubCategory1 FROM EXT_AP WITH(NOLOCK) WHERE workid = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery $$$$$ :: " + sQuery, winame);
        String val1 = formObject.getDataFromDataSource(sQuery).toString();
        val1 = val1.replace("[", "").replace("]", "").trim();
        CommonObj.writeToLog(2, "val1 $$$$$ :: " + val1, winame);
        formObject.addItem("SubCategory1", val1);
        formObject.setNGValue("SubCategory1", val1);
        formObject.setEnabled("SubCategory1", false);
        
        //Added by IBPS Support for populating Dropdowns in GRID
        formObject.setEnabled("txt_trvl_fromloc", true);
        String txt_trvl_fromlocsQuery = "select fromloc from EXT_TravelFare1 WITH(NOLOCK) where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery fromloc $$$$$ :: " + txt_trvl_fromlocsQuery, winame);
        String txt_trvl_fromlocval = formObject.getDataFromDataSource(txt_trvl_fromlocsQuery).toString();
        CommonObj.DBValues_Combo(txt_trvl_fromlocsQuery, "txt_trvl_fromloc");
        CommonObj.writeToLog(2, "fromloc val1 $$$$$ :: " + txt_trvl_fromlocval, winame);
        formObject.setEnabled("txt_trvl_fromloc", false);

        formObject.setEnabled("txt_trvl_toloc", true);
        String txt_trvl_tolocsQuery = "select ToLoc from EXT_TravelFare1 WITH(NOLOCK) where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery ToLoc $$$$$ :: " + txt_trvl_tolocsQuery, winame);
        String txt_trvl_tolocval = formObject.getDataFromDataSource(txt_trvl_tolocsQuery).toString();
        CommonObj.DBValues_Combo(txt_trvl_tolocsQuery, "txt_trvl_toloc");
        CommonObj.writeToLog(2, "ToLoc val1 $$$$$ :: " + txt_trvl_tolocval, winame);
        formObject.setEnabled("txt_trvl_toloc", false);
        
        formObject.setEnabled("cb_hotelfare_britannia_statename", true);
        String hotelfare_statenamesQuery = "select BritStateName from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery BritStateName $$$$$ :: " + hotelfare_statenamesQuery, winame);
        String hotelfare_statenameval = formObject.getDataFromDataSource(hotelfare_statenamesQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_statenamesQuery, "cb_hotelfare_britannia_statename");
        CommonObj.writeToLog(2, "BritStateName val1 $$$$$ :: " + hotelfare_statenameval, winame);
        formObject.setEnabled("cb_hotelfare_britannia_statename", false);
        
        formObject.setEnabled("cb_hotelfare_gst_percentage", true);
        String hotelfare_gstsQuery = "select GSTPercentage from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery GSTPercentage $$$$$ :: " + hotelfare_gstsQuery, winame);
        String hotelfare_gstsQueryval = formObject.getDataFromDataSource(hotelfare_gstsQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_gstsQuery, "cb_hotelfare_gst_percentage");
        CommonObj.writeToLog(2, "GSTPercentage val1 $$$$$ :: " + hotelfare_gstsQueryval, winame);
        formObject.setEnabled("cb_hotelfare_gst_percentage", false);
        
        formObject.setEnabled("dp_hotelfare_location", true);
        String hotelfare_locsQuery = "select Location from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery Location $$$$$ :: " + hotelfare_locsQuery, winame);
        String hotelfare_locsQueryval = formObject.getDataFromDataSource(hotelfare_locsQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_locsQuery, "dp_hotelfare_location");
        CommonObj.writeToLog(2, "Location val1 $$$$$ :: " + hotelfare_locsQueryval, winame);
        formObject.setEnabled("dp_hotelfare_location", false);
        //End of Added by IBPS Support for populating Dropdowns in GRID
        
        CommonObj.enableDORMailBtn(formObject);
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException 
    {
            CommonObj.InserComments();
//throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void eventDispatched(ComponentEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
        
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId"); 
        String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");
        String strInitiateSts = formObject.getNGValue("InitSts");
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1"); 
        String BapiResult="";
           switch (fe.getType()) {
               case MOUSE_CLICKED: {
                   if (fe.getSource().getName().equalsIgnoreCase("Btn_SAP")) {
                       CommonObj.writeToLog(2, "In Btn_SAP Test", winame);
                       try {
                           String BAPIInputTest = formObject.getNGValue("Text_SAP_Input");
                           if (BAPIInputTest != "") {
                               objSAPFunc.BAPI_Test(BAPIInputTest);
                           }
                       } catch (Exception ex) {
                           CommonObj.writeToLog(2, "In Btn_SAP Test Exception:" + ex.getMessage(), winame);
                       }
                   }
                    if (fe.getSource().getName().equalsIgnoreCase("btn_query")) 
                    {
                        if((formObject.getNGValue("QueryType").equalsIgnoreCase(""))&&(formObject.getNGValue("QueryType").equalsIgnoreCase("--Select--")))
                            {
                            throw new ValidatorException(new FacesMessage("Please Select the Query Type","QueryType"));
                            }
                        else 
                            {
                            formObject.setNGValue("ParkSts", "Query");
                            formObject.RaiseEvent("WFDone");
                            }
                    }
                   if (fe.getSource().getName().equalsIgnoreCase("btn_Reject")) {
                       formObject.setNGValue("ParkSts", "Reject");
                       formObject.RaiseEvent("WFDone");
                       break;
                   }
                   //Added By Harinatha R on 2017/07/10 NOTE : To route transaction from Rework to Parking stage directly to avoid delay in processeing minor changes
                   if (fe.getSource().getName().equalsIgnoreCase("btn_Exception")) {
                       if (strInitiateSts.equalsIgnoreCase("ER")) {
                           CommonObj.mandatoryCheck(formObject, "Comments", "Please enter comments");
                           formObject.setNGValue("ParkSts","Exception");
                           formObject.RaiseEvent("WFDone");
                       }
                       break;
                   }
                   //Ended By Harinatha R on 2017/07/10
                   if ((fe.getSource().getName().equalsIgnoreCase("btn_save")) || (fe.getSource().getName().equalsIgnoreCase("btn_Approve"))) {
                       try {
                           formObject.setNGValue("DocHeadText", "Rs " + formObject.getNGValue("TotInvoiceAmnt") + " / " + CommonObj.DMSSAPNO());
                           //formObject.setNGValue("Text", "Bill # " + formObject.getNGValue("InvoiceNo"));
                           formObject.setNGValue("ItemText", "Bill # " + formObject.getNGValue("InvoiceNo") + " " + formObject.getNGValue("Text"));
                           formObject.setNGValue("WorkIDSAP", CommonObj.DMSSAPNO());
                           formObject.setNGValue("DocDtSAP", dateFormat.format((Date) NGDateFormat.parse(formObject.getNGValue("InvoiceDate"))));
                           formObject.setNGValue("BaseLineDtSAP", dateFormat.format((Date) NGDateFormat.parse(formObject.getNGValue("BaseLineDt"))));
                           
                       } catch (Exception ex) {
                       }
                       formObject.RaiseEvent("WFSave");

                   }
                   if (fe.getSource().getName().equalsIgnoreCase("btn_submit")) {
                        if(strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")|| strTypeofinvoice.equalsIgnoreCase("Travel Expense")|| strTypeofinvoice.equalsIgnoreCase("Employee Advances")){
                            if (formObject.getNGValue("SAPDocRefNo").equalsIgnoreCase("")) {
                            formObject.setEnabled("btn_submit", false);
                            BapiResult=objSAPDirectPostER.NONPO_DirectPosting(winame);
                                if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                                   CommonObj.writeToLog(2, "BAPI result !=SUCCESS in Post.java", winame);
                                   throw new ValidatorException(new FacesMessage("Posting in SAP is failed..!!! \nError Message="+BapiResult, ""));
                               }
                                else if (BapiResult.equalsIgnoreCase("SUCCESS")){
                                   formObject.setNGValue("ParkSts", "Audit");
                                   formObject.RaiseEvent("WFDone");
                                   break;
                                }
                           }else if (!formObject.getNGValue("SAPDocRefNo").equalsIgnoreCase("")){
                                   formObject.setNGValue("ParkSts", "Audit");
                                   formObject.RaiseEvent("WFDone");
                                   break;
                                }
                        }
                        else if(strTypeofinvoice.equalsIgnoreCase("Advances")){
                                CommonObj.writeToLog(2, "In Advances btn_postk Click", winame);
                               if (formObject.getNGValue("SAPDocRefNo") == "") {
                                   formObject.setEnabled("btn_submit", false);
                                       BapiResult=objSAPAdvancesPost.AdvancesPost("btn_park");
                                       CommonObj.writeToLog(2, "BapiResult: Advances Posting:"+BapiResult, winame);                                    
                                        if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                                           CommonObj.writeToLog(2, "BAPI result !=SUCCESS in Advances Posting", winame);
                                           throw new ValidatorException(new FacesMessage("Posting in SAP is failed..!!! \nError Message=" + BapiResult, ""));
                                       } else if (BapiResult.equalsIgnoreCase("SUCCESS")) {
                                           formObject.setNGValue("ParkSts", "Audit");
                                           formObject.RaiseEvent("WFDone");
                                           break;
                                       }
                               } else {
                                   formObject.setNGValue("ParkSts", "Audit");
                                   formObject.RaiseEvent("WFDone");
                               }
                                
                            }
                   
                   }
                   if ((fe.getSource().getName().equalsIgnoreCase("btn_Approve"))|| (fe.getSource().getName().equalsIgnoreCase("btn_park"))) {
                       if (strInitiateSts.equalsIgnoreCase("ER")) {
                           formObject.setEnabled("btn_park", false);
                           formObject.setEnabled("btn_Approve", false);
                           CommonObj.writeToLog(2, "In btn_park Click", winame);
                           //Modified By Harinath on 2017/08/09  NOTE: To move zero amount claims to Archival, since those claimsa canot be Parked into SAP
                           if (Float.parseFloat(formObject.getNGValue("TotalAmount")) > 0) {
                               CommonObj.writeToLog(2, "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^", winame);
                               CommonObj.writeToLog(2, "Inside If totalamount greter than zero", winame);
                               CommonObj.writeToLog(2, "winame --> " + winame, winame);
                               CommonObj.writeToLog(2, "SAPDocRefNo --> " + formObject.getNGValue("SAPDocRefNo"), winame);
                               if (formObject.getNGValue("SAPDocRefNo") == "" || formObject.getNGValue("SAPDocRefNo").equalsIgnoreCase("")) {
                                   CommonObj.writeToLog(2, "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^", winame);
                                   //Added by SandeepKn on 10JAn2020 for ASFI and SFIC Changes-Start
                                   //Avoiding Parking for Dubai & Oman if Paid To is Payable to Govt/Telecom Provider. added on 22-Nov-2019 by Sivashankar KS starts
                                   if ((formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI"))
                                           // && formObject.getNGValue("ToBePaid").equalsIgnoreCase("Payable to Govt")// as per confirmation from Syed on 18Dec2019 on mail
                                           && formObject.getNGValue("ToBePaid").equalsIgnoreCase("Telecom Provider")) {
                                       CommonObj.writeToLog(2, "**** Avoiding Parking for Dubai & Oman if Paid To is Payable to Govt/Telecom Provider ***", winame);
                                       //Added by SandeepKN on 30Mar2020 for ASFI/SFIC changes -start
                                       formObject.setNGValue("ParkSts", "Audit");
                                       formObject.RaiseEvent("WFDone");
                                       throw new ValidatorException(new FacesMessage("Parking in SAP is failed..!!! \n Since Company code exist SFIC/ASFI along with PaidTo is Telecom Provider", ""));
                                   } else {
                                       CommonObj.writeToLog(2, "^^^^--------------------------^^^^^^", winame);
                                       formObject.setEnabled("btn_park", false);
                                       formObject.setEnabled("btn_Approve", false);
                                       CommonObj.writeToLog(2, "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ER_Parking:", winame);
                                       BapiResult = objSAPParkk.NONPO_Parking("btn_park");
                                       CommonObj.writeToLog(2, "BapiResult:ER_Parking:" + BapiResult, winame);
                                       if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                                           CommonObj.writeToLog(2, "BAPI result !=SUCCESS in ER Park.java", winame);
                                           throw new ValidatorException(new FacesMessage("Parking in SAP is failed..!!!", ""));
                                       }
                                       //objSAPPark.Parking_DocumentNo(formObject.getNGValue("PONumber"));
                                       if (formObject.getNGValue("SAPDocRefNo") != "") {
                                           formObject.setNGValue("ParkSts", "Yes");
                                           formObject.RaiseEvent("WFDone");
                                       } else {
                                           CommonObj.mandatoryCheck(formObject, "SAPDocRefNo", "Please enter SAP document reference number");
                                       }
                                   }//Avoiding Parking for Dubai & Oman if Paid To is Payable to Govt/Telecom Provider. added on 22-Nov-2019 by Sivashankar KS ends
                                   //Added by SandeepKn on 10JAn2020 for ASFI and SFIC Changes-End
                               }else {
                                   formObject.setNGValue("ParkSts", "Yes");
                                   formObject.RaiseEvent("WFDone");
                               }
                           } else {
                               CommonObj.writeToLog(2, "Total claim amount is zero..Transaction is routing to Archival...\n TotalAmount :: " + formObject.getNGValue("TotalAmount"), winame);
                               formObject.setNGValue("ParkSts", "Archival");
                               formObject.RaiseEvent("WFDone");
                           }
                           //Ended By Harinath on 2017/08/09 NOTE: To move zero amount claims to Archival, since those claimsa canot be Parked into SAP
                       }
                       else if(strInitiateSts.equalsIgnoreCase("TC")){
                               CommonObj.writeToLog(2, "In TC btn_park Click", winame);
                               if (formObject.getNGValue("SAPDocRefNo") == "") {
                                   formObject.setEnabled("btn_Approve", false);
                                       BapiResult=objSAPParkTC.ParkingTCCab("btn_park");
                                       CommonObj.writeToLog(2, "BapiResult: TCParking:"+BapiResult, winame);                                    
                                        if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                                           CommonObj.writeToLog(2, "BAPI result !=SUCCESS in TC park.java", winame);
                                           throw new ValidatorException(new FacesMessage("Posting in SAP is failed..!!! \nError Message=" + BapiResult, ""));
                                       } else if (BapiResult.equalsIgnoreCase("SUCCESS")) {
                                           formObject.setNGValue("ParkSts", "Yes");
                                           formObject.RaiseEvent("WFDone");
                                           break;
                                       }
                               } else {
                                   formObject.setNGValue("ParkSts", "Yes");
                                   formObject.RaiseEvent("WFDone");
                               }
                       
                       }
                       else if (strInitiateSts.equalsIgnoreCase("VP")) {
                           
                           
                            if (strTypeOfprocess.equalsIgnoreCase("NONPO")) {
                               CommonObj.writeToLog(2, "In NONPO btn_park Click", winame);
                               if (formObject.getNGValue("SAPDocRefNo") == "") {
                                   formObject.setEnabled("btn_Approve", false);
                                       BapiResult=objSAPParkNONPO.ParkingNONPO_VP("btn_park");
                                       CommonObj.writeToLog(2, "BapiResult: VP NON PO Parking:"+BapiResult, winame);                                    
                                        if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                                           CommonObj.writeToLog(2, "BAPI result !=SUCCESS in VP NON PO park.java", winame);
                                           throw new ValidatorException(new FacesMessage("Posting in SAP is failed..!!! \nError Message=" + BapiResult, ""));
                                       } else if (BapiResult.equalsIgnoreCase("SUCCESS")) {
                                           formObject.setNGValue("ParkSts", "Yes");
                                           formObject.RaiseEvent("WFDone");
                                           break;
                                       }
                               } else {
                                   formObject.setNGValue("ParkSts", "Yes");
                                   formObject.RaiseEvent("WFDone");
                               }

                           } 
                           else if (strTypeOfprocess.equalsIgnoreCase("PO")) {
                           /*if (!formObject.getNGValue("chk_WHTMandatory").equalsIgnoreCase("true") && formObject.getNGValue("WHTBaseAmnt").equalsIgnoreCase("")  ) {
                           throw new ValidatorException(new FacesMessage("Please enter the WHT Base Amount", "WHTBaseAmnt"));
                           }*/
                           if (formObject.getNGValue("SAPDocRefNo") == "") {
                               BapiResult=objSAPParkPO.PO_Parking("btn_park");
                                if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                                   CommonObj.writeToLog(2, "BAPI result !=SUCCESS in Post.java", winame);
                                   throw new ValidatorException(new FacesMessage("Parking in SAP is failed..!!! \nError Message="+BapiResult, ""));
                               }
                                else if (BapiResult.equalsIgnoreCase("SUCCESS")){
                                   formObject.setNGValue("ParkSts", "Yes");
                                   formObject.RaiseEvent("WFDone");
                                   break;
                                }
                           }else {
                                   formObject.setNGValue("ParkSts", "Yes");
                                   formObject.RaiseEvent("WFDone");
                               }
                           
                           }
                       }
                   }
                   if (fe.getSource().getName().equalsIgnoreCase("btn_SAP_Doc_No")) {
                       CommonObj.writeToLog(2, "In btn_SAP_Doc_No Click", winame);                   
                       //Modified By Harinath on 2017/06/14
                       try {
                           objSAPParkk.Parking_DocumentNo(formObject.getNGValue("MMDocNo"), formObject.getNGValue("FiscalYr"), formObject.getNGValue("CompanyCode"));
                       } catch (Exception ex) {
                       }
                       //Ended By Harinath on 2017/06/14
                   }
                   if (fe.getSource().getName().equalsIgnoreCase("btn_cal_due_date")) {
                       CommonObj.writeToLog(2, "In btn_cal_due_date Click", winame);
                       //System.out.println("In btn_cal_due_date Click");
                       String strBaseLineDate = formObject.getNGValue("BaseLineDt");                       
                       int po_GRN = formObject.getItemCount("list_po_invoice");
                       List<List<String>> list_po_invoice = CommonObj.getListViewValueInList(formObject, "list_po_invoice");
                       if (po_GRN > 0) {
                           //for (Integer i = 0; i < list_po_invoice.size(); i++) {
                               String sValue2 = list_po_invoice.get(0).get(2);
                               CommonObj.writeToLog(2, "GRN No:"+sValue2, winame);
                               BapiResult=objSAPParkk.Parking_DueDate(sValue2);
                               if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                                   CommonObj.writeToLog(2, "BAPI result !=SUCCESS in Park.java@btn_cal_due_date:"+BapiResult, winame);
                                   throw new ValidatorException(new FacesMessage("Due Date is not available in SAP", ""));
                               }
                           //}
                       }

                   }
                   if ((fe.getSource().getName().equalsIgnoreCase("CalcTax")) && formObject.getNGValue("CalcTax").equalsIgnoreCase("true")) {
                       CommonObj.writeToLog(2, "Inside Caluate Tax", winame);
                    
                   }
                   if (fe.getSource().getName().equalsIgnoreCase("btn_SAP_Master")) {
                       //System.out.println("In btn_SAP_Master Click");
                       CommonObj.writeToLog(2, "In btn_SAP_Master Click", winame);
                       try {
                           objSAPParkk.NONPO_Parking("btn_park");
                       } catch (Exception ex) {
                           
                       }
                   }

               }//End of Click
            case VALUE_CHANGED:
            {              
            if (fe.getSource().getName().equalsIgnoreCase("CashDiscount")) 
                {
                    if(formObject.getNGValue("CashDiscount").equalsIgnoreCase("No")){
                        formObject.setNGValue("CashDisAmnt", "");
                        formObject.setEnabled("CashDisAmnt", false);
                        formObject.setNGBackColor("CashDisAmnt", new Color(225, 225, 225));                        
                    }else{
                        formObject.setEnabled("CashDisAmnt", true);
                        formObject.setNGBackColor("CashDisAmnt", new Color(255, 255, 255));                    
                    }
                
                }
                if ((fe.getSource().getName().equalsIgnoreCase("CashDiscount")) && formObject.getNGValue("CashDiscount").equalsIgnoreCase("Yes") && !formObject.getNGValue("DueDate").equalsIgnoreCase("")) {
                    CommonObj.writeToLog(2, "Inside CashDiscount", winame);
                    int datediff = formObject.getNGValue("DueDate").compareTo(NGDateFormat.format(date));
                    CommonObj.writeToLog(2, "Inside CashDiscount: DueDate:" + formObject.getNGValue("DueDate"), winame);
                    CommonObj.writeToLog(2, "Inside CashDiscount: date:" + NGDateFormat.format(date), winame);
                    CommonObj.writeToLog(2, "Inside CashDiscount: datediff:" + datediff, winame);
                    int NoOfDays = datediff + 2;
                    String diffDaysresult = "";
                    try {
                        diffDaysresult = CommonObj.diffDays(NGDateFormat.format(date), formObject.getNGValue("DueDate"));
                    } catch (ParseException ex) {
                        Logger.getLogger(Park.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    CommonObj.writeToLog(2, "Inside CashDiscount: diffDaysresult:" + diffDaysresult, winame);
                    Float invAmount = Float.parseFloat(formObject.getNGValue("TotInvoiceAmnt"));
                    CommonObj.writeToLog(2, "Inside CashDiscount: NoOfDays:" + NoOfDays, winame);
                    CommonObj.writeToLog(2, "Inside CashDiscount: invAmount:" + invAmount, winame);
                    Float disAmount = ((float) (invAmount / 30) * ((float) (Float.parseFloat(diffDaysresult) + 2.0)) * ((float) 1 / 100));
                    CommonObj.writeToLog(2, "Inside CashDiscount: disAmount:" + disAmount, winame);
                    CommonObj.writeToLog(2, "Inside CashDiscount: disAmount:" + Float.valueOf(decimalFormat.format(disAmount)), winame);
                    formObject.setNGValue("CashDisAmnt", Float.valueOf(decimalFormat.format(disAmount)));
                }
            
            
            }//End of Value Changed
           
           }//End of Switch
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) 
    {
       // throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void initialize() 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }
    
  
    
}
