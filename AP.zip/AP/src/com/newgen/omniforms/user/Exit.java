/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.sapfunctions.SAPFunc;
import java.util.HashMap;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author balasubiramani.g
 * This file for handling SAP Posting functionality
 */
public class Exit implements FormListener
{
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
     
     SAPFunc objSAPFunc= new SAPFunc();

    @Override
    public void formLoaded(FormEvent fe) 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        //System.out.println("Inside Post FormPopulated");
        CommonObj.writeToLog(2,"Inside Exit FormPopulated",winame);        
        //Below line added bala on 09-12-2016 for clearing Commets on each workstep
        formObject.setNGValue("Comments", "");
        //formObject.setEnabled("btn_cmnthsty", true);
        //formObject.setEnabled("btn_trnsdtl",true);
        String sMode=formConfig.getConfigElement("Mode");
        CommonObj.writeToLog(2,"FormPopulated sMode:"+sMode,winame);
//        if(sMode.equalsIgnoreCase("R"))
//        {
//            formObject.setEnabled("btn_cmnthsty", true);
//            formObject.setEnabled("btn_trnsdtl",true);
//        }
        
        //formObject.setNGValue("RejectReason","");
        formObject.setVisible("btn_Approve", false);
        formObject.setVisible("btn_Reject", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Rescan", false);
        formObject.setVisible("btn_Travel", false);
        formObject.setVisible("btn_submit", false);
        
        //End
        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        //System.out.println("ER WS Status=" + ER_WS);
        CommonObj.writeToLog(2,"ER WS Status=" + ER_WS,winame);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) 
        {
            CommonObj.HideFrames_Init();
            CommonObj.Approval_lock();
            formObject.setVisible("txt_totalamount", true);
            formObject.setVisible("TotalAmount", true);
        } 
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) 
        {
            CommonObj.VP_Frame_Height();
            CommonObj.VP_Frame_lock();
        }
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("TC")) 
        {
//         CommonObj.TravelCab_Initaition_frm_visible();
//         CommonObj.TravelCab_Initaition_frm_height();
//         CommonObj.Travel_Cab_ButtonView();  // to view button based on invoice type TRAVEL/CAB
         CommonObj.TravelCab_Frames();
        }        
        
        formObject.setEnabled("frm_comments", true);
        
        CommonObj.enableDORMailBtn(formObject);
        CommonObj.writeToLog(2,"Exit Workstep form populated completed>>>>>>>" + ER_WS,winame);
        
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException 
    {
        CommonObj.InserComments();
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
        CommonObj.InserComments();
    }

    @Override
    public void eventDispatched(ComponentEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String fieldName = fe.getSource().getName();
        
        switch (fe.getType()) {
            case MOUSE_CLICKED:
            {
               break;         
            } 
            case KEY_PRESSED:{break;}
            case FOCUS_GAINED:{break;}
            case FOCUS_LOST:{break;}
            case VALUE_CHANGED:{break;}
            case KEY_DOWN:{break;}            
        }//End of Switch
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) 
    {
       // throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void initialize() 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
