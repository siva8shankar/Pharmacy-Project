package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import java.util.List;
import com.newgen.omniforms.component.PickList;
import java.io.Serializable;
import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

import com.newgen.omniforms.sapfunctions.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class AP_CommonFunctions implements Serializable {

    private static final String WriteLOG = "Y";
    private static final String XML_LOG_NAME = "xml.log";
    private static final String SUCCESS_LOG_NAME = "success.log";
    private static final String Error_LOG_NAME = "error.log";
    public static final int XML_LOG = 1;
    public static final int SUCCESS_LOG = 2;
    public static final int ERROR_LOG = 3;
    public static int logcount = 0;
    private static FacesMessage fm;
    FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
    String strprcsinstid = formConfig.getConfigElement("ProcessInstanceId");

    public static void addRow(FormReference formObject, String fieldName) {
        int ListViewIndex[] = new int[1];
        ListViewIndex[0] = -1;
        formObject.ExecuteExternalCommand("NGAddRow", fieldName);
        formObject.setSelectedIndices(fieldName, ListViewIndex);
    }

    public static void modifyRow(FormReference formObject, String fieldName) {
        int ListViewIndex[] = new int[1];
        ListViewIndex[0] = -1;
        formObject.ExecuteExternalCommand("NGModifyRow", fieldName);
        formObject.setSelectedIndices(fieldName, ListViewIndex);
    }

    public static void deleteRow(FormReference formObject, String fieldName) {
        formObject.ExecuteExternalCommand("NGDeleteRow", fieldName);
        formObject.setSelectedIndices(fieldName, null);
    }

    public static void mandatoryCheck(FormReference formObject, String fieldName,
            String errorMsg) {

        String value = formObject.getNGValue(fieldName);
        if (!mandatoryCheck(value)) {
            fm = new FacesMessage(errorMsg, fieldName);
            formObject.setNGBackColor(fieldName, new Color(123, 255, 250));
            //51, 153, 255
            formObject.setNGFocus(fieldName);
            throw new ValidatorException(fm);
        } else {
            formObject.setNGBackColor(fieldName, new Color(255, 255, 255));
        }
    }

    protected static boolean mandatoryCheck(String value) {

        if (value == null || value.isEmpty()) {
            return false;
        }

        return true;
    }

    public float listViewColumnSum(String ListView, int Column_no) {
        Float ListTotal = 0.f;
        try {
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            int RowCount = formObject.getItemCount(ListView);

            for (int i = 0; i <= RowCount; i++) {
                String ColumnValues = formObject.getNGValue(ListView, i, Column_no);
                ListTotal = ListTotal + Float.parseFloat(ColumnValues);
            }
            return ListTotal;
        } catch (Exception e) {
        }
        return ListTotal;
    }

    public float listViewColumnIgnorePaidBy(String ListView, int Column_no, int IgnoreColumn) {
        Float ListTotal = 0.f;
        writeToLog(2, " Inside listViewColumnIgnorePaidBy " + ListView, strprcsinstid);
        try {
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            int RowCount = formObject.getItemCount(ListView);

            for (int i = 0; i <= RowCount; i++) {
                String ColumnValues = formObject.getNGValue(ListView, i, Column_no);
                String PaidBy = formObject.getNGValue(ListView, i, IgnoreColumn);
                if (!PaidBy.equalsIgnoreCase("Company")) {
                    //Added By Harinath on 2017/06/21
                    writeToLog(2, "listViewColumnIgnorePaidBy  :::   PaidBy : " + PaidBy + "  value : " + ColumnValues, strprcsinstid);
                    if (ColumnValues.equalsIgnoreCase("") || ColumnValues.equalsIgnoreCase(null)) {
                        ColumnValues = "0";
                    }
                    //Ended By Harinath on 2017/06/21
                    ListTotal = ListTotal + Float.parseFloat(ColumnValues);
                    writeToLog(2, "listViewColumnIgnorePaidBy ==>>  ListTotal  :::" + ListTotal, strprcsinstid);
                }
            }
            return ListTotal;
        } catch (Exception e) {
        }
        writeToLog(2, " End listViewColumnIgnorePaidBy " + ListTotal, strprcsinstid);
        return ListTotal;
    }

    public void UpdateSerialNumber(FormReference formObject, String listviewname) {
        int len = formObject.getItemCount(listviewname);
        for (int i = 0; i < len; i++) {
            formObject.setNGValue(listviewname, i, 3, (i + 1) + "");
        }
    }

    public void DBValues_Combo(String sQuery, String FieldName) {

        FormConfig formConfig1 = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig1.getConfigElement("ProcessInstanceId");
        try {
            writeToLog(2, "Query in Common Function: " + sQuery, winame);
            FormReference formObject1 = FormContext.getCurrentInstance().getFormReference();
            List strFieldValue = formObject1.getDataFromDataSource(sQuery);
            if (!strFieldValue.isEmpty()) {
                String values = strFieldValue.toString();
                values = values.replace("[", "");
                values = values.replace("]", "");
                String[] FieldValue_array = values.split(",");
                if (FieldName.equalsIgnoreCase("SubCategory1")) {
                    formObject1.addItem(FieldName, "--Select--");
                }
                formObject1.clear(FieldName);
                for (String FieldValue_array1 : FieldValue_array) {
                    if (!FieldValue_array1.equalsIgnoreCase("") && !FieldValue_array1.equalsIgnoreCase(null)) {
                        formObject1.addItem(FieldName, FieldValue_array1.trim());
                    }
                }
            }
        } catch (Exception e) {
        }
    }
    //Below function added for Combo reload in Indexing by Bala 

    public void DBValues_ComboReload(String sQuery, String FieldName) {
        String StrCombval = "";
        try {
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            StrCombval = formObject.getNGValue(FieldName);
            List strFieldValue = formObject.getDataFromDataSource(sQuery);
            if (!strFieldValue.isEmpty()) {
                String values = strFieldValue.toString();
                values = values.replace("[", "");
                values = values.replace("]", "");
                String[] FieldValue_array = values.split(",");
                if (FieldName.equalsIgnoreCase("SubCategory1")) {
                    formObject.addItem(FieldName, "--Select--");
                }
                //Modified on 07-NOV-20 for adding Reason Field
                if (FieldName.equalsIgnoreCase("SalaryAdvanceReason")) {
                    formObject.clear(FieldName);
                    //formObject.addItem(FieldName, "--Select--");
                }
                //End on 07-NOV-20
                for (int i = 0; i < FieldValue_array.length; i++) {
                    formObject.addItem(FieldName, FieldValue_array[i].trim());
                }
            }
            formObject.setNGValue(FieldName, StrCombval);
        } catch (Exception e) {
        }
    }

    public void DBValues_Field(String sQuery, String FieldName) {
        try {

            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            List strFieldValue = formObject.getDataFromDataSource(sQuery);
            if (!strFieldValue.isEmpty()) {
                String values = strFieldValue.toString();
                values = values.replace("[", "");
                values = values.replace("]", "");
                String[] FieldValue_array = values.split(",");
                formObject.setNGValue(FieldName, FieldValue_array[0].trim());
            }

        } catch (Exception e) {
        }
    }

    public void DBValues_PickList(String sQuery, String BtnName, String FieldView, String[] FieldName) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();

        PickList objPickList = formObject.getNGPickList(BtnName, FieldView, true, 20, false);

        objPickList.setVisible(true);
        EventPickList ev = new EventPickList(objPickList.getClientId());
        //commented bala on 28-11-2016
        // ev.EventPickList(BtnName,FieldName);
        objPickList.addPickListListener(ev);
        objPickList.setWidth(300);
        objPickList.setWidth(400);
        objPickList.populateData(sQuery);
    }

    public void DBValues_PickList1(String sQuery, String BtnName, String FieldView) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();

        formObject.clear(FieldView);
        formObject.setNGValue(FieldView, "");
        PickList objPickList = formObject.getNGPickList(BtnName, FieldView, true, 20, false);
        objPickList.setVisible(true);
        EventPickList ev = new EventPickList(objPickList.getClientId());

        objPickList.addPickListListener(ev);
        objPickList.setWidth(350);
        objPickList.setWidth(350);
        objPickList.populateData(sQuery);

    }

    public String[] DB_QueryExecute(String sQuery) {
        String[] FieldValue_array = null;
        try {
            writeToLog(2, "Query is :" + sQuery, strprcsinstid);
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            //FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            //String winame = formConfig.getConfigElement("ProcessInstanceId");
            List strFieldValue = formObject.getDataFromDataSource(sQuery);
            //writeToLog(2, "DB_QueryExecute:" + strFieldValue, winame); 
            writeToLog(2, "Check Values=" + strFieldValue.toString(), strprcsinstid);
            if (!strFieldValue.isEmpty()) {
                String values = strFieldValue.toString();
                values = values.replace("[", "");
                values = values.replace("]", "");
                FieldValue_array = values.split(",");
                //formObject.setNGValue(FieldName, FieldValue_array[0]);
                //writeToLog(2,"**" + formObject.getNGValue(FieldName), strprcsinstid);
            }
            //System.out.println("Done!!");
        } catch (Exception e) {
            writeToLog(3, "Exception occured in DB_QueryExecute().. " + e.getMessage(), strprcsinstid);
        }
        writeToLog(2, "DB_QueryExecute Result:" + FieldValue_array, strprcsinstid);
        return FieldValue_array;
    }

    public List DB_QuerySelectMultiLine(String sQuery) {
        List strFieldValue = null;
        try {
            //System.out.println("Query is :" + sQuery);
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
            String winame = formConfig.getConfigElement("ProcessInstanceId");
            strFieldValue = formObject.getDataFromDataSource(sQuery);
            writeToLog(2, "DB_QuerySelectMultiLine:" + strFieldValue, winame);

            //System.out.println("Done!!");
        } catch (Exception e) {
            //  System.out.println("Exception occured in DB_QueryExecute().. " + e.getMessage());
        }
        //System.out.println("DB_QueryExecute Result:"+FieldValue_array);
        return strFieldValue;
    }

    public String DB_QueryExecuteSelect1(String sQuery) {
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String[] FieldValue_array = null;
        String output = "";
        try {
            writeToLog(2, "Query is :" + sQuery, winame);
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            List strFieldValue = formObject.getDataFromDataSource(sQuery);
            // System.out.println("Check Values="+strFieldValue.toString());
            if (!strFieldValue.isEmpty()) {
                String values = strFieldValue.toString();
                values = values.replace("[", "");
                values = values.replace("]", "");
                FieldValue_array = values.split(",");
                output = FieldValue_array[0];
            }
            writeToLog(2, "Done!!" + output, winame);
        } catch (Exception e) {
            writeToLog(3, "Exception occured in DB_QueryExecute().. " + e.getMessage(), winame);
        }
        return output;
    }
    //This function added for ER approver matrix

    public String DB_QueryExecute1(String sQuery) {
        String FieldValue_array = "";
        String Flag_null = "N";
        String return_str = "";
        try {
            writeToLog(2, "Query is : check" + sQuery, strprcsinstid);
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            List strFieldValue = formObject.getDataFromDataSource(sQuery);
            writeToLog(2, "Check Values***=" + strFieldValue.toString(), strprcsinstid);
            if (!strFieldValue.isEmpty()) {
                Flag_null = "Y"; //Flag Check
                String values = strFieldValue.toString().trim();
                values = values.replace("[", "");
                values = values.replace("]", "");
                values = values.replace(" ", ""); //  Added on 07-12-2016 by bala for removing empty space between the values
                FieldValue_array = values.trim();
            }
            // System.out.println("Done!!");
        } catch (Exception e) {//
            writeToLog(3, "Exception occured in DB_QueryExecute().. " + e.getMessage(), strprcsinstid);
        }
        //System.out.println("Value="+FieldValue_array.toString());
        if (Flag_null.equalsIgnoreCase("Y")) //Value Contains
        {
            return_str = FieldValue_array.toString();
        } else // Value not contains any thing
        {
            return_str = "NoEntry"; //Dont change here
        }
        return return_str;
    }

    public String DB_QueryExecuteFloat(String sQuery) {
        String FieldValue_array = "";
        String Flag_null = "N";
        String return_str = "";
        try {
            writeToLog(2, "Query is : check" + sQuery, strprcsinstid);
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            List strFieldValue = formObject.getDataFromDataSource(sQuery);
            writeToLog(2, "Check Values***=" + strFieldValue.toString(), strprcsinstid);
            if (!strFieldValue.isEmpty()) {
                Flag_null = "Y"; //Flag Check
                String values = strFieldValue.toString().trim();
                values = values.replace("[", "");
                values = values.replace("]", "");
                values = values.replace(" ", ""); //  Added on 07-12-2016 by bala for removing empty space between the values
                FieldValue_array = values.trim();
            }
            // System.out.println("Done!!");
        } catch (Exception e) {//
            writeToLog(3, "Exception occured in DB_QueryExecute().. " + e.getMessage(), strprcsinstid);
        }
        //System.out.println("Value="+FieldValue_array.toString());
        if (Flag_null.equalsIgnoreCase("Y")) //Value Contains
        {
            return_str = FieldValue_array.toString();
        } else // Value not contains any thing
        {
            return_str = "0.00"; //Dont change here
        }
        return return_str;
    }

    public String DB_QueryExecuteAppMatrix(String sQuery) {
        String FieldValue_array = "";
        String Flag_null = "N";
        String return_str = "";
        try {
            writeToLog(2, "Query is : check" + sQuery, strprcsinstid);
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();
            List strFieldValue = formObject.getDataFromDataSource(sQuery);
            writeToLog(2, "Check Values***=" + strFieldValue.toString(), strprcsinstid);
            if (!strFieldValue.isEmpty()) {
                Flag_null = "Y"; //Flag Check
                String values = strFieldValue.toString().trim();
                values = values.replace("[", "'");
                values = values.replace("]", "'");
                values = values.replace(" ", ""); //  Added on 07-12-2016 by bala for removing empty space between the values
                values = values.replaceAll("''", "'");
                FieldValue_array = values.trim();
            }
            // System.out.println("Done!!");
        } catch (Exception e) {//
            writeToLog(3, "Exception occured in DB_QueryExecute().. " + e.getMessage(), strprcsinstid);
        }
        //System.out.println("Value="+FieldValue_array.toString());
        if (Flag_null.equalsIgnoreCase("Y")) //Value Contains
        {
            return_str = FieldValue_array.toString();
        } else // Value not contains any thing
        {
            return_str = "NoEntry"; //Dont change here
        }
        return return_str;
    }

    public void InserComments() {
        writeToLog(2, "Inside Common function InserComments", strprcsinstid);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String strRemarks = "";
        strRemarks = formObject.getNGValue("Comments").replaceAll("'", "`");
        String winame = formConfig.getConfigElement("ProcessInstanceId");
//        if (strRemarks != null && !strRemarks.equalsIgnoreCase("")) {
        String Username = formObject.getUserName();
        String Activityname = formObject.getWFActivityName();
        writeToLog(2, "winame:" + winame + "Username:" + Username + "Activityname:" + Activityname + "   Comments:" + strRemarks, strprcsinstid);
        String query = "insert into EXT_AP_COMMENTS(PID,UserName,WorkstepName,EnteredDate,Comments)"
                + " values('" + winame + "','" + Username + "','" + Activityname + "',getdate(),'" + strRemarks + "')";
        writeToLog(2, "query:" + query, strprcsinstid);
        formObject.saveDataIntoDataSource(query);
        writeToLog(2, "After Insert", strprcsinstid);
//        } else {
//            System.out.println("Commets Empty");
//            writeToLog(1, "Commets field Empty,its skipped to insert", winame);
//        }
    }
    //Added by NanjundaMoorthy on 01/12/2016

    public void VP_Frame_lock() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
        String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");

        formObject.setVisible("frm_tran_details2", true);
        formObject.setVisible("frm_invdtl_po", true);
        formObject.setVisible("frm_trnsdtl_po", true);//
        formObject.setVisible("frm_venddtl_po", true);//
        formObject.setVisible("frm_accndtl_po", true);//

        formObject.setEnabled("frm_trnsdtl_po", false);
        formObject.setEnabled("frm_venddtl_po", false);
        formObject.setEnabled("frm_accndtl_po", false);
//DeclChange
//        formObject.setVisible("frm_Decl", true);
//        formObject.setEnabled("frm_Decl", true);
//DeclChange        
        formObject.setVisible("frm_comments", true);
        formObject.setVisible("frm_approval", false);
        formObject.setEnabled("frm_comments", true);
        formObject.setEnabled("frm_approval", false);

        if (strTypeOfprocess.equalsIgnoreCase("PO")) {
            formObject.setVisible("frm_po_line", true);
            //formObject.setEnabled("frm_po_line", true);
            formObject.setVisible("frm_nonpo_line", false);
            formObject.setVisible("btn_SAP_PO", true);
            formObject.setVisible("btn_SAP_MPO", true);
            formObject.setVisible("btn_SAP_Vendor", false);

            formObject.setEnabled("TypeOfProcess", false);
        } else if (strTypeOfprocess.equalsIgnoreCase("NONPO")) {
            formObject.setVisible("frm_nonpo_line", true);
            //formObject.setEnabled("frm_nonpo_line", true);
            formObject.setVisible("frm_po_line", false);
            formObject.setVisible("btn_SAP_PO", false);
            formObject.setVisible("btn_SAP_MPO", false);
            formObject.setVisible("btn_SAP_Vendor", true);

            formObject.setEnabled("TypeOfProcess", false);
            formObject.setNGValue("PONumber", "");
            formObject.setNGValue("PurchaseGrp", "");
            formObject.setNGValue("MMDocNo", "");
            formObject.setEnabled("PONumber", false);
            formObject.setEnabled("PurchaseGrp", false);
            formObject.setEnabled("MMDocNo", false);
            formObject.setNGBackColor("PONumber", new Color(225, 225, 225));
            formObject.setNGBackColor("PurchaseGrp", new Color(225, 225, 225));
            formObject.setNGBackColor("MMDocNo", new Color(225, 225, 225));
        } else {
            formObject.setVisible("frm_po_line", false);
            formObject.setVisible("frm_nonpo_line", false);
            formObject.setVisible("btn_SAP_PO", false);
            formObject.setVisible("btn_SAP_MPO", false);
            formObject.setVisible("btn_SAP_Vendor", false);
        }

        if (WorkstepName.equalsIgnoreCase("Scanning") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8")) {
            formObject.setVisible("frm_trnsdtl_po", false);//
            formObject.setVisible("frm_venddtl_po", false);//
            formObject.setVisible("frm_accndtl_po", false);//

            if (WorkstepName.equalsIgnoreCase("Scanning") || WorkstepName.equalsIgnoreCase("Indexing")) {
                formObject.setEnabled("frm_tran_details2", true);
                formObject.setEnabled("frm_invdtl_po", true);

                if (strTypeOfprocess.equalsIgnoreCase("PO")) {
                    formObject.setVisible("frm_po_line", true);
                    formObject.setEnabled("frm_po_line", true);
                    formObject.setVisible("frm_nonpo_line", false);

                    formObject.setEnabled("TypeOfProcess", false);
                } else if (strTypeOfprocess.equalsIgnoreCase("NONPO")) {
                    formObject.setVisible("frm_nonpo_line", true);
                    formObject.setEnabled("frm_nonpo_line", true);
                    formObject.setVisible("frm_po_line", false);

                    formObject.setEnabled("TypeOfProcess", false);
                    formObject.setNGValue("PONumber", "");
                    formObject.setNGValue("PurchaseGrp", "");
                    formObject.setNGValue("MMDocNo", "");
                    formObject.setEnabled("PONumber", false);
                    formObject.setEnabled("PurchaseGrp", false);
                    formObject.setEnabled("MMDocNo", false);
                    formObject.setNGBackColor("PONumber", new Color(225, 225, 225));
                    formObject.setNGBackColor("PurchaseGrp", new Color(225, 225, 225));
                    formObject.setNGBackColor("MMDocNo", new Color(225, 225, 225));
                } else {
                    formObject.setVisible("frm_po_line", false);
                    formObject.setVisible("frm_nonpo_line", false);
                }
            }

            formObject.setVisible("frm_parkdtl_po", false);
            formObject.setVisible("frm_salary_adv", false);
            formObject.setVisible("frm_invoice_details", false);
            formObject.setVisible("frm_ent_scheme", false);
            formObject.setVisible("frm_mobile_claims", false);
            formObject.setVisible("frm_moving_personal_effects", false);
            formObject.setVisible("frm_brokage_fees", false);
            formObject.setVisible("frm_summary", false);
            formObject.setVisible("frm_family_info", false);
            formObject.setVisible("frm_travel_fare", false);
            formObject.setVisible("frm_hotel_fare", false);
            formObject.setVisible("frm_daily_allw", false);
            formObject.setVisible("frm_convey", false);
            formObject.setVisible("frm_misc", false);
            formObject.setVisible("frm_medical_expense", false);

        } else if (WorkstepName.equalsIgnoreCase("Parking") || WorkstepName.equalsIgnoreCase("Posting")) {

            formObject.setEnabled("frm_trnsdtl_po", true);
            formObject.setEnabled("frm_venddtl_po", true);
            formObject.setEnabled("frm_accndtl_po", true);
            formObject.setEnabled("frm_parkdtl_po", true);
            formObject.setEnabled("frm_comments", true);
            formObject.setEnabled("frm_approval", false);

            formObject.setVisible("frm_parkdtl_po", true);
//            //DeclChange
//            formObject.setVisible("frm_Decl", true);
//            formObject.setEnabled("frm_Decl", true);
////DeclChange 
            formObject.setVisible("frm_comments", true);
            formObject.setVisible("frm_approval", false);

            formObject.setVisible("frm_salary_adv", false);
            formObject.setVisible("frm_invoice_details", false);
            formObject.setVisible("frm_ent_scheme", false);
            formObject.setVisible("frm_mobile_claims", false);
            formObject.setVisible("frm_moving_personal_effects", false);
            formObject.setVisible("frm_brokage_fees", false);
            formObject.setVisible("frm_summary", false);
            formObject.setVisible("frm_family_info", false);
            formObject.setVisible("frm_travel_fare", false);
            formObject.setVisible("frm_hotel_fare", false);
            formObject.setVisible("frm_daily_allw", false);
            formObject.setVisible("frm_convey", false);
            formObject.setVisible("frm_misc", false);
            formObject.setVisible("frm_medical_expense", false);

        } else {
            formObject.setVisible("frm_parkdtl_po", true);
            //DeclChange
            String comCode = formObject.getNGValue("CompanyCode");
            writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
            if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                formObject.setVisible("frm_Decl", true);
                formObject.setEnabled("frm_Decl", true);
            }
//DeclChange
            formObject.setVisible("frm_comments", true);
            formObject.setVisible("frm_approval", false);

            formObject.setVisible("frm_salary_adv", false);
            formObject.setVisible("frm_invoice_details", false);
            formObject.setVisible("frm_ent_scheme", false);
            formObject.setVisible("frm_mobile_claims", false);
            formObject.setVisible("frm_moving_personal_effects", false);
            formObject.setVisible("frm_brokage_fees", false);
            formObject.setVisible("frm_summary", false);
            formObject.setVisible("frm_family_info", false);
            formObject.setVisible("frm_travel_fare", false);
            formObject.setVisible("frm_hotel_fare", false);
            formObject.setVisible("frm_daily_allw", false);
            formObject.setVisible("frm_convey", false);
            formObject.setVisible("frm_misc", false);
            formObject.setVisible("frm_medical_expense", false);

        }
        formObject.setEnabled("DateOfReq", false);

    }

    //Added by NanjundaMoorthy on 01/12/2016
    public void VP_Frame_Height() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        formObject.setVisible("lbl_er", false);
        formObject.setVisible("lbl_trcab", false);
        formObject.setHeight("frm_tran_details2", 150);
        String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");
        writeToLog(1, "In VP_Frame_Height", winame);
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");

        //formObject.setVisible("btn_load", false);
        if (WorkstepName.equalsIgnoreCase("Scanning") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8")) {
            if (strTypeOfprocess.equalsIgnoreCase("PO")) {
                writeToLog(1, "In VP_Frame_Height PO", winame);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
                //formObject.setTop("frm_trnsdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                //formObject.setTop("frm_venddtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10);
                //formObject.setTop("frm_accndtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10);
                //formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10);
                formObject.setTop("frm_po_line", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                //formObject.setTop("frm_approval", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_po_line") + 10);
                formObject.setTop("frm_comments", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_po_line") + 10);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_po_line") + 10 + formObject.getHeight("frm_comments") + 10);

            } else if (strTypeOfprocess.equalsIgnoreCase("NONPO")) {
                writeToLog(1, "In VP_Frame_Height NOPO", winame);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
                //formObject.setTop("frm_trnsdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                //formObject.setTop("frm_venddtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10);
                //formObject.setTop("frm_accndtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10);
                //formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10);
                formObject.setTop("frm_nonpo_line", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                //formObject.setTop("frm_approval", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_nonpo_line") + 10);
                formObject.setTop("frm_comments", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_nonpo_line") + 10);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_nonpo_line") + 10 + formObject.getHeight("frm_comments") + 10);
            } else {
                writeToLog(1, "In VP_Frame_Height Else", winame);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
                //formObject.setTop("frm_trnsdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                //formObject.setTop("frm_venddtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10);
                //formObject.setTop("frm_accndtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10);
                //formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10);
                //formObject.setTop("frm_approval", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10);
                //formObject.setTop("frm_comments", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po"));
            }
        } else {
            if (strTypeOfprocess.equalsIgnoreCase("PO")) {
                writeToLog(1, "In VP_Frame_Height PO", winame);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
                formObject.setTop("frm_trnsdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                formObject.setTop("frm_venddtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10);
                formObject.setTop("frm_accndtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10);
                formObject.setTop("frm_po_line", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10);
                formObject.setTop("frm_approval", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_po_line") + 10);
                formObject.setTop("frm_comments", formObject.getHeight("frm_approval") + 20 + formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_po_line") + 10);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_approval") + 20 + formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_po_line") + 10 + formObject.getHeight("frm_comments") + 10);

            } else if (strTypeOfprocess.equalsIgnoreCase("NONPO")) {
                writeToLog(1, "In VP_Frame_Height NOPO", winame);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
                formObject.setTop("frm_trnsdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                formObject.setTop("frm_venddtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10);
                formObject.setTop("frm_accndtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10);
                formObject.setTop("frm_nonpo_line", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10);
                formObject.setTop("frm_approval", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_nonpo_line") + 10);
                formObject.setTop("frm_comments", formObject.getHeight("frm_approval") + 20 + formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_nonpo_line") + 10);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_approval") + 20 + formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_nonpo_line") + 10 + formObject.getHeight("frm_comments") + 10);
            } else {
                writeToLog(1, "In VP_Frame_Height Else", winame);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
                formObject.setTop("frm_trnsdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
                formObject.setTop("frm_venddtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10);
                formObject.setTop("frm_accndtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10);
                //formObject.setTop("frm_approval", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10);
                formObject.setTop("frm_comments", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_trnsdtl_po") + 10 + formObject.getHeight("frm_venddtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_comments") + 10);
            }
        }

    }

    //Addded Bala for hiding frame based on subcategoryq1 which was selected from ER initiation
    public void Approval_lock() {
        writeToLog(2, "Inside appr lock", strprcsinstid);
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String strSubcategory = formObject.getNGValue("SubCategory1");
        // Added by deva  for hiding frame
        if (strSubcategory.equalsIgnoreCase("Entertainment")) {
            formObject.setCaption("frm_ent_scheme", "Entertainment");
        } else if (strSubcategory.equalsIgnoreCase("Others")) {
            formObject.setCaption("frm_ent_scheme", "Others");
        } else if (strSubcategory.equalsIgnoreCase("Self Education Scheme")) {
            formObject.setCaption("frm_ent_scheme", "Self Education Scheme");
        } else if (strSubcategory.equalsIgnoreCase("Gift & Complimentary")) {
            formObject.setCaption("frm_ent_scheme", "Gift & Complimentary");
        } else if (strSubcategory.equalsIgnoreCase("Joining Expense")) {
            formObject.setCaption("frm_brokage_fees", "Joining Expense");
        } else if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
            formObject.setCaption("frm_brokage_fees", "Brokerage Fee");
        } else if (strSubcategory.equalsIgnoreCase("Travel Expense")) {
            formObject.setCaption("frm_brokage_fees", "Travel Expense");
        } else if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {
            formObject.setCaption("frm_brokage_fees", "Look and See Visit");
        } else if (strSubcategory.equalsIgnoreCase("Out of Pocket Expense")) {
            formObject.setCaption("frm_brokage_fees", "Out of Pocket Expense");
        } else if (strSubcategory.equalsIgnoreCase("Salary Advance")) {
            formObject.setCaption("frm_salary_adv", "Salary Advance");
        } else if (strSubcategory.equalsIgnoreCase("House Rent Advance")) {
            formObject.setCaption("frm_salary_adv", "House Rent Advance");
        } //Added By Harinath on 2017/03/22
        else if (strSubcategory.equalsIgnoreCase("Imprest Cash")) {
            formObject.setCaption("frm_salary_adv", "Imprest Cash");
        } //Ended By Harinath on 2017/03/22
        else if (strSubcategory.equalsIgnoreCase("Exceptional Advances")) {
            formObject.setCaption("frm_salary_adv", "Exceptional Advances");
        }

        if (strSubcategory.equalsIgnoreCase("Mobile Re-Imbursements")) {
            writeToLog(2, "Inside mble rmebus", strprcsinstid);

            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                formObject.setVisible("frm_mobile_claims", true);
                //formObject.setTop("frm_mobile_claims",470); 
                // formObject.setTop("frm_approval",690);
                //formObject.setTop("frm_comments",790);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_mobile_claims", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_approval",formObject.getHeight("frm_mobile_claims")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_mobile_claims") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_mobile_claims") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                formObject.setVisible("frm_mobile_claims", true);
                //formObject.setTop("frm_mobile_claims",470); 
                // formObject.setTop("frm_approval",690);
                //formObject.setTop("frm_comments",790);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_mobile_claims", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_approval",formObject.getHeight("frm_mobile_claims")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_mobile_claims") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_mobile_claims") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_mobile_claims") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            }

        } //for Employee Advances hiding frame
        //Modified By Harinath on 2017/03/22
        else if (strSubcategory.equalsIgnoreCase("Salary Advance")
                || strSubcategory.equalsIgnoreCase("House Rent Advance")
                || strSubcategory.equalsIgnoreCase("Exceptional Advances") || strSubcategory.equalsIgnoreCase("Imprest Cash")) {
            //Ended By Harinath on 2017/03/22
            if (strSubcategory.equalsIgnoreCase("House Rent Advance")) {

                formObject.setNGValue("Txt_DOJ", formObject.getNGValue("DateOfJoining"));
                formObject.setNGValue("Txt_DOT", formObject.getNGValue("DateOfTransfer"));

                //formObject.setNGValue("cmb_EAtypeoftransfer", formObject.getNGValue("DateOfTransfer"));
                //Ended By Harinath on 2017/03/22  
                formObject.setVisible("lbl_sal_basic", false);
                formObject.setVisible("BasicSalary", false);

                formObject.setVisible("lbl_EAtypeofrequest", true);
                formObject.setVisible("TypeOfTransfer1", true);

                formObject.setLeft("lbl_sal_repay", 25);
                formObject.setLeft("RepaymentSchedule", 155);
                formObject.setTop("lbl_sal_repay", 60);
                formObject.setTop("RepaymentSchedule", 60);
                formObject.setTop("Lbl_Months", 60);
                formObject.setLeft("lbl_sal_clmamnt", 25);
                formObject.setLeft("ClaimedAmount", 155);
                formObject.setTop("lbl_sal_clmamnt", 90);
                formObject.setTop("ClaimedAmount", 90);

                formObject.setHeight("frm_salary_adv", 150);

            } else if (strSubcategory.equalsIgnoreCase("Imprest Cash")) {

                formObject.setVisible("lbl_EAtypeofrequest", false);
                formObject.setVisible("TypeOfTransfer1", false);

                formObject.setEnabled("frm_salary_adv", true);
                formObject.setVisible("lbl_sal_basic", true);
                formObject.setVisible("BasicSalary", true);

                formObject.setVisible("lbl_DOJ", false);
                formObject.setVisible("Txt_DOJ", false);
                formObject.setVisible("lbl_DOT", false);
                formObject.setVisible("Txt_DOT", false);

                formObject.setLeft("lbl_sal_basic", 25);
                formObject.setLeft("BasicSalary", 155);
                formObject.setTop("lbl_sal_basic", 30);
                formObject.setTop("BasicSalary", 30);
                formObject.setLeft("lbl_sal_elblamnt", 345);
                formObject.setLeft("EligibleAmount", 475);
                formObject.setTop("lbl_sal_elblamnt", 30);
                formObject.setTop("EligibleAmount", 30);

                formObject.setLeft("lbl_sal_repay", 25);
                formObject.setLeft("RepaymentSchedule", 155);
                formObject.setTop("lbl_sal_repay", 60);
                formObject.setTop("RepaymentSchedule", 60);
                formObject.setTop("Lbl_Months", 60);
                formObject.setLeft("lbl_sal_clmamnt", 345);
                formObject.setLeft("ClaimedAmount", 475);
                formObject.setTop("lbl_sal_clmamnt", 60);
                formObject.setTop("ClaimedAmount", 60);

                formObject.setHeight("frm_salary_adv", 90);

            } else if (strSubcategory.equalsIgnoreCase("Salary Advance")) {

                formObject.setVisible("lbl_EAtypeofrequest", false);
                formObject.setVisible("TypeOfTransfer1", false);

                formObject.setTop("lbl_sal_basic", 30);
                formObject.setTop("BasicSalary", 30);
                formObject.setTop("lbl_sal_elblamnt", 30);
                formObject.setTop("EligibleAmount", 30);
                formObject.setTop("lbl_sal_repay", 60);
                formObject.setTop("RepaymentSchedule", 60);
                formObject.setTop("Lbl_Months", 60);
                formObject.setTop("lbl_sal_clmamnt", 60);
                formObject.setTop("ClaimedAmount", 60);
                //Added on 07-NOV-20 for Reason Field
                formObject.setTop("lbl_Reason", 90);
                formObject.setTop("SalaryAdvanceReason", 90);
                String qry = "SELECT SalaryAdvanceReason FROM EXT_AP WHERE WorkID='" + strprcsinstid + "'";
                String qryRes = formObject.getDataFromDataSource(qry).toString();
                qryRes = qryRes.replace("[", "").replace("]", "");
                writeToLog(2, "Qry : " + qry + " and result : " + qryRes, strprcsinstid);
                formObject.setEnabled("SalaryAdvanceReason", true);
                formObject.setNGValue("SalaryAdvanceReason", qryRes);
                formObject.addItem("SalaryAdvanceReason", qryRes);
                formObject.setEnabled("SalaryAdvanceReason", false);
                //End on 07-NOV-20

                formObject.setVisible("lbl_DOJ", false);
                formObject.setVisible("Txt_DOJ", false);
                formObject.setVisible("lbl_DOT", false);
                formObject.setVisible("Txt_DOT", false);

                formObject.setHeight("frm_salary_adv", 120);//Modified on 07-NOV-20 for adding Reason Field
                formObject.setTop("frm_comments", 150);//Added on 07-NOV-20 for adding Reason Field
            } else if (strSubcategory.equalsIgnoreCase("Exceptional Advances")) {

                formObject.setLeft("lbl_sal_clmamnt", 25);
                formObject.setLeft("ClaimedAmount", 155);
                formObject.setTop("lbl_sal_clmamnt", 30);
                formObject.setTop("ClaimedAmount", 30);
                formObject.setTop("lbl_sal_repay", 60);
                formObject.setTop("RepaymentSchedule", 60);
                formObject.setTop("Lbl_Months", 60);

                formObject.setVisible("lbl_sal_repay", true);
                formObject.setVisible("RepaymentSchedule", true);
                formObject.setVisible("Lbl_Months", true);

                formObject.setVisible("lbl_DOJ", false);
                formObject.setVisible("Txt_DOJ", false);
                formObject.setVisible("lbl_DOT", false);
                formObject.setVisible("Txt_DOT", false);
                formObject.setVisible("lbl_sal_basic", false);
                formObject.setVisible("BasicSalary", false);
                formObject.setVisible("lbl_sal_elblamnt", false);
                formObject.setVisible("EligibleAmount", false);
                //Added on 11-NOV-20 for disabling reason field
                formObject.setVisible("lbl_Reason", false);
                formObject.setVisible("SalaryAdvanceReason", false);
                //End on 11-NOV-20

                formObject.setHeight("frm_salary_adv", 90);
            }
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                //Modified By Harinath on 2017/03/22
                formObject.setVisible("frm_salary_adv", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_salary_adv", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_salary_adv") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_salary_adv") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            } else {
                formObject.setVisible("frm_salary_adv", true);
                formObject.setVisible("frm_parkdtl_po", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_salary_adv", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_salary_adv") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_salary_adv") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_salary_adv") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            }

        } else if (strSubcategory.equalsIgnoreCase("Travel Request")) {
            formObject.setNGValue("Txt_MobilNo", formObject.getNGValue("MobileNo"));
            formObject.setVisible("lbl_summ_medexp", false);
            formObject.setVisible("MedicalExpense", false);

            //Display fields
            formObject.setVisible("lbl_trvl_tktno", false);
            formObject.setVisible("txt_trvl_tcktno", false);
            formObject.setVisible("lbl_trvl_amnt", false);
            formObject.setVisible("txt_trvl_amnt", false);
            formObject.setVisible("lbl_trvl_paidby", false);
            formObject.setVisible("cb_trvl_paidby", false);
            formObject.setLeft("Label13", 24);
            formObject.setLeft("txt_trvl_FlightNo", 155);

            formObject.setTop("btn_add_trvl", 210);
            formObject.setTop("btn_mod_trvl", 210);
            formObject.setTop("btn_del_trvl", 210);
            formObject.setTop("btn_ghouse_check", 210);
            formObject.setTop("list_travel", 240);
            formObject.setTop("frm_travel_fare", 400);
//                if(formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant")){
            if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant/New Joinee")) {// Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram                

                formObject.setLeft("Label3", 345);
                formObject.setLeft("OthrPasngr", 475);
                formObject.setTop("Label3", 175);
                formObject.setTop("OthrPasngr", 175);

                formObject.setVisible("Label3", true);
                formObject.setVisible("OthrPasngr", true);

            } else {

                formObject.setVisible("Label3", false);
                formObject.setVisible("OthrPasngr", false);
            }

            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_invoice_details", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_invoice_details", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            }
        } else if (strSubcategory.equalsIgnoreCase("Travel Expense")) {
            formObject.setNGValue("Txt_MobilNo", formObject.getNGValue("MobileNo"));
            formObject.setVisible("lbl_summ_medexp", false);
            formObject.setVisible("btn_ghouse_check", false);
            formObject.setVisible("MedicalExpense", false);

//            if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant")) {
            if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant/New Joinee")) {// Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram                
                formObject.setVisible("Label3", true);
                formObject.setVisible("OthrPasngr", true);

            } else {

                formObject.setVisible("Label3", false);
                formObject.setVisible("OthrPasngr", false);
            }

            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                //formObject.setVisible("frm_brokage_fees", true);                       
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_hotel_fare", true);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }

                //Added by sandeepkn on 10Jan2020 for ASFI and SFIC changes --Start
                //Modified by Sivashankar KS for SFIC & ASFI company code changes on 25-Nov-2019
                if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                    formObject.setVisible("frm_daily_allw", false);
                    formObject.setVisible("frm_convey", false);
                    formObject.setVisible("frm_misc", false);
                    formObject.setVisible("frame_otherexpenses", true);
                    formObject.setVisible("lbl_summ_dailyallw", false);
                    formObject.setVisible("DailyAllowance", false);
                    formObject.setVisible("lbl_summ_misc", false);
                    formObject.setVisible("Miscellaneous", false);
                    formObject.setVisible("lbl_summ_convey", false);
                    formObject.setVisible("Conveyance", false);
                    formObject.setVisible("lbl_summary_otherexpenses", true);
                    formObject.setVisible("OtherExpense", true);
                } else {
                    formObject.setVisible("frm_daily_allw", true);
                    formObject.setVisible("frm_convey", true);
                    formObject.setVisible("frm_misc", true);
                    formObject.setVisible("frame_otherexpenses", false);
                    formObject.setVisible("lbl_summ_dailyallw", true);
                    formObject.setVisible("DailyAllowance", true);
                    formObject.setVisible("lbl_summ_misc", true);
                    formObject.setVisible("Miscellaneous", true);
                    formObject.setVisible("lbl_summ_convey", true);
                    formObject.setVisible("Conveyance", true);
                    formObject.setVisible("lbl_summary_otherexpenses", false);
                    formObject.setVisible("OtherExpense", false);
                }//Added by sandeepkn on 10Jan2020 for ASFI and SFIC changes --End

                //formObject.setVisible("frm_daily_allw", true);
                // formObject.setVisible("frm_convey", true);
                // formObject.setVisible("frm_misc", true);
                formObject.setVisible("frm_summary", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                //Added by sandeepkn on 10Jan2020 for ASFI and SFIC changes --Start
                //Modified by Sivashankar KS for SFIC & ASFI company code changes on 25-Nov-2019
                if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                    formObject.setTop("frame_otherexpenses", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
                    //  String comCode = formObject.getNGValue("CompanyCode");
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                } else {
                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
                    //String comCode = formObject.getNGValue("CompanyCode");
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                }//Added by sandeepkn on 10Jan2020 for ASFI and SFIC changes --End

                // formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                //formObject.setVisible("frm_brokage_fees", true);                       
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_hotel_fare", true);
                formObject.setVisible("frm_daily_allw", true);
                formObject.setEnabled("frm_daily_allw", false);
                formObject.setVisible("frm_convey", true);
                formObject.setVisible("frm_misc", true);
                formObject.setVisible("frm_summary", true);
                formObject.setVisible("frm_parkdtl_po", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                //Modified by Sandeep KN on 10Jan2020  Parking & Posting frame show and hide functionality with respect to SFIC,ASFI and other company code starts here
                if ((formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI"))) {
                    formObject.setVisible("OtherExpense", true);
                    formObject.setVisible("frm_daily_allw", false);
                    formObject.setVisible("frm_convey", false);
                    formObject.setVisible("frm_misc", false);
                    formObject.setTop("frame_otherexpenses", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
                    String comCode = formObject.getNGValue("CompanyCode");
                    writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                } else {
                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
                    String comCode = formObject.getNGValue("CompanyCode");
                    writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                }
                //Modified by Sandeep KN on 10Jan2020 Parking & Posting frame show and hide functionality with respect to SFIC,ASFI and other company code ends here

                // formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            }
        } else if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {

            formObject.setHeight("frm_brokage_fees", 160);
            formObject.setVisible("lbl_brok_amnt", true);
            formObject.setVisible("Amount", true);
            formObject.setVisible("lbl_brok_typeoftrvl", false);
            formObject.setVisible("TypeOfTravel", false);
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                formObject.setVisible("frm_brokage_fees", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_brokage_fees")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                sfd
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                formObject.setVisible("frm_brokage_fees", true);
                formObject.setVisible("frm_parkdtl_po", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            }

        } else if (strSubcategory.equalsIgnoreCase("Joining Expense")) {
            formObject.setHeight("frm_brokage_fees", 130);
            formObject.setVisible("TypeOfTravel", true);
            formObject.setVisible("lbl_brok_typeoftrvl", false);
            formObject.setVisible("TravelReqNo", false);
            formObject.setVisible("lbl_brok_trvlreqno", false);
            formObject.setVisible("lbl_prev_loc", false);
            formObject.setVisible("PrevLoc", false);
            formObject.setVisible("lbl_prev_sub_loc", false);
            formObject.setVisible("PrevSubLoc", false);
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                formObject.setVisible("frm_brokage_fees", true);
                // formObject.setEnabled("frm_brokage_fees", false);
                // formObject.setTop("frm_brokage_fees",470);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_hotel_fare", true);
                // formObject.setEnabled("frm_travel_fare", false);
                //  formObject.setTop("frm_travel_fare",600);
                formObject.setVisible("frm_convey", true);
                // formObject.setEnabled("frm_convey", false);
                //  formObject.setTop("frm_convey",960);
                formObject.setVisible("frm_misc", true);
                // formObject.setEnabled("frm_misc", false);
                //  formObject.setTop("frm_misc",1260);
                formObject.setVisible("frm_medical_expense", true);
                //formObject.setEnabled("frm_medical_expense", false);
                //  formObject.setTop("frm_medical_expense",1520);
                formObject.setVisible("frm_summary", true);
                //formObject.setEnabled("frm_summary", false);
                //   formObject.setTop("frm_summary",1790);
                //  formObject.setTop("frm_approval",1920);
                //   formObject.setTop("frm_comments",2020);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_convey", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_medical_expense", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_summary")+10+formObject.getHeight("frm_medical_expense")+10+formObject.getHeight("frm_misc")+10+formObject.getHeight("frm_convey")+10+formObject.getHeight("frm_travel_fare")+10+formObject.getHeight("frm_brokage_fees")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                formObject.setVisible("frm_brokage_fees", true);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_convey", true);
                formObject.setVisible("frm_misc", true);
                formObject.setVisible("frm_medical_expense", true);
                formObject.setVisible("frm_summary", true);
                formObject.setVisible("frm_parkdtl_po", true);
                formObject.setVisible("frm_hotel_fare", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_convey", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_misc", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_medical_expense", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            }
        } else if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                formObject.setVisible("frm_family_info", true);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                //formObject.setEnabled("frm_family_info", false);
                // formObject.setTop("frm_family_info",470);
                formObject.setVisible("frm_brokage_fees", true);
                //formObject.setEnabled("frm_brokage_fees", false);
                // formObject.setTop("frm_brokage_fees",720);
                formObject.setVisible("frm_travel_fare", true);
                //formObject.setEnabled("frm_travel_fare", false);
                // formObject.setTop("frm_travel_fare",850);
                formObject.setVisible("frm_hotel_fare", true);
                // formObject.setEnabled("frm_hotel_fare", false);
                //   formObject.setTop("frm_hotel_fare",1210);
                //Modified By Harinath om 2017/03/20
                //formObject.setVisible("frm_daily_allw", true);
                //Ended By Harinath
                // formObject.setEnabled("frm_daily_allw", false);
                //    formObject.setTop("frm_daily_allw",1510);
                formObject.setVisible("frm_convey", true);
                // formObject.setEnabled("frm_convey", false);
                //   formObject.setTop("frm_convey",1810);
                formObject.setVisible("frm_misc", true);
                //  formObject.setEnabled("frm_misc", false);
                //   formObject.setTop("frm_misc",2110);                          
                formObject.setVisible("frm_summary", true);
                // formObject.setEnabled("frm_summary", false);
                //  formObject.setTop("frm_summary",2380);
                //  formObject.setTop("frm_approval",2510);
                //  formObject.setTop("frm_comments",2610);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_summary")+10+formObject.getHeight("frm_misc")+10+formObject.getHeight("frm_convey")+10+formObject.getHeight("frm_daily_allw")+10+formObject.getHeight("frm_hotel_fare")+10+formObject.getHeight("frm_travel_fare")+10+formObject.getHeight("frm_brokage_fees")+10+formObject.getHeight("frm_family_info")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
                //String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                formObject.setVisible("frm_parkdtl_po", true);
                formObject.setVisible("frm_family_info", true);
                formObject.setVisible("frm_brokage_fees", true);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_hotel_fare", true);
//                formObject.setVisible("frm_daily_allw", true);
                formObject.setVisible("frm_convey", true);
                formObject.setVisible("frm_misc", true);
                formObject.setVisible("frm_summary", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            }

        } else if (strSubcategory.equalsIgnoreCase("Moving of Personal Effects")) {
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                formObject.setVisible("frm_moving_personal_effects", true);
                // formObject.setEnabled("frm_moving_personal_effects", false);
                //  formObject.setTop("frm_moving_personal_effects",470);                           
                //  formObject.setTop("frm_approval",640);
                //   formObject.setTop("frm_comments",740);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_moving_personal_effects", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_moving_personal_effects")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_moving_personal_effects") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
               if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_moving_personal_effects") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                formObject.setVisible("frm_moving_personal_effects", true);
                formObject.setVisible("frm_parkdtl_po", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_moving_personal_effects", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_moving_personal_effects") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_moving_personal_effects") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_moving_personal_effects") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            }

        } else if (strSubcategory.equalsIgnoreCase("Out of Pocket Expense") || strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval") || WorkstepName.equalsIgnoreCase("Parking") || WorkstepName.equalsIgnoreCase("Posting")) {//Modified on 25-MAY-21
                formObject.setVisible("frm_family_info", true);
                // formObject.setEnabled("frm_family_info", false);
                // formObject.setTop("frm_family_info",470);
                formObject.setVisible("frm_brokage_fees", true);
                // formObject.setEnabled("frm_brokage_fees", false);
                // formObject.setTop("frm_brokage_fees",720);
                formObject.setVisible("frm_travel_fare", true);
                // formObject.setEnabled("frm_travel_fare", false);
                //  formObject.setTop("frm_travel_fare",850);
                formObject.setVisible("frm_daily_allw", true);
                //formObject.setEnabled("frm_daily_allw", false);
                //  formObject.setTop("frm_daily_allw",1210);
                formObject.setVisible("frm_convey", true);
                // formObject.setEnabled("frm_convey", false);
                //  formObject.setTop("frm_convey",1510);
                formObject.setVisible("frm_misc", true);
                //formObject.setEnabled("frm_misc", false);
                //  formObject.setTop("frm_misc",1810);
                formObject.setVisible("frm_summary", true);
                //  formObject.setEnabled("frm_summary", false);
                //  formObject.setTop("frm_summary",2080);
                //  formObject.setTop("frm_approval",2210);
                //  formObject.setTop("frm_comments",2310);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //Modified By Harinath on 2017/08/18 NOTE : To add hotel fares template in Relocation-TravelExpense subcategory                              
                if (strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
                    formObject.setVisible("frm_hotel_fare", true);//Added on 25-May-21
                    formObject.setVisible("frm_daily_allw", true);//Added on 25-May-21
                    //DeclChange
                    String comCode = formObject.getNGValue("CompanyCode");
                    writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setVisible("frm_Decl", true);
                    }
                    formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                } else {
                    formObject.setVisible("frm_hotel_fare", true);//Added on 25-May-21
                    formObject.setVisible("frm_daily_allw", true);//Added on 25-May-21
                    formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                }
                //Ended By Harinath on 2017/08/18 
            } else {
                formObject.setVisible("frm_family_info", true);
                formObject.setVisible("frm_brokage_fees", true);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_daily_allw", true);
                formObject.setVisible("frm_convey", true);
                formObject.setVisible("frm_misc", true);
                formObject.setVisible("frm_summary", true);
                formObject.setVisible("frm_parkdtl_po", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_daily_allw", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            }
        } else if (strSubcategory.equalsIgnoreCase("Relocation-TravelExpense-Own Vehicle")) {
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                formObject.setVisible("frm_family_info", true);
                // formObject.setEnabled("frm_family_info", false);
                //  formObject.setTop("frm_family_info",470);
                formObject.setVisible("frm_travel_fare", true);
                //formObject.setEnabled("frm_travel_fare", false);
                //  formObject.setTop("frm_travel_fare",720);
                formObject.setVisible("frm_daily_allw", true);
                // formObject.setEnabled("frm_daily_allw", false);
                //   formObject.setTop("frm_daily_allw",1080);
                formObject.setVisible("frm_convey", true);
                // formObject.setEnabled("frm_convey", false);
                //    formObject.setTop("frm_convey",1380);
                formObject.setVisible("frm_misc", true);
                // formObject.setEnabled("frm_misc", false);
                //     formObject.setTop("frm_misc",1670);
                formObject.setVisible("frm_summary", true);
                // formObject.setEnabled("frm_summary", false);
                //    formObject.setTop("frm_summary",1960);
                //    formObject.setTop("frm_approval",2090);
                //    formObject.setTop("frm_comments",2190);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //Modified By Harinath on 2017/08/18 NOTE : Toadd hotel fares template in Relocation-TravelExpense subcategory                              
                if (strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
                    formObject.setVisible("frm_hotel_fare", true);
                    //DeclChange
                    String comCode = formObject.getNGValue("CompanyCode");
                    writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setVisible("frm_Decl", true);
                    }
                    formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                } else {

                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                }
                //Ended By Harinath on 2017/08/18  
            } else {
                formObject.setVisible("frm_parkdtl_po", true);
                formObject.setVisible("frm_family_info", true);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setVisible("frm_daily_allw", true);
                formObject.setVisible("frm_convey", true);
                formObject.setVisible("frm_misc", true);
                formObject.setVisible("frm_summary", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_daily_allw", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            }

        } else if (strSubcategory.equalsIgnoreCase("Self Education Scheme")) {
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {    // common.DBValues_Combo("SELECT ACCRef FROM EXT_AP_ER_GLcode", "cb_entschm_accref");
                formObject.setVisible("frm_ent_scheme", true);
                //formObject.setEnabled("frm_ent_scheme", false);
                //   formObject.setTop("frm_ent_scheme",470);
                //   formObject.setTop("frm_approval",770);
                //   formObject.setTop("frm_comments",870);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_ent_scheme", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_ent_scheme")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                formObject.setVisible("frm_ent_scheme", true);
                formObject.setVisible("frm_parkdtl_po", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_ent_scheme", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            }

        } else if ((strSubcategory.equalsIgnoreCase("Entertainment"))
                || (strSubcategory.equalsIgnoreCase("Others")) || (strSubcategory.equalsIgnoreCase("GIFT & COMPLIMENTARY"))) {
            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                //common.DBValues_Combo("SELECT ACCRef FROM EXT_AP_ER_GLcode", "cb_entschm_accref");
                formObject.setVisible("frm_ent_scheme", true);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                // formObject.setEnabled("frm_ent_scheme", false);
                //  formObject.setTop("frm_ent_scheme",470);
                //  formObject.setTop("frm_approval",770);
                //  formObject.setTop("frm_comments",870);  

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_ent_scheme", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_ent_scheme")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            } else {
                formObject.setVisible("frm_ent_scheme", true);
                formObject.setVisible("frm_parkdtl_po", true);

                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_ent_scheme", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_comments", formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            }
        }

    }
    // Below function wrriten to disply corresping category1 fields based on the selection (only setenabled)

    public void Approval_OpenIndexing() {
        writeToLog(2, "Inside appr lock", strprcsinstid);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String strSubcategory = formObject.getNGValue("SubCategory1");
        writeToLog(2, "strSubcategory=" + strSubcategory, strprcsinstid);
        // Added by deva  for hiding frame
        if (strSubcategory.equalsIgnoreCase("Entertainment")) {
            //Check   
        }

        if (strSubcategory.equalsIgnoreCase("Mobile Re-Imbursements")) {
            formObject.setEnabled("frm_mobile_claims", true);
        } //for Employee Advances hiding frame
        else if (strSubcategory.equalsIgnoreCase("Salary Advance")
                || strSubcategory.equalsIgnoreCase("Exceptional Advances")) {
            formObject.setEnabled("frm_salary_adv", true);

        } //Modified By Harinath on 2017/03/22
        else if (strSubcategory.equalsIgnoreCase("House Rent Advance") || strSubcategory.equalsIgnoreCase("Imprest Cash")) //Ended By Harinath on 2017/03/22                
        {
            formObject.setEnabled("frm_salary_adv", true);
            formObject.setVisible("lbl_sal_basic", false);
            formObject.setVisible("BasicSalary", false);
            formObject.setLeft("lbl_sal_elblamnt", 25);
            formObject.setLeft("EligibleAmount", 165);
            formObject.setLeft("lbl_sal_repay", 345);
            formObject.setLeft("RepaymentSchedule", 475);
            formObject.setTop("lbl_sal_repay", 30);
            formObject.setTop("RepaymentSchedule", 30);
            formObject.setLeft("lbl_sal_clmamnt", 25);
            formObject.setLeft("ClaimedAmount", 165);
        } else if (strSubcategory.equalsIgnoreCase("Travel Expense")) {

            formObject.setEnabled("frm_brokage_fees", true);
            formObject.setEnabled("frm_travel_fare", true);
            formObject.setEnabled("frm_hotel_fare", true);
            formObject.setEnabled("frm_convey", true);
            formObject.setEnabled("frm_misc", true);
            formObject.setEnabled("frm_summary", true);

        } else if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
            formObject.setEnabled("frm_brokage_fees", true);
        } else if (strSubcategory.equalsIgnoreCase("Joining Expense")) {
            writeToLog(2, "Inside Joining Expense", strprcsinstid);
            formObject.setEnabled("frm_brokage_fees", true);
            formObject.setEnabled("frm_travel_fare", true);
            formObject.setEnabled("frm_hotel_fare", true);
            formObject.setEnabled("frm_convey", true);
            formObject.setEnabled("frm_misc", true);
            formObject.setEnabled("frm_medical_expense", true);
            formObject.setEnabled("frm_summary", true);

        } else if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {

            formObject.setEnabled("frm_family_info", true);
            formObject.setEnabled("frm_brokage_fees", true);
            formObject.setEnabled("frm_travel_fare", true);
            formObject.setEnabled("frm_hotel_fare", true);
            //Modified by Harinath on 2017/03/20
            //formObject.setEnabled("frm_daily_allw", true);
            //Ended by Harinath on 2017/03/20
            formObject.setEnabled("frm_convey", true);
            formObject.setEnabled("frm_misc", true);
            formObject.setEnabled("frm_summary", true);

        } else if (strSubcategory.equalsIgnoreCase("Moving of Personal Effects")) {
            formObject.setEnabled("frm_moving_personal_effects", true);

        } else if (strSubcategory.equalsIgnoreCase("Out of Pocket Expense") || strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {

            formObject.setEnabled("frm_family_info", true);
            formObject.setEnabled("frm_brokage_fees", true);
            formObject.setEnabled("frm_travel_fare", true);
            formObject.setEnabled("frm_daily_allw", true);
            formObject.setEnabled("frm_convey", true);
            formObject.setEnabled("frm_misc", true);
            formObject.setEnabled("frm_summary", true);
            if (strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
                formObject.setVisible("frm_hotel_fare", true);
            }
        } else if (strSubcategory.equalsIgnoreCase("Relocation-TravelExpense-Own Vehicle")) {

            formObject.setEnabled("frm_family_info", true);
            formObject.setEnabled("frm_travel_fare", true);
            formObject.setEnabled("frm_daily_allw", true);
            formObject.setEnabled("frm_convey", true);
            formObject.setEnabled("frm_misc", true);
            formObject.setEnabled("frm_summary", true);

        } else if (strSubcategory.equalsIgnoreCase("Self Education Scheme")) {
            formObject.setEnabled("frm_ent_scheme", true);
        } else if ((strSubcategory.equalsIgnoreCase("Entertainment"))
                || (strSubcategory.equalsIgnoreCase("Others")) || (strSubcategory.equalsIgnoreCase("GIFT & COMPLIMENTARY"))) {

            formObject.setEnabled("frm_ent_scheme", true);

        }

    }

    public void HideFrames_Init() {
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");

        String ER_WS = "";
        writeToLog(2, "Inside Hide frames", strprcsinstid);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        writeToLog(2, "subcat=22" + formObject.getNGValue("SubCategory1"), strprcsinstid);
        formObject.setVisible("lbl_vp", false);
        formObject.setVisible("lbl_trcab", false);
        formObject.setVisible("frm_salary_adv", false);
        formObject.setVisible("frm_ent_scheme", false);
        formObject.setVisible("frm_mobile_claims", false);
        formObject.setVisible("frm_moving_personal_effects", false);
        formObject.setVisible("frm_brokage_fees", false);
        formObject.setVisible("frm_summary", false);
        formObject.setVisible("frm_family_info", false);
        formObject.setVisible("frm_travel_fare", false);
        formObject.setVisible("frm_hotel_fare", false);
        formObject.setVisible("frm_daily_allw", false);
        formObject.setVisible("frm_convey", false);
        formObject.setVisible("frm_misc", false);
        formObject.setVisible("frm_medical_expense", false);
        //Hiding PO NON-PO Frames
        ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        writeToLog(2, "ER WS Status=" + ER_WS, strprcsinstid);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) {

            if (WorkstepName.equalsIgnoreCase("ER_Initiation") || WorkstepName.equalsIgnoreCase("Rework") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8") || WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) {
                //Lock the other WS(PO/NON-PO) frames
                formObject.setVisible("frm_invdtl_po", false);
                formObject.setVisible("frm_trnsdtl_po", false);
                formObject.setVisible("frm_venddtl_po", false);
                formObject.setVisible("frm_accndtl_po", false);
                formObject.setVisible("frm_parkdtl_po", false);
                formObject.setVisible("frm_po_line", true);
                //Hiding below text 
                formObject.setVisible("SubCat2", false);
                formObject.setVisible("Label5", false);
                formObject.setVisible("SubCat3", false);
                formObject.setVisible("Label1", false);
                formObject.setHeight("frm_tran_details2", 120);
                formObject.getHeight("frm_tran_details2");
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

            } else {
                //Lock the other WS(PO/NON-PO) frames
                formObject.setVisible("frm_invdtl_po", false);
                formObject.setVisible("frm_trnsdtl_po", false);
                formObject.setVisible("frm_venddtl_po", false);
                formObject.setVisible("frm_accndtl_po", false);
                formObject.setVisible("frm_parkdtl_po", true);
                formObject.setEnabled("frm_parkdtl_po", true);
                //Added by Sandeep KN Parking & Posting frame show and hide functionality with respect to SFIC,ASFI and other company code starts here
                if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                    formObject.setVisible("frame_otherexpenses", true);
                    formObject.setEnabled("frame_otherexpenses", true);
                }
                //Added by Sandeep KN Parking & Posting frame show and hide functionality with respect to SFIC,ASFI and other company code ends here

                formObject.setVisible("frm_po_line", true);
                //Hiding below text 
                formObject.setVisible("SubCat2", false);
                formObject.setVisible("Label5", false);
                formObject.setVisible("SubCat3", false);
                formObject.setVisible("Label1", false);
                formObject.setHeight("frm_tran_details2", 120);
                formObject.getHeight("frm_tran_details2");
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
            }

        }
//                            formObject.setTop("frm_approval",470);
//                            formObject.setTop("frm_comments",570);
    }

    /*
     * Function Name    :writeToLog
     * Description      :This function is used to write XML,Success and Error logs for the specified processinstance id
     * Return Value     :Void
     * Input Parameter  :1)LogType(1-XmlLog,2-SuccessLog,3-ErrorLog)
     *                   2)Log String
     *                   3)ProcessInstanceID
         
     
     */
    public static void writeToLog(int intLogType, String strText, String strProcessInstanceID) {
        int logcount = 0;
        String strLogFilePath = "";
        GregorianCalendar cal = new GregorianCalendar();
        File objDirs = null;
        if (WriteLOG.equalsIgnoreCase("y") || intLogType == 3) {
            try {

//                strLogFilePath = "ProcessInstanceIDLogs\\" + File.separator + strProcessInstanceID;
                strLogFilePath = "AP_Logs\\" + File.separator + strProcessInstanceID;
                objDirs = new File(strLogFilePath);
                objDirs.mkdirs();
                switch (intLogType) {
                    case 1:
                        strLogFilePath = strLogFilePath + File.separator + XML_LOG_NAME;
                        break;
                    case 2:
                        strLogFilePath = strLogFilePath + File.separator + SUCCESS_LOG_NAME;
                        break;
                    case 3:
                        strLogFilePath = strLogFilePath + File.separator + Error_LOG_NAME;
                        break;

                }
                File objDirs1 = new File(strLogFilePath);
                while (true) {
                    if (new File(objDirs1.getAbsolutePath() + "_" + logcount).length() > 0) {
                        logcount++;
                        continue;
                    }
                    if (objDirs1.length() > (1024 * 1024 * 10)) {
                        objDirs1.renameTo(new File(objDirs1.getAbsolutePath() + "_" + logcount));
                        break;
                    }
                    break;
                }
                FileOutputStream os = new FileOutputStream(strLogFilePath, true);
                String strNewLine = "\n";
                byte[] bNewLine = strNewLine.getBytes();
                byte[] bText = strText.getBytes();
                String strTime = new SimpleDateFormat("HH:mm:ss").format(cal.getTime());
                String strDate = cal.get(Calendar.DAY_OF_MONTH) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.YEAR);
                byte[] btime = strTime.getBytes();
                byte[] bdate = strDate.getBytes();
                byte[] bspecial = ":".getBytes();
                byte[] bspace = " ".getBytes();
                os.write(bNewLine);
                os.write(bdate);
                os.write(bspace);
                os.write(btime);
                os.write(bspecial);
                os.write(bText);
                os.write(bNewLine);
                os.close();
            } catch (Exception e) {
                System.out.println("exception in writing to log " + e.getMessage());
                e.printStackTrace();
            } finally {
                if (strLogFilePath != null) {
                    strLogFilePath = null;
                }
                if (cal != null) {
                    cal = null;
                }
                if (objDirs != null) {
                    objDirs = null;
                }
            }
        }
    }

    /*public void TravelCab_Initaition_frm_height() {

     //Edited on Bala G on 21-12-2016 for height -> old code commeted Above
     FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
     String winame = formConfig.getConfigElement("ProcessInstanceId");
     FormReference formObject = FormContext.getCurrentInstance().getFormReference();
     //formObject.setNGValue("TypeOfProcess", "NONPO");
     //formObject.setLocked("TypeOfProcess", true);
     writeToLog(1, "In Travel Cab_Frame_Height NOPO", winame);
     formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
     formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
     formObject.setTop("frm_comments", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
     formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_comments") + 10);

     }*/

 /*public void TravelCab_Park_Post_frm_height() {

     //Edited on Bala G on 21-12-2016 for height -> old code commeted Above
     FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
     String winame = formConfig.getConfigElement("ProcessInstanceId");
     FormReference formObject = FormContext.getCurrentInstance().getFormReference();
     //formObject.setNGValue("TypeOfProcess", "NONPO");
     //formObject.setLocked("TypeOfProcess", true);
     formObject.setVisible("frm_parkdtl_po", true);
     formObject.setEnabled("frm_parkdtl_po", true);
     writeToLog(1, "In Travel Cab_Frame_Height NOPO", winame);
     formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
     formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
     formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
     formObject.setTop("frm_comments", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10);
     formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_comments") + 40);

     }*/
    // Below code writen to view the button based on Invoicetype seletion by the user Travel/Cab    
    /*public void Travel_Cab_ButtonView() {
     FormReference formObject = FormContext.getCurrentInstance().getFormReference();
     String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
     formObject.setVisible("btn_trnsdtl", false);
     formObject.setCaption("btn_Reject", "Reject");
     if (strTypeofinvoice.equalsIgnoreCase("Travel")) {
     formObject.setVisible("btn_Travel", true);
     formObject.setEnabled("btn_Travel", true);
     formObject.setEnabled("btn_Cab", false);
     formObject.setVisible("btn_Cab", false);
     formObject.setTop("btn_Travel", 128);
     formObject.setLeft("btn_Travel", 24);
            
     } else if (strTypeofinvoice.equalsIgnoreCase("Cab")) {
     formObject.setVisible("btn_Travel", false);
     formObject.setEnabled("btn_Travel", false);
     formObject.setEnabled("btn_Cab", true);
     formObject.setVisible("btn_Cab", true);
     formObject.setTop("btn_Cab", 128);
     formObject.setLeft("btn_Cab", 24);
     }
     }*/
 /*public void TravelCab_Initaition_frm_visible() {
     FormReference formObject = FormContext.getCurrentInstance().getFormReference();
     String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
     String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");

     //formObject.setNGValue("TypeOfProcess", "NONPO");
     //formObject.setLocked("TypeOfProcess", true);

     formObject.setVisible("lbl_er", false);
     formObject.setVisible("lbl_vp", false);
     formObject.setVisible("frm_salary_adv", false);
     // formObject.setVisible("frm_invoice_details", false); Commented bala on 210-12-2016
     formObject.setVisible("frm_ent_scheme", false);
     formObject.setVisible("frm_mobile_claims", false);
     formObject.setVisible("frm_moving_personal_effects", false);
     formObject.setVisible("frm_brokage_fees", false);
     formObject.setVisible("frm_summary", false);
     formObject.setVisible("frm_family_info", false);
     formObject.setVisible("frm_travel_fare", false);
     formObject.setVisible("frm_hotel_fare", false);
     formObject.setVisible("frm_daily_allw", false);
     formObject.setVisible("frm_convey", false);
     formObject.setVisible("frm_misc", false);
     formObject.setVisible("frm_medical_expense", false);
     formObject.setVisible("frm_nonpo_line", false);
     formObject.setVisible("frm_po_line", false);
     formObject.setVisible("frm_approval", false);
     formObject.setVisible("btn_Reject", false);
     formObject.setVisible("btn_Travel", false);
     formObject.setVisible("btn_Cab", false);
     formObject.setVisible("btn_Approve", false);
     formObject.setVisible("btn_Exception", false);
     formObject.setVisible("btn_Rescan", false);
     formObject.setVisible("frm_invoice_details", false);
     formObject.setVisible("frm_trnsdtl_po", true);
     formObject.setVisible("frm_invdtl_po", true);
     formObject.setVisible("frm_comments", true); //Added Newly
     formObject.setVisible("frm_venddtl_po", false);
     formObject.setVisible("frm_accndtl_po", false);
     formObject.setVisible("frm_parkdtl_po", false);
     //formObject.setVisible("btn_load", true);
     // formObject.setVisible("frm_nonpo_line", true);
     // formObject.setVisible("frm_po_line", true);
     }*/

 /*public void TravelCab_Initaition_frm_enable() {
     FormReference formObject = FormContext.getCurrentInstance().getFormReference();
     //String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
     String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");

     formObject.setEnabled("frm_tran_details2", true);
     formObject.setEnabled("frm_invdtl_po", true);
     formObject.setEnabled("frm_comments", true); //ADDED NEWLY
     //formObject.setEnabled("btn_load", true);

     formObject.setEnabled("frm_venddtl_po", false);
     formObject.setEnabled("frm_accndtl_po", false);
     formObject.setEnabled("frm_parkdtl_po", false);
     formObject.setEnabled("frm_nonpo_line", false);
     formObject.setEnabled("frm_po_line", true);
     formObject.setEnabled("frm_trnsdtl_po", false);
     formObject.setEnabled("btn_Travel", false);
     formObject.setEnabled("btn_Cab", false);

     formObject.setNGValue("PONumber", "");
     formObject.setNGValue("PurchaseGrp", "");
     formObject.setNGValue("MMDocNo", "");
     formObject.setEnabled("PONumber", false);
     formObject.setEnabled("PurchaseGrp", false);
     formObject.setEnabled("MMDocNo", false);
     formObject.setNGBackColor("PONumber", new Color(225, 225, 225));
     formObject.setNGBackColor("PurchaseGrp", new Color(225, 225, 225));
     formObject.setNGBackColor("MMDocNo", new Color(225, 225, 225));

     }*/
    // Added by Deva on 10-12-2016 20:00
    //Begin
    public void ER_Frames() {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1");
        formObject.setEnabled("TypeOfProcess", false);
        formObject.setEnabled("SubCategory1", false);
        formObject.setEnabled("cb_trvl_class", false);
        formObject.setVisible("btn_calc_totamnt", true);
        formObject.setVisible("txt_totalamount", true);
        formObject.setVisible("TotalAmount", true);

        formObject.setVisible("lbl_trns_cmpnycode", false);
        formObject.setVisible("CompanyCode", false);
        formObject.setVisible("lbl_trns_region", false);
        formObject.setVisible("Region", false);
        formObject.setHeight("frm_tran_details2", 130);

        if (strSubcategory.equalsIgnoreCase("Entertainment")) {
            formObject.setCaption("frm_ent_scheme", "Entertainment");
        } else if (strSubcategory.equalsIgnoreCase("Others")) {
            formObject.setCaption("frm_ent_scheme", "Others");
        } else if (strSubcategory.equalsIgnoreCase("Self Education Scheme")) {
            formObject.setCaption("frm_ent_scheme", "Self Education Scheme");
        } else if (strSubcategory.equalsIgnoreCase("Gift & Complimentary")) {
            formObject.setCaption("frm_ent_scheme", "Gift & Complimentary");
        } else if (strSubcategory.equalsIgnoreCase("Joining Expense")) {
            formObject.setCaption("frm_brokage_fees", "Joining Expense");
        } else if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
            formObject.setCaption("frm_brokage_fees", "Brokerage Fee");
        } else if (strSubcategory.equalsIgnoreCase("Travel Expense")) {
            formObject.setCaption("frm_brokage_fees", "Travel Expense");
        } else if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {
            formObject.setCaption("frm_brokage_fees", "Look and See Visit");
        } else if (strSubcategory.equalsIgnoreCase("Out of Pocket Expense")) {
            formObject.setCaption("frm_brokage_fees", "Out of Pocket Expense");
        } else if (strSubcategory.equalsIgnoreCase("Salary Advance")) {
            formObject.setCaption("frm_salary_adv", "Salary Advance");
        } else if (strSubcategory.equalsIgnoreCase("House Rent Advance")) {
            formObject.setCaption("frm_salary_adv", "House Rent Advance");
        } //Added By Harinath on 2017/03/22
        else if (strSubcategory.equalsIgnoreCase("Imprest Cash")) {
            formObject.setCaption("frm_salary_adv", "Imprest Cash");
        } //Added By Harinath on 2017/03/22
        else if (strSubcategory.equalsIgnoreCase("Exceptional Advances")) {
            formObject.setCaption("frm_salary_adv", "Exceptional Advances");
        }

        if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Travel Request") || strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {
            formObject.setVisible("lbl_note", false);
            formObject.setVisible("frm_Decl", false);
        } else {
            formObject.setVisible("lbl_note", true);
            //DeclChange
            String comCode = formObject.getNGValue("CompanyCode");
            writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
            if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                formObject.setVisible("frm_Decl", true);
            }
        }
        if (strSubcategory != null || !strSubcategory.equalsIgnoreCase("") || strSubcategory != "--Select--") {
            // Below three control disabled once click load , it wont user to change once button load clicked.
//                    formObject.setEnabled("TypeOfInvoice", false);
//                    formObject.setEnabled("SubCategory1", false);
//                    formObject.setEnabled("btn_load", false);
//                    //End 

            if ((strSubcategory != null && !strSubcategory.equalsIgnoreCase("") && !strSubcategory.equalsIgnoreCase("--Select--"))) {
                formObject.setEnabled("TypeOfInvoice", false);
                formObject.setEnabled("SubCategory1", false);
                formObject.setEnabled("btn_load", false);
                formObject.setEnabled("btn_sub", false);

                formObject.setVisible("lbl_trns_cmpnycode", true);
                formObject.setVisible("CompanyCode", true);
                formObject.setVisible("lbl_trns_region", true);
                formObject.setVisible("Region", true);
                formObject.setHeight("frm_tran_details2", 120);

            } else {
                writeToLog(2, "Kindly select TypeOfInvoice and SubCategory1 correctly", winame);

                //throw new ValidatorException(new FacesMessage(" Kindly select TypeOfInvoice and SubCategory1 correctly", "SubCategory1"));
            }
            // Added by deva  for hiding frame
            if (strSubcategory.equalsIgnoreCase("Entertainment")) {
                /*formObject.setNGValue("RequestFor", "Self");
                 formObject.setLocked("RequestFor", true);
                 formObject.setLocked("EmployeeCode", false);*///Commented by Sivashankar KS on 23-01-2019 i.e, for Others it is taking as Self
                formObject.setCaption("frm_ent_scheme", "Entertainment");
            } else if (strSubcategory.equalsIgnoreCase("Others")) {
                formObject.setCaption("frm_ent_scheme", "Others");
            } else if (strSubcategory.equalsIgnoreCase("Gift & Complimentary")) {
                formObject.setCaption("frm_ent_scheme", "Gift & Complimentary");
            }

            if (strSubcategory.equalsIgnoreCase("Mobile Re-Imbursements")) {
                formObject.setVisible("frm_invoice_details", true);
                //added by Deva for hiding Mobile Frame
                formObject.setVisible("frm_Decl", false);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_mobile_claims", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_mobile_claims")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_mobile_claims") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 10 + formObject.getHeight("frm_mobile_claims") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setVisible("frm_mobile_claims", true);
                formObject.setEnabled("frm_mobile_claims", true);
                //formObject.setTop("frm_mobile_claims",490);                         
                //formObject.setTop("frm_approval",710);
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                formObject.setEnabled("frm_comments", true);
//                        
            } //for Employee Advances hiding frame
            //Modified By Harinath on 2017/03/22
            else if (strSubcategory.equalsIgnoreCase("Salary Advance")
                    || strSubcategory.equalsIgnoreCase("House Rent Advance")
                    || strSubcategory.equalsIgnoreCase("Exceptional Advances") || strSubcategory.equalsIgnoreCase("Imprest Cash")) {
                //Ended By Harinath on 2017/03/22
                formObject.setVisible("frm_Decl", false);
                formObject.setVisible("btn_calc_totamnt", false);
                formObject.setVisible("txt_totalamount", false);
                formObject.setVisible("TotalAmount", false);
                //Modified By Harinath on 2017/03/22
                if (strSubcategory.equalsIgnoreCase("House Rent Advance")) {
                    //Ended By Harinath on 2017/03/22  

                    formObject.setNGValue("Txt_DOJ", formObject.getNGValue("DateOfJoining"));
                    formObject.setNGValue("Txt_DOT", formObject.getNGValue("DateOfTransfer"));

                    formObject.setVisible("lbl_sal_basic", false);
                    formObject.setVisible("BasicSalary", false);
                    /*formObject.setLeft("lbl_sal_elblamnt", 25);
                     formObject.setLeft("EligibleAmount",155);
                  
                     formObject.setLeft("lbl_sal_repay", 345);
                     formObject.setLeft("RepaymentSchedule",475);
                     formObject.setTop("lbl_sal_repay", 30);
                     formObject.setTop("RepaymentSchedule",30);
                     formObject.setLeft("lbl_sal_clmamnt", 25);
                     formObject.setLeft("ClaimedAmount",155);*/
                    formObject.setVisible("lbl_EAtypeofrequest", true);
                    formObject.setVisible("TypeOfTransfer1", true);

                    /*
                     formObject.setVisible("lbl_sal_elblamnt", false);
                     formObject.setVisible("EligibleAmount", false);
                     formObject.setLeft("lbl_sal_repay", 25);
                     formObject.setLeft("RepaymentSchedule", 155);
                     formObject.setTop("lbl_sal_repay", 30);
                     formObject.setTop("RepaymentSchedule", 30);
                     formObject.setLeft("lbl_sal_clmamnt", 345);
                     formObject.setLeft("ClaimedAmount", 475);
                     formObject.setTop("lbl_sal_clmamnt", 30);
                     formObject.setTop("ClaimedAmount", 30);
                     formObject.setLeft("lbl_DOJ", 25);
                     formObject.setLeft("Txt_DOJ", 155);
                     formObject.setTop("lbl_DOJ", 60);
                     formObject.setTop("Txt_DOJ", 60);
                     */
                    formObject.setLeft("lbl_sal_repay", 25);
                    formObject.setLeft("RepaymentSchedule", 155);
                    formObject.setLeft("Lbl_Months", 220);
                    formObject.setTop("lbl_sal_repay", 60);
                    formObject.setTop("RepaymentSchedule", 60);
                    formObject.setTop("Lbl_Months", 60);
                    formObject.setLeft("lbl_sal_clmamnt", 25);
                    formObject.setLeft("ClaimedAmount", 155);
                    formObject.setTop("lbl_sal_clmamnt", 90);
                    formObject.setTop("ClaimedAmount", 90);

                    formObject.setHeight("frm_salary_adv", 90);
                } else if (strSubcategory.equalsIgnoreCase("Imprest Cash")) {

                    formObject.setVisible("lbl_EAtypeofrequest", false);
                    formObject.setVisible("TypeOfTransfer1", false);

                    formObject.setEnabled("frm_salary_adv", true);
                    formObject.setVisible("lbl_sal_basic", true);
                    formObject.setVisible("BasicSalary", true);

                    formObject.setVisible("lbl_DOJ", false);
                    formObject.setVisible("Txt_DOJ", false);
                    formObject.setVisible("lbl_DOT", false);
                    formObject.setVisible("Txt_DOT", false);

                    formObject.setLeft("lbl_sal_basic", 25);
                    formObject.setLeft("BasicSalary", 155);
                    formObject.setTop("lbl_sal_basic", 30);
                    formObject.setTop("BasicSalary", 30);
                    formObject.setLeft("lbl_sal_elblamnt", 345);
                    formObject.setLeft("EligibleAmount", 475);
                    formObject.setTop("lbl_sal_elblamnt", 30);
                    formObject.setTop("EligibleAmount", 30);

                    formObject.setLeft("lbl_sal_repay", 25);
                    formObject.setLeft("RepaymentSchedule", 155);
                    formObject.setLeft("Lbl_Months", 220);
                    formObject.setTop("lbl_sal_repay", 60);
                    formObject.setTop("RepaymentSchedule", 60);
                    formObject.setTop("Lbl_Months", 60);
                    formObject.setLeft("lbl_sal_clmamnt", 345);
                    formObject.setLeft("ClaimedAmount", 475);
                    formObject.setTop("lbl_sal_clmamnt", 60);
                    formObject.setTop("ClaimedAmount", 60);

                    formObject.setHeight("frm_salary_adv", 90);
                } else if (strSubcategory.equalsIgnoreCase("Salary Advance")) {

                    formObject.setTop("lbl_sal_basic", 30);
                    formObject.setTop("BasicSalary", 30);
                    formObject.setTop("lbl_sal_elblamnt", 30);
                    formObject.setTop("EligibleAmount", 30);
                    formObject.setTop("lbl_sal_repay", 60);
                    formObject.setTop("Lbl_Months", 60);
                    formObject.setTop("RepaymentSchedule", 60);
                    formObject.setTop("lbl_sal_clmamnt", 60);
                    formObject.setTop("ClaimedAmount", 60);
                    //Added on 07-NOV-20 for Salary advance reason 
                    formObject.setTop("lbl_Reason", 90);
                    formObject.setTop("SalaryAdvanceReason", 90);
                    //End on 07-NOV-20
                    formObject.setVisible("lbl_DOJ", false);
                    formObject.setVisible("Txt_DOJ", false);
                    formObject.setVisible("lbl_DOT", false);
                    formObject.setVisible("Txt_DOT", false);

                    formObject.setHeight("frm_salary_adv", 120);//Modified on 07-NOV-20 for adding Reason Field
                    //Added on 07-NOV-20 for adding Reason Field 
                    formObject.setTop("frm_comments", 150);
                    String qry = "SELECT reasons FROM ext_ap_SalaryAdvance_Reasons ORDER BY len(Reasons),reasons";
                    DBValues_ComboReload(qry, "SalaryAdvanceReason");
                    //End on 07-NOV-20
                } else if (strSubcategory.equalsIgnoreCase("Exceptional Advances")) {
                    //formObject.setLocked("RepaymentSchedule", false);
                    //formObject.setNGBackColor("EligibleAmount", new Color(225, 225, 225));

                    formObject.setVisible("lbl_sal_basic", false);
                    formObject.setVisible("BasicSalary", false);
                    formObject.setVisible("lbl_sal_elblamnt", false);
                    formObject.setVisible("EligibleAmount", false);
                    formObject.setVisible("lbl_sal_repay", false);
                    formObject.setVisible("RepaymentSchedule", false);
                    formObject.setVisible("Lbl_Months", false);
                    //Added on 11-NOV-20 for disabling reason field
                    formObject.setVisible("lbl_Reason", false);
                    formObject.setVisible("SalaryAdvanceReason", false);
                    //End on 11-NOV-20

                    formObject.setLeft("lbl_sal_clmamnt", 25);
                    formObject.setLeft("ClaimedAmount", 155);
                    formObject.setTop("lbl_sal_clmamnt", 30);
                    formObject.setTop("ClaimedAmount", 30);
                    formObject.setLeft("lbl_DOJ", 345);
                    formObject.setLeft("Txt_DOJ", 475);
                    formObject.setTop("lbl_DOJ", 30);
                    formObject.setTop("Txt_DOJ", 30);

                    formObject.setVisible("lbl_DOJ", false);
                    formObject.setVisible("Txt_DOJ", false);
                    formObject.setVisible("lbl_DOT", false);
                    formObject.setVisible("Txt_DOT", false);

                    formObject.setHeight("frm_salary_adv", 90);

                }
                formObject.setVisible("frm_salary_adv", true);
                formObject.setEnabled("frm_salary_adv", true);
                formObject.setVisible("frm_invoice_details", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_salary_adv", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_salary_adv")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_salary_adv") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_salary_adv") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_salary_adv",490);
                //formObject.setTop("frm_approval",590);
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                formObject.setEnabled("frm_comments", true);

            } else if (strSubcategory.equalsIgnoreCase("Travel Request")) {
                formObject.setVisible("btn_calc_totamnt", false);
                formObject.setVisible("txt_totalamount", false);
                formObject.setVisible("TotalAmount", false);
                formObject.setCaption("lbl_comments", "Travel Purpose");
                formObject.setVisible("frm_Decl", false);
                //formObject.setVisible("btn_fromloc", true);
                //formObject.setVisible("btn_toloc", true);

                //Display fields
                formObject.setVisible("lbl_trvl_tktno", false);
                formObject.setVisible("txt_trvl_tcktno", false);
                formObject.setVisible("lbl_trvl_amnt", false);
                formObject.setVisible("txt_trvl_amnt", false);
                formObject.setVisible("lbl_trvl_paidby", false);
                formObject.setVisible("cb_trvl_paidby", false);
                formObject.setLeft("Label13", 24);
                formObject.setLeft("txt_trvl_FlightNo", 155);

                formObject.setTop("btn_add_trvl", 210);
                formObject.setTop("btn_mod_trvl", 210);
                formObject.setTop("btn_del_trvl", 210);
                formObject.setTop("btn_ghouse_check", 210);
                formObject.setTop("list_travel", 240);
                formObject.setHeight("frm_travel_fare", 400);
//                if(formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant")){
                if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant/New Joinee")) {// Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram                
                    formObject.setLeft("Label3", 345);
                    formObject.setLeft("OthrPasngr", 475);
                    formObject.setTop("Label3", 175);
                    formObject.setTop("OthrPasngr", 175);

                    formObject.setVisible("Label3", true);
                    formObject.setVisible("OthrPasngr", true);

                } else {

                    formObject.setVisible("Label3", false);
                    formObject.setVisible("OthrPasngr", false);
                }

                formObject.setVisible("frm_invoice_details", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                formObject.setTop("frm_comments", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                formObject.setVisible("frm_travel_fare", true);
                formObject.setEnabled("frm_travel_fare", true);

                formObject.setEnabled("frm_comments", true);
                //formObject.setTop("frm_comments",2380);
                formObject.setNGValue("Amount", "");
                formObject.setEnabled("Amount", false);
                formObject.setNGBackColor("Amount", new Color(225, 225, 225));
                formObject.setVisible("lbl_summ_medexp", false);
                formObject.setVisible("MedicalExpense", false);
                formObject.setNGValue("Txt_MobilNo", formObject.getNGValue("MobileNo"));
                //Commented By Harinath on 2017/03/27
                /*
                 if(formObject.getNGValue("TypeOfTravel").equalsIgnoreCase("Domestic")){
                 formObject.setEnabled("txt_trvl_fromloc", false);
                 formObject.setEnabled("txt_trvl_toloc", false);
                 
                 }
                 */
                //Ended By Harinath on 2017/03/27
            } else if (strSubcategory.equalsIgnoreCase("Travel Expense")) {
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                formObject.setNGValue("Txt_MobilNo", formObject.getNGValue("MobileNo"));
//                if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant")) {
                if (formObject.getNGValue("RequestFor").equalsIgnoreCase("Consultant/New Joinee")) {// Modified by Sivashankar KS on 30-Apr-2019 suggested by Sivaram                
                    formObject.setVisible("Label3", true);
                    formObject.setVisible("OthrPasngr", true);

                } else {

                    formObject.setVisible("Label3", false);
                    formObject.setVisible("OthrPasngr", false);
                }

                formObject.setVisible("frm_invoice_details", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                //Added by sandeepkn on10Jan2020 for ASFI and SFIC changes-- start
                //Modified by Sivashankar KS for SFIC & ASFI company code changes on 25-Nov-2019
                if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                    formObject.setTop("frame_otherexpenses", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frame_otherexpenses") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                } else {
                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                }//Added by sandeepkn on10Jan2020 for ASFI and SFIC changes-- End

                //formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_summary")+10+formObject.getHeight("frm_misc")+10+formObject.getHeight("frm_convey")+10+formObject.getHeight("frm_daily_allw")+10+formObject.getHeight("frm_hotel_fare")+10+formObject.getHeight("frm_travel_fare")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                //formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setHeight("Main", formObject.getHeight("frm_comments") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setVisible("frm_brokage_fees", true);
                //formObject.setEnabled("frm_brokage_fees", true);
                //formObject.setTop("frm_brokage_fees",490);                            
                formObject.setVisible("frm_travel_fare", true);
                formObject.setEnabled("frm_travel_fare", true);
                // formObject.setTop("frm_travel_fare",620);
                formObject.setVisible("frm_hotel_fare", true);
                formObject.setEnabled("frm_hotel_fare", true);
                //formObject.setTop("frm_hotel_fare",980);

                //Added by sandeepkn on10Jan2020 for ASFI and SFIC changes-- Start
                //Modified by Sivashankar KS for SFIC & ASFI company code changes on 25-Nov-2019
                if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                    formObject.setVisible("frm_daily_allw", false);
                    formObject.setEnabled("frm_daily_allw", false);
                    //formObject.setTop("frm_daily_allw",1280);
                    formObject.setVisible("frm_convey", false);
                    formObject.setEnabled("frm_convey", false);
                    //formObject.setTop("frm_convey",1580);                            
                    formObject.setVisible("frm_misc", false);
                    formObject.setEnabled("frm_misc", false);
                    //formObject.setTop("frm_misc",1880);  
                    formObject.setVisible("frame_otherexpenses", true);
                    formObject.setEnabled("frame_otherexpenses", true);
                    formObject.setVisible("lbl_summ_dailyallw", false);
                    formObject.setVisible("DailyAllowance", false);
                    formObject.setVisible("lbl_summ_misc", false);
                    formObject.setVisible("Miscellaneous", false);
                    formObject.setVisible("lbl_summ_convey", false);
                    formObject.setVisible("Conveyance", false);
                    formObject.setVisible("lbl_summary_otherexpenses", true);
                    formObject.setVisible("OtherExpense", true);
                } else {
                    formObject.setVisible("frm_daily_allw", true);
                    formObject.setEnabled("frm_daily_allw", true);
                    //formObject.setTop("frm_daily_allw",1280);
                    formObject.setVisible("frm_convey", true);
                    formObject.setEnabled("frm_convey", true);
                    //formObject.setTop("frm_convey",1580);                            
                    formObject.setVisible("frm_misc", true);
                    formObject.setEnabled("frm_misc", true);
                    //formObject.setTop("frm_misc",1880);  
                    formObject.setVisible("frame_otherexpenses", false);
                    formObject.setEnabled("frame_otherexpenses", false);
                    formObject.setVisible("lbl_summ_dailyallw", true);
                    formObject.setVisible("DailyAllowance", true);
                    formObject.setVisible("lbl_summ_misc", true);
                    formObject.setVisible("Miscellaneous", true);
                    formObject.setVisible("lbl_summ_convey", true);
                    formObject.setVisible("Conveyance", true);
                    formObject.setVisible("lbl_summary_otherexpenses", false);
                    formObject.setVisible("OtherExpense", false);
                }
                //Added by sandeepkn on10Jan2020 for ASFI and SFIC changes-- End

                // formObject.setVisible("frm_daily_allw", true);
                //formObject.setEnabled("frm_daily_allw", true);
                //formObject.setTop("frm_daily_allw",1280);
                //formObject.setVisible("frm_convey", true);
                // formObject.setEnabled("frm_convey", true);
                //formObject.setTop("frm_convey",1580);                            
                //formObject.setVisible("frm_misc", true);
                // formObject.setEnabled("frm_misc", true);
                //formObject.setTop("frm_misc",1880);  
                formObject.setVisible("frm_summary", true);
                formObject.setEnabled("frm_summary", true);
                //formObject.setTop("frm_summary",2150);          
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                //formObject.setTop("frm_approval",2280);
                formObject.setEnabled("frm_comments", true);
                //formObject.setTop("frm_comments",2380);
                formObject.setNGValue("Amount", "");
                formObject.setEnabled("Amount", false);
                formObject.setNGBackColor("Amount", new Color(225, 225, 225));
                formObject.setVisible("lbl_summ_medexp", false);
                formObject.setVisible("MedicalExpense", false);

                formObject.setVisible("lbl_trvl_note", true);
                formObject.setVisible("lbl_trvl_note_1", true);
                formObject.setVisible("lbl_trvl_note_2", true);

                formObject.setVisible("lbl_da_note", true);

                formObject.setVisible("lbl_hotel_note", true);
                formObject.setVisible("lbel_convey_note", true);
                formObject.setVisible("lbel_misc_note", true);
                formObject.setVisible("lbl_note", true);
                formObject.setNGValue("Txt_MobilNo", formObject.getNGValue("MobileNo"));
                // formObject.setEnabled("TypeOfTravel", false);               
                // formObject.setEnabled("txt_trvl_fromloc", false);
                // formObject.setEnabled("txt_trvl_toloc", false);
                // formObject.setEnabled("dp_trvl_trvl", false);
                // formObject.setEnabled("cb_trvl_mode", false);
                //formObject.setEnabled("cb_trvl_class", false);
                // formObject.setEnabled("btn_trvl_class", false);

                //Modified By Harinath on 2017/12/04
                String Grade1 = formObject.getNGValue("Grade");
                String strDesig = formObject.getNGValue("Designation");

                /*
                 if(Grade1.equalsIgnoreCase("Management Trainee") || Grade1.equalsIgnoreCase("Executive-Sales") 
                 || (Grade1.equalsIgnoreCase("Manager Band III") && (strDesig.equalsIgnoreCase("Sales Operation Manager") || strDesig.equalsIgnoreCase("Sales Operations Manager") || strDesig.equalsIgnoreCase("Sales Operations Manager-TN(North)")))
                 || (Grade1.equalsIgnoreCase("Manager Grade IV") && (strDesig.equalsIgnoreCase("Senior Area Sales Manager") || strDesig.equalsIgnoreCase("Senior Area Sales Manager - Bread") || strDesig.equalsIgnoreCase("Sr. Area Sales Manager")))
                 || (Grade1.equalsIgnoreCase("Manager Grade V") && (strDesig.equalsIgnoreCase("Area Sales Manager") || strDesig.equalsIgnoreCase("Area Sales Manager - Fresh Dairy (South)") || strDesig.equalsIgnoreCase("Area Sales Manager - Modern Trade")))){  
                    
                 formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                 formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                 formObject.setEnabled("txt_dailyallw_CityType", true);
                 formObject.setEnabled("txt_dailyallw_City", true);
                 formObject.setEnabled("txt_dailyallw_entilperday", false);
                 DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)", "txt_dailyallw_CityType");
                 } else{
                 String queryDA = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='DailyAllowance' and grade='" + Grade1 + "'";
                 DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                 formObject.setEnabled("txt_dailyallw_entilperday", false);
                 }                
                 //                String queryDA = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='DailyAllowance' and grade='" + Grade1 + "'";
                 //                DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                 //                formObject.setEnabled("txt_dailyallw_entilperday", false);
                 */
                String toDate = "";
                if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                    String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                    String strToDate = formObject.getNGValue("dp_dailyallw_todate");
//                        String toDate = "";
                    toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    if (SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                            || SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                        //Entire grade having citytype DA(Ex: Management Trainee)
                        formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                        formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                        formObject.setEnabled("txt_dailyallw_CityType", true);
                        formObject.setEnabled("txt_dailyallw_City", true);
                        DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock) WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                        formObject.setEnabled("txt_dailyallw_entilperday", false);
                        formObject.setNGValue("txt_dailyallw_entilperday", "");
                    }

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    //Entire grade having citytype DA(Ex: Managers)
                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                    formObject.setEnabled("txt_dailyallw_CityType", true);
                    formObject.setEnabled("txt_dailyallw_City", true);
                    DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                    formObject.setNGValue("txt_dailyallw_entilperday", "");
                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_Loc", Color.white);
                    formObject.setEnabled("txt_dailyallw_CityType", true);
                    formObject.setEnabled("txt_dailyallw_City", true);
                    formObject.setEnabled("txt_dailyallw_Loc", true);
                    DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                    formObject.setNGValue("txt_dailyallw_entilperday", "");

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "'  AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    //String queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WHERE DAType='Grade' AND Grade='" + Grade1 + "'";
                    DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);

                    formObject.setNGBackColor("txt_dailyallw_CityType", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_City", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_Loc", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_OthrLoc", new Color(225, 225, 225));
                    formObject.setEnabled("txt_dailyallw_CityType", false);
                    formObject.setEnabled("txt_dailyallw_City", false);
                    formObject.setEnabled("txt_dailyallw_Loc", false);
                    formObject.setEnabled("txt_dailyallw_OthrLoc", false);
                }

                //Ended By Harinath on 2017/12/04
            } else if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
                formObject.setVisible("frm_invoice_details", true);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setHeight("frm_brokage_fees", 160);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_brokage_fees")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                formObject.setVisible("frm_brokage_fees", true);
                formObject.setEnabled("frm_brokage_fees", true);
                //formObject.setTop("frm_brokage_fees",490); 
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                //formObject.setTop("frm_approval",610);
                //formObject.setTop("frm_comments",710);
                formObject.setEnabled("frm_comments", true);
                formObject.setCaption("lbl_brok_typeofrns", "Type of claim");
                formObject.setVisible("lbl_brok_amnt", true);
                formObject.setVisible("Amount", true);
                formObject.setVisible("lbl_brok_typeoftrvl", false);
                formObject.setVisible("TypeOfTravel", false);
                /*
                 formObject.setNGValue("TypeOfTravel", "");
                 formObject.setEnabled("TypeOfTravel", false);
                 formObject.setNGBackColor("TypeOfTravel", new Color(225, 225, 225));
                 formObject.setNGValue("TravelReqNo", "");
                 formObject.setEnabled("TravelReqNo", false);
                 formObject.setNGBackColor("TravelReqNo", new Color(225, 225, 225));
                 if(formObject.getNGValue("TypeOfTransfer").equalsIgnoreCase("New Joinee")){                    
                 formObject.setNGValue("DateOfTransfer", "");
                 formObject.setEnabled("DateOfTransfer", false);
                 formObject.setNGBackColor("DateOfTransfer", new Color(225, 225, 225));
                 formObject.setNGValue("PrevLoc", "");
                 formObject.setEnabled("PrevLoc", false);
                 formObject.setNGBackColor("PrevLoc", new Color(225, 225, 225));
                 formObject.setNGValue("PrevSubLoc", "");
                 formObject.setEnabled("PrevSubLoc", false);
                 formObject.setNGBackColor("PrevSubLoc", new Color(225, 225, 225));
                 }*/

            } else if (strSubcategory.equalsIgnoreCase("Joining Expense")) {

                formObject.setVisible("frm_invoice_details", true);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setHeight("frm_brokage_fees", 130);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_convey", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_misc", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_medical_expense", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_summary")+10+formObject.getHeight("frm_medical_expense")+10+formObject.getHeight("frm_misc")+10+formObject.getHeight("frm_convey")+10+formObject.getHeight("frm_travel_fare")+10+formObject.getHeight("frm_brokage_fees")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_medical_expense") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                formObject.setVisible("frm_brokage_fees", true);
                formObject.setEnabled("frm_brokage_fees", true);
                // formObject.setTop("frm_brokage_fees",490);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setEnabled("frm_travel_fare", true);
                formObject.setVisible("frm_hotel_fare", true);
                formObject.setEnabled("frm_hotel_fare", true);
                // formObject.setTop("frm_travel_fare",610);
                formObject.setVisible("frm_convey", true);
                formObject.setEnabled("frm_convey", true);
                // formObject.setTop("frm_convey",970);
                formObject.setVisible("frm_misc", true);
                formObject.setEnabled("frm_misc", true);
                // formObject.setTop("frm_misc",1270);
                formObject.setVisible("frm_medical_expense", true);
                formObject.setEnabled("frm_medical_expense", true);
                //  formObject.setTop("frm_medical_expense",1530);
                formObject.setVisible("frm_summary", true);
                formObject.setEnabled("frm_summary", true);
                //  formObject.setTop("frm_summary",1800);
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                //  formObject.setTop("frm_approval",1930);
                formObject.setEnabled("frm_comments", true);
                //  formObject.setTop("frm_comments",2030);
                //formObject.setNGValue("Amount", "");
                // formObject.setEnabled("Amount", false);
                // formObject.setNGBackColor("Amount", new Color(225, 225, 225));
                formObject.setNGValue("TypeOfTransfer", "New Joinee");
                formObject.setEnabled("TypeOfTransfer", false);
                //formObject.setLocked("TypeOfTransfer", true);
                formObject.setVisible("TypeOfTravel", true);
                formObject.setVisible("lbl_brok_typeoftrvl", false);
                formObject.setVisible("TravelReqNo", false);
                formObject.setVisible("lbl_brok_trvlreqno", false);
                formObject.setVisible("lbl_prev_loc", false);
                formObject.setVisible("PrevLoc", false);
                formObject.setVisible("lbl_prev_sub_loc", false);
                formObject.setVisible("PrevSubLoc", false);

            } else if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {
                formObject.setVisible("frm_invoice_details", true);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //Modified by Harinath on 2017/03/20
                formObject.setTop("frm_convey", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //Ended by Harinath on 2017/03/20
                formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_summary")+10+formObject.getHeight("frm_misc")+10+formObject.getHeight("frm_convey")+10+formObject.getHeight("frm_daily_allw")+10+formObject.getHeight("frm_hotel_fare")+10+formObject.getHeight("frm_travel_fare")+10+formObject.getHeight("frm_brokage_fees")+10+formObject.getHeight("frm_family_info")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setVisible("frm_family_info", true);
                formObject.setEnabled("frm_family_info", true);
                //formObject.setTop("frm_family_info",490);
                formObject.setVisible("frm_brokage_fees", true);
                formObject.setEnabled("frm_brokage_fees", true);
                //formObject.setTop("frm_brokage_fees",730);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setEnabled("frm_travel_fare", true);
                //formObject.setTop("frm_travel_fare",860);
                formObject.setVisible("frm_hotel_fare", true);
                formObject.setEnabled("frm_hotel_fare", true);
                //formObject.setTop("frm_hotel_fare",1220);
                formObject.setVisible("frm_daily_allw", true);
                formObject.setEnabled("frm_daily_allw", true);
                //formObject.setTop("frm_daily_allw",1520);
                formObject.setVisible("frm_convey", true);
                formObject.setEnabled("frm_convey", true);
                //formObject.setTop("frm_convey",1820);
                formObject.setVisible("frm_misc", true);
                formObject.setEnabled("frm_misc", true);
                //formObject.setTop("frm_misc",2120);                          
                formObject.setVisible("frm_summary", true);
                formObject.setEnabled("frm_summary", true);
                //formObject.setTop("frm_summary",2390);
                //formObject.setTop("frm_approval",2520);
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                formObject.setEnabled("frm_comments", true);
                //formObject.setTop("frm_comments",2620);
                formObject.setNGValue("Amount", "");
                formObject.setEnabled("Amount", false);
                formObject.setNGBackColor("Amount", new Color(225, 225, 225));

            } else if (strSubcategory.equalsIgnoreCase("Moving of Personal Effects")) {
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                formObject.setVisible("frm_invoice_details", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_moving_personal_effects", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_moving_personal_effects")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_moving_personal_effects") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_moving_personal_effects") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setVisible("frm_moving_personal_effects", true);
                formObject.setEnabled("frm_moving_personal_effects", true);
                //formObject.setTop("frm_moving_personal_effects",490);   
                formObject.setEnabled("frm_approval", false);
                //formObject.setTop("frm_approval",650);
                formObject.setEnabled("frm_comments", true);
                //formObject.setTop("frm_comments",750);
                formObject.setEnabled("RoadTax", false);
                formObject.setEnabled("LossOnPreClosureLease", false);
                formObject.setEnabled("OctroiPay", false);
                formObject.setEnabled("PackMove", false);
                formObject.setEnabled("SchlfeenoYN", false);
                formObject.setEnabled("SchlfeeElbamnt", false);
                formObject.setEnabled("NameChild1", false);
                formObject.setEnabled("NameChild2", false);
                formObject.setEnabled("SchlfeeClaimamnt", false);

            } else if (strSubcategory.equalsIgnoreCase("Out of Pocket Expense") || strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
                formObject.setVisible("frm_invoice_details", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_brokage_fees", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //Modified By Harinath on 2017/08/18 NOTE : Toadd hotel fares template in Relocation-TravelExpense subcategory                              
                if (strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
                    formObject.setVisible("frm_hotel_fare", true);
                    formObject.setEnabled("frm_hotel_fare", true);
                    //DeclChange
                    String comCode = formObject.getNGValue("CompanyCode");
                    writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setVisible("frm_Decl", true);
                    }
                    formObject.setTop("frm_hotel_fare", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //formObject.setTop("frm_approval",formObject.getHeight("frm_summary")+10+formObject.getHeight("frm_misc")+10+formObject.getHeight("frm_convey")+10+formObject.getHeight("frm_daily_allw")+10+formObject.getHeight("frm_travel_fare")+10+formObject.getHeight("frm_brokage_fees")+10+formObject.getHeight("frm_family_info")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                    formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                    if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                        formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                        formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    }
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_hotel_fare") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                } else {
                    formObject.setTop("frm_daily_allw", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                    //formObject.setTop("frm_approval",formObject.getHeight("frm_summary")+10+formObject.getHeight("frm_misc")+10+formObject.getHeight("frm_convey")+10+formObject.getHeight("frm_daily_allw")+10+formObject.getHeight("frm_travel_fare")+10+formObject.getHeight("frm_brokage_fees")+10+formObject.getHeight("frm_family_info")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                    formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
//                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
//                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                    formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_brokage_fees") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                }
                //Ended By Harinath on 2017/08/18
                formObject.setVisible("frm_family_info", true);
                formObject.setEnabled("frm_family_info", true);
                //formObject.setTop("frm_family_info",490);
                formObject.setVisible("frm_brokage_fees", true);
                formObject.setEnabled("frm_brokage_fees", true);
                //formObject.setTop("frm_brokage_fees",730);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setEnabled("frm_travel_fare", true);
                //formObject.setTop("frm_travel_fare",860);
                formObject.setVisible("frm_daily_allw", true);
                formObject.setEnabled("frm_daily_allw", true);
                //formObject.setTop("frm_daily_allw",1220);
                formObject.setVisible("frm_convey", true);
                formObject.setEnabled("frm_convey", true);
                //formObject.setTop("frm_convey",1520);
                formObject.setVisible("frm_misc", true);
                formObject.setEnabled("frm_misc", true);
                //formObject.setTop("frm_misc",1820);
                formObject.setVisible("frm_summary", true);
                formObject.setEnabled("frm_summary", true);
                //formObject.setTop("frm_summary",2090);
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                //formObject.setTop("frm_approval",2220);
                formObject.setEnabled("frm_comments", true);
                formObject.setNGValue("Amount", "");
                formObject.setEnabled("Amount", false);
                formObject.setNGBackColor("Amount", new Color(225, 225, 225));
                //formObject.setTop("frm_comments",2320);
                //Added By Harinath on 2017/03/22
                String Grade1 = formObject.getNGValue("Grade");
                String strDesig = formObject.getNGValue("Designation");

                //Commented by Sivashankar KS on 20-09-2018 starts here
                /*String queryDA = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='DailyAllowance' and grade='" + Grade1 + "'";
                 DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                 formObject.setEnabled("txt_dailyallw_entilperday", false);*/
                //Commented by Sivashankar KS on 20-09-2018 ends here
                //Ended By Harinath on 2017/03/22
                //Added by Sivashankar KS on 20-09-2018 starts here
                String toDate = "";
                if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                    String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                    String strToDate = formObject.getNGValue("dp_dailyallw_todate");
//                        String toDate = "";
                    toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
                }
                writeToLog(2, "SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil", winame);
                /*if(!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "'").equalsIgnoreCase(null)
                 && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "'").equalsIgnoreCase("")){  
                
                 DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "'", "txt_dailyallw_entilperday");
                 formObject.setEnabled("txt_dailyallw_entilperday", false);
                    
                 }*/

                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "'", "txt_dailyallw_entilperday");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    if (SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                            || SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                        //Entire grade having citytype DA(Ex: Management Trainee)
                        formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                        formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                        formObject.setEnabled("txt_dailyallw_CityType", true);
                        formObject.setEnabled("txt_dailyallw_City", true);
                        DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                        formObject.setEnabled("txt_dailyallw_entilperday", false);
                        formObject.setNGValue("txt_dailyallw_entilperday", "");
                    }

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    //Entire grade having citytype DA(Ex: Managers)
                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                    formObject.setEnabled("txt_dailyallw_CityType", true);
                    formObject.setEnabled("txt_dailyallw_City", true);
                    DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock) WHERE '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                    formObject.setNGValue("txt_dailyallw_entilperday", "");
                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_Loc", Color.white);
                    formObject.setEnabled("txt_dailyallw_CityType", true);
                    formObject.setEnabled("txt_dailyallw_City", true);
                    formObject.setEnabled("txt_dailyallw_Loc", true);
                    DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                    formObject.setNGValue("txt_dailyallw_entilperday", "");

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    //String queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WHERE DAType='Grade' AND Grade='" + Grade1 + "'";
                    DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);

                    formObject.setNGBackColor("txt_dailyallw_CityType", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_City", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_Loc", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_OthrLoc", new Color(225, 225, 225));
                    formObject.setEnabled("txt_dailyallw_CityType", false);
                    formObject.setEnabled("txt_dailyallw_City", false);
                    formObject.setEnabled("txt_dailyallw_Loc", false);
                    formObject.setEnabled("txt_dailyallw_OthrLoc", false);
                }

                //Added by Sivashankar KS on 20-09-2018 ends here
            } else if (strTypeofinvoice.equalsIgnoreCase("Relocation") && (strSubcategory.equalsIgnoreCase("Relocation-TravelExpense-Own Vehicle"))) {
                formObject.setVisible("frm_invoice_details", true);
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_family_info", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_brokage_fees",formObject.getHeight("frm_family_info")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_travel_fare", formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_daily_allw", formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_convey", formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_misc", formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_summary", formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_summary")+10+formObject.getHeight("frm_misc")+10+formObject.getHeight("frm_convey")+10+formObject.getHeight("frm_daily_allw")+10+formObject.getHeight("frm_travel_fare")+10+formObject.getHeight("frm_family_info")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_summary") + 10 + formObject.getHeight("frm_misc") + 10 + formObject.getHeight("frm_convey") + 10 + formObject.getHeight("frm_daily_allw") + 10 + formObject.getHeight("frm_travel_fare") + 10 + formObject.getHeight("frm_family_info") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);

                formObject.setVisible("frm_family_info", true);
                formObject.setEnabled("frm_family_info", true);
                //formObject.setTop("frm_family_info",490);
                formObject.setVisible("frm_travel_fare", true);
                formObject.setEnabled("frm_travel_fare", true);
                //formObject.setTop("frm_travel_fare",730);
                formObject.setVisible("frm_daily_allw", true);
                formObject.setEnabled("frm_daily_allw", true);
                // formObject.setTop("frm_daily_allw",1090);
                formObject.setVisible("frm_convey", true);
                formObject.setEnabled("frm_convey", true);
                //formObject.setTop("frm_convey",1390);
                formObject.setVisible("frm_misc", true);
                formObject.setEnabled("frm_misc", true);
                // formObject.setTop("frm_misc",1680);
                formObject.setVisible("frm_summary", true);
                formObject.setEnabled("frm_summary", true);
                // formObject.setTop("frm_summary",1970);
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                // formObject.setTop("frm_approval",2100);
                formObject.setEnabled("frm_comments", true);
                // formObject.setTop("frm_comments",2200);

                /*//Added By Harinath on 2017/03/21
                 String Grade1 = formObject.getNGValue("Grade");
                 String queryDA = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='DailyAllowance' and grade='" + Grade1 + "'";
                 DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                 formObject.setEnabled("txt_dailyallw_entilperday", false);
                 //Ended By Harinath on 2017/03/21*/
                //Added By Harinath on 2017/03/22
                String Grade1 = formObject.getNGValue("Grade");
                String strDesig = formObject.getNGValue("Designation");
                //Commented by Sivashankar KS on 20-09-2018 starts here
                /*String queryDA = "select claimlimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='DailyAllowance' and grade='" + Grade1 + "'";
                 DBValues_Field(queryDA, "txt_dailyallw_entilperday");
                 formObject.setEnabled("txt_dailyallw_entilperday", false);*/
                //Commented by Sivashankar KS on 20-09-2018 ends here
                //Ended By Harinath on 2017/03/22
                //Added by Sivashankar KS on 20-09-2018 starts here
                /* writeToLog(2, "SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "'", winame);
                 if(!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "'").equalsIgnoreCase(null)
                 && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "'").equalsIgnoreCase("")){  
                
                 DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "'", "txt_dailyallw_entilperday");
                 formObject.setEnabled("txt_dailyallw_entilperday", false);
                    
                 }*/
                String toDate = "";
                if (!formObject.getNGValue("dp_dailyallw_fromdate").equalsIgnoreCase("") && !formObject.getNGValue("dp_dailyallw_todate").equalsIgnoreCase("")) {
//                            ibpsadmin start
                    String strFromDate = formObject.getNGValue("dp_dailyallw_fromdate");
                    String strToDate = formObject.getNGValue("dp_dailyallw_todate");
//                        String toDate = "";
                    toDate = strToDate.split("/")[2] + "-" + strToDate.split("/")[1] + "-" + strToDate.split("/")[0];
                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='Grade' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    if (SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                            || SelectQuery("SELECT Designation FROM EXT_AP_ER_DA_Master  WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                        //Entire grade having citytype DA(Ex: Management Trainee)
                        formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                        formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                        formObject.setEnabled("txt_dailyallw_CityType", true);
                        formObject.setEnabled("txt_dailyallw_City", true);
                        DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock) WHERE '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                        formObject.setEnabled("txt_dailyallw_entilperday", false);
                        formObject.setNGValue("txt_dailyallw_entilperday", "");
                    }

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='CityType' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    //Entire grade having citytype DA(Ex: Managers)
                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                    formObject.setEnabled("txt_dailyallw_CityType", true);
                    formObject.setEnabled("txt_dailyallw_City", true);
                    DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                    formObject.setNGValue("txt_dailyallw_entilperday", "");
                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='LocationBased' AND Grade='" + Grade1 + "' AND Designation='" + strDesig + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    formObject.setNGBackColor("txt_dailyallw_CityType", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_City", Color.white);
                    formObject.setNGBackColor("txt_dailyallw_Loc", Color.white);
                    formObject.setEnabled("txt_dailyallw_CityType", true);
                    formObject.setEnabled("txt_dailyallw_City", true);
                    formObject.setEnabled("txt_dailyallw_Loc", true);
                    DBValues_Combo("SELECT DISTINCT CityType FROM EXT_AP_ER_DA_Master with (nolock)  WHERE   '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_CityType");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);
                    formObject.setNGValue("txt_dailyallw_entilperday", "");

                }
                if (!SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase(null)
                        && !SelectQuery("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil").equalsIgnoreCase("")) {

                    //String queryDA = "SELECT Amount FROM EXT_AP_ER_DA_Master WHERE DAType='Grade' AND Grade='" + Grade1 + "'";
                    DBValues_Field("SELECT Amount FROM EXT_AP_ER_DA_Master WITH (nolock) WHERE DAType='EmployeeCode' AND EmployeeCode='" + formObject.getNGValue("EmployeeCode") + "' AND '" + toDate + "' between validFrom and validUntil", "txt_dailyallw_entilperday");
                    formObject.setEnabled("txt_dailyallw_entilperday", false);

                    formObject.setNGBackColor("txt_dailyallw_CityType", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_City", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_Loc", new Color(255, 255, 255));
                    formObject.setNGBackColor("txt_dailyallw_OthrLoc", new Color(225, 225, 225));
                    formObject.setEnabled("txt_dailyallw_CityType", false);
                    formObject.setEnabled("txt_dailyallw_City", false);
                    formObject.setEnabled("txt_dailyallw_Loc", false);
                    formObject.setEnabled("txt_dailyallw_OthrLoc", false);
                }

                //Added by Sivashankar KS on 20-09-2018 ends here
            } //Modified By Harinath on 2017/03/22
            //else if (strTypeofinvoice.equalsIgnoreCase("Relocation") && (strSubcategory.equalsIgnoreCase("Self Education Scheme"))) {
            else if (strTypeofinvoice.equalsIgnoreCase("Relocation") && (strSubcategory.equalsIgnoreCase("Self Education Scheme"))) {
                //Ended By Harinath on 2017/03/22  
                //DBValues_Combo("SELECT ACCRef FROM EXT_AP_ER_GLcode", "cb_entschm_accref");
                //DBValues_Combo("SELECT ACCRef FROM EXT_AP_ER_GLcode WITH (NOLOCK) where ACCRef='EMPLOYEE WELFARE EXPENSES' ORDER BY ACCRef", "cb_entschm_accref");

                //Modified for fetching GLCode based on CompanyCode on 03-SEP-20 
                String strCompanyCode = formObject.getNGValue("CompanyCode");
                String qry = "SELECT DISTINCT ACCRef FROM EXT_AP_GLcode WITH (NOLOCK) where ACCRef = 'EMPLOYEE WELFARE EXPENSES' and CompanyCode ='" + strCompanyCode + "' ORDER BY ACCRef";
                DBValues_Combo(qry, "cb_entschm_accref");
                //End on 03-SEP-20
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                formObject.setVisible("frm_invoice_details", true);
                formObject.setVisible("frm_ent_scheme", true);
                formObject.setEnabled("frm_ent_scheme", true);
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                formObject.setEnabled("frm_comments", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_ent_scheme", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",formObject.getHeight("frm_ent_scheme")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_ent_scheme",490);
                //formObject.setTop("frm_approval",780);
                //formObject.setTop("frm_comments",880);

            } else if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && (strSubcategory.equalsIgnoreCase("Entertainment"))
                    || (strSubcategory.equalsIgnoreCase("Others") || (strSubcategory.equalsIgnoreCase("GIFT & COMPLIMENTARY")))) {
                formObject.setVisible("frm_invoice_details", true);
                if (strSubcategory.equalsIgnoreCase("Entertainment")) {
                    formObject.addItem("cb_entschm_accref", "ENTERTAINMENT EXPENDITURE");
                } else if (strSubcategory.equalsIgnoreCase("GIFT & COMPLIMENTARY")) {
                    formObject.addItem("cb_entschm_accref", "GIFT & COMPLIMENTARY");
                } else {
                    //DBValues_Combo("SELECT ACCRef FROM EXT_AP_ER_GLcode with(nolock) where ACCRef NOT IN('ENTERTAINMENT EXPENDITURE','GIFT & COMPLIMENTARY') ORDER BY ACCRef", "cb_entschm_accref");

                    //Modified for fetching GLCode based on CompanyCode on 03-SEP-20 
                    String strCompanyCode = formObject.getNGValue("CompanyCode");
                    String qry = "SELECT DISTINCT ACCRef FROM EXT_AP_GLcode with(nolock) where ACCRef NOT IN('ENTERTAINMENT EXPENDITURE','GIFT & COMPLIMENTARY') AND (ClaimType IS NULL OR ClaimType = 'Others') and CompanyCode = '" + strCompanyCode + "' ORDER BY ACCRef";
                    DBValues_Combo(qry, "cb_entschm_accref");
                    //End on 03-SEP-20
                }
                //DeclChange
                String comCode = formObject.getNGValue("CompanyCode");
                writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setVisible("frm_Decl", true);
                }
                formObject.setVisible("frm_ent_scheme", true);
                // formObject.setTop("frm_ent_scheme",490);
                formObject.setEnabled("frm_ent_scheme", true);
                formObject.setEnabled("frm_approval", false);
                formObject.setVisible("frm_approval", false);
                formObject.setEnabled("frm_comments", true);
                formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_invoice_details", formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                formObject.setTop("frm_ent_scheme", formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                // formObject.setTop("frm_approval",formObject.getHeight("frm_ent_scheme")+10+formObject.getHeight("frm_invoice_details")+10+formObject.getHeight("frm_tran_details2")+10+formObject.getHeight("frm_heading1") + 20 );
                formObject.setTop("frm_comments", formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");
                if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                    formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                    formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
                }
                formObject.setHeight("Main", formObject.getHeight("frm_comments") + 40 + formObject.getHeight("frm_ent_scheme") + 10 + formObject.getHeight("frm_invoice_details") + 10 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_heading1") + 20);
                //formObject.setTop("frm_approval",780);
                //formObject.setTop("frm_comments",880);

            }
        }

    }

    //public static List<List<String>> getListViewValueInList(FormReference formObject, String fieldName) {
    public List<List<String>> getListViewValueInList(FormReference formObject, String fieldName) {
        String listXML = formObject.getNGListView(fieldName);
        return new LineItemParser().getLineItems(listXML);
    }

    public List<List<String>> getListViewValueInList2(FormReference formObject, String fieldName) {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String listXML = formObject.getNGListView(fieldName);
        writeToLog(2, "list_PO listXML=" + listXML, winame);
        return new LineItemParser().getLineItems(listXML);
    }

    public String[] getRowValue(FormReference formObject, String listviewName, int row) {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String listViewValues = formObject.getNGValueLVWAT(listviewName, row);
        writeToLog(2, "listViewValues:" + listViewValues, winame);
        if (listViewValues.startsWith("<ListItem ")) {
            listViewValues = "<ListItem>" + listViewValues.substring(listViewValues.indexOf("<SubItem>"));
        }
        writeToLog(2, "listViewValues ::" + listViewValues, winame);
        listViewValues = listViewValues.replace("<ListItem>", "").replace("</ListItem>", "").replaceAll("<SubItem>", " ");
        listViewValues = listViewValues.replaceAll("</SubItem>", "~~~");
        String[] tempArrlist = listViewValues.split("~~~");
        return tempArrlist;
    }

    public boolean btnMoveup() throws Exception {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
//----------------------------------------------------------------------------------

        writeToLog(2, "Inside btnMoveup.........>>>>>>>>>>>", winame);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        int iSelectCount = formObject.getSelectedIndex("list_po");
        writeToLog(2, "iSelectCount==" + iSelectCount, winame);

        List<List<String>> ControlObj = getListViewValueInList(formObject, "list_po");
        writeToLog(2, "ControlObj==" + ControlObj, winame);

        //for (Integer i = 0; i < ControlObj.size(); i++) {                             
        String sValue0 = ControlObj.get(iSelectCount).get(0);
        String sValue1 = ControlObj.get(iSelectCount).get(1);
        String sValue2 = ControlObj.get(iSelectCount).get(2);
        String sValue3 = ControlObj.get(iSelectCount).get(3);
        String sValue4 = ControlObj.get(iSelectCount).get(4);
        String sValue5 = ControlObj.get(iSelectCount).get(5);
        String sValue6 = ControlObj.get(iSelectCount).get(6);
        String sValue7 = ControlObj.get(iSelectCount).get(7);
        String sValue8 = ControlObj.get(iSelectCount).get(8);
        String sValue9 = ControlObj.get(iSelectCount).get(9);
        String sValue10 = ControlObj.get(iSelectCount).get(10);
        String sValue11 = ControlObj.get(iSelectCount).get(11);
        String sValue12 = ControlObj.get(iSelectCount).get(12);
        String sValue13 = ControlObj.get(iSelectCount).get(13);
        String sValue14 = ControlObj.get(iSelectCount).get(14);
        String sValue15 = ControlObj.get(iSelectCount).get(15);
        String sValue16 = ControlObj.get(iSelectCount).get(16);
        String sValue17 = ControlObj.get(iSelectCount).get(17);
        String sValue18 = ControlObj.get(iSelectCount).get(18);
        String sValue19 = ControlObj.get(iSelectCount).get(19);
        String sValue20 = ControlObj.get(iSelectCount).get(20);
        String sValue21 = ControlObj.get(iSelectCount).get(21);

        writeToLog(2, "sValue0==" + sValue0, winame);
        writeToLog(2, "sValue1==" + sValue1, winame);
        writeToLog(2, "sValue2==" + sValue2, winame);
        writeToLog(2, "sValue3==" + sValue3, winame);
        writeToLog(2, "sValue4==" + sValue4, winame);
        writeToLog(2, "sValue5==" + sValue5, winame);
        writeToLog(2, "sValue6==" + sValue6, winame);
        writeToLog(2, "sValue7==" + sValue7, winame);
        writeToLog(2, "sValue8==" + sValue8, winame);
        writeToLog(2, "sValue9==" + sValue9, winame);
        writeToLog(2, "sValue10==" + sValue10, winame);
        writeToLog(2, "sValue11==" + sValue11, winame);
//                                       System.out.println("sValue0=="+sValue0);
//                                       System.out.println("sValue1=="+sValue1);
//                                       System.out.println("sValue2=="+sValue2);
//                                       System.out.println("sValue3=="+sValue3);
//                                       System.out.println("sValue4=="+sValue4);
//                                       System.out.println("sValue5=="+sValue5);
//                                       System.out.println("sValue6=="+sValue6);
//                                       System.out.println("sValue7=="+sValue7);
//                                       System.out.println("sValue8=="+sValue8);
//                                       System.out.println("sValue9=="+sValue9);
//                                       System.out.println("sValue10=="+sValue10);
//                                       System.out.println("sValue11=="+sValue11);
        //} 
        ListViewItems LVI = new ListViewItems();
        LVI.addColumnvalue(sValue0);
        LVI.addColumnvalue(sValue1);
        LVI.addColumnvalue(sValue2);
        LVI.addColumnvalue(sValue3);
        LVI.addColumnvalue(sValue4);
        LVI.addColumnvalue(sValue5);
        LVI.addColumnvalue(sValue6);
        LVI.addColumnvalue(sValue7);
        LVI.addColumnvalue(sValue8);
        LVI.addColumnvalue(sValue9);
        LVI.addColumnvalue(sValue10);
        LVI.addColumnvalue(sValue11);
        LVI.addColumnvalue(sValue12);
        LVI.addColumnvalue(sValue13);
        LVI.addColumnvalue(sValue14);
        LVI.addColumnvalue(sValue15);
        LVI.addColumnvalue(sValue16);
        LVI.addColumnvalue(sValue17);
        LVI.addColumnvalue(sValue18);
        LVI.addColumnvalue(sValue19);
        LVI.addColumnvalue(sValue20);
        LVI.addColumnvalue(sValue21);
        try {
            formObject.removeItem("list_po", iSelectCount);
        } catch (Exception ex) {
            //Logger.getLogger(Parking.class.getName()).log(Level.SEVERE, null, ex);
            writeToLog(3, "Error in Removing NGAddListItem @btn_po_down", winame);

        }
        writeToLog(2, "flag true==" + LVI.getXML(), winame);

        formObject.NGAddListItem("list_po_invoice", LVI.getXML());
        return true;
    }

    public boolean btnMovedown() throws Exception {
//----------------------------------------------------------------------------------
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        writeToLog(2, "Inside btnMovedown...............>>>>>>>", winame);

        FormReference formObject = FormContext.getCurrentInstance().getFormReference();

        int iSelectCount = formObject.getSelectedIndex("list_po_invoice");

        writeToLog(2, "iSelectCount==" + iSelectCount, winame);
        List<List<String>> ControlObj = getListViewValueInList(formObject, "list_po_invoice");

        writeToLog(2, "ControlObj==" + ControlObj, winame);

        String sValue0 = ControlObj.get(iSelectCount).get(0);
        String sValue1 = ControlObj.get(iSelectCount).get(1);
        String sValue2 = ControlObj.get(iSelectCount).get(2);
        String sValue3 = ControlObj.get(iSelectCount).get(3);
        String sValue4 = ControlObj.get(iSelectCount).get(4);
        String sValue5 = ControlObj.get(iSelectCount).get(5);
        String sValue6 = ControlObj.get(iSelectCount).get(6);
        String sValue7 = ControlObj.get(iSelectCount).get(7);
        String sValue8 = ControlObj.get(iSelectCount).get(8);
        String sValue9 = ControlObj.get(iSelectCount).get(9);
        String sValue10 = ControlObj.get(iSelectCount).get(10);
        String sValue11 = ControlObj.get(iSelectCount).get(11);
        String sValue12 = ControlObj.get(iSelectCount).get(12);
        String sValue13 = ControlObj.get(iSelectCount).get(13);
        String sValue14 = ControlObj.get(iSelectCount).get(14);
        String sValue15 = ControlObj.get(iSelectCount).get(15);
        String sValue16 = ControlObj.get(iSelectCount).get(16);
        String sValue17 = ControlObj.get(iSelectCount).get(17);
        String sValue18 = ControlObj.get(iSelectCount).get(18);
        String sValue19 = ControlObj.get(iSelectCount).get(19);
        String sValue20 = ControlObj.get(iSelectCount).get(20);
        String sValue21 = ControlObj.get(iSelectCount).get(21);

        writeToLog(2, "sValue0==" + sValue0, winame);
        writeToLog(2, "sValue1==" + sValue1, winame);
        writeToLog(2, "sValue2==" + sValue2, winame);
        writeToLog(2, "sValue3==" + sValue3, winame);
        writeToLog(2, "sValue4==" + sValue4, winame);
        writeToLog(2, "sValue5==" + sValue5, winame);
        writeToLog(2, "sValue6==" + sValue6, winame);
        writeToLog(2, "sValue7==" + sValue7, winame);
        writeToLog(2, "sValue8==" + sValue8, winame);
        writeToLog(2, "sValue9==" + sValue9, winame);
        writeToLog(2, "sValue10==" + sValue10, winame);
        writeToLog(2, "sValue11==" + sValue11, winame);

//                                       System.out.println("sValue0=="+sValue0);
//                                       System.out.println("sValue1=="+sValue1);
//                                       System.out.println("sValue2=="+sValue2);
//                                       System.out.println("sValue3=="+sValue3);
//                                       System.out.println("sValue4=="+sValue4);
//                                       System.out.println("sValue5=="+sValue5);
//                                       System.out.println("sValue6=="+sValue6);
//                                       System.out.println("sValue7=="+sValue7);
//                                       System.out.println("sValue8=="+sValue8);
//                                       System.out.println("sValue9=="+sValue9);
//                                       System.out.println("sValue10=="+sValue10);
//                                       System.out.println("sValue11=="+sValue11);
        //} 
        ListViewItems LVI = new ListViewItems();
        LVI.addColumnvalue(sValue0);
        LVI.addColumnvalue(sValue1);
        LVI.addColumnvalue(sValue2);
        LVI.addColumnvalue(sValue3);
        LVI.addColumnvalue(sValue4);
        LVI.addColumnvalue(sValue5);
        LVI.addColumnvalue(sValue6);
        LVI.addColumnvalue(sValue7);
        LVI.addColumnvalue(sValue8);
        LVI.addColumnvalue(sValue9);
        LVI.addColumnvalue(sValue10);
        LVI.addColumnvalue(sValue11);
        LVI.addColumnvalue(sValue12);
        LVI.addColumnvalue(sValue13);
        LVI.addColumnvalue(sValue14);
        LVI.addColumnvalue(sValue15);
        LVI.addColumnvalue(sValue16);
        LVI.addColumnvalue(sValue17);
        LVI.addColumnvalue(sValue18);
        LVI.addColumnvalue(sValue19);
        LVI.addColumnvalue(sValue20);
        LVI.addColumnvalue(sValue21);
        try {
            formObject.removeItem("list_po_invoice", iSelectCount);
        } catch (Exception ex) {
            //Logger.getLogger(Parking.class.getName()).log(Level.SEVERE, null, ex);
            writeToLog(3, "Error in Removing NGAddListItem @btn_po_up", winame);

        }
        writeToLog(2, "flag true=" + LVI.getXML(), winame);

        formObject.NGAddListItem("list_po", LVI.getXML());
        return true;
    }

    public String appendzeros(String strControlName) {
        strControlName = strControlName.trim();
        if (strControlName.length() <= 9) {
            int len = 10 - strControlName.length();
            for (int i = 0; i < len; i++) {
                strControlName = "0" + strControlName;
            }
        }
        return strControlName;
    }

    public String appendzerosN(String strControlName, int maxlength) {
        strControlName = strControlName.trim();
        if (strControlName.length() < maxlength) {
            int len = maxlength - strControlName.length();
            for (int i = 0; i < len; i++) {
                strControlName = "0" + strControlName;
            }
        }
        return strControlName;
    }

    public String appendzeros3(String strControlName) {
        strControlName = strControlName.trim();
        if (strControlName.length() <= 2) {
            int len = 3 - strControlName.length();
            for (int i = 0; i < len; i++) {
                strControlName = "0" + strControlName;
            }
        }
        return strControlName;
    }

    public String appendzero(int intPO_NO, String strControlName) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        int intLength = formObject.getNGValue(strControlName).length();
        String strControValue = formObject.getNGValue(strControlName);
        if (intLength == 1) {
            strControValue = "000000000" + strControValue;
        } else if (intLength == 2) {
            strControValue = "00000000" + strControValue;
        } else if (intLength == 3) {
            strControValue = "0000000" + strControValue;
        } else if (intLength == 4) {
            strControValue = "000000" + strControValue;
        } else if (intLength == 5) {
            strControValue = "00000" + strControValue;
        } else if (intLength == 6) {
            strControValue = "0000" + strControValue;
        } else if (intLength == 7) {
            strControValue = "000" + strControValue;
        } else if (intLength == 8) {
            strControValue = "00" + strControValue;
        } else if (intLength == 9) {
            strControValue = "0" + strControValue;
        }
        //formObject.setNGValue(strControlName, strControValue);
        return strControValue;
    }

// Added by Deva for Amount Auto populates
    public void AmountCalc() {
        //15/12/2016 Auto populating the TotalAmount from ListView
        float Total;

        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1");
        String winame = formConfig.getConfigElement("ProcessInstanceId");

        if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")
                && (strSubcategory.equalsIgnoreCase("Entertainment")
                || strSubcategory.equalsIgnoreCase("Others") || strSubcategory.equalsIgnoreCase("GIFT & COMPLIMENTARY"))) {
            Total = (float) listViewColumnSum("list_Entertain", 5);
            formObject.setNGValue("TotalAmount", Total);
        } else if (strTypeofinvoice.equalsIgnoreCase("Employee Advances")) {
            //Total = Float.parseFloat(formObject.getNGValue("ClaimedAmount"));
            formObject.setNGValue("TotalAmount", formObject.getNGValue("ClaimedAmount"));
        } //Modified By Harinath on 2017/03/22
        /*else if (strTypeofinvoice.equalsIgnoreCase("Relocation") && 
         (strSubcategory.equalsIgnoreCase("Self Education Scheme")))*/ else if (strTypeofinvoice.equalsIgnoreCase("Relocation")
                && (strSubcategory.equalsIgnoreCase("Self Education Scheme"))) //Ended By Harinath on 2017/03/22    
        {
            Total = (float) listViewColumnSum("list_Entertain", 5);
            formObject.setNGValue("TotalAmount", Total);
        } else if (strTypeofinvoice.equalsIgnoreCase("Relocation")
                && (strSubcategory.equalsIgnoreCase("Relocation-TravelExpense-Own Vehicle"))) {

            //Added By Harinatha on 2017/07/03
            for (int i = 0; i < formObject.getLVWRowCount("list_travel"); i++) {
                if (formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase("") || formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase(null)) {
                    fm = new FacesMessage("Please update paid by for all the travels entered in Travel Fare template... ", "");
                    throw new ValidatorException(fm);
                }
            }
            //Ended By Harinatha on 2017/07/03

            Total = (float) listViewColumnIgnorePaidBy("list_travel", 9, 8);
            formObject.setNGValue("TicketExpense", listViewColumnIgnorePaidBy("list_travel", 9, 8));
            Total = (float) (Total + listViewColumnSum("list_daily", 5));
            formObject.setNGValue("DailyAllowance", listViewColumnSum("list_daily", 5));
            Total = (float) (Total + listViewColumnSum("list_convey", 3));
            formObject.setNGValue("Conveyance", listViewColumnSum("list_convey", 3));
            Total = (float) (Total + listViewColumnSum("list_misc", 1));
            formObject.setNGValue("Miscellaneous", listViewColumnSum("list_misc", 1));
            formObject.setNGValue("TotalAmount", Total);

        } else if ((strTypeofinvoice.equalsIgnoreCase("Relocation"))
                && (strSubcategory.equalsIgnoreCase("Out of Pocket Expense")
                || (strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")))) {

            //Added By Harinatha on 2017/07/03
            for (int i = 0; i < formObject.getLVWRowCount("list_travel"); i++) {
                if (formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase("") || formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase(null)) {
                    fm = new FacesMessage("Please update paid by for all the travels entered in Travel Fare template... ", "");
                    throw new ValidatorException(fm);
                }
            }
            //Ended By Harinatha on 2017/07/03

            //Modified By Harinath on 2017/08/18 NOTE : To add hotel fares template in Relocation-TravelExpense subcategory  
            Total = (float) listViewColumnIgnorePaidBy("list_travel", 9, 8);
            formObject.setNGValue("TicketExpense", listViewColumnIgnorePaidBy("list_travel", 9, 8));
            if (strSubcategory.equalsIgnoreCase("Relocation-Travel Expense")) {
                Total = (float) (Total + listViewColumnIgnorePaidBy("list_hotel", 15, 2));
                formObject.setNGValue("HotelExpense", listViewColumnIgnorePaidBy("list_hotel", 15, 2));
            }
            Total = (float) (Total + listViewColumnSum("list_daily", 5));
            formObject.setNGValue("DailyAllowance", listViewColumnSum("list_daily", 5));
            Total = (float) (Total + listViewColumnSum("list_convey", 3));
            formObject.setNGValue("Conveyance", listViewColumnSum("list_convey", 3));
            Total = (float) (Total + listViewColumnSum("list_misc", 1));
            formObject.setNGValue("Miscellaneous", listViewColumnSum("list_misc", 1));
            formObject.setNGValue("TotalAmount", Total);
            //Ended By Harinath on 2017/08/18
        } else if (strSubcategory.equalsIgnoreCase("Look and See Visit")) {

            //Added By Harinatha on 2017/07/03
            for (int i = 0; i < formObject.getLVWRowCount("list_travel"); i++) {
                if (formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase("") || formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase(null)) {
                    fm = new FacesMessage("Please update paid by for all the travels entered in Travel Fare template... ", "");
                    throw new ValidatorException(fm);
                }
            }
            //Ended By Harinatha on 2017/07/03

            Total = (float) listViewColumnIgnorePaidBy("list_travel", 9, 8);
            formObject.setNGValue("TicketExpense", listViewColumnIgnorePaidBy("list_travel", 9, 8));
            Total = (float) (Total + listViewColumnIgnorePaidBy("list_hotel", 15, 2));
            formObject.setNGValue("HotelExpense", listViewColumnIgnorePaidBy("list_hotel", 15, 2));//Modified by Harinath on 2017/03/20
            //Modified by Harinath on 2017/03/20
            //Total = (float) (Total + listViewColumnSum("list_daily", 5));
            //formObject.setNGValue("DailyAllowance", listViewColumnSum("list_daily", 5));
            //Ended by Harinath on 2017/03/20            Total = (float) (Total + listViewColumnSum("list_convey", 3));
            Total = (float) (Total + listViewColumnSum("list_convey", 3));
            formObject.setNGValue("Conveyance", listViewColumnSum("list_convey", 3));
            Total = (float) (Total + listViewColumnSum("list_misc", 1));
            formObject.setNGValue("Miscellaneous", listViewColumnSum("list_misc", 1));
            formObject.setNGValue("TotalAmount", Total);
        } else if (strSubcategory.equalsIgnoreCase("Joining Expense")) {

            //Added By Harinatha on 2017/07/03
            for (int i = 0; i < formObject.getLVWRowCount("list_travel"); i++) {
                if (formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase("") || formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase(null)) {
                    fm = new FacesMessage("Please update paid by for all the travels entered in Travel Fare template... ", "");
                    throw new ValidatorException(fm);
                }
            }
            //Ended By Harinatha on 2017/07/03

            Total = (float) listViewColumnIgnorePaidBy("list_travel", 9, 8);
            formObject.setNGValue("TicketExpense", listViewColumnIgnorePaidBy("list_travel", 9, 8));
            Total = (float) (Total + listViewColumnIgnorePaidBy("list_hotel", 15, 2));
            formObject.setNGValue("HotelExpense", listViewColumnIgnorePaidBy("list_hotel", 15, 2));
            Total = (float) (Total + listViewColumnSum("list_convey", 3));
            formObject.setNGValue("Conveyance", listViewColumnSum("list_convey", 3));
            Total = (float) (Total + listViewColumnSum("list_misc", 1));
            formObject.setNGValue("Miscellaneous", listViewColumnSum("list_misc", 1));
            Total = (float) (Total + listViewColumnSum("list_medical", 1));
            formObject.setNGValue("MedicalExpense", listViewColumnSum("list_medical", 1));
            formObject.setNGValue("TotalAmount", Total);

        } else if (strSubcategory.equalsIgnoreCase("Brokerage Fee")) {
            Total = Float.parseFloat(formObject.getNGValue("Amount"));
            formObject.setNGValue("TotalAmount", Total);
        } else if (strSubcategory.equalsIgnoreCase("Travel Expense")) {

            //Added By Harinatha on 2017/07/03
            for (int i = 0; i < formObject.getLVWRowCount("list_travel"); i++) {
                if (formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase("") || formObject.getNGValue("list_travel", i, 8).equalsIgnoreCase(null)) {
                    fm = new FacesMessage("Please update paid by for all the travels entered in Travel Fare template... ", "");
                    throw new ValidatorException(fm);
                }
            }
            //Ended By Harinatha on 2017/07/03

//            Total = (float) listViewColumnSum("list_travel", 9);
//            formObject.setNGValue("TicketExpense", listViewColumnSum("list_travel", 9));
            Total = (float) listViewColumnIgnorePaidBy("list_travel", 9, 8);
            formObject.setNGValue("TicketExpense", listViewColumnIgnorePaidBy("list_travel", 9, 8));
            Total = (float) (Total + listViewColumnIgnorePaidBy("list_hotel", 15, 2));
            formObject.setNGValue("HotelExpense", listViewColumnIgnorePaidBy("list_hotel", 15, 2));
            Total = (float) (Total + listViewColumnSum("list_daily", 5));
            formObject.setNGValue("DailyAllowance", listViewColumnSum("list_daily", 5));
            Total = (float) (Total + listViewColumnSum("list_convey", 3));
            formObject.setNGValue("Conveyance", listViewColumnSum("list_convey", 3));
            Total = (float) (Total + listViewColumnSum("list_misc", 1));
            formObject.setNGValue("Miscellaneous", listViewColumnSum("list_misc", 1));
            //Added by SAndeepKn on 10Jan2020 for ASFI and SFIC changes - Start
            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")
                    || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                Total = (float) (Total + listViewColumnSum("list_OtherExpenses", 10));
                formObject.setNGValue("OtherExpense", listViewColumnSum("list_OtherExpenses", 10));
            }
            //Added by SAndeepKn on 10Jan2020 for ASFI and SFIC changes - End            
            formObject.setNGValue("TotalAmount", Total);
        } else if (strSubcategory.equalsIgnoreCase("Mobile Re-Imbursements")) {
            if ((formObject.getNGValue("BillValueLessTax").equalsIgnoreCase("")
                    || formObject.getNGValue("ValueOfPersonalCalls").equalsIgnoreCase("")
                    //|| formObject.getNGValue("ServiceTax_BillValue").equalsIgnoreCase("")
                    //|| formObject.getNGValue("ServiceTax_ValueOfPersonalCalls").equalsIgnoreCase(""))
                    && (formObject.getNGValue("BillValueLessTax").equalsIgnoreCase(null)
                    || formObject.getNGValue("ValueOfPersonalCalls").equalsIgnoreCase(null) //|| formObject.getNGValue("ServiceTax_BillValue").equalsIgnoreCase(null)
                    //|| formObject.getNGValue("ServiceTax_ValueOfPersonalCalls").equalsIgnoreCase(null)
                    ))) {
                throw new ValidatorException(new FacesMessage("Please Enter BillValueLessTax", "BillValueLessTax"));
            } else {

                try {

                    Float billval = 0.00F;
                    Float perCall = 0.00F;
                    Float serTaxBill = 0.00F;
                    Float serTaxPerCall = 0.00F;
                    Float TotalBill = 0.00F;
                    String strBillVal = formObject.getNGValue("BillValueLessTax");
                    String strPerCall = formObject.getNGValue("ValueOfPersonalCalls");
                    writeToLog(2, "FOCUS_LOST:strBillVal:" + strBillVal, winame);
                    writeToLog(2, "FOCUS_LOST:strPerCall:" + strPerCall, winame);
                    formObject.setNGValue("TotalAmount", "");

                    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

                    if (!formObject.getNGValue("BillValueLessTax").equalsIgnoreCase("")) {
                        billval = Float.parseFloat(formObject.getNGValue("BillValueLessTax"));
                        //if (billval>0.0) {
                        writeToLog(2, "FOCUS_LOST:billval>0", winame);
                        //Modified By Harinath on 2017/06/30
                        //formObject.setNGValue("ServiceTax_BillValue", billval * 0.15);
                        if (dateFormat.parse(formObject.getNGValue("BillDate")).after(dateFormat.parse("01/07/2017")) || dateFormat.parse(formObject.getNGValue("BillDate")).equals(dateFormat.parse("01/07/2017"))) {
                            writeToLog(2, "Bill Date is after 01/07/2017 ::: 18%", winame);
                            //Added bysandeepkn on 10Jan2020 for ASFI ans SFIC changes -start
                            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                                formObject.setNGValue("ServiceTax_BillValue", billval * 0.05);
                            } else {
                                formObject.setNGValue("ServiceTax_BillValue", billval * 0.18);
                            }//Added bysandeepkn on 10Jan2020 for ASFI ans SFIC changes -End
                            //formObject.setNGValue("ServiceTax_BillValue", billval * 0.18);
                        } else {
                            writeToLog(2, "Bill Date is before 01/07/2017 ::: 15%", winame);
                            //Added bysandeepkn on 10Jan2020 for ASFI ans SFIC changes -start
                            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                                formObject.setNGValue("ServiceTax_BillValue", billval * 0.05);
                            } else {
                                formObject.setNGValue("ServiceTax_BillValue", billval * 0.15);
                            }//Added bysandeepkn on 10Jan2020 for ASFI ans SFIC changes -End
                            // formObject.setNGValue("ServiceTax_BillValue", billval * 0.15);
                        }
                        //Ended By Harinath on 2017/06/30
                    } else {
                        formObject.setNGValue("ServiceTax_BillValue", "0.00");
                    }

                    if (!formObject.getNGValue("ValueOfPersonalCalls").equalsIgnoreCase("")) {
                        perCall = Float.parseFloat(formObject.getNGValue("ValueOfPersonalCalls"));
                        //if (perCall>0.0) {
                        writeToLog(2, "FOCUS_LOST:perCall>0", winame);
                        //Modified By Harinath on 2017/06/30
                        //formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", perCall * 0.15);
                        if (dateFormat.parse(formObject.getNGValue("BillDate")).after(dateFormat.parse("01/07/2017")) || dateFormat.parse(formObject.getNGValue("BillDate")).equals(dateFormat.parse("01/07/2017"))) {
                            writeToLog(2, "Bill Date is after 01/07/2017 ::: 18%", winame);
                            //Added bysandeepkn on 10Jan2020 for ASFI ans SFIC changes -Start
                            //Added ASFI & SFIC company codes calculation logic on 15-Nov-2019
                            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                                //formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", perCall * 0.05);//Commented and added below line by sandeep.n on 09Mar2020 as per Syed calculation
                                formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", "0.00");
                                formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(225, 225, 225));
                            } else {
                                formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", perCall * 0.18);
                            }
                            //Added bysandeepkn on 10Jan2020 for ASFI ans SFIC changes -End
                            // formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", perCall * 0.18);
                        } else {
                            writeToLog(2, "Bill Date is before 01/07/2017 ::: 15%", winame);
                            //Added bysandeepkn on 10Jan2020 for ASFI ans SFIC changes -Start
                            if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                                //formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", perCall * 0.05);//Commented and added below line by sandeep.n on 09Mar2020 as per Syed calculation
                                formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", "0.00");
                                formObject.setNGBackColor("ServiceTax_ValueOfPersonalCalls", new Color(225, 225, 225));
                            } else {
                                formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", perCall * 0.15);
                            }
                            //Added bysandeepkn on 10Jan2020 for ASFI ans SFIC changes -End
                            //formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", perCall * 0.15);
                        }
                        //Ended By Harinath on 2017/06/30
                    } else {
                        formObject.setNGValue("ServiceTax_ValueOfPersonalCalls", "0.00");
                    }

                    billval = Float.parseFloat(formObject.getNGValue("BillValueLessTax"));
                    perCall = Float.parseFloat(formObject.getNGValue("ValueOfPersonalCalls"));
                    serTaxBill = Float.parseFloat(formObject.getNGValue("ServiceTax_BillValue"));
                    serTaxPerCall = Float.parseFloat(formObject.getNGValue("ServiceTax_ValueOfPersonalCalls"));
                    //Added by SandeepKn on 09Mra2020 as per SYED --start
                    if (formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") || formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                        TotalBill = billval + serTaxBill;
                    } else {
                        TotalBill = billval - perCall + (serTaxBill - serTaxPerCall);
                    }
                    //Added by SandeepKn on 09Mra2020 as per SYED --End
                    //TotalBill = billval - perCall + (serTaxBill - serTaxPerCall);
                    formObject.setNGValue("TotalAmount", TotalBill);

                    writeToLog(2, "billval:" + billval, winame);
                    Float billval2 = 0.0F;
                    billval2 = Float.parseFloat(formObject.getNGValue("BillValueLessTax"));
                    writeToLog(2, "billval2:" + billval2, winame);
                } catch (Exception e) {
                    writeToLog(1, "Exception occred while calculating total mobile amount :: " + e, winame);
                    //throw new ValidatorException(new FacesMessage("Exception occred while calculating total mobile amount :: " + e, "TotalAmount"));
                    throw new ValidatorException(new FacesMessage("Please check Bill Date or Bill value less Service Tax or Value of Personal Calls is entered...", "BillDate"));
                }
            }

        } /*else if (strSubcategory.equalsIgnoreCase("Mobile Re-Imbursements")) 
         {
         if ((formObject.getNGValue("BillValueLessTax").equalsIgnoreCase("")
         || formObject.getNGValue("ValueOfPersonalCalls").equalsIgnoreCase("")
         || formObject.getNGValue("ServiceTax_BillValue").equalsIgnoreCase("")
         || formObject.getNGValue("ServiceTax_ValueOfPersonalCalls").equalsIgnoreCase(""))
         && (formObject.getNGValue("BillValueLessTax").equalsIgnoreCase(null)
         || formObject.getNGValue("ValueOfPersonalCalls").equalsIgnoreCase(null)
         || formObject.getNGValue("ServiceTax_BillValue").equalsIgnoreCase(null)
         || formObject.getNGValue("ServiceTax_ValueOfPersonalCalls").equalsIgnoreCase(null))) 
         {
         throw new ValidatorException(new FacesMessage("Please Enter BillValueLessTax", "BillValueLessTax"));
         } 
         else 
         {
         Float billval = 0.00F;
         Float perCall = 0.00F;
         Float serTaxBill = 0.00F;
         Float serTaxPerCall = 0.00F;
         Float TotalBill = 0.00F;
         billval = Float.parseFloat(formObject.getNGValue("BillValueLessTax"));
         perCall = Float.parseFloat(formObject.getNGValue("ValueOfPersonalCalls"));
         serTaxBill = Float.parseFloat(formObject.getNGValue("ServiceTax_BillValue"));
         serTaxPerCall = Float.parseFloat(formObject.getNGValue("ServiceTax_ValueOfPersonalCalls"));
         TotalBill = billval - perCall + (serTaxBill - serTaxPerCall);
         formObject.setNGValue("TotalAmount", TotalBill);
         }

         }*/ else if (strSubcategory.equalsIgnoreCase("Moving of Personal Effects")) {
            Float moving = 0.00F;
            if ((formObject.getNGValue("RoadtaxYN")).equalsIgnoreCase("Yes")) {
                moving = (moving) + (Float.parseFloat(formObject.getNGValue("RoadTax")));
            }
            if ((formObject.getNGValue("LossYN")).equalsIgnoreCase("Yes")) {
                moving = (moving) + (Float.parseFloat(formObject.getNGValue("LossOnPreClosureLease")));
            }
            if ((formObject.getNGValue("OctroiYN")).equalsIgnoreCase("Yes")) {
                moving = (moving) + (Float.parseFloat(formObject.getNGValue("OctroiPay")));
            }
            if ((formObject.getNGValue("PackYN")).equalsIgnoreCase("Yes")) {
                moving = (moving) + (Float.parseFloat(formObject.getNGValue("PackMove")));
            }
            if ((formObject.getNGValue("SchlfeeYN")).equalsIgnoreCase("Yes")) {
                moving = (moving) + (Float.parseFloat(formObject.getNGValue("SchlfeeClaimamnt")));
            }
            formObject.setNGValue("TotalAmount", moving);
        }

    }

    public void TravelCab_Frames() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");

        formObject.setVisible("lbl_er", false);
        formObject.setVisible("lbl_vp", false);
        formObject.setVisible("frm_salary_adv", false);
        formObject.setVisible("frm_ent_scheme", false);
        formObject.setVisible("frm_mobile_claims", false);
        formObject.setVisible("frm_moving_personal_effects", false);
        formObject.setVisible("frm_brokage_fees", false);
        formObject.setVisible("frm_summary", false);
        formObject.setVisible("frm_family_info", false);
        formObject.setVisible("frm_travel_fare", false);
        formObject.setVisible("frm_hotel_fare", false);
        formObject.setVisible("frm_daily_allw", false);
        formObject.setVisible("frm_convey", false);
        formObject.setVisible("frm_misc", false);
        formObject.setVisible("frm_medical_expense", false);
        formObject.setVisible("frm_nonpo_line", false);
        formObject.setVisible("frm_po_line", false);
        formObject.setVisible("frm_approval", false);
        formObject.setVisible("btn_Reject", false);
        formObject.setVisible("btn_Travel", false);
        formObject.setVisible("btn_Cab", false);
        formObject.setVisible("btn_Approve", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Rescan", false);
        formObject.setVisible("frm_invoice_details", false);
        formObject.setVisible("frm_venddtl_po", false);
        formObject.setVisible("frm_accndtl_po", false);
        formObject.setVisible("frm_parkdtl_po", false);
        formObject.setVisible("frm_trnsdtl_po", true);
        formObject.setVisible("frm_invdtl_po", true);
        formObject.setVisible("frm_comments", true);

        formObject.setNGValue("PONumber", "");
        formObject.setNGValue("PurchaseGrp", "");
        formObject.setNGValue("MMDocNo", "");
        formObject.setEnabled("PONumber", false);
        formObject.setEnabled("PurchaseGrp", false);
        formObject.setEnabled("MMDocNo", false);
        formObject.setNGBackColor("PONumber", new Color(225, 225, 225));
        formObject.setNGBackColor("PurchaseGrp", new Color(225, 225, 225));
        formObject.setNGBackColor("MMDocNo", new Color(225, 225, 225));

        formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
        formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
        formObject.setTop("frm_comments", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
        //DeclChange
        String comCode = formObject.getNGValue("CompanyCode");
        writeToLog(2, "..........................comCode..................... "+comCode, strprcsinstid);
        if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
            formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
            formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
        }
        formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_comments") + 10);

        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        formObject.setVisible("btn_trnsdtl", false);
        formObject.setCaption("btn_Reject", "Reject");
        if (strTypeofinvoice.equalsIgnoreCase("Travel")) {
            formObject.setVisible("btn_Travel", true);
            //formObject.setEnabled("btn_Travel", true);
            //formObject.setEnabled("btn_Cab", false);
            //formObject.setVisible("btn_Cab", false);
            formObject.setTop("btn_Travel", 128);
            formObject.setLeft("btn_Travel", 24);

        } else if (strTypeofinvoice.equalsIgnoreCase("Cab")) {
            //formObject.setVisible("btn_Travel", false);
            //formObject.setEnabled("btn_Travel", false);
            //formObject.setEnabled("btn_Cab", true);
            formObject.setVisible("btn_Cab", true);
            formObject.setTop("btn_Cab", 128);
            formObject.setLeft("btn_Cab", 24);
        }

        if (WorkstepName.equalsIgnoreCase("Manual_Initiation") || WorkstepName.equalsIgnoreCase("Indexing") || WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2") || WorkstepName.equalsIgnoreCase("Approver3") || WorkstepName.equalsIgnoreCase("Approver4") || WorkstepName.equalsIgnoreCase("Approver5") || WorkstepName.equalsIgnoreCase("Approver6") || WorkstepName.equalsIgnoreCase("Approver7") || WorkstepName.equalsIgnoreCase("Approver8")) {
            formObject.setLeft("btn_Reject", 350);
            if (WorkstepName.equalsIgnoreCase("Manual_Initiation") || WorkstepName.equalsIgnoreCase("Indexing")) {
                formObject.setLeft("btn_submit", 210);
                formObject.setLeft("btn_Reject", 350);
                formObject.setVisible("btn_Reject", true);
                formObject.setCaption("btn_Reject", "Reject");

                formObject.setEnabled("frm_tran_details2", true);
                formObject.setEnabled("TypeOfProcess", false);
                formObject.setEnabled("TypeOfInvoice", false);
                formObject.setEnabled("frm_invdtl_po", true);
                formObject.setEnabled("frm_comments", true);
                formObject.setEnabled("btn_load", false);

            }

        } else {

            formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
            formObject.setTop("frm_invdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10);
            formObject.setTop("frm_accndtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10);
            formObject.setTop("frm_parkdtl_po", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10);
            formObject.setTop("frm_comments", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10);
            //DeclChange
//            String comCode = formObject.getNGValue("CompanyCode");

            if (comCode.equalsIgnoreCase("BIL1") || comCode.equalsIgnoreCase("BDPL") || comCode.equalsIgnoreCase("BCFL") || comCode.equalsIgnoreCase("IBPL")
                    && comCode.equalsIgnoreCase("JBM1") || comCode.equalsIgnoreCase("MFL1") || comCode.equalsIgnoreCase("SBCL")) {
                formObject.setTop("frm_Decl", formObject.getTop("frm_comments"));
                formObject.setTop("frm_comments", formObject.getTop("frm_Decl") + formObject.getHeight("frm_Decl") + 10);
            }
            formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_accndtl_po") + 10 + formObject.getHeight("frm_parkdtl_po") + 10 + formObject.getHeight("frm_comments") + 10);
            //formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 10 + formObject.getHeight("frm_invdtl_po") + 10 + formObject.getHeight("frm_comments") + 10);

            formObject.setVisible("frm_accndtl_po", true);
            formObject.setVisible("frm_parkdtl_po", true);

        }

    }

    public void TravelCab_Initaition() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");
        //formObject.setNGValue("TypeOfProcess", "NONPO");
        //formObject.setLocked("TypeOfProcess", true);
        formObject.setVisible("lbl_er", false);
        formObject.setVisible("lbl_vp", false);
        formObject.setVisible("frm_salary_adv", false);
        formObject.setVisible("frm_invoice_details", false); //Commented bala on 210-12-2016
        formObject.setVisible("frm_ent_scheme", false);
        formObject.setVisible("frm_mobile_claims", false);
        formObject.setVisible("frm_moving_personal_effects", false);
        formObject.setVisible("frm_brokage_fees", false);
        formObject.setVisible("frm_summary", false);
        formObject.setVisible("frm_family_info", false);
        formObject.setVisible("frm_travel_fare", false);
        formObject.setVisible("frm_hotel_fare", false);
        formObject.setVisible("frm_daily_allw", false);
        formObject.setVisible("frm_convey", false);
        formObject.setVisible("frm_misc", false);
        formObject.setVisible("frm_medical_expense", false);
        formObject.setVisible("frm_nonpo_line", false);
        formObject.setVisible("frm_po_line", false);
        formObject.setVisible("frm_approval", false);
        formObject.setEnabled("frm_tran_details2", true);
        formObject.setNGValue("SubCat2", "Applicable");
        formObject.setNGValue("SubCat3", "Not Exempted");
        DBValues_Combo("SELECT DISTINCT TypeofInv FROM EXT_AP_ER_InvoiceSub with(nolock) WHERE Process ='TC'", "TypeOfInvoice");
        DBValues_Combo("select distinct SubCat1 from EXT_AP_ER_InvoiceSub with(nolock) where process='TC' and SubCat1 IS NOT NULL", "SubCategory1");
        DBValues_Combo("select distinct SubCat2 from EXT_AP_ER_InvoiceSub with(nolock) where process='TC'AND TypeofInv='Cab' and SubCat2 IS NOT NULL", "SubCat2");
        DBValues_Combo("select distinct SubCat3 from EXT_AP_ER_InvoiceSub with(nolock) where process='TC'AND TypeofInv='Cab' and SubCat3 IS NOT NULL", "SubCat3");

        formObject.setEnabled("frm_comments", true); //ADDED NEWLY
        formObject.setEnabled("btn_load", true);
        formObject.setTop("frm_tran_details2", formObject.getHeight("frm_heading1") + 20);
        formObject.setHeight("Main", formObject.getHeight("frm_heading1") + 20 + formObject.getHeight("frm_tran_details2") + 40);
    }

    //Below function will pass the current Financial Year added by bala G on 23-12-2016 
    //Modified by Sivashankar KS on 31-May-2019 for Nepal Company Code starts here
//    public int Cur_FinanicalYr() {
//        int year = Calendar.getInstance().get(Calendar.YEAR);
//        int month_1 = Calendar.getInstance().get(Calendar.MONTH);
//        if (month_1 <= 2) {
//            year = year - 1;
//        }
//        writeToLog(2,"Financial year=" + year, strprcsinstid);
//        return year;
//    }
    public int Cur_FinanicalYr() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        int year = Calendar.getInstance().get(Calendar.YEAR);
        int month_1 = Calendar.getInstance().get(Calendar.MONTH);
        int strDays = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
        System.out.println("strDays  == " + strDays);
        String strCompanyCode = formObject.getNGValue("CompanyCode");
//        if (strCompanyCode.equalsIgnoreCase("BNP1")) {//Commented on 22-APR-21 as confirmed by JESTUS a/c to SAP HANA
//            if (month_1 < 6) {
//                year = year - 1;
//            } else if ((month_1 == 6) && (strDays < 15)) {
//                year = year - 1;
//            } else {
//                year = year;
//            }
//            System.out.println("Inside if(BNP1) Financial year=" + year);
//        } else {
        if (month_1 <= 2) {
            year = year - 1;
        } else {
            year = year;
        }
        System.out.println("Inside else(Other than BNP1) Financial year=" + year);
//        }
        System.out.println("Financial year=" + year);
        return year;
    }
//Modified by Sivashankar KS on 31-May-2019 for Nepal Company Code ends here

    public void Move_Park() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        formObject.setNGValue("ApprSts1", "Completed");
        formObject.setNGValue("ApprSts2", "No"); //Move for Park
        formObject.RaiseEvent("WFDone");
    }

    //Added on 07-NOV-20 for restricting Salary Advance for New Joinee within 6months time period 
    public String salaryAdvanceEligible(FormReference formObject, String strJoiningDate, String strEmployeeCode, String strLevel, String strEmpGrade) throws ParseException {
        String strJD = "";
        writeToLog(2, "DOJ from SAP :: " + strJoiningDate, strprcsinstid);

        if ((strEmpGrade.equalsIgnoreCase("EO") && strLevel.equalsIgnoreCase("Officer Grade V(W)"))
                || (strLevel.equalsIgnoreCase("Officer Grade V") || strEmpGrade.equalsIgnoreCase("EN"))
                || (strLevel.equalsIgnoreCase("Officer Grade IV (W)") || strEmpGrade.equalsIgnoreCase("EQ"))
                || (strLevel.equalsIgnoreCase("Officer Grade IV") || strEmpGrade.equalsIgnoreCase("EL"))) {
            String jdQry = "SELECT DateOfJoining FROM EXT_AP_SalaryAdvance_DOJ WHERE EmpCode = '" + strEmployeeCode + "'";
            writeToLog(2, "jdQry " + jdQry, strprcsinstid);
            strJD = formObject.getDataFromDataSource(jdQry).toString();
            strJD = strJD.replace("[", "");
            strJD = strJD.replace("]", "");
            writeToLog(2, "strJD result " + strJD, strprcsinstid);
            if (strJD.isEmpty() || strJD.equalsIgnoreCase("")) {
                writeToLog(2, " ******** ", strprcsinstid);
                return ("NODATA");
//                FacesMessage message = new FacesMessage("Data is not available. Please contact HR.");
//                throw new ValidatorException(message);
            }
            strJD = strJD.replace(".", "-");
        } else {
            String yy = strJoiningDate.substring(0, 4);
            String mm = strJoiningDate.substring(5, 7);
            String dd = strJoiningDate.substring(8, 10);
            strJD = dd + "-" + mm + "-" + yy;
        }
        writeToLog(2, " strJD : " + strJD, strprcsinstid);

        Date dateJD = new SimpleDateFormat("dd-MM-yyyy").parse(strJD);
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        Calendar cal = Calendar.getInstance();
        Date dateTD = cal.getTime();
        writeToLog(2, "Joining date : " + df.format(dateJD), strprcsinstid);
        writeToLog(2, "Today date : " + df.format(dateTD), strprcsinstid);
        //cal.setTime(today);

        Calendar sixMonthsAgo = Calendar.getInstance();
        sixMonthsAgo.add(Calendar.MONTH, -6);
        Date sixMonDate = sixMonthsAgo.getTime();
        writeToLog(2, df.format(sixMonDate), strprcsinstid);

        long daysBetweenSixMonths = dateTD.getTime() - sixMonDate.getTime();
        int daysSixMon = (int) TimeUnit.DAYS.convert(daysBetweenSixMonths, TimeUnit.MILLISECONDS);
        writeToLog(2, "noOfDaysBetween6months" + daysSixMon, strprcsinstid);

        long daysBetweenJoiningDate = dateTD.getTime() - dateJD.getTime();
        int daysJoiningDate = (int) TimeUnit.DAYS.convert(daysBetweenJoiningDate, TimeUnit.MILLISECONDS);
        writeToLog(2, "noOfDaysBetweenJoiningDate " + daysJoiningDate, strprcsinstid);

        if (daysJoiningDate >= daysSixMon) {
            return ("PASS");
        } else {
            return ("FAIL");
        }
    }
    //End on 07-NOV-20

    public void ER_EligibleAmount() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String strTypeOfInvoive = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1");
        String Grade1 = formObject.getNGValue("Grade");
        //Added on 06-NOV-20 for Salary Advance EMI
        String arrMon[] = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"};
        String arrMonEMI[] = {"03", "02", "01", "12", "11", "10", "09", "08", "07", "06", "05", "04"};
        String arrMonEMINepal[] = {"06", "05", "04", "03", "02", "01", "12", "11", "10", "09", "08", "07"};
        //End on 06-NOV-20

        if (strTypeOfInvoive.equalsIgnoreCase("Employee Advances")) {
            formObject.setEnabled("EligibleAmount", false);
            //formObject.setEnabled("RepaymentSchedule",false);
            /*
             if (strSubcategory.equalsIgnoreCase("Salary Advance")) {
             if (formObject.getNGValue("BasicSalary").equalsIgnoreCase("")) {
             formObject.setNGValue("BasicSalary", "0.00");
             }

             //Modified By Harinatha R 2017/05/29
             //formObject.setNGValue("EligibleAmount", Float.parseFloat(formObject.getNGValue("BasicSalary")) * 3);
             formObject.setNGValue("EligibleAmount", Math.floor((Float.parseFloat(formObject.getNGValue("BasicSalary")) * 3) / 100) * 100);
             formObject.setNGValue("RepaymentSchedule", "15 Months");
             //Ended By Harinatha R 2017/05/29

             //String querysalrepay="SELECT Repay FROM EXT_AP_AmountCalculation with(nolock) WHERE Grade='" + Grade1 + "'";
             //DBValues_Field(querysalrepay, "RepaymentSchedule");
             } else if (strSubcategory.equalsIgnoreCase("Exceptional Advances")) {
             //                                           String queryexe="SELECT Exception FROM EXT_AP_AmountCalculation with(nolock) WHERE Grade='" + Grade1 + "'";
             //                                           DBValues_Field(queryexe, "EligibleAmount");
             //                                           
             //                                           String queryexerepay="SELECT Repay FROM EXT_AP_AmountCalculation with(nolock) WHERE Grade='" + Grade1 + "'";
             //                                           DBValues_Field(queryexerepay, "RepaymentSchedule");

             //                                                String queryhouse="SELECT Claimlimit,Repayment FROM EXT_AP_ER_ClaimLimit with(nolock) WHERE Grade='" + Grade1 + "' and Subcategory1='"+strSubcategory+"'";
             //                                                String[] FieldValue_array=DB_QueryExecute(queryhouse);
             //                                                formObject.setNGValue("EligibleAmount", FieldValue_array[0]);
             //                                                formObject.setNGValue("RepaymentSchedule", FieldValue_array[1]);
             } //Modified By Harinath on 2017/03/22
             else if (strSubcategory.equalsIgnoreCase("House Rent Advance") || strSubcategory.equalsIgnoreCase("Imprest Cash")) //Ended By Harinath on 2017/03/22
             {
             //                                           String queryhouse="SELECT Houserent FROM EXT_AP_AmountCalculation with(nolock) WHERE Grade='" + Grade1 + "'";
             //                                           DBValues_Field(queryhouse, "EligibleAmount");
             //                                           formObject.setEnabled("EligibleAmount",false);
             //                                           String queryhouserepay="SELECT Repay FROM EXT_AP_AmountCalculation with(nolock) WHERE Grade='" + Grade1 + "'";
             //                                           DBValues_Field(queryhouserepay, "RepaymentSchedule");
             //                                           formObject.setEnabled("RepaymentSchedule",false);
             //Added by nanjunda Moorthy for House Advances Calculations on 24/01/2016

             if (strSubcategory.equalsIgnoreCase("House Rent Advance") && formObject.getNGValue("Region").equalsIgnoreCase("Britannia - Mumbai Plant")) {
             formObject.setNGValue("EligibleAmount", "50000.00");
             formObject.setNGValue("RepaymentSchedule", "60 Months");
             } else {
             String queryhouse = "SELECT Claimlimit,Repayment FROM EXT_AP_ER_ClaimLimit with(nolock) WHERE Grade='" + Grade1 + "' and Subcategory1='" + strSubcategory + "'";
             String[] FieldValue_array = DB_QueryExecute(queryhouse);
             formObject.setNGValue("EligibleAmount", FieldValue_array[0]);
             formObject.setNGValue("RepaymentSchedule", FieldValue_array[1]);
             }
             }
             */

            //Modified By Harinath on 2018/03/21 
            if (strSubcategory.equalsIgnoreCase("House Rent Advance")) {

                if ((formObject.getNGValue("PersonalArea").equalsIgnoreCase("IN03") && (formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("MUMB") || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("MUMM") || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("PANV")))
                        || (formObject.getNGValue("PersonalArea").equalsIgnoreCase("BDPL") && (formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("MUMB")))
                        || (formObject.getNGValue("PersonalArea").equalsIgnoreCase("PA13") && (formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("MUMB") || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("MUX5") || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("OMUM")
                        || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("THAN") || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("KHOP")
                        || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("CPM5") || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("CPM0")
                        || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("CPH8") || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("CP31")
                        || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("CP28") || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("CP20")
                        || formObject.getNGValue("PersonalSubArea").equalsIgnoreCase("CP11")))) {

                    String queryhouse = "select EligibleAmt, EMIs from EXT_AP_ER_MASTER_EMPLOYEEADVANCES with (nolock) where EmployeeGradeText='" + Grade1 + "' and AdvanceType='" + strSubcategory + "' and PersonalArea ='" + formObject.getNGValue("PersonalArea") + "' and PersonalSubArea='" + formObject.getNGValue("PersonalSubArea") + "' and Location='M'";
                    String[] FieldValue_array = DB_QueryExecute(queryhouse);
                    formObject.setNGValue("EligibleAmount", FieldValue_array[0]);
                    formObject.setNGValue("RepaymentSchedule", FieldValue_array[1]);
                } else {
                    String queryhouse = "select EligibleAmt, EMIs from EXT_AP_ER_MASTER_EMPLOYEEADVANCES with (nolock) where EmployeeGradeText='" + Grade1 + "' and AdvanceType='" + strSubcategory + "' and Location='NM'";
                    String[] FieldValue_array = DB_QueryExecute(queryhouse);
                    formObject.setNGValue("EligibleAmount", FieldValue_array[0]);
                    formObject.setNGValue("RepaymentSchedule", FieldValue_array[1]);
                }

            } else if (strSubcategory.equalsIgnoreCase("Salary Advance")) {

                if (formObject.getNGValue("BasicSalary").equalsIgnoreCase("")) {
                    formObject.setNGValue("BasicSalary", "0.00");
                }

                formObject.setNGValue("EligibleAmount", Math.floor((Float.parseFloat(formObject.getNGValue("BasicSalary")) * 3) / 100) * 100);

                String queryhouse = "select EMIs from EXT_AP_ER_MASTER_EMPLOYEEADVANCES with (nolock) where EmployeeGradeText='" + Grade1 + "' and AdvanceType='" + strSubcategory + "'";
                String[] FieldValue_array = DB_QueryExecute(queryhouse);
                //Modified on 06-NOV-20 for Salary Advance EMI 
//                formObject.setNGValue("RepaymentSchedule", FieldValue_array[0]);
                Calendar cal = Calendar.getInstance();
                int monthNumber = cal.get(Calendar.MONTH);
                int dayNum = cal.get(Calendar.DAY_OF_MONTH);
                if (dayNum > 20) {
                    monthNumber = monthNumber + 1;
                }
                String strCompCode = formObject.getNGValue("CompanyCode");
                if (!strCompCode.equalsIgnoreCase("BNP1")) {
                    writeToLog(2, "Message : " + arrMon[(monthNumber)] + " advances will be recovered in " + arrMonEMI[monthNumber] + " months.", strprcsinstid);
                    formObject.setNGValue("RepaymentSchedule", arrMonEMI[monthNumber]);
                } else {
                    writeToLog(2, "Message : " + arrMon[(monthNumber)] + " advances will be recovered in " + arrMonEMINepal[monthNumber] + " months.", strprcsinstid);
                    formObject.setNGValue("RepaymentSchedule", arrMonEMINepal[monthNumber]);
                }
                //End on 06-NOV-20

            } else if (strSubcategory.equalsIgnoreCase("Imprest Cash")) {

                String queryhouse = "select EligibleAmt, EMIs from EXT_AP_ER_MASTER_EMPLOYEEADVANCES with (nolock) where EmployeeGradeText='" + Grade1 + "' and AdvanceType='" + strSubcategory + "'";
                String[] FieldValue_array = DB_QueryExecute(queryhouse);
                formObject.setNGValue("EligibleAmount", FieldValue_array[0]);
                formObject.setNGValue("RepaymentSchedule", FieldValue_array[1]);

            } else if (strSubcategory.equalsIgnoreCase("Exceptional Advances")) {

            }
            //Ended By Harinath on 2018/03/21

        } else if (strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements")) {
            /*
             if (strSubcategory.equalsIgnoreCase("Mobile Re-Imbursements")) {
             String querymobile = "SELECT Mobile FROM EXT_AP_AmountCalculation with(nolock) WHERE Grade='" + Grade1 + "'";
             DBValues_Field(querymobile, "EligibleAmount_MobileClaim");
             formObject.setEnabled("EligibleAmount_MobileClaim", false);
             }
             */
        }
//                            else if(strTypeOfInvoive.equalsIgnoreCase("Moving of Personal Effects"))
//                            {
//                                if ((formObject.getNGValue("SchlfeeYN")).equalsIgnoreCase("Yes"))
//                                   {
//                                      if ((formObject.getNGValue("SchlfeenoYN")).equalsIgnoreCase("1"))
//                                        {
//                                         String querymobile="SELECT SchoolFee FROM EXT_AP_AmountCalculation with(nolock) WHERE Grade='" + Grade1 + "'";
//                                         DBValues_Field(querymobile, "SchlfeeElbamnt");
//                                         formObject.setEnabled("SchlfeeElbamnt",false);  
//                                        }
//                                      else if ((formObject.getNGValue("SchlfeenoYN")).equalsIgnoreCase("2"))
//                                        {
//                                         String querymobile="SELECT SchoolFee FROM EXT_AP_AmountCalculation with(nolock) WHERE Grade='" + Grade1 + "'";
//                                         formObject.setEnabled("SchlfeeElbamnt",false);
//                                         
//                                        List strFieldValue = formObject.getDataFromDataSource(querymobile);
//                                            if (!strFieldValue.isEmpty()) {
//                                                String values = strFieldValue.toString();
//                                                values = values.replace("[", "");
//                                                values = values.replace("]", "");
//                                                String[] FieldValue_array = values.split(",");
//                                                formObject.setNGValue("SchlfeeElbamnt",(Float.parseFloat(FieldValue_array[0].trim()))*2);
//                                            }
//                                            formObject.setEnabled("SchlfeeElbamnt",false);
//                                        } 
//                                   } 
//                            }

    }

    public void multiplePO() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String stePOLineItemDetails = formObject.getNGValue("Text_MPO_Output");
        writeToLog(2, "stePOLineItemDetails:" + stePOLineItemDetails, strprcsinstid);
        String[] RowValue = stePOLineItemDetails.split("\\+#");
        HashMap<String, String> PoHeader = new HashMap<String, String>();
        for (int row = 0; row < RowValue.length; row++) {
            String[] ColumnValue = RowValue[row].split("~");

            String strSAPPO_NO = ColumnValue[0];
            String SAPGRNNO = ColumnValue[1];
            String SAPEntrySheetNo = ColumnValue[2];
            String SAPPOLineitemText = ColumnValue[3];
            String SAPItemQuantity = ColumnValue[4];
            String SAPStatus = ColumnValue[5];
            ListViewItems LVI = new ListViewItems();
            LVI.addColumnvalue("");
            LVI.addColumnvalue(strSAPPO_NO);
            LVI.addColumnvalue(SAPGRNNO);
            LVI.addColumnvalue("");
            LVI.addColumnvalue(SAPEntrySheetNo);
            LVI.addColumnvalue(SAPPOLineitemText);
            LVI.addColumnvalue(SAPItemQuantity);
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue(SAPStatus);
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            LVI.addColumnvalue("");
            //System.out.println("flag true Multiple PO" + LVI.getXML());
            formObject.NGAddListItem("list_po_invoice", LVI.getXML());

        }

    }

    public int DMSSAPNO() {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String Newgenwiname = winame.replaceAll("AP-", "");
        Newgenwiname = Newgenwiname.replaceAll("-Payments", "");
        Newgenwiname = Newgenwiname.replaceAll("-Process", "");
        int widlength = Newgenwiname.length();
        if (widlength > 15) {
            Newgenwiname = Newgenwiname.substring(widlength - 15, widlength);
        }
        int WID = Integer.parseInt(Newgenwiname);
        return WID;
    }

    public String diffDays(String dt1, String dt2) throws ParseException {
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        //String diff = "0";
        writeToLog(2, "Inside  diffDays()$$$$$$$  dt1 :::" + dt1 + "  dt2 :::: " + dt2, winame);
        Calendar cal1 = new GregorianCalendar();
        Calendar cal2 = new GregorianCalendar();

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        Date date = sdf.parse(dt1);
        cal1.setTime(date);
        date = sdf.parse(dt2);
        cal2.setTime(date);

        int intdiffDays = daysBetween(cal1.getTime(), cal2.getTime());

        writeToLog(2, "Days  difgffff= " + daysBetween(cal1.getTime(), cal2.getTime()), winame);
        return Integer.toString(intdiffDays);
    }

    public static int daysBetween(Date d1, Date d2) {
        return (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
    }

    public String getInitiatorMailId(String strUserName) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String Query = "SELECT MailId FROM PDBUser with(nolock) WHERE UserName='" + strUserName + "'";
        formObject.setNGValue("Initiatoremail", DB_QueryExecuteSelect1(Query));
        return "SUCCESS";
    }

    //Added By Harinath on 2017/03/21
    public Long getNoOfDaysFromCurDate(String OldDate) throws ParseException {
        Date oldDate = new SimpleDateFormat("dd/MM/yyyy").parse(OldDate);
        long noOfDays = 0;
        Date curDate = new Date();
        noOfDays = curDate.getTime() - oldDate.getTime();
        noOfDays = TimeUnit.DAYS.convert(noOfDays, TimeUnit.MILLISECONDS);
        noOfDays = TimeUnit.DAYS.toDays(noOfDays);
        noOfDays = noOfDays + 1;
        return noOfDays;
    }

    public Long getNoOfDaysBTWDates(String FromDate, String ToDate) throws ParseException {
        Date oldDate = new SimpleDateFormat("dd/MM/yyyy").parse(FromDate);
        Date newDate = new SimpleDateFormat("dd/MM/yyyy").parse(ToDate);
        long noOfDays = 0;
        noOfDays = newDate.getTime() - oldDate.getTime();
        noOfDays = TimeUnit.DAYS.convert(noOfDays, TimeUnit.MILLISECONDS);
        noOfDays = TimeUnit.DAYS.toDays(noOfDays);
        noOfDays = noOfDays + 1;
        return noOfDays;
    }

    /**
     * --------------------------------------------------------------------//
     * Function Name :setTextBox Input Parameters : Output parameters:
     * ReturnValues :String Description :set value to text box
     *
     * --------------------------------------------------------------------
     */
    public void setTextBox(final FormReference formObject,
            final String sql, final String textBox) {
        writeToLog(2, "Start setTextBox ****%%%%**** ", "");
        writeToLog(2, "Inside setTextBox", "");
        List<List<String>> list = formObject.getDataFromDataSource(sql);
        writeToLog(2, "sql ::: " + sql, "");
        for (List<String> templist1 : list) {
            String value = templist1.get(0);
            writeToLog(2, " " + textBox + " == " + value, "");
            formObject.setNGValue(textBox, value);
        }
        writeToLog(2, "End setTextBox ****%%%%**** ", "");
    }
    //Ended By Harinath on 2017/03/21

    /*
     * ----------------------------------------------------------------------------------
     * Function Name :SelectQuery 
     * Description   :Getting Required values from Database
     * Return Value : Required Fieldname  
     * -----------------------------------------------------------------------------------
     */
    public String SelectQuery(String sQuery) {
        writeToLog(2, "Start SelectQuery ****%%%%**** ", strprcsinstid);
        try {
            FormReference fo = FormContext.getCurrentInstance().getFormReference();
            List strFieldValue = fo.getDataFromDataSource(sQuery);
            writeToLog(2, "sQuery ****%%%%**** " + sQuery, strprcsinstid);
            if (!strFieldValue.isEmpty()) {
                String values = strFieldValue.toString();

                values = values.replace("[", "");
                values = values.replace("]", "");
                String[] FieldValue_array = values.split(",");
                return FieldValue_array[0].trim();
            }
            return "";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public void enableDORMailBtn(FormReference formObject) {
        //To display mail button to ssc team
        // FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String strUserAct = SelectQuery("select count(UserIndex) from PDBGroupMember WITH(NOLOCK) where UserIndex=(select UserIndex from PDBUser WITH(NOLOCK) where UserName='" + formObject.getUserName() + "')"
                + " and GroupIndex in (select GroupIndex from PDBGroup WITH (NOLOCK) where (GroupName='AP_ER_Advances_Park' or GroupName='AP_ER_Advances_Post' or GroupName='AP_ER_Mobile_Park' or GroupName='AP_ER_Mobile_Post' "
                + "or GroupName='AP_ER_Advances_Park'))");
        writeToLog(2, "Before if in  enableDORMailBtn:::  ", strprcsinstid);
        if (Integer.parseInt(strUserAct) >= 1) {
            writeToLog(2, "strUserAct :::  " + strUserAct, strprcsinstid);
            formObject.setVisible("btn_DORMail", true);
            writeToLog(2, "End of enable  ", strprcsinstid);
        }
    }

    //added by Sivashankar KS on 23-Oct-2018 for disabling the other than travel date in DA & Hotel fares template
    public void getDateFromList_TravelOld(FormReference formObject, String winame) {

        try {

            //SimpleDateFormat old_format = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat new_format = new SimpleDateFormat("dd/MM/yyyy");

            int count = formObject.getItemCount("list_travel");

            AP_CommonFunctions.writeToLog(2, " Travel Grid count--" + count, winame);
            String[] List_dates = new String[count];

            Date[] parse_dates_old = new Date[count];

//Getting Date from list
            for (int i = 0; i < count; i++) {

                List_dates[i] = formObject.getNGValue("list_travel", i, 2);
                AP_CommonFunctions.writeToLog(2, " Travel Grid List_dates--" + List_dates[i], winame);
            }

            for (int i = 0; i < count; i++) {

                parse_dates_old[i] = new_format.parse(List_dates[i]);
                //formObject.getNGc

                AP_CommonFunctions.writeToLog(2, " Travel Grid parse_dates_old--" + parse_dates_old[i], winame);
            }
            ArrayList<Date> fin_Date = new ArrayList<Date>(Arrays.asList(parse_dates_old));
            AP_CommonFunctions.writeToLog(2, " Travel Grid parse_dates_old--" + fin_Date, winame);

            String d_min = new_format.format(Collections.min(fin_Date));
            String d_max = new_format.format(Collections.max(fin_Date));

            AP_CommonFunctions.writeToLog(2, " Travel Grid MinDate before minus--" + d_min, winame);
            AP_CommonFunctions.writeToLog(2, " Travel Grid MaxDate before plus --" + d_max, winame);

            //to get next and previous date to set in date picker
            int MILLIS_IN_DAY = 1000 * 60 * 60 * 24;
            Date d_min_minus = new_format.parse(d_min);
            Date d_max_plus = new_format.parse(d_max);

            String prevDate = new_format.format(d_min_minus.getTime() - MILLIS_IN_DAY);
            String nextDate = new_format.format(d_max_plus.getTime() + MILLIS_IN_DAY);
//end

            AP_CommonFunctions.writeToLog(2, " Travel Grid prevDate--" + prevDate, winame);
            AP_CommonFunctions.writeToLog(2, " Travel Grid nextDate--" + nextDate, winame);

            formObject.setNGValue("main_txt_min_date", prevDate);
            formObject.setNGValue("main_txt_max_date", nextDate);
            AP_CommonFunctions.writeToLog(2, " value_max--" + d_max, winame);
            AP_CommonFunctions.writeToLog(2, " value_min--" + d_min, winame);

        } catch (Exception e) {
            AP_CommonFunctions.writeToLog(2, "Exception in Date calculatiuon" + e.getMessage(), winame);
        }
    }

}
