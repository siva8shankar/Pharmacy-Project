/*      
 '-----------------------------------------------------------------------------------------------
 '      NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 '   Group                  : SOUTH
 '   Product/Project/Utility: Britannia
 '   Module                 : ngfUser
 '   File Name              : EventPickList.Java
 '   Author                 : Balasubiramani.g
 '   Date created           : 28-11-2016
 '   Description            : This file is for Common Event Picklist functions  
 '-----------------------------------------------------------------------------------------------
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.component.PickList;
import com.newgen.omniforms.component.behavior.EventListenerImplementor;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.util.Constant.EVENT;
import javax.faces.event.ActionEvent;


public class EventPickList extends EventListenerImplementor 
{
    
    AP_CommonFunctions CommonObj= new AP_CommonFunctions();
    public EventPickList(String picklistid) 
    {
        super(picklistid);
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        
        //System.out.println("Inside EventlistenerHandler.java 1");
        CommonObj.writeToLog(2,"Inside EventlistenerHandler.java 1",winame);
    }

    public EventPickList(String picklistid, EVENT compId) 
    {
        super(picklistid, compId);
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        //System.out.println("Inside EventlistenerHandler.java 2");
        CommonObj.writeToLog(2,"Inside EventlistenerHandler.java 2",winame);
    }

    @Override
    public void btnNext_Clicked(ActionEvent ae)
    {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        CommonObj.writeToLog(2,"Inside EventlistenerHandler.java 3",winame);
    }

    @Override
    public void btnSearch_Clicked(ActionEvent ae) 
    {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        PickList m_objPickList = FormContext.getCurrentInstance().getDefaultPickList();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        //System.out.println("test picklist" + m_objPickList.getAssociatedTxtCtrl());
        CommonObj.writeToLog(2,"test picklist" + m_objPickList.getAssociatedTxtCtrl(),winame);

    }

    @Override
    public void btnOk_Clicked(ActionEvent ae) 
    {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        PickList objPickList = FormContext.getCurrentInstance().getDefaultPickList();
        //System.out.println("Inside OK clicked");
        CommonObj.writeToLog(2,"Inside OK clicked",winame);
        CommonObj.writeToLog(2,"ae="+objPickList.getAssociatedTxtCtrl(),winame);
        //System.out.println("ae="+objPickList.getAssociatedTxtCtrl());
       //  cm.genLog("Inside OK clicked");
        

        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        if(objPickList.getAssociatedTxtCtrl().equals("btn_fromloc"))
        {
            CommonObj.writeToLog(2,"Inside  btn_fromloc btnOk_Clicked From ",winame);
            CommonObj.writeToLog(2,"Value from="+objPickList.getSelectedValue().get(0),winame);
            
            //System.out.println("Inside  btn_fromloc btnOk_Clicked From ");
            //System.out.println("Value from="+objPickList.getSelectedValue().get(0));
            formObject.setNGValue("txt_trvl_fromloc", objPickList.getSelectedValue().get(0));
        }
         if(objPickList.getAssociatedTxtCtrl().equals("btn_toloc"))
        {
             CommonObj.writeToLog(2,"Inside btn_toloc btnOk_Clicked TO ",winame);
              CommonObj.writeToLog(2,"Value To="+objPickList.getSelectedValue().get(0),winame);
             //System.out.println("Inside pl_trvlfare_toloc btnOk_Clicked TO ");
            // System.out.println("Value To="+objPickList.getSelectedValue().get(0));
            formObject.setNGValue("txt_trvl_toloc", objPickList.getSelectedValue().get(0));
        }
         if(objPickList.getAssociatedTxtCtrl().equals("btn_sub"))
        {
             //CommonObj.writeToLog(2,"Inside pl_trvlfare_toloc btnOk_Clicked TO ",winame);
             // CommonObj.writeToLog(2,"Value To="+objPickList.getSelectedValue().get(0),winame);
             //System.out.println("Inside pl_trvlfare_toloc btnOk_Clicked TO ");
            // System.out.println("Value To="+objPickList.getSelectedValue().get(0));
            formObject.setNGValue("SubCategory1", objPickList.getSelectedValue().get(0));
            formObject.setEnabled("SubCategory1",false);
        }
         if(objPickList.getAssociatedTxtCtrl().equals("btn_trvl_class"))
        {
             //CommonObj.writeToLog(2,"Inside pl_trvlfare_toloc btnOk_Clicked TO ",winame);
             // CommonObj.writeToLog(2,"Value To="+objPickList.getSelectedValue().get(0),winame);
             //System.out.println("Inside pl_trvlfare_toloc btnOk_Clicked TO ");
            // System.out.println("Value To="+objPickList.getSelectedValue().get(0));
            formObject.setNGValue("cb_trvl_class", objPickList.getSelectedValue().get(0));
            formObject.setEnabled("cb_trvl_class",false);
        }
        if(objPickList.getAssociatedTxtCtrl().equals("btn_biss_code"))
        {
            formObject.setNGValue("txt_line_bussarea_nonpo", objPickList.getSelectedValue().get(0));
        }
        if(objPickList.getAssociatedTxtCtrl().equals("pl_glcode_nonpo"))
        {
            formObject.setNGValue("txt_line_glcode_nonpo", objPickList.getSelectedValue().get(0));
        }
        if(objPickList.getAssociatedTxtCtrl().equals("pl_cccode_nonpo"))
        {
            formObject.setNGValue("txt_line_cccode_nonpo", objPickList.getSelectedValue().get(0));
        }
        
      /*if(objPickList.getAssociatedTxtCtrl().equals("pl_appr_name"))
        {
            CommonObj.writeToLog(2,"Inside pl_appr_name  btnOk_Clicked",winame);
            CommonObj.writeToLog(2,"Value To="+objPickList.getSelectedValue().get(0),winame);
            
             //System.out.println("Inside pl_appr_name  btnOk_Clicked");
            // System.out.println("Value To="+objPickList.getSelectedValue().get(0));
             formObject.setNGValue("ApprName", objPickList.getSelectedValue().get(0));
        }*/
      if(objPickList.getAssociatedTxtCtrl().equals(""))
      {
       
                formObject.setNGValue("", objPickList.getSelectedValue().get(0));
                formObject.setNGValue("", objPickList.getSelectedValue().get(1));
      }
        //
//        String[] strButtonName = new String[]{"Btn_AccountCategory"};
//        String[] strPicklistName = new String[]{"AO_ACCOUNTCATEGORY", "AO_ACCCATEGORYDESC"};
//
//        for (int i = 0; i < strButtonName.length; i++) 
//        {
//            if (objPickList.getAssociatedTxtCtrl().equalsIgnoreCase(strButtonName[i])) {
//                formObject.setNGValue("AO_ACCOUNTCATEGORY", objPickList.getSelectedValue().get(0));
//                formObject.setNGValue("AO_ACCCATEGORYDESC", objPickList.getSelectedValue().get(1));
//            }
//        }


    }
}