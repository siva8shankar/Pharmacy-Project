/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.approvalmatrix.ApprovalMatrix_VP_PO;
import com.newgen.omniforms.component.PickList;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.sapfunctions.*;
import java.awt.Color;
import java.awt.List;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author deva.r
 */
public class VP_Scanning implements FormListener {

    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
    //VP_Po_ApprovalMatrix1 vp_po_ApprObj=new VP_Po_ApprovalMatrix1();
    ApprovalMatrix_VP_PO objApprovalMatrix_VP_PO = new ApprovalMatrix_VP_PO();
    //SAP_Functions objSAP_Functions= new SAP_Functions();
    SAPFunc objSAPFunc = new SAPFunc();
    //private static FacesMessage fm;
    public boolean flagonload = false;

    @Override
    public void formLoaded(FormEvent fe) {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        // System.out.println("winame:"+winame);
        CommonObj.writeToLog(2, "winame: formLoaded:" + winame, winame);

        formObject.setVisible("btn_ImportDoc", true);
        formObject.setVisible("Btn_SAP", true);
        formObject.setVisible("Text_SAP_Input", true);
        formObject.setVisible("Text_SAP_Output", true);
        formObject.setVisible("btn_load", true);
        formObject.setCaption("btn_load", "Initiate Payment");
        formObject.setVisible("btn_sub", true);

    }

    @Override
    public void formPopulated(FormEvent fe) {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();

        flagonload = true;
        if (formObject.getNGValue("WorkID").equalsIgnoreCase("")) {
            formObject.setNGValue("WorkID", winame);
        }
        formObject.setNGValue("Comments", "");
        CommonObj.VP_Frame_Height();
        CommonObj.VP_Frame_lock();
        formObject.setNGValue("FiscalYr", CommonObj.Cur_FinanicalYr()); //logic need to change

        if (formObject.getNGValue("TypeOfProcess").equalsIgnoreCase("--Select--") || formObject.getNGValue("TypeOfProcess").equalsIgnoreCase("") || formObject.getNGValue("TypeOfProcess") == null) {
            formObject.setNGValue("TypeOfProcess", "PO");
        }
        //End
        //Check below PID captured in the form comments histrory fetch query
        //formObject.setNGValue("PostSts", formObject.getWFWorkitemName());
        CommonObj.DBValues_Combo("select distinct TypeofInv from EXT_AP_ER_InvoiceSub with(nolock) where process='VP' and TypeofInv IS NOT NULL and TypeofInv !=''", "TypeOfInvoice");
        //System.out.println("form Populated in the ER_Initiation2");
        CommonObj.writeToLog(2, "form Populated in the ER_Initiation2", winame);
        //CommonObj.DBValues_Combo("select distinct SubCat1 from EXT_AP_ER_InvoiceSub with(nolock) where process='VP' and SubCat1 IS NOT NULL and SubCat1 !=''", "SubCategory1");
        CommonObj.DBValues_Combo("select distinct SubCat2 from EXT_AP_ER_InvoiceSub with(nolock) where process='VP' and SubCat2 IS NOT NULL and SubCat2 !=''", "SubCat2");
        CommonObj.DBValues_Combo("select distinct SubCat3 from EXT_AP_ER_InvoiceSub with(nolock) where process='VP' and SubCat3 IS NOT NULL and SubCat3 !=''", "SubCat3");
        //CommonObj.DBValues_Combo("select distinct Place from EXT_BUSINESS_PLACE with(nolock) where  Place IS NOT NULL and Place !=''", "BusiSec");
//        String strVendoeCode = formObject.getNGValue("VendCode");
//        if(strVendoeCode !=null && strVendoeCode!=""){
//        CommonObj.DBValues_Combo("select distinct StateCode from EXT_VENDOR_MASTER with(nolock) where VendorCode='" +strVendoeCode+ "' and StateCode IS NOT NULL", "StateCode");
//        CommonObj.DBValues_Combo("select distinct WHTCode from EXT_VENDOR_MASTER with(nolock) where VendorCode='" + strVendoeCode + "' and WHTCode IS NOT NULL", "WHTCode");
//        CommonObj.DBValues_Combo("select distinct WHTBaseAmt from EXT_VENDOR_MASTER with(nolock) where VendorCode='" + strVendoeCode + "' and WHTBaseAmt IS NOT NULL", "WHTBaseAmnt");
//        }
        //CommonObj.DBValues_Combo("select distinct StateCode from EXT_VENDOR_MASTER with(nolock) where StateCode IS NOT NULL and StateCode !=''", "StateCode");
        //CommonObj.DBValues_Combo("select distinct WHTCode from EXT_VENDOR_MASTER with(nolock) where WHTCode IS NOT NULL and WHTCode !=''", "WHTCode");
        //CommonObj.DBValues_Combo("select distinct WHTBaseAmt from EXT_VENDOR_MASTER with(nolock) where  WHTBaseAmt IS NOT NULL and WHTBaseAmt !=''", "WHTBaseAmnt");
        formObject.setNGValue("ExchangeRate", "1.00");
        //formObject.setLocked("ExchangeRate", true);
        formObject.setLocked("AmntLocCurrency", true);

        formObject.setVisible("btn_trnsdtl", false);
        formObject.setVisible("btn_Approve", false);
        formObject.setVisible("btn_Reject", false);
        formObject.setVisible("btn_cmnthsty", false);
        formObject.setLeft("btn_submit", 272);

        //formObject.setNGValue("CompanyCode", "BIL1");
        //formObject.setNGValue("Region", "KA01");
        formObject.setEnabled("DateOfReq", false);
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
        if (WorkstepName.equalsIgnoreCase("Indexing")) {

            formObject.setNGValue("CurrAppLevel", "");
            formObject.setNGValue("MaxAppLevel", "");
            formObject.setNGValue("App1index", "");
            formObject.setNGValue("App2index", "");
            formObject.setNGValue("App3index", "");
            formObject.setNGValue("App4index", "");
            formObject.setNGValue("App5index", "");
            formObject.setNGValue("App6index", "");
            formObject.setNGValue("App7index", "");
            formObject.setNGValue("App8index", "");
            formObject.setNGValue("Comments", "");

            formObject.setLeft("btn_submit", 210);
            formObject.setLeft("btn_Reject", 350);
            formObject.setVisible("btn_Reject", true);
            formObject.setCaption("btn_Reject", "Reject");
            formObject.setVisible("btn_cmnthsty", true);

        } else {
            formObject.setLeft("btn_submit", 272);
        }
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException {

    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException {

    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {

    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        //formObject.setNGValue(null, fe);
        CommonObj.InserComments();

    }

    @Override
    public void eventDispatched(ComponentEvent fe) throws ValidatorException {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        String strSubcategory = formObject.getNGValue("SubCategory1");
        switch (fe.getType()) {
            case MOUSE_CLICKED: {
                //CommonObj.writeToLog(2,"MOUSE_CLICKED Start",winame);
                if (fe.getSource().getName().equalsIgnoreCase("btn_load")) {

                    formObject.setNGValue("FiscalYr", CommonObj.Cur_FinanicalYr()); //logic need to change
                    //formObject.setLocked("FiscalYr", true);
                    if (strTypeOfprocess.equalsIgnoreCase("PO")) {
                        CommonObj.VP_Frame_Height();
                        CommonObj.VP_Frame_lock();
                        formObject.setEnabled("TypeOfProcess", false);
                        formObject.setEnabled("btn_load", false);
                        formObject.RaiseEvent("WFSave");
                    } else if (strTypeOfprocess.equalsIgnoreCase("NONPO")) {
                        CommonObj.VP_Frame_Height();
                        CommonObj.VP_Frame_lock();
                        formObject.setEnabled("TypeOfProcess", false);
                        formObject.setEnabled("btn_load", false);
                        formObject.RaiseEvent("WFSave");
                    }
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_SAP_PO")) {
                    CommonObj.writeToLog(2, "In btn_load", winame);
                    formObject.clear("list_po");
                    formObject.clear("list_po_invoice");
                    String strVendorCode = formObject.getNGValue("VendCode");
                    String strPO_NO = formObject.getNGValue("PONumber");
                    if (strPO_NO == null || strPO_NO == "" || strVendorCode == null || strVendorCode == "") {
                        throw new ValidatorException(new FacesMessage("Please Enter the PO Number and Vendor Code", "PONumber"));
                    }
                    if (formObject.getNGValue("Indicate").equalsIgnoreCase("") || formObject.getNGValue("Indicate").equalsIgnoreCase("--Select--")) {
                        throw new ValidatorException(new FacesMessage("Please select the Indicator", "Indicate"));
                    }

                    strPO_NO = CommonObj.appendzerosN(strPO_NO, 10);
                    strVendorCode = CommonObj.appendzerosN(strVendorCode, 10);

                    CommonObj.writeToLog(2, "Po Number and Vendor Code LENGTH  is 10", winame);
                    //objSAPFunc.ZBAPI_VENDOR_WITH_TAXCODE(strVendorCode);
                    String BapiResult = objSAPFunc.BAPI_PODetailsOnload(strVendorCode, strPO_NO, formObject.getNGValue("Indicate"));
                    CommonObj.writeToLog(2, "BapiResult:" + BapiResult, winame);
                    if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                        CommonObj.writeToLog(2, "BAPI result !=SUCCESS in VP.java", winame);
                        throw new ValidatorException(new FacesMessage("Entered PO Number and Vendor Code details are not available in SAP", "PONumber"));
                    }
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_SAP_Vendor")) {
                    String strVendorCode = formObject.getNGValue("VendCode");
                    if (strVendorCode == null || strVendorCode == "") {
                        throw new ValidatorException(new FacesMessage("Please Enter the Vendor Code", "VendCode"));
                    }

                    int intVendorCode = strVendorCode.length();
//                    if(intVendorCode<6){
//                    throw new ValidatorException(new FacesMessage("Vendor Code sould be minimum 6 digit lenth","VendCode"));                    
//                    }
//                    else 
                    if (intVendorCode < 10) {
                        strVendorCode = CommonObj.appendzero(intVendorCode, "VendCode");
                    }
                    if (strVendorCode.length() == 10) {
                        try {
                            //objSAPFunc.ZBAPI_VENDOR_WITH_TAXCODE(formObject.getNGValue("VendCode"));
                            objSAPFunc.BAPI_VendorDetailsOnload(strVendorCode);
                        } catch (Exception ex) {
                            //Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);PONumber
                        }
                    }
                    //formObject.setNGValue("FiscalYr",CommonObj.Cur_FinanicalYr());

                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_SAP_MPO")) {
                    CommonObj.multiplePO();
                }
                // Added by Deva on 26/12/2016 for listview operations
                if (fe.getSource().getName().equalsIgnoreCase("btn_add_po")) {
                    CommonObj.writeToLog(2, "PO lineitem Add Button", winame);
                    CommonObj.addRow(formObject, "list_po");
                } else if (fe.getSource().getName().equalsIgnoreCase("btn_mod_po")) {
                    CommonObj.writeToLog(2, "PO lineitem modify Button", winame);
                    CommonObj.modifyRow(formObject, "list_po");
                } else if (fe.getSource().getName().equalsIgnoreCase("btn_del_po")) {
                    CommonObj.writeToLog(2, "PO lineitem delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_po");
                } else if (fe.getSource().getName().equalsIgnoreCase("btn_add_nonpo")) {
                    CommonObj.writeToLog(2, "NONPO lineitem Add Button", winame);
                    CommonObj.addRow(formObject, "list_nonpo");
                    int len = formObject.getItemCount("list_nonpo");
                    for (int i = 0; i < len; i++) {
                        formObject.setNGValue("list_nonpo", i, 0, (i + 1) + "");
                    }
                } else if (fe.getSource().getName().equalsIgnoreCase("btn_mod_nonpo")) {
                    //System.out.println("Travel modify Button");
                    CommonObj.writeToLog(2, "NONPO lineitem  modify Button", winame);
                    CommonObj.modifyRow(formObject, "list_nonpo");
                    int len = formObject.getItemCount("list_nonpo");
                    for (int i = 0; i < len; i++) {
                        formObject.setNGValue("list_nonpo", i, 0, (i + 1) + "");
                    }
                } else if (fe.getSource().getName().equalsIgnoreCase("btn_del_nonpo")) {
                    //System.out.println("Travel delete Button");
                    CommonObj.writeToLog(2, "NONPO lineitem  delete Button", winame);
                    CommonObj.deleteRow(formObject, "list_nonpo");
                    int len = formObject.getItemCount("list_nonpo");
                    for (int i = 0; i < len; i++) {
                        formObject.setNGValue("list_nonpo", i, 0, (i + 1) + "");
                    }
                }
                //
                if (fe.getSource().getName().equalsIgnoreCase("btn_po_down")) {
                    //Newley Added by Deva on 19/01/2017 20:42
                    String listviewname = "list_po_invoice";
                    if (formObject.getSelectedIndex("list_po") != -1) {
                        String list = formObject.getNGValue("list_po");

                        formObject.NGAddListItem(listviewname, list);
                        //CommonObj.UpdateSerialNumber(formObject, "list_po");
                        int[] selectedlist = formObject.getNGLVWSelectedRows("list_po");
                        Arrays.sort(selectedlist);
                        for (int i = selectedlist.length; i > 0; i--) {
                            try {
                                CommonObj.writeToLog(2, "Selected rows " + selectedlist[i - 1], winame);
                                formObject.removeItem("list_po", selectedlist[i - 1]);
                                formObject.setSelectedIndex("list_po", -1);
                            } catch (Exception ex) {
                            }
                        }
                        //CommonObj.UpdateSerialNumber(formObject, "list_po");
                        //CommonObj.UpdateSerialNumber(formObject, "list_po_invoice");
                    } else {
                        CommonObj.writeToLog(2, "Kindly select any one of the line item to move down", winame);
                    }

                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_po_up")) {
                    String listviewname = "list_po";
                    if (formObject.getSelectedIndex("list_po_invoice") != -1) {
                        String list = formObject.getNGValue("list_po_invoice");

                        formObject.NGAddListItem(listviewname, list);
                        //CommonObj.UpdateSerialNumber(formObject, "list_po_invoice");
                        int[] selectedlist = formObject.getNGLVWSelectedRows("list_po_invoice");
                        Arrays.sort(selectedlist);
                        for (int i = selectedlist.length; i > 0; i--) {
                            try {
                                CommonObj.writeToLog(2, "Selected rows " + selectedlist[i - 1], winame);
                                formObject.removeItem("list_po_invoice", selectedlist[i - 1]);
                                formObject.setSelectedIndex("list_po_invoice", -1);
                            } catch (Exception ex) {
                            }
                            //CommonObj.UpdateSerialNumber(formObject, "list_po");
                            //CommonObj.UpdateSerialNumber(formObject, "list_po_invoice");
                        }
                    } else {
                        CommonObj.writeToLog(2, "Kindly select any one of the line item to move down", winame);
                    }

                }
                if (fe.getSource().getName().equalsIgnoreCase("Btn_SAP")) {
                    CommonObj.writeToLog(2, "In Btn_SAP Test", winame);
                    try {
                        String BAPIInputTest = formObject.getNGValue("Text_SAP_Input");
                        if (BAPIInputTest != "") {
                            objSAPFunc.BAPI_Test(BAPIInputTest);
                        }
                    } catch (Exception ex) {
                        CommonObj.writeToLog(2, "In Btn_SAP Test Exception:" + ex.getMessage(), winame);
                    }
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_sub")) {
                    String strTypeOfInvoive = formObject.getNGValue("TypeOfInvoice");
                    formObject.clear("SubCategory1");
                    formObject.setNGValue("SubCategory1", "");
                    String querySubCat = "select distinct SubCat1 from EXT_AP_ER_InvoiceSub with(nolock) where process='VP' and SubCat1 IS NOT NULL and SubCat1 !=''";
                    //CommonObj.DBValues_Combo(querySubCat, "SubCategory1"); 
                    PickList objPickList1 = formObject.getNGPickList("btn_sub", "Sub Category1", true, 20, false);
                    objPickList1.setVisible(true);
                    objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                    objPickList1.setWidth(350);
                    objPickList1.setWidth(350);
                    objPickList1.populateData(querySubCat);
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_biss_code")) {
                    String queryBtnClick = "select distinct Ltrim(Rtrim(BISS_AREA)) from EXT_AP_BUSINESS_AREA with(nolock) where BISS_AREA IS NOT NULL and BISS_AREA !=''";
                    CommonObj.DBValues_PickList1(queryBtnClick, "btn_biss_code", "Business Area");
                }
                if (fe.getSource().getName().equalsIgnoreCase("pl_glcode_nonpo")) {
                    //Modified for fetching GLCode based on CompanyCode on 03-SEP-20 
                    //String queryBtnClick="select distinct Ltrim(Rtrim(GLCode)) from EXT_AP_ER_GLcode with(nolock) where GLCode IS NOT NULL and GLCode !=''";
                    String strCompanyCode = formObject.getNGValue("CompanyCode");
                    String queryBtnClick = "select distinct Ltrim(Rtrim(GLCode)) from EXT_AP_GLcode with(nolock) where GLCode IS NOT NULL and GLCode !='' and CompanyCode ='" + strCompanyCode + "' ";
                    //End on 03-SEP-20
                    CommonObj.DBValues_PickList1(queryBtnClick, "pl_glcode_nonpo", "GL Code");
                }
                if (fe.getSource().getName().equalsIgnoreCase("pl_cccode_nonpo")) {
                    String queryBtnClick = "select distinct Ltrim(Rtrim(COST_CENTER)) from EXT_AP_BUSINESS_AREA with(nolock) where COST_CENTER IS NOT NULL and COST_CENTER !=''";
                    CommonObj.DBValues_PickList1(queryBtnClick, "pl_cccode_nonpo", "Cost Centre Code");
                }

                if (fe.getSource().getName().equalsIgnoreCase("pl_appr_name")) {
                    //System.out.println("Inside Approver load");
                    CommonObj.writeToLog(2, "Inside Approver load", winame);
                    String sQuery = "SELECT approvers  FROM EXT_ERApprover_Pick with(nolock)";
                    // System.out.println("queryloc--------------" + sQuery);
                    CommonObj.writeToLog(2, "queryloc--------------" + sQuery, winame);
                    PickList objPickList1 = formObject.getNGPickList("pl_appr_name", "Approvers", true, 20, false);
                    objPickList1.setVisible(true);
                    objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                    objPickList1.setWidth(350);
                    objPickList1.setWidth(350);
                    objPickList1.populateData(sQuery);

                    // CommonObj.DBValues_PickList(sQuery, "pl_appr_name", "Approvers",);
                }
                if (fe.getSource().getName().equalsIgnoreCase("1")) {

                    //System.out.println("Inside Approver load");
                    CommonObj.writeToLog(2, "Inside Approver load", winame);
                    String sQuery = "SELECT approvers  FROM EXT_ERApprover_Pick with(nolock)";
                    //System.out.println("queryloc--------------" + sQuery);
                    CommonObj.writeToLog(2, "queryloc--------------" + sQuery, winame);
                    PickList objPickList1 = formObject.getNGPickList("pl_appr_name", "Approvers", true, 20, false);
                    objPickList1.setVisible(true);
                    objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                    objPickList1.setWidth(350);
                    objPickList1.setWidth(350);
                    objPickList1.populateData(sQuery);
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_submit")) {
                    CommonObj.writeToLog(2, "Inside ngfuser:btn_submit", winame);
                    formObject.setNGValue("InitSts", "VP");
                    /*if (formObject.getNGValue("Currency").equalsIgnoreCase(""))
                     {
                     throw new ValidatorException(new FacesMessage("Please Enter the Currency","Currency"));
                     } */
                    String qryDuplicate = "";
                    qryDuplicate = "Select Count(ITEMINDEX) from EXT_AP with(nolock) where InvoiceNo='" + formObject.getNGValue("InvoiceNo") + "' and TotInvoiceAmnt='" + formObject.getNGValue("TotInvoiceAmnt") + "' and "
                            + "InvoiceDate= convert(datetime,'" + formObject.getNGValue("InvoiceDate") + "',103) and WorkID IS NOT NULL and WorkID !='" + winame + "'";

                    CommonObj.writeToLog(2, "Duplicate check Query:" + qryDuplicate, winame);
                    int dupCOUNT = Integer.parseInt(CommonObj.DB_QueryExecuteSelect1(qryDuplicate));
                    CommonObj.writeToLog(2, "Duplicate check Query COUNT:" + dupCOUNT, winame);
                    if (dupCOUNT >= 1) {
                        CommonObj.writeToLog(2, "Duplicate invoice will not be allowed", winame);
                        CommonObj.writeToLog(3, "Duplicate invoice will not be allowed", winame);
                        throw new ValidatorException(new FacesMessage("Duplicate invoice will not be allowed", "InvoiceNo"));

                    }

                    if (strTypeOfprocess.equalsIgnoreCase("PO")) {
                        if (formObject.getNGValue("PORef").equalsIgnoreCase("")) {
                            throw new ValidatorException(new FacesMessage("Please select reference/category", "PORef"));
                        }
                        if (formObject.getNGValue("Indicate").equalsIgnoreCase("")) {
                            throw new ValidatorException(new FacesMessage("Please select indicator", "Indicate"));
                        }

                        if (strTypeofinvoice.equalsIgnoreCase("Services-A&SP") || strTypeofinvoice.equalsIgnoreCase("Services-Others") || strSubcategory.equalsIgnoreCase("A&SP") || strSubcategory.equalsIgnoreCase("Legal") || strSubcategory.equalsIgnoreCase("IT") || strSubcategory.equalsIgnoreCase("HR") || strSubcategory.equalsIgnoreCase("Admin")) {
                            //try {
                            formObject.setNGValue("VPsts", "Approvel");
                            String arrApprovalLevel[] = {"Approver1", "Approver2", "Approver3", "Approver4", "Approver5", "Approver6"};
                            String struserRoleQuery = "";
                            String struserRole = "";
                            String strusernameQuery = "";
                            String strusername = "";
                            String struserIndexQuery = "";
                            String struserIndex = "";
                            String strTotalApproval = "0";
                            String strTotalApprovalQuery = "SELECT TOP 1 (CASE WHEN Approver1 IS NULL OR Approver1=''  THEN 0 ELSE 1 END)+(CASE WHEN Approver2 IS NULL OR Approver2='' THEN 0 ELSE 1 END)+(CASE WHEN Approver3 IS NULL OR Approver3='' THEN 0 ELSE 1 END)+(CASE WHEN Approver4 IS NULL OR Approver4='' THEN 0 ELSE 1 END)+(CASE WHEN Approver5 IS NULL OR Approver5='' THEN 0 ELSE 1 END)+(CASE WHEN Approver6 IS NULL OR Approver6='' THEN 0 ELSE 1 END)+(CASE WHEN Approver7 IS NULL OR Approver7='' THEN 0 ELSE 1 END)+(CASE WHEN Approver8 IS NULL OR Approver8='' THEN 0 ELSE 1  END)"
                                    + " AS TotalLevel from EXT_AP_PO_Approval WITH (NOLOCK) where"
                                    + " upper(companycode)='" + formObject.getNGValue("CompanyCode").toUpperCase() + "' and upper(Typeofprocess)='" + formObject.getNGValue("TypeOfProcess").toUpperCase() + "' and "
                                    + " upper(TypeofInvoice)='" + formObject.getNGValue("TypeOfInvoice").toUpperCase() + "' and "
                                    //upper(Subcategory1)='" + formObject.getNGValue("").toUpperCase() + "' and "
                                    //+ " upper(Subcategory2)='" + formObject.getNGValue("").toUpperCase() + "' and upper(Region)='" + formObject.getNGValue("").toUpperCase() + "' and "
                                    + formObject.getNGValue("TotInvoiceAmnt") + " between MININVOICEAMOUNT and MAXINVOICEAMOUNT ";

                            CommonObj.writeToLog(1, "strTotalApprovalQuery: " + strTotalApprovalQuery, winame);
                            strTotalApproval = CommonObj.DB_QueryExecute1(strTotalApprovalQuery);
                            CommonObj.writeToLog(1, "strTotalApproval: " + strTotalApproval, winame);

                            if (strTotalApproval.equalsIgnoreCase("") || strTotalApproval.equalsIgnoreCase("NoEntry")) {
                                strTotalApproval = "0";
                            }
                            CommonObj.writeToLog(1, "strTotalApproval: " + strTotalApproval, winame);
                            if (Integer.parseInt(strTotalApproval) == 0 || strTotalApproval.equalsIgnoreCase("NoEntry")) {
                                CommonObj.writeToLog(1, "Approval matrix not present in system ", winame);
                                throw new ValidatorException(new FacesMessage("Approval matrix not present in system", ""));
                            }

                            for (int i = 0; i < arrApprovalLevel.length; i++) {
                                CommonObj.writeToLog(1, "************************* Approval matrix queries for Level " + i + "  ****************************", winame);
                                struserRoleQuery = "select distinct " + arrApprovalLevel[i] + " from EXT_AP_PO_Approval WITH (NOLOCK) where "
                                        + " upper(companycode)='" + formObject.getNGValue("CompanyCode").toUpperCase() + "' and upper(Typeofprocess)='" + formObject.getNGValue("TypeOfProcess").toUpperCase() + "' and "
                                        + " upper(TypeofInvoice)='" + formObject.getNGValue("TypeOfInvoice").toUpperCase() + "' and "
                                        //upper(Subcategory1)='" + formObject.getNGValue("").toUpperCase() + "' and "
                                        //+ " upper(Subcategory2)='" + formObject.getNGValue("").toUpperCase() + "' and upper(Region)='" + formObject.getNGValue("").toUpperCase() + "' and "
                                        + formObject.getNGValue("TotInvoiceAmnt") + " between MININVOICEAMOUNT and MAXINVOICEAMOUNT ";
                                CommonObj.writeToLog(1, "struserRoleQuery: " + struserRoleQuery, winame);
                                struserRole = CommonObj.DB_QueryExecuteAppMatrix(struserRoleQuery);
                                CommonObj.writeToLog(1, "struserRole: " + struserRole, winame);

                                strusernameQuery = "select distinct username from EXT_AP_PO_UserProfile WITH (NOLOCK) where upper(designation) in (" + struserRole.toUpperCase() + ") and "
                                        + " companycode='" + formObject.getNGValue("CompanyCode").toUpperCase() + "' ";//and TypeofInvoice='" + formObject.getNGValue("TypeOfInvoice").toUpperCase() + "' ";
                                // + " and region='" + formObject.getNGValue("").toUpperCase() + "'";
                                CommonObj.writeToLog(1, "strusernameQuery: " + strusernameQuery, winame);
//                                String arrUserNames []=CommonObj.DB_QueryExecute(struserRoleQuery);
//                                CommonObj.writeToLog(1,"arrUserNames []: "+arrUserNames,winame);
//                                for (int j=0; j<arrUserNames.length; j++)
//                                {
//                                  strusername=  arrUserNames[i]+",";
//                                }

                                strusername = CommonObj.DB_QueryExecuteAppMatrix(strusernameQuery);
                                CommonObj.writeToLog(1, "strusername: " + strusername, winame);
                                struserIndexQuery = "select userindex from pdbuser WITH (NOLOCK) where upper(username) in (" + strusername.toUpperCase() + ")";
                                CommonObj.writeToLog(1, "struserIndexQuery: " + struserIndexQuery, winame);
//                                String arrUserIndex []=CommonObj.DB_QueryExecute(struserIndexQuery);
//                                CommonObj.writeToLog(1,"arrUserIndex []: "+arrUserIndex,winame);
//                                for (int k=0; k<arrUserIndex.length; k++)
//                                {
//                                  struserIndex=  arrUserIndex[i]+",";
//                                }
                                struserIndex = CommonObj.DB_QueryExecute1(struserIndexQuery);
                                if (!struserIndex.equalsIgnoreCase("NoEntry") && !struserIndex.equalsIgnoreCase("")) {
                                    struserIndex = struserIndex + ",";
                                }
                                CommonObj.writeToLog(1, "struserIndex: " + struserIndex, winame);
                                if (i == 0) {
                                    formObject.setNGValue("App1index", struserIndex);
                                } else if (i == 1) {
                                    formObject.setNGValue("App2index", struserIndex);
                                } else if (i == 2) {
                                    formObject.setNGValue("App3index", struserIndex);
                                } else if (i == 3) {
                                    formObject.setNGValue("App4index", struserIndex);
                                } else if (i == 4) {
                                    formObject.setNGValue("App5index", struserIndex);
                                } else if (i == 5) {
                                    formObject.setNGValue("App6index", struserIndex);
                                }
                                //CommonObj.writeToLog(1, "App1index: " + formObject.getNGValue("App1index"), winame);
                                if (formObject.getNGValue("App1index").equalsIgnoreCase("") || formObject.getNGValue("App1index").equalsIgnoreCase("NoEntry")) {
                                    throw new ValidatorException(new FacesMessage("Approval matrix not present", ""));

                                }

                            }

                            for (int j = 1; j <= Integer.parseInt(strTotalApproval); j++) {
                                if (formObject.getNGValue("App" + j + "index").equalsIgnoreCase("") || formObject.getNGValue("App" + j + "index").equalsIgnoreCase("NoEntry")) {
                                    throw new ValidatorException(new FacesMessage("Approval matrix not present, You can't proceed the transaction", ""));
                                }

                            }
                            formObject.setNGValue("MaxAppLevel", strTotalApproval);
                            formObject.RaiseEvent("WFDone");
//                            } catch (Exception ex) {
//                                CommonObj.writeToLog(3, "Exception in PO Approval Matrix: " + ex.getMessage(), winame);
//                            }
                        }//End of PO Approval Matrix                     
                        else {
                            formObject.setNGValue("VPsts", "Park");
                            formObject.RaiseEvent("WFDone");

                        }

                    } else if (strTypeOfprocess.equalsIgnoreCase("NONPO")) {
                        formObject.setNGValue("VPsts", "Approvel");
                        try {
                            //vp_po_ApprObj.SapReadXml();
                            objApprovalMatrix_VP_PO.SapReadXml();
                        } catch (FileNotFoundException ex) {
                            CommonObj.writeToLog(3, "Exception =" + ex.getMessage(), winame);
                        } catch (IOException ex) {
                            CommonObj.writeToLog(3, "Exception =" + ex.getMessage(), winame);
                        }
                        formObject.RaiseEvent("WFDone");
                    }

                }
                //CommonObj.writeToLog(2,"MOUSE_CLICKED END",winame);
                //break;
            }
            case KEY_PRESSED: {
                //CommonObj.writeToLog(2,"KEY_PRESSED END",winame);
                //break;
            }
            case FOCUS_LOST: {
                //CommonObj.writeToLog(2,"FOCUS_LOST Start",winame);
                //CommonObj.writeToLog(2,"FOCUS_LOST Name:"+fe.getSource().getName(),winame);
                if (fe.getSource().getName().equalsIgnoreCase("TypeOfProcess")) {
                    //CommonObj.writeToLog(2,"FOCUS_LOST Start 2",winame);
                    formObject.setLocked("SubCat3", true);
                    //formObject.setLocked("CashDiscount", true);
                }
                if (fe.getSource().getName().equalsIgnoreCase("TotInvoiceAmnt") || fe.getSource().getName().equalsIgnoreCase("ExchangeRate")) {
                    float intTotalamt = Float.parseFloat(formObject.getNGValue("TotInvoiceAmnt"));
                    float intExchangeRt = Float.parseFloat(formObject.getNGValue("ExchangeRate"));
                    float loccurrencyAmt = intTotalamt * intExchangeRt;
                    formObject.setNGValue("AmntLocCurrency", loccurrencyAmt);

                }
//                if (fe.getSource().getName().equalsIgnoreCase("VendCode")) 
//                {
//                    String strVendoeCode = formObject.getNGValue("VendCode").trim();
//                    if (strVendoeCode != null && strVendoeCode != "") 
//                    {                        
//                        String query1 = "select TanNo, StateCode, TinNo, ServiceTaxRegNo, WHTCode, WHTType, WHTBaseAmt from EXT_VENDOR_MASTER with(nolock) where VendorCode='" + strVendoeCode + "' and StateCode IS NOT NULL and StateCode !=''";
//                        String[] FieldValue_array=CommonObj.DB_QueryExecute(query1);
//                        System.out.println("VendCode Last Focus: "+FieldValue_array[0]);
//                        System.out.println("VendCode Last Focus2: "+FieldValue_array[1]);
//                        
//                        formObject.setNGValue("TanNo", FieldValue_array[0]);
//                        formObject.setNGValue("StateCode", FieldValue_array[1]);
//                        formObject.setNGValue("TINNO", FieldValue_array[2]);
//                        formObject.setNGValue("ServiceTaxRegNo", FieldValue_array[3]);
//                        formObject.setNGValue("WHTCode", FieldValue_array[4]);
//                        formObject.setNGValue("WHTType", FieldValue_array[5]);
//                        formObject.setNGValue("WHTBaseAmnt", FieldValue_array[6]);
//                    }
//                }
//                if (fe.getSource().getName().equalsIgnoreCase("CashDiscount")) 
//                {
//                    if(formObject.getNGValue("CashDiscount").equalsIgnoreCase("No")){
//                        formObject.setNGValue("CashDisAmnt", "");
//                        formObject.setEnabled("CashDisAmnt", false);
//                        formObject.setNGBackColor("CashDisAmnt", new Color(225, 225, 225));
//                        
//                    }else{
//                        formObject.setEnabled("CashDisAmnt", true);
//                        formObject.setNGBackColor("CashDisAmnt", new Color(255, 255, 255));                    
//                    }
//                
//                }
                //CommonObj.writeToLog(2,"FOCUS_LOST END",winame);
                break;
            }

            case FOCUS_GAINED: {
                //CommonObj.writeToLog(2,"FOCUS_GAINED END",winame);
                break;
            }

            case VALUE_CHANGED: {
                if (flagonload) {
                    if ((fe.getSource().getName().equalsIgnoreCase("TypeOfInvoice")) && ((formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Advances") || formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Capex") || formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("Standard")))) {
                    //CommonObj.writeToLog(2, "Inside Type of In 1" + formObject.getNGValue("TypeOfInvoice"), winame);
                        //CommonObj.writeToLog(2, "Inside Type of In 2" + fe.getSource().getName().equalsIgnoreCase("TypeOfInvoice"), winame);

                        formObject.setNGValue("SubCat2", "Not Applicable");
                        //formObject.setLocked("SubCat2", true);
                        formObject.setEnabled("SubCat2", false);
                        formObject.setNGValue("SubCat3", "Not Applicable");
                        formObject.setEnabled("SubCat3", false);

                    } else if (fe.getSource().getName().equalsIgnoreCase("TypeOfInvoice")) {
                        //formObject.setLocked("SubCat2", false);
                        formObject.setNGValue("SubCat2", "--Select--");
                        formObject.setNGValue("SubCat3", "--Select--");
                        formObject.setEnabled("SubCat2", true);
                        formObject.setEnabled("SubCat3", true);
                    }

                    if (fe.getSource().getName().equalsIgnoreCase("SubCat2")) {
//                    if((formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase(""))||(formObject.getNGValue("TypeOfInvoice").equalsIgnoreCase("--Select--")))
//                    {
//                      throw new ValidatorException(new FacesMessage("Please select type of invoice", "TypeOfInvoice"));  
//                    }
//                    else
//                    {
                        if ((formObject.getNGValue("SubCat2").equalsIgnoreCase("TDS"))) {
                            formObject.setNGValue("SubCat3", "--Select--");
                            formObject.setEnabled("SubCat3", true);
                        } else {
                            formObject.setNGValue("SubCat3", "Not Applicable");
                            formObject.setEnabled("SubCat3", false);
                        }
//                    }
                    }

                    if (fe.getSource().getName().equalsIgnoreCase("CompanyCode") && formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC")) {
                        formObject.setNGValue("Currency", "AED");

                    } else if (fe.getSource().getName().equalsIgnoreCase("CompanyCode") && formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI")) {
                        formObject.setNGValue("Currency", "SAR");

                    } else if (fe.getSource().getName().equalsIgnoreCase("CompanyCode") && (!formObject.getNGValue("CompanyCode").equalsIgnoreCase("ASFI") && !formObject.getNGValue("CompanyCode").equalsIgnoreCase("SFIC"))) {
                        formObject.setNGValue("Currency", "INR");
                    }

                    if (fe.getSource().getName().equalsIgnoreCase("CashDiscount")) {
                        if (formObject.getNGValue("CashDiscount").equalsIgnoreCase("No")) {
                            formObject.setNGValue("CashDisAmnt", "");
                            formObject.setEnabled("CashDisAmnt", false);
                            formObject.setNGBackColor("CashDisAmnt", new Color(225, 225, 225));
                        } else {
                            formObject.setEnabled("CashDisAmnt", true);
                            formObject.setNGBackColor("CashDisAmnt", new Color(255, 255, 255));
                        }

                    }
                }
                //CommonObj.writeToLog(2,"Value Changed END",winame);
                break;
            }

        }//End of Switch
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) {

    }

    @Override
    public void initialize() {

    }

}
