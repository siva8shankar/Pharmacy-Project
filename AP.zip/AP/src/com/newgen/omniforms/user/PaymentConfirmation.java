/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.sapfunctions.SAPFunc;
import java.util.HashMap;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author balasubiramani.g
 * This file for handling SAP Posting functionality
 */
public class PaymentConfirmation implements FormListener
{
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();
     SAPFunc objSAPFunc= new SAPFunc();
     
    @Override
    public void formLoaded(FormEvent fe) 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        //System.out.println("Inside Post FormPopulated");
        CommonObj.writeToLog(2,"Inside Post FormPopulated",winame);        
        //Below line added bala on 09-12-2016 for clearing Commets on each workstep
        formObject.setNGValue("Comments", "");
        //formObject.setNGValue("RejectReason","");
        formObject.setVisible("btn_Approve", false);
        formObject.setVisible("btn_Reject", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Rescan", false);
        formObject.setVisible("btn_Travel", false);
        //End
        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        CommonObj.writeToLog(2,"ER WS Status=" + ER_WS, winame);
        CommonObj.writeToLog(2,"ER WS Status=" + ER_WS,winame);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) 
        {
            CommonObj.HideFrames_Init();
            CommonObj.Approval_lock();
            formObject.setEnabled("frm_parkdtl_po", false);//edited on 03-01-2017 (Deva)
            formObject.setVisible("txt_totalamount", true);
            formObject.setVisible("TotalAmount", true);
        } 
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) 
        {
            CommonObj.VP_Frame_Height();
            CommonObj.VP_Frame_lock();
        }
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("TC")) 
        {
//         CommonObj.TravelCab_Initaition_frm_visible();
//         CommonObj.TravelCab_Park_Post_frm_height();// edited on 03-01-2017
//         CommonObj.Travel_Cab_ButtonView();  // to view button based on invoice type
         CommonObj.TravelCab_Frames();
        }
        formObject.setEnabled("frm_parkdtl_po", false);//edited on 03-01-2017 (Deva
        formObject.setVisible("btn_Reject", true);//edited on 03-01-2017 (Deva)
        formObject.setEnabled("btn_Reject", true);//edited on 03-01-2017 (Deva)
        formObject.setLeft("btn_submit", 328);
        formObject.setLeft("btn_Reject", 208);
        
        CommonObj.enableDORMailBtn(formObject);
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException 
    {
        
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
        CommonObj.InserComments();
    }

    @Override
    public void eventDispatched(ComponentEvent fe) throws ValidatorException 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String fieldName = fe.getSource().getName();
        
        switch (fe.getType()) {
            case MOUSE_CLICKED:
            {
               if(fieldName.equalsIgnoreCase("btn_reverse"))
               {
                   CommonObj.writeToLog(2,"In btn_reverse Click",winame);
                   try {                        
                        objSAPFunc.ZFI_DOCUMENT_REVERSE("btn_reverse"); 
                    } catch (Exception ex) {                        
                        CommonObj.writeToLog(3,"Exception in btn_park: "+ex.getMessage(),winame);
                    }
                   break;
               } 
               if(fieldName.equalsIgnoreCase("btn_submit"))
               {
                   CommonObj.writeToLog(2,"In btn_submit Click",winame);                                        
                        if(!formObject.getNGValue("ReversalDocNo").equalsIgnoreCase(""))
                        {                           
                        formObject.setNGValue("PaymentSts", "Reject");                                                     
                        formObject.RaiseEvent("WFDone");                              
                        }
                        else if(formObject.getNGValue("ReversalDocNo").equalsIgnoreCase("")){                           
                        formObject.setNGValue("PaymentSts", "Yes");                                                     
                        formObject.RaiseEvent("WFDone");                              
                        }break;
               } 
               if(fieldName.equalsIgnoreCase("btn_Reject"))
               {
                    formObject.setNGValue("PaymentSts", "Reject");                                                     
                    formObject.RaiseEvent("WFDone");
                    break;
               } 
               break;
            } 
            case KEY_PRESSED:{break;}
            case FOCUS_GAINED:{break;}
            case FOCUS_LOST:{break;}
            case VALUE_CHANGED:{break;}
            case KEY_DOWN:{break;}            
        }//End of Switch
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) 
    {
       // throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void initialize() 
    {
        //throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
