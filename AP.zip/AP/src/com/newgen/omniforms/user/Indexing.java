/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.approvalmatrix.ApprovalMatrix_VP_PO;
import com.newgen.omniforms.component.PickList;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.sapfunctions.SAPApprovalMatrix;
import com.newgen.omniforms.sapfunctions.SAPFunc;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author deva.r
 */
public class Indexing implements FormListener
{
    AP_CommonFunctions CommonObj = new AP_CommonFunctions();    
    FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
    SAPFunc objSAPFunc= new SAPFunc();
    SAPApprovalMatrix objSAPApprovalMatrix= new SAPApprovalMatrix();
    //VP_Po_ApprovalMatrix1 vp_po_ApprObj=new VP_Po_ApprovalMatrix1();
    ApprovalMatrix_VP_PO objApprovalMatrix_VP_PO=new ApprovalMatrix_VP_PO();
//    SAP_Functions objSAP_Functions= new SAP_Functions();
    private static FacesMessage fm;
    
    @Override
    public void formLoaded(FormEvent fe) 
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        
    }

    @Override
    public void formPopulated(FormEvent fe)  
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        CommonObj.writeToLog(2,"Inside formLoaded Approver1",winame);
        //Below line added bala on 09-12-2016 for clearing Commets on each workstep and button hiding
        formObject.setNGValue("Comments", "");
        formObject.setVisible("btn_submit", true);
        //formObject.setVisible("btn_Travel", false); // cehck and delete the button 
        formObject.setCaption("btn_Reject", "Reject");
        //End
         //Reinitializing Routing flags of Indexing added bala on 05-12-2016
         formObject.setNGValue("IndxSts1", "");//Routed to po/no po check
         formObject.setNGValue("IndxSts2", "");// No pocheck-> if yes routed to Approver1
         //End
         //Approval values clear
         formObject.setNGValue("CurrAppLevel","");
         formObject.setNGValue("MaxAppLevel", "");
         formObject.setNGValue("App1index", "");
         formObject.setNGValue("App2index", "");
         formObject.setNGValue("App3index", "");
         formObject.setNGValue("App4index", "");
         formObject.setNGValue("App5index", "");
         formObject.setNGValue("App6index", "");
         formObject.setNGValue("App7index", "");
         formObject.setNGValue("App8index", "");
         //End
          formObject.setVisible("btn_Approve", false);
        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        CommonObj.writeToLog(2,"ER WS Status="+ER_WS, winame);
        CommonObj.writeToLog(2,"ER WS Status="+ER_WS,winame);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) 
        {
            CommonObj.HideFrames_Init();
            CommonObj.Approval_lock();
           
        } 
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) 
        {
            CommonObj.VP_Frame_Height();
            CommonObj.VP_Frame_lock();
            formObject.setNGValue("CompanyCode", "BIL1");
            //formObject.setNGValue("Region", "BIL1");
            formObject.setVisible("btn_trnsdtl", false);
            formObject.setLeft("btn_Submit", 150);
            formObject.setLeft("btn_Reject", 330);
        }
        else if (ER_WS != null && ER_WS.equalsIgnoreCase("TC")) 
        {
         //CommonObj.TravelCab_Initaition_frm_visible(); 
         //CommonObj.TravelCab_Initaition_frm_enable();
         formObject.setVisible("btn_Exception", true);
         formObject.setVisible("btn_Reject", true);
         String strTypeofinvoice=formObject.getNGValue("TypeOfInvoice");
         String strSubcategory=formObject.getNGValue("SubCategory1");
           if ((strTypeofinvoice != null && !strTypeofinvoice.equalsIgnoreCase("") && !strTypeofinvoice.equalsIgnoreCase("--Select--"))) 
                    {
                        formObject.setEnabled("TypeOfInvoice", false);
                        formObject.setEnabled("SubCategory1", false);
                        formObject.setEnabled("btn_load", false);
                        //CommonObj.TravelCab_Initaition_frm_height();
                        CommonObj.TravelCab_Frames();
                        if(strTypeofinvoice.equalsIgnoreCase("Travel"))
                        {
                          formObject.setVisible("btn_Travel", true);
                          formObject.setEnabled("btn_Travel", true);
                          formObject.setEnabled("btn_Cab", false);
                          formObject.setVisible("btn_Cab", false);
                        }
                        else if(strTypeofinvoice.equalsIgnoreCase("Cab"))
                        {
                          formObject.setVisible("btn_Travel", false);
                          formObject.setEnabled("btn_Travel", false);
                          formObject.setEnabled("btn_Cab", true);
                          formObject.setVisible("btn_Cab", true);        
                        }
                    }
           else 
                    {
                        //writeToLog(2,"Kindly select TypeOfInvoice and SubCategory1 correctly",winame);
                        //System.out.println("Kindly select TypeOfInvoice and SubCategory1 correctly");
                        //CommonObj.TravelCab_Initaition_frm_visible();
                        //CommonObj.TravelCab_Initaition_frm_enable();
                        //CommonObj.TravelCab_Initaition_frm_height();
                        CommonObj.TravelCab_Frames();
                        throw new ValidatorException(new FacesMessage(" Kindly select TypeOfInvoice and SubCategory1 correctly","SubCategory1"));
                        
                    }
         
        }
        formObject.setEnabled("DateOfReq", false);
        //objSAP_Functions.BAPI_POGETDETAILS(formObject, "116684", "456");

    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException 
    {
       
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException 
    {
        CommonObj.InserComments();  
        
    }

    @Override
    public void eventDispatched(ComponentEvent fe) throws ValidatorException 
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        switch (fe.getType()) 
        {
            case VALUE_CHANGED:
             {
                 
                 
                           
       }//ValueChanged end
       case MOUSE_CLICKED:
       {
           //System.out.println("Inside MouseClick");
            CommonObj.writeToLog(2,"inside MouseClick>>>>>>>>>>>>>>>>>>>>>>>",winame);
           //System.out.println("ER_WS=" + ER_WS);
           CommonObj.writeToLog(2,"ER WS"+ER_WS,winame);
           if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) 
           {
            
           } //End of ER process mouse click
           else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) 
           {
               //added by Deva 26/12/2016
                if (fe.getSource().getName().equalsIgnoreCase("btn_load")) 
	        {
                    String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");                    
                    if (strTypeOfprocess.equalsIgnoreCase("PO")) 
                    {
                        CommonObj.VP_Frame_Height();
                        CommonObj.VP_Frame_lock();
                        formObject.setEnabled("TypeOfProcess", false);
                        formObject.setEnabled("btn_load", false);
                    } 
                    else if (strTypeOfprocess.equalsIgnoreCase("NONPO")) 
                    {
                        CommonObj.VP_Frame_Height();
                        CommonObj.VP_Frame_lock();
                        formObject.setEnabled("TypeOfProcess", false);
                        formObject.setEnabled("btn_load", false);
                    }
                }
               if (fe.getSource().getName().equalsIgnoreCase("btn_add_po")) {
                           //System.out.println("Entertainment Add Button");
                           CommonObj.writeToLog(2,"PO lineitem Add Button",winame); 
                           CommonObj.addRow(formObject, "list_po");
                       } else if (fe.getSource().getName().equalsIgnoreCase("btn_mod_po")) {
                          // System.out.println("Entertainment modify Button");
                           CommonObj.writeToLog(2,"PO lineitem modify Button",winame); 
                           CommonObj.modifyRow(formObject, "list_po");
                       } else if (fe.getSource().getName().equalsIgnoreCase("btn_del_po")) {
                           //System.out.println("Entertainment delete Button");
                           CommonObj.writeToLog(2,"PO lineitem delete Button",winame); 
                           CommonObj.deleteRow(formObject, "list_po");
                       } else if (fe.getSource().getName().equalsIgnoreCase("btn_add_nonpo")) {
                          // System.out.println("Travel Add Button");
                           CommonObj.writeToLog(2,"NONPO lineitem Add Button",winame); 
                           CommonObj.addRow(formObject, "list_nonpo");
                       } else if (fe.getSource().getName().equalsIgnoreCase("btn_mod_nonpo")) {
                           //System.out.println("Travel modify Button");
                           CommonObj.writeToLog(2,"NONPO lineitem  modify Button",winame); 
                           CommonObj.modifyRow(formObject, "list_nonpo");
                       } else if (fe.getSource().getName().equalsIgnoreCase("btn_del_nonpo")) {
                           //System.out.println("Travel delete Button");
                           CommonObj.writeToLog(2,"NONPO lineitem  delete Button",winame); 
                           CommonObj.deleteRow(formObject, "list_nonpo");
                       }
               //
               //Check below code to be repalce as VPsts
               if (fe.getSource().getName().equalsIgnoreCase("btn_Reject")) //Incase rejected it was routed to Reject
               {
                   formObject.setNGValue("IndxSts1", "Reject");//Routed to Exit Directly
                   formObject.RaiseEvent("WFDone");
               } else if (fe.getSource().getName().equalsIgnoreCase("btn_Exception")) //Incase rejected it was routed to Reject
               {
                   formObject.setNGValue("IndxSts1", "Exception");//Routed to Exit Directly
                   formObject.RaiseEvent("WFDone");
               } else if (fe.getSource().getName().equalsIgnoreCase("btn_Rescan")) //Incase rejected it was routed to Reject
               {
                   formObject.setNGValue("IndxSts1", "Rescan");//Routed to Exit Directly
                   formObject.RaiseEvent("WFDone");
               }
               if (fe.getSource().getName().equalsIgnoreCase("btn_submit")) {
                    if (formObject.getNGValue("Currency").equalsIgnoreCase(""))
                    {
                        throw new ValidatorException(new FacesMessage("Please Enter the Currency","Currency"));
                    }
                    //System.out.println("Inside ngfuser:btn_submit");
                    CommonObj.writeToLog(2,"Inside ngfuser:btn_submit",winame);
                    formObject.setNGValue("InitSts", "VP");
                    try 
                    {
                        //vp_po_ApprObj.SapReadXml();
                        objApprovalMatrix_VP_PO.SapReadXml();
                    } 
                    catch (FileNotFoundException ex) 
                    {
                        //System.out.println("Exception ="+ex.getMessage());
                        CommonObj.writeToLog(3,"Exception ="+ex.getMessage(),winame);
                    } catch (IOException ex) 
                    {
                        //System.out.println("Exception ="+ex.getMessage());
                        CommonObj.writeToLog(3,"Exception ="+ex.getMessage(),winame);
                    }
                    formObject.setNGValue("IndxSts1", "Yes");
                    formObject.setNGValue("IndxSts2", "Yes");
                    formObject.RaiseEvent("WFDone");                    
                    //throw new ValidatorException(new FacesMessage(" Plrase Enter the Currency","Currency"));                   
                }
               if (fe.getSource().getName().equalsIgnoreCase("btn_SAP_PO")) 
	        {
                   // System.out.println("In btn_load");
                    CommonObj.writeToLog(2,"In btn_load",winame);
                    String strVendorCode=formObject.getNGValue("VendCode");
                    String strPO_NO=formObject.getNGValue("PONumber");
                    if(strPO_NO ==null || strPO_NO =="" || strVendorCode ==null || strVendorCode =="")
                    {
                    throw new ValidatorException(new FacesMessage("Please Enter the PO Number and Vendor Code","PONumber"));                    
                    }   
                    if(formObject.getNGValue("Indicate").equalsIgnoreCase("") || formObject.getNGValue("Indicate").equalsIgnoreCase("--Select--"))
                    {
                    throw new ValidatorException(new FacesMessage("Please select the Indicator","Indicate"));                    
                    }
                    int intPO_NO=strPO_NO.length();
                    int intVendorCode=strVendorCode.length();                   
                     CommonObj.writeToLog(2,"intPO_NO:" +intPO_NO,winame);
                     CommonObj.writeToLog(2,"intVendorCode:" +intVendorCode,winame); 
//                    if(intPO_NO<8){
//                    throw new ValidatorException(new FacesMessage("PO Number sould be minimum 8 digit lenth","PONumber"));                    
//                    }
//                    else 
                    if(intPO_NO<10){
                    strPO_NO=CommonObj.appendzero(intPO_NO, "PONumber");
                    CommonObj.writeToLog(2,"strPO_NO:" +strPO_NO,winame); 
                    }
//                    if(intVendorCode<6){
//                    throw new ValidatorException(new FacesMessage("Vendor Code sould be minimum 6 digit lenth","VendCode"));                    
//                    }
//                    else
                    if(intVendorCode<10){
                    strVendorCode=CommonObj.appendzero(intVendorCode, "VendCode");
                    CommonObj.writeToLog(2,"strVendorCode:" +strVendorCode,winame); 
                    }                    
                    if((strPO_NO.length()==10) && (strVendorCode.length()==10))
                    {                      
                        CommonObj.writeToLog(2,"Po Number and Vendor Code LENGTH  is 10",winame);
                    try {
                        objSAPFunc.ZBAPI_VENDOR_WITH_TAXCODE(strVendorCode);
                        objSAPFunc.BAPI_PODetailsOnload(strVendorCode, strPO_NO,formObject.getNGValue("Indicate"));
                        
                    } catch (Exception ex) {
                        //Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);PONumber
                    }
                    }
                    formObject.setNGValue("FiscalYr",CommonObj.Cur_FinanicalYr());
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_SAP_Vendor")) 
	        {
                    String strVendorCode=formObject.getNGValue("VendCode");
                    if(strVendorCode ==null || strVendorCode =="")
                    {
                    throw new ValidatorException(new FacesMessage("Please Enter the Vendor Code","VendCode"));                    
                    }                    
                    int intVendorCode=strVendorCode.length();
//                    if(intVendorCode<6){
//                    throw new ValidatorException(new FacesMessage("Vendor Code sould be minimum 6 digit lenth","VendCode"));                    
//                    }
//                    else 
                    if(intVendorCode<10){
                    strVendorCode=CommonObj.appendzero(intVendorCode, "VendCode");
                    }
                    if(strVendorCode.length()==10)
                    {
                    try {
                        objSAPFunc.ZBAPI_VENDOR_WITH_TAXCODE(formObject.getNGValue("VendCode"));
                        objSAPFunc.BAPI_VendorDetailsOnload(strVendorCode);
                        
                    } catch (Exception ex) {
                        //Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);PONumber
                    }
                    }
                    formObject.setNGValue("FiscalYr",CommonObj.Cur_FinanicalYr());
                
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_po_down")) 
	        {
                  //  System.out.println("In PO Move Down Click");
                    CommonObj.writeToLog(2,"In PO Move Down Click",winame);
                    try {
                        
                        CommonObj.btnMovedown();
                    } catch (Exception ex) {
                        //Logger.getLogger(Vp.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_po_up")) 
	        {
                    //System.out.println("In PO Move UP Click");
                    CommonObj.writeToLog(2,"In PO Move UP Click",winame);
                    try {
                        CommonObj.btnMoveup();
                    } catch (Exception ex) {
                        //Logger.getLogger(Vp.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (fe.getSource().getName().equalsIgnoreCase("Btn_SAP")) 
	        {
                    //System.out.println("In Btn_SAP Test");
                    CommonObj.writeToLog(2,"In Btn_SAP Test",winame);
                    try {
                        //StringBuffer BAPIInputTest = new StringBuffer();
                        String BAPIInputTest= formObject.getNGValue("Text_SAP_Input");
                        if(BAPIInputTest !=""){
                        objSAPFunc.BAPI_Test(BAPIInputTest);
                        }
                    } catch (Exception ex) {
                        //Logger.getLogger(ER_Initiation.class.getName()).log(Level.SEVERE, null, ex);PONumber
                    }
           
                }
                if (fe.getSource().getName().equalsIgnoreCase("btn_sub")) 
                       {
                            String strTypeOfInvoive=formObject.getNGValue("TypeOfInvoice");
                            formObject.clear("SubCategory1");
                            formObject.setNGValue("SubCategory1","");
                            String querySubCat = "select distinct SubCat1 from EXT_AP_ER_InvoiceSub with(nolock) where process='VP' and SubCat1 IS NOT NULL and SubCat1 !=''";
                            //CommonObj.DBValues_Combo(querySubCat, "SubCategory1"); 
                            PickList objPickList1 = formObject.getNGPickList("btn_sub", "Sub Category1", true, 20, false);
                           objPickList1.setVisible(true);
                           objPickList1.addPickListListener(new EventPickList(objPickList1.getClientId()));
                           objPickList1.setWidth(350);
                           objPickList1.setWidth(350);
                           objPickList1.populateData(querySubCat);                           
                       }
           }//end of VP
           else if(ER_WS != null && ER_WS.equalsIgnoreCase("TC")) //Inside TravelCab Click
           {
               if (fe.getSource().getName().equalsIgnoreCase("btn_submit")) 
               {
                   formObject.setNGValue("IndxSts1", "Yes");//Routed to po/no po check
                   formObject.setNGValue("IndxSts2", "Yes");// No pocheck-> if yes routed to Approver1 
               }
              else if (fe.getSource().getName().equalsIgnoreCase("btn_Reject")) //Incase rejected it was routed to Reject
               {
                   formObject.setNGValue("IndxSts1", "Reject");//Routed to Exit Directly
                   formObject.RaiseEvent("WFDone");
               } else if (fe.getSource().getName().equalsIgnoreCase("btn_Exception")) //Incase rejected it was routed to Reject
               {
                   formObject.setNGValue("IndxSts1", "Exception");//Routed to Exit Directly
                   formObject.RaiseEvent("WFDone");
               } 
//               else if (ce.getSource().getName().equalsIgnoreCase("btn_Rescan")) //Incase rejected it was routed to Reject
//               {
//                   formObject.setNGValue("TCsts", "Rescan");//Routed to Exit Directly
//                   formObject.RaiseEvent("WFDone");
//               }
           }
       } //Mouse Click end
       
               
      }
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) 
    {
        
    }

    @Override
    public void initialize() 
    {
        //Dont add any code over here - product team
    }
    
}
