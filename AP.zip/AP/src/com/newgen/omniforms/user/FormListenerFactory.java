/*      
 '----------------------------------------------------------------------------
 '      NEWGEN SOFTWARE TECHNOLOGIES LIMITED
 '   Group                   : South
 '   Product/Project/Utility : Britannia
 '   Module                  : ngfUser
 '   File Name               : FormListenerFactory.java
 '   Author                  : NanjundaMoorthy
 '   Date created            : 21/11/2016
 '   Description             : This file is for various functions used in Britannia.
 '   ----------------------------------------------------------------------------
 '   CHANGE HISTORY
 '   ----------------------------------------------------------------------------
 '   Date:       Change Number/Bug ID        Change By :     Change Description
 '  
 '   ----------------------------------------------------------------------------
 */

/*
 *
 * @author NanjundaMoorthy
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.user.IFormListenerFactory;

/**
 *
 *  Modified on 23-12-2016
 * @author NanjundaMoorthy  
 */
public class FormListenerFactory implements IFormListenerFactory
{
    FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
    
        
    @Override
    public FormListener getListener() 
    {       
        String processName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ProcessName");

        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName"); 
        
        if (processName.equalsIgnoreCase("AP")) 
        {
            if ((WorkstepName.equalsIgnoreCase("ER_Initiation"))|| (WorkstepName.equalsIgnoreCase("Rework")))
            {
                return new ER_Initiation();
            }
//            else if (WorkstepName.equalsIgnoreCase("Indexing")) 
//            {
//                return new Indexing();
//            }
            else if (WorkstepName.equalsIgnoreCase("Scanning") || WorkstepName.equalsIgnoreCase("Indexing")) 
            {
                return new VP_Scanning();
            }
            else if (WorkstepName.equalsIgnoreCase("Manual_Initiation")) 
            {
                return new TravelCab();
            }
            
            else if (WorkstepName.equalsIgnoreCase("Approver1") || WorkstepName.equalsIgnoreCase("Approver2")||WorkstepName.equalsIgnoreCase("Approver3")||WorkstepName.equalsIgnoreCase("Approver4")||WorkstepName.equalsIgnoreCase("Approver5")||WorkstepName.equalsIgnoreCase("Approver6")||WorkstepName.equalsIgnoreCase("Approver7")
                   ||WorkstepName.equalsIgnoreCase("Approver8")) 
            {
    
                return new Approver1();
            }           
            else if (WorkstepName.equalsIgnoreCase("HR_Verification") || WorkstepName.equalsIgnoreCase("HR_Approval") || WorkstepName.equalsIgnoreCase("MD_Approval")) 
            {
                return new HR_Approval();
            }
            else if (WorkstepName.equalsIgnoreCase("Parking")) 
            {
                return new Park();
            }
            else if (WorkstepName.equalsIgnoreCase("Posting")) 
            {
                return new Post();
            }
            else if (WorkstepName.equalsIgnoreCase("Audit")) 
            {
                return new Audit();
            }
            else if (WorkstepName.equalsIgnoreCase("Payment_Confirmation")) 
            {
                return new PaymentConfirmation();
            }
            else if (WorkstepName.equalsIgnoreCase("Exit")) 
            {
                return new Exit();
            }
            else if (WorkstepName.equalsIgnoreCase("Query")) 
            {
                return new Query();
            }
        }

        return null;
    }
}