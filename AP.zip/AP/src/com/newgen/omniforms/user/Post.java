/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.sapfunctions.*;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author balasubiramani.g This file for handling SAP Posting functionality
 */
public class Post implements FormListener {

    AP_CommonFunctions CommonObj = new AP_CommonFunctions();

    SAPFunc objSAPFunc = new SAPFunc();
    SAPParkER objSAPPark = new SAPParkER();
    SAPParkPO objSAPParkPO = new SAPParkPO();
    SAPDirectPostER objSAPDirectPostER = new SAPDirectPostER();

    @Override
    public void formLoaded(FormEvent fe) {
        //throw new UnsupportedOperationException("Not supported yet.");
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();

        formObject.setVisible("Btn_SAP", true);
        formObject.setVisible("Text_SAP_Input", true);
        formObject.setVisible("Text_SAP_Output", true);

//        formObject.setVisible("btn_SAP_Post", true);//S4P
        formObject.setVisible("Button_SAP", true);//HANA
        formObject.setVisible("SAPUserName", true);
        formObject.setVisible("lbl_SAPUsername", true);
        formObject.setTop("Text_SAP_Input", 170);
        formObject.setTop("Btn_SAP", 170);
        formObject.setTop("Text_SAP_Output", 170);
        formObject.setTop("btn_trnsdtl", 145);
        formObject.setTop("Button_SAP", 145);
        formObject.setTop("btn_Reject", 145);
        formObject.setTop("btn_cmnthsty", 145);
        formObject.setTop("lbl_SAPUsername", 125);
        formObject.setTop("SAPUserName", 125);

        formObject.setEnabled("btn_reverse", true);

        formObject.setVisible("Label33", false);
        formObject.setVisible("ReversalDocNo", false);
        formObject.setVisible("btn_reverse", false);
        formObject.setVisible("Label36", false);
        formObject.setVisible("SapErrorMsg", false);
        formObject.setVisible("Label34", false);
        formObject.setVisible("ClearedBy", false);
        formObject.setVisible("Label30", false);
        formObject.setVisible("ClearingDate", false);
        formObject.setVisible("Label31", false);
        formObject.setVisible("ClearingDocNo", false);
        formObject.setVisible("Label32", false);
        formObject.setVisible("ClearedAmnt", false);
        //formObject.setHeight("frm_parkdtl_po", formObject.getTop("ReversalDocNo") + 30 );
        formObject.setHeight("frm_parkdtl_po", formObject.getTop("PostBySAP") + 30);
    }

    @Override
    public void formPopulated(FormEvent fe) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        //System.out.println("Inside Post FormPopulated");
        CommonObj.writeToLog(2, "Inside Post FormPopulated", winame);
        //Below line added bala on 09-12-2016 for clearing Commets on each workstep
        formObject.setNGValue("Comments", "");
        //formObject.setNGValue("RejectReason","");
        formObject.setVisible("btn_Approve", false);
        formObject.setVisible("btn_Reject", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Rescan", false);
        formObject.setVisible("btn_Travel", false);
        //End

        //Added started by Sivashankar for hiding the Grade 29-June-2018
        String strFlag = "";
        String sqlQuery = "SELECT Value FROM EXT_AP_ER_MASTER_EXTERNALCONSTANTS WITH(NOLOCK) WHERE ColumnName='BLOCKPORTAL'";
        List<List<String>> Flag = formObject.getDataFromDataSource(sqlQuery);
        strFlag = Flag.get(0).get(0);
        CommonObj.writeToLog(2, "sqlQuery ==> " + sqlQuery, winame);
        CommonObj.writeToLog(2, "strFlag ==> " + strFlag, winame);
        if (strFlag.equalsIgnoreCase("YES")) {
            formObject.setVisible("lbl_inv_grade", false);
            formObject.setVisible("Grade", false);
            formObject.setVisible("lbl_inv_design", false);
            formObject.setVisible("Designation", false);
        }
        //Added ended by Sivashankar for hiding the Grade

        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        //System.out.println("ER WS Status=" + ER_WS);
        CommonObj.writeToLog(2, "ER WS Status=" + ER_WS, winame);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) {
            CommonObj.HideFrames_Init();
            CommonObj.Approval_lock();
            //formObject.setLeft("btn_submit", 220);
            formObject.setVisible("btn_submit", false);
//            formObject.setLeft("btn_SAP_Post", 220);//S4P
            formObject.setLeft("Button_SAP", 220);//HANA
            formObject.setNGValue("SAPUserName", formObject.getUserName());
            formObject.setLeft("btn_Reject", 350);
            formObject.setVisible("btn_Reject", true);
            formObject.setCaption("btn_Reject", "Reject");
            formObject.setVisible("txt_totalamount", true);
            formObject.setVisible("TotalAmount", true);
            formObject.setNGBackColor("MMDocNo", new Color(225, 225, 225));
        } else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) {
            CommonObj.VP_Frame_Height();
            CommonObj.VP_Frame_lock();
            formObject.setLeft("btn_submit", 300);
        } else if (ER_WS != null && ER_WS.equalsIgnoreCase("TC")) {

            CommonObj.TravelCab_Frames();
            //formObject.setLeft("btn_submit", 300);
            formObject.setVisible("btn_submit", false);
            formObject.setLeft("Button_SAP", 220);//S4P
//            formObject.setLeft("btn_SAP_Post", 220);
            formObject.setLeft("btn_Reject", 350);
            formObject.setVisible("btn_Reject", true);
            formObject.setCaption("btn_Reject", "Reject");

        }
        formObject.setEnabled("ParkingDate", false);
        formObject.setEnabled("PostingDate", false);
        formObject.setEnabled("ClearingDate", false);
        //formObject.setCaption("btn_submit", "Post");

        formObject.setEnabled("TypeOfInvoice", true);
        String sQuery2 = "SELECT TypeOfInvoice FROM EXT_AP WITH(NOLOCK) WHERE workid = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery2 $$$$$ :: " + sQuery2, winame);
        String val = formObject.getDataFromDataSource(sQuery2).toString();
        val = val.replace("[", "").replace("]", "").trim();
        CommonObj.writeToLog(2, "Val $$$$$ :: " + val, winame);
        formObject.addItem("TypeOfInvoice", val);
        formObject.setNGValue("TypeOfInvoice", val);
        formObject.setEnabled("TypeOfInvoice", false);

        formObject.setEnabled("SubCategory1", true);
        String sQuery = "SELECT SubCategory1 FROM EXT_AP WITH(NOLOCK) WHERE workid = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery $$$$$ :: " + sQuery, winame);
        String val1 = formObject.getDataFromDataSource(sQuery).toString();
        val1 = val1.replace("[", "").replace("]", "").trim();
        CommonObj.writeToLog(2, "val1 $$$$$ :: " + val1, winame);
        formObject.addItem("SubCategory1", val1);
        formObject.setNGValue("SubCategory1", val1);
        formObject.setEnabled("SubCategory1", false);

        //Added by IBPS Support for populating Dropdowns in GRID
        formObject.setEnabled("txt_trvl_fromloc", true);
        String txt_trvl_fromlocsQuery = "select fromloc from EXT_TravelFare1 WITH(NOLOCK) where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery fromloc $$$$$ :: " + txt_trvl_fromlocsQuery, winame);
        String txt_trvl_fromlocval = formObject.getDataFromDataSource(txt_trvl_fromlocsQuery).toString();
        CommonObj.DBValues_Combo(txt_trvl_fromlocsQuery, "txt_trvl_fromloc");
        CommonObj.writeToLog(2, "fromloc val1 $$$$$ :: " + txt_trvl_fromlocval, winame);
        formObject.setEnabled("txt_trvl_fromloc", false);

        formObject.setEnabled("txt_trvl_toloc", true);
        String txt_trvl_tolocsQuery = "select ToLoc from EXT_TravelFare1 WITH(NOLOCK) where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery ToLoc $$$$$ :: " + txt_trvl_tolocsQuery, winame);
        String txt_trvl_tolocval = formObject.getDataFromDataSource(txt_trvl_tolocsQuery).toString();
        CommonObj.DBValues_Combo(txt_trvl_tolocsQuery, "txt_trvl_toloc");
        CommonObj.writeToLog(2, "ToLoc val1 $$$$$ :: " + txt_trvl_tolocval, winame);
        formObject.setEnabled("txt_trvl_toloc", false);
        
        formObject.setEnabled("cb_hotelfare_britannia_statename", true);
        String hotelfare_statenamesQuery = "select BritStateName from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery BritStateName $$$$$ :: " + hotelfare_statenamesQuery, winame);
        String hotelfare_statenameval = formObject.getDataFromDataSource(hotelfare_statenamesQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_statenamesQuery, "cb_hotelfare_britannia_statename");
        CommonObj.writeToLog(2, "BritStateName val1 $$$$$ :: " + hotelfare_statenameval, winame);
        formObject.setEnabled("cb_hotelfare_britannia_statename", false);
        
        formObject.setEnabled("cb_hotelfare_gst_percentage", true);
        String hotelfare_gstsQuery = "select GSTPercentage from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery GSTPercentage $$$$$ :: " + hotelfare_gstsQuery, winame);
        String hotelfare_gstsQueryval = formObject.getDataFromDataSource(hotelfare_gstsQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_gstsQuery, "cb_hotelfare_gst_percentage");
        CommonObj.writeToLog(2, "GSTPercentage val1 $$$$$ :: " + hotelfare_gstsQueryval, winame);
        formObject.setEnabled("cb_hotelfare_gst_percentage", false);
        
        formObject.setEnabled("dp_hotelfare_location", true);
        String hotelfare_locsQuery = "select Location from EXT_HotelFare where PID = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery Location $$$$$ :: " + hotelfare_locsQuery, winame);
        String hotelfare_locsQueryval = formObject.getDataFromDataSource(hotelfare_locsQuery).toString();
        CommonObj.DBValues_Combo(hotelfare_locsQuery, "dp_hotelfare_location");
        CommonObj.writeToLog(2, "Location val1 $$$$$ :: " + hotelfare_locsQueryval, winame);
        formObject.setEnabled("dp_hotelfare_location", false);
        //End of Added by IBPS Support for populating Dropdowns in GRID

        CommonObj.enableDORMailBtn(formObject);
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException {

        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException {
        //throw new UnsupportedOperationException("Not supported yet.");
        CommonObj.InserComments();
    }

    @Override
    public void eventDispatched(ComponentEvent fe) throws ValidatorException {
        //throw new UnsupportedOperationException("Not supported yet.");
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String fieldName = fe.getSource().getName();

        switch (fe.getType()) {
            case MOUSE_CLICKED: {
                if (fieldName.equalsIgnoreCase("btn_reverse")) {
                    CommonObj.writeToLog(2, "In btn_reverse Click", winame);
                    if (formObject.getNGValue("ReversalDocNo").equalsIgnoreCase("")) {
                        String BapiResult = objSAPFunc.ZFI_DOCUMENT_REVERSE("btn_reverse");
                        if (!BapiResult.equalsIgnoreCase("S")) {
                            CommonObj.writeToLog(2, "BAPI result !=SUCCESS in Post.java @ btn_reverse", winame);

                            throw new ValidatorException(new FacesMessage("Reversal in SAP is failed..!!!", ""));
                        } else if (BapiResult.equalsIgnoreCase("S")) {
                            formObject.setNGValue("PostSts", "Reject");
                            formObject.RaiseEvent("WFDone");
                            break;
                        }
                    } else {
                        throw new ValidatorException(new FacesMessage("Reversal is already done..!!!", ""));
                    }
                } else if (fe.getSource().getName().equalsIgnoreCase("btn_SAP_Doc_No")) {
                    CommonObj.writeToLog(2, "In btn_SAP_Doc_No Click", winame);
                    //Modified By Harinath on 2017/06/14
                    try {
                        objSAPPark.Parking_DocumentNo(formObject.getNGValue("MMDocNo"), formObject.getNGValue("FiscalYr"), formObject.getNGValue("CompanyCode"));
                    } catch (Exception ex) {
                        CommonObj.writeToLog(3, "Exception in btn_SAP_Doc_No: " + ex.getMessage(), winame);
                    }
                    //Ended By Harinath on 2017/06/14
                } else if (fieldName.equalsIgnoreCase("btn_SAP_Post")) {
                    formObject.setVisible("btn_submit", true);
                    formObject.setLeft("btn_submit", 220);
                    formObject.setLeft("btn_SAP_Post", 160);
                } else if (fieldName.equalsIgnoreCase("Button_SAP"))//S4P
                {
                    formObject.setVisible("btn_submit", true);
                    formObject.setLeft("btn_submit", 220);
                    formObject.setLeft("Button_SAP", 160);
                    formObject.setTop("btn_submit", 145);
                } else if (fieldName.equalsIgnoreCase("btn_Reject")) {
                    formObject.setNGValue("PostStsSAP", "Reject");
                    formObject.RaiseEvent("WFDone");
                } else if (fieldName.equalsIgnoreCase("btn_submit")) {

                    if (formObject.getNGValue("SAPDocRefNo") != "") {
                        //Modified By Harinath on 2017/06/14
                        try {
                            objSAPPark.Parking_DocumentNo(formObject.getNGValue("SAPDocRefNo"), formObject.getNGValue("FiscalYr"), formObject.getNGValue("CompanyCode"));
                        } catch (Exception ex) {
                            CommonObj.writeToLog(3, "Exception in btn_SAP_Doc_No: " + ex.getMessage(), winame);
                        }
                        //Ended By Harinath on 2017/06/14
                        CommonObj.writeToLog(2, "In btn_submit Click", winame);
                        //HANA
                        if (formObject.getNGValue("PostBySAP").equalsIgnoreCase(null) || formObject.getNGValue("PostBySAP").equalsIgnoreCase("")) {
                            CommonObj.writeToLog(2, "In RFC - Document Number", winame);
//                            formObject.setNGValue("PostBySAP", formObject.getUserName());
                            throw new ValidatorException(new FacesMessage("Document is not Posted in SAP \n Kindly post the document in SAP and submit", ""));
                        }
                        if (!formObject.getNGValue("ReversalDocNo").equalsIgnoreCase("")) {
                            formObject.setNGValue("PostStsSAP", "Reject");
                            formObject.RaiseEvent("WFDone");
                        } else if (formObject.getNGValue("ReversalDocNo").equalsIgnoreCase("") && formObject.getNGValue("PostBySAP") != "") {

                            //------------Underlined Code------------
//                            formObject.setNGValue("PostStsSAP", "Yes");
//                            formObject.RaiseEvent("WFDone");
                            //------------Underlined Code------------
                            //NOTE: Please follow below steps, While moving IT45 functionality to PDR
                            //      1.Comment the above underlined code
                            //      2.Uncomment the below code and deploy
                            //---------- code and deploy ---------
                            CommonObj.writeToLog(2, " ReversalDocNo is null ::: " + formObject.getNGValue("ReversalDocNo") + "  PostBySAP::: " + formObject.getNGValue("PostBySAP"), winame);
                            if (formObject.getNGValue("SubCategory1").equalsIgnoreCase("Salary Advance")
                                    || formObject.getNGValue("SubCategory1").equalsIgnoreCase("House Rent Advance") || formObject.getNGValue("SubCategory1").equalsIgnoreCase("Exceptional Advances")) {
                                if (!formObject.getNGValue("TotalAmount").equalsIgnoreCase("") && !formObject.getNGValue("RepaymentSchedule").equalsIgnoreCase("")) {
                                    if (((Float.parseFloat(formObject.getNGValue("TotalAmount"))) / (Float.parseFloat(formObject.getNGValue("RepaymentSchedule")))) <= 100000.00) {// Modified by Sivashankar KS on 7th May 2019 as 50000/- to 100000/-

                                        boolean bVal = false;
                                        try {
                                            bVal = objSAPPark.updateLoanDataInSAP(formObject);
                                        } catch (Exception ex) {
                                            Logger.getLogger(Post.class.getName()).log(Level.SEVERE, null, ex);
                                            CommonObj.writeToLog(3, "ERROR:: Exception while executing updateLoanData() method" + ex.getMessage(), winame);
                                            throw new ValidatorException(new FacesMessage("Exception occured while posting loan data into SAP... Please contact administrator", ""));
                                        }
                                        if (bVal == true) {
                                            formObject.setNGValue("PostStsSAP", "Yes");
                                            formObject.RaiseEvent("WFDone");
                                        } else {
                                            CommonObj.writeToLog(3, "ERROR:: ERROR while executing updateLoanData() method.... bVal::: " + bVal, winame);
                                            throw new ValidatorException(new FacesMessage("Error occured while posting loan data into SAP... Please contact administrator", ""));
                                        }
                                    } else {

                                        CommonObj.writeToLog(3, "ERROR:: EMI amount should not br more than Rs.100000/- as there is a validation in SAP ", winame);
                                        throw new ValidatorException(new FacesMessage("Not able to update the data in SAP as there is no authorization to update amount more than Rs. 100000/-", ""));
                                    }
                                } else {
                                    CommonObj.writeToLog(3, "ERROR:: Total Amount and Repayment Schdeble(EMI months) should not be null", winame);
                                    throw new ValidatorException(new FacesMessage("Please enter Total Amount and EMI months...", ""));
                                }
                            } else {
                                formObject.setNGValue("PostStsSAP", "Yes");
                                formObject.RaiseEvent("WFDone");
                            }

                            //---------- code and deploy ---------
                        } else {
                            throw new ValidatorException(new FacesMessage("SAP document reference number: " + formObject.getNGValue("SAPDocRefNo") + " is still posting pending in SAP", "PostBySAP"));
                        }
                    } else if (formObject.getNGValue("SAPDocRefNo") == "") {
                        CommonObj.writeToLog(2, "Inside Direct Posting", winame);
                        String BapiResult = objSAPDirectPostER.NONPO_DirectPosting(winame);
                        if (!BapiResult.equalsIgnoreCase("SUCCESS")) {
                            CommonObj.writeToLog(2, "BAPI result !=SUCCESS in Post.java", winame);
                            throw new ValidatorException(new FacesMessage("Posting in SAP is failed..!!!", ""));

                        }

                    }
                }// End of Submit
            }
            case KEY_PRESSED: {
                break;
            }
            case FOCUS_GAINED: {
                break;
            }
            case FOCUS_LOST: {
                break;
            }
            case VALUE_CHANGED: {
                break;
            }
            case KEY_DOWN: {
                break;
            }
        }//End of Switch
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) {
        // throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void initialize() {
        //throw new UnsupportedOperationException("Not supported yet.");
    }

}
