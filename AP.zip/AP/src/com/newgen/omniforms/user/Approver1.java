/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import java.util.HashMap;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author balasubiramani.g This call File for handling Approver Workstep
 */
public class Approver1 implements FormListener {

    AP_CommonFunctions CommonObj = new AP_CommonFunctions();

    @Override
    public void formLoaded(FormEvent fe) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
    }

    @Override
    public void formPopulated(FormEvent fe) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
        //System.out.println("Inside formLoaded Approver1");
        CommonObj.writeToLog(2, "Inside formLoaded Approver1", winame);
        //Below line added bala on 09-12-2016 for clearing Commets on each workstep
        formObject.setNGValue("Comments", "");
        //formObject.setNGValue("RejectReason","");
        formObject.setVisible("btn_submit", false);
        formObject.setVisible("btn_Exception", false);
        formObject.setVisible("btn_Travel", false);
        formObject.setVisible("btn_Rescan", false);
        //End
        formObject.setVisible("Label10", false);
        formObject.setVisible("Label9", false);
        formObject.setVisible("Label11", false);
        formObject.setVisible("Text25", false);
        formObject.setVisible("Text26", false);
        formObject.setVisible("Combo6", false);
        //formObject.setHeight("frm_approval", 90);
        //Added started by Sivashankar for hiding the Grade 29-June-2018
        String strFlag = "";
        String sqlQuery = "SELECT Value FROM EXT_AP_ER_MASTER_EXTERNALCONSTANTS WITH(NOLOCK) WHERE ColumnName='BLOCKPORTAL'";
        List<List<String>> Flag = formObject.getDataFromDataSource(sqlQuery);
        strFlag = Flag.get(0).get(0);
        CommonObj.writeToLog(2, "sqlQuery ==> " + sqlQuery, winame);
        CommonObj.writeToLog(2, "strFlag ==> " + strFlag, winame);
        if (strFlag.equalsIgnoreCase("YES")) {
            formObject.setVisible("lbl_inv_grade", false);
            formObject.setVisible("Grade", false);
            formObject.setVisible("lbl_inv_design", false);
            formObject.setVisible("Designation", false);
        }
        //Added ended by Sivashankar for hiding the Grade
        //Added by Sivashankar KS on 29-Oct-2019 NOTE: To set the priority for the claims of employee who is working in notice period
        if (!formObject.getNGValue("ResigDate").equalsIgnoreCase("") || !formObject.getNGValue("LastWorkngDate").equalsIgnoreCase("")) {

            formObject.saveDataIntoDataSource("Update WFINSTRUMENTTABLE set PriorityLevel=4 where processInstanceId='" + winame + "'");
        }
        //Ended by Sivashankar KS on 29-Oct-2019 NOTE: To set the priority for the claims of employee who is working in notice period                                

        String ER_WS = formObject.getNGValue("InitSts"); //if InitSts value=ER , these to be from ER Initiation
        //System.out.println("ER WS Status=" + ER_WS);
        CommonObj.writeToLog(2, "ER WS Status=" + ER_WS, winame);
        if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) {
            CommonObj.HideFrames_Init();
            CommonObj.Approval_lock();
            formObject.setLeft("btn_Approve", 220);
            formObject.setLeft("btn_Reject", 350);
            if (!strTypeofinvoice.equalsIgnoreCase("Travel Request")) {
                formObject.setVisible("txt_totalamount", true);
                formObject.setVisible("TotalAmount", true);
            }

        } else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) {
            CommonObj.VP_Frame_Height();
            CommonObj.VP_Frame_lock();
            formObject.setVisible("btn_trnsdtl", false);
            formObject.setLeft("btn_Reject", 330);

        } else if (ER_WS != null && ER_WS.equalsIgnoreCase("TC")) {

            CommonObj.TravelCab_Frames();
            formObject.setVisible("btn_Approve", true);
            formObject.setVisible("btn_Reject", true);

        }
        
        formObject.setEnabled("TypeOfInvoice", true);
        String sQuery2 = "SELECT TypeOfInvoice FROM EXT_AP WITH(NOLOCK) WHERE workid = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery2 $$$$$ :: " + sQuery2, winame);
        String val = formObject.getDataFromDataSource(sQuery2).toString();
        val = val.replace("[", "").replace("]", "").trim();
        CommonObj.writeToLog(2, "Val $$$$$ :: " + val, winame);
        formObject.addItem("TypeOfInvoice", val);
        formObject.setNGValue("TypeOfInvoice", val);
        formObject.setEnabled("TypeOfInvoice", false);
        
        formObject.setEnabled("SubCategory1", true);
        String sQuery = "SELECT SubCategory1 FROM EXT_AP WITH(NOLOCK) WHERE workid = '" + winame + "'";
        CommonObj.writeToLog(2, "sQuery $$$$$ :: " + sQuery, winame);
        String val1 = formObject.getDataFromDataSource(sQuery).toString();
        val1 = val1.replace("[", "").replace("]", "").trim();
        CommonObj.writeToLog(2, "val1 $$$$$ :: " + val1, winame);
        formObject.addItem("SubCategory1", val1);
        formObject.setNGValue("SubCategory1", val1);
        formObject.setEnabled("SubCategory1", false);

        CommonObj.enableDORMailBtn(formObject);
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        CommonObj.writeToLog(2, "saveFormStarted in Approver1", winame);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        CommonObj.writeToLog(2, "saveFormCompleted in Approver1", winame);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();

    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        CommonObj.writeToLog(2, "submitFormStarted in Approver1", winame);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        CommonObj.writeToLog(2, "submitFormCompleted in Approver1", winame);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        CommonObj.InserComments();
    }

    @Override
    public void eventDispatched(ComponentEvent ce) throws ValidatorException {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        // CommonObj.writeToLog(2, "eventDispatched in Approver1", winame);
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String WorkstepName = FormContext.getCurrentInstance().getFormConfig().getConfigElement("ActivityName");
        String strTypeOfprocess = formObject.getNGValue("TypeOfProcess");
        switch (ce.getType()) {
            case MOUSE_CLICKED: {
                CommonObj.writeToLog(2, "MOUSE_CLICKED in Approver1", winame);
                if (ce.getSource().getName().equalsIgnoreCase("btn_Reject")) {
                    CommonObj.writeToLog(2, "Inside ngfuser:btn_Reject", winame);
                    formObject.setNGValue("ApprSts1", "Reject");
                    formObject.RaiseEvent("WFDone");
                } else if (ce.getSource().getName().equalsIgnoreCase("Btn_Approve")) {
                    String ER_WS = formObject.getNGValue("InitSts");
                    Integer Cur_Appr_Lvl = 0;
                    Integer Max_Appr_Lvl = 0;
                    Integer Next_Appr_Lvl = 0;

                    Cur_Appr_Lvl = Integer.parseInt(formObject.getNGValue("CurrAppLevel"));
                    Max_Appr_Lvl = Integer.parseInt(formObject.getNGValue("MaxAppLevel"));
                    if (ER_WS != null && ER_WS.equalsIgnoreCase("ER")) {
                        //MaxAppLevel
                        //CurrAppLevel
                        //System.out.println("Inside Btn_Approve");
                        CommonObj.writeToLog(2, "Inside Btn_Approve in Approver1", winame);

                        String strTypeOfInvoive = "";
                        strTypeOfInvoive = formObject.getNGValue("TypeOfInvoice");
                        CommonObj.writeToLog(2, "strTypeOfInvoive==" + strTypeOfInvoive, winame);
                        if (strTypeOfInvoive.equalsIgnoreCase("Travel Request")) {
                            formObject.setNGValue("ApprSts1", "Approved");
                            formObject.RaiseEvent("WFDone");
                            break;
                        } else if (strTypeOfInvoive.equalsIgnoreCase("Travel Expense")) {
                            //formObject.setNGValue("ApprSts1", "Completed");
                            //formObject.setNGValue("ApprSts2", "No");
                            formObject.setNGValue("ApprSts1", "Approved");
                            formObject.RaiseEvent("WFDone");
                            break;
                        } else if (strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) {

//                            if ((Max_Appr_Lvl != 0) && Cur_Appr_Lvl == Max_Appr_Lvl) {
//                            formObject.setNGValue("ApprSts1", "Completed");
//                            formObject.setNGValue("ApprSts2", "No");                            
//                            }else{
//                            formObject.setNGValue("ApprSts1", "Pending");                                   
//                            }
                            formObject.setNGValue("ApprSts1", "Approved");
                            formObject.RaiseEvent("WFDone");
                            break;
                        } else if (strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others")) {
                            formObject.setNGValue("ApprSts1", "Approved");
                            formObject.RaiseEvent("WFDone");
                            break;
                        } else {
                            //throw new ValidatorException(new FacesMessage("TypeOfInvoice is not matchecd", ""));
                            //break;
                        }

                        String App_Status_Amt = "NextLevel";

                        Next_Appr_Lvl = Cur_Appr_Lvl + 1;
                        //System.out.println("Current Level=" + Cur_Appr_Lvl + ";Max Appr level" + Max_Appr_Lvl);
                        CommonObj.writeToLog(2, "Current Level=" + Cur_Appr_Lvl + ";Max Appr level" + Max_Appr_Lvl, winame);
                        //System.out.println("Cur_Appr_Lvl=" + Cur_Appr_Lvl);
                        CommonObj.writeToLog(2, "Cur_Appr_Lvl=" + Cur_Appr_Lvl, winame);
                        //Added Bala on 24-12-2016
                        String Grades_limit = formObject.getNGValue("Grade_Test");
                        CommonObj.writeToLog(2, "Grade_Text Value=" + Grades_limit, winame);
                        String Grade_Val[] = Grades_limit.split("~");
                        Float fTotal = Float.parseFloat(formObject.getNGValue("TotalAmount"));
                        //
                        //Added bala on 24-12-2016 below code logic calculation of total amount to be compared with Current approver max limit amount

                        if (strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) {
//                            CommonObj.writeToLog(2, "Cur_Appr_Lvl level =" + Cur_Appr_Lvl, winame);
//                            CommonObj.writeToLog(2, "Cur_Appr Grade =" + Grade_Val[Cur_Appr_Lvl - 1], winame);
//                            System.out.println("Cur_Appr Grade =" + Grade_Val[Cur_Appr_Lvl - 1]);
//                            String qGradeTotal="select ApproverLimit from EXT_AP_AmountCalculation with(nolock) where Grade='"+ Grade_Val[Cur_Appr_Lvl - 1]+"'";
//                            CommonObj.writeToLog(2, "qGradeTotal =" + qGradeTotal, winame);
//                            String[] strApprLimit= CommonObj.DB_QueryExecute(qGradeTotal);
//                            CommonObj.writeToLog(2, "strApprLimit =" + strApprLimit[0], winame);

                            if (fTotal <= Float.parseFloat(Grade_Val[Cur_Appr_Lvl - 1])) {
                                App_Status_Amt = "Approved";  //Move to park
                            } else {
                                App_Status_Amt = "NextLevel";  //Move to next level approver
                            }
                        }
                        //Above case toatl amount leseer than current approver amount max limit it wouild be moved to Park directly
                        //

                        if ((Max_Appr_Lvl != 0) && Cur_Appr_Lvl == Max_Appr_Lvl) {
                            //Last Approver
                            CommonObj.writeToLog(2, "Last Approver level =" + Cur_Appr_Lvl, winame);
                            CommonObj.Move_Park();
                        } else if (Cur_Appr_Lvl == 1) //App1index
                        {
                            if (formObject.getNGValue("App2index") != null && !formObject.getNGValue("App2index").equalsIgnoreCase("NoEntry")) {
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    formObject.setNGValue("ApprSts1", "Pending");
                                    formObject.RaiseEvent("WFDone");
                                }

                            } else {
                                //System.out.println("Approver ID invalid");
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    CommonObj.writeToLog(2, Next_Appr_Lvl + "Approver ID invalid", winame);
                                    throw new ValidatorException(new FacesMessage("" + Next_Appr_Lvl + "-level Approver ID Not Available in DMS", ""));
                                }
                            }
                        } else if (Cur_Appr_Lvl == 2) {
                            if (formObject.getNGValue("App3index") != null && !formObject.getNGValue("App3index").equalsIgnoreCase("NoEntry")) {
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    formObject.setNGValue("ApprSts1", "Pending");
                                    formObject.RaiseEvent("WFDone");
                                }

                            } else {
                                //System.out.println("Approver ID invalid");
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    CommonObj.writeToLog(2, Next_Appr_Lvl + "Approver ID invalid", winame);
                                    throw new ValidatorException(new FacesMessage("" + Next_Appr_Lvl + "-level Approver ID Not Available in DMS", ""));
                                }
                            }

                        } else if (Cur_Appr_Lvl == 3) {
                            if (formObject.getNGValue("App4index") != null && !formObject.getNGValue("App4index").equalsIgnoreCase("NoEntry")) {
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    formObject.setNGValue("ApprSts1", "Pending");
                                    formObject.RaiseEvent("WFDone");
                                }

                            } else {
                                //System.out.println("Approver ID invalid");
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    CommonObj.writeToLog(2, Next_Appr_Lvl + "Approver ID invalid", winame);
                                    throw new ValidatorException(new FacesMessage("" + Next_Appr_Lvl + "-level Approver ID Not Available in DMS", ""));
                                }
                            }

                        } else if (Cur_Appr_Lvl == 4) {
                            if (formObject.getNGValue("App5index") != null && !formObject.getNGValue("App5index").equalsIgnoreCase("NoEntry")) {
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    formObject.setNGValue("ApprSts1", "Pending");
                                    formObject.RaiseEvent("WFDone");
                                }

                            } else {
                                //System.out.println("Approver ID invalid");
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    CommonObj.writeToLog(2, Next_Appr_Lvl + "Approver ID invalid", winame);
                                    throw new ValidatorException(new FacesMessage("" + Next_Appr_Lvl + "-level Approver ID Not Available in DMS", ""));
                                }
                            }

                        } else if (Cur_Appr_Lvl == 5) {
                            if (formObject.getNGValue("App6index") != null && !formObject.getNGValue("App6index").equalsIgnoreCase("NoEntry")) {
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    formObject.setNGValue("ApprSts1", "Pending");
                                    formObject.RaiseEvent("WFDone");
                                }

                            } else {
                                //System.out.println("Approver ID invalid");
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    CommonObj.writeToLog(2, Next_Appr_Lvl + "Approver ID invalid", winame);
                                    throw new ValidatorException(new FacesMessage("" + Next_Appr_Lvl + "-level Approver ID Not Available in DMS", ""));
                                }
                            }

                        } else if (Cur_Appr_Lvl == 6) {
                            if (formObject.getNGValue("App7index") != null && !formObject.getNGValue("App7index").equalsIgnoreCase("NoEntry")) {
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    formObject.setNGValue("ApprSts1", "Pending");
                                    formObject.RaiseEvent("WFDone");
                                }

                            } else {
                                //System.out.println("Approver ID invalid");
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    CommonObj.writeToLog(2, Next_Appr_Lvl + "Approver ID invalid", winame);
                                    throw new ValidatorException(new FacesMessage("" + Next_Appr_Lvl + "-level Approver ID Not Available in DMS", ""));
                                }
                            }

                        } else if (Cur_Appr_Lvl == 7) {
                            if (formObject.getNGValue("App8index") != null && !formObject.getNGValue("App8index").equalsIgnoreCase("NoEntry")) {
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    formObject.setNGValue("ApprSts1", "Pending");
                                    formObject.RaiseEvent("WFDone");
                                }

                            } else {
                                //System.out.println("Approver ID invalid");
                                if ((strTypeOfInvoive.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeOfInvoive.equalsIgnoreCase("Entertainment & Others") || strTypeOfInvoive.equalsIgnoreCase("Employee Advances") || strTypeOfInvoive.equalsIgnoreCase("Relocation")) && (App_Status_Amt != null && !App_Status_Amt.equals("") && App_Status_Amt.equalsIgnoreCase("Approved"))) {
                                    CommonObj.Move_Park(); //WF_Done
                                } else {
                                    CommonObj.writeToLog(2, Next_Appr_Lvl + "Approver ID invalid", winame);
                                    throw new ValidatorException(new FacesMessage("" + Next_Appr_Lvl + "-level Approver ID Not Available in DMS", ""));
                                }
                            }

                        } else {
                            CommonObj.writeToLog(3, "Error in ER Approval matrix", winame);
                        }

                    }//End of ER
                    else if (ER_WS != null && ER_WS.equalsIgnoreCase("VP")) {
                        formObject.setNGValue("ApprSts2", "No");
                        if (strTypeOfprocess.equalsIgnoreCase("PO")) {
                            Cur_Appr_Lvl = Integer.parseInt(formObject.getNGValue("CurrAppLevel"));
                            Max_Appr_Lvl = Integer.parseInt(formObject.getNGValue("MaxAppLevel"));
                            Next_Appr_Lvl = Cur_Appr_Lvl + 1;
                            CommonObj.writeToLog(2, "PO  Max_Appr_Lvl level =" + Max_Appr_Lvl, winame);
                            if ((Max_Appr_Lvl != 0) && Cur_Appr_Lvl == Max_Appr_Lvl) {
                                //Last Approver
                                CommonObj.writeToLog(2, "PO  Last Approver level =" + Cur_Appr_Lvl, winame);
                                //CommonObj.Move_Park();
                                formObject.setNGValue("ApprSts1", "Completed");
                                formObject.setNGValue("ApprSts2", "No"); //Move for Park
                                CommonObj.writeToLog(2, "PO  Routing to Park>>>>", winame);
                                formObject.RaiseEvent("WFDone");
                                break;
                            }
                        }

                        CommonObj.writeToLog(2, "VP after PO Validation", winame);
                        if (WorkstepName.equalsIgnoreCase("Approver8")) {
                            formObject.setNGValue("ApprSts1", "Approved");
                            formObject.RaiseEvent("WFDone");
                        } else {
                            formObject.setNGValue("ApprSts1", "Pending");
                            CommonObj.writeToLog(2, "VP Moving to Next Approval level", winame);
                            formObject.RaiseEvent("WFDone");
                        }
                    }//End of VP
                    else if (ER_WS != null && ER_WS.equalsIgnoreCase("TC")) {
                        formObject.setNGValue("ApprSts2", "No");
                        formObject.setNGValue("ApprSts1", "Approved");
                        formObject.RaiseEvent("WFDone");
                    }
                }//End of Submit
                break;

            }
            case KEY_PRESSED: {
                //CommonObj.writeToLog(2, "KEY_PRESSED in Approver1", winame);
                //System.out.println("KEY_PRESSED");
                break;
            }
            case FOCUS_GAINED: {
                //CommonObj.writeToLog(2, "FOCUS_GAINED in Approver1", winame);
                //System.out.println("FOCUS_GAINED");
                break;
            }
            case VALUE_CHANGED: {
                //CommonObj.writeToLog(2, "VALUE_CHANGED in Approver1", winame);
                break;
            }
        }
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
    }

    @Override
    public void initialize() {
    }
}
