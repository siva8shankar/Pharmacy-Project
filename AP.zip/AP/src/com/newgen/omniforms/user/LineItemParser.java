/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.user;

/**
 *
 */
import java.io.StringReader;
import java.util.LinkedList;
import java.util.List;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Nanjundamoorthy
 */
public class LineItemParser extends DefaultHandler {

    private List<List<String>> lineItems = new LinkedList<List<String>>();
    private List<String> currentRow;
    private boolean insideSubItem = false;
    private String currentValue = "";

    @Override
    public void startElement(String uri, String localName,
            String qName, Attributes attributes)
            throws SAXException {
        if (qName.equalsIgnoreCase("Listitem")) {
            currentRow = new LinkedList();
        } else if (qName.equalsIgnoreCase("subitem")) {
            insideSubItem = true;
            currentValue = "";
        }
    }

    @Override
    public void endElement(String uri, String localName,
            String qName)
            throws SAXException {
        if (qName.equalsIgnoreCase("Listitem")) {
            lineItems.add(currentRow);
        } else if (qName.equalsIgnoreCase("subitem")) {
            currentRow.add(currentValue);
            insideSubItem = false;
        }
    }

    @Override
    public void characters(char ch[], int start, int length)
            throws SAXException {
        if (insideSubItem) {
            currentValue = new String(ch, start, length);
        }
    }

    public List<List<String>> getLineItems(String xml) {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            saxParser.parse(new InputSource(new StringReader(xml)), this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lineItems;
    }
}
