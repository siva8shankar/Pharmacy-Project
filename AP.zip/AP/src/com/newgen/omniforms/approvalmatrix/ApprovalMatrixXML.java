/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.approvalmatrix;

/**
 *
 * @author ngappadmin
 */
import com.newgen.dmsapi.DMSXmlList;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author balasubiramani.g
 * This file for ER Approval matrix
 */
public class ApprovalMatrixXML implements FormListener
{

AP_CommonFunctions CommonObj=new AP_CommonFunctions();

    public void SapReadXml() throws FileNotFoundException, IOException
    {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String sXMLFilePath="C:\\coding\\Bala\\SAP.xml";
        //System.out.println("File path="+sXMLFilePath);
        CommonObj.writeToLog(2,"File path="+sXMLFilePath,winame);
       // DMSXmlList centerList=null;
        File fXmlFile = new File(sXMLFilePath);
        Reader fileReader = new FileReader(fXmlFile);
        BufferedReader bufReader = new BufferedReader(fileReader);
        StringBuilder sb = new StringBuilder();
        String line = bufReader.readLine();
        while( line != null)
        {
            sb.append(line);
            line = bufReader.readLine();
        }
        String SAP_XML=sb.toString();
        WFXmlResponse xmlresponse = new WFXmlResponse(SAP_XML.trim());
        WFXmlList xmlList = xmlresponse.createList("TableParameters", "IT_PERNR_DET");
        int i= 0;int maxlevel=0;
        String Appr_name="";
        Map<String,String> Appr_Matrix=new HashMap<String, String>();
        Appr_Matrix.clear();
        String Approvers_name="";String Squery="";String OtherValues="";
        String L1="";String L2="";String L3="";String L4="";String L5="";String L6="";String L7="";String L8="";
        String UserIndex="";String UserIndexRet[]=null;
        String list12="";
                for (; xmlList.hasMoreElements(true); xmlList.skip(true)) 
                {
                    if(i==0)
                    {
                        CommonObj.writeToLog(2,"Logged user info need to skip this step",winame);
                        //System.out.println("Logged user info need to skip this step"); 
                    }
                    else
                    {
                        CommonObj.writeToLog(2,"level="+i+"***Corresponding ApproverLevel="+xmlList.getVal("LEVEL1")+"****And Approver ID="+xmlList.getVal("REPORT_MNGR_NAME"),winame);
                        //System.out.println("level="+i+"***Corresponding ApproverLevel="+xmlList.getVal("LEVEL1")+"****And Approver ID="+xmlList.getVal("REPORT_MNGR_NAME"));
                        Appr_name=xmlList.getVal("REPORT_MNGR_NAME");
//                        if(Appr_name!=null && !Appr_name.equalsIgnoreCase("")) //Commeted it will skip the approver if null
//                        {
//                            Approvers_name+=xmlList.getVal("REPORT_MNGR_NAME")+"~";
//                            OtherValues+=xmlList.getVal("LEVEL1")+"~~"+"~~Level="+i+"~~"+xmlList.getVal("REPORT_MNGR_NAME")+"~~Designation"+xmlList.getVal("GRADE_TEXT")+";;;";
//                        }
//                        else
//                        {                   
//                            System.out.println("No approvers found for current level="+i);
//                            Appr_name="NoEntry";
//                        }
                        if (Appr_name != null && !Appr_name.equalsIgnoreCase("")) //Normal case
                        {
                            Approvers_name += xmlList.getVal("REPORT_MNGR_NAME") + "~";
                            OtherValues += xmlList.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + xmlList.getVal("REPORT_MNGR_NAME") + "~~Designation" + xmlList.getVal("GRADE_TEXT") + ";;;";
                        }
                        else //in case approver is null it would be consider as no approver
                        {
                            //System.out.println("Inside No Approvers");
                            CommonObj.writeToLog(2,"Inside No Approvers",winame);
                            Appr_name = "NoApprovers";
                            Approvers_name += Appr_name+ "~";
                            OtherValues += xmlList.getVal("LEVEL1") + "~~" + "~~Level=" + i + "~~" + Appr_name + "~~Designation" + xmlList.getVal("GRADE_TEXT") + ";;;";
                        }
                    }
                   
                    i++;
                  
                }
                CommonObj.writeToLog(2,"Others Details="+OtherValues,winame);
                CommonObj.writeToLog(2,"Aprpovers Name="+Approvers_name,winame);
                //System.out.println("Others Details="+OtherValues);
               // System.out.println("Aprpovers Name="+Approvers_name);
                 String a1[]=Approvers_name.split("~");
                 maxlevel=a1.length;
                 //System.out.println("Approver matrix maxlevel="+maxlevel);
                 CommonObj.writeToLog(2,"Approver matrix maxlevel="+maxlevel,winame);
                 formObject.setNGValue("MaxAppLevel", maxlevel);
                 Squery="SELECT userindex FROM PDBUser WITH(NOLOCK) WHERE UserName=";
                 for(String a:a1)
                  {
                      UserIndex=CommonObj.DB_QueryExecute1(Squery+"'"+a.trim()+"'");
                      if(maxlevel==i) // Last element
                      list12+=UserIndex.toString();
                      else // Other elements
                       list12+=UserIndex.toString()+"~";
                      i++;
                  }
                 //System.out.println("list of index="+list12);
                 CommonObj.writeToLog(2,"list of index="+list12,winame);
                 String App_Index[]=list12.split("~");
                 int j=1;
                // System.out.println("App_Index size="+App_Index.length);
                 CommonObj.writeToLog(2,"App_Index size="+App_Index.length,winame);
                 for(String Index1:App_Index) //Approval MATRIX Assign
                 {
                     //System.out.println("Inside App Matrix set function="+Index1);
                     CommonObj.writeToLog(2,"Inside App Matrix set function="+Index1,winame);
                     if(j==1)
                         formObject.setNGValue("App1index", Index1);
                     else if(j==2)
                         formObject.setNGValue("App2index", Index1);
                     else if(j==3)
                         formObject.setNGValue("App3index", Index1);
                     else if(j==4)
                         formObject.setNGValue("App4index", Index1);
                     else if(j==5)
                         formObject.setNGValue("App5index", Index1);
                     else if(j==6)
                         formObject.setNGValue("App6index", Index1);
                     else if(j==7)
                         formObject.setNGValue("App7index", Index1);
                      else if(j==8)
                         formObject.setNGValue("App8index", Index1);
                     j++;
                 }
                 //System.out.println("After Approval matrix set");
                 CommonObj.writeToLog(2,"After Approval matrix set",winame);
    }
        catch(Exception e)
        {
            CommonObj.writeToLog(3,"Error inApproval Matrix="+e.getMessage(),winame);
            //System.out.println("Error inApproval Matrix="+e.getMessage());
        }
    }
    @Override
    public void formLoaded(FormEvent fe) 
    {
        
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void eventDispatched(ComponentEvent ce) throws ValidatorException 
    {
        
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) 
    {
        
    }

    @Override
    public void initialize() 
    {
       
    }

}
