/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.approvalmatrix;

/**
 *
 * @author ngappadmin
 */
import com.newgen.dmsapi.DMSXmlList;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author Nanjundamoorthy.B
 * This file for VP-AP Approval matrix
 */
public class ApprovalMatrix_VP_PO implements FormListener
{

AP_CommonFunctions CommonObj=new AP_CommonFunctions();
    public void SapReadXml() throws FileNotFoundException, IOException 
    {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try 
        {
            FormReference formObject = FormContext.getCurrentInstance().getFormReference();

            int i = 1;
            int currLvel = 0;
            int maxlevel = 0;
            String vp_desg[] = null;
            String Desg = "";
            String Users = "";
            String User_Index[] = null;
            String val_users = "";
            String Squery_vp = "";
            String Squery_User = "";
            String Squery_UI = "";
            Integer Max_approver=0;
            String sQuery_maxApp = "SELECT (CASE WHEN Approver1 IS NULL OR Approver1=''  THEN 0 ELSE 1 END)+(CASE WHEN Approver2 IS NULL OR Approver2='' THEN 0 ELSE 1 END)+(CASE WHEN Approver3 IS NULL OR Approver3='' THEN 0 ELSE 1 END)+(CASE WHEN Approver4 IS NULL OR Approver4='' THEN 0 ELSE 1 END)+(CASE WHEN Approver5 IS NULL OR Approver5=''"
                    + " THEN 0 ELSE 1 END)+(CASE WHEN Approver6 IS NULL OR Approver6='' THEN 0 ELSE 1 END)+(CASE WHEN Approver7 IS NULL OR Approver7='' THEN 0 ELSE 1 END)+(CASE WHEN Approver8 IS NULL OR Approver8='' THEN 0 ELSE 1  END)  "
                    + " AS TotalLevel from EXT_AP_ApprovalMatrix WITH(NOLOCK) WHERE SubCategory1='" + formObject.getNGValue("SubCategory1") + "'";
            //Query to found number of approvers(Max Approvers)
            //System.out.println("Max_approver find query="+sQuery_maxApp);
            CommonObj.writeToLog(2,"Max_approver find query="+sQuery_maxApp,winame);
            Max_approver=Integer.parseInt(CommonObj.DB_QueryExecute1(sQuery_maxApp));
            //System.out.println("Max Approver="+Max_approver);
            CommonObj.writeToLog(2,"Max Approver="+Max_approver,winame);
            for (int Vp_lvl = 1; Vp_lvl <= Max_approver; Vp_lvl++) //EXT_AP_ApprovalMatrix Query 
            {
                Squery_vp = "SELECT approver" + Vp_lvl + " FROM EXT_AP_ApprovalMatrix WITH(NOLOCK) WHERE SubCategory1='" + formObject.getNGValue("SubCategory1") + "'";
                //System.out.println("Query=" + Squery_vp);
                CommonObj.writeToLog(2,"Query=" + Squery_vp,winame);
                Desg = CommonObj.DB_QueryExecute1(Squery_vp);
                if (Desg.length() > 0) //EXT_AP_UserProfile
                {
                    vp_desg = Desg.split(",");
                    //System.out.println("Size==" + vp_desg.length);
                    CommonObj.writeToLog(2,"Size==" + vp_desg.length,winame);
                    Squery_User = "SELECT username from EXT_AP_UserProfile WITH(NOLOCK) WHERE Designation in(";
                    val_users = "";
                    int flag = 1;
                    for (String a1 : vp_desg) 
                    {
                        if (vp_desg.length == flag) //Last value
                        {
                            val_users += "'" + a1.trim() + "')"; 
                        } 
                        else 
                        {
                            val_users += "'" + a1.trim() + "',";
                        }
                        flag++;
                    }
                    //System.out.println("Query=" + Squery_User + val_users);
                    CommonObj.writeToLog(2,"Query=" + Squery_User + val_users,winame);
                    Users = CommonObj.DB_QueryExecute1(Squery_User + val_users);
                    //System.out.println("Users=" + Users);
                    CommonObj.writeToLog(2,"Users=" + Users,winame);
                    val_users = ""; // Re-assing before use
                    if (Users.length() > 0) //For getting Userindex
                    {
                        Squery_UI = "SELECT UserIndex FROM  PDBUser WITH(NOLOCK) WHERE UserName IN (";
                        User_Index = Users.trim().split(",");
                        int flag1 = 0;
                        for (String a1 : User_Index) 
                        {
                            if (vp_desg.length == flag1) //Last value
                            {
                                val_users +="'"+a1.trim()+ "')";
                            } 
                            else 
                            {
                                 val_users +="'"+a1.trim()+ "',";
                            }
                            flag1++;
                        }
                        //System.out.println("Query=" + Squery_UI + val_users);
                        CommonObj.writeToLog(2,"Query=" + Squery_UI + val_users,winame);
                        Users = CommonObj.DB_QueryExecute1(Squery_UI + val_users);
                        //System.out.println("User Index=" + Users);
                        CommonObj.writeToLog(2,"User Index=" + Users,winame);

                    }
                    else
                    {
                        //System.out.println("No approvers");
                        CommonObj.writeToLog(2,"No approvers",winame);
                    }
                 
                     //System.out.println("Inside App Matrix set function="+Users);
                     CommonObj.writeToLog(2,"Inside App Matrix set function="+Users,winame);
                     if(Vp_lvl==1)
                         formObject.setNGValue("App1index", Users);
                     else if(Vp_lvl==2)
                         formObject.setNGValue("App2index", Users);
                     else if(Vp_lvl==3)
                         formObject.setNGValue("App3index", Users);
                     else if(Vp_lvl==4)
                         formObject.setNGValue("App4index", Users);
                     else if(Vp_lvl==5)
                         formObject.setNGValue("App5index", Users);
                     else if(Vp_lvl==6)
                         formObject.setNGValue("App6index", Users);
                     else if(Vp_lvl==7)
                         formObject.setNGValue("App7index", Users);
                     else if(Vp_lvl==8)
                         formObject.setNGValue("App8index", Users);

                }
                else
                {
                    //System.out.println("Approver matrix profile empty for current level");
                    CommonObj.writeToLog(2,"Approver matrix profile empty for current level",winame);
                }
            }
           // System.out.println("After Approval matrix set");
            CommonObj.writeToLog(2,"After Approval matrix set",winame);
        } 
        catch (Exception e) 
        {
            //System.out.println("Error in VP -AP Approval Matrix=" + e.getMessage());
            CommonObj.writeToLog(3,"Error in VP -AP Approval Matrix=" + e.getMessage(),winame);
        }
    }
    @Override
    public void formLoaded(FormEvent fe) 
    {
        
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void eventDispatched(ComponentEvent ce) throws ValidatorException 
    {
        
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) 
    {
        
    }

    @Override
    public void initialize() 
    {
       
    }

}

