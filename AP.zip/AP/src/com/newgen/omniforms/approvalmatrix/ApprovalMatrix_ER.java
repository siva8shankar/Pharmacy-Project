/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.approvalmatrix;

/**
 *
 * @author ngappadmin
 */
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.IOException;
import java.io.Serializable;

public class ApprovalMatrix_ER implements Serializable {

    AP_CommonFunctions CommonObj = new AP_CommonFunctions();

    public String ApprovalMatrixER(String strUserName) throws IOException {
        String outputResult = "F";
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig();
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try {

            String strTypeofinvoice = formObject.getNGValue("TypeOfInvoice");
            String strSubcategory = formObject.getNGValue("SubCategory1");
            if (strSubcategory.equalsIgnoreCase("Travel Request")) {
                strSubcategory = "Travel Expense";
            }
            String sTotalAmount = formObject.getNGValue("TotalAmount");
            Float fTotal = 0.0f;
            if (!sTotalAmount.equalsIgnoreCase("")) {
                fTotal = Float.parseFloat(sTotalAmount);
            }
            int i = 1;
            int maxlevel = 0;
            String Squery_Grade_Limit = "";
            String GradeAmount = "";
//            Map<String, String> Appr_Matrix = new HashMap<String, String>();
//            Appr_Matrix.clear();
            String sApproversName = "";
            String sApproversGrade = "";
            String sApproversLevel = "";
            String Squery = "";
            String UserIndex = "";
            sApproversName = formObject.getNGValue("SAPApprovers");
            sApproversGrade = formObject.getNGValue("SAPApproversGr");
            sApproversLevel = formObject.getNGValue("apprsts2");

            String arrayApproversName[] = sApproversName.split("~");
            maxlevel = arrayApproversName.length;
            CommonObj.writeToLog(2, "Approver matrix maxlevel=" + maxlevel, winame);
            formObject.setNGValue("MaxAppLevel", maxlevel);
            Squery = "SELECT UserIndex,MailId FROM PDBUser with(nolock) WHERE UserName=";
            for (String a : arrayApproversName) {
                UserIndex = CommonObj.DB_QueryExecute1(Squery + "'" + a.trim() + "'");
                CommonObj.writeToLog(2, "Squery:" + Squery + "'" + a.trim() + "'", winame);
                try {

                    String[] FieldValue_array = CommonObj.DB_QueryExecute(Squery + "'" + a.trim() + "'");
                    CommonObj.writeToLog(2, "FieldValue_array[1]:" + FieldValue_array[1], winame);
                    if (FieldValue_array[1].contains("null")) {
                        //formObject.setNGValue("Appr"+i+"email", "");
                    } else {
                        formObject.setNGValue("Appr" + i + "email", FieldValue_array[1]);
                    }
                    formObject.setNGValue("App" + i + "index", a.trim().trim());
                    CommonObj.writeToLog(2, "Appr" + i + "email ID:" + FieldValue_array[1], winame);
                } catch (Exception e) {
                    CommonObj.writeToLog(3, "Approver:" + a.trim() + " is Not Present in DMS", winame);
                    return "Approver:" + a.trim() + " is Not Present in DMS";
                }
                i++;
            }

            //ApproverMatrix GradeText Amount passing Query added by bala G on 24-12-2016
            String[] arrayApproversGrade = sApproversGrade.split("~");
            if (/*!arrayApproversGrade[0].equalsIgnoreCase("Managing Director") &&*/sApproversLevel.equalsIgnoreCase("HRBP")) {

                return "All Approvers are Not Present in SAP, Please contact HR  and kindly save the transaction";
            }
            //Squery_Grade_Limit="SELECT ApproverLimit from ext_ap_amountcalculation where grade=";
            //Modified by Harinatha R on 2018/03/19 //NOTE: Separate master table has been created for employee advances 
            if (strSubcategory.equalsIgnoreCase("Salary Advance") || strSubcategory.equalsIgnoreCase("House Rent Advance")
                    || strSubcategory.equalsIgnoreCase("Exceptional Advances") || strSubcategory.equalsIgnoreCase("Imprest Cash")) {

                Squery_Grade_Limit = "SELECT ApprovalLimitAmt from EXT_AP_ER_MASTER_EMPLOYEEADVANCES with(nolock) where AdvanceType='" + strSubcategory + "' and EmployeeGradeText=";
            } else {
                Squery_Grade_Limit = "SELECT ApproverLimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='" + strSubcategory + "' and grade=";
            }
            //Squery_Grade_Limit="SELECT ApproverLimit from EXT_AP_ER_ClaimLimit with(nolock) where Subcategory1='"+strSubcategory+"' and grade=";
            //Ended by Harinatha R on 2018/03/19
            i = 0;
            String S_Amount = "";
            Float fGradeAmount0 = 0.0f;
            Float fGradeAmount1 = 0.0f;
            Float fGradeAmount2 = 0.0f;
            Float fGradeAmount3 = 0.0f;
            Float fGradeAmount4 = 0.0f;
            Float fGradeAmount5 = 0.0f;
            Float fGradeAmount6 = 0.0f;
            Float fGradeAmount7 = 0.0f;
            CommonObj.writeToLog(2, "fGradeAmount1=" + fGradeAmount1, winame);
            for (String Amt_val : arrayApproversGrade) {
                try {
                    //S_Amount = CommonObj.DB_QueryExecuteFloat(Squery_Grade_Limit + "'" + Amt_val.trim() + "'");
                    S_Amount = CommonObj.DB_QueryExecuteSelect1(Squery_Grade_Limit + "'" + Amt_val.trim() + "'");
                    //if (maxlevel == i) // Last element
                    //{
                    //    GradeAmount += S_Amount.toString();
                    //} else // Other elements
                    //{
                    GradeAmount += S_Amount.toString() + "~";
                    //}                
                    if (i == 0) {
                        fGradeAmount0 = Float.parseFloat(S_Amount);
                    }
                    if (i == 1) {
                        fGradeAmount1 = Float.parseFloat(S_Amount);
                    }
                    if (i == 2) {
                        fGradeAmount2 = Float.parseFloat(S_Amount);
                    }
                    if (i == 3) {
                        fGradeAmount3 = Float.parseFloat(S_Amount);
                    }
                    if (i == 4) {
                        fGradeAmount4 = Float.parseFloat(S_Amount);
                    }
                    if (i == 5) {
                        fGradeAmount5 = Float.parseFloat(S_Amount);
                    }
                    if (i == 6) {
                        fGradeAmount6 = Float.parseFloat(S_Amount);
                    }
                    if (i == 7) {
                        fGradeAmount7 = Float.parseFloat(S_Amount);
                    }
                } catch (Exception e) {
                    CommonObj.writeToLog(3, "Approver=" + arrayApproversName[i] + ", ApproverGrade:" + Amt_val.trim() + " is Not Present in DMS", winame);
                    return "Approver=" + arrayApproversName[i] + ", Approver Grade:" + Amt_val.trim() + " is Not Present in DMS";
                }
                i++;
            }
            CommonObj.writeToLog(2, "fGradeAmount0=" + fGradeAmount0, winame);
            CommonObj.writeToLog(2, "fGradeAmount1=" + fGradeAmount1, winame);
            CommonObj.writeToLog(2, "fGradeAmount2=" + fGradeAmount2, winame);
            CommonObj.writeToLog(2, "fGradeAmount3=" + fGradeAmount3, winame);
            CommonObj.writeToLog(2, "fGradeAmount4=" + fGradeAmount4, winame);
            CommonObj.writeToLog(2, "fGradeAmount5=" + fGradeAmount5, winame);
            CommonObj.writeToLog(2, "fGradeAmount6=" + fGradeAmount6, winame);
            CommonObj.writeToLog(2, "fGradeAmount7=" + fGradeAmount7, winame);
            CommonObj.writeToLog(2, "GradeAmount=" + GradeAmount, winame);
            formObject.setNGValue("Grade_Test", GradeAmount);
            String[] arrayGradeAmount = GradeAmount.split("~");
            //Modified By Harinatha R on 2017/06/05
            //if (strTypeofinvoice.equalsIgnoreCase("Travel Request") || strTypeofinvoice.equalsIgnoreCase("Travel Expense")){
            if (strTypeofinvoice.equalsIgnoreCase("Travel Request") || strTypeofinvoice.equalsIgnoreCase("Travel Expense")
                    || (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && strSubcategory.equalsIgnoreCase("Others"))
                    || strSubcategory.equalsIgnoreCase("Imprest Cash")) {
                formObject.setNGValue("MaxAppLevel", "1");
                outputResult = "S";
            } //else if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements") || strTypeofinvoice.equalsIgnoreCase("Entertainment & Others")){
            else if (strTypeofinvoice.equalsIgnoreCase("Entertainment & Others") && (strSubcategory.equalsIgnoreCase("Entertainment") || strSubcategory.equalsIgnoreCase("Gift & Complimentary"))) {
                int j = 0;
                for (j = 0; j < maxlevel; j++) {
                    Float fGradeAmount = Float.parseFloat(arrayGradeAmount[j]);
                    if (fTotal < fGradeAmount || fTotal.equals(fGradeAmount)) {
                        CommonObj.writeToLog(2, "fTotal<fGradeAmount or equal,Total=" + fTotal + " GradeAmount=" + arrayGradeAmount[j], winame);
                        formObject.setNGValue("MaxAppLevel", j + 1);
                        break;
                    } else if (fTotal > fGradeAmount) {
                        CommonObj.writeToLog(2, "fTotal>fGradeAmount,Total=" + fTotal + " GradeAmount=" + arrayGradeAmount[j], winame);
                        formObject.setNGValue("MaxAppLevel", j + 1);

                    } else {
                        CommonObj.writeToLog(2, "else,Total=" + fTotal + " GradeAmount=" + arrayGradeAmount[j], winame);
                    }

                }
                outputResult = "S";
            } else if (strTypeofinvoice.equalsIgnoreCase("Mobile Re-Imbursements")) {
//                String strEligibleAmt="0.0";
//                String qryClaimlimit="SELECT Claimlimit FROM EXT_AP_ER_ClaimLimit with(nolock) WHERE Grade='" + formObject.getNGValue("Grade") + "' and Subcategory1='"+strSubcategory+"'";
//                strEligibleAmt = CommonObj.DB_QueryExecuteSelect1(qryClaimlimit);
//                if(maxlevel==1){
//                    formObject.setNGValue("MaxAppLevel", "1");
//                }else{                  
//                    if(fTotal > Float.parseFloat(strEligibleAmt)){
//                        formObject.setNGValue("MaxAppLevel", "2");
//                    }else{
//                        formObject.setNGValue("MaxAppLevel", "1");
//                    }
//                    
//                }
//                outputResult = "S";

                String strEligibleAmt = "0.0";
                String strCompanyCode = formObject.getNGValue("CompanyCode");
                String qryClaimlimit = "";
                if (strCompanyCode.equalsIgnoreCase("BNP1")) {
                    qryClaimlimit = "SELECT Claimlimit FROM EXT_AP_ER_ClaimLimit with(nolock) WHERE Grade='" + formObject.getNGValue("Grade") + "' and Subcategory1='" + strSubcategory + "' AND CompanyCode='" + formObject.getNGValue("CompanyCode") + "'";
                } else {
                    qryClaimlimit = "SELECT Claimlimit FROM EXT_AP_ER_ClaimLimit with(nolock) WHERE Grade='" + formObject.getNGValue("Grade") + "' and Subcategory1='" + strSubcategory + "' AND CompanyCode IS NULL";
                }
                strEligibleAmt = CommonObj.DB_QueryExecuteSelect1(qryClaimlimit);
                if (maxlevel == 1) {
                    formObject.setNGValue("MaxAppLevel", "1");
                } else {
                    if (fTotal > Float.parseFloat(strEligibleAmt)) {
                        formObject.setNGValue("MaxAppLevel", "2");
                    } else {
                        formObject.setNGValue("MaxAppLevel", "1");
                    }

                }
                outputResult = "S";

            } //Ended By Harinatha R on 2017/06/05
            else if (strSubcategory.equalsIgnoreCase("Exceptional Advances")) {
                if (maxlevel >= 4) {
                    formObject.setNGValue("MaxAppLevel", "4");
                    outputResult = "S";
                } else {
                    outputResult = "All the approvers are Not Present in SAP";
                }
            } else if (strTypeofinvoice.equalsIgnoreCase("Relocation")) {
                if (maxlevel >= 3) {
                    formObject.setNGValue("MaxAppLevel", "3");
                    outputResult = "S";
                } else {
                    outputResult = "All the approvers are Not Present in SAP";
                }
            } //else if (strTypeofinvoice.equalsIgnoreCase("Relocation") || strSubcategory.equalsIgnoreCase("House Rent Advance") || strSubcategory.equalsIgnoreCase("Salary Advance") ){
            //Modified By Harinath on 2017/03/22
            else if (strSubcategory.equalsIgnoreCase("House Rent Advance") /*|| strSubcategory.equalsIgnoreCase("Imprest Cash") || strSubcategory.equalsIgnoreCase("Salary Advance")*/) {
                //Ended By Harinath on 2017/03/22
                formObject.setNGValue("MaxAppLevel", "2");
                int j = 0;
                for (j = 0; j < maxlevel; j++) {
                    Float fMgrGradeAmount = Float.parseFloat(arrayGradeAmount[0]);
                    if (j == 1) {
                        if (fTotal < fMgrGradeAmount || fTotal.equals(fMgrGradeAmount)) {
                            CommonObj.writeToLog(2, "fTotal<fMgrGradeAmount or equal,Total=" + fTotal + " GradeAmount=" + arrayGradeAmount[j], winame);
                            formObject.setNGValue("MaxAppLevel", j + 1);
                            break;
                        }
                        if (fTotal > fMgrGradeAmount) {
                            CommonObj.writeToLog(2, "fTotal>fMgrGradeAmount,Total=" + fTotal + " GradeAmount=" + arrayGradeAmount[j], winame);
                            formObject.setNGValue("MaxAppLevel", j + 1);

                        }
                    }
                }
                /*for (j=0; j<maxlevel; j++) {
                 Float fGradeAmount=Float.parseFloat(arrayGradeAmount[j]);
                 if(j==0){
                 formObject.setNGValue("MaxAppLevel", "2");
                 }
                 else if(j>=1){
                 if(fTotal<fGradeAmount ||fTotal.equals(fGradeAmount) ){  
                 CommonObj.writeToLog(2,"fTotal<fGradeAmount or equal,Total="+fTotal+" GradeAmount="+arrayGradeAmount[j],winame);
                 formObject.setNGValue("MaxAppLevel", j+1);
                 break;
                 }
                 else if(fTotal>fGradeAmount){
                 CommonObj.writeToLog(2,"fTotal>fGradeAmount,Total="+fTotal+" GradeAmount="+arrayGradeAmount[j],winame);
                 formObject.setNGValue("MaxAppLevel", j+1);                       
                 }
                 else {
                 CommonObj.writeToLog(2,"else,Total="+fTotal+" GradeAmount="+arrayGradeAmount[j],winame);
                 }
                 }
                
                 }*/
                outputResult = "S";

            } else if (strSubcategory.equalsIgnoreCase("Salary Advance")) {
                FormReference formObject1 = FormContext.getCurrentInstance().getFormReference();

                CommonObj.writeToLog(2, "Salary Advance app matrix", winame);
                if (fTotal > 200000) {
                    formObject1.setNGValue("MaxAppLevel", "4");
                } else {
                    formObject1.setNGValue("MaxAppLevel", "3");
                }
                outputResult = "S";

            } else {
                outputResult = "Approval matrix not found for the Type of Invoice";
            }

            return outputResult;
        } catch (Exception e) {
            //System.out.println("Error ERApprovalMatrix=" + e.getMessage());
            CommonObj.writeToLog(3, "Error ERApprovalMatrix=" + e.getMessage(), winame);
            return e.getMessage();
        }
    }

}
