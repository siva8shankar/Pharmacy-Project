/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.omniforms.approvalmatrix;

/**
 *
 * @author ngappadmin
 */
import com.newgen.dmsapi.DMSXmlList;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.xml.WFXmlList;
import com.newgen.omni.wf.util.xml.api.dms.WFXmlResponse;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import com.newgen.omniforms.user.AP_CommonFunctions;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author Nanjundamoorthy.B

 */
public class ApprovalMatrix_VP_NONPO implements FormListener
{

AP_CommonFunctions CommonObj=new AP_CommonFunctions();
    public void SapReadXml() throws FileNotFoundException, IOException
    {
        FormConfig formConfig = FormContext.getCurrentInstance().getFormConfig(); 
        String winame = formConfig.getConfigElement("ProcessInstanceId");
        try
    {
        FormReference formObject = FormContext.getCurrentInstance().getFormReference();
        String sXMLFilePath="C:\\coding\\Bala\\SAP.xml";
        
        //System.out.println("File path="+sXMLFilePath);
        CommonObj.writeToLog(2,"File path="+sXMLFilePath,winame);
       // DMSXmlList centerList=null;
        File fXmlFile = new File(sXMLFilePath);
        Reader fileReader = new FileReader(fXmlFile);
        BufferedReader bufReader = new BufferedReader(fileReader);
        StringBuilder sb = new StringBuilder();
        String line = bufReader.readLine();
        while( line != null)
        {
            sb.append(line);
            line = bufReader.readLine();
        }
        String SAP_XML=sb.toString();
        //System.out.println("XML String="+SAP_XML);
         WFXmlResponse xmlresponse = new WFXmlResponse(SAP_XML.trim());
         //System.out.println("After xmlresponse1");
        //DMSXmlResponse xmlResponse = new DMSXmlResponse(SAP_XML.trim());
       // System.out.println("XMl resp new ="+xmlresponse.toString());
        WFXmlList xmlList = xmlresponse.createList("TableParameters", "EMPRSR");
        //System.out.println("After xmlList");
        //centerList = xmlresponse.createList("TableParameters","EMPRSR");
        int i= 0;int currLvel=0;int maxlevel=0;
        String Approvers_name="";String Squery="";
        String L1="";String L2="";String L3="";String L4="";String L5="";String L6="";String L7="";String L8="";
        String UserIndex="";String UserIndexRet[]=null;
        String list12="";
       // List<String> a=new ArrayList<String>();
        //System.out.println("centerList size="+xmlList.toString());
        CommonObj.writeToLog(2,"centerList size="+xmlList.toString(),winame);
                for (; xmlList.hasMoreElements(true); xmlList.skip(true)) 
                {
                    //System.out.println("Inside Line Item"+ i++);
                    CommonObj.writeToLog(2,"Inside Line Item"+ i++,winame);
                     L1= xmlList.getVal("l1");
                     L2 = xmlList.getVal("l2");
                     L3 =xmlList.getVal("l3");
                     L4 =xmlList.getVal("l4");
                     L5 = xmlList.getVal("l5");
                     L6 = xmlList.getVal("l6");
                     L7 =xmlList.getVal("l7");
                     L8 =xmlList.getVal("l8");
                     CommonObj.writeToLog(2,"Approvers="+L1+"~"+L2+"~"+L3+"~"+L4+"~"+L5+"~"+L6+"~"+L7+"~"+L8,winame);
                   // System.out.println("Approvers="+L1+"~"+L2+"~"+L3+"~"+L4+"~"+L5+"~"+L6+"~"+L7+"~"+L8);
                   // String sInsertQry = "INSERT INTO EXT_HR_APPROVAL_MATRIX(PID,APPROVER_NO,APPROVER_NAME,APPROVAL_HIRARCHY,ATE_APPROVAL_HIERARCHY) VALUES ('" + sProcessInstanceId + "','" + sAppNo.trim() + "','" + sAppName.trim() + "','" + i + "','" + sAppHirarchy.trim() + "')";
                    //System.out.println("sInsertQry for Approval Matrix : " + sInsertQry);
                   // formObject.saveDataIntoDataSource(sInsertQry);
                    //i++;
                }
                 Approvers_name=L1+"~"+L2+"~"+L3+"~"+L4+"~"+L5+"~"+L6+"~"+L7+"~"+L8;
                 String a1[]=Approvers_name.split("~");
                 maxlevel=a1.length;
                 //System.out.println("Approver matrix maxlevel="+maxlevel);
                 CommonObj.writeToLog(2,"Approver matrix maxlevel="+maxlevel,winame);
                 formObject.setNGValue("MaxAppLevel", maxlevel);
                 Squery="SELECT userindex FROM PDBUser WITH(NOLOCK) WHERE UserName=";
                 for(String a:a1)
                  {
                      //System.out.println("Inside loop="+i);
                      UserIndex=CommonObj.DB_QueryExecute1(Squery+"'"+a.trim()+"'");
                      //System.out.println("UserIndex "+i+"="+UserIndex.toString());
                      if(maxlevel==i) // Last element
                      list12+=UserIndex.toString();
                      else // Other elements
                       list12+=UserIndex.toString()+"~";
                      i++;
                  }
                 CommonObj.writeToLog(2,"list of index="+list12,winame);
                // System.out.println("list of index="+list12);
                 String App_Index[]=list12.split("~");
                 int j=1;
                // System.out.println("App_Index size="+App_Index.length);
                 CommonObj.writeToLog(2,"App_Index size="+App_Index.length,winame);
                 for(String Index1:App_Index) //Approval MATRIX Assign
                 {
                     //System.out.println("Inside App Matrix set function="+Index1);
                      CommonObj.writeToLog(2,"Inside App Matrix set function="+Index1,winame);
                     if(j==1)
                         formObject.setNGValue("App1index", Index1);
                     else if(j==2)
                         formObject.setNGValue("App2index", Index1);
                     else if(j==3)
                         formObject.setNGValue("App3index", Index1);
                     else if(j==4)
                         formObject.setNGValue("App4index", Index1);
                     else if(j==5)
                         formObject.setNGValue("App5index", Index1);
                     else if(j==6)
                         formObject.setNGValue("App6index", Index1);
                     else if(j==7)
                         formObject.setNGValue("App7index", Index1);
                      else if(j==8)
                         formObject.setNGValue("App8index", Index1);
                     j++;
                 }
                 CommonObj.writeToLog(2,"After Approval matrix set",winame);
                 //System.out.println("After Approval matrix set");
    }
        catch(Exception e)
        {
            CommonObj.writeToLog(3,"Error inApproval Matrix="+e.getMessage(),winame);
           // System.out.println("Error inApproval Matrix="+e.getMessage());
        }
    }
    @Override
    public void formLoaded(FormEvent fe) 
    {
        
    }

    @Override
    public void formPopulated(FormEvent fe) 
    {
        
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        
    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException 
    {
        
    }

    @Override
    public void eventDispatched(ComponentEvent ce) throws ValidatorException 
    {
        
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm) 
    {
        
    }

    @Override
    public void initialize() 
    {
       
    }

}


