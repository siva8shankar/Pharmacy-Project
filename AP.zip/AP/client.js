/*
		Module          :       WorkList Window
		File            :       client.js
		Purpose         :       Contains the functions used for custom coding

		Change History  :

		Problem No        Correction Date	   Comments
		-----------       ----------------      ----------                
                WCL_8.0_047       18/06/2009            Function commitException() is provided in client.js for customization at exception commit and save workitem.
                WCL_8.0_081       12/08/2009            Required Custom function in client.js for validating document type or File extension while importing document.
                WCL_8.0_092       03/09/2009            Short cut keys for  toggling, between Form applet and document applet.
                WCL_8.0_093      03/09/2009             Option for saving Template Preferences.
                WCL_8.0_102      11/09/2009             Need to Disable/Enable the New  link for worklist on the basis of  ProcessName.
                WCL_8.0_103      11/09/2009             Need a pre hook for   custom validations in case of Save/Done/Introduce for Custom Form.
                WCL_8.0_106      11/09/2009             Need only 2 priorities 1)Normal 2)High.
                WCL_8.0_113      24/09/2009             Need  apply a custom validation when user clicks on ok after  selecting  document type for cropping of image applet.
                WCL_8.0_114      29/09/2009             Need to hide links form workdesk on the basis of workstep name (Add Document & Scan Document links to be hide)
                WCL_8.0_119     06/10/2009             User will select multiple workitems from webdesktop, and performs done, on clicking done, a new window to open, where some process fields will be displayed. User will enter data for these fields and perform done all the workitems together
                WCL_8.0_120      06/10/2009             When  user selects multiple workitems from webdesktop, and clicks on done, batch number to be generated  for these workitems and saved in database.
                WCL_8.0_121      06/10/2009             User should be able to open only one workitem per process.
                WCL_8.0_136     16/10/2009              Provision for LockForMe and Release in worklist.
                WCL_8.0_139     22/10/2009               selected workitem count required in  setQueueData function of client.js.
                WCL_8.0_148     16/11/2009               Provision of custom link In search screen and in worklist screen. 
                WCL_8.0_149     16/11/2009               Need provision of conditional enabling or disabling of done button in worklist window and for serach workitem list.
                WCL_8.0_161     16/12/2009               Need to disable Reassign option for users My Queue.
                WCL_8.0_163    24/12/2009                On crop document page a custom combo required and cropped document name  should be combination of selected document type and selected value of custom combo.
                WCL_8.0_176     19/01/2010               Need a Hook during import/check/add a document in OmniFlow Webdesktop.
                WCL_8.0_184     02/02/2010               Short Cut key is required to scroll the outer scroll bar.
                WCL_9.0_002     24/09/2010              Required hook in client.js on sucessful addition of conversation
                WCL_9.0_021     04/01/2011              We have to restrict some document type ext while importing document only for some particular document
                WCL_9.0_026     11/01/2011              Prehook required in client.js on click of custom link.	Requirement
                WCL_9.0_041     04/02/2011              DocAppletHeight and Formheight method missing from client.js which helps in windows size setup
                WCL_9.0_051     15/02/2011              Need a hook in client.js for initiate button
                WCL_9.0_053     23/02/2011              Need a hook in client.js for initiate and Done  Button in case of search workiitem
                Bug 28049       02/09/2011              Get Parent Document name in ngfuser script
                WCL_8.0_321     21/04/2011               Need a prehook on  exception commit
                WCL_8.0_228     11/06/2010               Required Refer comment and UserName in clicnt.js ReferClick function
                WCL_9.0_053     23/02/2011              Need a hook in client.js for initiate and Done  Button in case of search workiitem
                                29/12/2011          29610      Refer and Reassign popup not opened correctly
                30543           08/06/2012          Need a validation check while importing document
        	Bug 30277      24/01/2012              Need Process Name and Activity Name of opened Workitem in getUploadMaxLength() function to restrict maximum size for document Upload based on these parameters
                Bug 30946       Need a hook to raise exception via custom code rather than click on raise button
                Bug 32773 - Requirement for keeping the Web and DB session active forcefully through client.js
                Bug 32179  prehook required to restrict zone draw on the basis of Activity Name and Doc Type
                Bug 31564   Need a hook to draw zone by custom code by calling Image View Applet's API 
                Bug 32608      Ritu Raj              Enabling Overwrite option according to modify rights for doctypes in import document window
                Bug 41792, 27/09/2013          Need a hook to Save Process Variables in Workitem's Save/Done/Introduce 
                Bug 44632       06/06/2014         Showing particular DOC type while cropping in omniflow 
*               Bug 42621       30/07/2014         Hide new version if already exist and overwrite existing document options from import document screen for a particular process.
*               Bug 42678       05/08/2014   Bhanu Priya                Need a hook to display custom document list in import document and scan document window
*               PRDPBug 44696 -      06/08/2014      Mohammad Sayemul Makki     Required to save cropped image at shared location instead of adding it to DMS

*               Bug 47668       06/08/2014   Bhanu Priya                Requirement of a hook in client.js for not to display Document's original name in Document's combo list box based on Process name / Activity Name 
                Bug 62986 -     22/07/2016      Mohit   Nothing is happening on ok or cancel click and exception message
*

*/

function executeActionClick(actionName)
{
	return true;
}


function OpenCustomUrl(url,name)
{//todo security
    url = url.replace('\\','\\\\');    
    var src = url;
    customChildCount++;
    
    url = getActionUrlFromURL(src);
    url = appendUrlSession(url);
    
    var wFeatures = 'resizable=yes,scrollbars=1,status=yes,width='+window1W+',height=320,left='+window1Y+',top='+window1X;
    
    var listParam=new Array();
    listParam = getInputParamListFromURL(src);
    customChild[customChildCount] = openNewWindow(url,name,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    
   // url = appendUrlSession(url);
  //  customChild[customChildCount] = window.open(url,name,'resizable=yes,scrollbars=auto,width='+window1W+',height=320,left='+window1Y+',top='+window1X);        
}


function CustomFormReload(loc)
{
	//Just uncomment below line if value to be set is in the form
//	eval(loc).reload();
}

function MoreActionsClick()
{
	return true;
}


function ToolsClick()
{
	return true;
}


function PreferenceClick()
{
	return true;
}


function ReassignClick()
{
	return true;
}


function LinkedWiClick()
{
	return true;
}


function QueryClick()
{
	return true;
}


function SearchDocClick()
{
	return true;
}


function SearchFolderClick()
{
	return true;
}


function AddConversationClick()
{       
        
	return true;
}


function AddDocClick()
{
	return true;
}


function ImportDocClick()
{
	return true;
}


function ScanDocClick()
{
	return true;
}


function SaveClick()
{
	return true;
}


function IntroduceClick()
{
	return true;
}


function RejectClick()
{
	return true;
}


function AcceptClick()
{
	return true;
}


function DoneClick()
{
	return true;
}


function RevokeClick()
{
	return true;
}


function PrevClick()
{
	return true;
}


function NextClick()
{
    return true;
}


function ExceptionClick()
{
	return true;
}


function FormViewClick()
{
	return true;
}


function ToDoListClick()
{
	return true;
}


function DocumentClick()
{
	return true;
}


function ClientInterfaceClick(url)
{
	return true;
}


function NewClick()
{
	return true;
}


function DeleteWIClick()
{
	return true;
}


function WIPropertiesClick()
{
	return true;
}


function PriorityClick()
{
	return true;
}


function ReminderClick()
{
	return true;
}





function saveFormData()
{
	return true;
}


function NGGeneral(sEventName,sXML)
{
	switch(sEventName)
	{
		case 'ImportDoc' :
			window.parent.parent.frames["wiview_top"].importDoc('S');
			break;
	}
}


function preHook(opType)
{
	return true;
}

function CommentWiClick(){
              return true;
}

function getUploadMaxLength()
{
    /*
         strprocessname :   Name of the Current Process
         stractivityName:   Name of the Current Activity
    */
   /*Bug 42111
         strprocessname :   Name of the Current Process
         stractivityName:   Name of the Current Activity
	 docType	:	DocumentType
    if(strprocessname == 'AttachTest' && stractivityName == 'Work Introduction1' && docType == 'attachmentfree')
    {
        return 5;
    }
    else if(strprocessname == 'AttachTest' && stractivityName == 'Work Introduction1' && docType == 'selfattach')
    {
        alert("In else if ");
        return 15;
    }
    else
    {
        alert("In else");
        return 10;
    }
*/
	return 10;
}

function WFGeneralData(){
       
}
function CustomShow(){
              return true;
}

function setFormFocus(){
 
}

function commitException(){
    return true;
}

function validateUploadDocType(docExt,DocTypeName)// WCL_8.0_081
{ 
	//check doc extension and return false from the function in case of undesired file extension  
	return true;
}

function validateUploadDocTypeName(DocTypeName)// WCL_8.0_081
{
        //make custom check for the Document Type Name 
 	var win_workdesk = window.opener;
        var winList=win_workdesk.windowList;
        var formWindow=getWindowHandler(winList,"formGrid");
        var formFrame; 
        if(formWindow){
            if(win_workdesk.wiproperty.formType=="NGFORM"){
		formFrame = formWindow; 
                // Write custom code here for ngform   
            }
            else if(win_workdesk.wiproperty.formType=="HTMLFORM"){
                formFrame = formWindow;
                //Write custom code here for HTMLForm
            }
           else if(win_workdesk.wiproperty.formType=="CUSTOMFORM"){
                formFrame = formWindow.frames['customform'];
                //Write custom code here for customform
            }
        }

	return true;
}
function ToggleFocus(interfaceFlag)
{
    if(interfaceFlag == "F")
    {
          /*if(typeof  interFace0!='undefined'){
                if(interFace0=="doc" && interFace2!=""){
                     toggleIntFace("doc",interFace2);
                }
                else if(interFace1=="doc" && interFace3!=""){
                     toggleIntFace("doc",interFace3);
                }
                else if(interFace2=="doc" && interFace0!=""){
                     toggleIntFace("doc",interFace0);
                }
                else if(interFace3=="doc" && interFace1!=""){
                    toggleIntFace("doc",interFace1);
                }
          }
           if(document.IVApplet)
            {
               try{
                    document.IVApplet.setIVFocus();
                }catch(ex){
                  }
        }*/
        
        if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm){
            var ngformIframe = document.getElementById("ngformIframe");	
            if(ngformIframe != null){
                if(!bAllDeviceForm){      
                    ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.focus()");	
                }
            }
         } else if((typeof document.wdgc!='undefined') && document.wdgc){
            document.wdgc.NGFocus();
         } else {
                var htmlFormPanel = window.document.getElementById("wdesk:htmlFormPanel")
                if(htmlFormPanel!=null){           
                   try{               
                        htmlFormPanel.rows[0].cells[1].firstChild.focus();
                    } catch(e){}
                }
         }
    }
    else if(interfaceFlag == "D")
     {

           /*if(typeof  interFace0!='undefined'){
                if(interFace0=="form" && interFace2!=""){
                     toggleIntFace("form",interFace2);
                }
                else if(interFace1=="form" && interFace3!=""){
                     toggleIntFace("form",interFace3);
                }
                else if(interFace2=="form" && interFace0!=""){
                     toggleIntFace("form",interFace0);
                }
                else if(interFace3=="form" && interFace1!=""){
                    toggleIntFace("form",interFace1);
                }
          }
          
             try{
                 if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm){
                    var ngformIframe = document.getElementById("ngformIframe");	
                    if(ngformIframe != null){
                        ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.focus()");	
                    }
                 } else {
                     if((typeof document.wdgc!='undefined') && document.wdgc){
                        document.wdgc.NGFocus();
                     }
                 }
            }catch(ex){
              }*/
        
        try{               
               window.document.getElementById("wdesk:docCombo").focus();
        } catch(e){}        
          
    }else if(interfaceFlag=="W"){
       window.focus();
   } else if(interfaceFlag == "E"){
        if(window.document.getElementById("wdesk:expList")!=null){
            try{
                window.document.getElementById("wdesk:expList").focus();
            } catch(e){}
        }
   } else if(interfaceFlag == "T"){
        var todoListTableRef = window.document.getElementById("wdesk:todoListTable")
        if(todoListTableRef!=null){           
           try{               
                todoListTableRef.rows[0].cells[1].firstChild.focus();
            } catch(e){}
        }
   }
}
function getTempletPref(){ 

    var strTemplatePrefXml=''; 

    return strTemplatePrefXml; 
}
function showPriority(){
        var priorityArray =new Array();
        priorityArray[0]=1;  //Low (replace 1 by 0 for removing it from priority combo)
        priorityArray[1]=1;  //Medium
        priorityArray[2]=1;  //High
        priorityArray[3]=1; //Very High
        return priorityArray;
}
function customValidation(opt){
    //In case of Save opt="S" and for Done and Introduce opt="D"   
   return true;
}
function enableWLNew(queueName){    

  return true;
}
function validateCropDocTypeName(DocTypeName){ 
  return true;
}

function hideWdeskMenuitems(){
    var wdeskMenu=""; 
    //wdeskMenu=LABEL_SAVE_WDESK+","+LABEL_INTRODUCE_WDESK;	
	wdeskMenu=LABEL_DONE_WDESK+","+LABEL_INTRODUCE_WDESK;// Added by Nanjunda Moorthy on 11/01/2017 to disable DONE & Introduce button from workitem Header
    return wdeskMenu;
}

function hideWdeskSubMenuitems(){
   var wdeskSubMenu="";
   //wdeskSubMenu=LABEL_ADD_DOCUMENT_WDESK+","+LABEL_SCAN_DOCUMENT_WDESK; 
   //Added by Nanjunda Moorthy on 11/01/2017 to disable ADD_DOCUMENT and SCAN_DOCUMENT //from workitem Header 
   var processname=window.parent.strprocessname;
   var activityName=window.parent.stractivityName;
 
 if(processname == 'AP')
    {  
   wdeskSubMenu=LABEL_ADD_DOCUMENT_WDESK+","+LABEL_SCAN_DOCUMENT_WDESK;
    }
 if(processname == 'SP')
    { 
   wdeskSubMenu=LABEL_SCAN_DOCUMENT_WDESK;
    }
   return wdeskSubMenu;
}

function setAttributeData()
{
    closeFrm = 'ok';
    var inputObject,i;
    var inputObjectValue;
    var inputObjectType;
   // var attributeData = '';
    var tmpObj = document.forms["dataForm"];
   // var status = htmlFormOk(window,"dataForm");
   // alert(document.forms["dataForm"].elements.length);
    for ( i=0; i < document.forms["dataForm"].elements.length ; i++)
    {
		
        if (document.forms["dataForm"].elements[i].type == "text" || document.forms["dataForm"].elements[i].type == "select-one")
        {
            inputObject = document.forms["dataForm"].elements[i].name;
            inputObjectValue = document.forms["dataForm"].elements[i].value;
            if(document.forms["dataForm"].elements[i].type == "text")
                inputObjectType = document.forms["dataForm"].elements[i].alt;
            else
                inputObjectType = "";

          //  attributeData +=inputObject.substring((inputObject.indexOf(SYMBOL_3) + 1))+SEPERATOR2+inputObjectValue+SEPERATOR2+inputObjectType+SEPERATOR1;
            attributeData +="<"+inputObject.substring((inputObject.indexOf(":")+1))+">"+inputObjectValue+"</"+inputObject.substring((inputObject.indexOf(":")+1))+">";
        }
    }

    
            window.returnValue = attributeData;
            window.close();
            return false;

}

function WIWindowName(pidWid,processName,activityName){
    
 return pidWid;
}
function UnassignClick(){

 return true;   
}
function LockForMe(){

 return true;   
}
function setQueueData(queueId,selectedWICount)
{
    alert("33");
 var dataXMl="";
//TODO set your queue variable or external variable return the dataXML in given format--
// <VaribaleName>variableValue</VaribaleName>
 return dataXMl;
}

function enableCustomButton(strSelQueueName,strFrom){  
     return true;
}
function CustomButtonClick(selectedWIInfo){  
    //Uncomment refresh() for refreshing workitem list.
   //refresh();
   return true;
}

function enableReassign(strSelQueueName,strFrom){   

    /*
         strSelQueueName: selected QueueName (in case of search it is blank) 
         strFrom        : W or F or S
         W              : Workitem list form any queue
         F              : Workitem list form Filter
         S              : Workitem list form Search
    */

     return   true;
}

function enableRefer(strSelQueueName,strFrom){  
   
    /*
         strSelQueueName: selected QueueName (in case of search it is blank)
         strFrom        : W or F or S
         W              : Workitem list form any queue
         F              : Workitem list form Filter
         S              : Workitem list form Search
    */

   return   true;
}
function enableLockForMe(strSelQueueName,strFrom){  
   
    /*
         strSelQueueName: selected QueueName (in case of search it is blank) 
         strFrom        : W or F or S
         W              : Workitem list form any queue
         F              : Workitem list form Filter
         S              : Workitem list form Search
    */

   return   true;
}
function enableRelease(strSelQueueName,strFrom){  
   
    /*
         strSelQueueName: selected QueueName (in case of search it is blank)
         strFrom        : W or F or S
         W              : Workitem list form any queue
         F              : Workitem list form Filter
         S              : Workitem list form Search
    */

   return   true;
}

function enableDelete(strSelQueueName,strFrom){  
   
    /*
         strSelQueueName: selected QueueName (in case of search it is blank)
         strFrom        : W or F or S
         W              : Workitem list form any queue
         F              : Workitem list form Filter
         S              : Workitem list form Search
    */

   return   true;
}
function customFieldForCropping(){ 
  // return the name of string type array variable for displaying combo for it on crop document page.
 return ""; 
}

function customDataDefName(strProcessname, strActivityname, strUsername, strDocType){
 
    /*
         strProcessname :   Name of the Current Process
         strActivityname:   Name of the Current Activity    
         strUsername    :   Current Logged in Username
         strDocType     :   Document type to be associated with Dataclass
         return         :   DataDefinition Output XML string.
    */

     return ("");
}
function OkConversationClick() {

}
function customClick(linkName){
    return true;
  }
function docAndFormAppletHeight(strprocessname,stractivityName){
  var strDocAndFormHeight="";                     // 180 need to be subtracted from screen height for MenuBar.
  // strDocAndFormHeight="<DocHeight>"+strDocHeight+"</DocHeight><FormHeight>"+strFormHeight+"</FormHeight>";
  return strDocAndFormHeight;
}
function enableDone(strSelQueueName,strFromSearch){    
    return true;
}

function enableInitiate(strSelQueueName,strFromSearch){
 return true;

}

function isSaveOnClose(strProcessName,strActivityName) {
return true;
}

function LinkedWiClick()
{
	return true;
}

function worklistHandler(from,wiInfo){
    /*
       from             : reassign
       wiInfo           : Selected workitem information
    */
  return true;
}
function validateCropDocTypeName(DocTypeName){
  return true;
}
function UploadDocClick(){
     return true;
}
function isEnableDownloadFlag(strprocessname,stractivityName)
{
return true;
}
function isEnableEditDocFlag(strProcessname,strActivityname )
{
return true;
}
function workitemOperation(opt,ext){
    if(wiproperty.locked != 'Y') {
        if(opt=="S"){
            mainSave();
        }else if(opt=="D"){
            if(wiproperty.operationOption== 'done')
                done();
            else if(wiproperty.operationOption== 'introduction')
                introduceWI();
        }
    }
    if(opt=="C"){
        closeWorkdesk();
    }
}

function getSelectedDocumentDetails()
{
    var dataXMl="";
    var objCombo=document.getElementById('wdesk:docCombo');
    var strDocIndex=objCombo.value;
    var strDocName=objCombo[objCombo.selectedIndex].text;
    dataXMl += '<Document><DocumentIndex>'+strDocIndex+ '</DocumentIndex><DocumentName>'+strDocName+'</DocumentName></Document>';
    return dataXMl;

}

function chkForRaisedExcp(selindx, seltxt)
{

/*   var retExp = getInterfaceData('E');
   for(var i=0;i< retExp.length;i++){
        var exceptionName = retExp[i].name;
        var seqid = retExp[i].seqid;
        var RaiseComment=retExp[i]. RaiseComment;
   }
*/
return true;
}

function ReferClick(commentsRfer,referTo,referBY,from)
{
  /*  commentsRfer    : Refer Comment
      referTo         : User  to which workitem is reffered
      referBY         : User who refer the workitem
      from            : WDESK or WLIST
      from is 'WDESK' : when reffered by opening the workitem i,e from workdesk
      from is 'WLIST' : when reffered without opening workitem i,e from workitem list
  */
   return true;
}

function ReassignClick()
{
	return true;
}

function getDoneInformation(){
    /*   user name can be found in variable : username
                 e.g. alert(username);  */

    /* following loop will get processincstanceid activityName and processName of the selected done workitems */
    var ctrlTable=document.getElementById("frmworkitemlist:pnlResult");
    var checkboxId="frmworkitemlist:checkBox_";
    var rowCount = ctrlTable.rows.length;
    if(rowCount>0) {
        for(var iCount = 0; iCount < rowCount-2;iCount++)
        {
            var wiClicked=document.getElementById(checkboxId+iCount);
            if(wiClicked.checked){
                    
                var jsonOutput=document.getElementById("frmworkitemlist:hidWIJson"+(iCount+1)).innerHTML;
                jsonOutput= eval("("+jsonOutput+")");
                var arrobjJsonOutput= jsonOutput.Outputs;
                for(var i=0;i<arrobjJsonOutput.length;i++){
                    var outputJson=arrobjJsonOutput[i];
                    var objJson=outputJson.Output;
                    var activityName,processName,processInstanceId;
                    if(objJson.Name=='ActivityName'){
                        //listParam.push(new Array(objJson.Name,encode_ParamValue(objJson.Value)));
                        activityName=+objJson.Value;
                    }
                    if(objJson.Name=='RouteName'){
                        //  listParam.push(new Array(objJson.Name,encode_ParamValue(objJson.Value)));
                        processName=objJson.Value;
                    }
                    if(objJson.Name=='ProcessInstanceID'){
                        //  listParam.push(new Array(objJson.Name,encode_ParamValue(objJson.Value)));
                        processInstanceId=objJson.Value;
                    }
                }
            }
        }
    }
}

function isDefaultDocument(processName,activityName){
          return true;
} 

function customDone(opt)
{
    //opt=1 for  done and bring next workitem
    //opt=2 for only done
    if(isFormLoaded==false)
        return;
    showProcessing();
    if(!form_cutomValidation("D")){
        hideProcessing();
        return false;
    }
    if(!saveFormdata('formDataTodo','done')){
        hideProcessing();
        return false;
    }

    handleDoneWI(opt);
}
function customIntroduce(opt)
{
    //opt=1 for  done and bring next workitem
    //opt=2 for only done
    if(isFormLoaded==false)
        return;
    showProcessing();
    if(!form_cutomValidation("D")){
        hideProcessing();
        return false;
    }
    var batchflag=document.getElementById('wdesk:batchflag').value;
    if(!saveFormdata('formDataTodo','introduce')){
        hideProcessing();
        return false;
    }
    handleIntroduceWI(opt);

}

function noClickAfterDone(){

}
function customUserList(strUname){

    /*
         strqueueId       :   Name of the queue selected
         strUname         :   Current Logged in Username
         userPersonalName :   User's personal name (to whom workitems to be reassigned)
         userName         :   User's name (to whom workitems to be reassigned) 
         userIndex        :   User's index (to whom workitems to be reassigned)
         return           :   false
    */  
//         Usage:

//        var queueId = document.getElementById("reassignworkitem:hidQueueId").value;
//        document.getElementById('reassignworkitem:bp:UserName').value=userName;
//        document.getElementById('reassignworkitem:hidUserIndex').value=userIndex;
//        document.getElementById('reassignworkitem:hidUserName').value=userName;
//              
//        return false; 
		   
    return true;
}

function customUserListForSetDiversion(strUname){

    /*
         strqueueId       :   Name of the queue selected
         strUname         :   Current Logged in Username
         userPersonalName :   User's personal name (to whom workitems to be reassigned)
         userName         :   User's name (to whom workitems to be reassigned) 
         userIndex        :   User's index (to whom workitems to be reassigned)
         return           :   false
    */  
//         Usage:

//        document.getElementById('setdiversion:assignedName').value=userName;
//        document.getElementById('setdiversion:hidAssignedToIndex').value=userIndex;
//        document.getElementById('setdiversion:hidAssignedToName').value=userName;
//              
//        return false; 
		   
    return true;
}
function referBtnClick(referTo){
//alert(referTo); 
 return true;
}

function validateUploadFormFieldRestriction(fileName){
    var win_workdesk = window.opener;
    var formBuffer;
    var winList=win_workdesk.windowList;
    var formWindow=getWindowHandler(winList,"formGrid");
    if(typeof formWindow!='undefined'){
        if(win_workdesk.wiproperty.formType=="NGFORM")
        {
            if(!(win_workdesk.ngformproperty.type=="applet"))
                formBuffer = new String(formWindow.document.wdgc.FieldValueBag);
            else if(win_workdesk.ngformproperty.type=="applet")
            {
                if(win_workdesk.bDefaultNGForm){
                    formBuffer=formWindow.document.wdgc.getFieldValueBagEx();
                }
                formBuffer=formBuffer+"";
            }
        }
    }
     // Write custom code here for ngform. Parse formBuffer and use if/else logic to return false if filename and field value doesn't match else return true;
    return true;
}
function excphook(strRaiseComnt ,strRaiseExp, strRaiseExpName ){
    raiseComnt = strRaiseComnt;
    raiseExp   = strRaiseExp;
    raiseExpName = strRaiseExpName;
    raiseExcep_open('Y');
}


function customRaiseExp(){
    return false;
}

function setCustomExpVar()
{
   document.getElementById("raise:comnt").value = window.parent.raiseComnt;
   document.getElementById("raise:Exp").value = window.parent.raiseExp;
   document.getElementById("raise:expName").value = window.parent.raiseExpName;
}

function setColorForDocumentList(pid,wid){
  /*if(pid=="WF-00000000000000006-gen7" && wid=="1"){
        var objCombo = document.getElementById('wdesk:docCombo');
        var arr=["red","blue"];
        for(var index2=0;index2<objCombo.length;index2++){
            
            var docType=objCombo.options[index2].text;
            if ((docType.indexOf("(") != -1))
                docType = docType.substring(0,docType.indexOf("("));
            if(docType =="doc1"){
                objCombo.options[index2].style.color=arr[0];
            }else if(docType =="doc2"){
                objCombo.options[index2].style.color=arr[1];
            }
        }
    }*/
    return true;
}


function ChangeColorOnComboSelect(docindex){
    try{
        var objCombo = document.getElementById('wdesk:docCombo');     
      objCombo.style.color = objCombo.options[docindex].style.color;
    }catch(e){ }
}
function StartSessionActiveTimer()
{
    var interval = 30;   //interval in seconds

    StartCheckIsAdminTimer(interval);
}

function StopSessionActiveTimer()
{
    StopCheckIsAdminTimer();
}
function isZoningRequired()
{
   
 /*
   var objCombo = document.getElementById('wdesk:docCombo');
   var strDocName=objCombo[objCombo.selectedIndex].text;

   activityName : Activity Name
   strDocName   : selected doc name (contains doc type)
   return : false for the Doc types for which no zoning is required
*/
   return true;

}

function customHighlightZone()
{
    /*
     drawExtractZone (int zoneType, int x1, int y1, int x2, int y2, int zoneColor, int thickness, boolean isMutable)
    
Where 
	 zoneType Type of Extract Zone � Permissible values are the following defined constants:
     EXT_ZONE_SOLID_RECT = 1 (draws hollow rectangle)
     EXT_ZONE_HIGHLIGHT = 2 (draws highlighted rectangle)
     x1 x-coordinate of top-left corner of the zone
     y1 y-coordinate of top-left corner of the zone
     x2 x-coordinate of bottom-right corner of the zone
     y2 y-coordinate of bottom-right corner of the zone
     zoneColor Color of extract zone (for e.g., dvBlue = 170, dvYellow = 16776960, dvBlack = 0, dvLightGray = 8421504)
     thickness thickness of the extract zone. Permissible values are integer values between 1 and 5 pixels
     isMutable Specifying whether the extract zone is mutable i.e. it can be selected, moved or resized or not.

For example
	 
     if(document.IVApplet)
        document.IVApplet.drawExtractZone(2, 150, 150, 580, 580, 16776960 , 5,true);
		
    */
    
}

function enableOverwriteInImportDoc(strprocessname,stractivityName ,docType){
    /*

      strprocessname    : Process Name
      stractivityName   : Activity Name
      docType           : Document Type
      return false for the docType  for which overwrite to be disabled , Note that this hook will work only if no modify right on that docType
    */
return true;
}

function  RefreshClientComp(){
    try{
     /*var ref = window.parent.getComponentRef(sourceInsId).contentWindow;
	 ref.reloadPage(pid);  /*implemented by the calling page*/
         }catch(e){}
}
/*function eventDispatched(pId,pEvent){
	switch(pEvent.type)
    {           
        case 'click':
        {
            switch(pEvent.srcElement.id)
            {
				case 'opt1':	alert('');
				break;
			}
		}	
	}
}*/
//Added for Britannia AP process and SP process Event Dispatch By Nanjunda Moorthy

function eventDispatched(pId,pEvent){
	
	
var processname=window.parent.strprocessname;
var activityName=window.parent.stractivityName;
	
	if(processname == 'AP')
    {
			
		return eventDispatched_AP(pId,pEvent);
		
    }
	if(processname == 'SP')
    {
		
		return eventDispatched_SP(pId,pEvent);
		
    }
}

function getExtParam(processName, activityName)
{
  var retXML =  "";
   /*
     This function will return the  process variables and these values to be saved in workitem while Save / Done / Introduce operation.
   */
 // retXML =  "<Attributes><Attribute><Name>qname</Name><Value>dssD</Value></Attribute><Attribute><Name>qage</Name><Value>65</Value></Attribute></Attributes>";
  return retXML;
}

/*
 *sample code for field validation (Global Method associated with process variant field)
function validateAccNo(ref){
	var strPrefix = "wdesk";
	var field = ref;
	var bError = false;
	var msg = "";
	var dtime;//time to display the message
	var rem = "true";//to remove the message after specified time or not
	var fieldLength = field.value.length;
	var fieldValue = field.value;
	if(fieldLength>15){
		bError = true;
        msg = "Length of account number should be less than 15";
    }
	if(!bError){
		var i=0;
	    if(fieldValue=='-'){
			bError = true;
			msg = "Invalid Number Entered";
		}
		if(!bError && fieldValue.charAt(0)=='-')
			i=1;

		for (; i < fieldValue.length; i++)
		{   
			var c = fieldValue.charAt(i);
			if (!((c >= "0") && (c <= "9"))){ 
				bError = true;
				msg = "Invalid Number Entered";
				break;
			}
		}

	}
	
	if(bError){
                var workdeskView = (typeof wdView == "undefined")? '': wdView;
		if((isEmbd == 'Y') && (workdeskView == "em") && document.getElementById("wdesk:indicatorPG"))
			document.getElementById("wdesk:indicatorPG").style.display = "inline";

		var messageDiv=document.getElementById("wdesk:messagediv");
        if(messageDiv){
            var messagePG = document.getElementById("wdesk:messagedivPG");
            if(messagePG){                
                var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1; 
                if(isSafari){
                    messagePG.style.width = "auto";
                    messagePG.style.display = "inline-block";
                } else {
                    messagePG.style.display = "inline-table";
                }
                messageDiv.innerHTML= msg; 
				messagePG.style.display = "inline-table";
            }
        }
		
		if(!dtime) {
			dtime=3000;
		}
		if(rem) {
			if(rem=="true") {
				setTimeout("removemessageFromDiv()",dtime);
			}
		}
	}
}
*/

function yesBringNextWI(strprocessname,stractivityName)
{
/* strprocessname : Process Name
 * stractivityName : Activity Name
 * return false will not open Bring Next Workitem in dialog box
 * will work only when there is entry YesBringNextWI=N in webdesktop.ini
*/
 return false;
}
function disableConfirmDone(strprocessname,stractivityName)
{
/* strprocessname : Process Name
 * stractivityName : Activity Name
 * return false will  open confirm done window
 * will work only when there is entry ConfirmDone=N in webdesktop.ini
*/
var processname=window.parent.strprocessname;
var activityName=window.parent.stractivityName;
if(processname == 'AP')
    {  
		if(activityName=='Parking')
		{
			return true;
		}
	   else
	   {
			return false;
	   }
   }
 if(processname == 'SP')
    { 
   return false;
    }
 //return false;
}

function nameUploadDocument(strDocName,frm,processname, activityname,username)
{

/*
    alert(strDocName);
    alert(frm);
    alert(processname);
    alert(activityname);
    alert(username);
    alert(strDocName); 
*/	
return strDocName;
}

function mandatoryCommentsBeforeReassign(strprocessname,stractivityName)
{
/*  if(document.wdgc != undefined)
    {
    if( document.wdgc.getNGValue("formcontrolname") == "" ) {   
    alert(ENTER_YOUR_MSG_HERE);
    return false;   
    }
    else
    return true;
    }    
*/
    
/*
     *formcontrolname : name of form control on which you want apply validation
     *return true:will open reassign window
     *return false :will not open reassign window
*/
    return true;
}

function isCustomValidException(selectedExcpName)
{
    // if it returns false , the exception will not be raised
    return true;
}

function postHookGenerateResponse(docIndex, docName)
{
 /*
         docIndex: Document Index of the added Document
		 docName: Document Type of the added Document
 */

}

function cropDocTypeList(strprocessname,stractivityName,strPageNo,docName)
{
    /*  strprocessname : Process Name
        stractivityName : Activity Name
     *  strPageNo       : Page No from which image is cropped
     *  docName         : Document Type & Name from which image is cropped
     *  
     *  return the doc types as Comma separated e.g.- "doc1,doc2"
     *  Doc types returned are CASE SENSITIVE. 
     */
    return  "";
}

function importDocumentPrehook(docTypeName)
{
   /* Sample custom code to retrieve Document typon executeActies added in import Document Window combo list as well in workitem window's added documents and
    * Will not upload the documents if this Hook returns false
    *
   var objCombo = window.opener.document.getElementById('wdesk:docCombo');
    if(typeof objCombo != 'undefined')
      {
        for(var index2=0;index2<objCombo.length;index2++){

            var importedDocType=objCombo.options[index2].text;
            if(importedDocType.indexOf(docTypeName)== 0)
             {
                alert("Document Already Added");
                return false;
             }

        }
      }
   */
    return true;
}
function isDebug(strprocessname,stractivityName)
{
/*    if(strprocessname=='TestGen' && stractivityName=='Work Introduction1')
        {
            return true;
        }
*/
    return false;
}

function templateData(){

}

function isDisablePrintScreen(strProcessname, strActivityname)
{
    // return true to disable print screen
    return false;
}

function isNewVersionDoc(processName, activityName){ 
    
    return true;
}
function isOverWriteDoc(processName, activityName){
    
     return true;
}

function deleteDocFromComboList(docIndex)
{
    var objCombo = window.document.getElementById('wdesk:docCombo');
    var isFound= false;
     for(var i=0;i<objCombo.options.length;i++)
       {
        if(objCombo.options[i].value == docIndex)
         {
         objCombo.options[i]=null;
         isFound = true;
         break;
         }
       }
       
       if(isFound == false) {
           alert(NO_MATCHING_DOCUMENT);
       }
}
function isEnableDownloadPrint(strProcessname, strActivityname, strUsername)
{
    // If returned true will allow print and download option even to thos doc types which have no modified rights
    // By default do not display toolbar by making entry in ShowDefaulToolbarFlag=N
    return false;
}

function getdocTypeListExt(docListObj)
{
var docTypeList = new Array();
var count = -1;
// How to Capture Existing Doc List

   /* var tmpDocTypeList = docListObj;
    for(var i=0 ; i<tmpDocTypeList.length; i++)
    {
     alert("Doc Type = "+tmpDocTypeList.options[i].value);
    }
*/

//Added By Harinatha R on 11/01/2017, To set Document Type filters under Import Document window
	var processname=window.parent.strprocessname;
	var activityName=window.parent.stractivityName;	
	
    var element = null;
    try{
        element = window.opener.document.getElementById("ngformIframe").contentWindow;
    }
    catch(ex){
        element = window.opener.document.getElementById("ngformIframe");
    }
	if(processname == 'SP')
    {
		//alert('ProcessName : ' + processname + ' Activity Name : '+ activityName);
		if(activityName=='Initiator' || activityName=='Rework'){
			if(element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'ISD')
			{
        
				docTypeList=["Invoice","ExcisableProducts","ExemptedProducts","CommonCredit","ReversalValue","PlantLevelAnnexure","InvoiceCalculation","RegionalReversals","CAL1_Annexure","BID1_Annexure","CP04_Annexure","CP06_Annexure","CP11_Annexure","CP12_Annexure","CP15_Annexure","CP17_Annexure","CP19_Annexure","CP20_Annexure","CP21_Annexure","CP31_Annexure","CP33_Annexure","CP34_Annexure","CP36_Annexure","CP38_Annexure","CP51_Annexure","CP85_Annexure","CP86_Annexure","CPD0_Annexure","CPC9_Annexure","CPE1_Annexure","CPG3_Annexure","CPH0_Annexure","CPH3_Annexure","CPI5_Annexure","CPI6_Annexure","CPI7_Annexure","CPK1_Annexure","CPK5_Annexure","GUJ1_Annexure","ORS1_Annexure","PAT1_Annexure","PER1_Annexure","PFC4_Annexure","PFF2_Annexure","PFK7_Annexure","SB01_Annexure","ZCPH5_Annexure","ZCPK0_Annexure","UTC1_Annexure","CP55_Annexure"];
			}
			
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'RoutineRFA' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'SupplementaryRFA' ) && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'Service Tax')
			{
        
				docTypeList=["ST_Working", "ST_Others", "ST_SupportingDoc"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'RoutineRFA' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'SupplementaryRFA' ) && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'TDS')
			{
        
				docTypeList=["TDS_Calculation", "TDS_Others", "TDS_SupportingDoc", "TCS_Calculation", "TCS_SupportingDoc", "TCS_Others"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'RoutineRFA' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'SupplementaryRFA' ) && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'TDS195')
			{
        
				docTypeList=["TDS195_Calculation", "TDS195_others", "TDS195_Supporting"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'RoutineRFA' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'SupplementaryRFA' ) && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'VAT')
			{
        
				docTypeList=["VAT_Calculation","VAT_SupportingDoc","VAT_Others","CST_Calculation","CST_Supporting","CST_Others"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'RoutineRFA' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'SupplementaryRFA' ) && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'Entry Tax')
			{
        
				docTypeList=["Entry_Calculation","Entry_Others","Entry_Supporting"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'RoutineRFA' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'SupplementaryRFA' ) && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'Excise Duty')
			{
        
				docTypeList=["ExciseDuty_Calculation","ExciseDuty_SupportingDoc","ExciseDuty_Others"];
			}
			//
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Reconciliation' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Non-RoutineRFA'  || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'AdditionalRFA' ) && (element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'Service Tax')) 
			{
        
				docTypeList=["ST_Working", "ST_Others", "ST_SupportingDoc"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Reconciliation' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Non-RoutineRFA' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'AdditionalRFA' ) && (element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'TDS') )
			{
        
				docTypeList=["TDS_Calculation", "TDS_Others", "TDS_SupportingDoc", "TCS_Calculation", "TCS_SupportingDoc", "TCS_Others"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Reconciliation' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Non-RoutineRFA'  || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'AdditionalRFA' ) && (element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'TDS195'))
			{
        
				docTypeList=["TDS195_Calculation", "TDS195_others", "TDS195_Supporting"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Reconciliation' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Non-RoutineRFA'  || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'AdditionalRFA' ) && (element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'VAT'))
			{
        
				docTypeList=["VAT_Calculation","VAT_SupportingDoc","VAT_Others","CST_Calculation","CST_Supporting","CST_Others"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Reconciliation' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Non-RoutineRFA' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'AdditionalRFA' ) && (element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'Entry Tax'))
			{
        
				docTypeList=["Entry_Calculation","Entry_Others","Entry_Supporting"];
			}
			if((element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Reconciliation' || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'Non-RoutineRFA'  || element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'AdditionalRFA' ) && (element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'Excise Duty'))
			{
        
				docTypeList=["ExciseDuty_Calculation","ExciseDuty_SupportingDoc","ExciseDuty_Others"];
			}
			//
			if(element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'MIS' && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'TDS')
			{
        
				docTypeList=["TDS_MIS"];
			}
			if(element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'MIS' && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'VAT')
			{
        
				docTypeList=["VAT_MIS"];
			}
			if(element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'MIS' && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'Entry Tax')
			{
        
				docTypeList=["Entrytax_MIS"];
			}
			if(element.com.newgen.omniforms.formviewer.getNGValue("TypeOfRequest") == 'MIS' && element.com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation") == 'Custom Duty')
			{
        
				docTypeList=["CustomsDuty_MIS"];
			}

		}		
		if(activityName=='ChallanUpload' || activityName=='Rework_Challan'){
		
			docTypeList=["Challan_1", "Challan_2", "Challan_3"];
		}
		if(activityName=='ReturnsUpload' || activityName=='Rework_Returns'){
		
			docTypeList=["ReturnsDocument_1", "ReturnsDocument_2", "ReturnsDocument_3"];
		}			
		
    }
	//Ended By Harinatha R on 11/01/2017


// Return custom Doc List Array as below , It must be from existing above
 
  /* docTypeList[++count] = "tabc";
   docTypeList[++count] = "txyz";
*/

return docTypeList;
}
function CustomCrop(strprocessname,stractivityName)
{
/* strprocessname : Process Name
 * stractivityName : Activity Name
 * return false will not open custom Crop Document Window
*/
return true;
}
function croppedByField(strprocessname,stractivityName){
    // return the name of variable
    return "";
}

function isDocOrgName(strprocessname, stractivityName)
{
/* strprocessname : Process Name
 * stractivityName : Activity Name
 * return false will not display 
   document's original name (document file's name) but the
   Doc Type only even if it is cofigured through webdesktop.ini to display its
   original name by entry (DocOrgName=Y)
*/  
 return true;
}

function isAnnotationToolbar(strProcessname,strActivityname )
{
   // if(strProcessname == 'AParentForm' && strActivityname == 'Standard Workdesk1')
   //     return false;
   // else
        return true;
}
function currentSelPageInImage(strPageInImage){
    
    //strPageInImage: contains current page no. of a Multi-page Tiff
    
}
function extractZoneModified(zoneType, x1, y1, x2, y2, createModifyFlag, zoneID, partitionInfo)
{
 /*
  *This method gets called when zone gets drawn or selected or modified
  */   
}
function customDownloadedDocName(docName,docOrgNamge,DocExt,pid){
    var downloadedDocName="";
   /* alert("docName -> "+docName+" docOrgNamge -> "+docOrgNamge+" DocExt -> "+DocExt+" pid -> "+pid)
     docName--> Document type
     docOrgNamge--> disk name of the document
     DocExt--> document exttension
     pid--> processinstanceid
     Note : Add the document extension after the document name with '.' e.g downloadedDocName=docName+pid+"."+DocExt.
   */
   return downloadedDocName;

}

function reloadNewAddedDoc(strprocessname,stractivityName)
{
   /*return
    *true  : it will reload the applet to show newly added doc
    *false : it will not reload the applet to show newly added doc
    **/
   return true;
}

function isUploadedDocType(filepath,docTypeName){
    /*var docJsonList=window.opener.getInterfaceData("D");
    var returnFlag=true;
    for(var i=0;i<docJsonList.length;i++){
        if(docJsonList[i].name.indexOf(docTypeName)>-1 && filepath.indexOf(docJsonList[i].DiskName)>-1){
            returnFlag=false;
            break;
        } 
    } 
    if(returnFlag==false){
        alert("document is already attached");
        return returnFlag;
    }*/
    
    //alert("docJsonList.name"+docJsonList[i].name);
    //alert("docJsonList.DiskName"+docJsonList[i].DiskName);

   return true; 
}

function modifyDocComment(processname,activityname,username,docTypeName){
    return "";
}
function wiLockForMeClick(){
     return true;
}
function wiReleaseClick(){
     return true;
}


function isDocumentAttached(){
    var docAttached = false;
    var objCombo = docWindow.document.getElementById('wdesk:docCombo');
    
    if(objCombo != null){
        if(objCombo.length > 0){
            if(objCombo.length == 1){
                if(objCombo.options[0].value == "-1"){
                    docAttached = false;
                } else {
                    docAttached = true;
                }
            } else {
                docAttached = true;
            }
        }
    }
    
    return docAttached;
}
function getWiFormValues()
{
    //Function returns attributes xml composing of queue variables values present in Custom Introduce form 
    var str = "";
    var valueArr = null;
    var val = "";
    var cmd = "";
    var fobj = frames['NewWIFRAME'].document.forms['wdesk']
    if(typeof fobj == 'undefined')
        return "";
    
    var formid=fobj.id;
    
    var strAttribXML="<Attributes>";
    if(formid=='wdesk'){
        for(var i = 0;i < fobj.elements.length;i++)
        {
            switch(fobj.elements[i].type)
            {
                case "textarea":
                case "text": 
                    strAttribXML=strAttribXML+"<"+fobj.elements[i].name+">"+fobj.elements[i].value+"</"+fobj.elements[i].name+">";
                    break;
               /* case "select-one":
                    if(fobj.elements[i].selectedIndex!=-1)
                        strAttribXML=strAttribXML+"<"+fobj.elements[i].name+">"+fobj.elements[i].options[fobj.elements[i].selectedIndex].value+"</"+fobj.elements[i].name+">";
                    break; 
                case "checkbox":
                    if(fobj.elements[i].checked)
                    {
                        strAttribXML=strAttribXML+"<"+fobj.elements[i].name+">"+fobj.elements[i].value+"</"+fobj.elements[i].name+">";
                    
                    }
                    break;
                case "hidden": 
                      strAttribXML=strAttribXML+"<"+fobj.elements[i].name+">"+fobj.elements[i].value+"</"+fobj.elements[i].name+">";
                     break; */
            }
        }
    }
    strAttribXML=strAttribXML+"</Attributes>";
    return strAttribXML;
}

function customCloseMessage()
{
    //ALERT_CLOSE_SAVE_CONFIRM="Do you want to save the workitem before closiung the window?";
    return ALERT_CLOSE_SAVE_CONFIRM; 
}

function handleExcp(excpHandlerJson)
{
excpHandlerJson = customEventHandler(excpHandlerJson);
document.getElementById("excpJson").value = JSON.stringify(excpHandlerJson);
document.getElementById("btnEventHandler").click();   // For executing any custom code in java
} 
// this method is called when you call ValidatorException from java..u will get the parameters specified from java code in this js method.. 
function customEventHandler(excpHandlerJson)
{
    excpHandlerJson=JSON.parse(excpHandlerJson);
    var eventHandlerName = decode_utf8(excpHandlerJson.EventHandler); // 3rd parameter in from Customexceptionhandler constructor
    var params = JSON.parse(excpHandlerJson.Parameters) // 4th parameters which is hashmap in form of JSON 
    var firstParam = decode_utf8(excpHandlerJson.Summary); //1st parameter 
    var secondParam = decode_utf8(excpHandlerJson.Detail); //2nd parameter 
    var jsonParam = {};
    for( var key in params )
    {
        jsonParam[decode_utf8(key)] = decode_utf8(params[key]);
    }
    params = jsonParam;

// custom coding goes here 

    

return excpHandlerJson;
}