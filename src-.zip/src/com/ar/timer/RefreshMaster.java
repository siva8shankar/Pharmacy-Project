/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: RefreshMaster.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.ar.timer;

import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.newgen.omni.webdesktop.ngappbean.ngappbean;

public class RefreshMaster {

	private String port = "8180";
	private String ip = "127.0.0.1";
	private String protocol = "http";
	private String cabinetName = "VendorPortalDB";
	static ngappbean bean = null;
	private String dbType = "mssql";

	public void checkMasterUpdate() {
		String sProcName = "NG_TEST_FETCH_MASTER_DATA";
		CallableStatement callablestatement = null;
		PreparedStatement prepareStatement = null;
		ResultSet resultset = null;
		Connection con = null;
		try {
			System.out.println("cabinetName- ");
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://192.168.25.105:1433;databaseName=VendorPortalDB",
					"login_apo", "loginapo123#");
			if (dbType != null && !dbType.equalsIgnoreCase("") && dbType.equalsIgnoreCase("oracle")) {
				callablestatement = con
						.prepareCall("{ call " + sProcName + "('CHECKUPDATE','" + ip + ":" + port + "',?)}");
				callablestatement.registerOutParameter(1, -10);
				System.out.println((new StringBuilder()).append("Result App Start:-")
						.append(callablestatement.execute()).toString());
				resultset = (ResultSet) callablestatement.getObject(1);
			} else if (dbType != null && !dbType.equalsIgnoreCase("") && dbType.equalsIgnoreCase("mssql")) {
				callablestatement = con
						.prepareCall("{ call " + sProcName + "('CHECKUPDATE','" + ip + ":" + port + "')}");
				System.out.println((new StringBuilder()).append("Result App Start:-")
						.append(callablestatement.execute()).toString());
				resultset = (ResultSet) callablestatement.getResultSet();
			}
			System.out.println("resultset @ masterupdate--" + resultset);
			System.out.println("rs next--" + resultset.next());
			System.out.println("Check Update Flag--" + resultset.getString(1));
			if (Integer.parseInt(resultset.getString(1)) > 0) {
				try {
					URL url = new URL(protocol + "://" + ip + ":" + port
							+ "/portal/com/ar/timer/MasterServlet?update=true&column_name=" + ip + ":" + port
							+ "&cabinetName=" + cabinetName + "&dbType=" + dbType);
					url.openStream();
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else
				System.out.println("already Updated" + resultset.getString(1));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (resultset != null) {
					resultset.close();
					resultset = null;
				}
				if (callablestatement != null) {
					callablestatement.close();
					callablestatement = null;
				}
				if (con != null) {
					// NGDBConnection.closeDBConnection(con,cabinetName);
					con = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}
}
