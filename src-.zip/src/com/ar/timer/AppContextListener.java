/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AppContextListener.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.ar.timer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.json.JSONObject;

import com.newgen.omni.webdesktop.ngappbean.ngappbean;


public class AppContextListener implements ServletContextListener {

	private static ngappbean bean=null;
	private String cabinetName;
	private String dbType="mssql";
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		
		System.out.println("Context has been destroyed of webdesktop.war at"+(new java.util.Date()));

	}

	@Override
	public void contextInitialized(ServletContextEvent servletContextEvent) {

		System.out.println("Context has been Initialized of webdesktop.war at"+(new java.util.Date())); 
		com.newgen.omni.webdesktop.ngappbean.ngappbean ngp=new com.newgen.omni.webdesktop.ngappbean.ngappbean();
		servletContextEvent.getServletContext().setAttribute("wfapplication1",ngp);		
	    bean = (ngappbean) servletContextEvent.getServletContext().getAttribute("wfapplication1");
		System.out.println("SetBean Method called from context");
		
		}
	
	static String  readFile(String fileName) {
		StringBuilder sb=null;
		BufferedReader br=null;
	   
		System.out.println();
	    try {
	    	br = new BufferedReader(new FileReader(fileName));
	        sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	       
	    }
	    catch(Exception e)
		{
			System.out.println("readFIleExcepAppcontext--"+e);
		}
	    finally {
	        try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    return sb.toString();
	}
	
		
		@SuppressWarnings("unused")
		public void setBeanData(ngappbean bean, ServletContextEvent servletContextEvent)
		{
			String sProcName="NG_TEST_FETCH_MASTER_DATA";
			CallableStatement callablestatement=null;
		
					
        	//String connectionURL = "jdbc:sqlserver://192.168.25.105:1433\\VendorPortalDB;user=login_apo;password=loginapo123#";
	        ResultSet resultset=null;
	        Connection con = null;
	       
	        try {
	        	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	        	 con = DriverManager.getConnection ("jdbc:sqlserver://192.168.25.105:1433;databaseName=VendorPortalDB","login_apo","loginapo123#");
				//con=NGDBConnection.getDBConnection(cabinetName,"");
				if(dbType!=null && !dbType.equalsIgnoreCase("") && dbType.equalsIgnoreCase("oracle"))
				{
					callablestatement = con.prepareCall("{ call "+sProcName+"('APPSTART','',?)}");
					callablestatement.registerOutParameter(1, -10);
					System.out.println((new StringBuilder()).append("Result App StartAppcontext:-").append(callablestatement.execute()).toString());
					resultset = (ResultSet)callablestatement.getObject(1);
				}
				else if(dbType!=null  && !dbType.equalsIgnoreCase("") && dbType.equalsIgnoreCase("mssql"))
				{
					callablestatement = con.prepareCall("{ call "+sProcName+"('APPSTART','')}");
					System.out.println("callablestatement:::"+"call "+sProcName+"('APPSTART','')}");
					System.out.println((new StringBuilder()).append("Result App StartAppcontext:-").append(callablestatement.execute()).toString());
					resultset = (ResultSet)callablestatement.getResultSet();
				}
				System.out.println("resultset @ Appcontext--"+resultset);
				if(resultset==null)
				{
					System.out.println("Master Data table is empty");
				}
				else{
				while(resultset.next())
		        {
					if(resultset.getString(1)!=null && resultset.getString(2)!=null)
					{
					  System.out.println("AppContext not null");
					  ngappbean.setBeanData(resultset.getString(1).toString(),resultset.getString(2).toString());
					  String FORMTYPE_MASTER = ngappbean.getBeanData("CompanyID");
					  
					  splitComData s= new splitComData();

					  LinkedHashMap<String, ArrayList<String>> CompanyDataMap=  s.getCompanyData(FORMTYPE_MASTER);

					  if(CompanyDataMap!=null){
						 ServletContext s_con= servletContextEvent.getServletContext();
					        s_con.setAttribute("CompanyDataMap",CompanyDataMap);
						//getServletContext().setAttribute("CompanyDataMap",CompanyDataMap);
						System.out.println(s_con.getAttribute("CompanyDataMap")); 	
						JSONObject jObj = new JSONObject();
						jObj.put("CompanyDataMap", CompanyDataMap);
						   s_con.setAttribute("jsonComData",jObj);	
						   System.out.println(s_con.getAttribute("jsonComData"));
					  }
					  
					
						// System.out.println("CompanyDataMap:"+CompanyDataMap);
					
					  }
					  
					}
					   
					
		        }
				
	        } 
	        catch (Exception e) {
	        	// TODO Auto-generated catch block
	        	System.out.println("Exception in setBeanData method of AppContextListener");
	        	e.printStackTrace();
	        }
	        finally
	        {
				try
		        {
		            if(resultset != null)
		            {
		                resultset.close();
		                resultset = null;
		            }
		            if(callablestatement != null)
		            {
		                callablestatement.close();
		                callablestatement = null;
		            }
		            if(con !=null)
		            {
		            	//NGDBConnection.closeDBConnection(con,cabinetName);
		            	con=null;
		            }
		        }
		        catch(Exception e) { e.printStackTrace(); }
		        
	        }
			
		}
		
	
}