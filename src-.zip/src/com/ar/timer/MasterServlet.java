/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: MasterServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/
package com.ar.timer;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.newgen.omni.webdesktop.ngappbean.ngappbean;

// Extend HttpServlet class
public class MasterServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		// Do required initialization
		// System.out.println("Initialized MasterServlet");

	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			if (request.getParameter("update").equalsIgnoreCase("true")) {
				// System.out.println("Inside MasterServlet");
				ServletContext application = getServletContext();
				ngappbean bean = (ngappbean) application.getAttribute("wfapplication1");
				if (bean != null)
					setBeanData(bean, request.getParameter("column_name"), request.getParameter("cabinetName"),
							request.getParameter("dbType"));
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void destroy() {
		// do nothing.
	}

	public void setBeanData(ngappbean bean, String column_name, String cabinetName, String dbType) {
		// System.out.println("Setting Master data....");
		String sProcName = "NG_TEST_FETCH_MASTER_DATA";
		CallableStatement callablestatement = null;
		ResultSet resultset = null;
		Connection con = null;

		try {
			if (cabinetName != null && !cabinetName.equalsIgnoreCase("")) {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				con = DriverManager.getConnection("jdbc:sqlserver://192.168.25.105:1433;databaseName=VendorPortalDB",
						"login_apo", "loginapo123#");
				if (dbType != null && !dbType.equalsIgnoreCase("") && dbType.equalsIgnoreCase("oracle")) {
					callablestatement = con.prepareCall("{ call " + sProcName + "('SELECT','" + column_name + "',?)}");
					callablestatement.registerOutParameter(1, -10);
					// System.out.println((new StringBuilder()).append("Result
					// App Start
					// @MasterServlet:-").append(callablestatement.execute()).toString());
					resultset = (ResultSet) callablestatement.getObject(1);
				} else if (dbType != null && !dbType.equalsIgnoreCase("") && dbType.equalsIgnoreCase("mssql")) {
					callablestatement = con.prepareCall("{ call " + sProcName + "('SELECT','" + column_name + "')}");
					// System.out.println((new StringBuilder()).append("Result
					// App Start
					// @MasterServlet:-").append(callablestatement.execute()).toString());
					resultset = (ResultSet) callablestatement.getResultSet();
				}
				while (resultset.next()) {
					// System.out.println("resultset.getString(1)::resultset.getString(2)--"+resultset.getString(1)+"
					// "+resultset.getString(2));
					if (resultset.getString(1) != null && resultset.getString(2) != null) {
						bean.ResetBeanData(resultset.getString(1).toString());
						bean.setBeanData(resultset.getString(1).toString(), resultset.getString(2).toString());
					}
				}
			} else {
				// System.out.println("Cabinnet Name "+cabinetName+" not
				// found");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (resultset != null) {
					resultset.close();
					resultset = null;
				}
				if (callablestatement != null) {
					callablestatement.close();
					callablestatement = null;
				}
				if (con != null) {
					// NGDBConnection.closeDBConnection(con,cabinetName);
					con = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}
}