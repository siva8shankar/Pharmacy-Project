/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: splitComData.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.ar.timer;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class splitComData {

	LinkedHashMap<String, ArrayList<String>> CompanyDataMap = new LinkedHashMap<String, ArrayList<String>>();

	public LinkedHashMap<String, ArrayList<String>> getCompanyData(String FORMTYPE_MASTER) {

		if (FORMTYPE_MASTER != null || FORMTYPE_MASTER != "") {

			ArrayList<String> companyDataArr = new ArrayList<String>();

			String[] rowsdata = FORMTYPE_MASTER.split("~");

			for (int i = 0; i < rowsdata.length; i++) {
				String companyName = null;

				String[] columnsdata = rowsdata[i].split("#");
				// System.out.println(columnsdata[1]);
				for (int col = 0; col < columnsdata.length; col++) {
					companyName = columnsdata[1];

					if (CompanyDataMap.containsKey(companyName)) {
						if (!companyDataArr.contains(columnsdata[2]))
							// companyDataArr.add('|' ) ;
							companyDataArr.add(columnsdata[2]);
					} else {
						companyDataArr = new ArrayList<String>();
						companyDataArr.add(columnsdata[0]);
						companyDataArr.add(columnsdata[2]);
					}
				}

				CompanyDataMap.put(companyName, companyDataArr);

			}
		}
		return CompanyDataMap;

	}
}