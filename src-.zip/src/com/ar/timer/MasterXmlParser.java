/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: MasterXmlParser.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.ar.timer;

import java.io.File;
import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class MasterXmlParser {
	
	private Document doc;
	public MasterXmlParser(String filePath)
	{
		try
		{
			//File fXmlFile = new File(filePath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			//doc = dBuilder.parse(fXmlFile);
			doc = dBuilder.parse(new InputSource(new StringReader(filePath)));
			
		}
		catch (Exception e)
	    {
	        e.printStackTrace();
	    }
	}

	public String getTagValue(String tag)
	{
	    
	    NodeList nodeList = doc.getElementsByTagName(tag);
	    int length = nodeList.getLength();
	    if (length > 0)
	    {
	        Node node =  nodeList.item(0);
	        if (node.getNodeType() == Node.ELEMENT_NODE)
	        {
	            NodeList childNodes = node.getChildNodes();
	            String value = "";
	            int count = childNodes.getLength();
	            for (int i = 0; i < count; i++)
	            {
	                Node item = childNodes.item(i);
	                if (item.getNodeType() == Node.TEXT_NODE)
	                {
	                    value += item.getNodeValue();
	                }
	            }
	            return value;
	        }
	        else if (node.getNodeType() == Node.TEXT_NODE)
	        {
	            return node.getNodeValue();
	        }
	    }
	    return "";
	}
	
	public ArrayList<String> getAllTagValues(String tag)
	{
	    ArrayList<String> sList=new ArrayList<String>();
	    NodeList nodeList = doc.getElementsByTagName(tag);
	    int length = nodeList.getLength();
	    if (length > 0)
	    {
	        for(int k=0;k<length;k++)
	        {
	            Node node =  nodeList.item(k);
	            if (node.getNodeType() == Node.ELEMENT_NODE)
	            {
	                NodeList childNodes = node.getChildNodes();
	                int count = childNodes.getLength();
	                for (int i = 0; i < count; i++)
	                {
	                    Node item = childNodes.item(i);
	                    if (item.getNodeType() == Node.TEXT_NODE)
	                    {
	                        sList.add(item.getNodeValue());
	                    }
	                }
	            }
	            else if (node.getNodeType() == Node.TEXT_NODE)
	            {
	                sList.add(node.getNodeValue());
	            }
	        }
	    }
	    return sList;
	}
}


