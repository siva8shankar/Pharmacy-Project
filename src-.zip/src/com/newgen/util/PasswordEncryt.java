/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: PasswordEncryt.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  It is used to encrypt Password
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

//import com.newgen.omni.jts.srvr.DatabaseTransactionServer;
//import com.newgen.omni.jts.srvr.ServerProperty;
//import com.newgen.security.Cryptography;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import org.apache.log4j.Logger;

import com.newgen.security.Cryptography;

public class PasswordEncryt {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	public static final String encode(String paramString) {
		logger.debug("encode Method starts....paramString: " + paramString);

		String str1 = null;
		String str2 = null;
		try {
			str1 = "UTF-8";
			str2 = encode(paramString.getBytes(str1), str1);
		} catch (Exception localException) {
		}
		return str2;
	}

	public static final String encode(String paramString1, String paramString2) {
		String str = null;
		try {
			logger.debug("encode Method starts....paramString1: " + paramString1 + "paramString2 : " + paramString2);

			paramString2 = (paramString2 != null) ? paramString2 : "UTF-8";
			str = encode(paramString1.getBytes(paramString2), paramString2);
		} catch (Exception localException) {
		}
		return str;
	}

	public static final byte[] encode(byte[] paramArrayOfByte) {
		byte[] arrayOfByte1 = null;
		try {
			logger.debug("encode Method starts....paramArrayOfByte: " + paramArrayOfByte);

			byte[] arrayOfByte2 = new byte[6];
			arrayOfByte2[0] = 31;
			arrayOfByte2[1] = 32;
			arrayOfByte2[2] = 33;
			arrayOfByte2[3] = 34;
			arrayOfByte2[4] = 35;
			arrayOfByte2[5] = 36;
			ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
			ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
			Cryptography.encrypt128(localByteArrayInputStream, localByteArrayOutputStream, arrayOfByte2);
			arrayOfByte1 = localByteArrayOutputStream.toByteArray();
			localByteArrayOutputStream.close();
			localByteArrayInputStream.close();
		} catch (Exception localException) {
			loggerErr.error("localException in encode method : " + localException.getMessage());
			localException.printStackTrace();
		}
		return arrayOfByte1;
	}

	public static final String encode(byte[] paramArrayOfByte, String paramString) {
		byte[] arrayOfByte1 = null;
		String str = null;
		try {
			logger.debug(
					"encode Method starts....paramArrayOfByte: " + paramArrayOfByte + "paramString : " + paramString);

			byte[] arrayOfByte2 = new byte[6];
			arrayOfByte2[0] = 31;
			arrayOfByte2[1] = 32;
			arrayOfByte2[2] = 33;
			arrayOfByte2[3] = 34;
			arrayOfByte2[4] = 35;
			arrayOfByte2[5] = 36;
			paramString = (paramString != null) ? paramString : "UTF-8";
			ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
			ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
			Cryptography.encrypt128(localByteArrayInputStream, localByteArrayOutputStream, arrayOfByte2);
			arrayOfByte1 = localByteArrayOutputStream.toByteArray();
			localByteArrayOutputStream.close();
			localByteArrayInputStream.close();
			str = new String(arrayOfByte1, paramString);
		} catch (UnsupportedEncodingException localUnsupportedEncodingException) {
			loggerErr.error("localUnsupportedEncodingException in Password Encryt : "
					+ localUnsupportedEncodingException.getMessage());
			localUnsupportedEncodingException.printStackTrace();
		} catch (Exception localException) {
			loggerErr.error("localException in Password Encryt : " + localException.getMessage());
			localException.printStackTrace();
		}

		return str;
	}

	public static final String decode(String paramString) {
		String str1 = null;
		String str2 = null;
		try {
			logger.debug("decode Method starts....paramString: " + paramString);

			str1 = "UTF-8";
			str2 = decode(paramString.getBytes(str1), str1);
		} catch (Exception localException) {
			loggerErr.error("localException in decode method of Password Encryt : " + localException.getMessage());
			localException.printStackTrace();
		}
		return str2;
	}

	public static final String decode(String paramString1, String paramString2) {
		String str = null;
		try {
			logger.debug("decode Method starts....paramString1: " + paramString1 + "paramString2 : " + paramString2);

			paramString2 = (paramString2 != null) ? paramString2 : "UTF-8";
			str = decode(paramString1.getBytes(paramString2), paramString2);
		} catch (Exception localException) {
			localException.printStackTrace();
		}
		return str;
	}

	public static final byte[] decode(byte[] paramArrayOfByte) {
		byte[] arrayOfByte1 = null;
		try {
			logger.debug("decode Method starts....paramArrayOfByte: " + paramArrayOfByte);

			byte[] arrayOfByte2 = new byte[6];
			arrayOfByte2[0] = 31;
			arrayOfByte2[1] = 32;
			arrayOfByte2[2] = 33;
			arrayOfByte2[3] = 34;
			arrayOfByte2[4] = 35;
			arrayOfByte2[5] = 36;
			ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
			ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
			Cryptography.decrypt128(localByteArrayInputStream, localByteArrayOutputStream, arrayOfByte2);
			arrayOfByte1 = localByteArrayOutputStream.toByteArray();
			localByteArrayOutputStream.close();
			localByteArrayInputStream.close();
		} catch (Exception localException) {
			localException.printStackTrace();
		}
		return arrayOfByte1;
	}

	public static final String decode(byte[] paramArrayOfByte, String paramString) {
		byte[] arrayOfByte1 = null;
		String str = null;
		try {
			logger.debug(
					"decode Method starts....paramArrayOfByte: " + paramArrayOfByte + "paramString : " + paramString);

			byte[] arrayOfByte2 = new byte[6];
			arrayOfByte2[0] = 31;
			arrayOfByte2[1] = 32;
			arrayOfByte2[2] = 33;
			arrayOfByte2[3] = 34;
			arrayOfByte2[4] = 35;
			arrayOfByte2[5] = 36;
			paramString = (paramString != null) ? paramString : "UTF-8";
			ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
			ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
			Cryptography.decrypt128(localByteArrayInputStream, localByteArrayOutputStream, arrayOfByte2);
			arrayOfByte1 = localByteArrayOutputStream.toByteArray();
			localByteArrayOutputStream.close();
			localByteArrayInputStream.close();
			str = new String(arrayOfByte1, paramString);
		} catch (UnsupportedEncodingException localUnsupportedEncodingException) {
			localUnsupportedEncodingException.printStackTrace();
		} catch (Exception localException) {
			localException.printStackTrace();
		}

		return str;
	}

	public static void main(String[] paramArrayOfString) {
		try {
			String str = null;
			BufferedReader localBufferedReader = new BufferedReader(new FileReader("D:\\J2EE\\Release\\passin.txt"));
			PrintWriter localPrintWriter = new PrintWriter(
					new BufferedWriter(new FileWriter("D:\\J2EE\\Release\\passout.txt", true)));

			while ((str = localBufferedReader.readLine()) != null) {
				localPrintWriter.println("P-" + str);

				byte[] arrayOfByte1 = encode(str.trim().getBytes("ISO8859_1"));
				localPrintWriter.println("STE-" + new String(arrayOfByte1, "ISO8859_1"));

				byte[] arrayOfByte2 = decode(arrayOfByte1);
				localPrintWriter.println("STD-" + new String(arrayOfByte2, "ISO8859_1"));
			}

			localBufferedReader.close();
			localBufferedReader = null;

			localPrintWriter.close();
			localPrintWriter = null;
		} catch (FileNotFoundException localFileNotFoundException) {
			localFileNotFoundException.printStackTrace();
		} catch (IOException localIOException) {
			loggerErr.error("IOException in  Password Encryt : " + localIOException.getMessage());
			localIOException.printStackTrace();
		}
	}
}