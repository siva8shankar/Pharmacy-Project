/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsUtil.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class ClsUtil {

	public static String autoGeneration(String pPrefix, int pToBeGenerated, int pLength) {

		String IdNo;
		String tempId;
		if (pToBeGenerated == 0) {
			pToBeGenerated = 1;
		}
		IdNo = pPrefix;
		tempId = pToBeGenerated + "";
		if (pLength - (pPrefix.length() + tempId.length()) > 0) {
			for (int i = 0; i < (pLength - (pPrefix.length() + tempId.length())); i++) {
				IdNo = IdNo + "0";
			}
			IdNo = IdNo + pToBeGenerated;
		} else {
			IdNo = pPrefix + pToBeGenerated;
		}

		return IdNo;

	}

	// Used to Validate Session
	public boolean ValidateSession(long pCreationTime, long pLastAccessTime) {

		boolean flag = false;
		Date dayAgo = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
		Date hourAgo = new Date(System.currentTimeMillis() - 60 * 60 * 1000);
		Date created = new Date(pCreationTime);
		Date accessed = new Date(pLastAccessTime);
		if (created.before(dayAgo) || accessed.before(hourAgo)) {
			flag = false;
		} else {
			flag = true;
		}

		return flag;
	}

	public static synchronized String CalculateInvoiceAmount(String pBaseInvoiceamount, String pServiceTax,
			String pEducationCess, String pHEducationCess, String pVAT, String pAdditionalVAT, String pAnyTax,
			String pFreight, String pDiscount, String pPenaltyDeduction) {
		double Total_Invoice_Amount = 0.0;
		double BaseInvoiceamount = 0.0;
		double ServiceTax = 0.0;
		double EducationCess = 0.0;
		double HEducationCess = 0.0;
		double VAT = 0.0;
		double AdditionalVAT = 0.0;
		double AnyTax = 0.0;
		double Freight = 0.0;
		double Discount = 0.0;
		double PenaltyDeduction = 0.0;

		if (null != pBaseInvoiceamount && !pBaseInvoiceamount.equalsIgnoreCase("")) {
			BaseInvoiceamount = Double.parseDouble(pBaseInvoiceamount);
		}
		if (null != pServiceTax && !pServiceTax.equalsIgnoreCase("")) {
			ServiceTax = Double.parseDouble(pServiceTax);
		}
		if (null != pEducationCess && !pEducationCess.equalsIgnoreCase("")) {
			EducationCess = Double.parseDouble(pEducationCess);
		}
		if (null != pHEducationCess && !pHEducationCess.equalsIgnoreCase("")) {
			HEducationCess = Double.parseDouble(pHEducationCess);
		}
		if (null != pVAT && !pVAT.equalsIgnoreCase("")) {
			VAT = Double.parseDouble(pVAT);
		}
		if (null != pAdditionalVAT && !pAdditionalVAT.equalsIgnoreCase("")) {
			AdditionalVAT = Double.parseDouble(pAdditionalVAT);
		}
		if (null != pAnyTax && !pAnyTax.equalsIgnoreCase("")) {
			AnyTax = Double.parseDouble(pAnyTax);
		}
		if (null != pFreight && !pFreight.equalsIgnoreCase("")) {
			Freight = Double.parseDouble(pFreight);
		}
		if (null != pDiscount && !pDiscount.equalsIgnoreCase("")) {
			Discount = Double.parseDouble(pDiscount);
		}
		if (null != pPenaltyDeduction && !pPenaltyDeduction.equalsIgnoreCase("")) {
			PenaltyDeduction = Double.parseDouble(pPenaltyDeduction);
		}

		Total_Invoice_Amount = (BaseInvoiceamount + ServiceTax + EducationCess + HEducationCess + VAT + AdditionalVAT
				+ AnyTax + Freight) - (Discount + PenaltyDeduction);

		return Total_Invoice_Amount + "";
	}

	// Get the Encrypted Key
	public static String GetEncryptKey() {
		/*
		 * Calendar cal = Calendar.getInstance(); java.util.Date dt =
		 * cal.getTime(); long largeNumber = dt.getTime(); Random rnd = new
		 * Random(largeNumber); long randomNumber = rnd.nextLong(); return
		 * Long.toString(randomNumber);
		 */
		String randomNumber = "-2982974477059013788";
		return randomNumber;
	}

	// This method is used to decrypt the Encrypted Key
	public String decrypt(String strEncrypt, String strKey) {
		String strDecrypt = "";
		for (int i = 0; i < strEncrypt.length(); i++) {
			int ch = strEncrypt.charAt(i);
			int x = 0;
			for (int k = strKey.length() - 1; k >= 0; k--) {
				int z = strKey.charAt(k);
				x = ch ^ z;
				ch = x;
			}

			strDecrypt = (new StringBuilder()).append(strDecrypt).append((char) x).toString();
		}

		return strDecrypt;
	}

	// This method is used to decode in utf8

	public String decode_utf8(String s) throws UnsupportedEncodingException {
		String s1 = "UTF8";
		boolean flag = false;
		StringBuffer stringbuffer = new StringBuffer();
		int i = s.length();
		int j = 0;
		if (s1.length() == 0)
			throw new UnsupportedEncodingException("URLDecoder: empty string enc parameter");
		do {
			if (j >= i)
				break;
			char c = s.charAt(j);
			switch (c) {
			case 43: // '+'
				stringbuffer.append(' ');
				j++;
				flag = true;
				break;

			case 37: // '%'
				try {
					byte abyte0[] = new byte[(i - j) / 3];
					int k = 0;
					do {
						if (j + 2 >= i || c != '%')
							break;
						abyte0[k++] = (byte) Integer.parseInt(s.substring(j + 1, j + 3), 16);
						if ((j += 3) < i)
							c = s.charAt(j);
					} while (true);
					if (j < i && c == '%')
						throw new IllegalArgumentException("URLDecoder: Incomplete trailing escape (%) pattern");
					stringbuffer.append(new String(abyte0, 0, k, s1));
				} catch (NumberFormatException numberformatexception) {
					throw new IllegalArgumentException(
							(new StringBuilder()).append("URLDecoder: Illegal hex characters in escape (%) pattern - ")
									.append(numberformatexception.getMessage()).toString());
				}
				flag = true;
				break;

			default:
				stringbuffer.append(c);
				j++;
				break;
			}
		} while (true);
		return flag ? stringbuffer.toString() : s;
	}

	public Map sortByValue(Map map) {
		List list = new LinkedList(map.entrySet());
		Collections.sort(list, new Comparator() {
			@Override
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getKey()).compareTo(((Map.Entry) (o2)).getKey());
			}
		});

		Map result = new LinkedHashMap();
		for (Iterator itr = list.iterator(); itr.hasNext();) {
			Map.Entry entry = (Map.Entry) itr.next();
			result.put(entry.getKey(), entry.getValue());
		}
		return result;
	}

	// It is used to check whether object is null or empty
	/**
	 * Method to check the NULL Object
	 */
	public static boolean isNullOrEmpty(Object object) {
		if (object != null && !object.toString().trim().equalsIgnoreCase("")
				&& !object.toString().trim().equalsIgnoreCase("null")) {
			return false;
		}
		return true;
	}

	/**
	 * Method to handle the DateFormat while Uploading to OF
	 */
	public static String handleDateFormat(String object) {
		String newString = "";
		if (object != null && !object.trim().equalsIgnoreCase("")
				&& !object.toString().trim().equalsIgnoreCase("null")) {
			String[] strArr = object.split(" ");
			newString = strArr[0] + "T" + strArr[1];// Appending with T in
													// between date and hours as
													// it is throws exception as
													// "Incorrect date format"
													// in Upload WSDL
		}
		return newString;
	}

	/**
	 * Method to convert the date format
	 * 
	 * @param sDate
	 * @param inputDateFormat
	 * @param outputDateFormat
	 * @return
	 */
	public static String convertDateFormat(String sDate, String inputDateFormat, String outputDateFormat) {
		String sOutput = "";
		try {
			if (!isNullOrEmpty(sDate)) {
				SimpleDateFormat inputFormat = new SimpleDateFormat(inputDateFormat); // "yyyy-MM-dd
																						// HH:mm:ss"
				java.util.Date dt = inputFormat.parse(sDate);

				SimpleDateFormat outputFormat = new SimpleDateFormat(outputDateFormat, Locale.ENGLISH);// "dd/MM/yyyy"
				sOutput = outputFormat.format(dt);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return sOutput;
	}

	/**
	 * Method to replace comma values by blank in the amount fields
	 * 
	 * @param sInputAmt
	 * @return
	 */
	public static String replaceByBLANK(String sInputAmt) {
		String sOutputAmt = "0";
		if (!ClsUtil.isNullOrEmpty(sInputAmt)) {
			sOutputAmt = sInputAmt;
			if (sInputAmt.indexOf(",") > -1) {
				sOutputAmt = sInputAmt.replaceAll(",", "");
			}
		}
		return sOutputAmt;
	}

	/**
	 * Method to replace NULL values by blank in the String fields
	 * 
	 * @param sInputAmt
	 * @return
	 */
	public static String blankString(Object object) {
		String sOutputAmt = "";
		if (object != null && !object.toString().trim().equalsIgnoreCase("")
				&& !object.toString().trim().equalsIgnoreCase("null")) {
			sOutputAmt = object.toString();
		}
		return sOutputAmt;
	}

	/**
	 * Method to get the Encrypted contents
	 * 
	 * @return
	 */
	public static String getEncryptedDate() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String encryptedDT = "";
		try {
			java.util.Date d1 = new java.util.Date();
			String currentDateTime = dateFormat.format(d1);
			// String currentDateTime="2016/10/22 17:50:00";
			// System.out.println("currentDateTime--->"+currentDateTime);

			byte[] byteDT = currentDateTime.getBytes();
			BASE64Encoder base64Encode = new BASE64Encoder();
			encryptedDT = base64Encode.encode(byteDT);
			// System.out.println("encryptedDT--->"+encryptedDT);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return encryptedDT;
	}

	/**
	 * Method to decrypted the given encrypted contents
	 * 
	 * @param encryptedDT
	 * @return
	 */
	public static String getDecryptedDate(String encryptedDT) {
		String decryptedDT = "";
		try {
			BASE64Decoder base64Decode = new BASE64Decoder();
			byte[] byteDecyptedDT = base64Decode.decodeBuffer(encryptedDT);
			decryptedDT = bytes2String(byteDecyptedDT);
			// System.out.println("decryptedDT-->"+decryptedDT);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return decryptedDT;

	}

	/**
	 * Method to increment the current date by 2 hours
	 * 
	 * @return
	 */
	public static String getCurrentDateTime() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String currentDateTime = "";
		try {
			// Calendar cal = Calendar.getInstance();
			// cal.add(Calendar.HOUR_OF_DAY, 24); //Hardcoded here...
			// incrementDT = dateFormat.format(cal.getTime());
			// System.out.println("incrementDT-->"+incrementDT);

			java.util.Date d1 = new java.util.Date();
			currentDateTime = dateFormat.format(d1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return currentDateTime;
	}

	/**
	 * Method to convert the encrypted base64 contents into byte
	 * 
	 * @param bytes
	 * @return
	 */
	private static String bytes2String(byte[] bytes) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
			stringBuffer.append((char) bytes[i]);
		}
		return stringBuffer.toString();
	}

	/**
	 * Method to get the date difference in Hours
	 * 
	 * @param decryptedDT
	 * @param incrementDT
	 * @return boolean
	 */
	public static boolean getDifferenceInHours(String decryptedDT, String currentDT) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		boolean isLinkActive = false;
		System.out.println("getDifferenceInHours .......");
		try {
			System.out.println("getDifferenceInHours decryptedDT-->" + decryptedDT);
			System.out.println("getDifferenceInHours currentDT-->" + currentDT);

			java.util.Date dRequest = null;
			java.util.Date dSystem = null;
			dRequest = dateFormat.parse(decryptedDT);
			dSystem = dateFormat.parse(currentDT);

			long diff = dSystem.getTime() - dRequest.getTime();
			// System.out.println("diff---->"+diff);

			long diffHours = diff / (60 * 60 * 1000);
			System.out.println("getDifferenceInHours diffHours-->" + diffHours);
			// if(diffHours <= 24)//Hardcoded here...
			if (diffHours <= 72)
			{
				System.out.println("getDifferenceInHours Valid Link");
				isLinkActive = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isLinkActive;
	}

	/**
	 * Method to format the amount in thousand separator
	 * 
	 * @param sInput
	 * @return
	 */
	public static String thousandFormatter(String sInput) {
		String output = "0.00";
		try {
			DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance();
			symbols.setGroupingSeparator(',');
			DecimalFormat myFormatter = new DecimalFormat("###,###.00", symbols);
			output = myFormatter.format(new Double(sInput));
			// System.out.println("Inside thousandFormatter"+output);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	public static String replaceString(String sInput) {
		String sOutput = "";
		if (!isNullOrEmpty(sInput)) {
			sOutput = sInput.replaceAll("&", "&amp;");
		}
		return sOutput;
	}

}