/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsExportPdf.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)          
* * 09/01/2018						ksivashankar			Bug 1023787 - Vendor Portal - value is not populated in the pdf and allignment issue                                                          
************************************************************************************************/

package com.newgen.util;

import java.io.File;
import java.io.FileOutputStream;

import jsp.header;

import org.apache.log4j.Logger;

import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.FontSelector;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.newgen.bean.VPReportMaster;

public class ClsExportPdf {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	public static void exportPdf(StringBuffer exportData, String headers, VPReportMaster reportBean, String sessionId,
			String tempPath) {
		// TODO Auto-generated method stub
		try {
			logger.debug("Inside export PDF");
			PdfPCell cell = null;
			String colData = null;

			Document document = new Document(PageSize.A3.rotate(), 40, 40, 40, 40);
			// PdfWriter.getInstance(document,new FileOutputStream(tempPath +
			// "\\PDFReport"+sessionId+".pdf"));
			PdfWriter.getInstance(document,
					new FileOutputStream(tempPath + File.separator + "PDFReport" + sessionId + ".pdf"));
			document.open();

			/*
			 * HeaderFooter header = new HeaderFooter( new
			 * Phrase("Vendor Portal Self Service"),false);
			 * header.setAlignment(Element.ALIGN_CENTER);
			 * 
			 * document.setHeader(header);
			 */
			document.getPageSize();
			String[] head = headers.split(",");
			PdfPTable t = new PdfPTable(head.length);
			t.setWidthPercentage(100);

			for (int i = 0; i < head.length; i++) {
				cell = new PdfPCell(new Phrase(head[i] + "                       "));
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell.setVerticalAlignment(Element.ALIGN_TOP);
				cell.setPaddingTop(10);
				cell.setPaddingBottom(10);
				t.addCell(cell);
			}

			String[] rows = new String(exportData).split(reportBean.getRowDelimiter());

			for (int j = 0; j < rows.length; j++) {

				colData = rows[j];

				String[] columnData = colData.split(reportBean.getFieldDelimiter());

				for (int i = 0; i < columnData.length; i++) {

					if (ClsUtil.isNullOrEmpty(columnData[i])) {
						columnData[i] = "";
					}
					cell = new PdfPCell(new Phrase(columnData[i] + "                           "));

					cell.setHorizontalAlignment(Element.ALIGN_LEFT);
					cell.setVerticalAlignment(Element.ALIGN_LEFT);
					cell.setPaddingLeft(10);
					cell.setPaddingTop(10);
					cell.setPaddingBottom(10);
					t.addCell(cell);

				}

			}

			/*
			 * HeaderFooter footer = new HeaderFooter(new
			 * Phrase(reportBean.getFooter()), false);
			 * document.setFooter(footer);
			 */

			document.add(t);

			logger.debug("Text is inserted into pdf file");
			document.close();
		} catch (Exception e) {
			loggerErr.error("Exception in ClsExportPdf  : " + e.getMessage());
			e.printStackTrace();
		}

	}

}
