/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorPortalXMLGeneration.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class VendorPortalXMLGeneration {

	public HashMap<String, String> loadXMLData(String pPortalXMLPath) {

		HashMap<String, String> hshMap = null;
		try {
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc;

			hshMap = new HashMap<String, String>();
			doc = docBuilder.parse(new File(pPortalXMLPath));
			// root element
			Element root = doc.getDocumentElement();
			NodeList nodelist = root.getChildNodes();
			for (int i = 1; i < nodelist.getLength(); i++) {

				Node node = nodelist.item(i);
				if (null != node && node.hasChildNodes()) {

					NodeList nodelistChild = node.getChildNodes();
					for (int j = 0; j < nodelistChild.getLength(); j++) {

						if (j == 0)
							continue;

						Node ChildNode = nodelistChild.item(j);

						hshMap.put(ChildNode.getNodeName(), ChildNode.getTextContent());
					}
				}

			}
		} catch (Exception e) {
			e.getMessage();
		}
		return hshMap;

	}

	/*
	 * public void generateXMLJSP(String pPortalXMLPath, String
	 * pGeneratedJspPath){
	 * 
	 * try{ StringBuffer sb = new StringBuffer();
	 * 
	 * sb.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>"); sb.append(
	 * "<%@ page language=\"java\" contentType=\"text/html; charset=ISO-8859-1\""
	 * ); sb.append("pageEncoding=\"ISO-8859-1\"%>");
	 * sb.append("<%@page import=\"com.newgen.connection.*\"%>"); sb.append(
	 * "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
	 * ); sb.append("<%@page import=\"com.newgen.bean.VendorQueryMaster\"%>");
	 * sb.append("<%@page import=\"java.util.ArrayList\"%>");
	 * sb.append("<%@page import=\"java.sql.Connection\"%>");
	 * sb.append("<%@page import=\"com.newgen.util.ClsMessageHandler\"%>");
	 * sb.append("<%@page import=\"java.util.HashMap\"%>");
	 * sb.append("<%@page import=\"java.util.SortedMap\"%>");
	 * sb.append("<%@page import=\"javax.xml.parsers.DocumentBuilderFactory\"%>"
	 * ); sb.append("<%@page import=\"javax.xml.parsers.DocumentBuilder\"%>");
	 * sb.append("<%@page import=\"java.io.File\"%>");
	 * sb.append("<%@page import=\"org.w3c.dom.Document\"%>");
	 * sb.append("<%@page import=\"org.w3c.dom.Element\"%>");
	 * sb.append("<%@page import=\"org.w3c.dom.NodeList\"%>");
	 * sb.append("<%@page import=\"org.w3c.dom.Node\"%><html");
	 * sb.append("xmlns=\"http://www.w3.org/1999/xhtml\"><html>");
	 * 
	 * 
	 * sb.append("<head>");
	 * sb.append("<%@ include file=\"AdminTopMenu.jsp\"%>"); sb.append(
	 * "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\" />"
	 * ); sb.append("<title>Vendor Portal</title>"); sb.append(
	 * "<script language=\"JavaScript\" src=\"${pageContext.request.contextPath}/JavaScript/calendar_us.js\"></script>"
	 * ); sb.append(
	 * "<link rel=\"stylesheet\" href=\"${pageContext.request.contextPath}/StyleSheet/calendar.css\" />"
	 * ); sb.append(
	 * "<script type=\"text/javascript\" src=\"${pageContext.request.contextPath}/JavaScript/general.js\"></script>"
	 * ); sb.append("<script type=\"text/javascript\">");
	 * 
	 * sb.append("</script>");
	 * 
	 * sb.append("</head>"); sb.append("<%"); sb
	 * .append("String MsgCode = (String)request.getAttribute(\"MSGCODE\");");
	 * sb.append("String msg =\"\";"); //sb.append(
	 * "msg = (MsgCode != null)?ClsMessageHandler.getErrorMsg(MsgCode):\"\";");
	 * 
	 * sb.append(
	 * "HashMap<String, String> mapXmlData = (HashMap<String, String>)request.getAttribute(\"MAPXMLDATA\"); %>"
	 * ); //sb.append(
	 * "<% if(mapXmlData == null) {mapXmlData = (HashMap<String, String>)getServeltContext().getAttribute(\"VendorPortalXMLData\");} %>"
	 * );
	 * 
	 * sb.append(
	 * "<body onkeydown=\"javascript:return keycheck(this.id,event)\" id=\"bodyDynamicXML\">"
	 * ); sb.append("<div class=\"mainForm\">"); sb.append(
	 * "<form name=\"XMLConfigurationForm\" id=\"XMLConfiguration\" method=\"post\" action=\"${pageContext.request.contextPath}/SaveConfigurationXMLServlet\">"
	 * ); sb.append(
	 * "<br /><div style=\"width: 100%;\" align=\"left\"><a class=\"H2\">Manage Configuration</a></div>"
	 * ); sb.append(
	 * "<div style=\"width: 100%;\" align=\"left\"><h4 class=\"errorMsg\"><label id=\"err\"><%=msg%></label></h4></div>"
	 * ); sb.append("<table class=\"fontTable\">");
	 * 
	 * //sb.append(
	 * "<% HashMap<String, String> mapXmlData = getServletContext.getAttribute(\"VendorPortalXMLData\"); %>"
	 * );
	 * 
	 * 
	 * sb.append("<% HashMap<String, String> mapXmlData = null;");
	 * sb.append("try {"); sb.append(
	 * "DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();"
	 * ); sb.append(
	 * "DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();");
	 * sb.append("Document doc;");
	 * 
	 * sb.append("mapXmlData = new HashMap<String, String>();");
	 * 
	 * String[] arrayPath = pPortalXMLPath.split("\\"); String xmlPath =
	 * arrayPath[0];
	 * 
	 * for(int i=1; i<arrayPath.length; i++){ xmlPath = xmlPath + "/" +
	 * arrayPath[i]; } //String xmlPath = pPortalXMLPath.replace("\\", "\\\\");
	 * sb.append("doc = docBuilder.parse(new File(\"" + pPortalXMLPath +
	 * "\"));"); // root element
	 * sb.append("Element root = doc.getDocumentElement();");
	 * 
	 * sb.append("NodeList nodelist = root.getChildNodes();");
	 * sb.append("for (int i = 1; i < nodelist.getLength(); i++) {");
	 * 
	 * sb.append("Node node = nodelist.item(i);");
	 * sb.append("if (null != node && node.hasChildNodes()){");
	 * 
	 * sb.append("NodeList nodelistChild = node.getChildNodes();");
	 * 
	 * sb.append("for (int j = 0; j < nodelistChild.getLength(); j++) {");
	 * 
	 * sb.append("if(j == 0)"); sb.append("continue;");
	 * 
	 * sb.append("Node ChildNode = nodelistChild.item(j);");
	 * 
	 * sb.append(
	 * "mapXmlData.put(ChildNode.getNodeName(), ChildNode.getTextContent());");
	 * sb.append("}}}");
	 * 
	 * sb.append("}catch(Exception e){"); sb.append("e.getMessage();");
	 * sb.append("} %>");
	 * 
	 * 
	 * HashMap<String, String> hshMap = null; try { DocumentBuilderFactory
	 * docBuilderFactory = DocumentBuilderFactory .newInstance();
	 * DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
	 * Document doc;
	 * 
	 * hshMap = new HashMap<String, String>(); doc = docBuilder.parse(new
	 * File(pPortalXMLPath)); // root element Element root =
	 * doc.getDocumentElement();
	 * 
	 * NodeList nodelist = root.getChildNodes(); for (int i = 1; i <
	 * nodelist.getLength(); i++) {
	 * 
	 * Node node = nodelist.item(i); if (null != node && node.hasChildNodes()){
	 * 
	 * NodeList nodelistChild = node.getChildNodes();
	 * 
	 * sb.append("<tr style=\"height: 15px;\">"); sb.append("</tr>");
	 * sb.append("<tr>"); sb.append(
	 * "<td colspan = \"8\" align=\"left\" style=\"font-weight: bold; font-size: 16px; color: green;\">"
	 * + node.getNodeName() + "</td>"); sb.append("</tr>");
	 * sb.append("<tr style=\"height: 5px;\">"); sb.append("</tr>");
	 * 
	 * for (int j = 0; j < nodelistChild.getLength(); j++) {
	 * 
	 * Node ChildNode = nodelistChild.item(j*2+1);
	 * 
	 * if(ChildNode != null){
	 * 
	 * if(j%2 == 0){
	 * 
	 * sb.append("<tr style=\"height: 15px\">");
	 * sb.append("<td width=\"\"></td>"); sb.append("<td>" +
	 * ChildNode.getNodeName()+ "</td>"); sb.append("<td width=\"2px;\"></td>");
	 * sb.append("<td><input type=\"text\" id=\"" + ChildNode.getNodeName() +
	 * "\" name=\"" + ChildNode.getNodeName() +
	 * "\" style=\"width: 150px;\" value=\"<%=mapXmlData.get(\"" +
	 * ChildNode.getNodeName() + "\") %>\"></input></td>");
	 * sb.append("<td width=\"100px;\"></td>");
	 * 
	 * }else{ sb.append("<td>" + ChildNode.getNodeName()+ "</td>");
	 * sb.append("<td width=\"2px;\"></td>");
	 * sb.append("<td><input type=\"text\" id=\"" + ChildNode.getNodeName() +
	 * "\" name=\"" + ChildNode.getNodeName() +
	 * "\" style=\"width: 150px;\" value=\"<%=mapXmlData.get(\"" +
	 * ChildNode.getNodeName() + "\") %>\"></input></td>"); sb.append("</tr>");
	 * }
	 * 
	 * hshMap.put(ChildNode.getNodeName(), ChildNode.getTextContent()); }else{
	 * break; } } }
	 * 
	 * } }catch(Exception e){ e.getMessage(); }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * sb.append("<tr style=\"height: 15px\">");
	 * sb.append("<td width=\"\"></td>");
	 * sb.append("<td><NOBR>Document Size</NOBR></td>");
	 * sb.append("<td width=\"2px;\"></td>"); sb.append(
	 * "<td><input type=\"text\" id=\"DocumentSize\" name=\"DocumentSize\" style=\"width: 120px;\" value=\"<%=hshMap.get(\"DocumentSize\") %>\"></input></td>"
	 * ); sb.append("<td width=\"150px;\"></td>"); sb.append("<td></td>");
	 * sb.append("<td></td>"); sb.append("<td></td>"); sb.append("</tr>");
	 * 
	 * sb.append("<tr>"); sb.append(
	 * "<td colspan = \"8\" align=\"center\" style=\"font-weight: bold; font-size: 16px; color: green;\">InvoiceDetails</td>"
	 * ); sb.append("</tr>");
	 * 
	 * sb.append("<tr style=\"height: 15px\">");
	 * sb.append("<td width=\"\"></td>");
	 * sb.append("<td><NOBR>Invoice Number Prefix</NOBR></td>");
	 * sb.append("<td width=\"2px;\"></td>"); sb.append(
	 * "<td><input type=\"text\" id=\"InvoiceNumberPrefix\" name=\"InvoiceNumberPrefix\" style=\"width: 120px;\" value=\"<%=hshMap.get(\"InvoiceNumberPrefix\") %>\"></input></td>"
	 * ); sb.append("<td width=\"150px;\"></td>");
	 * sb.append("<td><NOBR>Invoice Number Length</NOBR></td>");
	 * sb.append("<td width=\"2px;\"></td>"); sb.append(
	 * "<td><input type=\"text\" id=\"InvoiceNumberLength\" name=\"InvoiceNumberLength\" style=\"width: 120px;\" value=\"<%=hshMap.get(\"InvoiceNumberLength\") %>\"></input></td>"
	 * ); sb.append("</tr>");
	 * 
	 * sb.append("<tr style=\"height: 15px\">");
	 * sb.append("<td width=\"\"></td>");
	 * sb.append("<td><NOBR>Invoice Status Types</NOBR></td>");
	 * sb.append("<td width=\"2px;\"></td>"); sb.append(
	 * "<td><input type=\"text\" id=\"InvoiceStatusTypes\" name=\"InvoiceStatusTypes\" style=\"width: 120px;\" value=\"<%=hshMap.get(\"InvoiceStatusTypes\") %>\"></input></td>"
	 * ); sb.append("<td width=\"150px;\"></td>");
	 * sb.append("<td><NOBR>Submit Invoice Status</NOBR></td>");
	 * sb.append("<td width=\"2px;\"></td>"); sb.append(
	 * "<td><input type=\"text\" id=\"SubmitInvoiceStatus\" name=\"SubmitInvoiceStatus\" style=\"width: 120px;\" value=\"<%=hshMap.get(\"SubmitInvoiceStatus\") %>\"></input></td>"
	 * ); sb.append("</tr>");
	 * 
	 * sb.append("<tr style=\"height: 15px\">");
	 * sb.append("<td width=\"\"></td>"); <td><NOBR>Billing Currency</NOBR></td>
	 * <td width=\"2px;\"></td> <td><input type=\
	 * "text\" id=\"BillingCurrency\" name=\"BillingCurrency\" style=\"width: 120px;\" value=\"<%=hshMap.get(\"BillingCurrency\") %>\"
	 * ></input></td> <td width=\"150px;\"></td> <td><NOBR>PO Type</NOBR></td>
	 * <td width=\"2px;\"></td> <td><input type=\
	 * "text\" id=\"POType\" name=\"POType\" style=\"width: 120px;\" value=\"<%=hshMap.get(\"POType\") %>\"
	 * ></input></td> </tr> sb.append("<tr style=\"height: 30px;\">");
	 * sb.append("</tr>"); sb.append("<tr align=\"center\">"); sb.append(
	 * "<td colspan=\"8\"><button type=\"submit\" id=\"saveButton\" name=\"saveButton\">Save</button></td>"
	 * ); sb.append("</tr>");
	 * 
	 * sb.append("</table>"); sb.append("</form>"); sb.append("</div>");
	 * sb.append("</body>"); sb.append("</html>");
	 * 
	 * try { String file_name = pGeneratedJspPath; FileWriter file = new
	 * FileWriter(file_name); BufferedWriter out = new BufferedWriter(file);
	 * out.write(sb.toString()); out.close(); } catch (IOException e) {
	 * System.out.println(e.getMessage()); } }catch(Exception ex){
	 * ex.getMessage(); }
	 * 
	 * }
	 */
}
