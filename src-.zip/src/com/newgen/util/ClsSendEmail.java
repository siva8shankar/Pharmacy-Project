/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsSendEmail.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Class is used for Sending Email
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserMaster;

public class ClsSendEmail {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	public static void sendEmail(VPUserMaster userMaster, String option) {

		java.net.InetAddress ipAddress = null;
		String host = ClsMessageHandler.MainEmailServer;
		String hostactual = ClsMessageHandler.strMainEmailServer;
		String protocol = ClsMessageHandler.VPProtocol;
		final String user = ClsMessageHandler.MainEmailUserId;// change
																// accordingly
		final String password = ClsMessageHandler.MainEmailPassword;// change
																	// accordingly
		String to = userMaster.getUserEmailId();// change accordingly
		String from = ClsMessageHandler.MainEmailUserId;// change accordingly
		String jbossport = ClsMessageHandler.JBossPort;

		// logger.debug(" Host name"+host);

		// Get the session object
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.starttls.enable", "true");
		System.out.println("ClsMessageHandler.Port" + ClsMessageHandler.Port);
		props.setProperty("mail.smtp.port", ClsMessageHandler.Port);
		props.put("mail.smtp.auth", ClsMessageHandler.EmailAuthentication);

		// getDefaultInstance
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(user, password);
			}
		});

		// Compose the message
		try {

			ipAddress = java.net.InetAddress.getLocalHost();

			String str = "Dear ";
			str += userMaster.getUserName() + ", <br/><br/>";

			logger.debug("option in ClsSendEmail--->" + option);
			logger.debug("ipAddress.getHostName()----->" + ipAddress.getHostName());// Activate
																					// Working
																					// fine
			logger.debug("ipAddress.getHostAddress()----->" + ipAddress.getHostAddress());// Activate
																							// Working
																							// fine
			logger.debug("hostactual--->" + hostactual);// Activate will not
														// work
			// logger.debug("userMaster.getUserName()-->"+userMaster.getUserName());
			// logger.debug("userMaster.getEmailID()-->"+to);
			String encryptedDT = ClsUtil.getEncryptedDate();

			logger.debug("encryptedDT--->" + encryptedDT);
			if (option.equalsIgnoreCase("Activate")) {
				/*
				 * str +=
				 * "Please click on below link to activate your account with Vendor Portal system. <br/>"
				 * ;
				 */
				// str +=
				// "http://"+ipAddress.getHostAddress()+":"+jbossport+"/portal/NewUserConfirmation?uesgsezwqop="
				// + userMaster.getUserName()+ "$" +
				// userMaster.getActivationCode() + " \n\n\r";
				// changed according to WAS &
				// str +=
				// protocol+"://"+ipAddress.getHostAddress()+":"+jbossport+"/vendorportal/NewUserConfirmation?uesgsezwqop="
				// + userMaster.getUserName()+ "$" +
				// userMaster.getActivationCode() + " \n\n\r";
				// Below lines commented - UAT 08-Nov-16
				// str += "Please <a
				// href='"+protocol+"://"+ipAddress.getHostAddress()
				// +":"+jbossport+"/portal/NewUserConfirmation?uesgsezwqop="+userMaster.getUserName()+"$"+encryptedDT+"$"+userMaster.getActivationCode()+"'>Click
				// Here</a> link to activate your account with Vendor Portal
				// system. <br/>";
				// str += "Please <a
				// href='http://192.168.12.58:8080/portal/NewUserConfirmation?uesgsezwqop="+userMaster.getUserName()+"$"+encryptedDT+"$"+userMaster.getActivationCode()+"'>Click
				// Here</a> link to activate your account with Vendor Portal
				// system. <br/>";
				// str += "Please <a
				// href='"+protocol+"://"+ipAddress.getHostName()
				// +":"+jbossport+"/portal/NewUserConfirmation?uesgsezwqop="+userMaster.getUserName()+"$"+encryptedDT+"$"+userMaster.getActivationCode()+"'>Click
				// Here</a> link to activate your account with Vendor Portal
				// system. <br/>";
				str += "Please <a href='" + protocol + "://" + hostactual + ":" + jbossport
						+ "/portal/NewUserConfirmation?uesgsezwqop=" + userMaster.getUserName() + "$" + encryptedDT
						+ "$" + userMaster.getActivationCode()
						+ "'>Click Here</a> link to activate your account with Vendor Portal system. <br/>";
				// str +=
				// protocol+"://"+ipAddress.getHostName()+":"+jbossport+"/vendorportal/NewUserConfirmation?uesgsezwqop="
				// + userMaster.getUserName()+ "$" +
				// userMaster.getActivationCode() + " \n\n\r";
				// This is LIVE Domain URL
				// str +=
				// protocol+"://payablesmbrdi.daimler.com/vendorportal/NewUserConfirmation?uesgsezwqop="+userMaster.getUserName()+"$"+encryptedDT+"$"+userMaster.getActivationCode()+"
				// <br/>";
				// str += "Note: Your activation link will be expired within 24
				// hours. <br/>";
				// str += "<br/><br/>If you find any issues while loading,
				// Kindly replace IPAddress with the given Public IPAddress ::
				// "+hostactual;
				str += "<br /> <br /> Note: Your activation link will be expired within 72 hours. <br/>";

				str += "Your temporary password is: " + userMaster.getPassword() + " <br/><br/>";
				logger.debug("str val inside activate case :: " + str);

			} else if (option.equalsIgnoreCase("Enable")) {
				str += "Your Account has been enabled by Administrator. Please login into the Vendor Portal System using the below link <br/>";
				str += "<a href='" + protocol + "://" + hostactual + ":" + jbossport + "/portal/login" + "'>" + protocol
						+ "://" + hostactual + ":" + jbossport + "/portal/login" + "</a>";
				str += "<br/><br/>";
			} else if (option.equalsIgnoreCase("Disable")) {
				str += "Your Account has been disabled by Administrator. <br/><br/>";
			} else if (option.equalsIgnoreCase("AdminChangedPassword")) {
				str += "Your Password has been changed by Administrator. New Password is " + userMaster.getPassword()
						+ " <br/><br/>";
			} else if (option.equalsIgnoreCase("Reject")) {
				str += "Your Account has been rejected by Administrator. <br/><br/>";
			}
			// modified by Saravanan M on 27/07/17 for Deloitte Project.
			/*
			 * str += "Regards," + "<br/>"; str += "Administrator" + "<br/>";
			 * str += "Vendor Portal System" + "<br/>"; str += "Deloitte Place"+
			 * "<br/>"; str += "20 Woodlands Drive,Woodmead Sandton"+ "<br/>";
			 * str += "Johannesburg, South Africa, 2052"+ "<br/><br/>"; str +=
			 * "Note: This is an auto generated e-mail.Responses to this e-mail ID are not being monitored."
			 * ; str +=
			 * "In case of any queries please write to vendorportaladmin@deloitteiaas.co.za"
			 * ;
			 */

			str += "Regards," + "<br/>";
			str += "Deloitte System Admin" + "<br/>";
			str += "Note: This is an auto generated e-mail.Responses to this e-mail ID are not being monitored.";

			MimeMessage message = new MimeMessage(session);

			message.setFrom(new InternetAddress(user));

			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

			if (option.equalsIgnoreCase("Activate")) {
				message.setSubject("Vendor Portal - User Activation/Change Password link");
			} else if (option.equalsIgnoreCase("Enable")) {
				message.setSubject("Vendor Portal - User Account Enabled");
			} else if (option.equalsIgnoreCase("Disable")) {
				message.setSubject("Vendor Portal - User Account Disabled");
			} else if (option.equalsIgnoreCase("AdminChangedPassword")) {
				message.setSubject("Vendor Portal - User Account Password Changed");
			} else if (option.equalsIgnoreCase("Reject")) {
				message.setSubject("Vendor Portal - User Account Rejected");
			}
			// message.setText(str);
			message.setContent(str, "text/html;charset=UTF-8");

			// send the message
			Transport.send(message);
			logger.debug("Email sent successfully");

		} catch (Exception e) {
			loggerErr.error("Invalid Addresses : " + e.getMessage());
			e.printStackTrace();
		}

	}

}
