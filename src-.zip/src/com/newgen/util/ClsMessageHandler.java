/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsMessageHandler.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class ClsMessageHandler implements IMessageCodes {

	public static boolean proptery = false;
	public static String DocumentPath = null;
	public static String DocumentType = null;
	public static String InvoiceNumberPrefix = null;
	public static int InvoiceNumberLength;
	public static String InvoiceStatusTypes = null;
	public static String QueryNumberPrefix = null;
	public static int QueryNumberLength;
	public static String QueryStatusTypes = null;
	public static int BatchSizeInvoiceSearch;
	public static int BatchSizeQuerySearch;
	public static int BatchSizeMyInvoice;
	public static int BatchSizeMyPO;
	public static int BatchSizeMyQuery;
	public static int BarCodeFontSize;
	public static int BarCodeSymbology;
	public static int BarCodeDpi;
	public static String BarCodeGeneratedFileName = null;
	public static String BarCodeGeneratedFileExt = null;
	public static String MainWelcomeNote = null;
	public static String MainDateFormat = null;
	public static String XMLDateFormat = null;
	public static String CalendarDateFormat = null;
	public static final int BatchSizeMax = 50;
	public static long MainLoginWaitTime;
	private static long LoginWaitTimeInMinute;
	public static String MainEnableDebugLog = null;
	public static String MainEnableErrorLog = null;
	public static String MainDBConfig = null;
	public static String SubmitInvoiceStatus = null;
	public static String InvoiceBillingCurrency = null;
	public static String InvoicePOType = null;
	public static String BarCodeLibraryPath = null;
	public static String BarcodeFontFamily = null;
	public static String DocumentSize = null;
	public static String HistoryAdministration = null;
	public static String HistoryVendorSearch = null;
	public static String HistoryVendorInvoice = null;
	public static String HistoryVendorQuery = null;
	public static int BatchSizeUserList;
	public static int BatchSizeVendorList;
	public static int BatchSizeCompanyList;
	public static int BatchSizeHistory;
	public static String LMPSubmitInvoice = "Y";
	public static String LMPSubmitQuery = "Y";
	public static String LMPSearchInvoiceQuery = "Y";
	public static String LMPMyInvoice = "Y";
	public static String LMPMyQuery = "Y";
	public static String TMPHome = "Y";
	public static String TMPChangePassword = "Y";
	public static String TMPLogOut = "Y";
	public static String MainAdminEmailId = null;
	public static String VPProtocol = null;
	public static String MainEmailUserId = null;
	public static String MainEmailPassword = null;
	public static String MainEmailServer = null;
	public static String strMainEmailServer = null;
	public static String EmailAuthentication = null;
	public static String LMPAddNewUser = null;
	public static String LMPUserList = null;
	public static String LMPVendorList = null;
	public static String LMPCompanyList = null;
	public static String LMPChangeUserPassword = null;
	public static String TMPSettings = null;
	public static String TMPHistory = null;
	public static String Port = null;
	public static String JBossPort = null;
	public static String MSG001 = null;
	public static String MSG002 = null;
	public static String MSG003 = null;
	public static String MSG004 = null;
	public static String MSG005 = null;
	public static String MSG006 = null;
	public static String MSG007 = null;
	public static String MSG008 = null;
	public static String MSG009 = null;
	public static String MSG010 = null;
	public static String MSG011 = null;
	public static String MSG012 = null;
	public static String MSG013 = null;
	public static String MSG014 = null;
	public static String MSG015 = null;
	public static String MSG016 = null;
	public static String MSG017 = null;
	public static String MSG018 = null;
	public static String MSG019 = null;
	public static String MSG020 = null;
	public static String MSG021 = null;
	public static String MSG022 = null;
	public static String MSG023 = null;
	public static String MSG024 = null;
	public static String MSG025 = null;
	public static String MSG026 = null;
	public static String MSG027 = null;
	public static String MSG028 = null;
	public static String MSG029 = null;
	public static String MSG030 = null;
	public static String MSG031 = null;
	public static String MSG032 = null;
	public static String MSG033 = null;
	public static String MSG034 = null;
	public static String MSG035 = null;
	public static String MSG036 = null;
	public static String MSG037 = null;
	public static String MSG038 = null;
	public static String MSG039 = null;
	public static String MSG040 = null;
	public static String MSG041 = null;
	public static String MSG042 = null;
	public static String MSG043 = null;
	public static String MSG044 = null;
	public static String MSG045 = null;
	public static String MSG046 = null;
	public static String MSG047 = null;
	public static String MSG048 = null;
	public static String MSG049 = null;
	public static String MSG050 = null;
	public static String MSG051 = null;
	public static String MSG052 = null;
	public static String MSG053 = null;
	public static String MSG054 = null;
	public static String MSG055 = null;
	public static String MSG056 = null;
	public static String MSG057 = null;
	public static String MSG058 = null;
	public static String MSG059 = null;
	public static String MSG060 = null;
	public static String MSG061 = null;
	public static String MSG062 = null;
	public static String MSG063 = null;
	public static String MSG064 = null;
	public static String MSG065 = null;
	public static String MSG066 = null;
	public static String MSG067 = null;
	public static String MSG068 = null;
	public static String MSG069 = null;
	public static String MSG070 = null;
	public static String MSG071 = null;
	public static String MSG072 = null;
	public static String MSG073 = null;
	public static String MSG074 = null;
	public static String MSG075 = null;
	public static String MSG076 = null;
	public static String MSG077 = null;
	public static String MSG078 = null;
	public static String MSG079 = null;
	public static String MSG080 = null;
	public static String MSG081 = null;
	public static String MSG082 = null;
	public static String MSG083 = null;
	public static String MSG084 = null;
	public static String MSG085 = null;
	public static String MSG086 = null;
	public static String MSG087 = null;
	public static String MSG088 = null;
	public static String MSG089 = null;
	public static String MSG090 = null;
	public static String MSG091 = null;
	public static String MSG092 = null;
	public static String MSG093 = null;

	public static String XMLUserName = null;
	public static String XMLPassword = null;

	/*
	 * public static String getErrorMsg(String pMsgCode) { // TODO
	 * Auto-generated method stub
	 * 
	 * if (pMsgCode.equalsIgnoreCase("MSG017")){ String MessageDesc
	 * =ClsMessageHandler.MSG017+LoginWaitTimeInMinute + " Minute(s)"; return
	 * MessageDesc; }else if (pMsgCode.equalsIgnoreCase("MSG028")){ String
	 * MessageDesc = ClsMessageHandler.MSG028+DocumentSize + " MB"; return
	 * MessageDesc; }else{ String MessageDesc= ClsMessageHandler.MSG001; return
	 * MessageDesc; } for (int i = 0; i < MSGCODES.length; i++) { if
	 * (MSGCODES[i].equalsIgnoreCase(pMsgCode)){ if
	 * (MSGCODES[i].equalsIgnoreCase("MSG017")){ String MessageDesc =
	 * MSGCODEDESC[i]+LoginWaitTimeInMinute + " Minute(s)"; return MessageDesc;
	 * }else if (MSGCODES[i].equalsIgnoreCase("MSG028")){ String MessageDesc =
	 * MSGCODEDESC[i]+DocumentSize + " MB"; return MessageDesc; }else{ return
	 * MSGCODEDESC[i]; } } } return "Unidentified Error Occured "; }
	 */

	public static void SetProperty(String pXMLFilePath) {
		try {
			// ResourceBundle
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse((new File(pXMLFilePath)));
			Element root = doc.getDocumentElement();
			NodeList nodelist = root.getChildNodes();

			if (proptery) {
				return;
			}

			for (int i = 0; i < nodelist.getLength(); i++) {

				Node node = nodelist.item(i);
				if (null != node && node.hasChildNodes()) {

					NodeList nodelistChild = node.getChildNodes();
					for (int j = 0; j < nodelistChild.getLength(); j++) {

						Node ChildNode = nodelistChild.item(j);
						if (null == ChildNode || ChildNode.getTextContent().equalsIgnoreCase("")) {
							continue;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(DocumentPathNode)) {
							DocumentPath = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(DocumentTypeNode)) {
							DocumentType = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(InvoiceNumberPrefixNode)) {
							InvoiceNumberPrefix = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(InvoiceNumberLengthNode)) {
							InvoiceNumberLength = Integer.parseInt(ChildNode.getTextContent());
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(InvoiceStatusTypesNode)) {
							InvoiceStatusTypes = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(QueryNumberPrefixNode)) {
							QueryNumberPrefix = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(QueryStatusTypesNode)) {
							QueryStatusTypes = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(QueryNumberLengthNode)) {
							QueryNumberLength = Integer.parseInt(ChildNode.getTextContent());
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeInvoiceSearchNode)) {
							BatchSizeInvoiceSearch = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeInvoiceSearch > BatchSizeMax)
								BatchSizeInvoiceSearch = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeQuerySearchNode)) {
							BatchSizeQuerySearch = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeQuerySearch > BatchSizeMax)
								BatchSizeQuerySearch = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeMyInvoiceNode)) {
							BatchSizeMyInvoice = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeMyInvoice > BatchSizeMax)
								BatchSizeMyInvoice = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeMyPONode)) {
							BatchSizeMyPO = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeMyPO > BatchSizeMax)
								BatchSizeMyPO = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeMyQueryNode)) {
							BatchSizeMyQuery = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeMyQuery > BatchSizeMax)
								BatchSizeMyQuery = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BarCodeFontSizeNode)) {
							BarCodeFontSize = Integer.parseInt(ChildNode.getTextContent());
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BarCodeSymbologyNode)) {
							BarCodeSymbology = Integer.parseInt(ChildNode.getTextContent());
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BarCodeDpiNode)) {
							BarCodeDpi = Integer.parseInt(ChildNode.getTextContent());
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BarCodeGeneratedFileNameNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							BarCodeGeneratedFileName = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BarCodeGeneratedFileExtNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							BarCodeGeneratedFileExt = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainWelcomeNoteNode)) {
							MainWelcomeNote = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainDateFormatNode)) {
							MainDateFormat = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(XMLDateFormatNode)) {
							XMLDateFormat = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(CalendarDateFormatNode)) {
							CalendarDateFormat = ChildNode.getTextContent();
							proptery = true;
						}

						if (ChildNode.getNodeName().equalsIgnoreCase(MainLoginWaitTimeNode)) {
							MainLoginWaitTime = Long.parseLong(ChildNode.getTextContent());
							LoginWaitTimeInMinute = MainLoginWaitTime / (60 * 1000);
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainEnableDebugLogNode)) {
							MainEnableDebugLog = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainEnableErrorLogNode)) {
							MainEnableErrorLog = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainDBConfigNode)) {
							MainDBConfig = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(JBossPortNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							JBossPort = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(SubmitInvoiceStatusNode)) {
							SubmitInvoiceStatus = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(InvoiceBillingCurrencyNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							InvoiceBillingCurrency = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(InvoicePOTypeNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							InvoicePOType = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BarCodeLibraryPathNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							BarCodeLibraryPath = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BarcodeFontFamilyNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							BarcodeFontFamily = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(DocumentSizeNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							DocumentSize = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(HistoryAdministrationNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							HistoryAdministration = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(HistoryVendorSearchNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							HistoryVendorSearch = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(HistoryVendorInvoiceNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							HistoryVendorInvoice = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(HistoryVendorQueryNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							HistoryVendorQuery = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeUserListNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							BatchSizeUserList = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeUserList > BatchSizeMax)
								BatchSizeUserList = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeVendorListNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							BatchSizeVendorList = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeVendorList > BatchSizeMax)
								BatchSizeVendorList = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeCompanyListNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							BatchSizeCompanyList = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeCompanyList > BatchSizeMax)
								BatchSizeCompanyList = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(BatchSizeHistoryNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							BatchSizeHistory = Integer.parseInt(ChildNode.getTextContent());
							if (BatchSizeHistory > BatchSizeMax)
								BatchSizeHistory = BatchSizeMax;
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPSubmitInvoiceNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPSubmitInvoice = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(Portnode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							Port = ChildNode.getTextContent();
							proptery = true;
						}

						if (ChildNode.getNodeName().equalsIgnoreCase(LMPSubmitQueryNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPSubmitQuery = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPSearchInvoiceQueryNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPSearchInvoiceQuery = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPMyInvoiceNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPMyInvoice = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPMyQueryNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPMyQuery = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(TMPHomeNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							TMPHome = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(TMPChangePasswordNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							TMPChangePassword = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(TMPLogOutNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							TMPLogOut = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainAdminEmailIdNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							MainAdminEmailId = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainEmailUserIdNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							MainEmailUserId = ChildNode.getTextContent();
							System.out.println("inside class handler MainEmailUserId:" + MainEmailUserId);
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainEmailPasswordNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							MainEmailPassword = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(MainEmailServerNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							MainEmailServer = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(strMainEmailServerNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							strMainEmailServer = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(EmailAuthenticationNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							EmailAuthentication = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(TMPHistoryNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							TMPHistory = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPAddNewUserNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPAddNewUser = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPUserListNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPUserList = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPVendorListNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPVendorList = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPCompanyListNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPCompanyList = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(LMPChangeUserPasswordNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							LMPChangeUserPassword = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(TMPSettingsNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							TMPSettings = ChildNode.getTextContent();
							proptery = true;
						}
						if (ChildNode.getNodeName().equalsIgnoreCase(VPProtocolNode)) {
							if (null == ChildNode.getTextContent() || ChildNode.getTextContent().equalsIgnoreCase(""))
								continue;
							VPProtocol = ChildNode.getTextContent();
							System.out.println("inside class handler VPProtocol:" + VPProtocol);
							proptery = true;
						}
					}
				}
			}

		} catch (SAXParseException err) {

		} catch (SAXException e) {
			Exception x = e.getException();
			((x == null) ? e : x).printStackTrace();

		} catch (Throwable t) {
			t.printStackTrace();
		}

	}
}
