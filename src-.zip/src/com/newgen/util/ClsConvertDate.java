/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsConvertDate.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

public class ClsConvertDate {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to convert date.
	 * 
	 * @param String
	 * @return Date
	 * @exception Exception
	 */
	public static Date ConvertxmlDatetoDate(String sXMLDate) {
		if (ClsUtil.isNullOrEmpty(sXMLDate)) {
			return null;
		}
		Date date = null;
		SimpleDateFormat sdfSource = new SimpleDateFormat(ClsMessageHandler.XMLDateFormat);
		try {
			date = sdfSource.parse(sXMLDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return date;
	}

	/**
	 * This Method is used to convert date.
	 * 
	 * @param String
	 * @return String
	 * @exception Exception
	 */
	public static String ConvertxmlDatetostring(String sXMLDate) {
		if (ClsUtil.isNullOrEmpty(sXMLDate)) {
			return null;
		}
		Date date = null;
		SimpleDateFormat sdfSource = new SimpleDateFormat(ClsMessageHandler.XMLDateFormat);
		try {
			date = sdfSource.parse(sXMLDate);

			logger.debug("formatted date is : " + date);

		} catch (Exception e) {
			loggerErr.error("Exception : " + e.getMessage());
			e.printStackTrace();
		}
		SimpleDateFormat sdfDestination = new SimpleDateFormat(ClsMessageHandler.MainDateFormat);
		String strDate = sdfDestination.format(date);

		return strDate;
	}

}
