/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: CommonMethod.java
*    Author                                    	: ksivashankar
*    Date written                          		: 23/02/2018
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/
package com.newgen.util;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.log4j.Logger;

import com.newgen.bean.PropertyBean;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;

/**
 *
 * @author Administrator
 */
public class CommonMethod {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerXml =Logger.getLogger("xmlLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	public static PropertyBean connect(PropertyBean propBean) {
		logger.debug("Inside connect method ....");
		String output = null;
		DMSXmlResponse oResp = null;

		String CabinetName = propBean.getCabinetName();
		String UserName = propBean.getUserName();
		String Password = propBean.getPassword();
		String ServerIP = propBean.getServerIP();

		System.out.println("UserName-->" + UserName);
		System.out.println("Password-->" + Password);
		System.out.println("ServerIP-->" + ServerIP);
		logger.debug("UserName-->" + UserName);
		logger.debug("Password-->" + Password);
		logger.debug("ServerIP-->" + ServerIP);
		StringBuilder inputconnect = new StringBuilder();
		inputconnect.append("<?xml version=\"1.0\"?><NGOConnectCabinet_Input><Option>NGOConnectCabinet</Option>"
				+ "<CabinetName>" + CabinetName + "</CabinetName><UserName>" + UserName + "</UserName>"
				+ "<UserPassword>" + Password + "</UserPassword>"// OmniDocs_Authentication_Manager_0123456789_!@#$%&*
				+ "<CurrentDateTime></CurrentDateTime><UserExist>N</UserExist>"
				+ "<MainGroupIndex></MainGroupIndex><UserType>U</UserType><Locale>en-US</Locale>"
				+ "<ApplicationName></ApplicationName><ApplicationInfo></ApplicationInfo>" + "<Hook>No</Hook>"
				+ "</NGOConnectCabinet_Input>");
		try {
			logger.debug("NGOConnectCabinet_Input Input XML ===" + inputconnect.toString());
			loggerXml.debug("NGOConnectCabinet_Input Input XML ===" + inputconnect.toString());
			System.out.println("Input==" + inputconnect.toString());
			output = WFCallBroker.execute(inputconnect.toString(), ServerIP, Integer.parseInt("3333"), 0);
			oResp = new DMSXmlResponse(output);
			System.out.println("Output===" + oResp);
			logger.debug("NGOConnectCabinet_Input Output XML ===" + oResp);
			loggerXml.debug("NGOConnectCabinet_Input Output XML ===" + oResp);
			if ("0".equalsIgnoreCase(oResp.getVal("Status"))) {
				propBean.setUserDBId(oResp.getVal("UserDBId"));
				propBean.setUserIndex(oResp.getVal("LoginUserIndex"));
			} else {
				propBean.setUserDBId("Invalid Session");
				propBean.setUserIndex("");
			}
		} catch (Exception ex) {
			loggerErr.debug("\n\n### **[Error]** Exception in connect cabinet : "+oResp.getVal("Error"));
			propBean.setUserDBId("Exception");
			propBean.setUserIndex("");
			ex.printStackTrace();
		} finally {
			if (output != null) {
				output = null;
			}
			if (oResp != null) {
				oResp = null;
			}
		}
		return propBean;
	}
	
	public static void disconCabinet(PropertyBean propBean,String SessionID)
	  {
		logger.debug("Inside disconCabinet method ....");
		DMSXmlResponse oResp = null;
		String output = null;

		String CabinetName = propBean.getCabinetName();
		String UserName = propBean.getUserName();
		String Password = propBean.getPassword();
		String ServerIP = propBean.getServerIP();

		System.out.println("CabinetName-->" + CabinetName);
		System.out.println("SessionID-->" + SessionID);
		logger.debug("CabinetName-->" + CabinetName);
		logger.debug("SessionID-->" + SessionID);
	    try
	    {
	      StringBuilder inputconnect = new StringBuilder();
	      inputconnect.append("<?xml version='1.0'?>");
	      inputconnect.append("<NGODisconnectCabinet_Input>");
	      inputconnect.append("<Option>NGODisconnectCabinet</Option>");
	      inputconnect.append("<CabinetName>" + CabinetName + "</CabinetName>");
	      inputconnect.append("<UserDBId>" + SessionID + "</UserDBId>");
	      inputconnect.append("</NGODisconnectCabinet_Input>");
	      logger.debug("NGODisconnectCabinet_Input input XML ==" + inputconnect.toString());
	      loggerXml.debug("NGODisconnectCabinet_Input input XML ==" + inputconnect.toString());
	      output = WFCallBroker.execute(inputconnect.toString(), ServerIP, Integer.parseInt("3333"), 0);
			oResp = new DMSXmlResponse(output);
			System.out.println("Output===" + oResp);
			logger.debug("NGODisconnectCabinet_Input Output XML ===" + oResp);
			loggerXml.debug("NGODisconnectCabinet_Input Output XML ===" + oResp);
			if ("0".equalsIgnoreCase(oResp.getVal("Status"))) {
				logger.debug("Cabinet Disconnected Successfully ...");				
			} else {
				logger.debug("Problem in Disconnecting cabinet:"+oResp.getVal("Error"));
			}
		} catch (Exception ex) {
			loggerErr.debug("\n\n### **[Error]** Exception in Disconnecting cabinet : "+oResp.getVal("Error"));
			ex.printStackTrace();
		} finally {
			if (output != null) {
				output = null;
			}
			if (oResp != null) {
				oResp = null;
			}
		}
	  }
	
	static StringBuffer strBuffer = null;
    NGEjbClient ngEJBClient = null;
    StringBuffer strInputXml = null;
    String sOutputXml = new String();
    String strDocIndex = null;
    String strFID = null;
    
	public String addFolder(PropertyBean propBean, String strFolderName, String Sessionid) throws IOException, Exception, FileNotFoundException {
//      NGEjbClient ngEJBClient = null;
//      ngEJBClient = NGEjbClient.getSharedInstance();
//      DMSInputXml input=new DMSInputXml();
//      input.getAddFolderXml(str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str, str)
      
		String CabinetName = propBean.getCabinetName();
		String UserName = propBean.getUserName();
		String Password = propBean.getPassword();
		String ServerIP = propBean.getServerIP();

		System.out.println("CabinetName-->" + CabinetName);
		System.out.println("Sessionid-->" + Sessionid);
		logger.debug("CabinetName-->" + CabinetName);
		
		StringBuffer strInputXml = null;
      try {
          strInputXml = new StringBuffer();
          String sOutputXml = new String();
          strInputXml.append("<?xml version=1.0?>");
          strInputXml.append("<NGOAddFolder_Input>");
          strInputXml.append("<Option>NGOAddFolder</Option>");
          strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
          strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
          strInputXml.append("<Folder>");
          strInputXml.append("<ParentFolderIndex>19542</ParentFolderIndex>");//21737 is BritanniaKYC//19542 TC1 WorkFlow
          strInputXml.append("<FolderName>" + strFolderName + "</FolderName>");
          strInputXml.append("<CreationDateTime></CreationDateTime>");
          strInputXml.append("<AccessType>S</AccessType>");
          strInputXml.append("<ImageVolumeIndex>1</ImageVolumeIndex>");
          strInputXml.append("<FolderType>G</FolderType>");
          //strInputXml.append("<Location>G</Location>");
          strInputXml.append("<Comment>comments</Comment>");
          strInputXml.append("<Owner>" + UserName + "</Owner>");
          strInputXml.append("<LogGeneration>Y</LogGeneration>");
          strInputXml.append("<EnableFtsFlag>Y</EnableFtsFlag>");
          strInputXml.append("<DuplicateName>N</DuplicateName>");
//          strInputXml.append("<DataDefinition>");
//          strInputXml.append("<DataDefName></DataDefName>");
//          strInputXml.append("<Fields>");
//          strInputXml.append("<Field>");
//          strInputXml.append("<IndexId></IndexId>");
//          strInputXml.append("<IndexValue></IndexValue>");
//          strInputXml.append("<IndexType></IndexType>");
//          strInputXml.append("</Field>");
//          strInputXml.append("</Fields>");
//          strInputXml.append("</DataDefinition>");
          strInputXml.append("</Folder>");
          strInputXml.append("</NGOAddFolder_Input>");
         logger.debug("addFolder Input XML ===>  :: " + strInputXml.toString());
          sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt("3333"), 0);
         logger.debug("addFolder output XML ===>  :: " + sOutputXml.toString());
          WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);
          if (xmlResponse.getVal("Status").equals("0")) {
             logger.debug("Folder created Successfully!!!!!!!!!!!!!");
             logger.debug("\n" + sOutputXml);
              strFID = xmlResponse.getVal("FolderIndex");
          } else {
             logger.debug("Folder already exist with the same name.!!!!!!!!!!!!!");
              strFID = xmlResponse.getVal("FolderIndex");
          }
      } catch (NGException ex) {
         loggerErr.info("\n\n### **(Error)**###");
      } catch (FileNotFoundException exx) {
         loggerErr.info("\n\n### **(Error)**###");
      }
      return strFID;
  }
	
	public void addDocProperties(PropertyBean propBean, String strDocIndex, String Sessionid, String strEmployeeCode, String strDocType, String strDocData) {
		String CabinetName = propBean.getCabinetName();
		String UserName = propBean.getUserName();
		String Password = propBean.getPassword();
		String ServerIP = propBean.getServerIP();

		System.out.println("CabinetName-->" + CabinetName);
		System.out.println("Sessionid-->" + Sessionid);
		logger.debug("CabinetName-->" + CabinetName);
		
		logger.debug("Inside add addDocProperties");
	        try {

	            strInputXml = new StringBuffer();
	            strInputXml.append("<?xml version=1.0?>");
	            strInputXml.append("<NGOChangeDocumentProperty_Input>");
	            strInputXml.append("<Option>NGOChangeDocumentProperty</Option>");
	            strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
	            strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
	            strInputXml.append("<GroupIndex>0</GroupIndex>");
	            strInputXml.append("<Document>");
	            strInputXml.append("<DocumentIndex>"+strDocIndex+"</DocumentIndex>");
	            strInputXml.append("<DataDefinition>");
	            strInputXml.append("<DataDefName>TrialCoilReqUpdate</DataDefName>");
	            strInputXml.append("<Fields>");
	            strInputXml.append("<Field>");
	            strInputXml.append("<IndexId>1051</IndexId>");
	            strInputXml.append("<IndexType>S</IndexType>");
	            strInputXml.append("<IndexValue>"+strEmployeeCode+"</IndexValue>");
	            strInputXml.append("</Field>");
	            strInputXml.append("<Field>");
	            strInputXml.append("<IndexId>1052</IndexId>");
	            strInputXml.append("<IndexType>S</IndexType>");
	            strInputXml.append("<IndexValue>"+strDocType+"</IndexValue>");
	            strInputXml.append("</Field>");
	            strInputXml.append("<Field>");
	            strInputXml.append("<IndexId>1053</IndexId>");
	            strInputXml.append("<IndexType>S</IndexType>");
	            strInputXml.append("<IndexValue>"+strDocData+"</IndexValue>");
	            strInputXml.append("</Field>");
	            strInputXml.append("</Fields>");
	            strInputXml.append("</DataDefinition>");
	            strInputXml.append("</Document>");
	            strInputXml.append("</NGOChangeDocumentProperty_Input>");
	           logger.debug("NGOChangeDocumentProperty INPUT XML : " + strInputXml.toString());
	            sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt("3333"), 0);
	           logger.debug("NGOChangeDocumentProperty OUTPUT XML : " + sOutputXml.toString());
	            WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);
	            if (xmlResponse.getVal("Status").equals("0")) {
	               logger.debug("document Properties updated !!!!!!!!!!!!!");
	            }
	            
	        } catch (Exception ex) {
	           loggerErr.info("\n\n### **(Error)**###");
	        }

	    }
	
	public String adddocument(PropertyBean propBean, String FileName, String FileSize, int pages, String Index, String Extension, String FileType, String folderindex, String sfilename, String Sessionid) throws IOException, Exception {
	       logger.debug("Inside add document");
	       String CabinetName = propBean.getCabinetName();
			String UserName = propBean.getUserName();
			String Password = propBean.getPassword();
			String ServerIP = propBean.getServerIP();

			System.out.println("CabinetName-->" + CabinetName);
			System.out.println("Sessionid-->" + Sessionid);
			logger.debug("CabinetName-->" + CabinetName);
	       try {

	           /* ngEJBClient = NGEjbClient.getSharedInstance();*/

	            strInputXml = new StringBuffer();
	            strInputXml.append("<?xml version=1.0?>");
	            strInputXml.append("<NGOAddDocument_Input>");
	            strInputXml.append("<Option>NGOAddDocument</Option>");
	            strInputXml.append("<CabinetName>" + CabinetName + "</CabinetName>");
	            strInputXml.append("<UserDBId>" + Sessionid + "</UserDBId>");
	            strInputXml.append("<Document>");
	            strInputXml.append("<ParentFolderIndex>" + folderindex + "</ParentFolderIndex>");
	            strInputXml.append("<DocumentName>" + sfilename + "</DocumentName>");
	            strInputXml.append("<DocumentType>N</DocumentType>");
	            strInputXml.append("<CreatedByAppName>" + Extension + "</CreatedByAppName>");
	            strInputXml.append("<DocumentSize>" + FileSize + "</DocumentSize>");
	            strInputXml.append("<ISIndex>" + Index + "</ISIndex>");
	            strInputXml.append("<TextISIndex></TextISIndex>");

	            //added by ksivashankar for configuring the dataclass
//	            strInputXml.append("<DataDefinition>");
//	            strInputXml.append("<DataDefIndex>BritKYC</DataDefIndex>");
////	            strInputXml.append("<Fields>1234</Fields>");
////	            strInputXml.append("<Fields>432</Fields>");
////	            strInputXml.append("<Fields>2343</Fields>");
//	            strInputXml.append("</DataDefinition>");
	            strInputXml.append("</Document>");
	            strInputXml.append("</NGOAddDocument_Input>");

	            sOutputXml = WFCallBroker.execute(strInputXml.toString(), ServerIP, Integer.parseInt("3333"), 0);
	           logger.debug("addDoc URL:" + strInputXml.toString());

	           logger.debug("add doc URL:s" + sOutputXml.toString());

	            WFXmlResponse xmlResponse = new WFXmlResponse(sOutputXml);

	            if (xmlResponse.getVal("Status").equals("0")) {
	                strDocIndex = xmlResponse.getVal("DocumentIndex");
	               logger.debug("document added!!!!!!!!!!!!!");
	               logger.debug("\n" + sOutputXml);
	            }
	        } catch (NGException ex) {
	           loggerErr.info("\n\n### **(Error)**###");
	            //ad.writeToLog("\nError");
	        }
	        return strDocIndex;

	    }

	
}
