/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsExportExcel.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)     
* 04/10/2017                        ksivashankar       				Bug 1015856 - Vendor Portal - Data is empty while Exporting excel or pdf in reports                                  
************************************************************************************************/
package com.newgen.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFFooter;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.VPReportMaster;
import com.newgen.bean.VPUserMasterBean;
import com.newgen.util.GeneralClass;

public class ClsExportExcel {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	// private static ArrayList<InvoiceDetails> arrayInvoiceDetails;

	private static HashMap<Integer, List> hash;
	private static ArrayList<HashMap<Integer, List>> myList = new ArrayList<HashMap<Integer, List>>();

	@SuppressWarnings("deprecation")
	public static void exportExcel(StringBuffer exportData, String headers, VPReportMaster reportBean, String sessionId,
			String tempPath) {
		logger.debug("************ Inside exportExcel Method ************");
		logger.debug("Inside exportExcel Method--");
		logger.debug("Inside exportExcel Method exportData--" + exportData);
		logger.debug("Inside exportExcel Method  headers--" + headers);
		logger.debug("Inside exportExcel Method tempPath--" + tempPath);

		// Bug 1015856 - Vendor Portal - Data is empty while Exporting excel or
		// pdf in reports
		// The below two lines for Local Testing
		
		 HSSFWorkbook workBook = new HSSFWorkbook(); 
		 HSSFSheet sheet = workBook.createSheet("Sample sheet");
		 
		// The below two lines for Serverside Testing
		/*org.apache.poi.ss.usermodel.Workbook workBook = (Workbook) new HSSFWorkbook();
		org.apache.poi.ss.usermodel.Sheet sheet = workBook.createSheet("Vendor Portal Reports");*/
		// logger.debug("Inside exportExcel Method 1-----------------");
		// HSSFFooter footer = sheet.getFooter();
		HSSFFooter footer = (HSSFFooter) sheet.getFooter();

		footer.setCenter(reportBean.getFooter());
		// logger.debug("Inside exportExcel Method
		// 2-----------------"+reportBean.getFooter());
		int rownum = 0;

		String[] head = new String[headers.length()];
		head = headers.split(",");
		HSSFCell cell = null;
		String colData = null;

		// logger.debug("Inside exportExcel Method 3-----------------");
		// HSSFCellStyle style = workbook.createCellStyle();
		HSSFCellStyle style = (HSSFCellStyle) workBook.createCellStyle();
		// style.setWrapText(true);
		// HSSFFont font = workBook.createFont();
		HSSFFont font = (HSSFFont) workBook.createFont();
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		// HSSFRow row = sheet.createRow(rownum++);
		HSSFRow row = (HSSFRow) sheet.createRow(rownum++);
		short cellnum = 0;
		for (String obj : head) {
			cell = row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue((String) obj);

			sheet.autoSizeColumn((short) (cellnum - 1));
			// logger.debug("Inside exportExcel Method
			// 4-----------------"+(String)obj);
		}

		String[] rows = new String(exportData).split(reportBean.getRowDelimiter());
		// logger.debug("Inside exportExcel Method
		// 5-----------------"+reportBean.getRowDelimiter());
		// logger.debug("Inside exportExcel Method
		// 6-----------------"+reportBean.getFieldDelimiter());
		// style = workBook.createCellStyle();
		style = (HSSFCellStyle) workBook.createCellStyle();
		style.setWrapText(true);
		// logger.debug("Inside exportExcel Method 7 rows.length
		// -----------------"+rows.length);
		for (int j = 0; j < rows.length; j++) {

			colData = rows[j];

			String[] columnData = colData.split(reportBean.getFieldDelimiter());

			// row = sheet.createRow(rownum++);
			row = (HSSFRow) sheet.createRow(rownum++);

			cellnum = 0;

			for (int i = 0; i < columnData.length; i++) {
				if (ClsUtil.isNullOrEmpty(columnData[i])) {
					columnData[i] = "";
				}

				cell = row.createCell(cellnum++);
				cell.setCellStyle(style);
				cell.setCellValue(columnData[i]);
			}

		}
		// logger.debug("Inside exportExcel Method before
		// generation----------------------");

		try {
			// FileOutputStream out = new FileOutputStream(new File(tempPath +
			// "\\ExcelReport"+sessionId+".xls"));
			FileOutputStream out = new FileOutputStream(
					new File(tempPath + File.separator + "ExcelReport" + sessionId + ".xls"));
			workBook.write(out);
			out.close();
			out.flush();

			logger.debug("Excel written successfully");

		} catch (FileNotFoundException e) {
			loggerErr.error("FileNotFoundException in ClsExportExcel  : " + e.getMessage());
			logger.debug("FileNotFoundException in ClsExportExcel  : " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			loggerErr.error("IOException in ClsExportExcel  : " + e.getMessage());
			logger.debug("IOException in ClsExportExcel  : " + e.getMessage());
			e.printStackTrace();
		}
		// logger.debug("Inside exportExcel Method at the end-------------");
	}

	public static void exportExcelx(StringBuffer exportData, String headers, VPReportMaster reportBean,
			String sessionId, String tempPath) {
		logger.debug("************ Inside exportExcelx Method ************");
		logger.debug("Inside exportExcelx Method--");
		logger.debug("Inside exportExcelx Method exportData--" + exportData);
		logger.debug("Inside exportExcelx Method  headers--" + headers);
		logger.debug("Inside exportExcelx Method tempPath--" + tempPath);
		System.out.println("insde excel creations siva: ");
		// Bug 1015856 - Vendor Portal - Data is empty while Exporting excel or
		// pdf in reports
		 HSSFWorkbook workBook = new HSSFWorkbook();
		 HSSFSheet sheet = workBook.createSheet("Sample sheet");
//		org.apache.poi.ss.usermodel.Workbook workBook = (Workbook) new XSSFWorkbook();
//		org.apache.poi.ss.usermodel.Sheet sheet = workBook.createSheet("Vendor Portal Reports");
		// logger.debug("Inside exportExcel Method 1-----------------");
		// HSSFFooter footer = sheet.getFooter();
		// XSSFFooter footer = (XSSFFooter) sheet.getFooter();

		// footer.setCenter(reportBean.getFooter());
		// logger.debug("Inside exportExcel Method
		// 2-----------------"+reportBean.getFooter());
		int rownum = 0;

		String[] head = new String[headers.length()];
		head = headers.split(",");
		Cell cell = null;
		String colData = null;

		// logger.debug("Inside exportExcel Method 3-----------------");
		 HSSFCellStyle style = workBook.createCellStyle();
//		XSSFCellStyle style = (XSSFCellStyle) workBook.createCellStyle();
		// style.setWrapText(true);
		 HSSFFont font = workBook.createFont();
//		XSSFFont font = (XSSFFont) workBook.createFont();
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		 HSSFRow row = sheet.createRow(rownum++);
//		XSSFRow row = (XSSFRow) sheet.createRow(rownum++);
		short cellnum = 0;
		for (String obj : head) {
			cell = (Cell) row.createCell(cellnum++);
//			cell.setCellStyle(style);
			cell.setCellValue((String) obj);

			sheet.autoSizeColumn((short) (cellnum - 1));
			// logger.debug("Inside exportExcel Method
			// 4-----------------"+(String)obj);
		}

		String[] rows = new String(exportData).split(reportBean.getRowDelimiter());
		// logger.debug("Inside exportExcel Method
		// 5-----------------"+reportBean.getRowDelimiter());
		// logger.debug("Inside exportExcel Method
		// 6-----------------"+reportBean.getFieldDelimiter());
		 style = workBook.createCellStyle();
//		style = (XSSFCellStyle) workBook.createCellStyle();
		style.setWrapText(true);
		// logger.debug("Inside exportExcel Method 7 rows.length
		// -----------------"+rows.length);
		for (int j = 0; j < rows.length; j++) {

			colData = rows[j];

			String[] columnData = colData.split(reportBean.getFieldDelimiter());

			 row = sheet.createRow(rownum++);
//			row = (XSSFRow) sheet.createRow(rownum++);

			cellnum = 0;

			for (int i = 0; i < columnData.length; i++) {
				if (ClsUtil.isNullOrEmpty(columnData[i])) {
					columnData[i] = "";
				}

				cell = (Cell) row.createCell(cellnum++);
//				cell.setCellStyle(style);
				cell.setCellValue(columnData[i]);
			}

		}
		//PRODUCTION CODE HERE
		/*org.apache.poi.ss.usermodel.Workbook workBook = (Workbook) new XSSFWorkbook();
		org.apache.poi.ss.usermodel.Sheet sheet = workBook.createSheet("Vendor Portal Reports");
		int rownum = 0;

		String[] head = new String[headers.length()];
		head = headers.split(",");
		Cell cell = null;
		String colData = null;
		XSSFCellStyle style = (XSSFCellStyle) workBook.createCellStyle();
		// style.setWrapText(true);
		XSSFFont font = (XSSFFont) workBook.createFont();
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		XSSFRow row = (XSSFRow) sheet.createRow(rownum++);
		short cellnum = 0;
		for (String obj : head) {
			cell = (Cell) row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue((String) obj);

			sheet.autoSizeColumn((short) (cellnum - 1));
			// logger.debug("Inside exportExcel Method
			// 4-----------------"+(String)obj);
		}

		String[] rows = new String(exportData).split(reportBean.getRowDelimiter());
		style = (XSSFCellStyle) workBook.createCellStyle();
		style.setWrapText(true);
		// logger.debug("Inside exportExcel Method 7 rows.length
		// -----------------"+rows.length);
		for (int j = 0; j < rows.length; j++) {

			colData = rows[j];

			String[] columnData = colData.split(reportBean.getFieldDelimiter());

			row = (XSSFRow) sheet.createRow(rownum++);

			cellnum = 0;

			for (int i = 0; i < columnData.length; i++) {
				if (ClsUtil.isNullOrEmpty(columnData[i])) {
					columnData[i] = "";
				}
				cell.setCellStyle(style);
				cell.setCellValue(columnData[i]);
			}

		}
		*/
		//PRODUCTION CODE ENDS HERE
		
		// logger.debug("Inside exportExcel Method before
		// generation----------------------");

		try {
			// FileOutputStream out = new FileOutputStream(new File(tempPath +
			// "\\ExcelReport"+sessionId+".xls"));
			FileOutputStream out = new FileOutputStream(
					new File(tempPath + File.separator + "ExcelReport_XLSX" + sessionId + ".xlsx"));
			workBook.write(out);
			out.close();
			out.flush();

			logger.debug("Excelx file written successfully");

		} catch (FileNotFoundException e) {
			loggerErr.error("FileNotFoundException in ClsExportExcel  : " + e.getMessage());
			logger.debug("FileNotFoundException in ClsExportExcel  : " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			loggerErr.error("IOException in ClsExportExcel  : " + e.getMessage());
			logger.debug("IOException in ClsExportExcel  : " + e.getMessage());
			e.printStackTrace();
		}
		// logger.debug("Inside exportExcel Method at the end-------------");
	}

	/*
	 * @SuppressWarnings("deprecation") public static void readExcel(File
	 * filename) {
	 * 
	 * System.out.println("Inside read excel ---> "); //FileInputStream fis =
	 * null; try { FileInputStream fis = new FileInputStream(filename);
	 * HSSFWorkbook workbook = new HSSFWorkbook(fis); HSSFSheet sheet =
	 * workbook.getSheetAt(0); // HSSFRow row = sheet.getRow(0);
	 * System.out.println("Before row iteration ---> "); Iterator rows=
	 * sheet.rowIterator(); while (rows.hasNext()) {
	 * System.out.println("Inside read excel - row iterator ---> "); HSSFRow row
	 * = (HSSFRow) rows.next(); Iterator cells = row.cellIterator(); // List
	 * Cname = new ArrayList(); // List data = new ArrayList(); // List age =
	 * new ArrayList(); while (cells.hasNext()) { HSSFCell cell = (HSSFCell)
	 * cells.next();
	 * 
	 * if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
	 * System.out.println(" ROW OR COLUMN NAME : -->" + cell.getCellType()); //
	 * System.out.println(""+ cell.getStringCellValue());
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * /* if(cell.getCellType() == HSSFCell.CELL_TYPE_STRING) { data.add(cell);
	 * System.out.println(cell.getRichStringCellValue().getString() + " ");
	 * logger.debug("somestring-------->"+cell.getRichStringCellValue().
	 * getString()); } else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
	 * { data.add(cell); System.out.print(cell.getNumericCellValue() + " "); }
	 * else if(cell.getCellType() == HSSFCell.CELL_TYPE_BOOLEAN) {
	 * System.out.println(cell.getBooleanCellValue() + " "); }
	 */

	// }
	/*
	 * for (int i = 0; i < data.size(); i = i + 2) { Cname.add(data.get(i));
	 * age.add(data.get(i + 1)); } sheetData.add(age);
	 */

	/*
	 * } } catch(Exception e) { System.out.println("Exception "+e); }
	 * 
	 * 
	 * }
	 */

	public ArrayList<HashMap<Integer, List>> getMap() {
		return myList;
	}

	public void setMap(ArrayList<HashMap<Integer, List>> map) {
		this.myList = map;
	}

	public ArrayList<HashMap<Integer, List>> readXLSFile(File filename) throws IOException, InvalidFormatException {
		System.out.println("Inside Read");
		InputStream ExcelFileToRead = new FileInputStream(filename);
		// ArrayList<HashMap<Integer, List>> myList = new
		// ArrayList<HashMap<Integer, List>>();

		HashMap<Integer, List> hashMap = new HashMap<Integer, List>();
		String sheetName = null;
		String a = "";
		// Create an ArrayList to store the data read from excel sheet.
		// List sheetData = new ArrayList();
		// Create an excel workbook from the file system
		org.apache.poi.ss.usermodel.Workbook workBook = WorkbookFactory.create(ExcelFileToRead);
		org.apache.poi.ss.usermodel.Sheet sheet = workBook.getSheetAt(0);

		Iterator rows = sheet.rowIterator();
		hashMap = new HashMap<Integer, List>();
		// while (rows.hasNext())
		// {

		logger.debug("No of rows in sheet " + sheet.getLastRowNum());
		for (int j = 0; j <= sheet.getLastRowNum(); j++) {
			XSSFRow row = (XSSFRow) sheet.getRow(j);
			// HSSFRow row = (HSSFRow) rows.next();
			// Iterator cells = row.cellIterator();

			List data = new LinkedList();
			// while (cells.hasNext())
			// {
			for (int i = 0; i < row.getLastCellNum(); i++) {
				XSSFCell cell = row.getCell(i);

				// HSSFCell cell = (HSSFCell) cells.next();
				// cell.setCellType(Cell.CELL_TYPE_STRING);

				/*
				 * if(i==1) { if(row.getCell((short) 1).getCellType()==
				 * XSSFCell.CELL_TYPE_NUMERIC) { DateFormat df = new
				 * SimpleDateFormat("dd/MM/yyyy"); java.util.Date d =
				 * row.getCell((short) 1).getDateCellValue(); String buy_date =
				 * df.format(d); System.out.println("date is :- "+ buy_date);
				 * data.add(buy_date); }
				 * 
				 * }
				 * 
				 * else {
				 */
				// logger.debug("cell type"+cell.getCellType() + "Row value-->"
				// + j);

				// cell.setCellType(Cell.CELL_TYPE_STRING);
				if (cell == null) {
					logger.debug("All field except date :- " + cell);
					String Stringcell = "";
					data.add(Stringcell);
					logger.debug("All field except date :- " + Stringcell);
				} else if (cell.getCellType() >= 0 && cell.getCellType() <= 1) {
					cell.setCellType(Cell.CELL_TYPE_STRING);
					data.add(cell);
				} else {
					data.add(cell);
					logger.debug("All field except date :- " + cell);
				}
				// data.add(cell);
				logger.debug("cell" + cell);
			}

			logger.debug("no of cells in row " + row.getLastCellNum());

			logger.debug("" + data.toString());
			hashMap.put(row.getRowNum(), data);
			logger.debug("HashMap Values" + hashMap.values());

			// logger.debug("ARRAYLIST OF HASHMAP"+ myList.toString());
			// sheetData.add(data);
		}

		myList.add(hashMap);
		// setMap(myList);
		// logger.debug("getting values of list of rows in excel using getter"+
		// getMap().size());
		// logger.debug("getting values of list of rows in excel using getter"+
		// getMap().toString());

		logger.debug("Hash map:" + hashMap.toString());

		/*
		 * for(int i=0;i<sheet.getLastRowNum();i++) { for(int j=0;j<26;j++) {
		 * if(myList.get(0).get(i).get(j)==null) {
		 * 
		 * }
		 * 
		 * }
		 * 
		 * }
		 */

		// outerMap.put(sheetName, hashMap);

		// }
		logger.debug("Using KeySet");
		for (Integer key : hashMap.keySet()) {
			logger.debug(key + " :: " + hashMap.get(key));

		}
		ExcelFileToRead.close();
		// return hashMap;
		return myList;

	}

	// added for Userlist generation
	public static void exportUserExcel(StringBuffer exportData, String headers, VPUserMasterBean usermasterBean,
			String sessionId, String tempPath) {
		logger.debug("************ Inside exportUserExcel Method ************");
		logger.debug("Inside exportUserExcel Method--");
		logger.debug("Inside exportUserExcel Method exportData--" + exportData);
		logger.debug("Inside exportUserExcel Method  headers--" + headers);
		logger.debug("Inside exportUserExcel Method tempPath--" + tempPath);

		// Bug 1015856 - Vendor Portal - Data is empty while Exporting excel or
		// pdf in reports
		// The below two lines for Local Testing
		
		  HSSFWorkbook workBook = new HSSFWorkbook(); HSSFSheet sheet =
		  workBook.createSheet("Sample sheet");
		 
		// The below two lines for Serverside Testing
		/*org.apache.poi.ss.usermodel.Workbook workBook = (Workbook) new HSSFWorkbook();
		org.apache.poi.ss.usermodel.Sheet sheet = workBook.createSheet("Vendor Portal Reports");*/

		// logger.debug("Inside exportExcel Method 1-----------------");
		// HSSFFooter footer = sheet.getFooter();
		HSSFFooter footer = (HSSFFooter) sheet.getFooter();

		footer.setCenter(usermasterBean.getFooter());
		// logger.debug("Inside exportExcel Method
		// 2-----------------"+reportBean.getFooter());
		int rownum = 0;

		String[] head = new String[headers.length()];
		head = headers.split(",");
		HSSFCell cell = null;
		String colData = null;

		// logger.debug("Inside exportExcel Method 3-----------------");
		// HSSFCellStyle style = workbook.createCellStyle();
		HSSFCellStyle style = (HSSFCellStyle) workBook.createCellStyle();
		// style.setWrapText(true);
		// HSSFFont font = workBook.createFont();
		HSSFFont font = (HSSFFont) workBook.createFont();
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		style.setFont(font);

		// HSSFRow row = sheet.createRow(rownum++);
		HSSFRow row = (HSSFRow) sheet.createRow(rownum++);
		short cellnum = 0;
		for (String obj : head) {
			cell = row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue((String) obj);

			sheet.autoSizeColumn((short) (cellnum - 1));
			// logger.debug("Inside exportExcel Method
			// 4-----------------"+(String)obj);
		}

		String[] rows = new String(exportData).split(usermasterBean.getRowDelimiter());
		// logger.debug("Inside exportExcel Method
		// 5-----------------"+reportBean.getRowDelimiter());
		// logger.debug("Inside exportExcel Method
		// 6-----------------"+reportBean.getFieldDelimiter());
		// style = workBook.createCellStyle();
		style = (HSSFCellStyle) workBook.createCellStyle();
		style.setWrapText(true);
		// logger.debug("Inside exportExcel Method 7 rows.length
		// -----------------"+rows.length);
		for (int j = 0; j < rows.length; j++) {

			colData = rows[j];

			String[] columnData = colData.split(usermasterBean.getFieldDelimiter());

			// row = sheet.createRow(rownum++);
			row = (HSSFRow) sheet.createRow(rownum++);

			cellnum = 0;

			for (int i = 0; i < columnData.length; i++) {
				if (ClsUtil.isNullOrEmpty(columnData[i])) {
					columnData[i] = "";
				}

				cell = row.createCell(cellnum++);
				cell.setCellStyle(style);
				cell.setCellValue(columnData[i]);
			}

		}
		// logger.debug("Inside exportExcel Method before
		// generation----------------------");

		try {
			// FileOutputStream out = new FileOutputStream(new File(tempPath +
			// "\\ExcelReport"+sessionId+".xls"));
			FileOutputStream out = new FileOutputStream(
					new File(tempPath + File.separator + "ExcelReport" + sessionId + ".xls"));
			workBook.write(out);
			out.close();
			out.flush();

			logger.debug("Excel written successfully");

		} catch (FileNotFoundException e) {
			loggerErr.error("FileNotFoundException in ClsExportExcel  : " + e.getMessage());
			logger.debug("FileNotFoundException in ClsExportExcel  : " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			loggerErr.error("IOException in ClsExportExcel  : " + e.getMessage());
			logger.debug("IOException in ClsExportExcel  : " + e.getMessage());
			e.printStackTrace();
		}
		// logger.debug("Inside exportExcel Method at the end-------------");
	}

}
