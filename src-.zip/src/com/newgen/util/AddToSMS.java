/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AddToSMS.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.io.File;

import org.apache.log4j.Logger;

import com.newgen.dao.WorkitemDAO;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;

public class AddToSMS {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	public static String AddtoSms(String docName, String savedFile, String Sessionid, String WorkitemEndPointurl,
			String jtsIpAddress, String cabinet, String jtsPort, String volumeIndex) throws JPISException {
		String strDocumentType = null;
		String CaseNumber = "";
		String sISIndex = "";

		try {
			File file = new File(savedFile);
			String fileName = file.getName();
			JPDBRecoverDocData docDBData = new JPDBRecoverDocData();
			ISPack.ISUtil.JPISIsIndex isIndex = new ISPack.ISUtil.JPISIsIndex();
			String simgVolId1 = "";
			String simgDocId = "";
			String OfDocType = docName;
			long lgvDocSize;
			File obvFile = file;
			lgvDocSize = obvFile.length();
			String sDocSize = Long.toString(lgvDocSize);
			int nNoOfPages = 1;
			String ISLookupBean = "com.newgen.omni.jts.txn.NGOClientServiceHandlerHome";
			String ISProviderURL = "jnp://192.168.13.93:2809";
			String ISJndiContextFactory = "org.jnp.interfaces.NamingContextFactory";
			int a = fileName.lastIndexOf(".");
			a = a + 1;
			String ss = fileName.substring(a);

			logger.debug("file in Add to SMS--" + file);
			logger.debug("fileName in Add to SMS---" + fileName);
			logger.debug("OfDocType in Add to SMS--" + OfDocType);
			logger.debug("lgvDocSize in Add to SMS--" + lgvDocSize);
			logger.debug("obvFile.length in Add to SMS--" + obvFile.length());
			logger.debug("obvFile in Add to SMS--" + obvFile);
			logger.debug("sDocSize in Add to SMS--" + sDocSize);
			logger.debug("nNoOfPages in Add to SMS--" + nNoOfPages);
			logger.debug("ISLookupBean in Add to SMS--" + ISLookupBean);
			logger.debug("ISProviderURL in Add to SMS--" + ISProviderURL);
			logger.debug("ISJndiContextFactory in Add to SMS--" + ISJndiContextFactory);
			logger.debug("a in Add to SMS--" + a);
			logger.debug("ss in Add to SMS--" + ss);

			logger.debug("savedfile in Add to SMS---->" + savedFile);

			CPISDocumentTxn.AddDocument_MT(null, jtsIpAddress, Short.parseShort(jtsPort), cabinet,
					Short.parseShort(volumeIndex), savedFile, docDBData, "", isIndex);

			if ((ss.equalsIgnoreCase("tif")) || (ss.equalsIgnoreCase("tiff"))) {
				nNoOfPages = com.newgen.niplj.fileformat.Tif6.getPageCount(savedFile);
			}

			// CPISDocumentTxn.AddDocument_MT(ISProviderURL,
			// ISJndiContextFactory, ISLookupBean, "mercedes",
			// Short.parseShort("1"), downloadFile1, docDBData, null, isIndex);
			simgVolId1 = simgVolId1 + isIndex.m_sVolumeId;
			simgDocId = simgDocId + isIndex.m_nDocIndex;
			// sISIndex = simgDocId + "#" + simgVolId1;
			sISIndex = simgDocId + "#" + simgVolId1 + "#" + ss + '#' + nNoOfPages + '#' + lgvDocSize;
			logger.debug("sISIndex------------->" + sISIndex);
			strDocumentType = OfDocType + (char) 21 + sISIndex + (char) 21 + nNoOfPages + (char) 21 + sDocSize
					+ (char) 21 + ss + (char) 25;
			logger.debug("strDocumentType------------->" + strDocumentType);
			logger.debug("Document addeds successfully in OD - SMS");

		} catch (JPISException exp) {
			exp.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();

		}
		return sISIndex;

	}

}
