/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsGenerateBarcode.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Class is used to  Generate Barcode
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.lang.reflect.Field;

import org.apache.log4j.Logger;

public class ClsGenerateBarcode {

	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static Logger logger = Logger.getLogger("consoleLogger");

	public native int NGIMAPBR_JNI_GenerateBarFont(String lpstrString, int iFont, int iSymbology, int iDpi,
			String lpstrFileName);

	static {
		boolean imgap32 = false;
		boolean imgfl32 = false;
		final String[] libraries = ClsLoadLibrary.getLoadedLibraries(ClassLoader.getSystemClassLoader()); // MyClassName.class.getClassLoader()
		for (int i = 0; i < libraries.length; i++) {
			if (libraries[i].contains("imgap32")) {
				imgap32 = true;
			}
			if (libraries[i].contains("imgfl32")) {
				imgfl32 = true;
			}
		}
		if (!imgap32 || !imgfl32) {
			System.setProperty("java.library.path", ClsMessageHandler.BarCodeLibraryPath);
			Field fieldSysPath;
			try {
				fieldSysPath = ClassLoader.class.getDeclaredField("sys_paths");
				fieldSysPath.setAccessible(true);
				try {
					fieldSysPath.set(null, null);
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					loggerErr.error("IllegalAccessException in ClsGenerateBarcode:" + e.getMessage());
					e.printStackTrace();
				}
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				loggerErr.error("IllegalArgumentException in ClsGenerateBarcode:" + e.getMessage());
				e.printStackTrace();

			} catch (NoSuchFieldException e) {
				// TODO Auto-generated catch block
				loggerErr.error("NoSuchFieldException in ClsGenerateBarcode:" + e.getMessage());
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				loggerErr.error("SecurityException in ClsGenerateBarcode:" + e.getMessage());
				e.printStackTrace();
			}
			if (!imgap32) {
				System.loadLibrary("imgap32");
				logger.debug("imgap32 Loaded Succesfully");
			}
			if (!imgfl32) {
				System.loadLibrary("imgfl32");
				logger.debug("imgfl32 Loaded Succesfully");
			}
		}

	}

	public static int generateBarcode(String pInvNoForBarCode, int pFontSize, int pSymbology, int pDpi,
			String pGeneratedFileName) {
		try {
			ClsGenerateBarcode genBarCode = new ClsGenerateBarcode();

			int i = genBarCode.NGIMAPBR_JNI_GenerateBarFont(pInvNoForBarCode, pFontSize, pSymbology, pDpi,
					pGeneratedFileName);

			System.out.println("BarCode : " + i);
			return i;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			loggerErr.error("Exception in generateBarcode method:" + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

}
