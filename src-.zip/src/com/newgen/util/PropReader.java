/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: PropReader.java
*    Author                                    	: ksivashankar
*    Date written                          		: 23/02/2018
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/
package com.newgen.util;
import com.newgen.bean.PropertyBean;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropReader {

    public static String blankString(Object object) {
        String sReturnVal = "";
        if (object != null && !object.toString().trim().equalsIgnoreCase("") && !object.toString().trim().equalsIgnoreCase("null")) {
            sReturnVal = object.toString();
        }
        return sReturnVal;
    }

    public PropertyBean readPropertyFile() {
        PropertyBean myBean = null;
        Properties reader = new Properties();
        InputStream in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/resources/configuration.properties");
        try {
            myBean = new PropertyBean();
            //reader = new Properties();
            reader.load(in);

            myBean.setCabinetName(blankString(reader.getProperty("CabinetName")));
            myBean.setPassword(blankString(reader.getProperty("Password")));
            myBean.setShowLogOut(blankString(reader.getProperty("ShowLogOut")));
            myBean.setUserName(blankString(reader.getProperty("UserName")));
            myBean.setServerIP(blankString(reader.getProperty("ServerIP")));
            myBean.setServerPort(blankString(reader.getProperty("ServerPort")));
            myBean.setProtocol(blankString(reader.getProperty("Protocol")));
            System.out.println("Password-->" + myBean.getPassword());

        } catch (IOException ex) {
            ex.printStackTrace();
            return myBean;
        }
        return myBean;
    }
}