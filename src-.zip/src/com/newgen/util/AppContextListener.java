/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AppContextListener.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Listener implementation class AppContextListener
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.PropertyConfigurator;

public class AppContextListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {

		// Your code here
		System.out.println("Context has been destroyed of NGWEBVendorPortal at" + (new java.util.Date()));

	}

	@Override
	public void contextInitialized(ServletContextEvent servletContextEvent) {
		Properties props = null;
		System.out.println("Context to be initialized of NGWEBVendorPortal at " + (new java.util.Date()));
		props = new Properties();
		java.io.FileInputStream is = null;
		try {
			java.io.File fIni = new java.io.File("WebServiceConsume.ini");
			if (!(fIni.isFile() && fIni.exists())) {
				String message = "NewgenVendorPortal: WebServiceConsume.ini file not present.";
				throw new Exception(message);
			}
			is = new java.io.FileInputStream(fIni);
			props.load(is);
			String endPointURL = props.getProperty("EndPointurl");
			String IBPSEndPointURL = props.getProperty("IBPSEndPointurl");
			String WorkItemEndPointURL = props.getProperty("WorkitemEndPointurl");
			String ODIP = props.getProperty("ODIP");
			String username = props.getProperty("XMLUserName");
			String pwd = props.getProperty("XMLPassword");
			String cabinet = props.getProperty("Cabinet");
			String volumeIndex = props.getProperty("VolumeIndex");
			String jtsIpAddress = props.getProperty("jtsIpAddress");
			String jtsPort = props.getProperty("jtsPort");

			String OD_SessionURL = props.getProperty("OD_SessionURL");
			String OD_Session_User = props.getProperty("OD_Session_User");
			String OD_Session_Pwd = props.getProperty("OD_Session_Pwd");
			String WrapperPort = props.getProperty("WrapperPort");
			String UserType = props.getProperty("UserType");
			String SocketServerIp = props.getProperty("SocketServerIp");
			String SocketPort = props.getProperty("SocketPort");
			String InitiateFromActivityId = props.getProperty("InitiateFromActivityId");
			String InitiateFromActivityName = props.getProperty("InitiateFromActivityName");
			String ProcessDefId = props.getProperty("ProcessDefId");
			String ProcessName = props.getProperty("ProcessName");

			ClsMessageHandler.XMLUserName = username;
			ClsMessageHandler.XMLPassword = pwd;

			ServletContext s_con = servletContextEvent.getServletContext();
			s_con.setAttribute("EndPointURL", endPointURL);
			s_con.setAttribute("IBPSEndPointURL", IBPSEndPointURL);
			s_con.setAttribute("WorkItemEndPointURL", WorkItemEndPointURL);
			s_con.setAttribute("ODIP", ODIP);
			s_con.setAttribute("Cabinet", cabinet);
			s_con.setAttribute("VolumeIndex", volumeIndex);
			s_con.setAttribute("jtsIpAddress", jtsIpAddress);
			s_con.setAttribute("jtsPort", jtsPort);

			s_con.setAttribute("OD_SessionURL", OD_SessionURL);
			s_con.setAttribute("OD_Session_User", OD_Session_User);
			s_con.setAttribute("OD_Session_Pwd", OD_Session_Pwd);
			s_con.setAttribute("WrapperPort", WrapperPort);
			s_con.setAttribute("UserType", UserType);

			System.out.println("endPointURL in context listner" + endPointURL);
			System.out.println("IBPSEndPointURL in context listner" + IBPSEndPointURL);
			System.out.println("WorkItemEndPointURL in context listner" + WorkItemEndPointURL);
			System.out.println("endPointURL in context listner" + endPointURL);
			System.out.println("IBPSEndPointURL in context listner" + IBPSEndPointURL);
			s_con.setAttribute("SocketServerIp", SocketServerIp);
			s_con.setAttribute("SocketPort", SocketPort);
			s_con.setAttribute("InitiateFromActivityId", InitiateFromActivityId);
			s_con.setAttribute("InitiateFromActivityName", InitiateFromActivityName);
			s_con.setAttribute("ProcessDefId", ProcessDefId);
			s_con.setAttribute("ProcessName", ProcessName);

			System.out.println("SocketServerIp in context listner" + SocketServerIp);
			System.out.println("SocketPort in context listner" + SocketPort);
			System.out.println("InitiateFromActivityId in context listner" + InitiateFromActivityId);
			System.out.println("InitiateFromActivityName in context listner" + InitiateFromActivityName);
			System.out.println("ProcessDefId in context listner" + ProcessDefId);
			System.out.println("ProcessName in context listner" + ProcessName);
			System.out.println("Configuring Mail part......");
			System.out.println("Reading VendorPortal.xml");
			ClsMessageHandler.SetProperty(servletContextEvent.getServletContext().getRealPath("VendorPortal.xml"));
			System.out.println("Completed reading file VendorPortal.xml...");
			System.out.println("Mail has been configured successfully");

			// Load log4j file
			// System.setProperty("rootPath",
			// s_con.getRealPath(File.separator));
			String log4jConfigFile = s_con.getInitParameter("log4j-config-location");
			String fullPath = s_con.getRealPath("") + File.separator + log4jConfigFile;

			PropertyConfigurator.configure(fullPath);
			// System.getProperty("user.dir");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}