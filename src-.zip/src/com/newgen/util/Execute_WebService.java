/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: Execute_WebService.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Class is used to Execute WebService
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Properties;

import javax.mail.Session;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextEvent;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.fileupload.servlet.ServletRequestContext;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import com.newgen.webserviceclient.NGWebServiceClient;

public class Execute_WebService {

	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static Logger loggerXml = Logger.getLogger("xmlLogger");
	private static Logger logger = Logger.getLogger("consoleLogger");

	public static ArrayList<String> executeWebservice(String SOAP_inxml, String EndPointurl) {
		String SOAPResponse_xml = "";
		ArrayList<String> outptXMLlst = null;
		NGWebServiceClient ngwsclnt = null;
		Socket socket = null;
		Properties props = null;
		try {
			props = new Properties();
			java.io.File fIni = new java.io.File("WebServiceConsume.ini");
			if (!(fIni.isFile() && fIni.exists())) {
				String message = "NewgenVendorPortal: WebServiceConsume.ini file not present.";
				throw new Exception(message);
			}
			java.io.FileInputStream is = new java.io.FileInputStream(fIni);
			props.load(is);
			String SocketIpAddress = props.getProperty("SocketIpAddress");
			Integer SocketPort = Integer.parseInt(props.getProperty("SocketPort"));
			String Workitemurl = props.getProperty("WorkitemEndPointurl");
			is.close();

			logger.debug("executeWebservice method starts...");
			outptXMLlst = new ArrayList<String>();

			logger.debug("Connecting to Socket Server...");
			socket = new Socket(SocketIpAddress, SocketPort);

			logger.debug("Socket Server Connected" + socket);
			logger.debug("Endpoint URL to execute wsdl" + EndPointurl);
			loggerXml.debug("SOAP_inxml->" + SOAP_inxml);

			// Sending stream to server
			/*
			 * DataOutputStream dout=new
			 * DataOutputStream(socket.getOutputStream());
			 * dout.writeBytes(EndPointurl+"~"+SOAP_inxml);
			 * logger.debug("Input XML sent to Server"+SOAP_inxml);
			 */

			DataOutputStream dout = new DataOutputStream(socket.getOutputStream());
			// dout.writeBytes(EndPointurl+"~"+SOAP_inxml);
			// dout.write((EndPointurl+"~"+SOAP_inxml).getBytes("UTF-16LE"));
			// ----- Commented By Saravanan M
			dout.write((EndPointurl + "~" + "VPcalls" + "~" + SOAP_inxml).getBytes("UTF-16LE"));
			dout.flush();

			// Get Response
			/*
			 * BufferedReader r = new BufferedReader(new
			 * InputStreamReader(socket.getInputStream(), "UTF-8"));
			 * StringBuilder content = new StringBuilder(); String line = "";
			 * while ((line = r.readLine()) != null) {
			 * content.append(line+"\n"); }
			 */

			/* logger.debug("Input XML sent to Server"+SOAP_inxml); */

			DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
			String content = "";
			byte[] bytes = new byte[3500];
			StringBuilder sb = new StringBuilder(100);
			while (sb.lastIndexOf("</soapenv:Envelope>") == -1) {
				int bytesRead = in.read(bytes);
				sb.append(new String(bytes, 0, bytesRead, "UTF-16LE"));
			}
			content = sb.toString();
			/* System.out.println("Received message :" + content); */

			dout.close();
			in.close();

			SOAPResponse_xml = content;
			loggerXml.debug("Output XML Received->" + SOAPResponse_xml);

			/* logger.debug("Output XML Received->"+SOAPResponse_xml); */
			// Till Here 30-Jan-17

			if (SOAPResponse_xml != "" && EndPointurl != Workitemurl) {
				outptXMLlst = getAllTagValues(SOAPResponse_xml, "FieldValue");
				return outptXMLlst;
			}
			// newly added
			else if (SOAPResponse_xml != "" && EndPointurl == Workitemurl) {
				return outptXMLlst;
			} else {
				return null;
			}

		} catch (Exception e) {
			loggerErr.error("Exception in Execute_WebService:" + e.getMessage());
			e.printStackTrace();
			SOAPResponse_xml = e.getMessage();
			return null;
		}
		finally {
			if (outptXMLlst != null)
				outptXMLlst = null;

			if (ngwsclnt != null)
				ngwsclnt = null;
			if (socket != null)
				try {
					// logger.debug("Socket Server before closed" + socket);
					socket.close();
					socket = null;
					logger.debug("Socket Server Disconnected");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if (props != null)
				props.clear();

		} // till here

	}

	public static String executeWebservice_initiate(String SOAP_inxml, String EndPointurl) {
		String SOAPResponse_xml = "";
		ArrayList<String> outptXMLlst = null; 
		NGWebServiceClient ngwsclnt = null;
		Socket socket = null;
		Properties props = null;
		try {
			props = new Properties();
			java.io.File fIni = new java.io.File("WebServiceConsume.ini");
			if (!(fIni.isFile() && fIni.exists())) {
				String message = "NewgenVendorPortal: WebServiceConsume.ini file not present.";
				throw new Exception(message);
			}
			java.io.FileInputStream is = new java.io.FileInputStream(fIni);
			props.load(is);
			String SocketIpAddress = props.getProperty("SocketIpAddress");
			Integer SocketPort = Integer.parseInt(props.getProperty("SocketPort"));
			String Workitemurl = props.getProperty("WorkitemEndPointurl");
			is.close();

			logger.debug("executeWebservice method starts for initiation ...");

			// ngwsclnt = new NGWebServiceClient(true);
			// ArrayList<String> outptXMLlst = new ArrayList<String>();
			// NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
			// SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, EndPointurl);
			/*
			 * logger.debug("Connecting to Socket Server...");
			 * 
			 * socket = new Socket(SocketIpAddress, SocketPort);
			 * 
			 * logger.debug("Socket Server Connected" + socket);
			 * logger.debug("Endpoint URL to execute wsdl" + EndPointurl);
			 * //DataOutputStream dout=new
			 * DataOutputStream(socket.getOutputStream());
			 * //dout.writeBytes(SOAP_inxml); //dout.writeBytes(EndPointurl);
			 * loggerXml.debug("SOAP_inxml->"+SOAP_inxml);
			 * 
			 * DataOutputStream dout = new
			 * DataOutputStream(socket.getOutputStream());
			 * dout.writeUTF(SOAP_inxml); dout.flush();
			 * 
			 * logger.debug("Sending SOAP Input XML to Socket Server...");
			 * StringBuilder sb_SOAP_inxml = new StringBuilder(SOAP_inxml);
			 * 
			 * StringBuilder sb_SOAPResponse_xml=new StringBuilder();
			 * sb_SOAPResponse_xml=doComms.executeWebservice(sb_SOAP_inxml,
			 * EndPointurl);
			 * //SOAPResponse_xml=doComms.executeWebservice(sb_SOAP_inxml,
			 * EndPointurl); System.out.println(
			 * "Response from execute webservice sb_SOAPResponse_xml -->"
			 * +sb_SOAPResponse_xml);
			 * 
			 * SOAPResponse_xml=sb_SOAPResponse_xml.toString();
			 * logger.debug("SOAP Output XML Received from Socket Server...");
			 * loggerXml.debug("SOAPResponse_xml->"+SOAPResponse_xml);
			 */
			// System.out.println("o/p
			// list"+doComms.executeWebservice(SOAP_inxml, EndPointurl));

			// loggerXml.debug("SOAPResponse_xml:"+SOAPResponse_xml);
			// dout.close();

			// Newly Added - 30-Jan-17
			logger.debug("Connecting to Socket Server for initiation ...");
			socket = new Socket(SocketIpAddress, SocketPort);

			logger.debug("Socket Server Connected for initiation" + socket);
			logger.debug("Endpoint URL to execute wsdl for initiation" + EndPointurl);
			loggerXml.debug("SOAP_inxml for initiation ->" + SOAP_inxml);

			// Sending stream to server
			/*
			 * DataOutputStream dout=new
			 * DataOutputStream(socket.getOutputStream());
			 * dout.writeBytes(EndPointurl+"~"+SOAP_inxml);
			 * logger.debug("Input XML sent to Server"+SOAP_inxml);
			 */
			// Get Response
			/*
			 * BufferedReader r = new BufferedReader(new
			 * InputStreamReader(socket.getInputStream(), "UTF-8"));
			 * StringBuilder content = new StringBuilder(); String line = "";
			 * while ((line = r.readLine()) != null) {
			 * content.append(line+"\n"); }
			 */

			DataOutputStream dout = new DataOutputStream(socket.getOutputStream());
			// dout.writeBytes(EndPointurl+"~"+SOAP_inxml);
			// dout.write((EndPointurl+"~"+SOAP_inxml).getBytes("UTF-16LE"));
			// ---- Commented by Saravanan M
			dout.write((EndPointurl + "~" + "wfinitiate" + "~" + SOAP_inxml).getBytes("UTF-16LE"));
			dout.flush();

			logger.debug("Input XML sent to Server for initiation " + SOAP_inxml);

			DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
			String content = "";
			byte[] bytes = new byte[45000];
			StringBuilder sb = new StringBuilder(45000);
			while (sb.lastIndexOf("</soapenv:Envelope>") == -1) {
				int bytesRead = in.read(bytes);
				sb.append(new String(bytes, 0, bytesRead, "UTF-16LE"));
			}
			content = sb.toString();
			/*
			 * System.out.println("Received message for initiation :" +
			 * content);
			 */

			SOAPResponse_xml = content;
			loggerXml.debug("Output XML Received for initiation ->" + SOAPResponse_xml);
			// Till Here 30-Jan-17

			if (SOAPResponse_xml != "") {

				return SOAPResponse_xml;
			}

			else {
				return null;
			}

		} catch (Exception e) {
			loggerErr.error("Exception in Execute_WebService for initiation :" + e.getMessage());
			e.printStackTrace();
			SOAPResponse_xml = e.getMessage();
			return null;
		}
		finally {
			if (outptXMLlst != null)
				outptXMLlst = null;
			if (ngwsclnt != null)
				ngwsclnt = null;
			if (socket != null)
				try {
					// logger.debug("Socket Server before closed" + socket);
					socket.close();
					socket = null;
					logger.debug("Socket Server Disconnected for initiation ");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if (props != null)
				props.clear();

		} // till here

	}

	// xml parser
	public static String getTagValue(String xml, String tag) {

		logger.debug("getTagValue method starts...");

		Document doc = getDocument(xml);
		NodeList nodeList = doc.getElementsByTagName(tag);
		int length = nodeList.getLength();
		if (length > 0) {
			Node node = nodeList.item(0);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				NodeList childNodes = node.getChildNodes();
				String value = "";
				int count = childNodes.getLength();
				for (int i = 0; i < count; i++) {
					Node item = childNodes.item(i);
					if (item.getNodeType() == Node.TEXT_NODE) {
						value += item.getNodeValue();
					}
				}
				return value;
			} else if (node.getNodeType() == Node.TEXT_NODE) {
				return node.getNodeValue();
			}
		}
		return "";
	}

	// Fetching value of XML tags. i.e. <FieldName>Field1</FieldName>
	public static ArrayList<String> getAllTagValues(String xml, String tag) {
		ArrayList<String> sList = new ArrayList<String>();
		Document doc = getDocument(xml);
		NodeList nodeList = doc.getElementsByTagName(tag);
		int length = nodeList.getLength();
		if (length > 0) {
			for (int k = 0; k < length; k++) {
				Node node = nodeList.item(k);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					NodeList childNodes = node.getChildNodes();
					int count = childNodes.getLength();
					if (count == 0) {
						sList.add("NULL");
					}
					for (int i = 0; i < count; i++) {
						Node item = childNodes.item(i);
						if (item.getNodeType() == Node.TEXT_NODE) {
							sList.add(item.getNodeValue());
						}
					}
				} else if (node.getNodeType() == Node.TEXT_NODE) {
					sList.add(node.getNodeValue());
				}
			}
		}
		return sList;
	}

	public static Document getDocument(String xml) {
		// Step 1: create a DocumentBuilderFactory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		// Step 2: create a DocumentBuilder
		DocumentBuilder db = null;
		try {
			db = dbf.newDocumentBuilder();
		} catch (Exception e) {
			loggerErr.error("Exception in creating  a document builder:" + e.getMessage());
			e.printStackTrace();
		}
		// Step 3: parse the input file to get a Document object
		Document doc = null;
		try {
			doc = db.parse(new InputSource(new StringReader(xml)));
		} catch (Exception e) {
			loggerErr.error("Exception in parsing the input file to get a Document object:" + e.getMessage());
			e.printStackTrace();
		}
		return doc;
	}

}
