/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GenerateBarcodeImage.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Program in java to generate barcode image 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;

import org.apache.log4j.Logger;

public class GenerateBarcodeImage {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	public static void main(String args[]) throws Exception {
		new GenerateBarcodeImage().GenerateBarCode("INV000091", "bmp", "D:/code128.ttf");

	}

	/**
	 * This Method is used to Generate BarCode.
	 * 
	 * @param String
	 *            InvoiceNumber, String FileExtn, Date FontFilePath
	 * @return int
	 * @exception Exception
	 */
	public int GenerateBarCode(String pInvoiceNumber, String pFileExtn, String pFontFilePath) {

		logger.debug("GenerateBarCode Method Starts...");

		File saveFile = null;
		File file1 = null;
		long starttime = System.currentTimeMillis();

		try {
			int width, height;
			String FileName = pInvoiceNumber + "." + pFileExtn;
			saveFile = new File(FileName);
			String format = new String(pFileExtn);
			BufferedImage bi, biFiltered;
			width = 770;
			height = 220;
			BufferedImage bufimg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics graphicsobj = bufimg.createGraphics();

			file1 = new File(pFontFilePath);
			FileInputStream fin = new FileInputStream(file1);
			Font font = Font.createFont(Font.TRUETYPE_FONT, fin);
			Font font1 = font.deriveFont(46f);

			graphicsobj.setFont(font1);
			graphicsobj.setFont(Font.getFont("3 of 9 Barcode")); // 3 of 9
																	// Barcode
			graphicsobj.setColor(Color.WHITE);
			graphicsobj.fillRect(1, 1, 768, 218);
			graphicsobj.setColor(Color.BLACK);
			((Graphics2D) graphicsobj).drawString("*" + pInvoiceNumber + "*", 25, 170);
			ImageIO.write(bufimg, format, saveFile);
			return 1;
		} catch (Exception e) {
			loggerErr.error("Exception in GenerateBarCode Class : " + e.getMessage());
			e.printStackTrace();
		} finally {
			file1 = null;
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Generating BarCode is " + totaltime);

		return -1;
	}
}