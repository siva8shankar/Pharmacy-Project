/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsUserActivity.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserActivityTable;
import com.newgen.dao.UserMasterDAOI;

public class ClsUserActivity implements Runnable {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	String UserName = null;
	String SessionId = null;
	String ActivityType = null;
	VPUserActivityTable UserActivity = null;
	UserMasterDAOI usermasterDAO = null;
	String endurl = null;

	public ClsUserActivity() {
	}

	public ClsUserActivity(VPUserActivityTable pUserActivity, String endurl) {
		this.UserActivity = pUserActivity;
		this.endurl = endurl;
	}

	public ClsUserActivity(String pUserName, String pSessionId, String pActivityType) {
		this.UserName = pUserName;
		this.SessionId = pSessionId;
		this.ActivityType = pActivityType;

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			logger.debug("User Activity With Details");

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", this.UserActivity.getUserName());
			xmlvalues.put("SessionID", this.UserActivity.getSessionID());
			xmlvalues.put("ActivityType", this.UserActivity.getActivityType());
			java.util.Date date = new java.util.Date();
			Timestamp timeStamp = new Timestamp(date.getTime());
			xmlvalues.put("ActivityDateTime", timeStamp.toString());
			xmlvalues.put("ActivityDescription", this.UserActivity.getActivityDesc());
			option = "ProcedureInsertUserActivity";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0)
				logger.debug("success: User Activity Data Inserted");

		} catch (Exception e) {
			loggerErr.error("Exception in ClsUserActivity:" + e.getMessage());
			e.printStackTrace();
		}

	}

}