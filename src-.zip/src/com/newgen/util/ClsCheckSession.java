/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsCheckSession.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

public class ClsCheckSession {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to check the session
	 * 
	 * @param String
	 *            userName, String sessionId
	 * @return int
	 * @exception Exception
	 */
	public static int checkValidSession(String userName, String sessionId, String endurl) {

		logger.debug("checkValidSession Method Starts...");
		long starttime = System.currentTimeMillis();
		String SOAP_inxml = "";
		String option = "";
		int result = 0;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Username", userName);
			xmlvalues.put("sessionid", sessionId);
			option = "ProcedureCheckSession";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (outptXMLlst.get(0).equalsIgnoreCase("0")) {
				result = -2;

			} else {
				result = 1;

			}
		} catch (Exception e) {
			loggerErr.error("Exception While validating session : " + e.getMessage());
			e.printStackTrace();

		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken While validating session is " + totaltime);
		return result;
	}
}
