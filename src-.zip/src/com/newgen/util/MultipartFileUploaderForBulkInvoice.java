/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: MultipartFileUploaderForBulkInvoice.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: created for bulk invoice document upload
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.io.File;
import java.util.List;
import org.apache.log4j.Logger;

public class MultipartFileUploaderForBulkInvoice {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	// public static String AddDocInOD(String filepath,String invno,String
	// Sessionid, String OD_IP,String WI_DocIndexId,String
	// File_DocIndexId,String VolumeIndex, String RootFolderPath,String
	// JTSIP,String JTSPORT,String CabinetName,String Filename,String DocName
	// ,String FolderName,String DataClass,String DocIndexName1,String
	// DocIndexName2) { by devi 28/11/16

	public static String AddDocInOD(String filepath, int i, int Itemsize, String invno, String Sessionid, String OD_IP,
			String WI_DocIndexId, String File_DocIndexId, String VolumeIndex, String RootFolderPath, String JTSIP,
			String JTSPORT, String CabinetName, String Filename, String DocName, String FolderName, String DataClass,
			String DocIndexName1, String DocIndexName2) {

		String charset = "UTF-8";
		System.out.println("filepath before:" + filepath);
		// String[] File=filename.split("_");//, 2)[1];
		// String Filename1=File[File.length-1];
		// System.out.println("Filename:"+Filename1);
		// File uploadFile1 = new File(filename);
		File uploadFile1 = new File(filepath);
		String requestURL = "http://" + OD_IP + "/omnidocs/servlet/addBlkDocument?inputype=xml";
		logger.debug("requestURL  ::::  " + requestURL);

		String dataclass = "<DocDataDefinition><DataClassDoc>" + DataClass + "</DataClassDoc><DocField><DocIndexName>"
				+ DocIndexName1 + "</DocIndexName><DocIndexId>" + WI_DocIndexId + "</DocIndexId><DocIndexValue>" + invno
				+ "</DocIndexValue>" + "<DocIndexType>I</DocIndexType></DocField><DocField><DocIndexName>"
				+ DocIndexName2 + "</DocIndexName><DocIndexId>" + File_DocIndexId + "</DocIndexId><DocIndexValue>"
				+ Filename + "</DocIndexValue>" + "<DocIndexType>I</DocIndexType></DocField></DocDataDefinition>";
		// logger.debug( "dataclass :::: "+dataclass );
		try {
			MultipartUtility multipart = new MultipartUtility(requestURL, charset);

			// multipart.addHeaderField("User-Agent", "CodeJava");
			// multipart.addHeaderField("Test-Header", "Header-Value");

			multipart.addFormField("FolderName", FolderName);
			logger.debug("FolderName  ::::  " + FolderName);
			multipart.addFormField("VolumeIndex", VolumeIndex);
			logger.debug("VolumeIndex  ::::  " + VolumeIndex);
			multipart.addFormField("RootFolderPath", RootFolderPath);
			logger.debug("RootFolderPath  ::::  " + RootFolderPath);
			multipart.addFormField("jtsIpAddress", JTSIP);
			logger.debug("JTSIP  ::::  " + JTSIP);
			multipart.addFormField("jtsPort", JTSPORT);
			logger.debug("JTSPORT  ::::  " + JTSPORT);
			multipart.addFormField("CabinetName", CabinetName);
			logger.debug("CabinetName  ::::  " + CabinetName);
			multipart.addFormField("UserDBId", Sessionid);
			logger.debug("Sessionid  ::::  " + Sessionid);
			multipart.addFormField("DocumentName", DocName);
			logger.debug("DocumentName  ::::  " + DocName);
			multipart.addFormField("DocumentDataDefList", dataclass);
			logger.debug("dataclass  ::::  " + dataclass);
			multipart.addFilePart("fileUpload", uploadFile1);
			logger.debug("uploadFile1  ::::  " + uploadFile1);
			// multipart.addFilePart("fileUpload", uploadFile2);
			logger.debug("Itemsss  ::::  " + i);
			logger.debug("Itemsize---->  ::::  " + Itemsize);

			List<String> response = multipart.finish();

			System.out.println("SERVER REPLIED:");
			System.out.println("SERVER REPLIED:" + response.toString());
			String result = "";

			for (String line : response) {
				System.out.println(line + "===" + line.indexOf("DocumentIndex"));
				if ((line.contains("DocumentIndex") && (i == 0 && Itemsize == 1)))
				// if((line.contains("DocumentIndex"))
				{
					System.out.println("Doc Added in OD!!");
					result = "Document added successfully";
					// System.out.println("line::"+line);
					// result = line.split(":")[1];
					// System.out.println("Result for successful doc
					// upload::"+result);
					// result.trim();
					logger.debug("result  ::::  " + result);
					return result;
				}

				else {
					System.out.println("Doc not Added in OD!!");
					// logger.debug("Doc not Added in OD!!");
					result = "failed";
					return result;
				}

				// return "failed";
			}
			return result;
		} catch (Exception ex) {
			System.err.println(ex);
			ex.printStackTrace();
			return "failed";
		}

	}

}
