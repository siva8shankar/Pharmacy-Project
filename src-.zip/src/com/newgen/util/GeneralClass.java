/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GeneralClass.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.util.ArrayList;
import java.util.HashMap;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.CompanyMaster;
import com.newgen.bean.DashBoardBean;
import com.newgen.bean.DashboardStatusBean;
import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.PODetails;
import com.newgen.bean.ReportsBean;
import com.newgen.bean.SAPConPODetails;
import com.newgen.bean.TCDashBoardBean;
import com.newgen.bean.TCDashboardStatusBean;
import com.newgen.bean.TCInvoiceDetails;
import com.newgen.bean.VPUserActivityTable;
import com.newgen.bean.VPUserMaster;
import com.newgen.bean.VendorBankingDetails;
import com.newgen.bean.VendorMaster;
import com.newgen.bean.VendorQueryDetails;
import com.newgen.bean.VendorQueryMaster;

public class GeneralClass {

	ArrayList<VendorQueryMaster> arrayQueryMaster;
	ArrayList<VendorQueryDetails> arrayQueryDetails;
	ArrayList<InvoiceNewDetails> arrayInvoiceMaster;
	ArrayList<InvoiceDetails> arrayInvoiceDetails;
	ArrayList<ReportsBean> arrayReports;
	ArrayList<PODetails> arrayPOMaster;

	ArrayList<AppliedUser> arrayAppliedUser;
	ArrayList<VPUserMaster> arrayRegisteredUser;
	ArrayList<VendorMaster> arrayVendorList;
	ArrayList<CompanyMaster> arrayCompanyList;
	ArrayList<VPUserActivityTable> arrayUserActivity;
	ArrayList<DashBoardBean> arrayDashBoardBean;
	ArrayList<DashboardStatusBean> arrayDashboardStatusBean;
	ArrayList<TCDashBoardBean> arrayTCDashBoardBean;
	ArrayList<TCDashboardStatusBean> arrayTCDashboardStatusBean;
	ArrayList<SAPConPODetails> sapconpodetails;
	ArrayList<TCInvoiceDetails> arrayTCInvoiceDetails;

	String queryLockedStatus;
	String lastRecordFlag;
	String prevRecordFlag;
	String paginationTopQryNo;
	String paginationLastQryNo;
	String linkType;
	HashMap<String, InvoiceNewDetails> map;
	HashMap<String, PODetails> map1;
	HashMap<String, VendorBankingDetails> bankdetailmap;

	int resultCode;
	String queryNumber;
	int batchSize;
	String dbConfig;
	String Priviledge;
	String VendorCode;
	String[] arrStatus;
	String[] arrayDocumentIDs;
	int sessionresult;

	public ArrayList<ReportsBean> getArrayReports() {
		return arrayReports;
	}

	public void setArrayReports(ArrayList<ReportsBean> arrayReports) {
		this.arrayReports = arrayReports;
	}

	public int getSessionresult() {
		return sessionresult;
	}

	public void setSessionresult(int sessionresult) {
		this.sessionresult = sessionresult;
	}

	public ArrayList<PODetails> getArrayPOMaster() {
		return arrayPOMaster;
	}

	public void setArrayPOMaster(ArrayList<PODetails> arrayPOMaster) {
		this.arrayPOMaster = arrayPOMaster;
	}

	public String[] getArrStatus() {
		return arrStatus;
	}

	public void setArrStatus(String[] arrStatus) {
		this.arrStatus = arrStatus;
	}

	public String[] getArrayDocumentIDs() {
		return arrayDocumentIDs;
	}

	public void setArrayDocumentIDs(String[] arrayDocumentIDs) {
		this.arrayDocumentIDs = arrayDocumentIDs;
	}

	public void setArrayInvoiceDetails(ArrayList<InvoiceDetails> arrayInvoiceDetails) {
		this.arrayInvoiceDetails = arrayInvoiceDetails;
	}

	public ArrayList<InvoiceNewDetails> getArrayInvoiceMaster() {
		return arrayInvoiceMaster;
	}

	public void setArrayInvoiceMaster(ArrayList<InvoiceNewDetails> arrayInvoiceMaster) {
		this.arrayInvoiceMaster = arrayInvoiceMaster;
	}

	public ArrayList<InvoiceDetails> getArrayInvoiceDetails() {
		return arrayInvoiceDetails;
	}

	public String getVendorCode() {
		return VendorCode;
	}

	public void setVendorCode(String pVendorCode) {
		VendorCode = pVendorCode;
	}

	public String getPriviledge() {
		return Priviledge;
	}

	public void setPriviledge(String pPriviledge) {
		Priviledge = pPriviledge;
	}

	public ArrayList<VPUserActivityTable> getArrayUserActivity() {
		return arrayUserActivity;
	}

	public void setArrayUserActivity(ArrayList<VPUserActivityTable> arrayUserActivity) {
		this.arrayUserActivity = arrayUserActivity;
	}

	public ArrayList<CompanyMaster> getArrayCompanyList() {
		return arrayCompanyList;
	}

	public void setArrayCompanyList(ArrayList<CompanyMaster> arrayCompanyList) {
		this.arrayCompanyList = arrayCompanyList;
	}

	public ArrayList<VendorMaster> getArrayVendorList() {
		return arrayVendorList;
	}

	public void setArrayVendorList(ArrayList<VendorMaster> arrayVendorList) {
		this.arrayVendorList = arrayVendorList;
	}

	public ArrayList<AppliedUser> getArrayAppliedUser() {
		return arrayAppliedUser;
	}

	public void setArrayAppliedUser(ArrayList<AppliedUser> arrayAppliedUser) {
		this.arrayAppliedUser = arrayAppliedUser;
	}

	public ArrayList<VPUserMaster> getArrayRegisteredUser() {
		return arrayRegisteredUser;
	}

	public void setArrayRegisteredUser(ArrayList<VPUserMaster> arrayRegisteredUser) {
		this.arrayRegisteredUser = arrayRegisteredUser;
	}

	public String getDbConfig() {
		return dbConfig;
	}

	public void setDbConfig(String dbConfig) {
		this.dbConfig = dbConfig;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public String getQueryNumber() {
		return queryNumber;
	}

	public void setQueryNumber(String queryNumber) {
		this.queryNumber = queryNumber;
	}

	public ArrayList<VendorQueryDetails> getArrayQueryDetails() {
		return arrayQueryDetails;
	}

	public void setArrayQueryDetails(ArrayList<VendorQueryDetails> arrayQueryDetails) {
		this.arrayQueryDetails = arrayQueryDetails;
	}

	public int getResultCode() {
		return resultCode;
	}

	public HashMap<String, InvoiceNewDetails> getMap() {
		return map;
	}

	public void setMap(HashMap<String, InvoiceNewDetails> map) {
		this.map = map;
	}

	public HashMap<String, VendorBankingDetails> getBankdetailmap() {
		return bankdetailmap;
	}

	public void setBankdetailmap(HashMap<String, VendorBankingDetails> bankdetailmap) {
		this.bankdetailmap = bankdetailmap;
	}

	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}

	public String getLinkType() {
		return linkType;
	}

	public void setLinkType(String linkType) {
		this.linkType = linkType;
	}

	public ArrayList<VendorQueryMaster> getArrayQueryMaster() {
		return arrayQueryMaster;
	}

	public void setArrayQueryMaster(ArrayList<VendorQueryMaster> arrayQueryMaster) {
		this.arrayQueryMaster = arrayQueryMaster;
	}

	public String getLastRecordFlag() {
		return lastRecordFlag;
	}

	public void setLastRecordFlag(String lastRecordFlag) {
		this.lastRecordFlag = lastRecordFlag;
	}

	public String getPrevRecordFlag() {
		return prevRecordFlag;
	}

	public void setPrevRecordFlag(String prevRecordFlag) {
		this.prevRecordFlag = prevRecordFlag;
	}

	public String getPaginationTopQryNo() {
		return paginationTopQryNo;
	}

	public void setPaginationTopQryNo(String paginationTopQryNo) {
		this.paginationTopQryNo = paginationTopQryNo;
	}

	public String getPaginationLastQryNo() {
		return paginationLastQryNo;
	}

	public void setPaginationLastQryNo(String paginationLastQryNo) {
		this.paginationLastQryNo = paginationLastQryNo;
	}

	public HashMap<String, PODetails> getMap1() {
		return map1;
	}

	public void setMap1(HashMap<String, PODetails> map1) {
		this.map1 = map1;
	}

	public ArrayList<DashBoardBean> getArrayDashBoardBean() {
		return arrayDashBoardBean;
	}

	public void setArrayDashBoardBean(ArrayList<DashBoardBean> arrayDashBoardBean) {
		this.arrayDashBoardBean = arrayDashBoardBean;
	}

	public ArrayList<DashboardStatusBean> getArrayDashboardStatusBean() {
		return arrayDashboardStatusBean;
	}

	public void setArrayDashboardStatusBean(ArrayList<DashboardStatusBean> arrayDashboardStatusBean) {
		this.arrayDashboardStatusBean = arrayDashboardStatusBean;
	}

	public ArrayList<SAPConPODetails> getSapconpodetails() {
		return sapconpodetails;
	}

	public void setSapconpodetails(ArrayList<SAPConPODetails> sapconpodetails) {
		this.sapconpodetails = sapconpodetails;
	}

	public String getQueryLockedStatus() {
		return queryLockedStatus;
	}

	public void setQueryLockedStatus(String queryLockedStatus) {
		this.queryLockedStatus = queryLockedStatus;
	}

	public ArrayList<TCDashBoardBean> getArrayTCDashBoardBean() {
		return arrayTCDashBoardBean;
	}

	public void setArrayTCDashBoardBean(ArrayList<TCDashBoardBean> arrayTCDashBoardBean) {
		this.arrayTCDashBoardBean = arrayTCDashBoardBean;
	}

	public ArrayList<TCDashboardStatusBean> getArrayTCDashboardStatusBean() {
		return arrayTCDashboardStatusBean;
	}

	public void setArrayTCDashboardStatusBean(ArrayList<TCDashboardStatusBean> arrayTCDashboardStatusBean) {
		this.arrayTCDashboardStatusBean = arrayTCDashboardStatusBean;
	}

	public ArrayList<TCInvoiceDetails> getArrayTCInvoiceDetails() {
		return arrayTCInvoiceDetails;
	}

	public void setArrayTCInvoiceDetails(ArrayList<TCInvoiceDetails> arrayTCInvoiceDetails) {
		this.arrayTCInvoiceDetails = arrayTCInvoiceDetails;
	}
	

}
