/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: PdfCreator.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import com.lowagie.text.DocumentException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.xhtmlrenderer.pdf.ITextRenderer;
import org.xml.sax.InputSource;

public class PdfCreator {

	public static final Logger logger = Logger.getLogger(PdfCreator.class.getName());
	private String cabinetName;
	private String sOutDocName;
	private FileHandler logFileHander;
	private Map<String, String> templatePath = new HashMap<String, String>();
	private Map<String, String> tablesAndPk = new HashMap<String, String>();
	private DataSource dataSource;
	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	public File GeneratePDF(String pk, String sTempType) {
		initLogger(pk);
		try {
			initSettings();
		} catch (Exception ex) {
			Logger.getLogger(PdfCreator.class.getName()).log(Level.SEVERE, null, ex);
			return null;
		}

		try {
			String templateLoc = getTemplatePath(sTempType);
			logger.info("Template Path : " + templateLoc);
			System.out.println("Template Path : " + templateLoc);
			if (templateLoc == null) {
				logger.log(Level.SEVERE,
						"Template path to for '" + sTempType + "' type is not mapped in pdf_creator/templates.ini");
				return null;
			}
			File templateFile = new File(templateLoc);
			if (!templateFile.exists()) {
				logger.log(Level.SEVERE, "Template file '" + templateLoc + "' not found");
				return null;
			}
			if (!templateFile.canRead()) {
				logger.log(Level.SEVERE, "Template file '" + templateLoc + "' is found but it is not readable. "
						+ "Please check the file permission.");
				return null;
			}
			System.out.println("sOutDocName ===> " + sOutDocName);
			File generatedPDF = File.createTempFile(sOutDocName, ".pdf");
			org.w3c.dom.Document filledTemplate;
			try {
				filledTemplate = createFilledTemplate(templateFile, pk);
				System.out.println("createFilledTemplate  === finished......");
			} catch (Exception e) {
				logger.log(Level.SEVERE, "Unable to create filled template : ", e);
				return null;
			}
			String imageLocation = "file:///" + new File(templateFile.getAbsolutePath()).getParent() + "\\";
			logger.info("Image location : " + imageLocation);
			System.out.println("Image location : " + imageLocation);
			createPDF(filledTemplate, imageLocation, generatedPDF);
			return generatedPDF;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Unpredicted exception.", e);
			return null;
		} finally {
			logFileHander.close();
		}
	}

	private String getTemplatePath(String parameterType) {
		System.out.println("inside get template path -----> ");
		return templatePath.get(parameterType);
	}

	private org.w3c.dom.Document createFilledTemplate(File templateFile, String pk)
			throws FileNotFoundException, IOException, Exception {

		String data = ReadTemplate(templateFile);
		Matcher[] matchers = new Matcher[3];
		Pattern pattern1 = Pattern.compile("--!(.+?)!--");
		Matcher matcher1 = pattern1.matcher(data);
		Pattern pattern2 = Pattern.compile("==!(.+?)!==");
		Matcher matcher2 = pattern2.matcher(data);
		Pattern pattern3 = Pattern.compile("--$(.+?)$--");
		Matcher matcher3 = pattern3.matcher(data);
		matchers[0] = matcher1;
		matchers[1] = matcher2;
		matchers[2] = matcher3;
		Map<String, List<String>> tablesAndColumnsToFetch = new HashMap<String, List<String>>();

		for (Matcher matcher : matchers) {
			logger.info("Indentified fields in template. ");
			StringBuilder builder = new StringBuilder();
			while (matcher.find()) {
				String group = matcher.group(1);
				String[] split = group.split("\\.");
				if (split.length == 2) {
					builder.append(group).append("\n");
					if (tablesAndColumnsToFetch.containsKey(split[0])) {
						if (!tablesAndColumnsToFetch.get(split[0]).contains(split[1])) {
							tablesAndColumnsToFetch.get(split[0]).add(split[1]);
						}
					} else {
						List<String> columns = new LinkedList<String>();
						columns.add(split[1]);
						tablesAndColumnsToFetch.put(split[0], columns);
					}
				} else {
					builder.append("Skipping the field : ").append(group);
					builder.append(" as it is not in format <tablename>." + "<columnname>\n");
					builder.append("Note : there should be no '.' " + "(dot) in the tablename or columnname")
							.append("\n");
				}
			}
		}

		Map<String, Object> fetchedResults = getDataFromDB(tablesAndColumnsToFetch, pk);
		for (Map.Entry<String, Object> entry : fetchedResults.entrySet()) {
			System.out.println("inside for loop .....");
			Date date = new Date();
			if ((entry.getValue()) != null) {
				data = data.replace("--!" + entry.getKey() + "!--",
						"<![CDATA[" + formatContent(entry.getValue()) + "]]>");
			} else {
				data = data.replace("--!" + entry.getKey() + "!--", "<![CDATA[" + entry.getKey() + "]]>");
			}
		}

		// Added By G Girivasu for dynamic invoice generation on 17-Aug-2017
		Map<String, Object> fetchedResults1 = getDataFromDB1(pk);

		for (Map.Entry<String, Object> entry : fetchedResults1.entrySet()) {
			System.out.println("inside for loop .....");
			Date date = new Date();
			if ((entry.getValue()) != null) {
				String html = formatContent(entry.getValue());
				data = data.replace("--$VPPODetails.Temhtml$--", html);
			}
		}
		DocumentBuilder docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		org.w3c.dom.Document doc = docBuilder.parse(new InputSource(new StringReader(data)));
		return doc;
	}

	private String ReadTemplate(File templateFile) throws FileNotFoundException {
		System.out.println("ReadTemplate");
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(templateFile)));
		String line;
		StringBuilder builder = new StringBuilder();
		try {
			while ((line = br.readLine()) != null) {
				builder.append(line);
				builder.append("\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return builder.toString();
	}

	private Map<String, Object> getDataFromDB(Map<String, List<String>> tablesAndColumnsToFetch, String pk)
			throws Exception {
		System.out.println("inside getDataFromDB " + pk);
		for (Map.Entry<String, List<String>> key : tablesAndColumnsToFetch.entrySet()) {
			System.out.println("Key is ==== " + key.getKey() + " value is === " + key.getValue());
		}
		System.out.println("map list finished........");
		Map<String, Object> fetchedResults = new HashMap<String, Object>();
		Connection conn = null;

		try {
			conn = dataSource.getConnection();
			System.out.println("conn == " + conn);
			for (Map.Entry<String, List<String>> entry : tablesAndColumnsToFetch.entrySet()) {
				System.out.println("inside map");
				String tableName = tablesAndPk.get("VPPODetailsTable");
				System.out.println("tableName == " + tableName);
				String primaryColumn = tablesAndPk.get("VPPODetailsCon");
				System.out.println("primaryColumn from tables ini-->" + primaryColumn);
				if (primaryColumn == null) {
					throw new Exception("Primary Column for table :" + tableName + " is not mapped correctly in "
							+ "pdf_creator/tables.ini file");
				}
				List<String> columnsToFetch = entry.getValue();
				int columnCount = columnsToFetch.size();
				StringBuilder sql = new StringBuilder();
				sql.append("Select ");
				for (String column : columnsToFetch) {
					sql.append(column);
					sql.append(",");
				}
				sql.deleteCharAt(sql.length() - 1);
				sql.append(" from ");
				sql.append(tableName);
				sql.append(" where ");
				sql.append(primaryColumn);
				sql.append("=?");
				PreparedStatement ps = conn.prepareStatement(sql.toString());
				ps.setObject(1, pk);
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					for (int i = 0; i < columnCount; i++) {
						fetchedResults.put(tableName + "." + columnsToFetch.get(i), rs.getObject(i + 1));
					}
					StringBuilder builder = new StringBuilder();
					builder.append("\nValues Fetched from database.\n");
					builder.append("The format of below output is <tablename>." + "<columnname> = <value> \n");
					for (Map.Entry<String, Object> t : fetchedResults.entrySet()) {
						System.out.println("inside fetchedResults ============ ");
						builder.append(t.getKey()).append(" = ").append(t.getValue()).append("\n");
					}
					logger.info(builder.toString());
				} else {
					logger.info("SQL returns zero rows");
				}
			}
		} catch (Exception ex) {
			logger.log(Level.SEVERE, "Error in fetching data from database", ex);
			if (conn != null) {
				conn.close();
			}
			throw ex;
		}
		if (conn != null) {
			conn.close();
		}
		return fetchedResults;
	}

	// Added By G Girivasu for dynamic invoice generation on 17-Aug-2017
	private Map<String, Object> getDataFromDB1(String pk) throws Exception {
		System.out.println("inside getDataFromDB1 " + pk);

		System.out.println("map list finished........");
		Map<String, Object> fetchedResults = new HashMap<String, Object>();
		Connection conn = null;

		try {
			conn = dataSource.getConnection();
			System.out.println("conn == " + conn);
			String table = tablesAndPk.get("VPPOLineItemsTable");
			String columns = tablesAndPk.get("VPPOLineItemsCol");
			String condition = tablesAndPk.get("VPPOLineItemsCon");

			// int columnCount=5;
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT ");
			sql.append(columns);
			sql.append(" from " + table + " where " + condition + "='" + pk + "'");
			System.out.println("Query == " + sql.toString());
			PreparedStatement ps = conn.prepareStatement(sql.toString());
			ResultSet rs = ps.executeQuery();

			int i = 1;
			float tax = 0;
			float total = 0;
			StringBuffer temhtml = new StringBuffer();
			temhtml.append(
					"<table> <thead><tr><th>S.NO</th><th>DESCRIPTION</th><th>QUANTITY</th><th>RATE</th><th>AMOUNT</th></tr></thead>");
			temhtml.append("<tbody>");
			while (rs.next()) {
				temhtml.append("<tr style=\"border-bottom:none\">");
				temhtml.append("<td class=\"sno\" rowspan=\"2\" style=\"text-align:center\">" + i + "</td>");
				temhtml.append(
						"<td class=\"desc\" style=\"border-bottom: 1px solid ;\">" + rs.getString("Descr") + "</td>");
				temhtml.append("<td class=\"qty\"  style=\"text-align:center;border-bottom: 1px solid ;\">"
						+ rs.getFloat("Quantity") + "</td>");
				temhtml.append("<td class=\"qty\"  style=\"text-align:center;border-bottom: 1px ;\"	>"
						+ rs.getFloat("GrossAmt") + "</td>");
				temhtml.append(" <td class=\"qty\" style=\"border-bottom: 1px solid ;\">" + rs.getFloat("NetAm")
						+ "</td></tr><tr></tr>");
				tax = rs.getFloat("Tax");
				total = rs.getFloat("NetAmount");
				i = i + 1;
			}
			temhtml.append("<tr><td class=\"desc\">GST (" + tax + "%)</td>");
			temhtml.append("<td class=\"qty\"  style=\"text-align:center\">-</td>");
			temhtml.append("<td class=\"qty\">" + tax + "</td><td class=\"qty\">-</td></tr>");
			temhtml.append(
					"<tr><td class=\"qty\" colspan=\"5\"><b><span style=\"font-size:16px\">Total </span>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</b>&#160;&#160;<b>"
							+ total + "</b></td>");
			temhtml.append("</tr></tbody></table>");

			String temhtml1 = temhtml.toString();
			fetchedResults.put("VPPODetails.Temhtml", temhtml1);

		} catch (Exception ex) {
			logger.log(Level.SEVERE, "Error in fetching data from database", ex);
			if (conn != null) {
				conn.close();
			}
			throw ex;
		}
		if (conn != null) {
			conn.close();
		}
		return fetchedResults;
	}
	// End 17-Aug-2017

	private boolean createPDF(org.w3c.dom.Document filledTemplate, String baseURL, File generatedPDF)
			throws FileNotFoundException, IOException, DocumentException {
		System.out.println("Image location1 : " + baseURL);
		OutputStream os = new FileOutputStream(generatedPDF);
		System.out.println("Image location2 : " + baseURL);
		ITextRenderer renderer = new ITextRenderer();
		System.out.println("Image location 3: " + baseURL);
		renderer.setDocument(filledTemplate, baseURL);
		System.out.println("Image location 4: " + baseURL);
		renderer.layout();
		System.out.println("Image location 5: " + baseURL);
		renderer.createPDF(os);
		System.out.println("Image location 6: " + baseURL);
		os.close();

		return true;
	}

	private String formatContent(Object data) {
		if (data == null) {
			return "";
		}
		String returnData;
		if (data instanceof java.sql.Date) {
			returnData = new SimpleDateFormat("dd/MMM/yyyy").format((java.sql.Date) data);
		} else if (data instanceof java.util.Date) {
			returnData = new SimpleDateFormat("dd/MMM/yyyy").format((java.util.Date) data);
		} else if (data instanceof java.sql.Timestamp) {
			returnData = new SimpleDateFormat("dd/MMM/yyyy").format((java.sql.Timestamp) data);
		} else {
			returnData = data.toString();
		}
		return returnData.toString().replaceAll("]]>", "]] >");
	}

	private void initSettings() throws Exception {
		try {
			init();
		} catch (FileNotFoundException fnfe) {
			logger.log(Level.SEVERE, "Settings file not found.", fnfe);
			throw fnfe;
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Settings file found but " + "unable to read it. Check the file permission", e);
			throw e;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Unexpected error", e);
			throw e;
		}
		try {
			InitialContext context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:/" + cabinetName);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error in connecting to datasource.\n" + "Current Cabinet Configuration is : "
					+ cabinetName + "\n" + "if it wrong, change it in pdf_creator/" + "connection.ini", e);
			throw e;
		}
		// dataSource = new TestDataSource();
	}

	private void init() throws FileNotFoundException, IOException, Exception {

		String STemplatePath = System.getProperty("user.dir") + File.separator + "WebServiceConsume.ini";
		File file = new File(STemplatePath);
		Properties property = new Properties();
		property.load(new FileInputStream(file));
		templatePath.put("Invoice", property.getProperty("Invoice"));
		cabinetName = property.getProperty("cabinetpt");

		if (cabinetName == null) {
			throw new Exception("cabinet value is not specified in : " + file.getAbsolutePath());
		}
		sOutDocName = property.getProperty("OutDocName");

		if (sOutDocName == null) {
			throw new Exception("Output Document Name is not specified in : " + file.getAbsolutePath());
		}
		// Table name, Columns and condition from ini file
		tablesAndPk.put("VPPODetailsTable", property.getProperty("VPPODetailsTable"));
		tablesAndPk.put("VPPODetailsCon", property.getProperty("VPPODetailsCon"));
		tablesAndPk.put("VPPOLineItemsTable", property.getProperty("VPPOLineItemsTable"));
		tablesAndPk.put("VPPOLineItemsCol", property.getProperty("VPPOLineItemsCol"));
		tablesAndPk.put("VPPOLineItemsCon", property.getProperty("VPPOLineItemsCon"));
	}

	private void initLogger(String pk) {
		Calendar calender = Calendar.getInstance();
		calender.setTimeInMillis(System.currentTimeMillis());

		try {
			String logFolder = "pdf_creator_log/" + calender.get(Calendar.YEAR) + "/"
					+ (calender.get(Calendar.MONTH) + 1) + "/" + calender.get(Calendar.DAY_OF_MONTH) + "/";
			File file = new File(logFolder);
			file.mkdirs();
			boolean append = true;
			FileHandler fh = new FileHandler(logFolder + "/" + pk + ".log", append);

			fh.setFormatter(new SimpleFormatter());
			logFileHander = fh;
			Logger.getLogger("com.newgen.CLAS.pdfCreator").addHandler(fh);
			Logger.getLogger("com.newgen.CLAS").setUseParentHandlers(false);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
