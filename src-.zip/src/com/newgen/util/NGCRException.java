/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: NGCRException.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

public class NGCRException extends Exception {
	public static final int CRYPTOGRAPHIC_ERROR = -8000;
	public static final int BAD_ALGORITHM = -8001;
	public static final int BAD_KEY = -8002;
	public static final int BAD_KEY_DATA = -8002;
	public static final int UNRECOVERABLE_KEY = -8003;
	public static final int BAD_STORE = -8004;
	public static final int BAD_SIGNATURE = -8005;
	public static final int BAD_PROVIDER = -8006;
	public static final int BAD_CERTIFICATE = -8007;
	public static final int BAD_CRL = -8008;
	private int m_iException;

	public NGCRException() {
	}

	public NGCRException(int exception) {
		this.m_iException = exception;
	}

	public void setException(int exception) {
		this.m_iException = exception;
	}

	public int getException() {
		return this.m_iException;
	}
}
