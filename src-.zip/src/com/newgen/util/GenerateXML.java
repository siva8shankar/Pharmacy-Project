/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GenerateXML.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Class is used to Generate XML
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

public class GenerateXML {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static Logger loggerXml = Logger.getLogger("xmlLogger");

	// wfinitiate xml
	@SuppressWarnings("rawtypes")
	public static String wfinitiatexml(HashMap xmlvalues, String sessionid) {
		String inputXML = "";
		StringBuilder sb = new StringBuilder();
		try {
			logger.debug("wfinitiatexml method starts...");

			sb.append(
					"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:app=\"http://app.omni.newgen.com\" xmlns:xsd=\"http://data.omni.newgen.com/xsd\">");
			sb.append("<soapenv:Header/>");
			sb.append("<soapenv:Body>");
			sb.append("<app:wfInitiate>");
			sb.append("<app:request>");
			Iterator it = xmlvalues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry valuepair = (Map.Entry) it.next();
				sb.append("<xsd:attributes><xsd:name>" + valuepair.getKey() + "</xsd:name><xsd:value>");
				sb.append(valuepair.getValue() == null ? "" : valuepair.getValue());
				sb.append("</xsd:value></xsd:attributes>");
			}
			sb.append("<xsd:engineName>garelease</xsd:engineName>");
			sb.append("<xsd:initiateFromActivityId>1</xsd:initiateFromActivityId>");
			sb.append("<xsd:initiateFromActivityName>Introduction</xsd:initiateFromActivityName>");
			sb.append("<xsd:processDefId>21</xsd:processDefId>");
			sb.append("<xsd:processName>ApProcess</xsd:processName>");
			sb.append("<xsd:sessionId>" + sessionid + "</xsd:sessionId>");
			sb.append("</app:request>");
			sb.append("</app:wfInitiate>");
			sb.append("</soapenv:Body>");
			sb.append("</soapenv:Envelope>");
			inputXML = sb.toString();
			loggerXml.debug("inputXML : " + inputXML);
		} catch (Exception e) {
			loggerErr.error("Exception in wfinitiatexml:" + e.getMessage());
			e.printStackTrace();
		}
		return inputXML;
	}

	public static String wfUploadXML(HashMap xmlvalues, String userName, String password) {
		String inputXML = "";
		StringBuilder sb = new StringBuilder();
		try {
			logger.debug("wfUploadxml method starts...");

			sb.append(
					"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:app=\"http://app.omni.newgen.com\" xmlns:xsd=\"http://data.omni.newgen.com/xsd\">");
			sb.append("<soapenv:Header/>");
			sb.append("<soapenv:Body>");
			sb.append("<app:wfUploadWorkitem>");
			// sb.append("<app:param0>");
			sb.append("<app:arg0>");
			sb.append("<xsd:password>" + password + "</xsd:password>");
			sb.append("<xsd:userName>" + userName + "</xsd:userName>");

			Iterator it = xmlvalues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry valuepair = (Map.Entry) it.next();
				sb.append("<xsd:" + valuepair.getKey() + ">");
				sb.append(valuepair.getValue() == null ? "" : valuepair.getValue());
				sb.append("</xsd:" + valuepair.getKey() + ">");
			}
			// Till here

			// sb.append("<xsd:userName>"+userName+"</xsd:userName>");
			/*
			 * sb.append("<xsd:engineName>garelease</xsd:engineName>");
			 * sb.append(
			 * "<xsd:initiateFromActivityId>1</xsd:initiateFromActivityId>");
			 * sb.append(
			 * "<xsd:initiateFromActivityName>Introduction</xsd:initiateFromActivityName>"
			 * ); sb.append("<xsd:processDefId>21</xsd:processDefId>");
			 * sb.append("<xsd:processName>ApProcess</xsd:processName>");
			 * sb.append("<xsd:sessionId>"+sessionid+"</xsd:sessionId>");
			 */
			// sb.append("</app:param0>");
			sb.append("</app:arg0>");
			sb.append("</app:wfUploadWorkitem>");
			sb.append("</soapenv:Body>");
			sb.append("</soapenv:Envelope>");
			inputXML = sb.toString();
			logger.debug("GeneralXML InitiationXML in code:" + inputXML);
			// String
			// str_loginputxml=inputXML.replace(inputXML.substring(inputXML.indexOf("<xsd:password>")+14,inputXML.indexOf("</xsd:password>")),
			// "");
			// loggerXml.debug("inputXML : "+str_loginputxml);
		} catch (Exception e) {
			loggerErr.error("Exception in wfuploadxml:" + e.getMessage());
			e.printStackTrace();
		}
		return inputXML;
	}

	public static String generatexml(HashMap xmlvalues, String option, String Cabinet) {
		String inputXML = "";
		StringBuilder sb = new StringBuilder();
		try {
			logger.debug("generatexml method starts...");

			sb.append(
					"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:req=\"http://ngprocedureselectq.ops.newgen.com/schema/Ngprocedureselect/request\"><soapenv:Header/><soapenv:Body><req:ProcedureselectReq><Option>"
							+ option + "</Option><Username>" + ClsMessageHandler.XMLUserName + "</Username><Password>"
							+ ClsMessageHandler.XMLPassword + "</Password><Cabinet>" + Cabinet
							+ "</Cabinet><req:CriteriaArray>");
			Iterator it = xmlvalues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry valuepair = (Map.Entry) it.next();
				sb.append("<req:Criteria><FieldName>" + valuepair.getKey() + "</FieldName><FieldValue>");
				sb.append(valuepair.getValue() == null ? "" : valuepair.getValue());
				sb.append("</FieldValue></req:Criteria>");
			}

			sb.append(
					"</req:CriteriaArray><nextSeedValue>?</nextSeedValue></req:ProcedureselectReq></soapenv:Body></soapenv:Envelope>");
			inputXML = sb.toString();
			/* System.out.println("inputXML first::"+inputXML); */
			inputXML = inputXML.replaceAll("&(?!.{2,4};)", "&amp;");
			/* System.out.println("inputXML 22::"+inputXML); */
			inputXML.replaceAll("[^\\x20-\\x7e]", "");
			/* System.out.println("inputXML 33::"+inputXML); */

		} catch (Exception e) {
			loggerErr.error("Exception in generatexml:" + e.getMessage());
			e.printStackTrace();
		}

		/*
		 * String
		 * str_loginputxml=inputXML.replace(inputXML.substring(inputXML.indexOf(
		 * "<Password>")+10,inputXML.indexOf("</Password>")), "");
		 * 
		 * str_loginputxml=str_loginputxml.replace(str_loginputxml.substring(
		 * str_loginputxml.indexOf("<Username>")+10,str_loginputxml.indexOf(
		 * "</Username>")), ""); loggerXml.debug("Inputxml:"+str_loginputxml);
		 */
		// loggerXml.debug("Inputxml:"+inputXML);
		return inputXML;
	}

	// Inputxml generator
	public static String generatexml(HashMap xmlvalues, String option) {
		String inputXML = "";
		StringBuilder sb = new StringBuilder();
		try {
			logger.debug("generatexml method starts...");

			sb.append(
					"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:req=\"http://ngprocedureselectq.ops.newgen.com/schema/Ngprocedureselect/request\"><soapenv:Header/><soapenv:Body><req:ProcedureselectReq><Option>"
							+ option + "</Option><Username>" + ClsMessageHandler.XMLUserName + "</Username><Password>"
							+ ClsMessageHandler.XMLPassword + "</Password><req:CriteriaArray>");
			Iterator it = xmlvalues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry valuepair = (Map.Entry) it.next();
				sb.append("<req:Criteria><FieldName>" + valuepair.getKey() + "</FieldName><FieldValue>");
				sb.append(valuepair.getValue() == null ? "" : valuepair.getValue());
				sb.append("</FieldValue></req:Criteria>");
			}
			sb.append(
					"</req:CriteriaArray><nextSeedValue>?</nextSeedValue></req:ProcedureselectReq></soapenv:Body></soapenv:Envelope>");
			inputXML = sb.toString();
			inputXML.replaceAll("[^\\x20-\\x7e]", "");
		} catch (Exception e) {
			loggerErr.error("Exception in generatexml:" + e.getMessage());
			e.printStackTrace();
		}

		String str_loginputxml = inputXML
				.replace(inputXML.substring(inputXML.indexOf("<Password>") + 10, inputXML.indexOf("</Password>")), "");
		// loggerXml.debug("Inputxml:"+str_loginputxml);
		return inputXML;
	}

	// Input xml generator for upload workitem with document 02/01/2017
	public static String wfInitiatewithDocumentXML(HashMap xmlvalues, ArrayList OdValues_List, String Sessionid,
			String cabinet, String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId,
			String ProcessName) {
		String inputXML = "";
		StringBuilder sb = new StringBuilder();

		ArrayList<HashMap<String, String>> OD_values_xml = new ArrayList<HashMap<String, String>>();
		OD_values_xml.addAll(OdValues_List);
		try {
			logger.debug("wfinitiatexml method starts...");

			sb.append(
					"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:app=\"http://app.omni.newgen.com\" xmlns:xsd=\"http://data.omni.newgen.com/xsd\">");
			sb.append("<soapenv:Header/>");
			sb.append("<soapenv:Body>");
			sb.append("<app:wfInitiate>");
			sb.append("<app:request>");
			// sb.append("<xsd:attributes><xsd:name>Invoiceno</xsd:name><xsd:value>12345</xsd:value></xsd:attributes>");

			Iterator iter = xmlvalues.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry valuepair = (Map.Entry) iter.next();
				String a = valuepair.getKey().toString();

				sb.append("<xsd:attributes><xsd:name>" + a + "</xsd:name><xsd:value>");
				sb.append(valuepair.getValue() == null ? "" : valuepair.getValue() + "</xsd:value></xsd:attributes>");
			}

			sb.append("<xsd:documentList>");
			System.out.println("OD_values_xml -- > " + OD_values_xml.size());

			for (int i = 0; i < OdValues_List.size(); i++) // to include support
															// document
			{
				if (i == 1) {
					sb.append("</xsd:documentList><xsd:documentList>");
				}
				HashMap<String, String> xmlvalues_odvalues = (HashMap<String, String>) OdValues_List.get(i);
				Iterator it = xmlvalues_odvalues.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry valuepair = (Map.Entry) it.next();
					String a = valuepair.getKey().toString(); // hashmap value
																// pair
					String a_value = OD_values_xml.get(i).get(a).toString(); // value
																				// pair
																				// value
					sb.append("<xsd:" + a + ">");
					// sb.append(valuepair.getValue() == null ? "" : valuepair
					// .getValue());
					sb.append(a_value == null ? "" : a_value);
					sb.append("</xsd:" + a + ">");

				}
			}
			sb.append("</xsd:documentList>");
			sb.append("<xsd:engineName>" + cabinet + "</xsd:engineName>");
			sb.append("<xsd:initiateFromActivityId>" + InitiateFromActivityId + "</xsd:initiateFromActivityId>");
			sb.append("<xsd:initiateFromActivityName>" + InitiateFromActivityName + "</xsd:initiateFromActivityName>");
			sb.append("<xsd:processDefId>" + ProcessDefId + "</xsd:processDefId>");
			sb.append("<xsd:processName>" + ProcessName + "</xsd:processName>");
			sb.append("<xsd:sessionId>" + Sessionid + "</xsd:sessionId>");
			sb.append("</app:request>");
			sb.append("</app:wfInitiate>");
			sb.append("</soapenv:Body>");
			sb.append("</soapenv:Envelope>");
			inputXML = sb.toString();
			loggerXml.debug("inputXML : " + inputXML);
		} catch (Exception e) {
			loggerErr.error("Exception in wfinitiatexml:" + e.getMessage());
			e.printStackTrace();
		} finally {
			if (OD_values_xml != null)
				OD_values_xml = null;
			sb.setLength(0);
		}

		return inputXML;
	}
}
