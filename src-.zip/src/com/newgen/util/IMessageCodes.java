/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: IMessageCodes.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

public interface IMessageCodes {

	public static String XMLRootNode = "VendorPortal";
	public static String DocumentPathNode = "Path";
	public static String DocumentTypeNode = "DocumentType";
	public static String InvoiceNumberPrefixNode = "InvoiceNumberPrefix";
	public static String InvoiceNumberLengthNode = "InvoiceNumberLength";
	public static String InvoiceStatusTypesNode = "InvoiceStatusTypes";
	public static String QueryNumberPrefixNode = "QueryNumberPrefix";
	public static String QueryNumberLengthNode = "QueryNumberLength";
	public static String QueryStatusTypesNode = "QueryStatusTypes";
	public static String BatchSizeInvoiceSearchNode = "InvoiceSearch";
	public static String BatchSizeQuerySearchNode = "QuerySearch";
	public static String BatchSizeMyInvoiceNode = "MyInvoice";
	public static String BatchSizeMyPONode = "MyPO";

	public static String BatchSizeMyQueryNode = "MyQuery";
	public static String BarCodeFontSizeNode = "FontSize";
	public static String BarCodeSymbologyNode = "Symbology";
	public static String BarCodeDpiNode = "Dpi";
	public static String BarCodeGeneratedFileNameNode = "GeneratedFileName";
	public static String BarCodeGeneratedFileExtNode = "FileExt";
	public static String MainWelcomeNoteNode = "WelcomeNote";
	public static String MainDateFormatNode = "DateFormat";
	public static String XMLDateFormatNode = "XMLDateFormat";
	public static String CalendarDateFormatNode = "CalendarDateFormat";
	public static String MainLoginWaitTimeNode = "LoginWaitTime";
	public static String MainEnableDebugLogNode = "EnableDebugLog";
	public static String MainEnableErrorLogNode = "EnableErrorLog";
	public static String MainDBConfigNode = "DBConfig";
	public static String SubmitInvoiceStatusNode = "SubmitInvoiceStatus";
	public static String InvoiceBillingCurrencyNode = "BillingCurrency";
	public static String InvoicePOTypeNode = "POType";
	public static String BarCodeLibraryPathNode = "LibraryPath";
	public static String BarcodeFontFamilyNode = "BarcodeFontFamily";
	public static String DocumentSizeNode = "DocumentSize";
	public static String HistoryAdministrationNode = "Administration";
	public static String HistoryVendorSearchNode = "VendorSearch";
	public static String HistoryVendorInvoiceNode = "VendorInvoice";
	public static String HistoryVendorQueryNode = "VendorQuery";
	public static String BatchSizeUserListNode = "UserList";
	public static String BatchSizeVendorListNode = "VendorList";
	public static String BatchSizeCompanyListNode = "CompanyList";
	public static String BatchSizeHistoryNode = "History";
	public static String LMPSubmitInvoiceNode = "SubmitInvoice";
	public static String LMPSubmitQueryNode = "SubmitQuery";
	public static String LMPSearchInvoiceQueryNode = "SearchInvoiceQuery";
	public static String LMPMyInvoiceNode = "MyInvoices";
	public static String LMPMyQueryNode = "MyQuerys";
	public static String TMPHomeNode = "Home";
	public static String TMPChangePasswordNode = "ChangePassword";
	public static String TMPLogOutNode = "LogOut";
	public static String MainAdminEmailIdNode = "AdminEmailId";
	public static String MainEmailUserIdNode = "EmailUserId";
	public static String MainEmailPasswordNode = "EmailPassword";
	public static String MainEmailServerNode = "EmailServer";
	public static String strMainEmailServerNode = "EmailActualIP";
	public static String EmailAuthenticationNode = "EmailAuthentication";
	public static String LMPAddNewUserNode = "AddNewUser";
	public static String LMPUserListNode = "UserListMenu";
	public static String LMPVendorListNode = "VendorListMenu";
	public static String LMPCompanyListNode = "CompanyListMenu";
	public static String LMPChangeUserPasswordNode = "ChangeUserPassword";
	public static String TMPSettingsNode = "Settings";
	public static String TMPHistoryNode = "HistoryMenu";
	public static String Portnode = "Port";
	public static String JBossPortNode = "JBossPort";
	public static String VPProtocolNode = "Protocol";

}
