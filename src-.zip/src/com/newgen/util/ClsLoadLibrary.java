/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ClsLoadLibrary.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.util;

import java.util.Vector;

import org.apache.log4j.Logger;

public class ClsLoadLibrary {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	private static java.lang.reflect.Field LIBRARIES;

	static {
		try {
			logger.debug("static block starts in ClsLoadLibrary...");

			LIBRARIES = ClassLoader.class.getDeclaredField("loadedLibraryNames");
			LIBRARIES.setAccessible(true);
		} catch (NoSuchFieldException e) {
			loggerErr.error("NoSuchFieldException in ClsLoadLibrary:" + e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			loggerErr.error("SecurityException in ClsLoadLibrary:" + e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String[] getLoadedLibraries(final ClassLoader loader) {
		Vector<String> libraries = null;
		try {
			logger.debug("getLoadedLibraries method starts...");
			libraries = (Vector<String>) LIBRARIES.get(loader);

		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			loggerErr.error("IllegalArgumentException in getLoadedLibraries:" + e.getMessage());
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			loggerErr.error("IllegalAccessException in getLoadedLibraries:" + e.getMessage());
			e.printStackTrace();
		}
		return libraries.toArray(new String[] {});
	}
}
