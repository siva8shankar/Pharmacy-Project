package com.newgen.util;

import java.util.Comparator;

import com.newgen.bean.SAPConPODetails;

public class SortArrayList implements Comparator<SAPConPODetails> {

	@Override
	public int compare(SAPConPODetails arg0, SAPConPODetails arg1) {
		// TODO Auto-generated method stub
		//if(arg0.getPONO() < arg1.getPONO()){
		if(Long.parseLong(arg0.getPONO()) < Long.parseLong(arg1.getPONO())){
            return 1;
        } else {
            return -1;
        }
	}

}
