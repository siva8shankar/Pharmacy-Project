/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: LoadMyProperties.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;

import com.newgen.bean.MyBean;
import com.newgen.util.ClsMessageHandler;

public class LoadMyProperties {
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private Properties prop = null;

	private Properties msgprop;
	HashMap<String, String> hshMap = null;

	public HashMap<String, String> getMyPropertiesFile(MyBean myBean) {
		String key = "";
		InputStream in = null;
		try {
			String lang = "en";
			hshMap = new HashMap<String, String>();

			this.prop = new Properties();
			in = this.getClass().getClassLoader().getResourceAsStream("com/newgen/resources/" + lang + ".properties");

			prop.load(in);
			Set<Object> keys = prop.keySet();
			for (Object k : keys) {
				key = (String) k;
				hshMap.put(key, this.prop.getProperty(key));
			}
			loadProperties();

		} catch (FileNotFoundException e) {
			loggerErr.error("FileNotFoundException in Load Properties  : " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			loggerErr.error("IOException in Load Properties  : " + e.getMessage());
			e.printStackTrace();
		}
		return hshMap;
	}

	private void loadProperties() {
		this.msgprop = new Properties();
		InputStream in = this.getClass().getClassLoader()
				.getResourceAsStream("com/newgen/resources/message.properties");
		try {
			msgprop.load(in);
			ClsMessageHandler.MSG001 = msgprop.getProperty("MSG001");
			ClsMessageHandler.MSG002 = msgprop.getProperty("MSG002");
			ClsMessageHandler.MSG003 = msgprop.getProperty("MSG003");
			ClsMessageHandler.MSG004 = msgprop.getProperty("MSG004");
			ClsMessageHandler.MSG005 = msgprop.getProperty("MSG005");
			ClsMessageHandler.MSG006 = msgprop.getProperty("MSG006");
			ClsMessageHandler.MSG007 = msgprop.getProperty("MSG007");
			ClsMessageHandler.MSG008 = msgprop.getProperty("MSG008");
			ClsMessageHandler.MSG009 = msgprop.getProperty("MSG009");
			ClsMessageHandler.MSG010 = msgprop.getProperty("MSG010");
			ClsMessageHandler.MSG011 = msgprop.getProperty("MSG011");
			ClsMessageHandler.MSG012 = msgprop.getProperty("MSG012");
			ClsMessageHandler.MSG013 = msgprop.getProperty("MSG013");
			ClsMessageHandler.MSG014 = msgprop.getProperty("MSG014");
			ClsMessageHandler.MSG015 = msgprop.getProperty("MSG015");
			ClsMessageHandler.MSG016 = msgprop.getProperty("MSG016");
			ClsMessageHandler.MSG017 = msgprop.getProperty("MSG017");
			ClsMessageHandler.MSG018 = msgprop.getProperty("MSG018");
			ClsMessageHandler.MSG019 = msgprop.getProperty("MSG019");
			ClsMessageHandler.MSG020 = msgprop.getProperty("MSG020");
			ClsMessageHandler.MSG021 = msgprop.getProperty("MSG021");
			ClsMessageHandler.MSG022 = msgprop.getProperty("MSG022");
			ClsMessageHandler.MSG023 = msgprop.getProperty("MSG023");
			ClsMessageHandler.MSG024 = msgprop.getProperty("MSG024");
			ClsMessageHandler.MSG025 = msgprop.getProperty("MSG025");
			ClsMessageHandler.MSG026 = msgprop.getProperty("MSG026");
			ClsMessageHandler.MSG027 = msgprop.getProperty("MSG027");
			ClsMessageHandler.MSG028 = msgprop.getProperty("MSG028");
			ClsMessageHandler.MSG029 = msgprop.getProperty("MSG029");
			ClsMessageHandler.MSG030 = msgprop.getProperty("MSG030");
			ClsMessageHandler.MSG031 = msgprop.getProperty("MSG031");
			ClsMessageHandler.MSG032 = msgprop.getProperty("MSG032");
			ClsMessageHandler.MSG033 = msgprop.getProperty("MSG033");
			ClsMessageHandler.MSG034 = msgprop.getProperty("MSG034");
			ClsMessageHandler.MSG035 = msgprop.getProperty("MSG035");
			ClsMessageHandler.MSG036 = msgprop.getProperty("MSG036");
			ClsMessageHandler.MSG037 = msgprop.getProperty("MSG037");
			ClsMessageHandler.MSG038 = msgprop.getProperty("MSG038");
			ClsMessageHandler.MSG039 = msgprop.getProperty("MSG039");
			ClsMessageHandler.MSG040 = msgprop.getProperty("MSG040");
			ClsMessageHandler.MSG041 = msgprop.getProperty("MSG041");
			ClsMessageHandler.MSG042 = msgprop.getProperty("MSG042");
			ClsMessageHandler.MSG043 = msgprop.getProperty("MSG043");
			ClsMessageHandler.MSG044 = msgprop.getProperty("MSG044");
			ClsMessageHandler.MSG045 = msgprop.getProperty("MSG045");
			ClsMessageHandler.MSG046 = msgprop.getProperty("MSG046");
			ClsMessageHandler.MSG047 = msgprop.getProperty("MSG047");
			ClsMessageHandler.MSG048 = msgprop.getProperty("MSG048");
			ClsMessageHandler.MSG049 = msgprop.getProperty("MSG049");
			ClsMessageHandler.MSG050 = msgprop.getProperty("MSG050");
			ClsMessageHandler.MSG051 = msgprop.getProperty("MSG051");
			ClsMessageHandler.MSG052 = msgprop.getProperty("MSG052");
			ClsMessageHandler.MSG053 = msgprop.getProperty("MSG053");
			ClsMessageHandler.MSG054 = msgprop.getProperty("MSG054");
			ClsMessageHandler.MSG055 = msgprop.getProperty("MSG055");
			ClsMessageHandler.MSG056 = msgprop.getProperty("MSG056");
			ClsMessageHandler.MSG057 = msgprop.getProperty("MSG057");
			ClsMessageHandler.MSG058 = msgprop.getProperty("MSG058");
			ClsMessageHandler.MSG059 = msgprop.getProperty("MSG059");
			ClsMessageHandler.MSG060 = msgprop.getProperty("MSG060");
			ClsMessageHandler.MSG061 = msgprop.getProperty("MSG061");
			ClsMessageHandler.MSG062 = msgprop.getProperty("MSG062");
			ClsMessageHandler.MSG063 = msgprop.getProperty("MSG063");
			ClsMessageHandler.MSG064 = msgprop.getProperty("MSG064");
			ClsMessageHandler.MSG065 = msgprop.getProperty("MSG065");
			ClsMessageHandler.MSG066 = msgprop.getProperty("MSG066");
			ClsMessageHandler.MSG067 = msgprop.getProperty("MSG067");
			ClsMessageHandler.MSG068 = msgprop.getProperty("MSG068");
			ClsMessageHandler.MSG069 = msgprop.getProperty("MSG069");
			ClsMessageHandler.MSG070 = msgprop.getProperty("MSG070");
			ClsMessageHandler.MSG071 = msgprop.getProperty("MSG071");
			ClsMessageHandler.MSG072 = msgprop.getProperty("MSG072");
			ClsMessageHandler.MSG073 = msgprop.getProperty("MSG073");
			ClsMessageHandler.MSG074 = msgprop.getProperty("MSG074");
			ClsMessageHandler.MSG075 = msgprop.getProperty("MSG075");
			ClsMessageHandler.MSG076 = msgprop.getProperty("MSG076");
			ClsMessageHandler.MSG077 = msgprop.getProperty("MSG077");
			ClsMessageHandler.MSG078 = msgprop.getProperty("MSG078");
			ClsMessageHandler.MSG079 = msgprop.getProperty("MSG079");
			ClsMessageHandler.MSG080 = msgprop.getProperty("MSG080");
			ClsMessageHandler.MSG081 = msgprop.getProperty("MSG081");
			ClsMessageHandler.MSG082 = msgprop.getProperty("MSG082");
			ClsMessageHandler.MSG083 = msgprop.getProperty("MSG083");
			ClsMessageHandler.MSG084 = msgprop.getProperty("MSG084");
			ClsMessageHandler.MSG085 = msgprop.getProperty("MSG085");
			ClsMessageHandler.MSG086 = msgprop.getProperty("MSG086");
			ClsMessageHandler.MSG087 = msgprop.getProperty("MSG087");
			ClsMessageHandler.MSG088 = msgprop.getProperty("MSG088");
			ClsMessageHandler.MSG089 = msgprop.getProperty("MSG089");
			ClsMessageHandler.MSG090 = msgprop.getProperty("MSG090");
			ClsMessageHandler.MSG091 = msgprop.getProperty("MSG091");
			ClsMessageHandler.MSG092 = msgprop.getProperty("MSG092");
			ClsMessageHandler.MSG093 = msgprop.getProperty("MSG093");			
			in.close();
		} catch (IOException e) {
			loggerErr.error("IOException in loadProperties of error messages  : " + e.getMessage());
			e.printStackTrace();
		}

	}

}
