/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminNewUserDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserMaster;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsSendEmail;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class AdminNewUserDAO implements AdminNewUserDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to add User.
	 * 
	 * @param VPUserMaster
	 *            userMaster
	 * @return int result
	 * @exception Exception
	 */
	@Override
	public int addNewUser(VPUserMaster userMaster, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.info("addNewUser Method Starts...");

		String SOAP_inxml = "";
		int result = 0;
		String option = "";
		HashMap<String, String> xmlvalues = null;
		int tempPassword = 0;
		Random randomGenerator = new Random();
		int activationCode = 0;
		SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.MainDateFormat);

		try {

			Date date = new Date();
			Timestamp timeStamp = new Timestamp(date.getTime());

			activationCode = randomGenerator.nextInt((999999999) + 1);

			tempPassword = randomGenerator.nextInt((9999999) + 1);

			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			String strAccExpiryTime = userMaster.getExpiryDateTime();
			String AccExpTimeFormat = "";

			if (!ClsUtil.isNullOrEmpty(strAccExpiryTime)) {
				try {

					Date invdate = sdf.parse(strAccExpiryTime);
					AccExpTimeFormat = dateFormat.format(invdate);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			logger.debug("AdminNewUserDAO AccExpTimeFormat--->" + AccExpTimeFormat);

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", userMaster.getUserName());
			xmlvalues.put("tempPassword", String.valueOf(tempPassword));
			xmlvalues.put("UserEmailId", userMaster.getUserEmailId());
			xmlvalues.put("UserPhoneNumber", userMaster.getUserPhoneNumber());
			xmlvalues.put("UserAddress", ClsUtil.replaceString(userMaster.getUserAddress()));
			xmlvalues.put("VendorCode", userMaster.getVendorCode());
			xmlvalues.put("VendorName", userMaster.getVendorName());
			xmlvalues.put("VendorAddress", ClsUtil.replaceString(userMaster.getVendorAddress()));
			xmlvalues.put("timeStamp", timeStamp.toString());
			xmlvalues.put("expiryDate", AccExpTimeFormat);
			xmlvalues.put("Privilege", userMaster.getPrivilege());
			xmlvalues.put("UserType", userMaster.getUserType());
			xmlvalues.put("activationCode", String.valueOf(activationCode));
			xmlvalues.put("FirstName", ClsUtil.replaceString(userMaster.getFirstName()));
			xmlvalues.put("LastName", ClsUtil.replaceString(userMaster.getLastName()));

			option = "ProcedureSelectAddUsr";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			ArrayList<String> outptXMLlst = null;
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (outptXMLlst.get(0).equalsIgnoreCase("UserAdded")) {
				userMaster.setActivationCode(activationCode + "");
				userMaster.setPassword(tempPassword + "");
				try {
					// Send Email to User
					ClsSendEmail.sendEmail(userMaster, "Activate");
					logger.info("User Added Successfully...");
					result = 1;
				} catch (Exception e) {
					loggerErr.error("Exception Occurred while Approve/Reject send email : " + e.getMessage());
					e.printStackTrace();
					result = -2;
				}

			} else if (outptXMLlst.get(0).equalsIgnoreCase("DuplicateUser")) {
				result = -1;
				logger.info("User Not Added Successfully...");
			}
		} catch (Exception e) {
			loggerErr.error("Exception While Adding New User By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.info("Total Time Taken in adding new user by admin is: " + totaltime);

		return result;
	}

	/**
	 * This Method is used to delete User.
	 * 
	 * @param String[]
	 *            userName
	 * @return int result
	 * @exception Exception
	 */
	@Override
	public int deleteUser(String[] userName, String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.info("deleteUser Method Starts...");

		String SOAP_inxml = "";
		int result = 0;
		HashMap<String, String> xmlvalues = null;
		String regUsrNames = "";
		String option = "";

		if (!ClsUtil.isNullOrEmpty(userName) && userName.length > 0) {
			regUsrNames = userName[0];

			for (int i = 1; i < userName.length; i++) {
				regUsrNames = regUsrNames + "', '" + userName[i];
			}
		}

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Usernames", regUsrNames);

			option = "ProcedureDeleteUser";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			ArrayList<String> outptXMLlst = null;
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)
					&& !outptXMLlst.get(0).equalsIgnoreCase("Admin User(S) cannot be Deleted")) {
				result = 1;
				logger.info("User Deleted Successfully...");

			} else if (outptXMLlst.get(0).equalsIgnoreCase("Admin User(S) cannot be Deleted")) {
				result = 2;
				logger.info("Admin User(S) cannot be Deleted");
			} else {
				result = -1;
			}
		} catch (Exception e) {
			loggerErr.error("Exception While Deleting User By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in deleting user by admin is: " + totaltime);

		return result;
	}

}
