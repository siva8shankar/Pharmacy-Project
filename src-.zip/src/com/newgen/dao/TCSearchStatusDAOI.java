/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SearchStatusDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Interface for SearchStatusDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.ReportsBean;
import com.newgen.bean.VPReportMaster;
import com.newgen.bean.VPUserMasterBean;
import com.newgen.bean.VendorQueryDetails;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.util.GeneralClass;

public interface TCSearchStatusDAOI {

	public abstract GeneralClass searchQueryDetails(String priviledge, VendorQueryDetails venDetails, String archive,
			String sessionid, String endurl);

	public abstract GeneralClass searchQuery(VendorQueryMaster venMaster, GeneralClass gen, String archive,
			String statusQuery, String endurl);

	// public abstract GeneralClass searchInvoice(GeneralClass
	// gen,InvoiceDetails invoice, String archive, String endurl);
	public abstract GeneralClass searchInvoice(GeneralClass gen, InvoiceNewDetails invoice, String archive,
			String endurl, String Cabinet);

	public abstract int getQueryStatus(String queryNo, String endurl);

	// public abstract StringBuffer exportInvoice(InvoiceDetails invoice,String
	// archive, VPReportMaster reportBean, String priviledge,String endurl);
	// public abstract StringBuffer exportInvoice(InvoiceNewDetails
	// invoice,String archive, VPReportMaster reportBean, String
	// priviledge,String endurl);
	public abstract StringBuffer exportInvoice(InvoiceNewDetails invoice, String archive, VPReportMaster reportBean,
			String priviledge, String endurl, String cabinet);

	public abstract StringBuffer exportQuery(VendorQueryMaster venMaster, String archive, String statusQuery,
			VPReportMaster reportBean, String priviledge, String VendorCode, String endurl);

	public abstract GeneralClass searchInvoice(InvoiceNewDetails invoice, GeneralClass gen, String sessionid,
			String endurl, String IBPSEndPointURL, String Cabinet);

	public abstract GeneralClass getReportDetails(ReportsBean report, GeneralClass gen, String sessionid, String endurl,
			String IBPSEndPointURL, String Cabinet);

	public abstract StringBuffer exportUserMaster(VPUserMasterBean usermasterBean, String iBPSurl);

}