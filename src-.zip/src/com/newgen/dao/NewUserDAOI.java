/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: NewUserDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Interface for NewUserDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.HashMap;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.VendorMaster;

public interface NewUserDAOI {

	public abstract int registerUser(AppliedUser appliedUser, String endurl);

	public abstract HashMap<String, String> fetchVendorDetails(String UserName, String endurl, String cabinet);

	public abstract int checkAvailability(String userName, String endurl);

	public abstract VendorMaster fetchVendorDetailsByVendorCode(String vendorCode, String endurl);

}