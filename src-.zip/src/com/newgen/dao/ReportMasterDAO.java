/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ReportMasterDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VPReportMaster;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class ReportMasterDAO implements ReportMasterDAOI {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to fetch details of invoice/query Report from db like
	 * header.
	 * 
	 * @param endurl.
	 * @return HashMap<String, VPReportMaster>
	 * @exception Exception
	 */
	public HashMap<String, VPReportMaster> getReportMasterData(String endurl) {

		long starttime = System.currentTimeMillis();
		logger.info("Loading Report Data");
		HashMap<String, VPReportMaster> reportMap = new HashMap<String, VPReportMaster>();
		VPReportMaster reportMaster = null;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", "rahul");
			option = "ProcedureReportMaster";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0)

			{
				for (int k = 0; k < outptXMLlst.size(); k++) {

					reportMaster = new VPReportMaster();
					reportMaster.setReportId(outptXMLlst.get(k));
					String strReportName = outptXMLlst.get(++k);
					reportMaster.setReportName(strReportName);
					reportMaster.setDescription(outptXMLlst.get(++k));
					reportMaster.setActive(outptXMLlst.get(++k));
					reportMaster.setBatchSize(outptXMLlst.get(++k));
					reportMaster.setFormName(outptXMLlst.get(++k));
					reportMaster.setFieldDelimiter(outptXMLlst.get(++k));
					reportMaster.setRowDelimiter(outptXMLlst.get(++k));
					reportMaster.setHeader(outptXMLlst.get(++k));
					reportMaster.setFooter(outptXMLlst.get(++k));
					reportMaster.setFileNamePattern(outptXMLlst.get(++k));
					reportMap.put(strReportName, reportMaster);
				}
				logger.debug("Got Report Data Successfully");
			}
		} catch (Exception e) {
			loggerErr.error("Exception in Loading Report Details : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Loading Report Details is " + totaltime);

		return reportMap;
	}

}