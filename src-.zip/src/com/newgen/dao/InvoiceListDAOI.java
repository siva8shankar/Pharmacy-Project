/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: InvoiceListDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  Interface for AdminUserListDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;

import com.newgen.bean.SubmitQueryListNew;
import com.newgen.util.GeneralClass;

public interface InvoiceListDAOI {

	public abstract GeneralClass getInvoiceListWithDetails(String userType, GeneralClass gen, String searchUser,
			String loggedInUser, String searchType, String endurl);

	public abstract ArrayList<SubmitQueryListNew> getInvoiceList(String VendorCode, String InvoiceNumber,
			String userPrevilage, String endurl, String cabinet);

	public abstract ArrayList<SubmitQueryListNew> getQueryList(String VendorCode, String userPrevilage, String endurl);

}