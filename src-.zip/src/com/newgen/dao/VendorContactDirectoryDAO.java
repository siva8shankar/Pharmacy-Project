/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorContactDirectoryDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorContactDirectory;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class VendorContactDirectoryDAO implements VendorContactDirectoryDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to fetch Contact Directory Details.
	 * 
	 * @param userName,
	 *            endurl.
	 * @return VendorContactDirectory
	 * @exception Exception
	 */

	@Override
	public HashMap<Integer, VendorContactDirectory> GetContactDirectory(String usr, String endurl) {

		long starttime = System.currentTimeMillis();
		logger.info("GetContactDirectory Method Starts...UserName: " + usr);
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		VendorContactDirectory contactbean = null;
		HashMap<Integer, VendorContactDirectory> contactmap = null;
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", usr);
			option = "ProcedureGetContactDirectory";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			contactmap = new HashMap<Integer, VendorContactDirectory>();
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (outptXMLlst.size() > 0 && !ClsUtil.isNullOrEmpty(outptXMLlst)) {
				int i = 0;
				for (int k = 0; k < outptXMLlst.size(); k++) {
					contactbean = new VendorContactDirectory();
					contactbean.setFirstName(outptXMLlst.get(k));
					contactbean.setLastName(outptXMLlst.get(++k));
					contactbean.setPhone(outptXMLlst.get(++k));
					contactbean.setEmail(outptXMLlst.get(++k));
					contactbean.setCPurpose(outptXMLlst.get(++k));
					contactbean.setRequUserAccount(outptXMLlst.get(++k));
					contactmap.put(i, contactbean);
					i++;
				}

				logger.debug("Got Vendor Contact Details Successfully");
			}
		} catch (Exception e) {
			loggerErr.error("Exception in getting Contact Details : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Getting Vendor Contact Details is " + totaltime);
		return contactmap;

	}
}
