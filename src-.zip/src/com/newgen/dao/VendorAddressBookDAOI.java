/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorAddressBookDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Interface for VendorAddressBookDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.HashMap;

import com.newgen.bean.VendorAddressBook;

public interface VendorAddressBookDAOI {
	public abstract HashMap<Integer, VendorAddressBook> GetAddressBook(String usr, String endurl);

}
