/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminNewCompanyDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  This is a Data access object class which interacts with database and perform CURD Operations i.e. Insert & Update.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.CompanyMaster;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class AdminNewCompanyDAO implements AdminNewCompanyDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to add & update Company.
	 * 
	 * @param CompanyMaster
	 *            companyMaster
	 * @return int result
	 * @exception Exception
	 */
	@Override
	public int addNewCompany(CompanyMaster companyMaster, String buttonType, String tempCompanyCode,
			String tempCompanyName, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("addNewCompany Method Starts...");

		String SOAP_inxml = null;
		String option = "";
		int result = 0;
		HashMap<String, String> xmlvalues = new HashMap<String, String>();

		try {
			xmlvalues.put("CompCode", companyMaster.getCompanyCode());
			xmlvalues.put("CompName", companyMaster.getCompanyName());
			xmlvalues.put("CompAdrs", companyMaster.getCompanyAddress());
			xmlvalues.put("CompCountry", companyMaster.getCountry());
			xmlvalues.put("TempCompanyCode", tempCompanyCode);
			xmlvalues.put("TempCompanyName", tempCompanyName);
			xmlvalues.put("buttonType", buttonType);

			option = "ProcedureInsertNewComp";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			ArrayList<String> outptXMLlst = null;

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			// Checking outptXMLlst object is null or empty
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				if (outptXMLlst.get(0).equalsIgnoreCase("CompanyDataUpdated"))

					logger.info("Company Details Updated Succesfully...");

				else
					logger.info("New Company Register Succesfully...");

				result = 1;
			} else {
				result = -1;
			}

		} catch (Exception e) {
			result = -1;
			loggerErr.error("Exception While Adding New Company By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.info("Total Time Taken in adding New Company by admin is " + totaltime);

		return result;
	}

	/**
	 * This Method is used to getCompanyDetails.
	 * 
	 * @param String
	 *            companyCode, String endurl
	 * @return GeneralClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass getCompanyDetails(String companyCode, String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.info("getCompanyDetails Method Starts...");
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		ArrayList<CompanyMaster> arrayCompanyDetails = new ArrayList<CompanyMaster>();

		try {

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("CompCode", companyCode);
			option = "ProcedureCompDetails";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {

				CompanyMaster companyMaster = new CompanyMaster();
				companyMaster.setCompanyCode(outptXMLlst.get(0));
				companyMaster.setCompanyName(outptXMLlst.get(1));
				companyMaster.setCompanyAddress(outptXMLlst.get(2));
				companyMaster.setCountry(outptXMLlst.get(3));

				arrayCompanyDetails.add(companyMaster);

			}

		} catch (Exception e) {
			loggerErr.error("Exception While getting Company Details By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		GeneralClass gen = new GeneralClass();
		gen.setArrayCompanyList(arrayCompanyDetails);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting Company Details by admin is " + totaltime);

		return gen;
	}
}
