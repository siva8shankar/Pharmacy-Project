/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GetInvoiceDetailDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations i.e UPDATE & SELECT
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;


public class GetInvoiceDetailDAO implements GetInvoiceDetailDAOI{
	private static Logger logger = Logger.getLogger("consoleLogger");

    private static Logger loggerErr = Logger.getLogger("errorLogger"); 

	/**
	 * This Method is used to GetInvoiceDetail.
	 * @param String,endurl
	 * @return Bean
	 * @exception Exception
	 */
	@Override
	public InvoiceNewDetails GetInvoiceDetail(String invid, String endurl){
		long starttime = System.currentTimeMillis();
		logger.debug("GetInvoiceDetail Method Starts...");
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;		
		InvoiceNewDetails invbean=null;
		try {
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("InvoiceId", invid);
			option="ProcedureGetInvoiceDetail";
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option);
		
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)

			{
				for(int k=0 ;k<outptXMLlst.size();k++)
				{   
					invbean  = new InvoiceNewDetails();
					invbean.setInvoiceno(outptXMLlst.get(k));
					invbean.setInvoicedate(ClsConvertDate.ConvertxmlDatetoDate(outptXMLlst.get(++k)));
					//invbean.setBillingaddress(outptXMLlst.get(++k));
					invbean.setCurrency(outptXMLlst.get(++k));
					invbean.setFDocumentType(outptXMLlst.get(++k));
					invbean.setTypeofinvoice(outptXMLlst.get(++k));
					invbean.setPono(outptXMLlst.get(++k));
					//invbean.setRequestor_EmailID(outptXMLlst.get(++k));
					//invbean.setRequestor_Name(outptXMLlst.get(++k));					
					
					String invoiceAmount = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(invoiceAmount))
						invbean.setInvoiceAmount("");
					else
						invbean.setInvoiceAmount(invoiceAmount);
					
					String exchangeRate = outptXMLlst.get(++k);
					/*if(ClsUtil.isNullOrEmpty(exchangeRate))
						invbean.setExchangeRate("");
					else
						invbean.setExchangeRate(exchangeRate);*/
					
					String invoiceAmountUSD = outptXMLlst.get(++k);
					/*if(ClsUtil.isNullOrEmpty(invoiceAmountUSD))
						invbean.setInvoiceAmountUSD("");
					else
						invbean.setInvoiceAmountUSD(invoiceAmountUSD);*/
					
				/*	String serviceTax  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(serviceTax))
						invbean.setServiceTax("");
					else
						invbean.setServiceTax(serviceTax);
					
					invbean.setStPerc(outptXMLlst.get(++k));
					
					String sbc  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(sbc))
						invbean.setSwachh_BharatCess("");
					else
						invbean.setSwachh_BharatCess(sbc);
					
					String kkc  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(sbc))
						invbean.setKrishi_KalyanCess("");
					else
						invbean.setKrishi_KalyanCess(kkc);
					
					String cstAmt  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(cstAmt))
						invbean.setCSTAmt("");
					else
						invbean.setCSTAmt(cstAmt);
					
					invbean.setCstPerc(outptXMLlst.get(++k));
					
					String vatAmt  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(vatAmt))
						invbean.setVATAmt("");
					else
						invbean.setVATAmt(vatAmt);
					
					invbean.setVatPerc(outptXMLlst.get(++k));
					
					String igstAmt  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(igstAmt))
						invbean.setIGSTAmt("");
					else
						invbean.setIGSTAmt(igstAmt);
					
					String cgstAmt  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(cgstAmt))
						invbean.setCGSTAmt("");
					else
						invbean.setCGSTAmt(cgstAmt);
					
					String sgstAmt  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(sgstAmt))
						invbean.setSGSTAmt("");
					else
						invbean.setSGSTAmt(sgstAmt);
					
					String exciseDuty  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(exciseDuty))
						invbean.setExciseDuty("");
					else
						invbean.setExciseDuty(exciseDuty);
					
					invbean.setEdPerc(outptXMLlst.get(++k));
					
					String invoiceAmt  = outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(invoiceAmt))
						invbean.setInvoiceamount("");
					else
						invbean.setInvoiceamount(invoiceAmt);
					
					invbean.setPANNo(outptXMLlst.get(++k));
					invbean.setTANNo(outptXMLlst.get(++k));
					invbean.setService_TaxRegNo(outptXMLlst.get(++k));
					invbean.setTINNo(outptXMLlst.get(++k));				
					*/
					
					/*if(ClsUtil.isNullOrEmpty(serviceTax)){
						invbean.setServiceTax("");
					}
					else{
						invbean.setServiceTax(serviceTax);
					}

					String educationCess =outptXMLlst.get(++k);

					if(ClsUtil.isNullOrEmpty(educationCess)){
						invbean.setEducationCess("");
					}
					else{
						invbean.setEducationCess(educationCess);
					}

					String highEducationCess =outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(highEducationCess)){
						invbean.setHigherEducationCess("");
					}
					else{
						invbean.setHigherEducationCess(highEducationCess);
					}

					String VAT =outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(VAT)){
						invbean.setVat("");
					}
					else{
						invbean.setVat(VAT);
					}

					String addtionalVATValue =outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(addtionalVATValue)){
						invbean.setAdditionalVATValue("");
					}
					else{
						invbean.setAdditionalVATValue(addtionalVATValue);
					}

					String AnyOtherTax =outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(AnyOtherTax)){
						invbean.setAnyOtherTax("");
					}
					else{
						invbean.setAnyOtherTax(AnyOtherTax);
					}

					String freight =outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(freight)){
						invbean.setFreight("");
					}
					else{
						invbean.setFreight(freight);
					}

					String totalInvoiceAmount =outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(totalInvoiceAmount)){
						invbean.setTotalInvoiceAmount("");
					}
					else{
						invbean.setTotalInvoiceAmount(totalInvoiceAmount);
					}

					String discount =outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(discount)){
						invbean.setDiscount("");
					}
					else{
						invbean.setDiscount(discount);
					}

					String penaltyDeduction =outptXMLlst.get(++k);
					if(ClsUtil.isNullOrEmpty(penaltyDeduction)){
						invbean.setPenaltyDeduction("");
					}
					else{
						invbean.setPenaltyDeduction(penaltyDeduction);
					}

					
					
					
					invbean.setVoucherNarration(outptXMLlst.get(++k));
					String date_fr =outptXMLlst.get(++k); 
					invbean.setFromDate(ClsConvertDate.ConvertxmlDatetoDate(date_fr));
					String date_to =outptXMLlst.get(++k); 
					invbean.setToDate(ClsConvertDate.ConvertxmlDatetoDate(date_to));
					invbean.setAnyOtherTaxType(outptXMLlst.get(++k));	*/

				}
				logger.debug("Got InvoiceDetail Successfully");

			}
		}catch (Exception e) {
			loggerErr.error("Exception While getting InvoiceDetail  : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting InvoiceDetail is ..."+ totaltime);
		return invbean;


	}}
