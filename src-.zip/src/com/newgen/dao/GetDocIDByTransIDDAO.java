/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GetDocIDByTransIDDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations i.e UPDATE & SELECT
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.SubmitQueryListNew;
import com.newgen.bean.VPUserMaster;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class GetDocIDByTransIDDAO {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to getUserListWithDetails.
	 * 
	 * @param String
	 *            userType, GeneralClass gen, String searchUser, String
	 *            loggedInUser, String endurl.
	 * @return GeneralClass
	 * @exception Exception
	 */

	public ArrayList<String> getDocIDByTransIDMethod(String transactionID, String endurl, String Cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup getDocIDByTransIDMethod  method starts.......");
		ArrayList<String> arrList = new ArrayList<String>();
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {
			logger.debug("transactionID ========>  " + transactionID);
			logger.debug("endurl ========>  " + endurl);
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("transactionID", transactionID);

			option = "ProcedureGetDocumentID";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			logger.debug("SOAP_inxml =========> " + SOAP_inxml);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("outptXMLlst =========> " + outptXMLlst);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				int i = 0;
				for (int k = 0; k < outptXMLlst.size(); k++) {
					arrList.add(outptXMLlst.get(k));
					i = k + 1;
				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is " + totaltime);

		return arrList;
	}

	public ArrayList<String> getDocIDByPOIDMethod(String PONumber, String endurl, String Cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup getDocIDByPOIDMethod  method starts.......");
		ArrayList<String> arrList = new ArrayList<String>();
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {
			logger.debug("PONumber ========>  " + PONumber);
			logger.debug("endurl ========>  " + endurl);
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("PONumber", PONumber);

			option = "ProcedureGetDocumentIDByPONumber";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			logger.debug("SOAP_inxml =========> " + SOAP_inxml);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("outptXMLlst =========> " + outptXMLlst);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				int i = 0;
				for (int k = 0; k < outptXMLlst.size(); k++) {
					arrList.add(outptXMLlst.get(k));
					i = k + 1;
				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is " + totaltime);

		return arrList;
	}

}
