/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminUserDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which can change the user status, check session whether it is valid or not and sent mail to user.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import org.apache.log4j.Logger;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.VPUserMaster;
import com.newgen.util.ClsSendEmail;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class AdminUserDAO implements AdminUserDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to change user status from applied to registered
	 * 
	 * @param String
	 *            [] userName
	 * @param String
	 *            status, String comments
	 * @return int result
	 * @exception Exception
	 */

	public static int changeUserStatus(String[] userName, String status, String comments, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("changeUserStatus Method Starts...");

		int result = 0;
		VPUserMaster userMaster = null;
		AppliedUser appliedBean = null;
		String appUserNames = "";

		if (!ClsUtil.isNullOrEmpty(userName) && userName.length > 0) {
			appUserNames = userName[0];

			for (int i = 1; i < userName.length; i++) {
				appUserNames = appUserNames + "," + userName[i];
			}
		}
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", appUserNames);
			xmlvalues.put("status", status);
			xmlvalues.put("comments", comments);

			option = "ProcedureChangeUserStatus";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			// Checking outptXMLlst is null or empty
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				if (!outptXMLlst.get(0).equalsIgnoreCase("Rejected")) {
					for (int k = 0; k < outptXMLlst.size(); k++) {
						// Setting values in userMaster Bean
						userMaster = new VPUserMaster();
						userMaster.setUserName(outptXMLlst.get(k));
						userMaster.setUserEmailId(outptXMLlst.get(++k));
						userMaster.setPassword(outptXMLlst.get(++k));
						userMaster.setActivationCode(outptXMLlst.get(++k));
						try {
							// Send Email to User
							ClsSendEmail.sendEmail(userMaster, "Activate");
							result = 1;
							logger.debug("User(s) Approved Successfully.");
						} catch (Exception e) {
							loggerErr.error("Exception Occurred while Approve/Reject send email : " + e.getMessage());
							e.printStackTrace();
							result = -1;
						}
					}
				} else if (outptXMLlst.get(0).equalsIgnoreCase("Rejected")) {
					// result = 1;
					// logger.debug("User(s) Rejected Successfully.");
					// logger.debug("outptXMLlst.size()-*****************"+outptXMLlst.size());
					// logger.debug("outptXMLlst.data--"+outptXMLlst.toString());
					for (int k = 1; k < outptXMLlst.size(); k++) {
						// logger.debug("outptXMLlst.get("+k+")-->"+outptXMLlst.get(k));
						userMaster = new VPUserMaster();
						userMaster.setUserName(outptXMLlst.get(k));
						userMaster.setUserEmailId(outptXMLlst.get(++k));
						try {
							// Send Email to User
							ClsSendEmail.sendEmail(userMaster, "Reject");
							result = 1;
							logger.debug("User(s) Rejected Successfully.------------");
						} catch (Exception e) {
							loggerErr.error("Exception Occurred while Approve/Reject send email : " + e.getMessage());
							e.printStackTrace();
							result = -1;
						}
					}
				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception Occurred while Approve/Reject User : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Approve/Reject User by admin is " + totaltime);

		return result;
	}

	/**
	 * This Method is used to send email
	 * 
	 * @param String
	 *            userName
	 * @return int
	 * @exception Exception
	 */
	@Override
	public int sendEmail(String userName, String endurl) {
		logger.debug("sendEmail Method Starts...");
		long starttime = System.currentTimeMillis();
		VPUserMaster userMaster = null;
		Random randomGenerator = new Random();
		int tempPassword = randomGenerator.nextInt((9999999) + 1);
		int activationCode = randomGenerator.nextInt((999999999) + 1);

		int result = 0;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", userName);
			xmlvalues.put("TempPassword", String.valueOf(tempPassword));
			xmlvalues.put("ActivationCode", String.valueOf(activationCode));

			option = "ProcedureSendEmail";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				if (outptXMLlst.get(0).trim().equalsIgnoreCase("User Does not Exist")) {
					result = -2;
					logger.debug("User Does not Exist...");
				} else {
					userMaster = new VPUserMaster();
					userMaster.setUserEmailId(outptXMLlst.get(0));
					userMaster.setPassword(String.valueOf(tempPassword));
					userMaster.setActivationCode(String.valueOf(activationCode));
					userMaster.setUserName(userName);
					try {
						// Send Email to User
						ClsSendEmail.sendEmail(userMaster, "Activate");
						result = 1;
					} catch (Exception e) {
						loggerErr.error("Exception Occurred while send email : " + e.getMessage());
						e.printStackTrace();
						result = -1;
					}

				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception While sending email : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken While sending email is " + totaltime);
		return result;
	}

	@Override
	public int sendEmailonEnable(String userName, String endurl, String mailOption) {
		logger.debug("sendEmailonEnable Method Starts...");
		long starttime = System.currentTimeMillis();
		VPUserMaster userMaster = null;

		int result = 0;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", userName);

			option = "ProcedureGetUserDetails";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				if (outptXMLlst.get(0).trim().equalsIgnoreCase("User Does not Exist")) {
					result = -2;
					logger.debug("User Does not Exist...");
				} else {
					userMaster = new VPUserMaster();
					userMaster.setUserName(outptXMLlst.get(0));
					userMaster.setUserEmailId(outptXMLlst.get(1));
					userMaster.setUserPhoneNumber(outptXMLlst.get(2));
					try {
						// Send Email to User
						ClsSendEmail.sendEmail(userMaster, mailOption);
						result = 1;
					} catch (Exception e) {
						loggerErr.error("Exception Occurred while sendEmailonEnable : " + e.getMessage());
						e.printStackTrace();
						result = -1;
					}

				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception While sendEmailonEnable : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken While sendEmailonEnable is " + totaltime);
		return result;
	}

	@Override
	public int sendEmailByAdmin(String userName, String endurl, String mailOption, String newPassword) {
		logger.debug("sendEmailByAdmin Method Starts...");
		long starttime = System.currentTimeMillis();
		VPUserMaster userMaster = null;

		int result = 0;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", userName);

			option = "ProcedureGetUserDetails";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				if (outptXMLlst.get(0).trim().equalsIgnoreCase("User Does not Exist")) {
					result = -2;
					logger.debug("User Does not Exist...");
				} else {
					userMaster = new VPUserMaster();
					userMaster.setUserName(userName);
					userMaster.setUserEmailId(outptXMLlst.get(1));
					userMaster.setPassword(newPassword);
					try {
						// Send Email to User
						ClsSendEmail.sendEmail(userMaster, mailOption);
						result = 1;
					} catch (Exception e) {
						loggerErr.error("Exception Occurred while sendEmailByAdmin : " + e.getMessage());
						e.printStackTrace();
						result = -1;
					}

				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception While sendEmailByAdmin : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken While sendEmailByAdmin is " + totaltime);
		return result;

	}

}