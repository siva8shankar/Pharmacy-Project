/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: UpdatePODetailsDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  This is a Data access object class which updates PO details
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.newgen.bean.PODetails;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class UpdatePODetailsDAO implements UpdatePODetailsDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to update PO details.
	 * 
	 * @param Bean,
	 *            endurl.
	 * @return int
	 * @exception Exception
	 */
	@Override
	public int UpdatePO(PODetails po, String endurl, Map<String, String> map, StringBuilder strDynamicRows) {

		long starttime = System.currentTimeMillis();
		int result = 0;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String DynamicRowSContent = "'" + strDynamicRows.toString().replaceAll("'", "\"") + "'";
		logger.debug("po.getDeliveryDate() " + po.getDeliveryDate());
		DynamicRowSContent = DynamicRowSContent.replaceAll("<", "&lt;");
		DynamicRowSContent = DynamicRowSContent.replaceAll(">", "&gt;");
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("PONumber", po.getPONumber());
			xmlvalues.put("SubmittoCompany", po.getSubmittoCompany());
			xmlvalues.put("CompanyAddress", po.getCompanyAddress());
			xmlvalues.put("AttentionTo", po.getAttentionTo());
			xmlvalues.put("VendorCode", po.getVendorCode());
			xmlvalues.put("VendorName", po.getVendorName());
			xmlvalues.put("VendorAddress", po.getVendorAddress());
			xmlvalues.put("InvoiceType", po.getInvoiceType());
			xmlvalues.put("InvoiceNumber", po.getInvoiceNumber());
			xmlvalues.put("InvoiceDate", po.getInvoiceDate());
			xmlvalues.put("Currency", po.getCurrency());
			xmlvalues.put("GrossAmount", po.getGrossAmount());
			xmlvalues.put("TotalTax", po.getTotalTax());
			xmlvalues.put("Freight", po.getFreight());
			xmlvalues.put("Discount", po.getDiscount());
			xmlvalues.put("NetAmount", po.getNetAmount());
			xmlvalues.put("ServiceTax", po.getServiceTax());
			xmlvalues.put("EducationCess", po.getEducationCess());
			xmlvalues.put("VAT", po.getVAT());
			xmlvalues.put("AdditionalVT", po.getAdditionalVAT());
			xmlvalues.put("AnyOtherTax", po.getAnyOtherTax());
			xmlvalues.put("DeliveryDate", po.getDeliveryDate());
			xmlvalues.put("DynamicRows", DynamicRowSContent);
			xmlvalues.put("UserName", po.getUserName());
			option = "ProcedureUpdatePO";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			logger.debug("SOAP_inxml" + SOAP_inxml);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug(outptXMLlst.get(0).trim().equalsIgnoreCase("Updated successfully"));
				if (outptXMLlst.get(0).trim().equalsIgnoreCase("Updated Successfully")) {
					result = 1;
					logger.debug("PO Data Updated succesfully");
				} else {
					result = -1;
					logger.debug("PO Data not Updated");
				}

			}
		} catch (Exception e) {
			loggerErr.error("Exception while Updating PO  : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Updating PO Details is " + totaltime);
		return result;
	}
}
