/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: WorkitemDAOPOSubmit.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object WorkitemDAOPOSubmit class which interacts with database and perform CRUD Operations.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;
import com.newgen.util.MultipartUtility;
import com.newgen.webserviceclient.NGWebServiceClient;

public class WorkitemDAOPOSubmit {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static Logger loggerXml = Logger.getLogger("xmlLogger");

	/**
	 * This Method is used To Initiate Workitem in AP Process.
	 * 
	 * @param InvoiceDetails
	 *            invdetails, String userName.
	 * @return String workitemNumber
	 * @exception Exception
	 */

	public String GetSessionOD(String IBPSEndPointURL, String Cabinet, ServletConfig config) throws ServletException {
		logger.debug("getting OD session start \n\n\n\n");
		String OD_SessionURL = (String) config.getServletContext().getAttribute("OD_SessionURL");
		logger.debug("OD_SessionURL :::  " + OD_SessionURL);

		String OD_Session_User = (String) config.getServletContext().getAttribute("OD_Session_User");
		logger.debug("OD_Session_User :::  " + OD_Session_User);

		String OD_Session_Pwd = (String) config.getServletContext().getAttribute("OD_Session_Pwd");
		logger.debug("OD_Session_Pwd :::  " + OD_Session_Pwd);

		String CabinetName = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("CabinetName :::  " + CabinetName);
		String JTSIP = (String) config.getServletContext().getAttribute("jtsIpAddress");

		logger.debug("JTSIP :::  " + JTSIP);

		String WrapperPort = (String) config.getServletContext().getAttribute("WrapperPort");
		logger.debug("WrapperPort :::  " + WrapperPort);

		String UserType = (String) config.getServletContext().getAttribute("UserType");
		logger.debug("UserType :::  " + UserType);

		String Sessionid = "";
		MultipartUtility MultipartUtility1 = null;

		try {
			MultipartUtility1 = new MultipartUtility(OD_SessionURL, "UTF-8");
		} catch (Exception e) {
			// TODO: handle exception
			loggerErr.debug("EXCEPTION in MultipartUtility of GetSessionOD");
		}

		logger.debug("OD_SessionURL" + OD_SessionURL + "OD_Session_User" + OD_Session_User + "OD_Session_Pwd"
				+ OD_Session_Pwd + "CabinetName" + CabinetName + "JTSIP" + JTSIP + "UserType" + UserType);
		Sessionid = MultipartUtility1.getSessionValue(OD_SessionURL, OD_Session_User, OD_Session_Pwd, UserType);

		logger.debug("GetSessionOD->Sessionid:::" + Sessionid);

		if (Sessionid == "") {
			logger.debug("Error in getting OD session id!!");
			// response.setStatus(500);
			return Sessionid;
		}
		logger.debug("SUCESS IN RETRIVING SESSION IN OD");
		return Sessionid;

	}

	public String initiateworkitem(InvoiceNewDetails invdetails, String WorkItemEndPointURL, String uploadUserName,
			String password, String Cabinet) {
		long starttime = System.currentTimeMillis();
		logger.debug("initiateworkitem Method Starts...");

		String SOAP_inxml = "";
		String sessionid = "";
		String option = "";
		String result = "";
		String folderindex = "";
		String processinstanceid = "";
		String maincode = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		SimpleDateFormat dt = new SimpleDateFormat(ClsMessageHandler.XMLDateFormat);
		String str_dateFrom = "";
		String str_dateTo = "";

		return result;
	}

	public String initiateworkitemwithDocument(InvoiceNewDetails invdetails, String WorkitemEndPointurl,
			String Sessionid, ArrayList AddtoSMS_Response_sd, String ibps_endurl, String cabinet,
			String InitiateFromActivityId, String InitiateFromActivityName, String ProcessDefId, String ProcessName,
			String Docname) {
		long starttime = System.currentTimeMillis();
		logger.debug("initiateworkitemwithDocument Method Starts...");

		String Response = "";
		String SOAP_inxml = "";
		String sessionid = "";
		String option = "";
		String result = "";
		String folderindex = "";
		String processinstanceid = "";
		String maincode = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<HashMap<String, String>> OdValues_List = null;
		HashMap<String, String> xmlvalues_odvalues = null;
		ArrayList<String> outptXMLlst = null;
		SimpleDateFormat dt = new SimpleDateFormat(ClsMessageHandler.XMLDateFormat);
		String str_dateFrom = "";
		String str_dateTo = "";
		ArrayList<String> SOAPResponse_xml_vp = null;

		try {

			xmlvalues = new HashMap<String, String>();

			OdValues_List = new ArrayList<HashMap<String, String>>();

			xmlvalues.clear();
			xmlvalues.put("InvoiceNo", invdetails.getInvoiceno().trim());
			xmlvalues.put("InvoiceType", "PO Based");
			xmlvalues.put("PONumber", invdetails.getPono());
			xmlvalues.put("InvoiceAmount", invdetails.getInvoiceAmount());
			xmlvalues.put("SourceFlag", "VendorPortal");
			xmlvalues.put("VendorCode", invdetails.getVendorno());
			xmlvalues.put("VendorName", invdetails.getVendorName());
			for (int i = 0; i < AddtoSMS_Response_sd.size(); i++) {
				String[] sISIndex = ((String) AddtoSMS_Response_sd.get(i)).split("#");
				String simgDocId = sISIndex[0];
				String simgVolId1 = sISIndex[1];
				String apptype = sISIndex[2];
				String nNoOfPages = sISIndex[3];
				String lgvDocSize = sISIndex[4];
				String doctype = "";
				if (apptype == "pdf") {
					doctype = "N";
				} else {
					doctype = "I";
				}

				logger.debug("" + simgDocId);
				logger.debug("" + simgVolId1);
				logger.debug("" + apptype);
				logger.debug("" + doctype);
				if (i == 0) {
					if (Docname.equalsIgnoreCase("Invoice")) {
						Docname = "Invoice";
					} else {
						Docname = "Remittance";
					}
				} else {
					Docname = "SupportingDocument"; // for supporting document
				}

				xmlvalues_odvalues = new HashMap<String, String>();
				xmlvalues_odvalues.put("appType", apptype);
				xmlvalues_odvalues.put("checkoutBy", "0");
				xmlvalues_odvalues.put("checkoutStatus", "no");
				xmlvalues_odvalues.put("comment", "Workitem with Document");
				xmlvalues_odvalues.put("createdByAppName", apptype);
				xmlvalues_odvalues.put("documentIndex", simgDocId);
				xmlvalues_odvalues.put("documentSize", lgvDocSize);
				xmlvalues_odvalues.put("documentType", doctype);
				xmlvalues_odvalues.put("imageIndex", simgDocId);
				xmlvalues_odvalues.put("name", Docname);
				xmlvalues_odvalues.put("noOfPages", nNoOfPages);
				xmlvalues_odvalues.put("ownerIndex", "1");
				xmlvalues_odvalues.put("versionNumber", "1");
				xmlvalues_odvalues.put("volumnIndex", simgVolId1);

				OdValues_List.add(xmlvalues_odvalues);
			}

			SOAP_inxml = GenerateXML.wfInitiatewithDocumentXML(xmlvalues, OdValues_List, Sessionid, cabinet,
					InitiateFromActivityId, InitiateFromActivityName, ProcessDefId, ProcessName);

			logger.debug(" SOAP_inxml after framing the Tags" + SOAP_inxml);
			String SOAPResponse_xml;
			SOAPResponse_xml = Execute_WebService.executeWebservice_initiate(SOAP_inxml, WorkitemEndPointurl);

			logger.debug("SOAPResponse_xml--->" + SOAPResponse_xml);

			loggerXml.debug("outputXML : " + SOAPResponse_xml);

			if (!ClsUtil.isNullOrEmpty(SOAPResponse_xml)) {
				int startPosition = SOAPResponse_xml.indexOf("processInstanceId>");
				int startmainPosition = SOAPResponse_xml.indexOf("mainCode>");

				processinstanceid = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("processInstanceId>") + 18,
						SOAPResponse_xml.indexOf("</", startPosition));
				maincode = SOAPResponse_xml.substring(SOAPResponse_xml.indexOf("mainCode>") + 9,
						SOAPResponse_xml.indexOf("</", startmainPosition));
				logger.debug("processinstanceid" + processinstanceid);

				if (maincode.equalsIgnoreCase("0")) {
					result = processinstanceid;
					logger.debug("WorkItem Initiated Successfully");

					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					Date d1 = new Date();
					String CreatedDate = dateFormat.format(d1);

					StringBuilder SOAP_inxml_sb = new StringBuilder();

					SOAP_inxml_sb.append(
							"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:req=\"http://ngprocedureselectq.ops.newgen.com/schema/Ngprocedureselect/request\">");
					SOAP_inxml_sb.append(
							"<soapenv:Header/><soapenv:Body><req:ProcedureselectReq><Option>ProcedureSaveInvoiceDetail</Option>");
					SOAP_inxml_sb.append("<Username>" + ClsMessageHandler.XMLUserName + "</Username><Password>"
							+ ClsMessageHandler.XMLPassword + "</Password>");
					SOAP_inxml_sb.append("<req:CriteriaArray>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>PrefixStr</FieldName><FieldValue>"
							+ ClsMessageHandler.InvoiceNumberPrefix + "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>Padding</FieldName><FieldValue>"
							+ ClsMessageHandler.InvoiceNumberLength + "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>Invoiceno</FieldName><FieldValue>"
							+ invdetails.getInvoiceno() + "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>Typeoftransaction</FieldName><FieldValue>"
							+ invdetails.getFDocumentType() + "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>Vendorno</FieldName><FieldValue>"
							+ invdetails.getVendorno() + "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>InvoiceCreatedDate</FieldName><FieldValue>"
							+ CreatedDate + "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>InvoiceCreatedBy</FieldName><FieldValue>"
							+ invdetails.getInvoiceCreatedBy() + "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>TransactionId</FieldName><FieldValue>" + result
							+ "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("<req:Criteria><FieldName>VendorName</FieldName><FieldValue>"
							+ invdetails.getVendorName() + "</FieldValue></req:Criteria>");
					SOAP_inxml_sb.append("</req:CriteriaArray>");
					SOAP_inxml_sb.append(
							"<nextSeedValue>?</nextSeedValue></req:ProcedureselectReq></soapenv:Body></soapenv:Envelope>");

					loggerXml.debug("SOAP_inxml for submit invoice: " + SOAP_inxml_sb.toString());
					SOAP_inxml = SOAP_inxml_sb.toString();

					SOAPResponse_xml_vp = Execute_WebService.executeWebservice(SOAP_inxml, ibps_endurl); // webservice
																											// call
																											// for
																											// insert
																											// the
																											// same
																											// case
																											// in
																											// vp

					loggerXml.debug("SOAPResponse_xml for submit invoice: " + SOAPResponse_xml_vp);
					if (SOAPResponse_xml_vp != null) {
						if (SOAPResponse_xml_vp.contains("INVOICE Inserted")) {
							logger.debug("Invoice Inserted succesfully");
							logger.debug("Reponse" + result);
							Response = result;
							logger.debug("Reponse" + Response);
						} else {
							Response = "No Response";
							logger.debug("Initiation Successfull. Insertion in Vendor Portal Table Failed");
						}

					} else {
						Response = "No Response";
						logger.debug("Initiation Successfull. Insertion in Vendor Portal SOAP Failed");

					}

				}

				else {
					result = "Pending";
					Response = result;
					logger.debug("Document added to SMS  and WorkItem Initiation Unsuccessful");
				}

			}

			else {
				result = "Pending";
				Response = result;
				logger.debug("Document added to SMS  and WorkItem Initiation Unsuccessful");
			}

		} catch (Exception e) {
			loggerErr.error("Exception occured :" + e.getMessage());
			e.printStackTrace();
			result = "Pending";
			Response = result;
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("result is --->:" + result);
		logger.debug("Response is --->:" + Response);
		logger.debug("Total Time Taken in initiating workitem is:" + totaltime);

		return Response;
	}

}