/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SubmitQueryDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  Interface for SubmitQueryDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import com.newgen.bean.VendorQueryDetails;
import com.newgen.util.GeneralClass;

public interface SubmitQueryDAOI {

	public abstract GeneralClass submitQuery(String vendorCode, VendorQueryDetails venDetails, String invoiceNo,
			Boolean status, String nextQueryNo, String sessionid, String endurl);

}