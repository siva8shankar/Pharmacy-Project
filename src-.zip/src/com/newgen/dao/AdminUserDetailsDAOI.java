/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminUserDetailsDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Interface for AdminUserDetailsDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.VPUserMaster;
import com.newgen.util.GeneralClass;

public interface AdminUserDetailsDAOI {

	public abstract GeneralClass getUserDetails(String userName, String userType, String endurls);

	public abstract int updateRegUser(VPUserMaster userMaster, String endurl);

	public abstract int updateAppUser(AppliedUser appliedUser, String endurl);

}