/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminNewCompanyDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  This is a Data access object class which interacts with database and perform CURD Operations i.e. Insert & Update.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.CompanyMaster;
import com.newgen.bean.UpdateTCRequestDetailsBean;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class UpdateTCRequestDetailsDAO{

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to add & update Company.
	 * 
	 * @param CompanyMaster
	 *            companyMaster
	 * @return int result
	 * @exception Exception
	 */
	public int updateTCRequestDetails(String VendorCode, UpdateTCRequestDetailsBean invDetails, String sessionid,
			String endurl, String IBPSEndPointURL, String Cabinet) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("updateTCRequestDetails Method Starts...");

		String SOAP_inxml = null;
		String option = "";
		int result = 0;
		HashMap<String, String> xmlvalues = new HashMap<String, String>();
		SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.MainDateFormat);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String strEddDF = "";
		String strDeliveryDateDF = "";
		String strDispatchedDateDF = "";

		if (!ClsUtil.isNullOrEmpty(invDetails.getEdd())) {
			try {

				Date invdate = sdf.parse(invDetails.getEdd());
				strEddDF = dateFormat.format(invdate);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		logger.debug("UpdateTCRequestDetailsDAO strEddDF--->" + strEddDF);	

		if (!ClsUtil.isNullOrEmpty(invDetails.getDeliverydate())) {
			try {

				Date invdate = sdf.parse(invDetails.getDeliverydate());
				strDeliveryDateDF = dateFormat.format(invdate);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		logger.debug("UpdateTCRequestDetailsDAO strDeliveryDateDF--->" + strDeliveryDateDF);
		
		if (!ClsUtil.isNullOrEmpty(invDetails.getDispatchedDate())) {
			try {

				Date invdate = sdf.parse(invDetails.getDispatchedDate());
				strDispatchedDateDF = dateFormat.format(invdate);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		logger.debug("UpdateTCRequestDetailsDAO strDispatchedDateDF--->" + strDispatchedDateDF);
		
		try {
			xmlvalues.put("InsertionID", invDetails.getTcInsertionID());
			xmlvalues.put("TCReqNo", invDetails.getTcReqID());
			xmlvalues.put("PID", invDetails.getTcPID());
			xmlvalues.put("Plant", invDetails.getPlant());
			xmlvalues.put("Quantity", invDetails.getQuantity());
			xmlvalues.put("Structure", invDetails.getStructure());
			xmlvalues.put("Comment",invDetails.getComment());
			xmlvalues.put("EDD",strEddDF);
			xmlvalues.put("DeliveryDate",strDeliveryDateDF);
			xmlvalues.put("DispatchedDate",strDispatchedDateDF);
			xmlvalues.put("Status",invDetails.getStatus());
			xmlvalues.put("VendorNo",invDetails.getVendorCode());
			xmlvalues.put("VendorName",invDetails.getVendorName());
			xmlvalues.put("VendorEmailId",invDetails.getVendorEmailID());

			option = "ProcedureUpdateTCRequestDetails";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			ArrayList<String> outptXMLlst = null;

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			// Checking outptXMLlst object is null or empty
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				if (outptXMLlst.get(0).equalsIgnoreCase("TCRequestDataUpdated"))

					logger.info("TCRequest Details Updated Succesfully...");

				else
					logger.info("New Company Register Succesfully...");

				result = 1;
			} else {
				result = -1;
			}

		} catch (Exception e) {
			result = -1;
			loggerErr.error("Exception While Adding New Company By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.info("Total Time Taken in adding New Company by admin is " + totaltime);

		return result;
	}

	/**
	 * This Method is used to getCompanyDetails.
	 * 
	 * @param String
	 *            companyCode, String endurl
	 * @return GeneralClass
	 * @exception Exception
	 */
	public GeneralClass getCompanyDetails(String companyCode, String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.info("getCompanyDetails Method Starts...");
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		ArrayList<CompanyMaster> arrayCompanyDetails = new ArrayList<CompanyMaster>();

		try {

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("CompCode", companyCode);
			option = "ProcedureCompDetails";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {

				CompanyMaster companyMaster = new CompanyMaster();
				companyMaster.setCompanyCode(outptXMLlst.get(0));
				companyMaster.setCompanyName(outptXMLlst.get(1));
				companyMaster.setCompanyAddress(outptXMLlst.get(2));
				companyMaster.setCountry(outptXMLlst.get(3));

				arrayCompanyDetails.add(companyMaster);

			}

		} catch (Exception e) {
			loggerErr.error("Exception While getting Company Details By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		GeneralClass gen = new GeneralClass();
		gen.setArrayCompanyList(arrayCompanyDetails);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting Company Details by admin is " + totaltime);

		return gen;
	}
}
