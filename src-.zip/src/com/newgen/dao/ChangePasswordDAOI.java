/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ChangePasswordDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Interface for ChangePasswordDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

public interface ChangePasswordDAOI {

	public abstract int savePassword(String oldPassword, String newPassword, String userName, String endurl);

}