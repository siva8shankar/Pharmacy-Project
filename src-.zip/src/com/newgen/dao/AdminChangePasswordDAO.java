/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminChangePasswordDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations i.e UPDATE & SELECT
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import org.apache.log4j.Logger;

import com.newgen.bean.PasswordPolicyBean;
import com.newgen.bean.VPUserMaster;
import com.newgen.util.ClsSendEmail;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class AdminChangePasswordDAO implements AdminChangePasswordDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to update password.
	 * 
	 * @param newPassword,
	 *            userName.
	 * @return Integer
	 * @exception Exception
	 */
	@Override
	public int changePassword(String newPassword, String userName, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		String SOAP_inxml = "";
		String option = "";
		int result = 0;
		HashMap<String, String> xmlvalues = null;
		VPUserMaster userMaster = null;

		Random randomGenerator = new Random();
		int activationCode = randomGenerator.nextInt((999999999) + 1);

		try {

			logger.debug("changePassword Method Starts...UserName: " + userName);

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("NewPassword", newPassword);
			xmlvalues.put("ActivationCode", String.valueOf(activationCode));
			xmlvalues.put("Username", userName.toLowerCase());

			option = "ProcedureChangePass";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			ArrayList<String> outptXMLlst = null;

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			// checking outptXMLlst is not null
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				if (outptXMLlst.get(0).equalsIgnoreCase("No_User_Found")) {
					result = -1;
					logger.debug("User not found");
				} else {
					userMaster = new VPUserMaster();
					userMaster.setUserEmailId(outptXMLlst.get(0));
					userMaster.setPassword(newPassword);
					userMaster.setActivationCode(activationCode + "");
					userMaster.setUserName(userName.toLowerCase());
					result = 1;
					logger.debug("Updating user details in User master. UserName:" + userName + " newPassword:"
							+ newPassword);
				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Admin User Change Password is " + totaltime);
		return result;
	}

	@Override
	public int savePasswordPolicy(PasswordPolicyBean passwordPolicyBean, String userName, String endurl) {

		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.info("passwordPolicy Method Starts...");

		String SOAP_inxml = "";
		int result = 0;
		String option = "";
		HashMap<String, String> xmlvalues = null;
		try {

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("PasswordLen", passwordPolicyBean.getPasswordLen());
			xmlvalues.put("MinSpecialCharLen", passwordPolicyBean.getMinSplCharCt());
			xmlvalues.put("MinNumericCharCount", passwordPolicyBean.getMinNumCharCt());
			xmlvalues.put("MinLowerCaseCharCount", passwordPolicyBean.getMinLowerCaseCt());
			xmlvalues.put("MinUpperCaseCharCount", passwordPolicyBean.getMinUpperCaseCt());
			xmlvalues.put("CreatedBy", userName);
			xmlvalues.put("CreatedDateTime", "");

			option = "ProcedureSelectUpdatePasswordPolicy";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			ArrayList<String> outptXMLlst = null;
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (outptXMLlst.get(0).trim().equalsIgnoreCase("PasswordPolicyAdded")) {
				logger.info("Password Policy has been updated successfully...");
				result = 1;
			} else {
				result = -1;
				logger.info("Password Policy Not Added Successfully...");
			}
		} catch (Exception e) {
			loggerErr.error("Exception While Adding passwordPolicy By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.info("Total Time Taken in adding passwordPolicy by admin is: " + totaltime);
		return result;

	}
	
	@Override
	public PasswordPolicyBean FetchPasswordPolicy(String pUserName, String sessionId, String endurl) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.info("FetchPasswordPolicy Method Starts...");

		String SOAP_inxml = "";
		int result = 0;
		String option = "";
		HashMap<String, String> xmlvalues = null;
		PasswordPolicyBean objBean = null;
		try {

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("userName", pUserName);
			xmlvalues.put("sessionId", sessionId);

			option = "ProcedureSelectFetchPasswordPolicy";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			ArrayList<String> outptXMLlst = null;
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (outptXMLlst.size() > 0 && !ClsUtil.isNullOrEmpty(outptXMLlst)) {
				objBean = new PasswordPolicyBean();
				objBean.setPasswordLen(outptXMLlst.get(0));
				objBean.setMinSplCharCt(outptXMLlst.get(1));
				objBean.setMinNumCharCt(outptXMLlst.get(2));
				objBean.setMinLowerCaseCt(outptXMLlst.get(3));
				objBean.setMinUpperCaseCt(outptXMLlst.get(4));
			} else {
				// Setting up default values here, in case if password policy
				// not defined by Admin.
				objBean = new PasswordPolicyBean();
				objBean.setPasswordLen("8");
				objBean.setMinSplCharCt("-1");
				objBean.setMinNumCharCt("0");
				objBean.setMinLowerCaseCt("0");
				objBean.setMinUpperCaseCt("0");
			}

		} catch (Exception e) {
			loggerErr.error("Exception While FetchPasswordPolicy By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.info("Total Time Taken in FetchPasswordPolicy by admin is: " + totaltime);
		return objBean;
	}
}
