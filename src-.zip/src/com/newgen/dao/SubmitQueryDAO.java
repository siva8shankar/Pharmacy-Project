/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SubmitQueryDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which is used to submit query against invoice
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
*  04/10/2017                        ksivashankar       				Bug 1015851 - Vendor Portal - Query Handling in both client and admin
************************************************************************************************/

package com.newgen.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorQueryDetails;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class SubmitQueryDAO implements SubmitQueryDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to submit Query.
	 * 
	 * @param String
	 *            vendorCode, VendorQueryDetails venDetails,String invoiceNo,
	 *            Boolean status,String nextQryNo, String endurl.
	 * @return GeneralClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass submitQuery(String vendorCode, VendorQueryDetails venDetails, String invoiceNo, Boolean status,
			String nextQryNo, String sessionid, String endurl) {

		long starttime = System.currentTimeMillis();
		logger.debug("submitQuery Method Starts...");
		String SOAP_inxml = "";
		String option = "";
		String prefix = "";
		int padding = 0;
		int result = 0;
		int sessionresult = 0;
		HashMap<String, String> xmlvalues = null;
		String user;
		String masterStatus = null;
		String nextQueryNo = "";
		prefix = ClsMessageHandler.QueryNumberPrefix;
		padding = ClsMessageHandler.QueryNumberLength;
		if (status.equals(true)) {
			masterStatus = "ToBeClosed";
		}
		String statusStr = "";
		if (ClsUtil.isNullOrEmpty(masterStatus)) {
			/* statusStr="Reopened"; */
			statusStr = "Responded";
		} else {
			statusStr = masterStatus;
		}

		Date date = new Date();
		Timestamp timeStamp = new Timestamp(date.getTime());

		String desc = venDetails.getDescription();
		String PONumber = venDetails.getPONumber();
		user = venDetails.getCreatedBy();
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("PrefixStr", prefix);
			xmlvalues.put("Padding", String.valueOf(padding));
			xmlvalues.put("InvoiceNo", invoiceNo);
			xmlvalues.put("PONumber", PONumber);
			xmlvalues.put("vendorCode", vendorCode);
			if (!ClsUtil.isNullOrEmpty(venDetails.getTransactionNo())
					&& !venDetails.getTransactionNo().equalsIgnoreCase("")) {
				xmlvalues.put("TransactionID", venDetails.getTransactionNo());
			} else {
				xmlvalues.put("TransactionID", venDetails.getPoTransactionNo());
			}
			xmlvalues.put("GetQueryNo", venDetails.getQueryNo());
			xmlvalues.put("Users", user);
			xmlvalues.put("timestamps", timeStamp.toString());
			xmlvalues.put("status", statusStr);
			xmlvalues.put("Descrip", desc);
			xmlvalues.put("sessionid", sessionid);
			// Bug 1015851 - Vendor Portal - Query Handling in both client and
			// admin
			if (!ClsUtil.isNullOrEmpty(venDetails.getUserPrivilege())
					&& venDetails.getUserPrivilege().equalsIgnoreCase("1")) {
				option = "ProcedureSubmitAdminReplyQuery";
			} else {
				option = "ProcedureSubmitQuery";

			}
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			ArrayList<String> outptXMLlst = null;
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!outptXMLlst.get(0).equalsIgnoreCase("Session Not Valid")) {
				logger.debug(
						"outptXMLlst.get(0) :: " + outptXMLlst.get(0) + " outptXMLlst.get(1) :: " + outptXMLlst.get(1));
				sessionresult = 1;
				if (!outptXMLlst.get(0).equalsIgnoreCase("NO DATA FOUND")
						&& outptXMLlst.get(1).equalsIgnoreCase("VPQueryMaster updated")) {

					result = 1;
					nextQueryNo = outptXMLlst.get(0);
					logger.debug("Query submitted successfully");
				} else if (outptXMLlst.get(1).equalsIgnoreCase("VPQueryMaster updation failed")) {
					result = 8;
					nextQueryNo = outptXMLlst.get(0);
					logger.debug("Query is Locked with other User, you donnot have right to submit the Query");
				} else {
					result = -1;
					logger.debug("Entered invoice# doesn't exist.");
				}
			} else {
				sessionresult = -1;
				logger.debug("Session Not Valid");
			}
		} catch (Exception e) {
			loggerErr.error("Exception While submitting Query :  " + e.getMessage());
			e.printStackTrace();

		}

		GeneralClass gen = new GeneralClass();
		gen.setQueryNumber(nextQueryNo);
		gen.setResultCode(result);
		gen.setSessionresult(sessionresult);
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Submitting Query is " + totaltime);

		return gen;
	}
}
