/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: UpdateComplexPODetailsDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which updates PO details
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.newgen.bean.ComplexPODetails;
import com.newgen.bean.PODetails;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class UpdateComplexPODetailsDAO implements UpdateComplexPODetailsDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to update PO details.
	 * 
	 * @param Bean,
	 *            endurl.
	 * @return int
	 * @exception Exception
	 */
	@Override
	public int UpdateComplexPO(ComplexPODetails cpo, String endurl, Map<String, String> map,
			StringBuilder strDynamicRows) {

		long starttime = System.currentTimeMillis();
		logger.info("UpdateComplexPO Method Starts...");
		int result = 0;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String DynamicRowSContent = "'" + strDynamicRows.toString().replaceAll("'", "\"") + "'";
		DynamicRowSContent = DynamicRowSContent.replaceAll("<", "&lt;");
		DynamicRowSContent = DynamicRowSContent.replaceAll(">", "&gt;");

		try {
			Properties props = null;
			props = new Properties();
			java.io.File fIni = new java.io.File("WebServiceConsume.ini");
			if (!(fIni.isFile() && fIni.exists())) {
				String message = "NewgenVendorPortal: WebServiceConsume.ini file not present.";
				throw new Exception(message);
			}
			java.io.FileInputStream is = new java.io.FileInputStream(fIni);
			props.load(is);
			String Cabinet = props.getProperty("Cabinet");
			is.close();
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("WIName", cpo.getWIName());
			xmlvalues.put("PONo", cpo.getCPONO());
			xmlvalues.put("DynamicRows", DynamicRowSContent);
			option = "ProcedureUpdateComplexPO";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				if (outptXMLlst.get(0).trim().equalsIgnoreCase("Updated succesfully")) {
					result = 1;
					logger.debug("Complex PO Data Updated succesfully");
				} else {
					result = -1;
					logger.debug("Complex PO Data not Updated");
				}

			}
		} catch (Exception e) {
			loggerErr.error("Exception while Updating Complex PO  : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Updating Complex PO Details is " + totaltime);
		return result;
	}
}
