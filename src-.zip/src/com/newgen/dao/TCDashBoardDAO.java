/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: DashBoardDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.DashBoardBean;
import com.newgen.bean.DashboardStatusBean;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class TCDashBoardDAO {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to get Dashboard DATA.
	 * 
	 * @param String
	 *            VendorCode,String IBPSEndPointURL
	 * @return ArrayList
	 * @exception Exception
	 */
	public GeneralClass getTCDashboardData(String VendorCode, String IBPSEndPointURL, String Cabinet) {
		long starttime = System.currentTimeMillis();
		logger.info("Get DashboardData  Method Starts...");
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		ArrayList<DashBoardBean> arr_dashboard = new ArrayList<DashBoardBean>();
		ArrayList<DashboardStatusBean> arr_dashboardstatus = new ArrayList<DashboardStatusBean>();
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("VendorCode", VendorCode);
			option = "ProcedureTCDashboard";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			logger.info("Get DashboardData SOAP_inxml..." + SOAP_inxml);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);
			logger.info("Get DashboardData outptXMLlst Size----> #####..." + outptXMLlst.size());
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				for (int k = 0; k < outptXMLlst.size(); k++) {
					logger.debug("outptXMLlst.get(" + k + ")-->" + outptXMLlst.get(k));
					String invAmount = "";
					DashBoardBean dashbean = new DashBoardBean();
					dashbean.setStatus(outptXMLlst.get(k));
					dashbean.setCount(outptXMLlst.get(++k));
//					invAmount = outptXMLlst.get(++k);
//
//					if (!ClsUtil.isNullOrEmpty(invAmount))
//						dashbean.setAmount(ClsUtil.thousandFormatter(invAmount));
//					else
//						dashbean.setAmount("0.00");
//					dashbean.setCurrency(outptXMLlst.get(++k));
					arr_dashboard.add(dashbean);
				}
			}

			if (outptXMLlst.size() == 0) {
				logger.info("if no data found in Dashboard Output");
				DashBoardBean dashbean = new DashBoardBean();
				dashbean.setStatus("Total");
				dashbean.setCount("0");
				dashbean.setAmount("0.00");
				dashbean.setCurrency("-");
				arr_dashboard.add(dashbean);
			}

//			String SOAP_inxmlS = "";
//			String optionS = "";
//			HashMap<String, String> xmlvaluesS = null;
//			ArrayList<String> outptXMLlstS = null;
//			xmlvaluesS = new HashMap<String, String>();
//			xmlvaluesS.put("VendorCode", VendorCode);
//			optionS = "ProcedureDashboardRejectedStatus";
//			SOAP_inxmlS = GenerateXML.generatexml(xmlvaluesS, optionS, Cabinet);
//			logger.info("Get ProcedureDashboardRejectedStatus SOAP_inxmlS..." + SOAP_inxmlS);
//			// Webservice call
//			outptXMLlstS = Execute_WebService.executeWebservice(SOAP_inxmlS, IBPSEndPointURL);
//			logger.info("Get ProcedureDashboardRejectedStatus outptXMLlstS Size----> #####..." + outptXMLlstS.size());
//			logger.debug(
//					"Get ProcedureDashboardRejectedStatus outptXMLlstS Size----> #####..." + outptXMLlstS.size());
//			if (!ClsUtil.isNullOrEmpty(outptXMLlstS) && outptXMLlstS.size() > 0) {
//				for (int k = 0; k < outptXMLlstS.size(); k++) {
//					logger.debug("outptXMLlstS.get(" + k + ")-->" + outptXMLlstS.get(k));
//					String invAmount = "";
//					DashboardStatusBean dashSbean = new DashboardStatusBean();
//					dashSbean.setStatus(outptXMLlstS.get(k));
//					dashSbean.setInvoiceno(outptXMLlstS.get(++k));
//					dashSbean.setTransactionid(outptXMLlstS.get(++k));
//					dashSbean.setRejectedreason(outptXMLlstS.get(++k));
//					invAmount = outptXMLlstS.get(++k);
//					if (!ClsUtil.isNullOrEmpty(invAmount))
//						dashSbean.setInvoiceamount(ClsUtil.thousandFormatter(invAmount));
//					else
//						dashSbean.setInvoiceamount("0.00");
//					dashSbean.setCurrency(outptXMLlstS.get(++k));
//					arr_dashboardstatus.add(dashSbean);
//				}
//			}
//
//			if (outptXMLlstS.size() == 0) {
//				logger.info("if no data found in Dashboard Output");
//				DashboardStatusBean dashSbean = new DashboardStatusBean();
//				dashSbean.setStatus("Rejected");
//				dashSbean.setInvoiceno("-");
//				dashSbean.setTransactionid("-");
//				dashSbean.setRejectedreason("-");
//				dashSbean.setInvoiceamount("0.00");
//				dashSbean.setCurrency("-");
//				arr_dashboardstatus.add(dashSbean);
//			}

		} catch (Exception e) {
			e.printStackTrace();
			loggerErr.error("Exception while getting DashboardData : " + e.getMessage());
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting DashboardData is " + totaltime);

		GeneralClass gen = new GeneralClass();
		logger.debug("Dashboard Data === " + arr_dashboard + " DashboardStatus Data === " + arr_dashboardstatus);
		gen.setArrayDashBoardBean(arr_dashboard);
		gen.setArrayDashboardStatusBean(arr_dashboardstatus);
		return gen;
	}
}