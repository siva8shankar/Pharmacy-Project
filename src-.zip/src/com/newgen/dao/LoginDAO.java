/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: LoginDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserMaster;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class LoginDAO {
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static Logger logger = Logger.getLogger("consoleLogger");

	public String loginGetPwd(String EnterUserName, String EndPointurl) {
		long starttime = System.currentTimeMillis();
		logger.debug("loginGetPwd Method Starts...EnterUserName" + EnterUserName);
		String SOAP_inxml = "";
		String option = "";
		String result = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("EnterUserName", EnterUserName);
			option = "ProcedureLoginGetPwd";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, EndPointurl);
			logger.debug("outptXMLlst =====" + outptXMLlst);
			if (outptXMLlst != null && outptXMLlst.size() > 0) {
				if (outptXMLlst.get(0).equalsIgnoreCase("No Data Exist")) {
					result = "No Data Exist";
					logger.debug("No Data Exist");
				} else {
					result = outptXMLlst.get(0).trim();
					logger.debug("Got password ::" + result);
				}
			}
		} catch (Exception e) {
			loggerErr.error("Exception in loginGetPwd  User : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in loginGetPwd  User is " + totaltime);
		return result;
	}

	public VPUserMaster checklogin(String EnterUserName, String dcryptedpwd, String SessionId, String EndPointurl) {
		long starttime = System.currentTimeMillis();
		logger.debug("checklogin Method Starts...");
		String SOAP_inxml = "";
		String option = "";

		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		VPUserMaster userMasterbean = new VPUserMaster();
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("EnterUserName", EnterUserName);
			xmlvalues.put("DecryptPassword", dcryptedpwd);
			xmlvalues.put("UserSessionId", SessionId);

			option = "ProcedureLogin";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, EndPointurl);
			if (outptXMLlst != null && outptXMLlst.size() > 0) {
				if (outptXMLlst.size() > 2) {

					logger.debug("checklogin Method Starts...outptXMLlst");
					userMasterbean.setUserName(outptXMLlst.get(0));
					userMasterbean.setPrivilege(outptXMLlst.get(1));
					userMasterbean.setActivationCode(outptXMLlst.get(2));
					userMasterbean.setVendorCode(outptXMLlst.get(3));
					userMasterbean.setVendorName(outptXMLlst.get(4));
					userMasterbean.setVendorAddress(outptXMLlst.get(5));
					userMasterbean.setIncorrectLoginAttempt(outptXMLlst.get(6));

					userMasterbean.setUserEmailId(outptXMLlst.get(7));
					userMasterbean.setMsgCode(outptXMLlst.get(8));
					userMasterbean.setJspPage(outptXMLlst.get(9));
					logger.debug("User loggedin Successfully...");
				} else {
					userMasterbean.setMsgCode(outptXMLlst.get(0));
					userMasterbean.setJspPage(outptXMLlst.get(1));
				}
			}
		} catch (Exception e) {
			userMasterbean = null;
			loggerErr.error("Exception in checklogin  User : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in checklogin  User is " + totaltime);
		return userMasterbean;
	}

}
