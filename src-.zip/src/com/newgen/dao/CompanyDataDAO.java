/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: CompanyDataDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations i.e UPDATE & SELECT
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class CompanyDataDAO implements CompanyDataDAOI {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to get company data i.e. company name, company
	 * address & company code.
	 * 
	 * @param String
	 *            UserName, String endurl.
	 * @return HashMap<String, ArrayList<String>>
	 * @exception Exception
	 */
	@Override
	public HashMap<String, ArrayList<String>> GetCompanyData(String UserName, String endurl) {

		long starttime = System.currentTimeMillis();
		logger.debug("GetCompanyData Method Starts...");
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> companyDataArr = null;
		ArrayList<String> outptXMLlst = null;

		LinkedHashMap<String, ArrayList<String>> CompanyDataMap = new LinkedHashMap<String, ArrayList<String>>();

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", UserName);
			option = "ProcedureGetCompanyData";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				for (int k = 0; k < outptXMLlst.size(); k++) {
					String companyName = null;
					companyDataArr = new ArrayList<String>();
					companyName = outptXMLlst.get(k);
					companyDataArr.add(outptXMLlst.get(++k));
					companyDataArr.add(outptXMLlst.get(++k));
					CompanyDataMap.put(companyName, companyDataArr);

				}
				for (Map.Entry<String, ArrayList<String>> entry : CompanyDataMap.entrySet()) {
					logger.debug(entry.getKey() + "/" + entry.getValue());

					for (int o = 0; o < entry.getValue().size(); o++) {
						logger.debug(entry.getKey() + "/" + entry.getValue());

					}

				}
				logger.debug("Got Company Data Successfully");
			}
		} catch (Exception e) {
			loggerErr.error("Exception While Generating Company Data : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Generating Company Data ..." + totaltime);

		return CompanyDataMap;

	}

}