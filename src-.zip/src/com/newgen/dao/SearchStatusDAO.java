/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SearchStatusDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  This is a Data access object class which provides status of query
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)             
*  01-Sep-201					 by ksivashankar 					 Reports Generation with respective to Deloitte Cabinet External tablel fields.
*  09/01/2018						ksivashankar 					Bug 1023801 - Vendor Portal - Reports Tab - Data is not shown
************************************************************************************************/

package com.newgen.dao;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.ReportsBean;
import com.newgen.bean.VPReportMaster;
import com.newgen.bean.VPUserMasterBean;
import com.newgen.bean.VendorQueryDetails;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class SearchStatusDAO implements SearchStatusDAOI {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	SimpleDateFormat sdf1 = new SimpleDateFormat(ClsMessageHandler.XMLDateFormat);
	SimpleDateFormat dt1 = new SimpleDateFormat(ClsMessageHandler.MainDateFormat);

	/**
	 * This Method is used to get Query Details.
	 * 
	 * @param VendorQueryDetails
	 *            venDetails, String archive, String endurl
	 * @return ArrayList<VendorQueryDetails>
	 * @exception Exception
	 */
	@Override
	public GeneralClass searchQueryDetails(String priviledge, VendorQueryDetails venDetails, String archive,
			String sessionid, String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("Getting Query Details");
		VendorQueryDetails venDetailsData = null;
		int result = 0;
		GeneralClass gen = new GeneralClass();
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String queryNo = venDetails.getQueryNo();
		ArrayList<VendorQueryDetails> arr_queryDetail = new ArrayList<VendorQueryDetails>();
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Queryno", queryNo);
			xmlvalues.put("userName", venDetails.getCreatedBy());
			xmlvalues.put("sessionid", sessionid);
			option = "ProcedureSearchQueryDetail";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			outptXMLlst = new ArrayList<String>();
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				if (!outptXMLlst.get(0).equalsIgnoreCase("Session Not Valid")) {
					result = 1;
					for (int k = 0; k < outptXMLlst.size(); k++) {

						venDetailsData = new VendorQueryDetails();
						venDetailsData.setQueryNo(outptXMLlst.get(k));
						venDetailsData.setDescription(outptXMLlst.get(++k));
						venDetailsData.setQueryType(outptXMLlst.get(++k));
						venDetailsData.setCreatedBy(outptXMLlst.get(++k));

						String str_CreateDate = outptXMLlst.get(++k);
						Date date = sdf1.parse(str_CreateDate);
						SimpleDateFormat dt2 = new SimpleDateFormat("HH:mm:ss");
						String str_createdDate = dt1.format(date).toString() + " " + dt2.format(date).toString();
						venDetailsData.setCreatedDate(str_createdDate);
						venDetailsData.setQueryStatus(outptXMLlst.get(++k));
						venDetailsData.setLockedBy(outptXMLlst.get(++k));
						arr_queryDetail.add(venDetailsData);
					}
				} else {
					result = -1;
					logger.debug("Session Not Valid");
				}
			}
		} catch (Exception e) {
			loggerErr.error("Exception in Search Query Details : " + e.getMessage());
			e.printStackTrace();
		}

		gen.setArrayQueryDetails(arr_queryDetail);
		gen.setSessionresult(result);
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Search Query Details  is " + totaltime);

		return gen;
	}

	/**
	 * This Method is used to search list of Queries based on different
	 * criteria.
	 * 
	 * @param VendorQueryMaster
	 *            venMaster,GeneralClass gen, String archive, String
	 *            statusQuery, String endurl
	 * @return GeneralClass
	 * @exception Exception
	 */
	public GeneralClass searchQuery(VendorQueryMaster venMaster, GeneralClass gen, String archive, String statusQuery,
			String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("searchQuery Method Starts...");

		ArrayList<VendorQueryMaster> arr_Query = new ArrayList<VendorQueryMaster>();
		String invoiceNo;
		VendorQueryMaster queryMaster = null;

		String queryNo = venMaster.getQueryNo();
		Timestamp dateFrom = null;
		Timestamp dateTo = null;
		String userName = venMaster.getCreatedBy();
		invoiceNo = venMaster.getInvoiceNo();
		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();

		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		int priviledge = Integer.parseInt(gen.getPriviledge());
		String VendorCode = gen.getVendorCode();
		String SOAP_inxml = "";
		String option = "";
		String str_todate = "";
		String str_frdate = "";

		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		if (ClsUtil.isNullOrEmpty(queryNo) && ClsUtil.isNullOrEmpty(invoiceNo)) {
			if (queryNo == null)
				queryNo = "";
			if (invoiceNo == null)
				invoiceNo = "";
			dateFrom = new Timestamp(venMaster.getFromDate().getTime());
			dateTo = new Timestamp(venMaster.getToDate().getTime() + (1000 * 60 * 60 * 24));
		}
		if (!ClsUtil.isNullOrEmpty(dateTo) && !ClsUtil.isNullOrEmpty(dateFrom)) {
			str_todate = dateTo.toString();
			str_frdate = dateFrom.toString();
		} else {
			str_todate = "";
			str_frdate = "";
		}

		// Pagination
		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastQryNo;
		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}

		try {

			if (!ClsUtil.isNullOrEmpty(queryNo)) {

				logger.debug(" Search Status of Query when queryNo is : " + queryNo);

			} else if (!ClsUtil.isNullOrEmpty(invoiceNo)) {
				logger.debug(" Search Status of Query when invoiceNo is : " + invoiceNo);

			} else {
				logger.debug(" Search Status of Query when dateFrom : " + dateFrom + " and dateTo : " + dateTo);

			}

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("queryNo", queryNo);
			xmlvalues.put("statusQuery", statusQuery);
			xmlvalues.put("invoiceNo", invoiceNo);
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("Previlege", String.valueOf(priviledge));
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("userName", userName);
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("dateTo", str_todate);
			xmlvalues.put("dateFrom", str_frdate);

			option = "ProcedureSelectQueryRecord";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				int j = 0;
				paginationTopQryNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					queryMaster = new VendorQueryMaster();
					queryMaster.setQueryNo(outptXMLlst.get(k));
					queryMaster.setStatus(outptXMLlst.get(++k));
					queryMaster.setInvoiceNo(outptXMLlst.get(++k));
					queryMaster.setPONumber(outptXMLlst.get(++k));
					queryMaster.setOtherId(outptXMLlst.get(++k));
					queryMaster.setCreatedBy(outptXMLlst.get(++k));
					queryMaster.setCreatedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
					queryMaster.setModifiedBy(outptXMLlst.get(++k));
					queryMaster.setModifiedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
					queryMaster.setLockedstatus(outptXMLlst.get(++k));
					queryMaster.setLockedby(outptXMLlst.get(++k));
					String Lokedtime = outptXMLlst.get(++k);
					if (!Lokedtime.equalsIgnoreCase("null") && !Lokedtime.equalsIgnoreCase("")) {
						queryMaster.setLockedtime(ClsConvertDate.ConvertxmlDatetostring(Lokedtime));
					} else {
						queryMaster.setLockedtime("");
					}
					arr_Query.add(queryMaster);
					j = k + 1;
				}
				paginationLastQryNo = queryMaster.getQueryNo();
				prevRecordFlag = outptXMLlst.get(j++);
				lastRecordFlag = outptXMLlst.get(j);

			}

		} catch (Exception e) {
			prevRecordFlag = "first";
			lastRecordFlag = "last";
			loggerErr.error("Exception in Search Query : " + e.getMessage());
			e.printStackTrace();

		}
		gen = new GeneralClass();
		gen.setArrayQueryMaster(arr_Query);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;

		logger.debug("Total Time Taken in Search Query is " + totaltime);

		return gen;
	}

	/**
	 * This Method is used to search list of Invoice based on different
	 * criteria.
	 * 
	 * @param GeneralClass
	 *            gen, InvoiceDetails invoice,String archive, String endurl
	 * @return GeneralClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass searchInvoice(GeneralClass gen, InvoiceNewDetails invoice, String archive, String endurl,
			String Cabinet) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("searchInvoice Method Starts...");
		String invoiceNo;
		Timestamp dateFrom = null;
		Timestamp dateTo = null;
		InvoiceNewDetails invmaster = null;
		String userName = invoice.getInvoiceCreatedBy();
		String invoiceId = null;

		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();
		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		String[] arrStatus = new String[1000];
		String[] arrDocumentIDs = new String[1000];
		HashMap<String, InvoiceNewDetails> map_invoice = new HashMap<String, InvoiceNewDetails>();
		ArrayList<InvoiceNewDetails> arr = new ArrayList<InvoiceNewDetails>();
		String VendorCode = gen.getVendorCode();
		int Privilege = Integer.parseInt(gen.getPriviledge());

		String str_todate = "";
		String str_frdate = "";

		invoiceNo = invoice.getInvoiceno();
		if (ClsUtil.isNullOrEmpty(invoiceNo))
			invoiceNo = "";

		if (!ClsUtil.isNullOrEmpty(invoice.getFromDate()) && !ClsUtil.isNullOrEmpty(invoice.getToDate())) {
			dateFrom = new Timestamp(invoice.getFromDate().getTime());
			dateTo = new Timestamp(invoice.getToDate().getTime() + (1000 * 60 * 60 * 24));
			str_todate = dateTo.toString();
			str_frdate = dateFrom.toString();
		}

		else {
			str_todate = "";
			str_frdate = "";
		}

		// Pagination
		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastQryNo;

		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}

		String SOAP_inxml = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String option = "";
		try {
			xmlvalues = new HashMap<String, String>();
			if (!ClsUtil.isNullOrEmpty(invoiceNo)) {
				logger.debug(" Invoice Records when invoice no is : " + invoiceNo);

			} else {
				logger.debug(" Invoice Records when dateFrom & dateTo is : " + dateFrom + dateTo);

			}
			xmlvalues.put("invoiceNo", invoiceNo);
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("Previlege", String.valueOf(Privilege));
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("userName", userName);
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("dateTo", str_todate);
			xmlvalues.put("dateFrom", str_frdate);
			option = "ProcedureSelectInvoiceRecord";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				int j = 0;
				paginationTopQryNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					invmaster = new InvoiceNewDetails();
					invoiceId = outptXMLlst.get(k);
					invmaster.setInvoiceId(Integer.parseInt(invoiceId));

					invmaster.setInvoiceno(outptXMLlst.get(++k));

					String totalInvoiceAmount = outptXMLlst.get(++k);
					String I_value_check = new String("0.00");
					logger.debug(
							"Total Invoice Amount" + totalInvoiceAmount.length() + "  " + I_value_check.length());

					if (ClsUtil.isNullOrEmpty(totalInvoiceAmount) || totalInvoiceAmount == "0") {

						invmaster.setInvoiceAmount("0");
					} else if (totalInvoiceAmount.equalsIgnoreCase(I_value_check)) {
						invmaster.setInvoiceAmount("0.00");
					}

					else {
						logger.debug("Total Invoice Amount in else" + totalInvoiceAmount);

						invmaster.setInvoiceAmount(ClsUtil.thousandFormatter(totalInvoiceAmount));
					}
					invmaster.setCurrency(outptXMLlst.get(++k));
					String str_createdate = outptXMLlst.get(++k);
					invmaster.setInvoiceCreatedDate(ClsConvertDate.ConvertxmlDatetostring(str_createdate));
					invmaster.setTransactionId(outptXMLlst.get(++k));
					String duedate = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(duedate)) {
						duedate = "-";
					} else {
						duedate = ClsConvertDate.ConvertxmlDatetostring(duedate);
					}
					invmaster.setDueDate(duedate);
					map_invoice.put(invoiceId, invmaster);
					arr.add(invmaster);
					j = k + 1;
				}
				paginationLastQryNo = invoiceId;
				prevRecordFlag = outptXMLlst.get(j++);
				lastRecordFlag = outptXMLlst.get(j);

				String[] CaseNumberArr = null;
				String strCaseNumber = "";
				String strStatus = "";
				String strDocumentIDs = "";
				CaseNumberArr = new String[1000];

				if (arr.size() > 0) {
					for (int i = 0; i < arr.size(); i++) {
						CaseNumberArr[i] = arr.get(i).getTransactionId();
						strCaseNumber += CaseNumberArr[i] + ",";
					}
					logger.debug("Output strCaseNumber--->" + strCaseNumber);
					xmlvalues.clear();
					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureSelect2";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strStatus = outptXMLlst.get(0);
							arrStatus = strStatus.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrStatus[i] = "NO STATUS";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting status  : " + e.getMessage());

					}

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureSelectDocumentID";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strDocumentIDs = outptXMLlst.get(0);
							arrDocumentIDs = strDocumentIDs.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrDocumentIDs[i] = "NO DocumentID";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting DocumentID  : " + e.getMessage());

					}
				}

			}
		} catch (Exception e) {
			loggerErr.error("Exception in Search Invoice" + e.getMessage());
			e.printStackTrace();
			prevRecordFlag = "first";
			lastRecordFlag = "last";
		}
		gen = new GeneralClass();
		logger.debug("map_invoice is " + map_invoice);
		gen.setMap(map_invoice);
		gen.setArrStatus(arrStatus);
		gen.setArrayDocumentIDs(arrDocumentIDs);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Search Invoice is " + totaltime);

		return gen;
	}

	/**
	 * This Method is used to get the status of a Query Number.
	 * 
	 * @param queryNo
	 *            , endurl.
	 * @return Integer
	 * @exception Exception
	 */
	@Override
	public int getQueryStatus(String queryNo, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("getQueryStatus Method Starts...");
		int result = 0;

		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("QueryNo", queryNo);
			option = "ProcedureQueryStatus";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				if (outptXMLlst.get(0).equalsIgnoreCase("Closed") || outptXMLlst.get(0).equalsIgnoreCase("InProcess")
						|| outptXMLlst.get(0).equalsIgnoreCase("ToBeClosed")) {
					result = 1;
				}
				logger.debug("Got Query Status Successfully");
			}
		} catch (Exception e) {
			loggerErr.error("Exception While fetching status  : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken while fetching status is " + totaltime);

		return result;
	}

	/**
	 * This Method is used to export User Master Report.
	 * 
	 * @param VPUserMasterBean
	 *            VPUserMasterBean usermasterBean,String endurl.
	 * @return StringBuffer
	 * @exception Exception
	 */
	@Override

	public StringBuffer exportUserMaster(VPUserMasterBean usermasterBean, String iBPSurl) {
		logger.debug("exportUserMaster Method Starts...");
		StringBuffer exportData = new StringBuffer("");
		logger.debug("Header from bean --->" + usermasterBean.getHeader());
		logger.debug("In exportInvoice usermasterbean.getHeader().length()" + usermasterBean.getHeader().length());
		String[] head = new String[usermasterBean.getHeader().length()];
		head = usermasterBean.getHeader().split(",");// Comma
		String SOAP_inxml = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String option = "";
		xmlvalues = new HashMap<String, String>();
		xmlvalues.put("header", usermasterBean.getHeader());
		logger.debug(xmlvalues.toString());
		option = "ProcedureExportUserReport";
		SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
		logger.debug("Input is -->" + SOAP_inxml.toString());
		// Webservice call
		outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, iBPSurl);
		logger.debug("Output is -->" + outptXMLlst.toString());

		try {
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 1) {
				for (int k = 0; k < (outptXMLlst.size() - 1); k++) {
					for (int j = 0; j < head.length; j++) {
						if (outptXMLlst.get(k) == null || outptXMLlst.get(k) == ""
								|| outptXMLlst.get(k).equalsIgnoreCase("NULL")) {
							if (head[j].equalsIgnoreCase("VendorTAN")) {
								exportData.append("---" + usermasterBean.getFieldDelimiter());
							} else if (head[j].equalsIgnoreCase("VendorPAN")) {
								exportData.append("---" + usermasterBean.getFieldDelimiter());
							} else if (head[j].equalsIgnoreCase("VendorTIN")) {
								exportData.append("---" + usermasterBean.getFieldDelimiter());
							} else if (head[j].equalsIgnoreCase("VendorSRNo")) {
								exportData.append("---" + usermasterBean.getFieldDelimiter());
							} else {
								exportData.append("------" + usermasterBean.getFieldDelimiter());
							}
							k++;
						} else {
							exportData.append(outptXMLlst.get(k++) + usermasterBean.getFieldDelimiter());
						}
					}
					k--;
					exportData.append(usermasterBean.getRowDelimiter());
				}
			}
		}

		catch (Exception e) {
			loggerErr.error("Exception While exporting Userlist  : " + e.getMessage());
			e.printStackTrace();

		}
		return exportData;

	}

	/**
	 * This Method is used to export Invoice Report.
	 * 
	 * @param InvoiceDetails
	 *            invoice, String archive, VPReportMaster reportBean, String
	 *            priviledge,String endurl.
	 * @return StringBuffer
	 * @exception Exception
	 */
	@Override
	public StringBuffer exportInvoice(InvoiceNewDetails invoice, String archive, VPReportMaster reportBean,
			String priviledge, String iBPSurl, String cabinet) {
		long starttime = System.currentTimeMillis();
		logger.debug("exportInvoice Method Starts...");
		String invoiceNo;
		Timestamp dateFrom = null;
		Timestamp dateTo = null;
		String userName = invoice.getInvoiceCreatedBy();
		StringBuffer exportData = new StringBuffer("");
		invoiceNo = invoice.getInvoiceno();

		if (ClsUtil.isNullOrEmpty(invoiceNo)) {
			invoiceNo = "";

		}
		logger.debug("invoiceNo---" + invoiceNo);
		logger.debug("userName---" + userName);
		logger.debug("FromDate---" + invoice.getFromDate());
		logger.debug("ToDate---" + invoice.getToDate());
		logger.debug("iBPSurl---" + iBPSurl);
		logger.debug("cabinet---" + cabinet);
		logger.debug("Vendorccode----" + invoice.getVendorno());

		logger.debug("In exportInvoice reportBean.getHeader().length()" + reportBean.getExportHeader().length());

		String[] head = new String[reportBean.getExportHeader().length()];

		String strHeaderMask = reportBean.getExportHeader().replace("','", "@");

		head = strHeaderMask.split(",");// Comma
		String SOAP_inxml = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String option = "";
		String str_todate = "";
		String str_frdate = "";

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("invoiceNo", invoiceNo);
			xmlvalues.put("Previlege", String.valueOf(priviledge));
			xmlvalues.put("VendorCode", invoice.getVendorno());
			xmlvalues.put("userName", userName);
			if (!ClsUtil.isNullOrEmpty(invoice.getFromDate()) && !ClsUtil.isNullOrEmpty(invoice.getToDate())) {
				dateFrom = new Timestamp(invoice.getFromDate().getTime());
				dateTo = new Timestamp(invoice.getToDate().getTime() + (1000 * 60 * 60 * 24));
				str_todate = dateTo.toString();
				str_frdate = dateFrom.toString();
			} else {
				str_todate = "";
				str_frdate = "";
			}
			logger.debug("str_todate-->" + str_todate);
			logger.debug("str_frdate-->" + str_frdate);

			xmlvalues.put("dateTo", str_todate);
			xmlvalues.put("dateFrom", str_frdate);
			xmlvalues.put("header", reportBean.getHeader());
			option = "ProcedureExportReport";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, cabinet);
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, iBPSurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 1) {
				logger.debug(" outptXMLlst.size() --> " + outptXMLlst.size());
				for (int k = 0; k < (outptXMLlst.size() - 1); k++) {
					logger.debug(" head.length --> " + head.length);
					for (int j = 0; j < head.length; j++) {
						logger.debug("  head[j] --> " +  head[j]);
						if (head[j] != null && head[j].indexOf("Date") == -1) {
							logger.debug("  Inside not Date "+outptXMLlst.get(k));
							if (outptXMLlst.get(k) == null || outptXMLlst.get(k) == ""
									|| outptXMLlst.get(k).equalsIgnoreCase("NULL")) {
								if (head[j].equalsIgnoreCase("physicalcopyrec")) {
									exportData.append("No" + reportBean.getFieldDelimiter());
								} else if (head[j].equalsIgnoreCase("Rejection_Status")) {
									exportData.append(" " + reportBean.getFieldDelimiter());
								} else if (head[j].equalsIgnoreCase("Comments")) {
									exportData.append(" " + reportBean.getFieldDelimiter());
								} else {
									exportData.append("------" + reportBean.getFieldDelimiter());
								}
								k++;
							} else if (head[j].equalsIgnoreCase("invoicedate")) {
								exportData.append(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(k++))
										+ reportBean.getFieldDelimiter());
							} else if (head[j].equalsIgnoreCase("invoiceamount")) {
								exportData.append(ClsUtil.thousandFormatter(outptXMLlst.get(k++))
										+ reportBean.getFieldDelimiter());
							} else {
								exportData.append(outptXMLlst.get(k++) + reportBean.getFieldDelimiter());
							}
						} else {
							String tempStr= outptXMLlst.get(k++);
							logger.debug("  Inside Date "+tempStr);
							if(!ClsUtil.isNullOrEmpty(tempStr)){
								exportData.append(tempStr
										+ reportBean.getFieldDelimiter());
							}else{
								exportData.append("------" + reportBean.getFieldDelimiter());
							}
							
						}
					}
					k--;
					exportData.append(reportBean.getRowDelimiter());
				}
			}
		} catch (Exception e) {
			loggerErr.error("Exception While exporting invoice  : " + e.getMessage());
			e.printStackTrace();

		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in exporting invoice is " + totaltime);
		return exportData;
	}

	/**
	 * This Method is used to export Query Report.
	 * 
	 * @param VendorQueryMaster
	 *            venMaster, String archive, String statusQuery, VPReportMaster
	 *            reportBean, String priviledge, String VendorCode,String endurl
	 * @return StringBuffer
	 * @exception Exception
	 */
	@Override
	public StringBuffer exportQuery(VendorQueryMaster venMaster, String archive, String statusQuery,
			VPReportMaster reportBean, String priviledge, String VendorCode, String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("exportInvoice Method Starts...");
		String invoiceNo = venMaster.getInvoiceNo();
		Timestamp dateFrom = null;
		Timestamp dateTo = null;
		String queryNo = venMaster.getQueryNo();
		String userName = venMaster.getCreatedBy();

		StringBuffer exportData = new StringBuffer("");
		if (ClsUtil.isNullOrEmpty(invoiceNo)) {
			invoiceNo = "";
		}

		if (ClsUtil.isNullOrEmpty(queryNo)) {
			queryNo = "";
		}
		String[] head = new String[reportBean.getHeader().length()];
		head = reportBean.getHeader().split(",");
		String SOAP_inxml = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String option = "";
		String str_todate = "";
		String str_frdate = "";
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("queryNo", queryNo);
			xmlvalues.put("statusQuery", statusQuery);
			xmlvalues.put("invoiceNo", invoiceNo);
			xmlvalues.put("Previlege", String.valueOf(priviledge));
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("userName", userName);
			if (!ClsUtil.isNullOrEmpty(venMaster.getFromDate()) && !ClsUtil.isNullOrEmpty(venMaster.getToDate())) {
				dateFrom = new Timestamp(venMaster.getFromDate().getTime());
				dateTo = new Timestamp(venMaster.getToDate().getTime() + (1000 * 60 * 60 * 24));
				str_todate = dateTo.toString();
				str_frdate = dateFrom.toString();
			} else {
				str_todate = "";
				str_frdate = "";
			}
			xmlvalues.put("dateTo", str_todate);
			xmlvalues.put("dateFrom", str_frdate);
			xmlvalues.put("header", reportBean.getHeader());

			option = "ProcedureSelectQueryExport";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 1) {
				for (int k = 0; k < (outptXMLlst.size() - 1); k++) {
					for (int j = 0; j < head.length; j++) {
						if (head[j] != null && head[j].indexOf("Date") == -1) {
							if (outptXMLlst.get(k) == null || outptXMLlst.get(k) == ""
									|| outptXMLlst.get(k).equalsIgnoreCase("NULL")) {
								exportData.append("  ------" + reportBean.getFieldDelimiter());
								k++;
							} else
								exportData.append(outptXMLlst.get(k++) + reportBean.getFieldDelimiter());
						} else {
							exportData.append(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(k++))
									+ reportBean.getFieldDelimiter());
						}
					}
					k--;
					exportData.append(reportBean.getRowDelimiter());
				}
			}
		} catch (Exception e) {
			loggerErr.error("Exception While exporting Query  : " + e.getMessage());
			e.printStackTrace();

		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in exporting Query is " + totaltime);
		return exportData;
	}

	@SuppressWarnings("unused")
	@Override
	public GeneralClass searchInvoice(InvoiceNewDetails invoice, GeneralClass gen, String sessionid, String endurl,
			String IBPSEndPointURL, String Cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("Inside SearchStatusDAO..searchInvoice Method Starts...");
		String invoiceNo;
		Timestamp dateFrom = null;
		Timestamp dateTo = null;
		InvoiceNewDetails myInvoiceMaster = null;
		String userName = invoice.getInvoiceCreatedBy();
		String invoiceId = null;
		int result = 0;

		ArrayList<InvoiceNewDetails> arr = new ArrayList<InvoiceNewDetails>();

		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();
		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		String[] arrStatus = new String[1000];
		int bufferSize = gen.getBatchSize();
		HashMap<String, InvoiceNewDetails> map_invoice = new HashMap<String, InvoiceNewDetails>();
		String VendorCode = gen.getVendorCode();
		int Privilege = Integer.parseInt(gen.getPriviledge());

		String str_todate = "";
		String str_frdate = "";

		invoiceNo = invoice.getInvoiceno();
		if (ClsUtil.isNullOrEmpty(invoiceNo))
			invoiceNo = "";

		if (!ClsUtil.isNullOrEmpty(invoice.getFromDate()) && !ClsUtil.isNullOrEmpty(invoice.getToDate())) {
			dateFrom = new Timestamp(invoice.getFromDate().getTime());
			dateTo = new Timestamp(invoice.getToDate().getTime() + (1000 * 60 * 60 * 24));
			str_todate = dateTo.toString();
			str_frdate = dateFrom.toString();
		}

		else {
			str_todate = "";
			str_frdate = "";
		}

		// Pagination
		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastQryNo;

		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}

		String SOAP_inxml = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String option = "";
		try {
			xmlvalues = new HashMap<String, String>();
			if (!ClsUtil.isNullOrEmpty(invoiceNo)) {
				logger.debug(" Invoice Records when invoice no is : " + invoiceNo);

			} else {
				logger.debug(" Invoice Records when dateFrom & dateTo is : " + dateFrom + dateTo);

			}

			logger.debug(" invoiceNo : " + invoiceNo);
			logger.debug(" paginationSql : " + paginationSql);
			logger.debug(" Linktype : " + gen.getLinkType());
			logger.debug(" Previlege " + String.valueOf(Privilege));
			logger.debug(" VendorCode " + VendorCode);
			logger.debug(" userName " + userName);
			logger.debug(" Buffersize " + String.valueOf(bufferSize));
			logger.debug(" dateTo " + str_todate);
			logger.debug(" dateFrom " + str_frdate);

			xmlvalues.put("invoiceNo", invoiceNo);
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("Previlege", String.valueOf(Privilege));
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("userName", userName);
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("dateTo", str_todate);
			xmlvalues.put("dateFrom", str_frdate);
			option = "ProcedureSelectInvoiceRecord";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (outptXMLlst.size() > 0 && !ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug("SearchStatusDAO size===============>" + outptXMLlst.size());
				logger.debug("SearchStatusDAO get(0)===============>" + outptXMLlst.get(0));
				// if (!outptXMLlst.get(0).equalsIgnoreCase("Session Not
				// Valid"))
				// {
				result = 1;
				int j = 0;
				// paginationTopQryNo = outptXMLlst.get(1);
				paginationTopQryNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					invoiceId = outptXMLlst.get(k);
					logger.debug("Data---->" + outptXMLlst.get(k));
					myInvoiceMaster = new InvoiceNewDetails();
					myInvoiceMaster.setInvoiceId(Integer.parseInt(invoiceId));
					myInvoiceMaster.setInvoiceno(outptXMLlst.get(++k));
					// myInvoiceMaster.setInvoiceNumberInSystem(outptXMLlst.get(++k));
					String totalInvoiceAmount = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(totalInvoiceAmount)) {
						myInvoiceMaster.setInvoiceAmount("0");
					} else {
						myInvoiceMaster.setInvoiceAmount(totalInvoiceAmount);
					}
					myInvoiceMaster.setCurrency(outptXMLlst.get(++k));
					myInvoiceMaster.setInvoiceCreatedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
					myInvoiceMaster.setTransactionId(outptXMLlst.get(++k));
					arr.add(myInvoiceMaster);
					j = k + 1;
				}
				paginationLastQryNo = invoiceId;
				prevRecordFlag = outptXMLlst.get(j++);
				lastRecordFlag = outptXMLlst.get(j);

				String[] CaseNumberArr = null;
				String strCaseNumber = "";
				String strStatus = "";
				CaseNumberArr = new String[1000];
				for (int i = 0; i < arr.size(); i++) {
					CaseNumberArr[i] = arr.get(i).getTransactionId();
					strCaseNumber += CaseNumberArr[i] + ",";
				}
				logger.debug("In SearchStatusDAO...Output strCaseNumber--->" + strCaseNumber);
				xmlvalues.clear();

				try {
					xmlvalues.put("Field1", strCaseNumber);
					String statusOption = "ProcedureSelect2";
					SOAP_inxml = "";
					SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
					outptXMLlst.clear();
					outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

					if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
						strStatus = outptXMLlst.get(0);
						arrStatus = strStatus.split(",");
					} else {
						for (int i = 0; i < 10; i++) {
							arrStatus[i] = "NO STATUS";
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					loggerErr.error("Exception while getting status  : " + e.getMessage());
				}
				// }
				// else{
				// result = -1;
				// logger.debug("Session Not Valid");
				// }
			}
		} catch (Exception e) {
			loggerErr.error("Exception in getting StatusStatus DAO  : " + e.getMessage());
			e.printStackTrace();
		}

		gen = new GeneralClass();
		gen.setSessionresult(result);
		gen.setArrStatus(arrStatus);
		gen.setArrayInvoiceMaster(arr);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		// gen.setMap(map_invoice);
		// gen.setPrevRecordFlag(prevRecordFlag);
		// gen.setLastRecordFlag(lastRecordFlag);
		// gen.setPaginationTopQryNo(paginationTopQryNo);
		// gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in My Invoices is " + totaltime);

		return gen;
	}

	// Bug 1023801
	@Override
	public GeneralClass getReportDetails(ReportsBean report, GeneralClass gen, String sessionid, String endurl,
			String IBPSEndPointURL, String Cabinet) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("Inside SearchStatusDAO..getReportDetails Method Starts...");
		String invoiceNo;
		Timestamp dateFrom = null;
		Timestamp dateTo = null;
		ReportsBean myReportBean = null;
		String itemIndex = null;
		int result = 0;

		ArrayList<ReportsBean> arr = new ArrayList<ReportsBean>();

		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();
		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;

		int bufferSize = gen.getBatchSize();
		String VendorCode = gen.getVendorCode();
		int Privilege = Integer.parseInt(gen.getPriviledge());

		String str_todate = "";
		String str_frdate = "";

		invoiceNo = report.getInvoiceNo();
		if (ClsUtil.isNullOrEmpty(invoiceNo))
			invoiceNo = "";

		if (!ClsUtil.isNullOrEmpty(report.getFromDate()) && !ClsUtil.isNullOrEmpty(report.getToDate())) {
			dateFrom = new Timestamp(report.getFromDate().getTime());
			dateTo = new Timestamp(report.getToDate().getTime() + (1000 * 60 * 60 * 24));
			str_todate = dateTo.toString();
			str_frdate = dateFrom.toString();
		}

		else {
			str_todate = "";
			str_frdate = "";
		}

		// Pagination
		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastQryNo;

		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}

		String SOAP_inxml = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String option = "";
		try {
			xmlvalues = new HashMap<String, String>();
			if (!ClsUtil.isNullOrEmpty(invoiceNo)) {
				logger.debug(" Invoice Records when invoice no is : " + invoiceNo);

			} else {
				logger.debug(" Invoice Records when dateFrom & dateTo is : " + dateFrom + dateTo);

			}

			logger.debug(" invoiceNo : " + invoiceNo);
			logger.debug(" paginationSql : " + paginationSql);
			logger.debug(" Linktype : " + gen.getLinkType());
			logger.debug(" Previlege " + String.valueOf(Privilege));
			logger.debug(" VendorCode " + VendorCode);
			logger.debug(" Buffersize " + String.valueOf(bufferSize));
			logger.debug(" dateTo " + str_todate);
			logger.debug(" dateFrom " + str_frdate);

			xmlvalues.put("invoiceNo", invoiceNo);
			xmlvalues.put("fromdate", str_frdate);
			xmlvalues.put("todate", str_todate);
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));

			option = "ProcedureSelectReportsRecord";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

			if (outptXMLlst.size() > 0 && !ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug("SearchStatusDAO size===============>" + outptXMLlst.size());
				logger.debug("SearchStatusDAO get(0)===============>" + outptXMLlst.get(0));
				// if (!outptXMLlst.get(0).equalsIgnoreCase("Session Not
				// Valid"))
				// {
				result = 1;
				int j = 0;
				// paginationTopQryNo = outptXMLlst.get(1);
				paginationTopQryNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					itemIndex = outptXMLlst.get(k);
					logger.debug("Data---->" + itemIndex);
					myReportBean = new ReportsBean();
					myReportBean.setItemIndex(Integer.parseInt(itemIndex));
					myReportBean.setInvoiceNo(outptXMLlst.get(++k));
					myReportBean.setTransactionId(outptXMLlst.get(++k));
					myReportBean.setActionFlag(outptXMLlst.get(++k));// Invoice
																		// Status
					// myInvoiceMaster.setInvoiceNumberInSystem(outptXMLlst.get(++k));
					String totalInvoiceAmount = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(totalInvoiceAmount)) {
						myReportBean.setInvoiceAmount("0");
					} else {
						myReportBean.setInvoiceAmount(ClsUtil.thousandFormatter(totalInvoiceAmount));
					}

					myReportBean.setInvoiceDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
					myReportBean.setInitiation_ExtDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
					myReportBean.setCurrency(outptXMLlst.get(++k));
					// Modified by ksivashankar on 01-Sep-2017 starts here
					/*
					 * String physicalRecord= outptXMLlst.get(++k);
					 * if(ClsUtil.isNullOrEmpty(physicalRecord))
					 * myReportBean.setPhysical_InvoiceRec("No"); else
					 * myReportBean.setPhysical_InvoiceRec(physicalRecord);
					 */

					myReportBean.setRejectionStatus(outptXMLlst.get(++k));// newly
																			// added
																			// by
																			// devi
																			// 01/03/2017
					myReportBean.setComments(outptXMLlst.get(++k)); // newly
																	// added by
																	// devi
																	// 01/03/2017

					// myReportBean.setPhysical_InvoiceRec(outptXMLlst.get(++k));
					// myInvoiceMaster.setTransactionId(outptXMLlst.get(++k));
					// Modified by ksivashankar on 01-Sep-2017 ends here
					arr.add(myReportBean);
					j = k + 1;
				}
				paginationLastQryNo = itemIndex;
				prevRecordFlag = outptXMLlst.get(j++);
				lastRecordFlag = outptXMLlst.get(j);
				// }
				// else{
				// result = -1;
				// logger.debug("Session Not Valid");
				// }
			}
		} catch (Exception e) {
			loggerErr.error("Exception in getting StatusStatus DAO  : " + e.getMessage());
			e.printStackTrace();
		}

		gen = new GeneralClass();
		gen.setSessionresult(result);
		gen.setArrayReports(arr);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		// gen.setMap(map_invoice);
		// gen.setPrevRecordFlag(prevRecordFlag);
		// gen.setLastRecordFlag(lastRecordFlag);
		// gen.setPaginationTopQryNo(paginationTopQryNo);
		// gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in My Invoices is " + totaltime);

		return gen;
	}

}