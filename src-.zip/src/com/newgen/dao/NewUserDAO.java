/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: NewUserDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.VendorMaster;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class NewUserDAO implements NewUserDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
    private static Logger loggerErr = Logger.getLogger("errorLogger"); 
	/**
	 * This Method is used to register user or insert applied user
	 * @param AppliedUser appliedUser
	 * @return int
	 * @exception Exception
	 */
	@Override
	public int registerUser(AppliedUser appliedUser, String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("registerUser Method Starts...");
		int result = 0;
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;		

		try {
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("UserName", appliedUser.getUserName());
			xmlvalues.put("VendorCode", appliedUser.getVendorCode());
			xmlvalues.put("VendorName", ClsUtil.replaceString(appliedUser.getVendorName()));
			xmlvalues.put("VendorAddress",ClsUtil.replaceString(appliedUser.getVendorAdd()));
			xmlvalues.put("EmailId", appliedUser.getEmailId());
			xmlvalues.put("Address", appliedUser.getAddress());
			xmlvalues.put("PhoneNumber", appliedUser.getPhoneNo());
			xmlvalues.put("Status", "Applied");
			xmlvalues.put("ContactPersonName", ClsUtil.replaceString(appliedUser.getContactPersonName()));
			xmlvalues.put("MobileNo", appliedUser.getMobileNo());
			xmlvalues.put("PAN", appliedUser.getPAN());
			xmlvalues.put("TAN", appliedUser.getTAN());
			xmlvalues.put("ServiceRegNo", appliedUser.getServiceRegNo());
			xmlvalues.put("TIN", appliedUser.getTIN());
			option="ProcedureAppliedUser";

			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option);
			logger.debug("Applied user input xml"+SOAP_inxml);

			outptXMLlst=new ArrayList<String>();
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			
			logger.debug("Applied user output xml"+outptXMLlst.toString());

				if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0){
				
				if(outptXMLlst.get(0).trim().equalsIgnoreCase("UserAdded"))
				{
					result=1;
					logger.debug("Applied User Data inserted Successfully...");
				}
				else if(outptXMLlst.get(0).trim().equalsIgnoreCase("DuplicateUser"))
				{
					result=-1;
					logger.debug("Applied User Already Exists...");
				}
				else
				{
					result=0;
				}
			}


		
		}
		catch (Exception e) {
			loggerErr.error("Exception in registering user : " + e.getMessage());
			e.printStackTrace();

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime-starttime;
		logger.debug("Total Time Taken in registering user is "+ totaltime);
		return result;
	}

	/**
	 * This Method is used to Fetch Details of all Vendors.
	 * @param UserName,String endurl
	 * @return HashMap<String, String>
	 * @exception Exception
	 */
	@Override
	public HashMap<String, String> fetchVendorDetails(String UserName,String endurl,String cabinet){

		long starttime = System.currentTimeMillis();
		logger.debug("fetchVendorDetails Method Starts...");

		HashMap<String, String> hshCompany = new HashMap<String, String>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;		

		try {
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("UserName",UserName );

			option="ProcedureGetVenData";

			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{	
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					String VendorCode = outptXMLlst.get(k);
					String VendorName = outptXMLlst.get(++k);
					String VendorInvType = outptXMLlst.get(++k);
					String VendorPaymentTerm = outptXMLlst.get(++k);
					String VendorEmailID = outptXMLlst.get(++k);

					hshCompany.put(VendorCode, VendorName + ","+VendorInvType+","+VendorPaymentTerm+","+VendorEmailID);
				}
				logger.debug("fetch VendorDetails Successfully");

			}
		}
		catch (Exception e) {
			loggerErr.error("Exception in fetch Vendor Details : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime-starttime;
		logger.debug("Total Time Taken in fetch Vendor Details is "+ totaltime);

		return hshCompany;


	}
	
	public String fetchVPVendorDetails(String userName, String searchString, String endurl,
			String cabinet, String minValue, String maxValue, String maxCount){

		long starttime = System.currentTimeMillis();
		logger.debug("fetchVPVendorDetails Method Starts...");

		ArrayList<String> arrList = new ArrayList<String>();
		String SOAP_inxml="";
		String option="";
		String returnValue = "";
		String sCount = "";
		String strInvValues="";
		HashMap<String,String> xmlvalues =null;
		HashMap<String,String> xmlvalues1 =null;
		ArrayList<String> outptXMLlst=null;		
		if (maxCount != null && maxCount.equals("0")) {
			try{			
				xmlvalues1=new HashMap<String,String>();				
				xmlvalues1.put("userName",userName);	
				xmlvalues1.put("searchString", searchString);
				option="ProcedureGetVenDataListCount";			
				SOAP_inxml=GenerateXML.generatexml(xmlvalues1,option,cabinet);
				logger.debug("Count SOAP_inxml =========> "+SOAP_inxml);
				// Webservice call
				outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
				logger.debug("Count outptXMLlst =========> "+SOAP_inxml);
				if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
				{			
					sCount=outptXMLlst.get(0);
					logger.debug("totalcount =========> "+sCount);
				}
				 if (sCount != null) {
	                 returnValue = sCount + "&#";
	             }
				
			}catch (Exception e) {
				loggerErr.error("Exception in Popup InvoiceList Count  : " + e.getMessage());
				e.printStackTrace();
			}
			
			}else {
	            returnValue = maxCount + "&#";
	        }
		try {
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("UserName",userName );
			xmlvalues.put("searchString", searchString);
			xmlvalues.put("minValue", minValue);
			xmlvalues.put("maxValue", maxValue);
			xmlvalues.put("maxCount", maxCount);
			option="ProcedureGetVenDataList";

			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{	
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					String VendorCode = outptXMLlst.get(k);
					String VendorName = outptXMLlst.get(++k);
					arrList.add(VendorCode+"#&@*"+VendorName);
				}
				logger.debug("fetch VendorDetails Successfully");

			}
			
			if (!arrList.isEmpty()) {

				 strInvValues = arrList.toString().replaceAll("\\[", "");
	                strInvValues = strInvValues.replaceAll("\\]", "");

	                logger.debug("*************** strInvValues" + strInvValues);
	                returnValue = returnValue + strInvValues;
	                logger.debug("Get User Return value: " + returnValue);
	                return returnValue;
	            } else {
	            	returnValue="No Vendors Found,";
	                return returnValue;
	            }
			
		}
		catch (Exception e) {
			loggerErr.error("Exception in fetch Vendor Details : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime-starttime;
		logger.debug("Total Time Taken in fetch Vendor Details is "+ totaltime);

		return returnValue;


	}

	/**
	 * This Method is used to check availability of username.
	 * @param UserName,String endurl
	 * @return int
	 * @exception Exception
	 */
	@Override
	public int checkAvailability(String userName, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("checkAvailability Method Starts...");

		String SOAP_inxml="";
		String option="";
		int result = 0;
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;		

		try{

			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("UserName", userName);

			option="ProcedureSelectUserAvai";

			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option);

			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);

				if(ClsUtil.isNullOrEmpty(outptXMLlst) || outptXMLlst.size()==0){
				result = 0;
				}
			else{
				result = -1;
				logger.debug("result is -->" +result);
			}
		}catch (Exception e) {
			loggerErr.error("Exception While Checking Availability  : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime-starttime;
		logger.debug("Total Time Taken in checking availability is " + totaltime);

		return result;
	}

	/**
	 * This Method is used to fetchVendorDetailsByVendorCode.
	 * @param vendorCode,String endurl
	 * @return Bean VendorMaster
	 * @exception Exception
	 */
	@Override
	public VendorMaster fetchVendorDetailsByVendorCode(String vendorCode, String endurl){

		long starttime = System.currentTimeMillis();
		logger.debug("fetchVendorDetailsByVendorCode Method Starts..."+vendorCode);
		VendorMaster venMaster = null;
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;		
		try {
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("VendorCode", vendorCode);
			option="ProcedureVenDataByCode";
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)

			{
					venMaster = new VendorMaster();
					venMaster.setVendorName(outptXMLlst.get(1));
					venMaster.setVendorAddress(outptXMLlst.get(2));
					venMaster.setVendorEmailId(outptXMLlst.get(3));
					venMaster.setContactPersonName(outptXMLlst.get(5));
					venMaster.setMobileNo(outptXMLlst.get(6));
					venMaster.setPAN(outptXMLlst.get(7));
					venMaster.setTAN(outptXMLlst.get(8));
					venMaster.setServiceRegNo(outptXMLlst.get(9));
					venMaster.setTIN(outptXMLlst.get(10));
					venMaster.setUserId(outptXMLlst.get(12));
					logger.debug("fetch Vendor Details By VendorCode successfully..........");
			}
		}catch (Exception e) {
			loggerErr.error("Exception in fetch Vendor Details By VendorCode : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime-starttime;
		logger.debug("Total Time Taken in fetch Vendor Details By VendorCode is " + totaltime);

		return venMaster;
	}	

}