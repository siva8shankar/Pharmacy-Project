/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminCompanyListDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.CompanyMaster;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class AdminCompanyListDAO implements AdminCompanyListDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to fetch list of Companies.
	 * 
	 * @param GeneralClass
	 *            generalClass
	 * @return GeneralClass generalClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass getCompanyList(GeneralClass generalClass, String endurl) {
		// TODO Auto-generalClasserated method stub

		long starttime = System.currentTimeMillis();
		logger.info("getCompanyList Method Starts...|");

		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopNo = generalClass.getPaginationTopQryNo();
		String paginationLastNo = generalClass.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = generalClass.getBatchSize();

		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		CompanyMaster companyMaster = null;
		ArrayList<CompanyMaster> arrCompanyList = new ArrayList<CompanyMaster>();

		if (!ClsUtil.isNullOrEmpty(generalClass.getLinkType()) && generalClass.getLinkType().equals("next")) {
			paginationSql = paginationLastNo;
		} else if (!ClsUtil.isNullOrEmpty(generalClass.getLinkType()) && generalClass.getLinkType().equals("prev")) {

			paginationSql = paginationTopNo;
		} else {
			paginationSql = "";
		}

		try {
			logger.info("Getting company list result...|");

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", generalClass.getLinkType());

			// Give the result of top 10 companies in Company Master table.
			option = "ProcedureSelectCompnylst";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				int i = 0;
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					paginationTopNo = outptXMLlst.get(0);
					companyMaster = new CompanyMaster();
					paginationLastNo = outptXMLlst.get(k);
					companyMaster.setCompanyCode(outptXMLlst.get(++k));
					companyMaster.setCompanyName(outptXMLlst.get(++k));
					companyMaster.setCompanyAddress(outptXMLlst.get(++k));
					companyMaster.setCountry(outptXMLlst.get(++k));

					arrCompanyList.add(companyMaster);
					i = k + 1;
				}
				prevRecordFlag = outptXMLlst.get(i++);
				lastRecordFlag = outptXMLlst.get(i);
			}
		} catch (Exception e) {
			loggerErr.error("Exception : " + e.getMessage());
			e.printStackTrace();

		}

		generalClass = new GeneralClass();
		generalClass.setArrayCompanyList(arrCompanyList);
		generalClass.setPrevRecordFlag(prevRecordFlag);
		generalClass.setLastRecordFlag(lastRecordFlag);
		generalClass.setPaginationTopQryNo(paginationTopNo);
		generalClass.setPaginationLastQryNo(paginationLastNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;

		logger.debug("Total Time Taken in getting Company List is " + totaltime);
		return generalClass;
	}
}
