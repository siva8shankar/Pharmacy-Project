/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: UpdateComplexPODetailsDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Interface for UpdateComplexPODetailsDAOI class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.Map;

import com.newgen.bean.ComplexPODetails;
import com.newgen.bean.PODetails;

public interface UpdateComplexPODetailsDAOI {
	public abstract int UpdateComplexPO(ComplexPODetails comPoDetails, String endurl, Map<String, String> map,
			StringBuilder strDynamicRows);

}
