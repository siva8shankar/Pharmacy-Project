/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminUserDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  Interface for AdminUserDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

public interface AdminUserDAOI {

	public abstract int sendEmail(String userName, String endurl);

	public abstract int sendEmailonEnable(String userName, String endurl, String option);

	public abstract int sendEmailByAdmin(String userName, String endurl, String option, String newPassword);

	// public abstract int checkValidSession(String userName, String sessionId,
	// String endurl);

	// public abstract String GetVendorName(String userName, String endurl);

}