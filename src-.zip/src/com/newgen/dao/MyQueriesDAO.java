/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: MyQueriesDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)        
* 04/10/2017                        ksivashankar       				Bug 1015850 - Vendor Portal - My queries should display only queries raised by that particular vendor.
* 09/01/2018						ksivashankar					Bug 1023795 - Vendor Portal - Query lock symbol was required for the Admin module.                                
************************************************************************************************/

package com.newgen.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorQueryDetails;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class MyQueriesDAO implements MyQueriesDAOI {
	private static Logger logger = Logger.getLogger("consoleLogger");
    private static Logger loggerErr = Logger.getLogger("errorLogger");
    SimpleDateFormat sdf1 = new SimpleDateFormat(ClsMessageHandler.XMLDateFormat);
	SimpleDateFormat dt1 = new SimpleDateFormat(ClsMessageHandler.MainDateFormat);
	/**
	 * This Method is used to getMyQueries of a corresponding Username.
	 * @param userName,GeneralClass, endurl.
	 * @return GeneralClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass getMyQueries(String priviledge,String userName, GeneralClass gen,String sessionid, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.info("Getting My Queries Method Starts...UserName: "+userName);
		int result=0;
		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();
		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		VendorQueryMaster myQueryMaster = null;
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;		
		ArrayList<VendorQueryMaster> arr_Query = new ArrayList<VendorQueryMaster>();

			if(!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql =  paginationLastQryNo;
		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType())
				&& gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}	

		try {
			xmlvalues=new HashMap<String,String>();

			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("userName", userName);
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("sessionid", sessionid);
//Bug 1015850 - Vendor Portal - My queries should display only queries raised by that particular vendor.
			if (!ClsUtil.isNullOrEmpty(priviledge) && priviledge.equalsIgnoreCase("1")){
				option="ProcedureSelectAllQueries";
			}else{
				option="ProcedureSelectMyQuery";
			}
			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);			
			if(!ClsUtil.isNullOrEmpty(outptXMLlst))
			{if (!outptXMLlst.get(0).equalsIgnoreCase("Session Not Valid"))
			{
			result=1;
				paginationTopQryNo = outptXMLlst.get(0);
				int i=0;
				for(int k=0 ;k<(outptXMLlst.size()-2);k++)
				{
					myQueryMaster = new VendorQueryMaster();
					myQueryMaster.setQueryNo(outptXMLlst.get(k));
					myQueryMaster.setStatus(outptXMLlst.get(++k));
					myQueryMaster.setInvoiceNo(outptXMLlst.get(++k));
					myQueryMaster.setPONumber(outptXMLlst.get(++k));					
					myQueryMaster.setOtherId(outptXMLlst.get(++k));
					myQueryMaster.setCreatedBy(outptXMLlst.get(++k));
					myQueryMaster.setCreatedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
					myQueryMaster.setModifiedBy(outptXMLlst.get(++k));
					myQueryMaster.setModifiedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
					myQueryMaster.setLockedstatus(outptXMLlst.get(++k));
					myQueryMaster.setLockedby(outptXMLlst.get(++k));
					String Lokedtime=outptXMLlst.get(++k);
					if(!Lokedtime.equalsIgnoreCase("null") && !Lokedtime.equalsIgnoreCase("")){
					myQueryMaster.setLockedtime(ClsConvertDate.ConvertxmlDatetostring(Lokedtime));
					//Bug 1023795
					Date date = sdf1.parse(Lokedtime);
					SimpleDateFormat dt2 = new SimpleDateFormat("HH:mm:ss");
					String str_lockedDate = dt1.format(date).toString() + " " + dt2.format(date).toString();
					myQueryMaster.setLockedtime(str_lockedDate);
					}else{
					myQueryMaster.setLockedtime("");	
					}					

					arr_Query.add(myQueryMaster);
					i=k+1;
				} 
				paginationLastQryNo = myQueryMaster.getQueryNo();
				prevRecordFlag=outptXMLlst.get(i++);
				lastRecordFlag=outptXMLlst.get(i);
			}
			else{
				result = -1;
				logger.debug("Session Not Valid");
			}
			}
		} catch (Exception e) {
			loggerErr.error("Exception in getting My Queries  : " + e.getMessage());
			e.printStackTrace();
		}

		gen = new GeneralClass();
		gen.setSessionresult(result);
		gen.setArrayQueryMaster(arr_Query);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in My Queries is "	+ totaltime);

		return gen;
	}
	
	public String queryLockMethod(
			String priviledge,VendorQueryDetails venDetails, String archive,String sessionid,  String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("Getting Query Details");
		VendorQueryDetails venDetailsData = null;
		int result = 0;
		 GeneralClass gen=new GeneralClass();
		String SOAP_inxml = "";
		String option = "";
		String queryLockedStatus="";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String queryNo = venDetails.getQueryNo();
		if (!ClsUtil.isNullOrEmpty(priviledge) && priviledge.equalsIgnoreCase("1")){
			try{
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Queryno", queryNo);
			xmlvalues.put("userName",venDetails.getCreatedBy());
			xmlvalues.put("sessionid", sessionid);
			option = "ProcedureLockQuery";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			outptXMLlst = new ArrayList<String>();
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml,
					endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug("outptXMLlst.get(0) "+outptXMLlst.get(0));
				if (!outptXMLlst.get(0).equalsIgnoreCase("Session Not Valid"))
				{
					if (outptXMLlst.get(0).equalsIgnoreCase("Query Locked"))
					{
						queryLockedStatus="Query Locked";
						logger.debug("Query Locked queryNo :: "+queryNo+"  ===> username :: "+venDetails.getCreatedBy());
					}
					if (outptXMLlst.get(0).equalsIgnoreCase("Query Locking failed"))
					{
						queryLockedStatus="Query Locking failed";
						logger.debug("Query Locking failed");
					}
				}
				}
			}catch(Exception e) {
				loggerErr.error("Exception in Procedure Lock Query : "
						+ e.getMessage());
				e.printStackTrace();
			}
		}
		return queryLockedStatus;
	}
	
	public String queryUnLockMethod(
			String priviledge,VendorQueryDetails venDetails, String archive,String sessionid,  String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("Getting Query Details");
		VendorQueryDetails venDetailsData = null;
		int result = 0;
		 GeneralClass gen=new GeneralClass();
		String SOAP_inxml = "";
		String option = "";
		String queryUnLockedStatus="";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		String queryNo = venDetails.getQueryNo();
		if (!ClsUtil.isNullOrEmpty(priviledge) && priviledge.equalsIgnoreCase("1")){
			try{
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Queryno", queryNo);
			xmlvalues.put("userName",venDetails.getCreatedBy());
			xmlvalues.put("sessionid", sessionid);
			option = "ProcedureUnLockQuery";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			outptXMLlst = new ArrayList<String>();
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml,
					endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug("outptXMLlst.get(0) "+outptXMLlst.get(0));
				if (!outptXMLlst.get(0).equalsIgnoreCase("Session Not Valid"))
				{
					if (outptXMLlst.get(0).equalsIgnoreCase("Query UnLocked"))
					{
						queryUnLockedStatus="Query UnLocked";
						logger.debug("Query Locked queryNo :: "+queryNo+"  ===> username :: "+venDetails.getCreatedBy());
					}
					if (outptXMLlst.get(0).equalsIgnoreCase("Query UnLocking failed"))
					{
						queryUnLockedStatus="Query UnLocking failed";
						logger.debug("Query UnLocking failed");
					}
				}
				}
			}catch(Exception e) {
				loggerErr.error("Exception in Procedure Lock Query : "
						+ e.getMessage());
				e.printStackTrace();
			}
		}
		return queryUnLockedStatus;
	}
}