/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GeneratedPODetailsDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and fetch all PO details & convert String into Date
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.PODetails;
import com.newgen.bean.SAPConPODetails;
import com.newgen.bean.SAPPODetails;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;
import com.newgen.util.SAPFunctions;
import com.newgen.wfdesktop.xmlapi.WFXmlList;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;

public class GeneratedPODetailsDAO implements GeneratedPODetailsDAOI {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to fetch all PO details.
	 * 
	 * @param PONumber
	 * @return PONumber,SubmittoCompany,CompanyAddress,AttentionTo,VendorCode,
	 *         VendorName,VendorAddress,InvoiceType,InvoiceNumber,InvoiceDate,
	 *         Currency,GrossAmount,TotalTax,Freight,Discount,NetAmount,
	 *         ServiceTax,EducationCess,VAT,AdditionalVT,AnyOtherTax.
	 * @exception Exception
	 */

	@Override
	public PODetails GeneratedPODetails(String po_no, String endurl) {

		long starttime = System.currentTimeMillis();
		logger.debug("GeneratedPODetails Method Starts...");
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		PODetails pomaster = null;
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("PONumber", po_no);
			option = "ProcedureSelectPODetails";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				for (int k = 0; k < outptXMLlst.size(); k++) {
					pomaster = new PODetails();
					pomaster.setPONumber(outptXMLlst.get(k));
					pomaster.setSubmittoCompany(outptXMLlst.get(++k));
					pomaster.setCompanyAddress(outptXMLlst.get(++k));
					pomaster.setAttentionTo(outptXMLlst.get(++k));
					pomaster.setVendorCode(outptXMLlst.get(++k));
					pomaster.setVendorName(outptXMLlst.get(++k));
					pomaster.setVendorAddress(outptXMLlst.get(++k));
					pomaster.setInvoiceType(outptXMLlst.get(++k));
					pomaster.setInvoiceNumber(outptXMLlst.get(++k));

					String str_invdate = outptXMLlst.get(++k);
					pomaster.setInvoiceDate(ClsConvertDate.ConvertxmlDatetostring(str_invdate));

					pomaster.setCurrency(outptXMLlst.get(++k));

					String strGrossAmount = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(strGrossAmount)) {
						pomaster.setGrossAmount("");
					} else {
						pomaster.setGrossAmount(strGrossAmount);
					}

					String strTotalTax = outptXMLlst.get(++k);

					if (ClsUtil.isNullOrEmpty(strTotalTax)) {
						pomaster.setTotalTax("");
					} else {
						pomaster.setTotalTax(strTotalTax);
					}

					String strFrieght = outptXMLlst.get(++k);

					if (ClsUtil.isNullOrEmpty(strFrieght)) {
						pomaster.setFreight("");
					} else {
						pomaster.setFreight(strFrieght);
					}

					String strDiscount = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(strDiscount)) {
						pomaster.setDiscount("");
					} else {
						pomaster.setDiscount(strDiscount);
					}

					String strNetAmount = outptXMLlst.get(++k);

					if (ClsUtil.isNullOrEmpty(strNetAmount)) {
						pomaster.setNetAmount("");
					} else {
						pomaster.setNetAmount(strNetAmount);
					}

					String strServiceTax = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(strServiceTax)) {
						pomaster.setServiceTax("");
					} else {
						pomaster.setServiceTax(strServiceTax);
					}

					String strEducationCess = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(strEducationCess)) {

						pomaster.setEducationCess("");
					} else {
						pomaster.setEducationCess(strEducationCess);
					}

					String strVAT = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(strVAT)) {
						pomaster.setVAT("");
					} else {
						pomaster.setVAT(strVAT);
					}

					String strAdditionalVAT = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(strAdditionalVAT)) {
						pomaster.setAdditionalVAT("");
					} else {
						pomaster.setAdditionalVAT(strAdditionalVAT);
					}

					String strAnyOtherTax = outptXMLlst.get(++k);
					if (ClsUtil.isNullOrEmpty(strAnyOtherTax)) {
						pomaster.setAnyOtherTax("");
					} else {
						pomaster.setAnyOtherTax(strAnyOtherTax);
					}

					String strDeliveryDate = outptXMLlst.get(++k);
					pomaster.setDeliveryDate(ClsConvertDate.ConvertxmlDatetostring(strDeliveryDate));

				}
				logger.debug("Generated PO Details Successfully");
			}

		} catch (Exception e) {
			loggerErr.error("Exception in Generated PO Details : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Generated PO Details is ..." + totaltime);
		return pomaster;

	}

	public SAPPODetails GeneratedSAPPODetails(String PONumber, String endurl) {

		long starttime = System.currentTimeMillis();
		logger.debug("GeneratedSAPPODetails method starts.......");
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		SAPPODetails sapPoDetails = null;
		try {
			logger.debug("SAP BAPI execution starts in GeneratedSAPPODetails  ==");
			SAPConPODetails sapconpo = null;
			SAPFunctions SAPObj = new SAPFunctions();
			SAPObj.InitializeEjbClient();
			String SAPXML = "";
			/* PONumber = "4500000069"; */
			SAPXML = SAPObj.getWFSAPInvoker("ZDI_OPEN_GRN_DETAILS", "<PURCHASEORDER>" + PONumber + "</PURCHASEORDER>");

			WFXmlResponse XmlResponse = new WFXmlResponse(SAPXML);
			logger.debug("XmlResponse==" + XmlResponse);
			logger.debug("====" + XmlResponse.getVal("MainCode"));
			if (XmlResponse.getVal("MainCode").equals("0")) {
				WFXmlList XMLListPoDetails = XmlResponse.createList("Parameters", "ExportParameters");
				logger.debug("XMLListPR==" + XMLListPoDetails);
				XMLListPoDetails.reInitialize(true);
				for (; XMLListPoDetails.hasMoreElements(true); XMLListPoDetails.skip(true)) {
					logger.debug("Inside for loop");
					String POAmount = XMLListPoDetails.getVal("PO_AMOUNT").trim();
					String POOpenAmount = XMLListPoDetails.getVal("PO_OPEN_AMOUNT").trim();
					String VENDORNAME = XMLListPoDetails.getVal("VENDOR_NAME").trim();
					String VENDORCODE = XMLListPoDetails.getVal("VENDOR_CODE").trim();
					String POStatus = XMLListPoDetails.getVal("PO_STATUS").trim();
					String COMPANYCODE = XMLListPoDetails.getVal("COMPANY_CODE").trim();
					String TAXCODE = XMLListPoDetails.getVal("TAX_CODE").trim();
					String BUSINESSAREA = XMLListPoDetails.getVal("BUSINESS_AREA").trim();
					String POTYPE = XMLListPoDetails.getVal("PO_TYPE").trim();
					sapPoDetails = new SAPPODetails();
					sapPoDetails.setPONumber(PONumber);
					sapPoDetails.setPOAmount(POAmount);
					sapPoDetails.setPOOpenAmount(POOpenAmount);
					sapPoDetails.setVendorName(VENDORNAME);
					sapPoDetails.setVendorCode(VENDORCODE);
					sapPoDetails.setBusinessArea(BUSINESSAREA);
					sapPoDetails.setCompanyCode(COMPANYCODE);
					sapPoDetails.setTaxCode(TAXCODE);
					sapPoDetails.setOrderType(POTYPE);

				}
			}
			logger.debug("SAP ArrayList == ");
			logger.debug("SAP BAPI execution ends in GeneratedSAPPODetails  ====");

		} catch (Exception e) {
			loggerErr.error("Exception in getPOLineItem  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getPOLineItem  is " + totaltime);

		return sapPoDetails;
	}
}