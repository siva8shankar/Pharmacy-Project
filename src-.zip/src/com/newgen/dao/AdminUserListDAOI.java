/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminUserListDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Interface for AdminUserListDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;

import com.newgen.util.GeneralClass;

public interface AdminUserListDAOI {

	public abstract GeneralClass getUserListWithDetails(String userType, GeneralClass gen, String searchUser,
			String loggedInUser, String searchType, String endurl);

	public abstract ArrayList<String> getUserList(String usrName, String userType, String searchusr, String endurl);

}