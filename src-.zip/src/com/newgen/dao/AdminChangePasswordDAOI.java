/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminChangePasswordDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: AdminChangePasswordDAOI
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import com.newgen.bean.PasswordPolicyBean;
import com.newgen.bean.VPUserMaster;

public interface AdminChangePasswordDAOI {

	public abstract int changePassword(String pPassword, String pUserName, String endurl);

	public abstract int savePasswordPolicy(PasswordPolicyBean passwordPolicyBean, String pUserName, String endurl);

	public abstract PasswordPolicyBean FetchPasswordPolicy(String pUserName, String sessionId, String endurl);

}