/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GetInvoiceDetailDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  Interface for GetInvoiceDetailDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;

public interface GetInvoiceDetailDAOI {
	//public abstract InvoiceDetails GetInvoiceDetail(String invid, String endurl);
	public abstract InvoiceNewDetails GetInvoiceDetail(String invid, String endurl);
}
