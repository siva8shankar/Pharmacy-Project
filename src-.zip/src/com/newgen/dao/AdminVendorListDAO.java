/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminVendorListDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations i.e UPDATE & SELECT
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorMaster;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class AdminVendorListDAO implements AdminVendorListDAOI {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to getVendorList.
	 * 
	 * @param GeneralClass,endurl.
	 * @return GeneralClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass getVendorList(GeneralClass generalClass, String endurl) {
		// TODO Auto-generalClasserated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("getVendorList Method Starts...");
		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopNo = generalClass.getPaginationTopQryNo();
		String paginationLastNo = generalClass.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = generalClass.getBatchSize();
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		VendorMaster vendorMaster = null;
		ArrayList<VendorMaster> arrVendorList = new ArrayList<VendorMaster>();

		if (!ClsUtil.isNullOrEmpty(generalClass.getLinkType()) && generalClass.getLinkType().equals("next")) {
			paginationSql = paginationLastNo;
		} else if (generalClass.getLinkType() != null && generalClass.getLinkType().equals("prev")) {
			paginationSql = paginationTopNo;
		} else {
			paginationSql = "";
		}

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", generalClass.getLinkType());
			option = "ProcedureSelectVendorlst";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("&&&& AdminVendorListDAO outptXMLlst--->" + outptXMLlst);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				int i = 0;
				paginationTopNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					vendorMaster = new VendorMaster();
					vendorMaster.setVendorID(outptXMLlst.get(k));
					vendorMaster.setVendorCode(outptXMLlst.get(++k));
					vendorMaster.setVendorName(outptXMLlst.get(++k));
					vendorMaster.setVendorAddress(outptXMLlst.get(++k));
					vendorMaster.setVendorEmailId(outptXMLlst.get(++k));
					vendorMaster.setSPOC(outptXMLlst.get(++k));
					vendorMaster.setSPOCEmailId(outptXMLlst.get(++k));
					vendorMaster.setCurrency(outptXMLlst.get(++k));
					vendorMaster.setCompanyCode(outptXMLlst.get(++k));
					vendorMaster.setIsVendorActive(outptXMLlst.get(++k));
					vendorMaster.setContactPersonName(outptXMLlst.get(++k));// Added
																			// Here
					vendorMaster.setMobileNo(outptXMLlst.get(++k));
					vendorMaster.setPAN(outptXMLlst.get(++k));
					vendorMaster.setTAN(outptXMLlst.get(++k));
					vendorMaster.setServiceRegNo(outptXMLlst.get(++k));
					vendorMaster.setTIN(outptXMLlst.get(++k));
					vendorMaster.setTelephoneNo(outptXMLlst.get(++k));
					vendorMaster.setUserId(outptXMLlst.get(++k));// Newly Added
					arrVendorList.add(vendorMaster);
					i = k + 1;
				}
				paginationLastNo = vendorMaster.getVendorID();
				prevRecordFlag = outptXMLlst.get(i++);
				lastRecordFlag = outptXMLlst.get(i);
			}

		} catch (Exception e) {
			// TODO Auto-generalClasserated catch block
			loggerErr.error("Exception in getting Vendor List  : " + e.getMessage());
			e.printStackTrace();
		}

		generalClass = new GeneralClass();
		generalClass.setArrayVendorList(arrVendorList);
		generalClass.setPrevRecordFlag(prevRecordFlag);
		generalClass.setLastRecordFlag(lastRecordFlag);
		generalClass.setPaginationTopQryNo(paginationTopNo);
		generalClass.setPaginationLastQryNo(paginationLastNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Vendor List is " + totaltime);
		return generalClass;
	}

}
