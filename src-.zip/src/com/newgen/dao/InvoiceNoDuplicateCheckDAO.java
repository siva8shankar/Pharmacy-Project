/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: InvoiceNoDuplicateCheckDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.dao.NewUserDAOI;

public class InvoiceNoDuplicateCheckDAO implements InvoiceNoDuplicateCheckDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to check Invoice duplication.
	 * 
	 * @param Invoiceno,Invoicedate,Vendorno,String
	 *            endurl
	 * @return int
	 * @exception Exception
	 */

	public int checkInvoiceDuplicate(String Invoiceno, String Invoicedate, String Vendorno, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("checkInvoiceDuplicate Method Starts...");
		logger.debug("checkInvoiceDuplicate Invoiceno--->" + Invoiceno);
		logger.debug("checkInvoiceDuplicate Invoicedate--->" + Invoicedate);
		logger.debug("checkInvoiceDuplicate Vendorno---->" + Vendorno);
		logger.debug("checkInvoiceDuplicate endurl--->" + endurl);

		String SOAP_inxml = "";
		String option = "";
		int result = 0;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {
			Properties props = null;
			props = new Properties();
			java.io.File fIni = new java.io.File("WebServiceConsume.ini");
			if (!(fIni.isFile() && fIni.exists())) {
				String message = "NewgenVendorPortal: WebServiceConsume.ini file not present.";
				throw new Exception(message);
			}
			java.io.FileInputStream is = new java.io.FileInputStream(fIni);
			props.load(is);
			String Cabinet = props.getProperty("Cabinet");
			is.close();

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("InvoiceNo", Invoiceno.trim());
			xmlvalues.put("InvoiceDate", Invoicedate);
			xmlvalues.put("VendorNo", Vendorno);

			option = "ProcedureInvoiceDuplicateCheck";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);

			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("outptXMLlst is --->" + outptXMLlst.get(0).toString());
			if (outptXMLlst.get(0) != null) {
				if (outptXMLlst.get(0).equalsIgnoreCase("0")) {
					result = 0;
					logger.debug("result" + result);
				} else {
					result = -1;
					logger.debug("result" + result);
				}
			} else {
				result = 1;
				logger.debug("result" + result);
			}
		} catch (Exception e) {
			loggerErr.error("Exception While Checking InvoiceDuplicate  : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in checking InvoiceDuplicate is " + totaltime);

		return result;
	}

}
