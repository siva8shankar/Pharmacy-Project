/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminDeleteDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  This is a Data access object class which interacts with database and perform CRUD Operations.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GenerateXML;

public class AdminDeleteDAO implements AdminDeleteDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to delete company.
	 * 
	 * @param String[]
	 *            companyCode
	 * @return int result
	 * @exception Exception
	 */
	public static int deleteCompany(String[] companyCode, String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.info("Inside Admin Deleting Company..." + companyCode);

		String SOAP_inxml = "";
		int result = 0;
		HashMap<String, String> xmlvalues = null;
		String cmpnyCodes = "";
		String option = "";

		if (!ClsUtil.isNullOrEmpty(companyCode) && companyCode.length > 0) {
			cmpnyCodes = companyCode[0];

			for (int i = 1; i < companyCode.length; i++) {
				cmpnyCodes = cmpnyCodes + "', '" + companyCode[i];
			}
		}
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("CompCode", cmpnyCodes);
			option = "ProcedureDeleteCompany";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			ArrayList<String> outptXMLlst = null;
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (outptXMLlst.get(0).equalsIgnoreCase("Company deleted")) {
				logger.info("Selected Company deleted succesfully");
				result = 1;
			}

			else
				result = -1;

		} catch (Exception e) {
			result = -1;
			loggerErr.error("Exception While Deleting Company By Admin  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.info("Total Time Taken in deleting Company by admin is " + totaltime);

		return result;
	}

	/**
	 * This Method is used to delete vendor.
	 * 
	 * @param String[]
	 *            VendorCode
	 * @param String[]
	 *            companyCode
	 * @return int result
	 * @exception Exception
	 */
	@Override
	public int deleteVendor(String[] vendorCode, String[] cmpnyCode, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.info("Inside Admin Deleting Vendor..." + vendorCode);

		int result = 0;
		String SOAP_inxml = "";
		String sVendorcode = "";
		String sCompanycode = "";
		String option1 = "";
		if (!ClsUtil.isNullOrEmpty(vendorCode)) {
			for (int i = 0; i < vendorCode.length; i++) {
				sVendorcode = sVendorcode + vendorCode[i] + ",";
				sCompanycode = sCompanycode + cmpnyCode[i] + ",";

			}
			HashMap<String, String> xmlvalues = null;
			try {
				xmlvalues = new HashMap<String, String>();
				xmlvalues.put("VendorCode", sVendorcode);
				xmlvalues.put("CompCode", sCompanycode);
				option1 = "ProcedureDeleteVendor";
				SOAP_inxml = GenerateXML.generatexml(xmlvalues, option1);
				ArrayList<String> outptXMLlst = null;
				// Webservice call
				outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
				if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
					result = 1;
					logger.info("Vendor Deleted Succesfully By Admin... ");
				} else
					result = -1;
			} catch (Exception e) {
				loggerErr.error("Exception While Deleting Vendor By Admin : " + e.getMessage());
				e.printStackTrace();
			}

			long endTime = System.currentTimeMillis();
			long totaltime = endTime - starttime;
			logger.info("Total Time Taken in deleting Vendor by admin is " + totaltime);

		}
		return result;
	}

	/**
	 * This Method is used to delete Invoice.
	 * 
	 * @param String
	 *            invoiceId
	 * @return int result
	 * @exception Exception
	 */
	@Override
	public int deleteInvoice(String invoiceId, String endurl) {
		long starttime = System.currentTimeMillis();
		logger.info("Inside Admin Deleting Invoice..." + invoiceId);
		int result = 0;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("InvoiceId", invoiceId);
			option = "ProcedureDeleteInvoice";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			ArrayList<String> outptXMLlst = null;
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.get(0).equalsIgnoreCase("Invoice Deleted")) {
				result = 1;
				logger.info("Invoice Deleted Succesfully By Admin... ");
			} else
				result = -1;
		} catch (Exception e) {

			loggerErr.error("Exception While Deleting Invoice By Admin : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in deleting Invoice by admin is " + totaltime);

		return result;
	}

}
