/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminUserListDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations i.e UPDATE & SELECT
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.VPUserMaster;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class AdminUserListDAO implements AdminUserListDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to getUserListWithDetails.
	 * 
	 * @param String
	 *            userType, GeneralClass gen, String searchUser, String
	 *            loggedInUser, String endurl.
	 * @return GeneralClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass getUserListWithDetails(String userType, GeneralClass gen, String searchUser,
			String loggedInUser, String searchType, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("getUserListWithDetails Method Starts...");

		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopNo = gen.getPaginationTopQryNo();
		String paginationLastNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		VPUserMaster regUserMaster = null;
		AppliedUser appUserMaster = null;
		ArrayList<VPUserMaster> arrRegUserList = new ArrayList<VPUserMaster>();
		ArrayList<AppliedUser> arrAppUserList = new ArrayList<AppliedUser>();

		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastNo;
		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopNo;
		} else {
			paginationSql = "";
		}

		try {
			logger.debug("searchType--->" + searchType);

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("Usertype", userType);
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("SearchUser", searchUser);
			xmlvalues.put("loggedinuser", loggedInUser);
			xmlvalues.put("SearchType", searchType);

			option = "ProcedureSelectUserlst";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("#AdminUserListDAO outptXMLlst-->" + outptXMLlst);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 2) {

				if (!ClsUtil.isNullOrEmpty(userType) && userType.equalsIgnoreCase("RegUser")) {
					int i = 0;
					paginationTopNo = outptXMLlst.get(0);
					for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
						regUserMaster = new VPUserMaster();

						regUserMaster.setUserIndex(outptXMLlst.get(k));
						regUserMaster.setUserName(outptXMLlst.get(++k));
						regUserMaster.setVendorCode(outptXMLlst.get(++k));
						regUserMaster.setVendorName(outptXMLlst.get(++k));
						regUserMaster.setVendorAddress(outptXMLlst.get(++k));
						regUserMaster.setUserAddress(outptXMLlst.get(++k));
						regUserMaster.setUserEmailId(outptXMLlst.get(++k));
						regUserMaster.setUserPhoneNumber(outptXMLlst.get(++k));
						regUserMaster.setIsUserActive(outptXMLlst.get(++k));
						String str_expdate = outptXMLlst.get(++k);

						if (!ClsUtil.isNullOrEmpty(str_expdate)) {
							try {
								regUserMaster.setExpiryDateTime(ClsConvertDate.ConvertxmlDatetostring(str_expdate));
							} catch (Exception e) {
								loggerErr.error("Date Parsing Exception for  FromDate while getting user list : "
										+ e.getMessage());
								e.printStackTrace();
							}
						}
						if (outptXMLlst.get(++k) != null && outptXMLlst.get(k).equalsIgnoreCase("1")) {
							regUserMaster.setPrivilege("Admin");
						} else if (outptXMLlst.get(k) != null && outptXMLlst.get(k).equalsIgnoreCase("2")) {
							regUserMaster.setPrivilege("Vendor Supervisor");
						} else {
							regUserMaster.setPrivilege("Vendor User");
						}
						regUserMaster.setLocked(outptXMLlst.get(++k));
						regUserMaster.setContactPersonName(outptXMLlst.get(++k));
						regUserMaster.setMobileNo(outptXMLlst.get(++k));
						regUserMaster.setUserType(ClsUtil.blankString(outptXMLlst.get(++k)));
						arrRegUserList.add(regUserMaster);
						i = k + 1;
					}
					paginationLastNo = regUserMaster.getUserIndex();
					prevRecordFlag = outptXMLlst.get(i++);
					lastRecordFlag = outptXMLlst.get(i);
				} else {
					int j = 0;
					paginationTopNo = outptXMLlst.get(0);
					for (int k = 0; k < (outptXMLlst.size() - 2); k++) {

						appUserMaster = new AppliedUser();

						appUserMaster.setUserIndex(outptXMLlst.get(k));
						appUserMaster.setUserName(outptXMLlst.get(++k));
						appUserMaster.setVendorCode(outptXMLlst.get(++k));
						appUserMaster.setVendorName(outptXMLlst.get(++k));
						appUserMaster.setVendorAdd(outptXMLlst.get(++k));
						appUserMaster.setEmailId(outptXMLlst.get(++k));
						appUserMaster.setPhoneNo(outptXMLlst.get(++k));
						appUserMaster.setStatus(outptXMLlst.get(++k));
						appUserMaster.setContactPersonName(outptXMLlst.get(++k));
						appUserMaster.setMobileNo(outptXMLlst.get(++k));
						appUserMaster.setPAN(ClsUtil.blankString(outptXMLlst.get(++k)));
						appUserMaster.setTAN(ClsUtil.blankString(outptXMLlst.get(++k)));
						appUserMaster.setServiceRegNo(ClsUtil.blankString(outptXMLlst.get(++k)));
						appUserMaster.setTIN(ClsUtil.blankString(outptXMLlst.get(++k)));

						arrAppUserList.add(appUserMaster);
						j = k + 1;
					}
					paginationLastNo = appUserMaster.getUserIndex();
					prevRecordFlag = outptXMLlst.get(j++);
					lastRecordFlag = outptXMLlst.get(j);
				}
			} else
				logger.debug("No data returned");
		} catch (Exception e) {
			loggerErr.error("Exception in getting User List With Details : " + e.getMessage());
			e.printStackTrace();

		}

		gen = new GeneralClass();

		if (!ClsUtil.isNullOrEmpty(userType) && userType.equalsIgnoreCase("RegUser")) {
			gen.setArrayRegisteredUser(arrRegUserList);
		} else {
			gen.setArrayAppliedUser(arrAppUserList);
		}
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopNo);
		gen.setPaginationLastQryNo(paginationLastNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting User List With Details  is " + totaltime);

		return gen;
	}

	/**
	 * This Method is used to get Popup User List.
	 * 
	 * @param String
	 *            usrName, String userType,String searchusr, String endurl.
	 * @return ArrayList<String>
	 * @exception Exception
	 */
	@Override
	public ArrayList<String> getUserList(String usrName, String userType, String searchusr, String endurl) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup User List method starts.......");
		logger.debug("logged in userName : " + usrName);
		ArrayList<String> arrUserList = new ArrayList<String>();
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Usertype", userType);
			xmlvalues.put("SearchUser", searchusr);
			xmlvalues.put("loggedinuser", usrName);

			option = "ProcedureSelectUserPopup";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0
					&& !(outptXMLlst.get(0).equalsIgnoreCase("No_User_Found"))) {
				for (int k = 0; k < outptXMLlst.size(); k++) {
					if (k == 0) {
						arrUserList.add("---Select---");
					}
					arrUserList.add(outptXMLlst.get(k));
				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is " + totaltime);

		return arrUserList;
	}

	public String getVPUserList(String userName, String userType, String searchString, String endurl,
			String cabinet, String minValue, String maxValue, String maxCount) {
		//userName,userType, searchString, EndPointurl,cabinet,Requesttype, minValue, maxValue, maxCount
		

		long starttime = System.currentTimeMillis();
		logger.debug("Popup User List method starts.......");
		logger.debug("logged in userName : " + userName);
		ArrayList<String> arrUserList = new ArrayList<String>();
		String SOAP_inxml = "";
		String option = "";
		String returnValue = "";
		String sCount = "";
		String strInvValues="";
		HashMap<String, String> xmlvalues = null;
		HashMap<String, String> xmlvalues1 = null;
		ArrayList<String> outptXMLlst = null;
		if (maxCount != null && maxCount.equals("0")) {
			try{			
				xmlvalues1=new HashMap<String,String>();								
				xmlvalues1.put("userType", userType);
				xmlvalues1.put("SearchUser",searchString);
				xmlvalues1.put("userName",userName);				
				option="ProcedureGetUserListCount";			
				SOAP_inxml=GenerateXML.generatexml(xmlvalues1,option);
				logger.debug("Count SOAP_inxml =========> "+SOAP_inxml);
				// Webservice call
				outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
				logger.debug("Count outptXMLlst =========> "+SOAP_inxml);
				if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
				{			
					sCount=outptXMLlst.get(0);
					logger.debug("totalcount =========> "+sCount);
				}
				 if (sCount != null) {
	                 returnValue = sCount + "&#";
	             }
				
			}catch (Exception e) {
				loggerErr.error("Exception in Popup InvoiceList Count  : " + e.getMessage());
				e.printStackTrace();
			}
			
			}else {
	            returnValue = maxCount + "&#";
	        }
		try {

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Usertype", userType);
			xmlvalues.put("SearchUser", searchString);
			xmlvalues.put("loggedinuser", userName);
			xmlvalues.put("minValue", minValue);
			xmlvalues.put("maxValue", maxValue);
			xmlvalues.put("maxCount", maxCount);

			option = "ProcedureGetVPUserListPopup";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				for (int k = 0; k < outptXMLlst.size(); k++) {					
					arrUserList.add(outptXMLlst.get(k));
				}
			}
			
			if (!arrUserList.isEmpty()) {

				 strInvValues = arrUserList.toString().replaceAll("\\[", "");
	                strInvValues = strInvValues.replaceAll("\\]", "");

	                logger.debug("*************** strInvValues" + strInvValues);
	                returnValue = returnValue + strInvValues;
	                logger.debug("Get User Return value: " + returnValue);
	                return returnValue;
	            } else {
	            	returnValue="No Users Found,";
	                return returnValue;
	            }

		} catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is " + totaltime);

		return returnValue;
	}

	
	public ArrayList<String> getUserForHistoryList(String usrName, String userType, String searchusr, String endurl) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup getUserForHistoryList method starts.......");
		ArrayList<String> arrUserList = new ArrayList<String>();
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {

			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("Usertype", userType);
			xmlvalues.put("SearchUser", searchusr);
			xmlvalues.put("loggedinuser", usrName);

			option = "ProcedureSelectUserForHistoryPopup";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0
					&& !(outptXMLlst.get(0).equalsIgnoreCase("No_User_Found"))) {
				for (int k = 0; k < outptXMLlst.size(); k++) {
					if (k == 0) {
						arrUserList.add("---Select---");
					}
					arrUserList.add(outptXMLlst.get(k));
				}
			}

		} catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is " + totaltime);

		return arrUserList;
	}

}
