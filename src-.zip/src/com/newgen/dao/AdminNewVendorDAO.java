/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminNewVendorDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  This is a Data access object class which interacts with database and perform CURD Operations i.e. Insert & Update.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorMaster;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class AdminNewVendorDAO implements AdminNewVendorDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to add & update Vendor.
	 * 
	 * @param VendorMaster
	 *            vendorMaster
	 * @param String
	 *            buttonType, String tempVendorCode, String tempCompanyCode
	 * @return int result
	 * @exception Exception
	 */
	@Override
	public int addNewVendor(VendorMaster vendorMaster, String buttonType, String tempVendorCode, String tempCompanyCode,
			String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("addNewVendor Method Starts...");

		String SOAP_inxml = "";
		String option = "";
		int result = 0;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("VendCode", vendorMaster.getVendorCode());
			xmlvalues.put("VendName", ClsUtil.replaceString(vendorMaster.getVendorName()));
			xmlvalues.put("VendAdrs", ClsUtil.replaceString(vendorMaster.getVendorAddress()));
			xmlvalues.put("VendEmailid", vendorMaster.getVendorEmailId());
			xmlvalues.put("VSPOC", vendorMaster.getSPOC());
			xmlvalues.put("VSpocEmailid", vendorMaster.getSPOCEmailId());
			xmlvalues.put("VCurrency", vendorMaster.getCurrency());
			xmlvalues.put("CompCode", "001");// Hardcoded Here
			xmlvalues.put("ContactPersonName", ClsUtil.replaceString(vendorMaster.getContactPersonName()));
			xmlvalues.put("MobileNo", vendorMaster.getMobileNo());
			xmlvalues.put("PAN", vendorMaster.getPAN());
			xmlvalues.put("TAN", vendorMaster.getTAN());
			xmlvalues.put("ServiceRegNo", vendorMaster.getServiceRegNo());
			xmlvalues.put("TIN", vendorMaster.getTIN());
			xmlvalues.put("TelephoneNo", vendorMaster.getTelephoneNo());
			xmlvalues.put("UserId", vendorMaster.getUserId());// Newly Added
			xmlvalues.put("FormStatus", vendorMaster.getFormStatus());// Newly
																		// Added

			option = "ProcedureSelectAddVendr";

			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			if (outptXMLlst.get(0).equalsIgnoreCase("UpdateVendor")) {
				logger.debug("Vendor Updated successfully");
				result = 11;
			} else if (outptXMLlst.get(0).equalsIgnoreCase("InsertedUser")) {
				logger.debug("New User Inserted successfully");
				AdminUserDAO adminUserDAO = new AdminUserDAO();

				int result1 = adminUserDAO.sendEmail(vendorMaster.getUserId(), endurl);
				if (result1 == 1) {
					result = 12;
				} else {
					logger.debug("Mail not sent ");
					result = 12;
				}
			}

			else if (outptXMLlst.get(0).equalsIgnoreCase("Exception")) {
				logger.debug("Exception while creating user");
				result = 13;

			} else if (outptXMLlst.get(0).equalsIgnoreCase("InsertedVendorUser")) {
				logger.debug("New Vendor Inserted successfully");
				AdminUserDAO adminUserDAO = new AdminUserDAO();

				int result1 = adminUserDAO.sendEmail(vendorMaster.getUserId(), endurl);
				if (result1 == 1) {
					result = 1;
				} else {
					logger.debug("Mail not sent ");
					result = 1;
				}
			} else if (outptXMLlst.get(0).equalsIgnoreCase("NoCompanyData")) {
				logger.debug("Company code does not exist : " + "Company code not found ");
				result = -1;
			} else
				result = -2;

		} catch (Exception e) {
			loggerErr.error("Exception While Adding New Vendor By Admin : " + e.getMessage());
			e.printStackTrace();

		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in adding New Vendor by admin is " + totaltime);

		return result;
	}

	/**
	 * This Method is used to get Vendor Details by Vendor Code.
	 * 
	 * @param String
	 *            vendorCode,String endurl
	 * @return GeneralClass gen
	 * @exception Exception
	 */
	@Override
	public GeneralClass getVendorDetails(String vendorCode, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("Getting Vendor Details");
		ArrayList<VendorMaster> arrayVendorDetails = new ArrayList<VendorMaster>();
		VendorMaster venMaster = null;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("VendorCode", vendorCode);
			option = "ProcedureVenDataByCode";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("#AdminNewVendorDAO outptXMLlst-->" + outptXMLlst);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				for (int k = 0; k < outptXMLlst.size(); k++) {
					venMaster = new VendorMaster();
					venMaster.setVendorCode(outptXMLlst.get(k));
					venMaster.setVendorName(outptXMLlst.get(++k));
					venMaster.setVendorAddress(outptXMLlst.get(++k));
					venMaster.setVendorEmailId(outptXMLlst.get(++k));
					venMaster.setIsVendorActive(outptXMLlst.get(++k));
					venMaster.setContactPersonName(outptXMLlst.get(++k));
					venMaster.setMobileNo(outptXMLlst.get(++k));
					venMaster.setPAN(outptXMLlst.get(++k));
					venMaster.setTAN(outptXMLlst.get(++k));
					venMaster.setServiceRegNo(outptXMLlst.get(++k));
					venMaster.setTIN(outptXMLlst.get(++k));
					venMaster.setTelephoneNo(outptXMLlst.get(++k));
					venMaster.setUserId(outptXMLlst.get(++k));
					arrayVendorDetails.add(venMaster);
				}
				logger.debug("Got Vendor Details Successfully");
			}
		} catch (Exception e) {
			loggerErr.error("Exception While Getting Vendor Details By Admin : " + e.getMessage());
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		GeneralClass gen = new GeneralClass();
		gen.setArrayVendorList(arrayVendorDetails);
		logger.debug("Total Time Taken in Getting Vendor Details  by admin is " + totaltime);

		return gen;
	}
}
