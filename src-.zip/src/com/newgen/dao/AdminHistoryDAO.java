/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminHistoryDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations i.e UPDATE & SELECT
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserActivityTable;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class AdminHistoryDAO implements AdminHistoryDAOI {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to getHistory.
	 * 
	 * @param GeneralClass
	 *            gen, String userHistory, Date dateFrom, Date dateTo, String
	 *            endurl.
	 * @return GeneralClass
	 * @exception Exception
	 */
	public GeneralClass getHistory(GeneralClass gen, String userHistory, Date dateFrom, Date dateTo, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("getHistory Method Starts...");
		int totalRecords = 0;
		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = null;
		String paginationLastQryNo = null;
		int bufferSize = 0;

		String paginationSql = null;

		int totalRecordsPrev = 0;
		int totalRecordsNext = 0;
		Timestamp tDateFrom = null;
		Timestamp tDateTo = null;
		String str_todate = "";
		String str_frdate = "";
		VPUserActivityTable activityTable = null;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;
		ArrayList<VPUserActivityTable> arrHistory = new ArrayList<VPUserActivityTable>();

		// Checking GeneralClass object is null or empty
		if (!ClsUtil.isNullOrEmpty(gen)) {
			paginationTopQryNo = gen.getPaginationTopQryNo();
			paginationLastQryNo = gen.getPaginationLastQryNo();
			bufferSize = gen.getBatchSize();

			if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
				paginationSql = paginationLastQryNo;
			} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
				paginationSql = paginationTopQryNo;
			} else {
				paginationSql = "";
			}

			try {
				xmlvalues = new HashMap<String, String>();
				// Checking dateFrom and dateTo is null or empty
				if (!ClsUtil.isNullOrEmpty(dateFrom) && !ClsUtil.isNullOrEmpty(dateTo)) {
					tDateFrom = new Timestamp(dateFrom.getTime());
					tDateTo = new Timestamp(dateTo.getTime() + (1000 * 60 * 60 * 24));
					str_todate = tDateTo.toString();
					str_frdate = tDateFrom.toString();
				} else {
					str_todate = "";
					str_frdate = "";
				}

				xmlvalues.put("Linktype", gen.getLinkType());
				xmlvalues.put("paginationTopNo", paginationTopQryNo);
				xmlvalues.put("paginationLastQryNo", paginationLastQryNo);
				xmlvalues.put("UserHistory", userHistory);
				xmlvalues.put("Buffersize", String.valueOf(bufferSize));
				xmlvalues.put("dateTo", str_todate);
				xmlvalues.put("dateFrom", str_frdate);
				option = "ProcedureSelectGetHistory";
				SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
				// Webservice call
				outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

				if (!ClsUtil.isNullOrEmpty(outptXMLlst)) {
					paginationTopQryNo = outptXMLlst.get(0);
					for (int k = 0; k < outptXMLlst.size(); k++) {
						activityTable = new VPUserActivityTable();
						activityTable.setActivityId(outptXMLlst.get(k));
						activityTable.setUserName(outptXMLlst.get(++k));
						activityTable.setActivityType(outptXMLlst.get(++k));
						activityTable.setActivityDesc(outptXMLlst.get(++k));
						activityTable.setSessionID(outptXMLlst.get(++k));
						activityTable.setActivityDateTime(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
						arrHistory.add(activityTable);
					}
					paginationLastQryNo = activityTable.getActivityId();

					xmlvalues.clear();
					xmlvalues.put("paginationSql", paginationSql);
					xmlvalues.put("paginationLastNo", paginationLastQryNo);
					xmlvalues.put("paginationTopNo", paginationTopQryNo);
					xmlvalues.put("UserHistory", userHistory);
					xmlvalues.put("dateTo", str_todate);
					xmlvalues.put("dateFrom", str_frdate);

					String sOption = "ProcedureTotalHistoryrecord";
					SOAP_inxml = "";

					SOAP_inxml = GenerateXML.generatexml(xmlvalues, sOption);

					// Webservice call
					outptXMLlst.clear();
					outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
					if (!ClsUtil.isNullOrEmpty(outptXMLlst))

						if (!paginationSql.trim().equals("")) {

							totalRecordsNext = Integer.parseInt(outptXMLlst.get(0));
							logger.debug("Admin History : Total Next History" + totalRecordsNext);
							totalRecordsPrev = Integer.parseInt(outptXMLlst.get(1));
							logger.debug("Admin History: Total Previous History" + totalRecordsPrev);

							if (!(totalRecordsNext > 0)) {
								lastRecordFlag = "last";
							}
							if (totalRecordsPrev == 0) {
								prevRecordFlag = "first";
							}

						} else {
							totalRecords = Integer.parseInt(outptXMLlst.get(0));

							if (totalRecordsPrev <= bufferSize) {
								prevRecordFlag = "first";
							}
							if (totalRecords <= bufferSize) {
								lastRecordFlag = "last";
							}
						}
				}
			} catch (Exception e) {
				loggerErr.error("Exception in getting History : " + e.getMessage());
				e.printStackTrace();
			}
		}
		gen = new GeneralClass();
		gen.setArrayUserActivity(arrHistory);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting History is " + totaltime);
		return gen;
	}
}
