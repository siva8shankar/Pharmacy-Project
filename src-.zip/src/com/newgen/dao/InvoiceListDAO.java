/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: InvoiceListDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations i.e UPDATE & SELECT
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)  
* 26/10/2017					ksivashankar				Added getPOLineItem method for displaying PO Line Items                                      
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.SAPConPODetails;
import com.newgen.bean.SAPPODetails;
import com.newgen.bean.SubmitQueryListNew;
import com.newgen.bean.VPUserMaster;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;
import com.newgen.util.SAPFunctions;
import com.newgen.wfdesktop.xmlapi.WFXmlList;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;

public class InvoiceListDAO implements InvoiceListDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
    private static Logger loggerErr = Logger.getLogger("errorLogger"); 
	/**
	 * This Method is used to getUserListWithDetails.
	 * @param String userType, GeneralClass gen, String searchUser, String loggedInUser, String endurl.
	 * @return GeneralClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass getInvoiceListWithDetails(String userType, GeneralClass gen, String searchUser, String loggedInUser, String searchType, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("getUserListWithDetails Method Starts...");

			String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopNo = gen.getPaginationTopQryNo();
		String paginationLastNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;				
		
		VPUserMaster regUserMaster = null;
		AppliedUser appUserMaster = null;
		ArrayList<VPUserMaster> arrRegUserList = new ArrayList<VPUserMaster>();
		ArrayList<AppliedUser> arrAppUserList = new ArrayList<AppliedUser>();
		
		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastNo;
		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopNo;
		} else {
			paginationSql = "";
		}
		

		try {
			logger.debug("searchType--->"+searchType);
			
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("Usertype", userType);
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("SearchUser", searchUser);			
			xmlvalues.put("loggedinuser", loggedInUser);
			xmlvalues.put("SearchType", searchType);

			option="ProcedureSelectUserlst";

			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("#AdminUserListDAO outptXMLlst-->"+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>2)
			{	
				
				if(!ClsUtil.isNullOrEmpty(userType) && userType.equalsIgnoreCase("RegUser"))
				{   int i=0;
					paginationTopNo = outptXMLlst.get(0);
					for(int k=0 ;k<(outptXMLlst.size()-2);k++)
					{
						regUserMaster = new VPUserMaster();

						regUserMaster.setUserIndex(outptXMLlst.get(k));
						regUserMaster.setUserName(outptXMLlst.get(++k));
						regUserMaster.setVendorCode(outptXMLlst.get(++k));
						regUserMaster.setVendorName(outptXMLlst.get(++k));
						regUserMaster.setVendorAddress(outptXMLlst.get(++k));
						regUserMaster.setUserAddress(outptXMLlst.get(++k));
						regUserMaster.setUserEmailId(outptXMLlst.get(++k));
						regUserMaster.setUserPhoneNumber(outptXMLlst.get(++k));
						regUserMaster.setIsUserActive(outptXMLlst.get(++k));
						String str_expdate =outptXMLlst.get(++k);
						
						if (!ClsUtil.isNullOrEmpty(str_expdate)) {
							try{
								regUserMaster.setExpiryDateTime(ClsConvertDate.ConvertxmlDatetostring(str_expdate));
							} catch (Exception e) {
								loggerErr.error("Date Parsing Exception for  FromDate while getting user list : " + e.getMessage());
								e.printStackTrace();
							}
						}
						if(outptXMLlst.get(++k) != null && outptXMLlst.get(k).equalsIgnoreCase("1")){
							regUserMaster.setPrivilege("Admin");
						}else if(outptXMLlst.get(k) != null && outptXMLlst.get(k).equalsIgnoreCase("2")){
							regUserMaster.setPrivilege("Vendor Supervisor");
						}else{
							regUserMaster.setPrivilege("Vendor User");
						}						
						regUserMaster.setLocked(outptXMLlst.get(++k));
						regUserMaster.setContactPersonName(outptXMLlst.get(++k));
						regUserMaster.setMobileNo(outptXMLlst.get(++k));
						regUserMaster.setPAN(ClsUtil.blankString(outptXMLlst.get(++k)));
						regUserMaster.setTAN(ClsUtil.blankString(outptXMLlst.get(++k)));
						regUserMaster.setServiceRegNo(ClsUtil.blankString(outptXMLlst.get(++k)));
						regUserMaster.setTIN(ClsUtil.blankString(outptXMLlst.get(++k)));
						arrRegUserList.add(regUserMaster);
						i=k+1;
					}
					paginationLastNo =  regUserMaster.getUserIndex();
					prevRecordFlag=outptXMLlst.get(i++);
					lastRecordFlag=outptXMLlst.get(i);
				}
				else {
					int j=0;
					paginationTopNo = outptXMLlst.get(0);
					for(int k=0 ;k<(outptXMLlst.size()-2);k++)
					{
						
						appUserMaster = new AppliedUser();
						
						appUserMaster.setUserIndex(outptXMLlst.get(k));
						appUserMaster.setUserName(outptXMLlst.get(++k));
						appUserMaster.setVendorCode(outptXMLlst.get(++k));
						appUserMaster.setVendorName(outptXMLlst.get(++k));
						appUserMaster.setVendorAdd(outptXMLlst.get(++k));
						appUserMaster.setEmailId(outptXMLlst.get(++k));
						appUserMaster.setPhoneNo(outptXMLlst.get(++k));	
						appUserMaster.setStatus(outptXMLlst.get(++k));
						appUserMaster.setContactPersonName(outptXMLlst.get(++k));
						appUserMaster.setMobileNo(outptXMLlst.get(++k));
						appUserMaster.setPAN(ClsUtil.blankString(outptXMLlst.get(++k)));
						appUserMaster.setTAN(ClsUtil.blankString(outptXMLlst.get(++k)));
						appUserMaster.setServiceRegNo(ClsUtil.blankString(outptXMLlst.get(++k)));
						appUserMaster.setTIN(ClsUtil.blankString(outptXMLlst.get(++k)));

						arrAppUserList.add(appUserMaster);
						j=k+1;
					}
					paginationLastNo =appUserMaster.getUserIndex() ;
					prevRecordFlag=outptXMLlst.get(j++);
					lastRecordFlag=outptXMLlst.get(j);
				}
			}
			else 
				logger.debug("No data returned");
	} catch (Exception e) {
			loggerErr.error("Exception in getting User List With Details : " + e.getMessage());
			e.printStackTrace();

		} 

		gen = new GeneralClass();
		
		if(!ClsUtil.isNullOrEmpty(userType) && userType.equalsIgnoreCase("RegUser")){
			gen.setArrayRegisteredUser(arrRegUserList);	
		}else{
			gen.setArrayAppliedUser(arrAppUserList);
		}
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopNo);
		gen.setPaginationLastQryNo(paginationLastNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting User List With Details  is "+totaltime);

		return gen;
	}


	/**
	 * This Method is used to get Popup User List.
	 * @param String usrName, String userType,String searchusr, String endurl.
	 * @return ArrayList<String> 
	 * @exception Exception
	 */
	@Override
	public ArrayList<SubmitQueryListNew> getInvoiceList(String vendorCode,String InvoiceNumber,String userPrevilage,String endurl,String cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup Invoice List method starts......." );
		ArrayList<SubmitQueryListNew> arrList = new ArrayList<SubmitQueryListNew>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;	
		SubmitQueryListNew submitQueryListNew=null;
		try {
			logger.debug("vendorCode ========>  "+vendorCode);
			logger.debug("InvoiceNumber ========>  "+InvoiceNumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("vendorcode",vendorCode);
			xmlvalues.put("InvoiceNumber",InvoiceNumber);
			xmlvalues.put("userPrevilage", userPrevilage);
			option="ProcedureInvoiceListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0 && !(outptXMLlst.get(0).equalsIgnoreCase("No_Invoice_Found")))
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					if(k == 0){
						submitQueryListNew = new SubmitQueryListNew();
						submitQueryListNew.setInvoiceno("---Select---");
						submitQueryListNew.setTransactionno("");
						arrList.add(submitQueryListNew);
					}
					submitQueryListNew = new SubmitQueryListNew();
					submitQueryListNew.setInvoiceno(outptXMLlst.get(k));
					submitQueryListNew.setTransactionno(outptXMLlst.get(++k));
					arrList.add(submitQueryListNew);	
					i=k+1;
				}
			}

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is "+totaltime);

		return arrList;
	}
	
	public ArrayList<SubmitQueryListNew> getUniqueInvoiceList(String vendorCode,String InvoiceNumber,String userPrevilage,String endurl,String cabinet,String RequestType) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup Invoice List method starts......." );
		ArrayList<SubmitQueryListNew> arrList = new ArrayList<SubmitQueryListNew>();
		ArrayList<SubmitQueryListNew> arrList1 = new ArrayList<SubmitQueryListNew>();
		ArrayList<SubmitQueryListNew> arrListRes = new ArrayList<SubmitQueryListNew>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;	
		SubmitQueryListNew submitQueryListNew=null;
		try {
			logger.debug("vendorCode ========>  "+vendorCode);
			logger.debug("InvoiceNumber ========>  "+InvoiceNumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("vendorcode",vendorCode);
			xmlvalues.put("InvoiceNumber",InvoiceNumber);
			xmlvalues.put("userPrevilage", userPrevilage);
			option="ProcedureUniqueInvoiceListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);					
			
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0 && !(outptXMLlst.get(0).equalsIgnoreCase("No_Invoice_Found")))
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					if(k == 0){
						submitQueryListNew = new SubmitQueryListNew();
						submitQueryListNew.setInvoiceno("---Select---");
						arrList.add(submitQueryListNew);
					}
					submitQueryListNew = new SubmitQueryListNew();
					submitQueryListNew.setInvoiceno(outptXMLlst.get(k));
					arrList.add(submitQueryListNew);	
					i=k+1;
				}
				
				if(RequestType.equalsIgnoreCase("MyQueries")){
					String[] InvoicesArr = null;
					String strInvoiceNumber = "";
					String strInvList="";
					String[] arrstrInvList = null;
					InvoicesArr = new String[1000];
					if (arrList.size() > 0) {
						for (int j = 0; j < arrList.size(); j++) {
							InvoicesArr[j] = arrList.get(j).getInvoiceno();
							strInvoiceNumber += InvoicesArr[j] + ",";
						}
						logger.debug("Output strInvoiceNumber--->" + strInvoiceNumber);
						xmlvalues.clear();
				}
					
					try {
						xmlvalues.put("InvoiceNumbers", strInvoiceNumber);
						String statusOption = "ProcedureQueryInvoicesList";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strInvList = outptXMLlst.get(0);
							arrstrInvList = strInvList.split(",");
						} else {
							for (int k = 0; k < outptXMLlst.size(); k++) {
								arrstrInvList[k] = "NO InvoiceNo";
							}
						}
						
						for (int l = 0;l < arrstrInvList.length;l++){
							if(l == 0){
								submitQueryListNew = new SubmitQueryListNew();
								submitQueryListNew.setInvoiceno("---Select---");
								arrList1.add(submitQueryListNew);
							}
							submitQueryListNew = new SubmitQueryListNew();
							submitQueryListNew.setInvoiceno(arrstrInvList[l]);
							arrList1.add(submitQueryListNew);
						}
						arrListRes=arrList1;
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting status  : " + e.getMessage());

					}
				}else{
					arrListRes=arrList;
				}
			}

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is "+totaltime);

		return arrListRes;
	}
	
	public String getVPInvoiceList(String vendorCode,String InvoiceNumber,String userPrevilage,
			String endurl,String cabinet,String RequestType, String minValue, String maxValue,
            String maxCount) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup Invoice List method starts......." );
		ArrayList<String> arrList = new ArrayList();
		String SOAP_inxml="";
		String option="";
		String returnValue = "";
		String sCount = "";
		String strInvValues;
		HashMap<String,String> xmlvalues =null;
		HashMap<String,String> xmlvalues1 =null;
		ArrayList<String> outptXMLlst=null;	
		SubmitQueryListNew submitQueryListNew=null;
		if (maxCount != null && maxCount.equals("0")) {
		try{			
			xmlvalues1=new HashMap<String,String>();
			xmlvalues1.put("vendorcode",vendorCode);
			xmlvalues1.put("InvoiceNumber",InvoiceNumber);
			xmlvalues1.put("userPrevilage", userPrevilage);
			option="ProcedureInvoiceListCount";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues1,option,cabinet);
			logger.debug("Count SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("Count outptXMLlst =========> "+SOAP_inxml);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{			
				sCount=outptXMLlst.get(0);
				logger.debug("totalcount =========> "+sCount);
			}
			 if (sCount != null) {
                 returnValue = sCount + "&#";
             }
			
		}catch (Exception e) {
			loggerErr.error("Exception in Popup InvoiceList Count  : " + e.getMessage());
			e.printStackTrace();
		}
		
		}else {
            returnValue = maxCount + "&#";
        }
		
		
		try {
			logger.debug("vendorCode ========>  "+vendorCode);
			logger.debug("InvoiceNumber ========>  "+InvoiceNumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("vendorcode",vendorCode);
			xmlvalues.put("InvoiceNumber",InvoiceNumber);
			xmlvalues.put("userPrevilage", userPrevilage);
			xmlvalues.put("minValue", minValue);
			xmlvalues.put("maxValue", maxValue);
			xmlvalues.put("maxCount", maxCount);
			option="ProcedureGetVPInvoiceListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);					
			
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					arrList.add(outptXMLlst.get(k));
				}
				
			}
			
			 if (!arrList.isEmpty()) {

				 strInvValues = arrList.toString().replaceAll("\\[", "");
	                strInvValues = strInvValues.replaceAll("\\]", "");

	                logger.debug("*************** strInvValues" + strInvValues);
	                returnValue = returnValue + strInvValues;
	                logger.debug("Get User Return value: " + returnValue);
	                return returnValue;
	            } else {
	            	returnValue="No Invoices Found";
	                return returnValue;
	            }			 			 

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}			

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is "+totaltime);
		return returnValue;
	}
	
	public String getTCPIDList(String vendorCode,String InvoiceNumber,String userPrevilage,
			String endurl,String cabinet,String RequestType, String minValue, String maxValue,
            String maxCount) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup getTCPIDList List method starts......." );
		ArrayList<String> arrList = new ArrayList();
		String SOAP_inxml="";
		String option="";
		String returnValue = "";
		String sCount = "";
		String strInvValues;
		HashMap<String,String> xmlvalues =null;
		HashMap<String,String> xmlvalues1 =null;
		ArrayList<String> outptXMLlst=null;	
		SubmitQueryListNew submitQueryListNew=null;
		if (maxCount != null && maxCount.equals("0")) {
		try{			
			xmlvalues1=new HashMap<String,String>();
			xmlvalues1.put("vendorcode",vendorCode);
			xmlvalues1.put("InvoiceNumber",InvoiceNumber);
			xmlvalues1.put("userPrevilage", userPrevilage);
			option="ProcedurePIDistCount";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues1,option,cabinet);
			logger.debug("Count SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("Count outptXMLlst =========> "+SOAP_inxml);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{			
				sCount=outptXMLlst.get(0);
				logger.debug("totalcount =========> "+sCount);
			}
			 if (sCount != null) {
                 returnValue = sCount + "&#";
             }
			
		}catch (Exception e) {
			loggerErr.error("Exception in Popup InvoiceList Count  : " + e.getMessage());
			e.printStackTrace();
		}
		
		}else {
            returnValue = maxCount + "&#";
        }
		
		
		try {
			logger.debug("vendorCode ========>  "+vendorCode);
			logger.debug("InvoiceNumber ========>  "+InvoiceNumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("vendorcode",vendorCode);
			xmlvalues.put("InvoiceNumber",InvoiceNumber);
			xmlvalues.put("userPrevilage", userPrevilage);
			xmlvalues.put("minValue", minValue);
			xmlvalues.put("maxValue", maxValue);
			xmlvalues.put("maxCount", maxCount);
			option="ProcedureGetTCPIDistPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);					
			
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					arrList.add(outptXMLlst.get(k));
				}
				
			}
			
			 if (!arrList.isEmpty()) {

				 strInvValues = arrList.toString().replaceAll("\\[", "");
	                strInvValues = strInvValues.replaceAll("\\]", "");

	                logger.debug("*************** strInvValues" + strInvValues);
	                returnValue = returnValue + strInvValues;
	                logger.debug("Get User Return value: " + returnValue);
	                return returnValue;
	            } else {
	            	returnValue="No Invoices Found";
	                return returnValue;
	            }			 			 

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}			

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is "+totaltime);
		return returnValue;
	}
	
	public String getVPTransactionsList(String vendorCode,String InvoiceNumber,String searchString,String userPrevilage,
			String endurl,String cabinet,String RequestType, String minValue, String maxValue,
            String maxCount) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup Invoice List method starts......." );
		ArrayList<String> arrList = new ArrayList();
		String SOAP_inxml="";
		String option="";
		String returnValue = "";
		String sCount = "";
		String strInvValues;
		HashMap<String,String> xmlvalues =null;
		HashMap<String,String> xmlvalues1 =null;
		ArrayList<String> outptXMLlst=null;	
		SubmitQueryListNew submitQueryListNew=null;
		if (maxCount != null && maxCount.equals("0")) {
		try{			
			xmlvalues1=new HashMap<String,String>();
			xmlvalues1.put("vendorcode",vendorCode);
			xmlvalues1.put("InvoiceNumber",InvoiceNumber);
			xmlvalues1.put("searchString",searchString);
			xmlvalues1.put("userPrevilage", userPrevilage);
			option="ProcedureInvoiceTransactionListCount";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues1,option,cabinet);
			logger.debug("Count SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("Count outptXMLlst =========> "+SOAP_inxml);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{			
				sCount=outptXMLlst.get(0);
				logger.debug("totalcount =========> "+sCount);
			}
			 if (sCount != null) {
                 returnValue = sCount + "&#";
             }
			
		}catch (Exception e) {
			loggerErr.error("Exception in Popup InvoiceList Count  : " + e.getMessage());
			e.printStackTrace();
		}
		
		}else {
            returnValue = maxCount + "&#";
        }
		
		
		try {
			logger.debug("vendorCode ========>  "+vendorCode);
			logger.debug("InvoiceNumber ========>  "+InvoiceNumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("vendorcode",vendorCode);		
			xmlvalues.put("InvoiceNumber",InvoiceNumber);
			xmlvalues.put("searchString",searchString);
			xmlvalues.put("userPrevilage", userPrevilage);
			xmlvalues.put("minValue", minValue);
			xmlvalues.put("maxValue", maxValue);
			xmlvalues.put("maxCount", maxCount);
			option="ProcedureGetVPInvoiceTransactionListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);					
			
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					arrList.add(outptXMLlst.get(k));
				}
				
			}
			
			 if (!arrList.isEmpty()) {

				 strInvValues = arrList.toString().replaceAll("\\[", "");
	                strInvValues = strInvValues.replaceAll("\\]", "");

	                logger.debug("*************** strInvValues" + strInvValues);
	                returnValue = returnValue + strInvValues;
	                logger.debug("Get User Return value: " + returnValue);
	                return returnValue;
	            } else {
	            	returnValue="No Transactions Found";
	                return returnValue;
	            }			 			 

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}			

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is "+totaltime);
		return returnValue;
	}
	
	public String getVPQueryInvoicesList(String vendorCode,String InvoiceNumber,String userPrevilage,
			String endurl,String cabinet,String RequestType, String minValue, String maxValue,
            String maxCount) {

		long starttime = System.currentTimeMillis();
		logger.debug("Inside getVPQueryInvoicesList method starts......." );
		ArrayList<String> arrList = new ArrayList();
		String SOAP_inxml="";
		String option="";
		String returnValue = "";
		String sCount = "";
		String strInvValues;
		HashMap<String,String> xmlvalues =null;
		HashMap<String,String> xmlvalues1 =null;
		ArrayList<String> outptXMLlst=null;	
		SubmitQueryListNew submitQueryListNew=null;
		if (maxCount != null && maxCount.equals("0")) {
		try{			
			xmlvalues1=new HashMap<String,String>();
			xmlvalues1.put("vendorcode",vendorCode);
			xmlvalues1.put("InvoiceNumber",InvoiceNumber);
			xmlvalues1.put("userPrevilage", userPrevilage);
			option="ProcedureInvoiceListCount";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues1,option,cabinet);
			logger.debug("Count SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("Count outptXMLlst =========> "+SOAP_inxml);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{			
				sCount=outptXMLlst.get(0);
				logger.debug("totalcount =========> "+sCount);
			}
			 if (sCount != null) {
                 returnValue = sCount + "&#";
             }
			
		}catch (Exception e) {
			loggerErr.error("Exception in Popup InvoiceList Count  : " + e.getMessage());
			e.printStackTrace();
		}
		
		}else {
            returnValue = maxCount + "&#";
        }
		
		
		try {
			logger.debug("vendorCode ========>  "+vendorCode);
			logger.debug("InvoiceNumber ========>  "+InvoiceNumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("vendorcode",vendorCode);
			xmlvalues.put("InvoiceNumber",InvoiceNumber);
			xmlvalues.put("userPrevilage", userPrevilage);
			xmlvalues.put("minValue", minValue);
			xmlvalues.put("maxValue", maxValue);
			xmlvalues.put("maxCount", maxCount);
			option="ProcedureGetVPInvoiceListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);					
			
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					arrList.add(outptXMLlst.get(k));
				}
				
			}
			
			 if (!arrList.isEmpty()) {

				 strInvValues = arrList.toString().replaceAll("\\[", "");
	                strInvValues = strInvValues.replaceAll("\\]", "");

	                logger.debug("*************** strInvValues" + strInvValues);
	                returnValue = returnValue + strInvValues;
	                logger.debug("Get User Return value: " + returnValue);
	                return returnValue;
	            } else {
	            	returnValue="No Invoices Found";
	                return returnValue;
	            }			 			 

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}			

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is "+totaltime);
		return returnValue;
	}

	
	public ArrayList<SubmitQueryListNew> getQueryList(String userName,String userPrevilage, String endurl) {

		long starttime = System.currentTimeMillis();
		logger.debug("inside getQueryList method starts......." );
		ArrayList<SubmitQueryListNew> arrList = new ArrayList<SubmitQueryListNew>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;	
		SubmitQueryListNew submitQueryListNew=null;
		try {
			logger.debug("userName ========>  "+userName);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("userName",userName);
			xmlvalues.put("userPrevilage", userPrevilage);

			option="ProcedureQueryListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0 && !(outptXMLlst.get(0).equalsIgnoreCase("No_Invoice_Found")))
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					if(k == 0){
						submitQueryListNew = new SubmitQueryListNew();
						submitQueryListNew.setQuerynumber("---Select---");
						submitQueryListNew.setCasenumber("");
						arrList.add(submitQueryListNew);
					}
					submitQueryListNew = new SubmitQueryListNew();
					submitQueryListNew.setQuerynumber(outptXMLlst.get(k));
					submitQueryListNew.setCasenumber(outptXMLlst.get(++k));
					arrList.add(submitQueryListNew);	
					i=k+1;
				}
			}

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is "+totaltime);

		return arrList;
	}
	
	public String getVPQueryList(String userName,String userPrevilage, String endurl,
			String QueryNumber,String minValue,String maxValue,String maxCount) {

		long starttime = System.currentTimeMillis();
		logger.debug("inside getQueryList method starts......." );
		ArrayList<String> arrList = new ArrayList<String>();
		String SOAP_inxml="";
		String option="";
		String returnValue = "";
		String sCount = "";
		String strInvValues="";
		HashMap<String,String> xmlvalues =null;
		HashMap<String,String> xmlvalues1 =null;
		ArrayList<String> outptXMLlst=null;	
		SubmitQueryListNew submitQueryListNew=null;
		if (maxCount != null && maxCount.equals("0")) {
			try{			
				xmlvalues1=new HashMap<String,String>();				
				xmlvalues1.put("userName",userName);
				xmlvalues1.put("userPrevilage", userPrevilage);
				xmlvalues1.put("QueryNumber",QueryNumber);
				option="ProcedureQueryListCount";			
				SOAP_inxml=GenerateXML.generatexml(xmlvalues1,option);
				logger.debug("Count SOAP_inxml =========> "+SOAP_inxml);
				// Webservice call
				outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
				logger.debug("Count outptXMLlst =========> "+SOAP_inxml);
				if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
				{			
					sCount=outptXMLlst.get(0);
					logger.debug("totalcount =========> "+sCount);
				}
				 if (sCount != null) {
	                 returnValue = sCount + "&#";
	             }
				
			}catch (Exception e) {
				loggerErr.error("Exception in Popup InvoiceList Count  : " + e.getMessage());
				e.printStackTrace();
			}
			
			}else {
	            returnValue = maxCount + "&#";
	        }
		try {
			logger.debug("userName ========>  "+userName);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("userName",userName);
			xmlvalues.put("userPrevilage", userPrevilage);
			xmlvalues.put("QueryNumber", QueryNumber);
			xmlvalues.put("minValue", minValue);
			xmlvalues.put("maxValue", maxValue);
			xmlvalues.put("maxCount", maxCount);

			option="ProcedureVPQueryListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{					
					arrList.add(outptXMLlst.get(k));
				}
			}
			
			 if (!arrList.isEmpty()) {

				 strInvValues = arrList.toString().replaceAll("\\[", "");
	                strInvValues = strInvValues.replaceAll("\\]", "");

	                logger.debug("*************** strInvValues" + strInvValues);
	                returnValue = returnValue + strInvValues;
	                logger.debug("Get User Return value: " + returnValue);
	                return returnValue;
	            } else {
	            	returnValue="No Queries Found";
	                return returnValue;
	            }	

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup User List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup User List  is "+totaltime);

		return returnValue;
	}
	
/*	public ArrayList<SAPPODetails> getPOLineItem(String PONumber, String endurl, String cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("getPOLineItem method starts......." );
		ArrayList<SAPPODetails> arrList = new ArrayList<SAPPODetails>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;	
		SAPPODetails sapPoDetails=null;
		try {
			logger.debug("PONumber ========>  "+PONumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("PONumber",PONumber);

			option="ProcedureToGetPOLineItemList";//VPGetPOLineItemList			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					sapPoDetails = new SAPPODetails();
					sapPoDetails.setPONumber(outptXMLlst.get(k));
					sapPoDetails.setPOAmount(outptXMLlst.get(++k));
					sapPoDetails.setPOOpenAmount(outptXMLlst.get(++k));
					sapPoDetails.setVendorName(outptXMLlst.get(++k));
					sapPoDetails.setVendorCode(outptXMLlst.get(++k));
					sapPoDetails.setBusinessArea(outptXMLlst.get(++k));
					sapPoDetails.setCompanyCode(outptXMLlst.get(++k));
					sapPoDetails.setTaxCode(outptXMLlst.get(++k));
					sapPoDetails.setOrderType(outptXMLlst.get(++k));
					arrList.add(sapPoDetails);
					i=k+1;
				}
			}

		}
		catch (Exception e) {
			loggerErr.error("Exception in getPOLineItem  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getPOLineItem  is "+totaltime);

		return arrList;
	}*/
	
	public ArrayList<SAPPODetails> getPOLineItem(String PONumber, String endurl, String cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("getPOLineItem method starts......." );
		ArrayList<SAPPODetails> arrList = new ArrayList<SAPPODetails>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;	
		SAPPODetails sapPoDetails=null;
		try {
			logger.debug("BAPI execution starts in getPOLineItem  ==");
			SAPConPODetails sapconpo = null;
			SAPFunctions SAPObj = new SAPFunctions();
			SAPObj.InitializeEjbClient();
	        String SAPXML = "";
	        /*PONumber = "4500000069";*/
	        SAPXML = SAPObj.getWFSAPInvoker("ZDI_OPEN_GRN_DETAILS", "<PURCHASEORDER>"+PONumber+"</PURCHASEORDER>");
			
	        WFXmlResponse XmlResponse = new WFXmlResponse(SAPXML);
	        logger.debug("XmlResponse==" + XmlResponse);
	        logger.debug("====" + XmlResponse.getVal("MainCode"));
	        if (XmlResponse.getVal("MainCode").equals("0")) {
	          /*WFXmlList XMLListPoDetails = XmlResponse.createList("Parameters", "ExportParameters");*/
	        	WFXmlList XMLListPoDetails = XmlResponse.createList("Parameters", "ZDI_GRN_ITEM1");
	          logger.debug("XMLListPR==" + XMLListPoDetails);
	          XMLListPoDetails.reInitialize(true);
	          for (; XMLListPoDetails.hasMoreElements(true); XMLListPoDetails.skip(true)) {
	        	  logger.debug("Inside for loop");
	              /*String PONO = XMLListPoDetails.getVal("PO_NUMBER").trim();
	              String POAmount = XMLListPoDetails.getVal("PO_AMOUNT").trim();
	              String POOpenAmount = XMLListPoDetails.getVal("PO_OPEN_AMOUNT").trim();	              
	              String VENDORNAME = XMLListPoDetails.getVal("VENDOR_NAME").trim();
	              String VENDORCODE = XMLListPoDetails.getVal("VENDOR_CODE").trim();  
	              String POStatus = XMLListPoDetails.getVal("PO_STATUS").trim();
	              String COMPANYCODE = XMLListPoDetails.getVal("COMPANY_CODE").trim();
	              String TAXCODE = XMLListPoDetails.getVal("TAX_CODE").trim();
	              String BUSINESSAREA = XMLListPoDetails.getVal("BUSINESS_AREA").trim();
	              String POTYPE = XMLListPoDetails.getVal("PO_TYPE").trim();
	              sapPoDetails = new SAPPODetails();
					sapPoDetails.setPONumber(PONumber);
					sapPoDetails.setPOAmount(POAmount);
					sapPoDetails.setPOOpenAmount(POOpenAmount);
					sapPoDetails.setVendorName(VENDORNAME);
					sapPoDetails.setVendorCode(VENDORCODE);
					sapPoDetails.setBusinessArea(BUSINESSAREA);
					sapPoDetails.setCompanyCode(COMPANYCODE);
					sapPoDetails.setTaxCode(TAXCODE);
					sapPoDetails.setOrderType(POTYPE);
					
					<ZDI_GRN_ITEM1><GRN>5000000020</GRN><PO_NUMBER>4500000018</PO_NUMBER><PO_LINE_ITEM>00010</PO_LINE_ITEM>
					<COST_CENTER>0000001202</COST_CENTER><MATERIAL/><MAT_DESCRI/><PLANT_CODE>1000</PLANT_CODE>
					<UNIT_PRICE>10.000</UNIT_PRICE><QUANTITY>10.000</QUANTITY><AMOUNT>100.00</AMOUNT><TAX_CODE/>
					<UNIT_OF_MEASURE>ST</UNIT_OF_MEASURE></ZDI_GRN_ITEM1>
					
					*/
	        	  String strPOLINEITEM = XMLListPoDetails.getVal("PO_LINE_ITEM").trim();
	              String strCOSTCENTRE = XMLListPoDetails.getVal("COST_CENTRE").trim();	              	             
	              String strPRODUCTCODE = XMLListPoDetails.getVal("MATERIAL").trim();
	              String strMATERIALDESCRIPTION = XMLListPoDetails.getVal("MAT_DESCRI").trim();  	              
	              String strPLANTCODE = XMLListPoDetails.getVal("PLANT_CODE").trim();	              
	              String strQUANTITY = XMLListPoDetails.getVal("QUANTITY").trim();
	              String strAMOUNT = XMLListPoDetails.getVal("AMOUNT").trim();
	              String strTAXCODE = XMLListPoDetails.getVal("TAX_CODE").trim();
	              String strUNITOFMEASURE = XMLListPoDetails.getVal("UNIT_OF_MEASURE").trim();
	              sapPoDetails = new SAPPODetails();
	              sapPoDetails.setPOItemNumber(strPOLINEITEM);
	              sapPoDetails.setMaterialCode(strPRODUCTCODE);
	              sapPoDetails.setMaterialDescription(strMATERIALDESCRIPTION);
	              sapPoDetails.setUnitofMeasure(strUNITOFMEASURE);
	              sapPoDetails.setQuantity(strQUANTITY);
	              sapPoDetails.setAmount(strAMOUNT);
	              sapPoDetails.setUnitPrice(strPLANTCODE);
					arrList.add(sapPoDetails);
	              
	          }
	        }
	          logger.debug("SAP ArrayList == "+arrList);
	          logger.debug("BAPI execution ends in getPOLineItem  ====");
	        /*
	        
	        
	        
	        
			logger.debug("PONumber ========>  "+PONumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("PONumber",PONumber);

			option="ProcedureToGetPOLineItemList";//VPGetPOLineItemList			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					sapPoDetails = new SAPPODetails();
					sapPoDetails.setPONumber(outptXMLlst.get(k));
					sapPoDetails.setPOAmount(outptXMLlst.get(++k));
					sapPoDetails.setPOOpenAmount(outptXMLlst.get(++k));
					sapPoDetails.setVendorName(outptXMLlst.get(++k));
					sapPoDetails.setVendorCode(outptXMLlst.get(++k));
					sapPoDetails.setBusinessArea(outptXMLlst.get(++k));
					sapPoDetails.setCompanyCode(outptXMLlst.get(++k));
					sapPoDetails.setTaxCode(outptXMLlst.get(++k));
					sapPoDetails.setOrderType(outptXMLlst.get(++k));
					arrList.add(sapPoDetails);
					i=k+1;
				}
			}*/

		}
		catch (Exception e) {
			loggerErr.error("Exception in getPOLineItem  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getPOLineItem  is "+totaltime);

		return arrList;
	}
	
	public ArrayList<SAPPODetails> getPOLineItemTest(String PONumber, String endurl, String cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("getPOLineItem method starts......." );
		ArrayList<SAPPODetails> arrList = new ArrayList<SAPPODetails>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;	
		SAPPODetails sapPoDetails=null;
		try {
			logger.debug("BAPI execution starts in getPOLineItem  ==");
			SAPConPODetails sapconpo = null;
			SAPFunctions SAPObj = new SAPFunctions();
			SAPObj.InitializeEjbClient();
	        String SAPXML = "";
	        /*PONumber = "4500000637";*/
	        SAPXML = SAPObj.getWFSAPInvoker("BAPI_PO_GETITEMS", "<PURCHASEORDER>"+PONumber+"</PURCHASEORDER>");
			
	        WFXmlResponse XmlResponse = new WFXmlResponse(SAPXML);
	        logger.debug("XmlResponse==" + XmlResponse);
	        logger.debug("====" + XmlResponse.getVal("MainCode"));
	        if (XmlResponse.getVal("MainCode").equals("0")) {
	          /*WFXmlList XMLListPoDetails = XmlResponse.createList("Parameters", "ExportParameters");*/
	        	WFXmlList XMLListPoDetails = XmlResponse.createList("TableParameters", "PO_ITEMS");
	          logger.debug("XMLListPR==" + XMLListPoDetails);
	          XMLListPoDetails.reInitialize(true);
	          for (; XMLListPoDetails.hasMoreElements(true); XMLListPoDetails.skip(true)) {
	        	  /* Requred Calculation
	        	  UnitPrice = NetPrice/PriceUnit 
	        	  Amount = unitPrice * quantity
	        	   * 
	        	   */
	        	  logger.debug("Inside for loop");	             
	        	  String strPOLINEITEM = XMLListPoDetails.getVal("PO_ITEM").trim();              	             
	              String strMaterialCODE = XMLListPoDetails.getVal("PUR_MAT").trim();
	              String strMATERIALDESCRIPTION = XMLListPoDetails.getVal("SHORT_TEXT").trim();  	              
	              String strNETPRICE = XMLListPoDetails.getVal("NET_PRICE").trim();
	              String strPRICEUNIT = XMLListPoDetails.getVal("PRICE_UNIT").trim();
	              String strUNITOFMEASURE = XMLListPoDetails.getVal("UNIT").trim();
	              String strQUANTITY = XMLListPoDetails.getVal("DISP_QUAN").trim();
	              
	              double netPrice=Double.parseDouble(strNETPRICE);
	              double priceUnit=Double.parseDouble(strPRICEUNIT);
	              
	              double unitPrice=netPrice/priceUnit;
	              double quantity=Double.parseDouble(strQUANTITY);
	              double amount = unitPrice * quantity;
	              //String strAMOUNT=Double.toString(amount);
	              String strUnitPRICE=String.format("%.2f", unitPrice);
	              strQUANTITY=String.format("%.2f", quantity);
	              String strAMOUNT=String.format("%.2f", amount);
	              
	              sapPoDetails = new SAPPODetails();
	              sapPoDetails.setPOItemNumber(strPOLINEITEM);
	              sapPoDetails.setMaterialCode(strMaterialCODE);
	              sapPoDetails.setMaterialDescription(strMATERIALDESCRIPTION);
	              sapPoDetails.setUnitofMeasure(strUNITOFMEASURE);
	              sapPoDetails.setQuantity(strQUANTITY);
	              sapPoDetails.setAmount(strAMOUNT);
	              sapPoDetails.setUnitPrice(strUnitPRICE);
					arrList.add(sapPoDetails);
	              
	          }
	        }
	          logger.debug("SAP ArrayList == "+arrList);
	          logger.debug("BAPI execution ends in getPOLineItem  ====");
	        /*
	        
	        
	        
	        
			logger.debug("PONumber ========>  "+PONumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("PONumber",PONumber);

			option="ProcedureToGetPOLineItemList";//VPGetPOLineItemList			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					sapPoDetails = new SAPPODetails();
					sapPoDetails.setPONumber(outptXMLlst.get(k));
					sapPoDetails.setPOAmount(outptXMLlst.get(++k));
					sapPoDetails.setPOOpenAmount(outptXMLlst.get(++k));
					sapPoDetails.setVendorName(outptXMLlst.get(++k));
					sapPoDetails.setVendorCode(outptXMLlst.get(++k));
					sapPoDetails.setBusinessArea(outptXMLlst.get(++k));
					sapPoDetails.setCompanyCode(outptXMLlst.get(++k));
					sapPoDetails.setTaxCode(outptXMLlst.get(++k));
					sapPoDetails.setOrderType(outptXMLlst.get(++k));
					arrList.add(sapPoDetails);
					i=k+1;
				}
			}*/

		}
		catch (Exception e) {
			loggerErr.error("Exception in getPOLineItem  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getPOLineItem  is "+totaltime);

		return arrList;
	}
	
	public ArrayList<SAPPODetails> getPOLineItemDatabase(String PONumber, String endurl, String cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("getPOLineItemDatabase method starts......." );
		ArrayList<SAPPODetails> arrList = new ArrayList<SAPPODetails>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;	
		SAPPODetails sapPoDetails=null;
		try {
			logger.debug("PONumber ========>  "+PONumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("PONumber",PONumber);

			option="ProcedureToGetPOLineItemList";//VPGetPOLineItemList			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					sapPoDetails = new SAPPODetails();
					sapPoDetails.setPONumber(outptXMLlst.get(k));
					sapPoDetails.setPOAmount(outptXMLlst.get(++k));
					sapPoDetails.setPOOpenAmount(outptXMLlst.get(++k));
					sapPoDetails.setVendorName(outptXMLlst.get(++k));
					sapPoDetails.setVendorCode(outptXMLlst.get(++k));
					sapPoDetails.setBusinessArea(outptXMLlst.get(++k));
					sapPoDetails.setCompanyCode(outptXMLlst.get(++k));
					sapPoDetails.setTaxCode(outptXMLlst.get(++k));
					sapPoDetails.setOrderType(outptXMLlst.get(++k));
					arrList.add(sapPoDetails);
					i=k+1;
				}
			}

		}
		catch (Exception e) {
			loggerErr.error("Exception in getPOLineItem  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getPOLineItem  is "+totaltime);

		return arrList;
	}
	
	public ArrayList<SAPPODetails> getPOList(String vendorCode,String PONumber,String endurl, String cabinet) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup PO List method starts......." );
		ArrayList<SAPPODetails> arrList = new ArrayList<SAPPODetails>();
		String SOAP_inxml="";
		String option="";
		HashMap<String,String> xmlvalues =null;
		ArrayList<String> outptXMLlst=null;	
		SAPPODetails sapPoDetails=null;
		try {
			logger.debug("vendorCode ========>  "+vendorCode);
			logger.debug("PONumber ========>  "+PONumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("vendorcode",vendorCode);
			xmlvalues.put("PONumber",PONumber);

			option="ProcedurePOListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0 && !(outptXMLlst.get(0).equalsIgnoreCase("No_POs_Found")))
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					if(k == 0){
						sapPoDetails = new SAPPODetails();
						sapPoDetails.setPONumber("---Select---");
						//sapPoDetails.setTransactionID("");
						arrList.add(sapPoDetails);
					}
					sapPoDetails = new SAPPODetails();
					sapPoDetails.setPONumber(outptXMLlst.get(k));
					//sapPoDetails.setTransactionID(outptXMLlst.get(++k));
					arrList.add(sapPoDetails);	
					i=k+1;
				}
			}

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup PO List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup PO List  is "+totaltime);

		return arrList;
	}
	
	public String getVPPOList(String vendorCode,String userPrevilage,String PONumber,String endurl, String cabinet, String minValue, 
			String maxValue, String maxCount) {

		long starttime = System.currentTimeMillis();
		logger.debug("Popup PO List method starts......." );
		ArrayList<String> arrList = new ArrayList<String>();
		String SOAP_inxml="";
		String option="";
		String returnValue = "";
		String sCount = "";
		String strInvValues="";
		HashMap<String,String> xmlvalues =null;
		HashMap<String,String> xmlvalues1 =null;
		ArrayList<String> outptXMLlst=null;	
		SAPPODetails sapPoDetails=null;
		if (maxCount != null && maxCount.equals("0")) {
			logger.debug("maxCount,VendorCode,userPrevilage,PONumber =========> "+maxCount+","+vendorCode+","+userPrevilage+","+PONumber);
			try{			
				xmlvalues1=new HashMap<String,String>();				
				xmlvalues1.put("VendorCode",vendorCode);
				xmlvalues1.put("userPrevilage",userPrevilage);
				xmlvalues1.put("PONumber",PONumber);
				option="ProcedurePOListCount";			
				SOAP_inxml=GenerateXML.generatexml(xmlvalues1,option,cabinet);
				logger.debug("Count getVPPOList SOAP_inxml =========> "+SOAP_inxml);
				// Webservice call
				outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
				logger.debug("Count getVPPOList outptXMLlst =========> "+SOAP_inxml);
				if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
				{			
					sCount=outptXMLlst.get(0);
					logger.debug("totalcount =========> "+sCount);
				}
				 if (sCount != null) {
	                 returnValue = sCount + "&#";
	             }
				
			}catch (Exception e) {
				loggerErr.error("Exception in Popup InvoiceList Count  : " + e.getMessage());
				e.printStackTrace();
			}
			
			}else {
	            returnValue = maxCount + "&#";
	        }
		try {
			logger.debug("vendorCode ========>  "+vendorCode);
			logger.debug("PONumber ========>  "+PONumber);
			logger.debug("endurl ========>  "+endurl);
			xmlvalues=new HashMap<String,String>();
			xmlvalues.put("vendorcode",vendorCode);
			xmlvalues.put("userPrevilage",userPrevilage);
			xmlvalues.put("PONumber",PONumber);
			xmlvalues.put("minValue",minValue);
			xmlvalues.put("maxValue",maxValue);
			xmlvalues.put("maxCount",maxCount);

			option="ProcedureVPPOListPopup";			
			SOAP_inxml=GenerateXML.generatexml(xmlvalues,option,cabinet);
			logger.debug("SOAP_inxml =========> "+SOAP_inxml);
			// Webservice call
			outptXMLlst=Execute_WebService.executeWebservice(SOAP_inxml,endurl);
			logger.debug("outptXMLlst =========> "+outptXMLlst);
			if(!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size()>0)
			{
				int i=0;
				for(int k=0 ;k<outptXMLlst.size();k++)
				{
					arrList.add(outptXMLlst.get(k));	
					i=k+1;
				}
			}
			
			if (!arrList.isEmpty()) {

				 strInvValues = arrList.toString().replaceAll("\\[", "");
	                strInvValues = strInvValues.replaceAll("\\]", "");

	                logger.debug("*************** strInvValues" + strInvValues);
	                returnValue = returnValue + strInvValues;
	                logger.debug("Get User Return value: " + returnValue);
	                return returnValue;
	            } else {
	            	returnValue="No POs Found";
	                return returnValue;
	            }

		}
		catch (Exception e) {
			loggerErr.error("Exception in Popup PO List  : " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Popup PO List  is "+totaltime);

		return returnValue;
	}

}
