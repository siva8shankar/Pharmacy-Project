/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: MyInvoiceDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which interacts with database and perform CRUD Operations.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)  
* * 09/01/2018						ksivashankar			Bug 1023790 - Vendor Portal - Mismatch in the data - dashboard shows no data                                     
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.TCInvoiceDetails;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class TCMyInvoiceDAO {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to get My Invoice list.
	 * 
	 * @param InvoiceDetails
	 *            invoice, GeneralClass gen, String endurl
	 * @return GeneralClass
	 * @exception Exception
	 */
	@SuppressWarnings("unused")
	public GeneralClass searchTCInvoice(String VendorCode, InvoiceNewDetails invoice, GeneralClass gen, String sessionid,
			String endurl, String IBPSEndPointURL, String Cabinet) {

		long starttime = System.currentTimeMillis();
		logger.info("Getting TC MyInvoice Method Starts...");
		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();
		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		double zero = 0.00;
		String username = invoice.getInvoiceCreatedBy();
		TCInvoiceDetails myTCInvoiceMaster = null;
		String SOAP_inxml = "";
		String[] arrStatus = new String[1000];
		String[] arrDocumentIDs = new String[1000];
		int result = 0;
		String option = "";
		String invoiceId = null;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		ArrayList<TCInvoiceDetails> arr = new ArrayList<TCInvoiceDetails>();

		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastQryNo;
		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("userName", username.toLowerCase());
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("sessionid", sessionid);
			option = "ProcedureSelectTCMyInvoice";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			logger.debug("SOAP_inxml ==> " + SOAP_inxml);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("outptXMLlst ==> " + outptXMLlst);
			if (outptXMLlst.size() > 0 && !ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug("MyInvoiceDAO size===============>" + outptXMLlst.size());
				logger.debug("MyInvoiceDAO get(0)===============>" + outptXMLlst.get(0));

				result = 1;
				int j = 0;
				paginationTopQryNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					logger.debug("Data---->" + outptXMLlst.get(k));
					myTCInvoiceMaster = new TCInvoiceDetails();
					invoiceId = outptXMLlst.get(k);
					System.out.println("invoiceId --> "+invoiceId);					
					myTCInvoiceMaster.setPID(outptXMLlst.get(++k));
					myTCInvoiceMaster.setPlant(outptXMLlst.get(++k));					
					myTCInvoiceMaster.setQuantity(outptXMLlst.get(++k));
					myTCInvoiceMaster.setStructure(outptXMLlst.get(++k));
					myTCInvoiceMaster.setComment(outptXMLlst.get(++k));
					myTCInvoiceMaster.setEDD(outptXMLlst.get(++k));
					myTCInvoiceMaster.setInvoiceId(Integer.parseInt(outptXMLlst.get(++k)));
					myTCInvoiceMaster.setTCReqNO(outptXMLlst.get(++k));
					myTCInvoiceMaster.setDeliveryDate(outptXMLlst.get(++k));
					myTCInvoiceMaster.setActivityName(outptXMLlst.get(++k));
					myTCInvoiceMaster.setStatus(outptXMLlst.get(++k));	
					myTCInvoiceMaster.setBreadth(outptXMLlst.get(++k));
					myTCInvoiceMaster.setCutoff(outptXMLlst.get(++k));
					myTCInvoiceMaster.setSKU(outptXMLlst.get(++k));
					/*String totalInvoiceAmount = outptXMLlst.get(++k);
					String I_value_check = new String("0.00");
					logger.debug(
							"Total Invoice Amount" + totalInvoiceAmount.length() + "  " + I_value_check.length());

					if (ClsUtil.isNullOrEmpty(totalInvoiceAmount) || totalInvoiceAmount == "0") {

						myInvoiceMaster.setInvoiceAmount("0");
					} else if (totalInvoiceAmount.equalsIgnoreCase(I_value_check)) {
						myInvoiceMaster.setInvoiceAmount("0.00");
					}

					else {
						logger.debug("Total Invoice Amount in else" + totalInvoiceAmount);

						myInvoiceMaster.setInvoiceAmount(ClsUtil.thousandFormatter(totalInvoiceAmount));
					}*/
//					myInvoiceMaster.setCurrency(outptXMLlst.get(++k));
//					myInvoiceMaster.setInvoiceCreatedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
//					myInvoiceMaster.setTransactionId(outptXMLlst.get(++k));
//					String duedate = outptXMLlst.get(++k);
//					if (ClsUtil.isNullOrEmpty(duedate)) {
//						duedate = "-";
//					} else {
//						duedate = ClsConvertDate.ConvertxmlDatetostring(duedate);
//					}
//					myTCInvoiceMaster.setDueDate(duedate);
					arr.add(myTCInvoiceMaster);
					j = k + 1;
				}
				paginationLastQryNo = invoiceId;
				prevRecordFlag = outptXMLlst.get(j++);
				lastRecordFlag = outptXMLlst.get(j);
				
				/*String[] CaseNumberArr = null;
				String strCaseNumber = "";
				String strStatus = "";
				String strDocumentIDs = "";
				CaseNumberArr = new String[1000];
				if (arr.size() > 0) {
					for (int i = 0; i < arr.size(); i++) {
						CaseNumberArr[i] = arr.get(i).getTransactionId();
						strCaseNumber += CaseNumberArr[i] + ",";
					}
					logger.debug("Output strCaseNumber--->" + strCaseNumber);
					xmlvalues.clear();

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureGetMyInvoiceStatus";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strStatus = outptXMLlst.get(0);
							arrStatus = strStatus.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrStatus[i] = "NO STATUS";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting status  : " + e.getMessage());

					}

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureGetMyInvoiceDocumentIDs";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strDocumentIDs = outptXMLlst.get(0);
							arrDocumentIDs = strDocumentIDs.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrDocumentIDs[i] = "NO DocumentID";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting DocumentID  : " + e.getMessage());

					}
				}*/

			}
		} catch (Exception e) {
			loggerErr.error("Exception in getting My Invoices  : " + e.getMessage());
			e.printStackTrace();
		}

		gen = new GeneralClass();
		gen.setSessionresult(result);
		gen.setArrStatus(arrStatus);
		gen.setArrayDocumentIDs(arrDocumentIDs);
		gen.setArrayTCInvoiceDetails(arr);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in My Invoices is " + totaltime);

		return gen;
	}
	
	public GeneralClass searchTCCompletedInvoice(String VendorCode, InvoiceNewDetails invoice, GeneralClass gen, String sessionid,
			String endurl, String IBPSEndPointURL, String Cabinet) {

		long starttime = System.currentTimeMillis();
		logger.info("Getting TC MyInvoice Method Starts...");
		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();
		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		double zero = 0.00;
		String username = invoice.getInvoiceCreatedBy();
		TCInvoiceDetails myTCInvoiceMaster = null;
		String SOAP_inxml = "";
		String[] arrStatus = new String[1000];
		String[] arrDocumentIDs = new String[1000];
		int result = 0;
		String option = "";
		String invoiceId = null;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		ArrayList<TCInvoiceDetails> arr = new ArrayList<TCInvoiceDetails>();

		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastQryNo;
		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("userName", username.toLowerCase());
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("sessionid", sessionid);
			option = "ProcedureSelectTCCompletedMyInvoice";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			logger.debug("SOAP_inxml ==> " + SOAP_inxml);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("outptXMLlst ==> " + outptXMLlst);
			if (outptXMLlst.size() > 0 && !ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug("MyInvoiceDAO size===============>" + outptXMLlst.size());
				logger.debug("MyInvoiceDAO get(0)===============>" + outptXMLlst.get(0));

				result = 1;
				int j = 0;
				paginationTopQryNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					logger.debug("Data---->" + outptXMLlst.get(k));
					myTCInvoiceMaster = new TCInvoiceDetails();
					invoiceId = outptXMLlst.get(k);
					System.out.println("invoiceId --> "+invoiceId);					
					myTCInvoiceMaster.setPID(outptXMLlst.get(++k));
					myTCInvoiceMaster.setPlant(outptXMLlst.get(++k));					
					myTCInvoiceMaster.setQuantity(outptXMLlst.get(++k));
					myTCInvoiceMaster.setStructure(outptXMLlst.get(++k));
					myTCInvoiceMaster.setComment(outptXMLlst.get(++k));
					myTCInvoiceMaster.setEDD(outptXMLlst.get(++k));
					myTCInvoiceMaster.setInvoiceId(Integer.parseInt(outptXMLlst.get(++k)));
					myTCInvoiceMaster.setTCReqNO(outptXMLlst.get(++k));
					myTCInvoiceMaster.setDeliveryDate(outptXMLlst.get(++k));
					myTCInvoiceMaster.setActivityName(outptXMLlst.get(++k));
					myTCInvoiceMaster.setStatus(outptXMLlst.get(++k));	
					myTCInvoiceMaster.setBreadth(outptXMLlst.get(++k));
					myTCInvoiceMaster.setCutoff(outptXMLlst.get(++k));
					myTCInvoiceMaster.setSKU(outptXMLlst.get(++k));
					/*String totalInvoiceAmount = outptXMLlst.get(++k);
					String I_value_check = new String("0.00");
					logger.debug(
							"Total Invoice Amount" + totalInvoiceAmount.length() + "  " + I_value_check.length());

					if (ClsUtil.isNullOrEmpty(totalInvoiceAmount) || totalInvoiceAmount == "0") {

						myInvoiceMaster.setInvoiceAmount("0");
					} else if (totalInvoiceAmount.equalsIgnoreCase(I_value_check)) {
						myInvoiceMaster.setInvoiceAmount("0.00");
					}

					else {
						logger.debug("Total Invoice Amount in else" + totalInvoiceAmount);

						myInvoiceMaster.setInvoiceAmount(ClsUtil.thousandFormatter(totalInvoiceAmount));
					}*/
//					myInvoiceMaster.setCurrency(outptXMLlst.get(++k));
//					myInvoiceMaster.setInvoiceCreatedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
//					myInvoiceMaster.setTransactionId(outptXMLlst.get(++k));
//					String duedate = outptXMLlst.get(++k);
//					if (ClsUtil.isNullOrEmpty(duedate)) {
//						duedate = "-";
//					} else {
//						duedate = ClsConvertDate.ConvertxmlDatetostring(duedate);
//					}
//					myTCInvoiceMaster.setDueDate(duedate);
					arr.add(myTCInvoiceMaster);
					j = k + 1;
				}
				paginationLastQryNo = invoiceId;
				prevRecordFlag = outptXMLlst.get(j++);
				lastRecordFlag = outptXMLlst.get(j);
				
				/*String[] CaseNumberArr = null;
				String strCaseNumber = "";
				String strStatus = "";
				String strDocumentIDs = "";
				CaseNumberArr = new String[1000];
				if (arr.size() > 0) {
					for (int i = 0; i < arr.size(); i++) {
						CaseNumberArr[i] = arr.get(i).getTransactionId();
						strCaseNumber += CaseNumberArr[i] + ",";
					}
					logger.debug("Output strCaseNumber--->" + strCaseNumber);
					xmlvalues.clear();

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureGetMyInvoiceStatus";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strStatus = outptXMLlst.get(0);
							arrStatus = strStatus.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrStatus[i] = "NO STATUS";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting status  : " + e.getMessage());

					}

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureGetMyInvoiceDocumentIDs";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strDocumentIDs = outptXMLlst.get(0);
							arrDocumentIDs = strDocumentIDs.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrDocumentIDs[i] = "NO DocumentID";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting DocumentID  : " + e.getMessage());

					}
				}*/

			}
		} catch (Exception e) {
			loggerErr.error("Exception in getting My Invoices  : " + e.getMessage());
			e.printStackTrace();
		}

		gen = new GeneralClass();
		gen.setSessionresult(result);
		gen.setArrStatus(arrStatus);
		gen.setArrayDocumentIDs(arrDocumentIDs);
		gen.setArrayTCInvoiceDetails(arr);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in My Invoices is " + totaltime);

		return gen;
	}
	
	public GeneralClass searchTCCompletDetailsInvoice(String VendorCode, InvoiceNewDetails invoice, GeneralClass gen, String sessionid,
			String endurl, String IBPSEndPointURL, String Cabinet,String PID,String TCReqNo,String strPage) {

		long starttime = System.currentTimeMillis();
		logger.info("Getting TC MyInvoice Method Starts...");
		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();
		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		double zero = 0.00;
		String username = invoice.getInvoiceCreatedBy();
		TCInvoiceDetails myTCInvoiceMaster = null;
		String SOAP_inxml = "";
		String[] arrStatus = new String[1000];
		String[] arrDocumentIDs = new String[1000];
		int result = 0;
		String option = "";
		String invoiceId = null;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		ArrayList<TCInvoiceDetails> arr = new ArrayList<TCInvoiceDetails>();

		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastQryNo;
		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("userName", username.toLowerCase());
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("sessionid", sessionid);
			xmlvalues.put("PID", PID);
			xmlvalues.put("TCReqNo", TCReqNo);
			xmlvalues.put("Page", strPage);
			option = "ProcedureSelectTCCompleteDetailsMyInvoice";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			logger.debug("SOAP_inxml ==> " + SOAP_inxml);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("outptXMLlst ==> " + outptXMLlst);
			if (outptXMLlst.size() > 0 && !ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug("MyInvoiceDAO size===============>" + outptXMLlst.size());
				logger.debug("MyInvoiceDAO get(0)===============>" + outptXMLlst.get(0));

				result = 1;
				int j = 0;
				paginationTopQryNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					logger.debug("Data---->" + outptXMLlst.get(k));
					myTCInvoiceMaster = new TCInvoiceDetails();
					invoiceId = outptXMLlst.get(k);
					System.out.println("invoiceId --> "+invoiceId);					
					myTCInvoiceMaster.setPID(outptXMLlst.get(++k));
					myTCInvoiceMaster.setPlant(outptXMLlst.get(++k));					
					myTCInvoiceMaster.setQuantity(outptXMLlst.get(++k));
					myTCInvoiceMaster.setStructure(outptXMLlst.get(++k));
					myTCInvoiceMaster.setComment(outptXMLlst.get(++k));
					myTCInvoiceMaster.setEDD(outptXMLlst.get(++k));
					myTCInvoiceMaster.setInvoiceId(Integer.parseInt(outptXMLlst.get(++k)));
					myTCInvoiceMaster.setTCReqNO(outptXMLlst.get(++k));
					myTCInvoiceMaster.setDeliveryDate(outptXMLlst.get(++k));
					myTCInvoiceMaster.setActivityName(outptXMLlst.get(++k));
					myTCInvoiceMaster.setStatus(outptXMLlst.get(++k));	
					myTCInvoiceMaster.setBreadth(outptXMLlst.get(++k));
					myTCInvoiceMaster.setCutoff(outptXMLlst.get(++k));
					myTCInvoiceMaster.setSKU(outptXMLlst.get(++k));
					/*String totalInvoiceAmount = outptXMLlst.get(++k);
					String I_value_check = new String("0.00");
					logger.debug(
							"Total Invoice Amount" + totalInvoiceAmount.length() + "  " + I_value_check.length());

					if (ClsUtil.isNullOrEmpty(totalInvoiceAmount) || totalInvoiceAmount == "0") {

						myInvoiceMaster.setInvoiceAmount("0");
					} else if (totalInvoiceAmount.equalsIgnoreCase(I_value_check)) {
						myInvoiceMaster.setInvoiceAmount("0.00");
					}

					else {
						logger.debug("Total Invoice Amount in else" + totalInvoiceAmount);

						myInvoiceMaster.setInvoiceAmount(ClsUtil.thousandFormatter(totalInvoiceAmount));
					}*/
//					myInvoiceMaster.setCurrency(outptXMLlst.get(++k));
//					myInvoiceMaster.setInvoiceCreatedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
//					myInvoiceMaster.setTransactionId(outptXMLlst.get(++k));
//					String duedate = outptXMLlst.get(++k);
//					if (ClsUtil.isNullOrEmpty(duedate)) {
//						duedate = "-";
//					} else {
//						duedate = ClsConvertDate.ConvertxmlDatetostring(duedate);
//					}
//					myTCInvoiceMaster.setDueDate(duedate);
					arr.add(myTCInvoiceMaster);
					j = k + 1;
				}
				paginationLastQryNo = invoiceId;
				prevRecordFlag = outptXMLlst.get(j++);
				lastRecordFlag = outptXMLlst.get(j);
				
				/*String[] CaseNumberArr = null;
				String strCaseNumber = "";
				String strStatus = "";
				String strDocumentIDs = "";
				CaseNumberArr = new String[1000];
				if (arr.size() > 0) {
					for (int i = 0; i < arr.size(); i++) {
						CaseNumberArr[i] = arr.get(i).getTransactionId();
						strCaseNumber += CaseNumberArr[i] + ",";
					}
					logger.debug("Output strCaseNumber--->" + strCaseNumber);
					xmlvalues.clear();

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureGetMyInvoiceStatus";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strStatus = outptXMLlst.get(0);
							arrStatus = strStatus.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrStatus[i] = "NO STATUS";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting status  : " + e.getMessage());

					}

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureGetMyInvoiceDocumentIDs";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strDocumentIDs = outptXMLlst.get(0);
							arrDocumentIDs = strDocumentIDs.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrDocumentIDs[i] = "NO DocumentID";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting DocumentID  : " + e.getMessage());

					}
				}*/

			}
		} catch (Exception e) {
			loggerErr.error("Exception in getting My Invoices  : " + e.getMessage());
			e.printStackTrace();
		}

		gen = new GeneralClass();
		gen.setSessionresult(result);
		gen.setArrStatus(arrStatus);
		gen.setArrayDocumentIDs(arrDocumentIDs);
		gen.setArrayTCInvoiceDetails(arr);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in My Invoices is " + totaltime);

		return gen;
	}
	
	public GeneralClass searchTCUpdateInvoice(String VendorCode, InvoiceNewDetails invoice, GeneralClass gen, String sessionid,
			String endurl, String IBPSEndPointURL, String Cabinet) {

		long starttime = System.currentTimeMillis();
		logger.info("Getting TC MyInvoice Method Starts...");
		String lastRecordFlag = null;
		String prevRecordFlag = null;
		String paginationTopQryNo = gen.getPaginationTopQryNo();
		String paginationLastQryNo = gen.getPaginationLastQryNo();
		String paginationSql = null;
		int bufferSize = gen.getBatchSize();
		double zero = 0.00;
		String username = invoice.getInvoiceCreatedBy();
		TCInvoiceDetails myTCInvoiceMaster = null;
		String SOAP_inxml = "";
		String[] arrStatus = new String[1000];
		String[] arrDocumentIDs = new String[1000];
		int result = 0;
		String option = "";
		String invoiceId = null;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		ArrayList<TCInvoiceDetails> arr = new ArrayList<TCInvoiceDetails>();

		if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("next")) {
			paginationSql = paginationLastQryNo;
		} else if (!ClsUtil.isNullOrEmpty(gen.getLinkType()) && gen.getLinkType().equals("prev")) {
			paginationSql = paginationTopQryNo;
		} else {
			paginationSql = "";
		}

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("paginationSql", paginationSql);
			xmlvalues.put("Linktype", gen.getLinkType());
			xmlvalues.put("userName", username.toLowerCase());
			xmlvalues.put("VendorCode", VendorCode);
			xmlvalues.put("Buffersize", String.valueOf(bufferSize));
			xmlvalues.put("sessionid", sessionid);
			option = "ProcedureSelectTCUpdateMyInvoice";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option, Cabinet);
			logger.debug("SOAP_inxml ==> " + SOAP_inxml);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			logger.debug("outptXMLlst ==> " + outptXMLlst);
			if (outptXMLlst.size() > 0 && !ClsUtil.isNullOrEmpty(outptXMLlst)) {
				logger.debug("MyInvoiceDAO size===============>" + outptXMLlst.size());
				logger.debug("MyInvoiceDAO get(0)===============>" + outptXMLlst.get(0));

				result = 1;
				int j = 0;
				paginationTopQryNo = outptXMLlst.get(0);
				for (int k = 0; k < (outptXMLlst.size() - 2); k++) {
					logger.debug("Data---->" + outptXMLlst.get(k));
					myTCInvoiceMaster = new TCInvoiceDetails();
					invoiceId = outptXMLlst.get(k);
					System.out.println("invoiceId --> "+invoiceId);					
					myTCInvoiceMaster.setPID(outptXMLlst.get(++k));
					myTCInvoiceMaster.setPlant(outptXMLlst.get(++k));					
					myTCInvoiceMaster.setQuantity(outptXMLlst.get(++k));
					myTCInvoiceMaster.setStructure(outptXMLlst.get(++k));
					myTCInvoiceMaster.setComment(outptXMLlst.get(++k));
					myTCInvoiceMaster.setEDD(outptXMLlst.get(++k));
					myTCInvoiceMaster.setInvoiceId(Integer.parseInt(outptXMLlst.get(++k)));
					myTCInvoiceMaster.setTCReqNO(outptXMLlst.get(++k));
					myTCInvoiceMaster.setDeliveryDate(outptXMLlst.get(++k));
					myTCInvoiceMaster.setActivityName(outptXMLlst.get(++k));
					myTCInvoiceMaster.setStatus(outptXMLlst.get(++k));	
					myTCInvoiceMaster.setBreadth(outptXMLlst.get(++k));
					myTCInvoiceMaster.setCutoff(outptXMLlst.get(++k));
					myTCInvoiceMaster.setSKU(outptXMLlst.get(++k));
					/*String totalInvoiceAmount = outptXMLlst.get(++k);
					String I_value_check = new String("0.00");
					logger.debug(
							"Total Invoice Amount" + totalInvoiceAmount.length() + "  " + I_value_check.length());

					if (ClsUtil.isNullOrEmpty(totalInvoiceAmount) || totalInvoiceAmount == "0") {

						myInvoiceMaster.setInvoiceAmount("0");
					} else if (totalInvoiceAmount.equalsIgnoreCase(I_value_check)) {
						myInvoiceMaster.setInvoiceAmount("0.00");
					}

					else {
						logger.debug("Total Invoice Amount in else" + totalInvoiceAmount);

						myInvoiceMaster.setInvoiceAmount(ClsUtil.thousandFormatter(totalInvoiceAmount));
					}*/
//					myInvoiceMaster.setCurrency(outptXMLlst.get(++k));
//					myInvoiceMaster.setInvoiceCreatedDate(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(++k)));
//					myInvoiceMaster.setTransactionId(outptXMLlst.get(++k));
//					String duedate = outptXMLlst.get(++k);
//					if (ClsUtil.isNullOrEmpty(duedate)) {
//						duedate = "-";
//					} else {
//						duedate = ClsConvertDate.ConvertxmlDatetostring(duedate);
//					}
//					myTCInvoiceMaster.setDueDate(duedate);
					arr.add(myTCInvoiceMaster);
					j = k + 1;
				}
				paginationLastQryNo = invoiceId;
				prevRecordFlag = outptXMLlst.get(j++);
				lastRecordFlag = outptXMLlst.get(j);
				
				/*String[] CaseNumberArr = null;
				String strCaseNumber = "";
				String strStatus = "";
				String strDocumentIDs = "";
				CaseNumberArr = new String[1000];
				if (arr.size() > 0) {
					for (int i = 0; i < arr.size(); i++) {
						CaseNumberArr[i] = arr.get(i).getTransactionId();
						strCaseNumber += CaseNumberArr[i] + ",";
					}
					logger.debug("Output strCaseNumber--->" + strCaseNumber);
					xmlvalues.clear();

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureGetMyInvoiceStatus";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strStatus = outptXMLlst.get(0);
							arrStatus = strStatus.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrStatus[i] = "NO STATUS";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting status  : " + e.getMessage());

					}

					try {
						xmlvalues.put("Field1", strCaseNumber);
						String statusOption = "ProcedureGetMyInvoiceDocumentIDs";
						SOAP_inxml = "";
						SOAP_inxml = GenerateXML.generatexml(xmlvalues, statusOption, Cabinet);
						outptXMLlst.clear();
						outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, IBPSEndPointURL);

						if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
							strDocumentIDs = outptXMLlst.get(0);
							arrDocumentIDs = strDocumentIDs.split(",");
						} else {
							for (int i = 0; i < 10; i++) {
								arrDocumentIDs[i] = "NO DocumentID";
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						loggerErr.error("Exception while getting DocumentID  : " + e.getMessage());

					}
				}*/

			}
		} catch (Exception e) {
			loggerErr.error("Exception in getting My Invoices  : " + e.getMessage());
			e.printStackTrace();
		}

		gen = new GeneralClass();
		gen.setSessionresult(result);
		gen.setArrStatus(arrStatus);
		gen.setArrayDocumentIDs(arrDocumentIDs);
		gen.setArrayTCInvoiceDetails(arr);
		gen.setPrevRecordFlag(prevRecordFlag);
		gen.setLastRecordFlag(lastRecordFlag);
		gen.setPaginationTopQryNo(paginationTopQryNo);
		gen.setPaginationLastQryNo(paginationLastQryNo);

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in My Invoices is " + totaltime);

		return gen;
	}
}