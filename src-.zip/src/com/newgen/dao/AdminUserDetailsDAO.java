/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminUserDetailsDAO.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: This is a Data access object class which provides user details.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.VPUserMaster;
import com.newgen.util.ClsConvertDate;
import com.newgen.util.ClsUtil;
import com.newgen.util.Execute_WebService;
import com.newgen.util.GeneralClass;
import com.newgen.util.GenerateXML;

public class AdminUserDetailsDAO implements AdminUserDetailsDAOI {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * This Method is used to fetch user details.
	 * 
	 * @param String
	 *            userName,String userType
	 * @return GeneralClass GeneralClass
	 * @exception Exception
	 */
	@Override
	public GeneralClass getUserDetails(String userName, String userType, String endurl) {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();

		logger.debug("getUserDetails Method Starts...");
		int result = 0;
		ArrayList<VPUserMaster> arrayRegUserDetails = new ArrayList<VPUserMaster>();
		ArrayList<AppliedUser> arrayAppUserDetails = new ArrayList<AppliedUser>();

		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserName", userName);
			xmlvalues.put("UserType", userType);
			option = "ProcedureSelectUserDetails";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0)

			{
				if (outptXMLlst.get(0).trim().equalsIgnoreCase("User Does Not Exist")) {
					result = -1;
					logger.debug("User Does Not Exist");

				} else {
					// if usertype is AppliedUser, then set values in
					// AppliedUser Bean
					if (!ClsUtil.isNullOrEmpty(userType) && userType.equalsIgnoreCase("AppUser")) {
						logger.debug("Inside AppUser-->" + userType);

						AppliedUser appUserMaster = new AppliedUser();
						appUserMaster.setUserName(outptXMLlst.get(0));
						appUserMaster.setVendorCode(outptXMLlst.get(2));
						appUserMaster.setEmailId(outptXMLlst.get(3));
						appUserMaster.setPhoneNo(outptXMLlst.get(4));
						appUserMaster.setAddress(outptXMLlst.get(5));
						appUserMaster.setVendorName(outptXMLlst.get(6));
						appUserMaster.setVendorAdd(outptXMLlst.get(7));
						appUserMaster.setUserIndex(outptXMLlst.get(11));
						appUserMaster.setContactPersonName(outptXMLlst.get(13));
						appUserMaster.setMobileNo(outptXMLlst.get(14));
						appUserMaster.setPAN(ClsUtil.blankString(outptXMLlst.get(15)));
						appUserMaster.setTAN(ClsUtil.blankString(outptXMLlst.get(16)));
						appUserMaster.setServiceRegNo(ClsUtil.blankString(outptXMLlst.get(17)));
						appUserMaster.setTIN(ClsUtil.blankString(outptXMLlst.get(18)));
						arrayAppUserDetails.add(appUserMaster);
						logger.debug("Added all Inside");
					} else {

						// if usertype is Registered User, then set values in
						// VPUserMaster Bean

						VPUserMaster regUserMaster = new VPUserMaster();

						regUserMaster.setUserIndex(outptXMLlst.get(0));
						regUserMaster.setUserName(outptXMLlst.get(1));
						regUserMaster.setUserEmailId(outptXMLlst.get(3));
						regUserMaster.setUserPhoneNumber(outptXMLlst.get(4));
						regUserMaster.setUserAddress(outptXMLlst.get(6));
						regUserMaster.setVendorCode(outptXMLlst.get(7));
						regUserMaster.setVendorName(outptXMLlst.get(8));
						regUserMaster.setVendorAddress(outptXMLlst.get(9));
						regUserMaster.setExpiryDateTime(ClsConvertDate.ConvertxmlDatetostring(outptXMLlst.get(14)));
						regUserMaster.setContactPersonName(outptXMLlst.get(22));
						regUserMaster.setMobileNo(outptXMLlst.get(23));
						regUserMaster.setFirstName(ClsUtil.blankString(outptXMLlst.get(24)));
						regUserMaster.setLastName(ClsUtil.blankString(outptXMLlst.get(25)));
						regUserMaster.setUserType(ClsUtil.blankString(outptXMLlst.get(26)));

						String priviledge = null;

						// if privilege is 1, then User is Admin
						if (!ClsUtil.isNullOrEmpty(outptXMLlst.get(18)) && outptXMLlst.get(18).equalsIgnoreCase("1")) {
							priviledge = "Admin";
						} else if (!ClsUtil.isNullOrEmpty(outptXMLlst.get(18))
								&& outptXMLlst.get(18).equalsIgnoreCase("2")) {
							priviledge = "Vendor Supervisor";
						} else {
							priviledge = "Vendor User";
						}

						regUserMaster.setPrivilege(priviledge);

						String isUserActive = null;
						// Check whether user is active or not
						if (!ClsUtil.isNullOrEmpty(outptXMLlst.get(11)) && outptXMLlst.get(11).equalsIgnoreCase("Y")) {
							isUserActive = "Yes";
						} else {
							isUserActive = "No";
						}
						regUserMaster.setIsUserActive(isUserActive);

						String isUserlocked = null;
						// Check whether user is active or not
						if (!ClsUtil.isNullOrEmpty(outptXMLlst.get(11)) && outptXMLlst.get(21).equalsIgnoreCase("Y")) {
							isUserlocked = "Yes";
						} else {
							isUserlocked = "No";
						}
						regUserMaster.setLocked(isUserlocked);

						arrayRegUserDetails.add(regUserMaster);
					}
					result = 1;
					logger.debug("Result value here" + result);
				}
			}
		} catch (Exception e) {
			loggerErr.error("Exception : " + e.getMessage());
			e.printStackTrace();
		}

		GeneralClass gen = new GeneralClass();
		if (!ClsUtil.isNullOrEmpty(userType) && userType.equalsIgnoreCase("AppUser")) {
			gen.setArrayAppliedUser(arrayAppUserDetails);
		} else {
			gen.setArrayRegisteredUser(arrayRegUserDetails);
		}
		logger.debug("Before setting Result value here" + result);
		gen.setResultCode(result);
		logger.debug("After setting Result value here" + gen.getResultCode());
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;

		logger.debug("Total Time Taken in getting User Details by admin is " + totaltime);

		return gen;
	}

	/**
	 * This Method is used to update registered user
	 * 
	 * @param VPUserMaster
	 *            userMaster
	 * @return int
	 * @exception Exception
	 */
	@Override
	public int updateRegUser(VPUserMaster userMaster, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("updateRegUser Method Starts...");

		int result = 0;

		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("UserEmailId", userMaster.getUserEmailId());
			xmlvalues.put("UserPhoneNumber", userMaster.getUserPhoneNumber());
			xmlvalues.put("UserAddress", ClsUtil.replaceString(userMaster.getUserAddress()));
			xmlvalues.put("VendorCode", userMaster.getVendorCode());
			xmlvalues.put("VendorName", ClsUtil.replaceString(userMaster.getVendorName()));
			xmlvalues.put("VendorAddress", ClsUtil.replaceString(userMaster.getVendorAddress()));
			xmlvalues.put("IsUserActive", userMaster.getIsUserActive());
			xmlvalues.put("ExpiryDateTime", userMaster.getExpiryDateTime());
			xmlvalues.put("Privilege", userMaster.getPrivilege());
			xmlvalues.put("Username", userMaster.getUserName());
			xmlvalues.put("locked", userMaster.getLocked());
			xmlvalues.put("ContactPersonName", ClsUtil.replaceString(userMaster.getContactPersonName()));
			xmlvalues.put("MobileNo", userMaster.getMobileNo());
			xmlvalues.put("UserType", userMaster.getUserType());
			option = "ProcedureupdateRegUser";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			outptXMLlst = new ArrayList<String>();
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				if (outptXMLlst.get(0).trim().equalsIgnoreCase("Updated Successfully")) {
					result = 1;

					logger.debug("Registered User Updated succesfully...");

				} else
					result = -1;
				logger.debug("Registered User details not updated...");
			}
		} catch (Exception e) {
			loggerErr.error("Exception in Updating Registered User details: " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in updating registered user by admin is " + totaltime);

		return result;
	}

	/**
	 * This Method is used to update AppliedUser user details
	 * 
	 * @param AppliedUser
	 *            appliedUser
	 * @return int
	 * @exception Exception
	 */
	@Override
	public int updateAppUser(AppliedUser appliedUser, String endurl) {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("updateAppUser Method Starts...");

		int result = 0;
		String SOAP_inxml = "";
		String option = "";
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("EmailId", appliedUser.getEmailId());
			xmlvalues.put("PhoneNumber", appliedUser.getPhoneNo());
			xmlvalues.put("Address", appliedUser.getAddress());
			xmlvalues.put("VendorCode", appliedUser.getVendorCode());
			xmlvalues.put("VendorName", ClsUtil.replaceString(appliedUser.getVendorName()));
			xmlvalues.put("VendorAdd", ClsUtil.replaceString(appliedUser.getVendorAdd()));
			xmlvalues.put("Username", appliedUser.getUserName());
			xmlvalues.put("ContactPersonName", ClsUtil.replaceString(appliedUser.getContactPersonName()));
			xmlvalues.put("MobileNo", appliedUser.getMobileNo());
			xmlvalues.put("PAN", appliedUser.getPAN());
			xmlvalues.put("TAN", appliedUser.getTAN());
			xmlvalues.put("ServiceRegNo", appliedUser.getServiceRegNo());
			xmlvalues.put("TIN", appliedUser.getTIN());

			option = "ProcedureupdateAppUser";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			// logger.debug("AdminUserDetailsDAO outptXMLlst..."+outptXMLlst);
			if (!ClsUtil.isNullOrEmpty(outptXMLlst) && outptXMLlst.size() > 0) {
				// logger.debug("AdminUserDetailsDAO INSIDE IF outptXMLlst
				// ###################"+outptXMLlst.get(0).trim());
				if (outptXMLlst.get(0).trim().equalsIgnoreCase("Updated Successfully")) {
					result = 1;
					logger.debug("App User Details Updated succesfully...");

				} else
					result = -1;
				// result = 1;//Harcoded
			}
		} catch (Exception e) {
			loggerErr.error("Exception in Updating App User details: " + e.getMessage());
			e.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in updating applied user by admin is " + totaltime);

		return result;
	}

}