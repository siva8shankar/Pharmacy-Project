/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminNewVendorDAOI.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Interface for AdminNewVendorDAO class.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.dao;

import com.newgen.bean.VendorMaster;
import com.newgen.util.GeneralClass;

public interface AdminNewVendorDAOI {

	public abstract int addNewVendor(VendorMaster vendorMaster, String buttonType, String tempVendorCode,
			String tempCompanyCode, String endurl);

	public abstract GeneralClass getVendorDetails(String vendorCode, String endurl);

}