/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: RequestAttributeListener.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Application Lifecycle Listener implementation class RequestAttributeListener
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.listener;

import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;

import com.newgen.bean.VPUserActivityTable;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUserActivity;

public class RequestAttributeListener implements ServletRequestAttributeListener {

	/**
	 * Default constructor.
	 */
	VPUserActivityTable VPUserActivityTable = null;

	public RequestAttributeListener() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see ServletRequestAttributeListener#attributeAdded(ServletRequestAttributeEvent)
	 */
	@Override
	public void attributeAdded(ServletRequestAttributeEvent arg0) {
		// TODO Auto-generated method stub

		String clsMessageAdministration = ClsMessageHandler.HistoryAdministration;
		String clsMessageVendorSearch = ClsMessageHandler.HistoryVendorSearch;
		String clsMessageVendorInvoice = ClsMessageHandler.HistoryVendorInvoice;
		String clsMessageVendorQuery = ClsMessageHandler.HistoryVendorQuery;

		if (null != arg0 && null != arg0.getName()
				&& (arg0.getName().equalsIgnoreCase("Administration") || arg0.getName().equalsIgnoreCase("VendorSearch")
						|| arg0.getName().equalsIgnoreCase("VendorInvoice")
						|| arg0.getName().equalsIgnoreCase("VendorQuery"))) {

			if (null != arg0 && null != arg0.getName() && arg0.getName().equalsIgnoreCase("Administration")) {
				if (clsMessageAdministration != null && clsMessageAdministration.equalsIgnoreCase("N"))
					return;
			}
			if (null != arg0 && null != arg0.getName() && arg0.getName().equalsIgnoreCase("VendorSearch")) {
				if (clsMessageVendorSearch != null && clsMessageVendorSearch.equalsIgnoreCase("N"))
					return;
			}
			if (null != arg0 && null != arg0.getName() && arg0.getName().equalsIgnoreCase("VendorInvoice")) {
				if (clsMessageVendorInvoice != null && clsMessageVendorInvoice.equalsIgnoreCase("N"))
					return;
			}
			if (null != arg0 && null != arg0.getName() && arg0.getName().equalsIgnoreCase("VendorQuery")) {
				if (clsMessageVendorQuery != null && clsMessageVendorQuery.equalsIgnoreCase("N"))
					return;
			}

			String UserName = (String) arg0.getServletRequest().getAttribute("UserName");
			String UserSession = (String) arg0.getServletRequest().getAttribute("SessionID");
			String endurl = null;
			endurl = (String) (String) arg0.getServletContext().getAttribute("EndPointURL");

			VPUserActivityTable = new VPUserActivityTable();

			VPUserActivityTable.setUserName(UserName);
			VPUserActivityTable.setSessionID(UserSession);
			VPUserActivityTable.setActivityType(arg0.getName());
			VPUserActivityTable.setActivityDesc((String) arg0.getValue());
			ClsUserActivity UserActivity = new ClsUserActivity(VPUserActivityTable, endurl);
			Thread t = new Thread(UserActivity, "UserActivity");
			t.start();
		} else {
			return;
		}
	}

	/**
	 * @see ServletRequestAttributeListener#attributeRemoved(ServletRequestAttributeEvent)
	 */
	@Override
	public void attributeRemoved(ServletRequestAttributeEvent arg0) {
		// TODO Auto-generated method stub
	}

	/**
	 * @see ServletRequestAttributeListener#attributeReplaced(ServletRequestAttributeEvent)
	 */
	@Override
	public void attributeReplaced(ServletRequestAttributeEvent arg0) {
		// TODO Auto-generated method stub
		String UserName = arg0.getServletRequest().getParameter("UserName");
		String UserActivity = arg0.getServletRequest().getParameter("Activity");

		VPUserActivityTable = new VPUserActivityTable();
		VPUserActivityTable.setUserName(arg0.getName());

	}
}