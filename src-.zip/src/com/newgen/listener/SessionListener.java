/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SessionListener.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Application Lifecycle Listener implementation class SessionListener
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.listener;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserMaster;
import com.newgen.dao.UserMasterDAO;
import com.newgen.dao.UserMasterDAOI;
import com.newgen.util.ClsUtil;

public class SessionListener implements HttpSessionListener {

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	/**
	 * Default constructor.
	 */
	public SessionListener() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
	 */
	@Override
	public void sessionCreated(HttpSessionEvent sessionEvent) {
		// TODO Auto-generated method stub

		HttpSession session = sessionEvent.getSession();

		try {
			logger.debug("Session created in Listener: " + session);
			session.setAttribute("flagValue", "N");

		} catch (Exception e) {
			e.printStackTrace();
			loggerErr.error("Error in setting session attribute : " + e.getMessage());
		}

	}

	/**
	 * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
	 */
	@Override
	public void sessionDestroyed(HttpSessionEvent sessionEvent) {

		// TODO Auto-generated method stub
		VPUserMaster userMasterDO = new VPUserMaster();
		// Get the session that was invalidated
		HttpSession session = sessionEvent.getSession();
		String endurl = null;
		endurl = (String) session.getServletContext().getAttribute("EndPointURL");
		userMasterDO = new VPUserMaster();
		try {
			if (!ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				userMasterDO.setUserName((String) session.getAttribute("UserName"));

				UserMasterDAOI userMasterDAO = new UserMasterDAO();
				int result = userMasterDAO.deleteLoggedInUser(userMasterDO, endurl);
				userMasterDAO = null;
				userMasterDO = null;
			}
		} catch (Exception e) {
			loggerErr.error("Session invalidated: : " + session);
			e.printStackTrace();
		}

	}

}
