
/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: LicFetch.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.lic.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LicFetch {

	public static ArrayList<String> fetchData(String endurl) {

		System.out.println("fetching data started....");
		String SOAP_inxml = "";
		String option = "";
		int result = 0;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("keylic", "12345");
			option = "ProcedureNGVPLicenseFetchProc";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			outptXMLlst = new ArrayList<String>();
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);
			System.out.println("outptXMLlst size after fetch::" + outptXMLlst.size());
			System.out.println("Fetch call end....");
			return outptXMLlst;
		} catch (Exception e) {
			System.out.println("Exception while fetching records::");
			e.printStackTrace();
			return null;
		}
	}
}
