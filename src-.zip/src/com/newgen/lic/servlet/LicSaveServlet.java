
/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: LicSaveServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.lic.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;

import com.newgen.util.ClsMessageHandler;

public class LicSaveServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	HttpServletRequest request1 = null;
	ServletConfig config = null;
	private static String endurl = "";

	public void init(ServletConfig config) throws ServletException {

		super.init(config);

		this.config = config;
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request1 = request;
		String maxUserCreated = "";
		String keySaved = "";
		String namedUser1 = "";
		String concUser = "";
		try {
			System.out.println("Saving data in doGet in saveServlet started..");
			ArrayList<String> outptXML;
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			String key = request.getParameter("key");
			// an
			String namedUser2 = request.getParameter("namedUser");
			if ("".equals(namedUser2)) {
				request.setAttribute("MSGCODE", "Invalid key");
				request.getRequestDispatcher("/JSP/UserLicense.jsp").forward(request, response);
			} else {
				String randno = key.substring(key.length() - 1);
				String shuffleData = key.substring(0, key.length() - 2);
				DESedeEncryption obj = new DESedeEncryption();
				Character[] charObjectArray = toCharacterArray(shuffleData);
				List<Character> list = new ArrayList<Character>(Arrays.asList(charObjectArray));
				compoundUnshuffle(list, 2, Integer.parseInt(randno));
				StringBuilder sb1 = new StringBuilder();
				for (Character s : list) {
					sb1.append(s);

				}

				String unshuffleData = sb1.toString();
				byte[] decodedBytes = Base64.decodeBase64(unshuffleData.getBytes());
				String decodedBytesStr = new String(decodedBytes);
				String dcryptedncUser = obj.decrypt(decodedBytesStr);
				String namedUser = dcryptedncUser;// dcryptArr[0];
				String ConcurrentUser = "";// dcryptArr[1];

				outptXML = LicFetch.fetchData(endurl);

				for (int i = 0; i < outptXML.size(); i++) {
					if (i == 0)
						maxUserCreated = outptXML.get(i);
					if (i == 1)
						keySaved = outptXML.get(i);
					if (i == 2)
						namedUser1 = outptXML.get(i);
					if (i == 3)
						concUser = outptXML.get(i);
				}
				int Int_maxUserCreated = Integer.parseInt(maxUserCreated);
				int Int_namedUser1 = Integer.parseInt(namedUser1);
				if (Int_maxUserCreated >= Int_namedUser1) {
					request.setAttribute("maxUserCreated", maxUserCreated);
					request.setAttribute("key", keySaved);
					request.setAttribute("namedUser1", namedUser1);
					request.setAttribute("MSGCODE", "MaxUserCreated should not exceed NamedUser.");
					request.getRequestDispatcher("JSP/UserLicense.jsp").forward(request, response);
				} else {
					System.out.println("Save data calling.....");
					saveData(key, namedUser, ConcurrentUser, out);
					System.out.println("Save data call done.....");
					request.setAttribute("maxUserCreated", maxUserCreated);
					request.setAttribute("key", keySaved);
					request.setAttribute("namedUser1", namedUser1);
					request.setAttribute("concUser", concUser);
					request.setAttribute("MSGCODE", "License Registration is done successfully....");
					ServletContext sCTX = config.getServletContext();
					RequestDispatcher dispatcher = sCTX.getRequestDispatcher("/JSP/UserLicense.jsp");
					dispatcher.forward(request, response);
				}
			}
		} catch (Exception e) {
			String keyMsg = "Plase enter valid key...";
			request1.setAttribute("ErrorMsg", keyMsg);
			RequestDispatcher dispatcher = config.getServletContext()
					.getRequestDispatcher("/JSP/UserLicense_failure.jsp");
			dispatcher.forward(request, response);
			System.out.println("Exception in doget of LicSaveServlet.......");
			e.printStackTrace();
		}

	}

	public static void saveData(String key, String namedUser, String ConcurrentUser, PrintWriter out) {
		String SOAP_inxml = "";
		String option = "";
		int result = 0;
		HashMap<String, String> xmlvalues = null;
		ArrayList<String> outptXMLlst = null;

		try {
			xmlvalues = new HashMap<String, String>();
			xmlvalues.put("keylic", key);
			xmlvalues.put("namedUser", namedUser);
			xmlvalues.put("concUser", ConcurrentUser);
			option = "ProcedureNGVPLicenseProc";
			SOAP_inxml = GenerateXML.generatexml(xmlvalues, option);
			outptXMLlst = new ArrayList<String>();
			// Webservice call
			outptXMLlst = Execute_WebService.executeWebservice(SOAP_inxml, endurl);

		} catch (Exception e) {
			System.out.println("Exception in saveData of LicSaveServlet.......");
			e.printStackTrace();

		}
	}

	public static Character[] toCharacterArray(String s) {

		try {
			if (s == null) {
				return null;
			}

			int len = s.length();
			Character[] array = new Character[len];
			for (int i = 0; i < len; i++) {
				array[i] = new Character(s.charAt(i));
			}

			return array;
		} catch (Exception e) {
			System.out.println("Exception in toCharacterArray in LicSaveServlet in VPconsume::");
			e.printStackTrace();
			return null;
		}

	}

	public static void compoundUnshuffle(List<?> list, int repetition, long seed) {
		helper(list, repetition, seed);
	}

	private static <E> void helper(List<E> list, int repetition, long seed) {

		try {
			System.out.println("helper 1 " + list);
			List<Integer> indices = new ArrayList<Integer>();
			int size = list.size();
			for (int i = 0; i < size; i++)
				indices.add(i);
			System.out.println(indices);
			compoundShuffle(indices, repetition, seed);
			List<E> copy = new ArrayList<E>(list);
			for (int i = 0; i < size; i++)
				list.set(indices.get(i), copy.get(i));
		} catch (Exception e) {
			System.out.println("Exception in helper in LicSaveServlet in VPconsume::");
			e.printStackTrace();

		}

	}

	public static void compoundShuffle(List<?> list, int repetition, long seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < repetition; i++)
			Collections.shuffle(list, rand);

	}
}
