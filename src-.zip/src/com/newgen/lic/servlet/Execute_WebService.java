
/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: Execute_WebService.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.lic.servlet;

import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.newgen.webserviceclient.NGWebServiceClient;

public class Execute_WebService {

	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static Logger loggerXml = Logger.getLogger("xmlLogger");

	public static ArrayList<String> executeWebservice(String SOAP_inxml, String EndPointurl) {
		String SOAPResponse_xml = "";
		try {
			ArrayList<String> outptXMLlst = new ArrayList<String>();
			NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
			SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, EndPointurl);
			loggerXml.debug("SOAPResponse_xml:" + SOAPResponse_xml);
			if (SOAPResponse_xml != "") {
				outptXMLlst = getAllTagValues(SOAPResponse_xml, "FieldValue");
				return outptXMLlst;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			SOAPResponse_xml = e.getMessage();
			loggerErr.error("Exception in Execute_WebService:" + e.getMessage());
			return null;
		}

	}

	// xml parser

	public static String getTagValue(String xml, String tag) {
		Document doc = getDocument(xml);
		NodeList nodeList = doc.getElementsByTagName(tag);
		int length = nodeList.getLength();
		if (length > 0) {
			Node node = nodeList.item(0);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				NodeList childNodes = node.getChildNodes();
				String value = "";
				int count = childNodes.getLength();
				for (int i = 0; i < count; i++) {
					Node item = childNodes.item(i);
					if (item.getNodeType() == Node.TEXT_NODE) {
						value += item.getNodeValue();
					}
				}
				return value;
			} else if (node.getNodeType() == Node.TEXT_NODE) {
				return node.getNodeValue();
			}
		}
		return "";
	}

	public static ArrayList<String> getAllTagValues(String xml, String tag) {
		ArrayList<String> sList = new ArrayList<String>();
		Document doc = getDocument(xml);
		NodeList nodeList = doc.getElementsByTagName(tag);
		int length = nodeList.getLength();
		if (length > 0) {
			for (int k = 0; k < length; k++) {
				Node node = nodeList.item(k);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					NodeList childNodes = node.getChildNodes();
					int count = childNodes.getLength();
					if (count == 0) {
						sList.add("NULL");
					}
					for (int i = 0; i < count; i++) {
						Node item = childNodes.item(i);
						if (item.getNodeType() == Node.TEXT_NODE) {
							sList.add(item.getNodeValue());
						}
					}
				} else if (node.getNodeType() == Node.TEXT_NODE) {
					sList.add(node.getNodeValue());
				}
			}
		}
		return sList;
	}

	public static Document getDocument(String xml) {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = null;
		try {
			db = dbf.newDocumentBuilder();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Document doc = null;
		try {
			doc = db.parse(new InputSource(new StringReader(xml)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return doc;
	}

}
