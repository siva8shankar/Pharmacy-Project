
/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: EncryptServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.lic.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;

public class EncryptServlet extends HttpServlet {
	ServletConfig config = null;
	HttpServletRequest request1 = null;

	private static String endurl = "";

	public void init(ServletConfig config) throws ServletException {

		super.init(config);

		this.config = config;
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request1 = request;
		try {
			System.out.println("Decryption of key started...");
			response.setContentType("text/html");
			String maxUserCreated = "";
			String keySaved = "";
			String namedUser1 = "";
			String concUser = "";
			PrintWriter out = response.getWriter();
			ArrayList<String> outptXML;
			String key = request.getParameter("key");
			String randno = key.substring(key.length() - 1);
			String shuffleData = key.substring(0, key.length() - 2);
			DESedeEncryption obj = new DESedeEncryption();
			Character[] charObjectArray = toCharacterArray(shuffleData);
			List<Character> list = new ArrayList<Character>(Arrays.asList(charObjectArray));
			compoundUnshuffle(list, 2, Integer.parseInt(randno));
			StringBuilder sb1 = new StringBuilder();
			for (Character s : list) {
				sb1.append(s);

			}

			String unshuffleData = sb1.toString();

			byte[] decodedBytes = Base64.decodeBase64(unshuffleData.getBytes());
			String decodedBytesStr = new String(decodedBytes);
			String dcryptedncUser = obj.decrypt(decodedBytesStr);
			namedUser1 = dcryptedncUser;// dcryptArr[0];
			String cUser1 = "";// dcryptArr[1];
			ServletContext sCTX = config.getServletContext();
			outptXML = LicFetch.fetchData(endurl);

			for (int i = 0; i < outptXML.size(); i++) {
				if (i == 0)
					maxUserCreated = outptXML.get(i);

			}
			request.setAttribute("namedUser1", namedUser1);
			request.setAttribute("cUser1", cUser1);
			request.setAttribute("key", key);
			request.setAttribute("maxUserCreated", maxUserCreated);
			System.out.println("Decryption of key ended...");
			RequestDispatcher dispatcher = sCTX.getRequestDispatcher("/JSP/UserLicense.jsp");
			dispatcher.forward(request, response);
		} catch (Exception e) {
			String keyMsg = "Plase enter valid key...";
			request1.setAttribute("ErrorMsg", keyMsg);
			RequestDispatcher dispatcher = config.getServletContext().getRequestDispatcher("/JSP/UserLicense.jsp");
			dispatcher.forward(request, response);
			System.out.println("Exception in encryptServlet in VPconsume::");
			e.printStackTrace();
		}

	}

	public static Character[] toCharacterArray(String s) {

		try {
			if (s == null) {
				return null;
			}

			int len = s.length();
			Character[] array = new Character[len];
			for (int i = 0; i < len; i++) {
				array[i] = new Character(s.charAt(i));
			}

			return array;
		} catch (Exception e) {
			System.out.println("Exception in toCharacterArray in encryptServlet in VPconsume::");
			e.printStackTrace();
			return null;
		}

	}

	public static void compoundUnshuffle(List<?> list, int repetition, long seed) {
		helper(list, repetition, seed);
	}

	private static <E> void helper(List<E> list, int repetition, long seed) {

		try {
			System.out.println("helper 1 " + list);
			List<Integer> indices = new ArrayList<Integer>();
			int size = list.size();
			for (int i = 0; i < size; i++)
				indices.add(i);
			System.out.println(indices);
			compoundShuffle(indices, repetition, seed);
			List<E> copy = new ArrayList<E>(list);
			for (int i = 0; i < size; i++)
				list.set(indices.get(i), copy.get(i));
		} catch (Exception e) {
			System.out.println("Exception in helper in encryptServlet in VPconsume::");
			e.printStackTrace();

		}

	}

	public static void compoundShuffle(List<?> list, int repetition, long seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < repetition; i++)
			Collections.shuffle(list, rand);

	}

}
