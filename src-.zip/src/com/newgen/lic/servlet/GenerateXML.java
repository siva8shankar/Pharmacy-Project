
/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GenerateXML.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.lic.servlet;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

public class GenerateXML {
	
	private static Logger loggerErr = Logger.getLogger("errorLogger");
    private static Logger loggerXml =Logger.getLogger("xmlLogger"); 
    
   @SuppressWarnings("rawtypes")
	public static String wfinitiatexml(HashMap xmlvalues,String sessionid)
   {
   	String inputXML="";
   	StringBuilder sb = new StringBuilder();
   	try{
   		sb.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:app=\"http://app.omni.newgen.com\" xmlns:xsd=\"http://data.omni.newgen.com/xsd\">");
   		sb.append("<soapenv:Header/>");
   		sb.append("<soapenv:Body>");
   		sb.append("<app:wfInitiate>");
   		sb.append("<app:request>");
   		Iterator it = xmlvalues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry valuepair = (Map.Entry) it.next();
				sb.append("<xsd:attributes><xsd:name>" + valuepair.getKey()
						+ "</xsd:name><xsd:value>");
				sb.append(valuepair.getValue() == null ? "" : valuepair
						.getValue());
				sb.append("</xsd:value></xsd:attributes>");
			}
   		sb.append("<xsd:engineName>garelease</xsd:engineName>");
   		sb.append("<xsd:initiateFromActivityId>1</xsd:initiateFromActivityId>");
   		sb.append("<xsd:initiateFromActivityName>Introduction</xsd:initiateFromActivityName>");
   		sb.append("<xsd:processDefId>21</xsd:processDefId>");
   		sb.append("<xsd:processName>ApProcess</xsd:processName>");
   		sb.append("<xsd:sessionId>"+sessionid+"</xsd:sessionId>");
   		sb.append("</app:request>");
   		sb.append("</app:wfInitiate>");
   		sb.append("</soapenv:Body>");
   		sb.append("</soapenv:Envelope>");
   		inputXML=sb.toString();
       }
       catch(Exception e)
       {
           e.printStackTrace();
           loggerErr.error("Exception in wfinitiatexml:" + e.getMessage());
       }
       return inputXML;
   }
	
	
	// Inputxml generator
	public static String generatexml(HashMap xmlvalues, String option) {
		String inputXML = "";
		StringBuilder sb = new StringBuilder();
		try {
			sb.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:req=\"http://ngprocedureselectq.ops.newgen.com/schema/Ngprocedureselect/request\"><soapenv:Header/><soapenv:Body><req:ProcedureselectReq><Option>"
					+ option + "</Option><Username>");
			sb.append("system</Username><Password>9kbXBdSqUi7LH2BSXYnhfQ==</Password><req:CriteriaArray>");
			Iterator it = xmlvalues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry valuepair = (Map.Entry) it.next();
				sb.append("<req:Criteria><FieldName>" + valuepair.getKey()
						+ "</FieldName><FieldValue>");
				sb.append(valuepair.getValue() == null ? "" : valuepair
						.getValue());
				sb.append("</FieldValue></req:Criteria>");
			}
			sb.append("</req:CriteriaArray><nextSeedValue>?</nextSeedValue></req:ProcedureselectReq></soapenv:Body></soapenv:Envelope>");
			inputXML = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
	        loggerErr.error("Exception in generatexml:" + e.getMessage());
		}		
		 return inputXML;
	}
}
