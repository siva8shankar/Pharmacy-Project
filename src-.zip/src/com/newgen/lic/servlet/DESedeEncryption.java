/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: DESedeEncryption.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.lic.servlet;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import sun.misc.*;

public class DESedeEncryption {
	public static final String UNICODE_FORMAT = "UTF8";
	public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
	KeySpec myKeySpec, myKeySpec1, myKeySpec2;
	SecretKeyFactory mySecretKeyFactory;
	Cipher cipher;
	byte[] keyAsBytes1, keyAsBytes2, keyAsBytes;
	String myEncryptionKey1;
	public static String myEncryptionKey;
	public static String myEncryptionKey2;
	public static String myEncryptionScheme;
	SecretKey key1, key2, key3;

	public DESedeEncryption() {
		try {
			myEncryptionKey = "ThisIsSecretEncryptionKey";
			myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
			keyAsBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
			myKeySpec = new DESedeKeySpec(keyAsBytes);
			mySecretKeyFactory = SecretKeyFactory.getInstance(myEncryptionScheme);
			cipher = Cipher.getInstance(myEncryptionScheme);
			key1 = mySecretKeyFactory.generateSecret(myKeySpec);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String encrypt(String unencryptedString) {
		myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
		String finalencryptedString = null;
		try {
			cipher.init(Cipher.ENCRYPT_MODE, key1);
			byte[] plainText = unencryptedString.getBytes(UNICODE_FORMAT);
			byte[] encryptedText = cipher.doFinal(plainText);
			BASE64Encoder base64encoder = new BASE64Encoder();
			finalencryptedString = base64encoder.encode(encryptedText);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return finalencryptedString;
	}

	public String decrypt(String encryptedString) {
		String decryptedText = null;
		try {
			cipher.init(Cipher.DECRYPT_MODE, key1);
			@SuppressWarnings("restriction")
			BASE64Decoder base64decoder = new BASE64Decoder();
			byte[] encryptedText = base64decoder.decodeBuffer(encryptedString);
			byte[] plainText = cipher.doFinal(encryptedText);
			decryptedText = bytes2String(plainText);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return decryptedText;
	}

	private static String bytes2String(byte[] bytes) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
			stringBuffer.append((char) bytes[i]);
		}
		return stringBuffer.toString();
	}
}
