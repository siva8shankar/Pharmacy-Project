/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: MainServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class MainServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.DashBoardBean;
import com.newgen.bean.PasswordPolicyBean;
import com.newgen.dao.AdminChangePasswordDAO;
import com.newgen.dao.AdminChangePasswordDAOI;
import com.newgen.dao.DashBoardDAO;
import com.newgen.dao.TCDashBoardDAO;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

import oracle.net.nt.TcpNTAdapter;

public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private String ibps_endurl = "";
	private String cabinet = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
		ibps_endurl = (String) config.getServletContext().getAttribute("IBPSEndPointURL");
		logger.debug("ibps_endurl " + ibps_endurl);
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("cabinet " + cabinet);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MainServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		int result = 0;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// to check valid session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method of adminUserDao is ::" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			ClsUtil utility = new ClsUtil();

			// Invalidate the session if it's more than a day old or has been
			// inactive for more than an hour.
			if (!session.isNew()
					&& !utility.ValidateSession(session.getCreationTime(), session.getLastAccessedTime())) {
				request.getRequestDispatcher("LogOutServlet").forward(request, response);
			}

			AdminChangePasswordDAOI adminChangePassworddao = new AdminChangePasswordDAO();
			PasswordPolicyBean myPasswordBean = adminChangePassworddao.FetchPasswordPolicy(userName, sessionId, endurl);
			logger.debug("In MainServlet ----> Getting Password Settings ********************"
					+ myPasswordBean.getPasswordLen());
			session.setAttribute("PasswordPolicyData", myPasswordBean);
			// Till here

			if (!ClsUtil.isNullOrEmpty(session.getAttribute("Privilege"))
					&& ((String) session.getAttribute("Privilege")).equalsIgnoreCase("1")) {
				request.getRequestDispatcher("AdminUserListServlet").forward(request, response);
			} else {
				GeneralClass generalClass = null;
				String strPortalFlag1 = (String) session.getAttribute("PortalFlag");
				if(!strPortalFlag1.equalsIgnoreCase("") && strPortalFlag1 != null){
					logger.debug("Inside MainServlet Portal Flag ---> "+strPortalFlag1);
					if(strPortalFlag1.equalsIgnoreCase("VendorPortal")){
						DashBoardDAO dashdao = new DashBoardDAO();
						generalClass = dashdao.getDashboardData((String) session.getAttribute("VendorCode"), ibps_endurl,
								cabinet);
						if (generalClass.getArrayDashBoardBean() != null && generalClass.getArrayDashBoardBean().size() > 0) {
							logger.debug("Inside dashboard--->");
							request.setAttribute("DashBoardData", generalClass.getArrayDashBoardBean());
//							request.setAttribute("DashBoardStatusData", generalClass.getArrayDashboardStatusBean());
							request.getRequestDispatcher("JSP/Dashboard.jsp").forward(request, response);
						} else {
							request.getRequestDispatcher("JSP/AdminReports.jsp").forward(request, response);
						}
					}else if(strPortalFlag1.equalsIgnoreCase("TCPortal")){
//						request.setAttribute("UserName",userName);
//						request.getRequestDispatcher("JSP/error404.jsp").forward(request, response);
						TCDashBoardDAO tcdashdao = new TCDashBoardDAO();
						generalClass = tcdashdao.getTCDashboardData((String) session.getAttribute("VendorCode"), ibps_endurl,
								cabinet);
						if (generalClass.getArrayDashBoardBean() != null && generalClass.getArrayDashBoardBean().size() > 0) {
							logger.debug("Inside tcdashboard--->");
							request.setAttribute("TCDashBoardData", generalClass.getArrayDashBoardBean());
							request.setAttribute("TCDashBoardStatusData", generalClass.getArrayDashboardStatusBean());
//							request.setAttribute("TCDashBoardData", generalClass.getArrayTCDashBoardBean());
//							request.setAttribute("TCDashBoardStatusData", generalClass.getArrayTCDashboardStatusBean());
							request.getRequestDispatcher("JSP/TCDashboard.jsp").forward(request, response);
						} else {
							request.getRequestDispatcher("JSP/AdminReports.jsp").forward(request, response);
						}
					}
				}
				else{
					DashBoardDAO dashdao = new DashBoardDAO();
					generalClass = dashdao.getDashboardData((String) session.getAttribute("VendorCode"), ibps_endurl,
							cabinet);
					if (generalClass.getArrayDashBoardBean() != null && generalClass.getArrayDashBoardBean().size() > 0) {
						logger.debug("Inside dashboard--->");
						request.setAttribute("DashBoardData", generalClass.getArrayDashBoardBean());
						request.setAttribute("DashBoardStatusData", generalClass.getArrayDashboardStatusBean());
						request.getRequestDispatcher("JSP/Dashboard.jsp").forward(request, response);
					} else {
						request.getRequestDispatcher("JSP/AdminReports.jsp").forward(request, response);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			loggerErr.error("Exception in Main Servlet:" + e);
			e.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting My Main Servlet is :" + totaltime);

	}

}
