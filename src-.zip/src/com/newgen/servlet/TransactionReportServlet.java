/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: TransactionReportServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class TransactionReportServlet.It is used to generate reports of invoice.
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)      
*  10/10/2017							ksivashankar	          Showing list of records instead of redirecting to Reports.jsp page
*  09/01/2018							ksivashankar 				Bug 1023801 - Vendor Portal - Reports Tab - Data is not shown
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.ReportsBean;
import com.newgen.bean.VendorQueryDetails;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.dao.MyInvoiceDAO;
import com.newgen.dao.MyInvoiceDAOI;
import com.newgen.dao.SearchStatusDAO;
import com.newgen.dao.SearchStatusDAOI;
import com.newgen.dao.SubmitQueryDAO;
import com.newgen.dao.SubmitQueryDAOI;
import com.newgen.dao.TCSearchStatusDAO;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class TransactionReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.CalendarDateFormat);
	private static Logger logger = Logger.getLogger("consoleLogger");
	private String IBPSEndPointURL = "";
	private String cabinet = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		IBPSEndPointURL = (String) config.getServletContext().getAttribute("IBPSEndPointURL");
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TransactionReportServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		int result = 0;

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));
		SearchStatusDAOI searchStatusDao = new SearchStatusDAO();

		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// used to check session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method of adminUserDao is ::" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			SimpleDateFormat dt = new SimpleDateFormat(ClsMessageHandler.XMLDateFormat);
			SimpleDateFormat MMddyyyyFormat = new SimpleDateFormat("MM/dd/yyyy");

			GeneralClass generalClass = new GeneralClass();
			String priviledge = (String) session.getAttribute("Privilege");
			String VendorCode = (String) session.getAttribute("VendorCode");
			generalClass.setPriviledge(priviledge);
			generalClass.setVendorCode(VendorCode);
			String queryNo = null;
			String linkType;
			String topQueryNo;
			String lastQueryNo;
			if (!ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
				request.setAttribute("MSGCODE", request.getAttribute("MSGCODE"));
			}

			String archive = "";
			if (!ClsUtil.isNullOrEmpty(request.getParameter("ArchiveSearch"))) {
				archive = request.getParameter("ArchiveSearch");
			}
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenArchive"))) {
				archive = request.getParameter("hiddenArchive");
			}
			if ((!ClsUtil.isNullOrEmpty(request.getParameter("SearchType"))
					&& request.getParameter("SearchType").equalsIgnoreCase("SearchInvoice"))
					|| (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearch"))
							&& request.getParameter("hiddenSearch").equalsIgnoreCase("SearchInvoice"))) {

				logger.debug("Session: " + session.getId() + "UserName:" + userName);
				logger.debug("DateFrom: " + request.getParameter("DateFrom"));
				logger.debug("DateTo: " + request.getParameter("DateTo"));

				logger.debug("HiddenToDate--->" + request.getParameter("hiddenToDate"));
				logger.debug("hiddenFromDate--->" + request.getParameter("hiddenFromDate"));
				logger.debug("hiddenInvoiceNo--->" + request.getParameter("hiddenInvoiceNo"));

				logger.debug("Session: " + session.getId() + "UserName:" + userName);
				request.setAttribute("hiddenSearch", "SearchInvoice");
				String InvoiceNumber = "";

				// InvoiceDetails invoice = new InvoiceDetails();
				// InvoiceNewDetails invoice = new InvoiceNewDetails();
				ReportsBean myReport = new ReportsBean();

				Date dateFrom = null;
				Date dateTo = null;
				String strDateFrom = "";
				String strDateTo = "";
				try {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("DateFrom"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("DateTo"))) {

						// logger.debug("Inside From If--->");

						dateFrom = sdf.parse(request.getParameter("DateFrom"));
						dateTo = sdf.parse(request.getParameter("DateTo"));
						strDateFrom = dt.format(dateFrom);
						strDateTo = dt.format(dateTo);

						// logger.debug("Inside From If dateFrom--->"+dateFrom);
						// logger.debug("Inside From If dateTo--->"+dateTo);
					}
					if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenFromDate"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("hiddenToDate"))) {

						// logger.debug("Inside Hidden If--->");

						dateFrom = sdf.parse(request.getParameter("hiddenFromDate"));
						dateTo = sdf.parse(request.getParameter("hiddenToDate"));
						strDateFrom = dt.format(dateFrom);
						strDateTo = dt.format(dateTo);

						// logger.debug("Inside Hidden If
						// dateFrom--->"+dateFrom);
						// logger.debug("Inside Hidden If dateTo--->"+dateTo);

					}

				} catch (ParseException e) {
					// TODO Auto-generated catch block

					logger.error("Date Parsing Exception while Searching Invoice: : " + e.getMessage());
					e.printStackTrace();
				}

				logger.debug("After date parserr strDateFrom--->" + strDateFrom);
				logger.debug("After date parserr strDateTo--->" + strDateTo);

				if (!ClsUtil.isNullOrEmpty(request.getParameter("InvoiceNumber"))) {

					InvoiceNumber = request.getParameter("InvoiceNumber").trim();
					logger.debug("Inside From If InvoiceNumber--->" + InvoiceNumber);
				}
				if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenInvoiceNo"))) {

					InvoiceNumber = request.getParameter("hiddenInvoiceNo").trim();
					logger.debug("Inside Hidden If InvoiceNumber--->" + InvoiceNumber);
				}

				topQueryNo = request.getParameter("hiddenTopQueryNo");
				lastQueryNo = request.getParameter("hiddenLastQueryNo");
				linkType = request.getParameter("LinkType");
				generalClass.setLinkType(linkType);
				generalClass.setPaginationTopQryNo(topQueryNo);
				generalClass.setPaginationLastQryNo(lastQueryNo);
				generalClass.setBatchSize(ClsMessageHandler.BatchSizeInvoiceSearch);
				generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);

				myReport.setInvoiceNo(InvoiceNumber);
				myReport.setFromDate(dateFrom);
				myReport.setToDate(dateTo);

				// invoice.setInvoiceCreatedDate(strDateTo);
				// invoice.setFromDate(dateFrom);
				// invoice.setToDate(dateTo);
				// invoice.setInvoiceCreatedBy(userName);
				logger.debug("Sivashankar Testing... --->" + InvoiceNumber);
				// used to search invoices
				// generalClass = searchStatusDao.searchInvoice(generalClass,
				// invoice,archive, endurl);
				// Bug 1023801
				String strPortalFlag1 = (String) session.getAttribute("PortalFlag");
				if(!strPortalFlag1.equalsIgnoreCase("") && strPortalFlag1 != null){
					logger.debug("Inside MainServlet Portal Flag ---> "+strPortalFlag1);
					if(strPortalFlag1.equalsIgnoreCase("VendorPortal")){
						SearchStatusDAOI searchObj = new SearchStatusDAO();
						generalClass = searchObj.getReportDetails(myReport, generalClass, sessionId, endurl, IBPSEndPointURL,
								cabinet);

						request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);

						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("invoiceRadio")) {
							request.setAttribute("hiddenSearchCriteria", "invoiceRadio");

						}
						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("dateRadio")) {
							request.setAttribute("hiddenSearchCriteria", "dateRadio");
						}

						logger.debug("TopQueryNo: " + generalClass.getPaginationTopQryNo());
						logger.debug("LastQueryNo: " + generalClass.getPaginationLastQryNo());
						logger.debug("PrevFlag: " + generalClass.getPrevRecordFlag());
						logger.debug("NextFlag: " + generalClass.getLastRecordFlag());
						logger.debug("ToDate: " + ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
						logger.debug(
								"FromDate: " + ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
						logger.debug("InvNo: " + InvoiceNumber);

						// if(!ClsUtil.isNullOrEmpty(generalClass.getMap()) &&
						// generalClass.getMap().size() > 0){
						if (generalClass.getArrayReports() != null && generalClass.getArrayReports().size() > 0) {

							// request.setAttribute("InvoiceData",
							// generalClass.getMap());
							request.setAttribute("InvoiceData", generalClass.getArrayReports());
							request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
							request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
							request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
							request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
							// request.setAttribute("hiddenArchive", archive);

							request.setAttribute("ToDate",
									ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("FromDate",
									ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("InvNo", InvoiceNumber);
							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/Reports.jsp").forward(request, response);
						} else {
							logger.debug("inside 612 else : " + request.getAttribute("MSGCODE"));
							if (ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
								request.setAttribute("MSGCODE", ClsMessageHandler.MSG093);
							}
							request.setAttribute("ToDate",
									ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("FromDate",
									ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("InvNo", InvoiceNumber);

							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/Reports.jsp").forward(request, response);
						}
					}
					else{
						logger.debug("Inside else" + InvoiceNumber);
						TCSearchStatusDAO tcSearchObj = new TCSearchStatusDAO();
						generalClass = tcSearchObj.getTCReportDetails(myReport, generalClass, sessionId, endurl, IBPSEndPointURL,
								cabinet);

						request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);

						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("invoiceRadio")) {
							request.setAttribute("hiddenSearchCriteria", "invoiceRadio");

						}
						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("dateRadio")) {
							request.setAttribute("hiddenSearchCriteria", "dateRadio");
						}

						logger.debug("TopQueryNo: " + generalClass.getPaginationTopQryNo());
						logger.debug("LastQueryNo: " + generalClass.getPaginationLastQryNo());
						logger.debug("PrevFlag: " + generalClass.getPrevRecordFlag());
						logger.debug("NextFlag: " + generalClass.getLastRecordFlag());
						logger.debug("ToDate: " + ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
						logger.debug(
								"FromDate: " + ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
						logger.debug("InvNo: " + InvoiceNumber);

						// if(!ClsUtil.isNullOrEmpty(generalClass.getMap()) &&
						// generalClass.getMap().size() > 0){
						if (generalClass.getArrayTCInvoiceDetails() != null && generalClass.getArrayTCInvoiceDetails().size() > 0) {

							// request.setAttribute("InvoiceData",
							// generalClass.getMap());
							request.setAttribute("InvoiceData", generalClass.getArrayTCInvoiceDetails());
							request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
							request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
							request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
							request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
							// request.setAttribute("hiddenArchive", archive);

							request.setAttribute("ToDate",
									ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("FromDate",
									ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("InvNo", InvoiceNumber);
							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/TCReports.jsp").forward(request, response);
						} else {
							logger.debug("inside 612 else : " + request.getAttribute("MSGCODE"));
							if (ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
								request.setAttribute("MSGCODE", ClsMessageHandler.MSG093);
							}
							request.setAttribute("ToDate",
									ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("FromDate",
									ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("InvNo", InvoiceNumber);

							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/TCReports.jsp").forward(request, response);
						}
					}
				}
			} else if ((!ClsUtil.isNullOrEmpty(request.getParameter("SearchType"))
					&& request.getParameter("SearchType").equalsIgnoreCase("SearchQuery"))
					|| (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearch"))
							&& request.getParameter("hiddenSearch").equalsIgnoreCase("SearchQuery"))
							&& ((!ClsUtil.isNullOrEmpty(request.getParameter("checkButton"))
									&& request.getParameter("checkButton").equals("SearchButton"))
									|| (!ClsUtil.isNullOrEmpty(request.getParameter("LinkType"))
											&& (request.getParameter("LinkType").equals("next")
													|| request.getParameter("LinkType").equals("prev"))))) {

				String invoiceNo = null;
				request.setAttribute("hiddenSearch", "SearchQuery");
				request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);
				VendorQueryMaster venMaster = new VendorQueryMaster();

				Date dateFrom = null;
				Date dateTo = null;
				String statusQuery = null;

				if (!ClsUtil.isNullOrEmpty(request.getParameter("QueryNumber"))) {
					queryNo = request.getParameter("QueryNumber").trim();
				}

				if (request.getParameter("LinkType").equals("next")
						|| request.getParameter("LinkType").equals("prev")) {
					statusQuery = request.getParameter("hiddenStatus");
				} else {
					statusQuery = request.getParameter("statusSelect");
				}
				// SimpleDateFormat sdf = new
				// SimpleDateFormat(ClsMessageHandler.MainDateFormat);
				try {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("DateFrom"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("DateTo"))) {
						dateFrom = sdf.parse(request.getParameter("DateFrom"));
						dateTo = sdf.parse(request.getParameter("DateTo"));
					}
				} catch (ParseException e) {
					// TODO Auto-generated catch block

					logger.error("Date Parsing Exception while Searching Query: : " + e.getMessage());
					e.printStackTrace();
				}
				if (!ClsUtil.isNullOrEmpty(request.getParameter("InvoiceNumber"))) {
					invoiceNo = request.getParameter("InvoiceNumber").trim();
				}
				topQueryNo = request.getParameter("hiddenTopQueryNo");
				lastQueryNo = request.getParameter("hiddenLastQueryNo");
				linkType = request.getParameter("LinkType");

				if (!ClsUtil.isNullOrEmpty(queryNo)) {
					venMaster.setQueryNo(queryNo);
				}
				venMaster.setInvoiceNo(invoiceNo);
				venMaster.setFromDate(dateFrom);
				venMaster.setToDate(dateTo);
				venMaster.setCreatedBy(userName);

				generalClass.setLinkType(linkType);
				generalClass.setPaginationTopQryNo(topQueryNo);
				generalClass.setPaginationLastQryNo(lastQueryNo);
				generalClass.setBatchSize(ClsMessageHandler.BatchSizeQuerySearch);
				generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);
				// used to search queries
				generalClass = searchStatusDao.searchQuery(venMaster, generalClass, archive, statusQuery, endurl);

				if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
						&& request.getParameter("searchCriteria").equals("invoiceRadio")) {
					request.setAttribute("hiddenSearchCriteria", "invoiceRadio");
				}
				if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
						&& request.getParameter("searchCriteria").equals("queryRadio")) {
					request.setAttribute("hiddenSearchCriteria", "queryRadio");
				}
				if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
						&& request.getParameter("searchCriteria").equals("dateRadio")) {
					request.setAttribute("hiddenSearchCriteria", "dateRadio");
				}

				if (!ClsUtil.isNullOrEmpty(generalClass.getArrayQueryMaster())
						&& generalClass.getArrayQueryMaster().size() > 0) {
					request.setAttribute("hiddenStatus", statusQuery);
					request.setAttribute("QueryData", generalClass.getArrayQueryMaster());
					request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
					request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
					request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
					request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
					request.setAttribute("hiddenArchive", archive);

					request.setAttribute("ToDate", request.getParameter("DateTo"));
					request.setAttribute("FromDate", request.getParameter("DateFrom"));
					request.setAttribute("InvNo", invoiceNo);
					request.setAttribute("QryNo", queryNo);
					request.setAttribute("VendorSearch", "Search Query");
					request.getRequestDispatcher("JSP/Reports.jsp").forward(request, response);
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG010);
					request.setAttribute("VendorSearch", "Search Query");
					request.getRequestDispatcher("JSP/Reports.jsp").forward(request, response);
				}
			} else if ((!ClsUtil.isNullOrEmpty(request.getParameter("hiddenHyperlink"))
					&& request.getParameter("hiddenHyperlink").equals("hyperlink"))
					|| (!ClsUtil.isNullOrEmpty(request.getParameter("Button1"))
							&& request.getParameter("Button1").equals("Reply"))) {

				boolean status;

				VendorQueryDetails venDetails = new VendorQueryDetails();
				String invoiceNo;
				queryNo = request.getParameter("hiddenQueryNo");
				invoiceNo = request.getParameter("hiddenInvoiceNo");
				GeneralClass genQueryDetails = null;
				venDetails.setQueryNo(queryNo);
				venDetails.setCreatedBy(userName);
				if (!ClsUtil.isNullOrEmpty(request.getParameter("Button1"))
						&& request.getParameter("Button1").equals("Reply")) {

					if (!ClsUtil.isNullOrEmpty(request.getParameter("status"))
							&& request.getParameter("status").equals("check")) {
						status = true;
					} else {
						status = false;
					}
					venDetails.setDescription(request.getParameter("QueryReply"));
					SubmitQueryDAOI vendorQueryDao = new SubmitQueryDAO();
					// used to get Query Status
					result = searchStatusDao.getQueryStatus(queryNo, endurl);
					if (result == 0) {
						// used to submit Query
						generalClass = vendorQueryDao.submitQuery(VendorCode, venDetails, invoiceNo, status, null,
								sessionId, endurl);
					} else {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG022);
					}
					// used to get Query Details
					genQueryDetails = searchStatusDao.searchQueryDetails(priviledge, venDetails, archive, sessionId,
							endurl);
					request.setAttribute("history", -1);
				} else {
					// used to get Query Details
					genQueryDetails = searchStatusDao.searchQueryDetails(priviledge, venDetails, archive, sessionId,
							endurl);
				}
				// used to get Query Status
				result = searchStatusDao.getQueryStatus(queryNo, endurl);
				if (result != 0) {
					request.setAttribute("checkStatus", "DisableReply");
				}

				request.setAttribute("invNo", invoiceNo);
				request.setAttribute("qryNo", queryNo);
				request.setAttribute("ArchiveDB", archive);
				if (generalClass.getSessionresult() > 0) {
					if (genQueryDetails.getSessionresult() > 0) {
						if (generalClass.getResultCode() > 0) {
							request.setAttribute("QueryDataDetails", genQueryDetails.getArrayQueryDetails());
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG005);
							request.setAttribute("VendorSearch", "Query Details");
							request.getRequestDispatcher("JSP/SearchQueryDetails.jsp").forward(request, response);
						} else if (generalClass.getResultCode() == 0) {
							request.setAttribute("QueryDataDetails", genQueryDetails.getArrayQueryDetails());
							request.setAttribute("VendorSearch", "Query Details");
							request.getRequestDispatcher("JSP/SearchQueryDetails.jsp").forward(request, response);
						} else {
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG006);
							request.setAttribute("VendorSearch", "Query Details");
							request.getRequestDispatcher("JSP/SearchQueryDetails.jsp").forward(request, response);
						}
					} else {
						// query details session
						response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
						return;
					}
				} else {
					// submit query session
					response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
					return;
				}
			} else {
				/*
				 * request.setAttribute("SearchStatus",
				 * ClsMessageHandler.QueryStatusTypes);
				 * request.getRequestDispatcher("JSP/Reports.jsp").forward(
				 * request, response);
				 */

				// on 10/10/2017 starts
				logger.debug("Session: " + session.getId() + "UserName:" + userName);
				logger.debug("DateFrom: " + request.getParameter("DateFrom"));
				logger.debug("DateTo: " + request.getParameter("DateTo"));

				logger.debug("HiddenToDate--->" + request.getParameter("hiddenToDate"));
				logger.debug("hiddenFromDate--->" + request.getParameter("hiddenFromDate"));
				logger.debug("hiddenInvoiceNo--->" + request.getParameter("hiddenInvoiceNo"));

				logger.debug("Session: " + session.getId() + "UserName:" + userName);
				request.setAttribute("hiddenSearch", "SearchInvoice");
				String InvoiceNumber = "";

				// InvoiceDetails invoice = new InvoiceDetails();
				// InvoiceNewDetails invoice = new InvoiceNewDetails();
				ReportsBean myReport = new ReportsBean();

				Date dateFrom = null;
				Date dateTo = null;
				String strDateFrom = "";
				String strDateTo = "";
				try {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("DateFrom"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("DateTo"))) {

						// logger.debug("Inside From If--->");

						dateFrom = sdf.parse(request.getParameter("DateFrom"));
						dateTo = sdf.parse(request.getParameter("DateTo"));
						strDateFrom = dt.format(dateFrom);
						strDateTo = dt.format(dateTo);

						// logger.debug("Inside From If dateFrom--->"+dateFrom);
						// logger.debug("Inside From If dateTo--->"+dateTo);
					}
					if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenFromDate"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("hiddenToDate"))) {

						// logger.debug("Inside Hidden If--->");

						dateFrom = sdf.parse(request.getParameter("hiddenFromDate"));
						dateTo = sdf.parse(request.getParameter("hiddenToDate"));
						strDateFrom = dt.format(dateFrom);
						strDateTo = dt.format(dateTo);

						// logger.debug("Inside Hidden If
						// dateFrom--->"+dateFrom);
						// logger.debug("Inside Hidden If dateTo--->"+dateTo);

					}

				} catch (ParseException e) {
					// TODO Auto-generated catch block

					logger.error("Date Parsing Exception while Searching Invoice: : " + e.getMessage());
					e.printStackTrace();
				}

				logger.debug("After date parserr strDateFrom--->" + strDateFrom);
				logger.debug("After date parserr strDateTo--->" + strDateTo);

				if (!ClsUtil.isNullOrEmpty(request.getParameter("InvoiceNumber"))) {

					InvoiceNumber = request.getParameter("InvoiceNumber").trim();
					logger.debug("Inside From If InvoiceNumber--->" + InvoiceNumber);
				}
				if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenInvoiceNo"))) {

					InvoiceNumber = request.getParameter("hiddenInvoiceNo").trim();
					logger.debug("Inside Hidden If InvoiceNumber--->" + InvoiceNumber);
				}

				topQueryNo = request.getParameter("hiddenTopQueryNo");
				lastQueryNo = request.getParameter("hiddenLastQueryNo");
				linkType = request.getParameter("LinkType");
				generalClass.setLinkType(linkType);
				generalClass.setPaginationTopQryNo(topQueryNo);
				generalClass.setPaginationLastQryNo(lastQueryNo);
				generalClass.setBatchSize(ClsMessageHandler.BatchSizeInvoiceSearch);
				generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);

				myReport.setInvoiceNo(InvoiceNumber);
				myReport.setFromDate(dateFrom);
				myReport.setToDate(dateTo);

				// invoice.setInvoiceCreatedDate(strDateTo);
				// invoice.setFromDate(dateFrom);
				// invoice.setToDate(dateTo);
				// invoice.setInvoiceCreatedBy(userName);
				
				// used to search invoices
				// generalClass = searchStatusDao.searchInvoice(generalClass,
				// invoice,archive, endurl);
				
				String strPortalFlag1 = (String) session.getAttribute("PortalFlag");
				if(!strPortalFlag1.equalsIgnoreCase("") && strPortalFlag1 != null){
					logger.debug("Inside MainServlet Portal Flag ---> "+strPortalFlag1);
					if(strPortalFlag1.equalsIgnoreCase("VendorPortal")){
						SearchStatusDAOI searchObj = new SearchStatusDAO();
						generalClass = searchObj.getReportDetails(myReport, generalClass, sessionId, endurl, IBPSEndPointURL,
								cabinet);

						request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);

						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("invoiceRadio")) {
							request.setAttribute("hiddenSearchCriteria", "invoiceRadio");

						}
						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("dateRadio")) {
							request.setAttribute("hiddenSearchCriteria", "dateRadio");
						}

						logger.debug("TopQueryNo: " + generalClass.getPaginationTopQryNo());
						logger.debug("LastQueryNo: " + generalClass.getPaginationLastQryNo());
						logger.debug("PrevFlag: " + generalClass.getPrevRecordFlag());
						logger.debug("NextFlag: " + generalClass.getLastRecordFlag());
						logger.debug("ToDate: " + ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
						logger.debug(
								"FromDate: " + ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
						logger.debug("InvNo: " + InvoiceNumber);

						// if(!ClsUtil.isNullOrEmpty(generalClass.getMap()) &&
						// generalClass.getMap().size() > 0){
						if (generalClass.getArrayReports() != null && generalClass.getArrayReports().size() > 0) {

							// request.setAttribute("InvoiceData",
							// generalClass.getMap());
							request.setAttribute("InvoiceData", generalClass.getArrayReports());
							request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
							request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
							request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
							request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
							// request.setAttribute("hiddenArchive", archive);

							request.setAttribute("ToDate",
									ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("FromDate",
									ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("InvNo", InvoiceNumber);
							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/Reports.jsp").forward(request, response);
						} else {
							logger.debug("inside 612 else : " + request.getAttribute("MSGCODE"));
							if (ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
								request.setAttribute("MSGCODE", ClsMessageHandler.MSG093);
							}
							request.setAttribute("ToDate",
									ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("FromDate",
									ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("InvNo", InvoiceNumber);

							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/Reports.jsp").forward(request, response);
						}
					}
					else{
						logger.debug("Inside else" + InvoiceNumber);
						TCSearchStatusDAO tcSearchObj = new TCSearchStatusDAO();
						generalClass = tcSearchObj.getTCReportDetails(myReport, generalClass, sessionId, endurl, IBPSEndPointURL,
								cabinet);

						request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);

						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("invoiceRadio")) {
							request.setAttribute("hiddenSearchCriteria", "invoiceRadio");

						}
						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("dateRadio")) {
							request.setAttribute("hiddenSearchCriteria", "dateRadio");
						}

						logger.debug("TopQueryNo: " + generalClass.getPaginationTopQryNo());
						logger.debug("LastQueryNo: " + generalClass.getPaginationLastQryNo());
						logger.debug("PrevFlag: " + generalClass.getPrevRecordFlag());
						logger.debug("NextFlag: " + generalClass.getLastRecordFlag());
						logger.debug("ToDate: " + ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
						logger.debug(
								"FromDate: " + ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
						logger.debug("InvNo: " + InvoiceNumber);

						// if(!ClsUtil.isNullOrEmpty(generalClass.getMap()) &&
						// generalClass.getMap().size() > 0){
						if (generalClass.getArrayTCInvoiceDetails() != null && generalClass.getArrayTCInvoiceDetails().size() > 0) {

							// request.setAttribute("InvoiceData",
							// generalClass.getMap());
							request.setAttribute("InvoiceData", generalClass.getArrayTCInvoiceDetails());
							request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
							request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
							request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
							request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
							// request.setAttribute("hiddenArchive", archive);

							request.setAttribute("ToDate",
									ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("FromDate",
									ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("InvNo", InvoiceNumber);
							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/TCReports.jsp").forward(request, response);
						} else {
							logger.debug("inside 612 else : " + request.getAttribute("MSGCODE"));
							if (ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
								request.setAttribute("MSGCODE", ClsMessageHandler.MSG093);
							}
							request.setAttribute("ToDate",
									ClsUtil.convertDateFormat(strDateTo, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("FromDate",
									ClsUtil.convertDateFormat(strDateFrom, "yyyy-MM-dd HH:mm:ss", "dd/MM/yyyy"));
							request.setAttribute("InvNo", InvoiceNumber);

							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/TCReports.jsp").forward(request, response);
						}
					}
				}
				

			}
		} catch (Exception e) {
			logger.error("Exception in Transaction Report Servlet: : " + e.getMessage());
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			e.printStackTrace();
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in geting transaction report is " + totaltime);
	}

}
