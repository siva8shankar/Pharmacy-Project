/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GetDocIDByTransIDServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminUserListDAO;
import com.newgen.dao.AdminUserListDAOI;
import com.newgen.dao.GetDocIDByTransIDDAO;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsExportExcel;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class GetDocIDByTransIDServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private String cabinet = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetDocIDByTransIDServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.debug("inside doPost in GetDocIDByTransIDServlet...");
		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		String transactionID = "";

		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();
			logger.debug("session  === " + sessionId + " userName   == " + userName);
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--" + sessionId);

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.--" + sessionId);

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			transactionID = request.getParameter("transactionID");
			ArrayList<String> arrList = new ArrayList<String>();

			logger.debug("transactionID ===" + transactionID);

			GetDocIDByTransIDDAO getdocdao = new GetDocIDByTransIDDAO();

			arrList = getdocdao.getDocIDByTransIDMethod(transactionID, endurl, cabinet);

			if (arrList.size() > 0) {

				logger.debug("arrList ====> " + arrList);
				logger.debug("transactionID ===" + transactionID);
				request.setAttribute("GetDocIDData", arrList);
				request.getRequestDispatcher("JSP/MyDocumentID.jsp").forward(request, response);

			} else {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
			loggerErr.error("Exception in My Queries Servlet:" + e.getMessage());
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting MyQueriesServlet is :" + totaltime);

	}
}
