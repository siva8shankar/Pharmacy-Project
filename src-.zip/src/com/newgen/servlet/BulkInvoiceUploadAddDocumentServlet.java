/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: BulkInvoiceUploadAddDocumentServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AddDocumentServlet to add document
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.newgen.bean.InvoiceNewDetails;
import com.newgen.dao.InvoiceNoDuplicateCheckDAO;
import com.newgen.dao.WorkitemDAO;
import com.newgen.util.AddToSMS;
import com.newgen.util.ClsExportExcel;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;
import com.newgen.util.MultipartFileUploaderForBulkInvoice;
import com.newgen.util.MultipartUtility;

import ISPack.ISUtil.JPISException;

public class BulkInvoiceUploadAddDocumentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private String ibps_endurl = "";
	private String WorkitemEndPointurl = "";
	private String OD_IP = "";
	private String cabinet = "";
	private String folderName = "";
	private String volumeIndex = "";
	private String rootFolderPath = "";
	private String jtsIpAddress = "";
	private String jtsPort = "";
	private String OD_SessionURL = "", OD_Session_User = "", OD_Session_Pwd = "", WrapperPort = "", UserType = "",
			DataClass = "", DocIndexName1, DocIndexName2 = "";
	private String WI_DocIndexId = "";
	private String File_DocIndexId = "";
	private String InitiateFromActivityId = "";
	private String InitiateFromActivityName = "";
	private String ProcessDefId = "";
	private String ProcessName = "";
	private String result = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		WorkitemEndPointurl = (String) config.getServletContext().getAttribute("WorkItemEndPointURL");
		logger.debug("WorkitemEndPointurl " + WorkitemEndPointurl);
		ibps_endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("ibps_endurl " + ibps_endurl);
		OD_IP = (String) config.getServletContext().getAttribute("ODIP");
		logger.debug("OD_IP " + OD_IP);
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("cabinet " + cabinet);
		volumeIndex = (String) config.getServletContext().getAttribute("VolumeIndex");
		logger.debug("VolumeIndex " + volumeIndex);
		jtsIpAddress = (String) config.getServletContext().getAttribute("jtsIpAddress");
		logger.debug("jtsIpAddress " + jtsIpAddress);
		jtsPort = (String) config.getServletContext().getAttribute("jtsPort");
		logger.debug("jtsPort " + jtsPort);
		OD_SessionURL = (String) config.getServletContext().getAttribute("OD_SessionURL");
		logger.debug("OD_SessionURL " + OD_SessionURL);
		OD_Session_User = (String) config.getServletContext().getAttribute("OD_Session_User");
		logger.debug("OD_Session_User " + OD_Session_User);
		OD_Session_Pwd = (String) config.getServletContext().getAttribute("OD_Session_Pwd");
		logger.debug("OD_Session_Pwd " + OD_Session_Pwd);
		WrapperPort = (String) config.getServletContext().getAttribute("WrapperPort");
		logger.debug("WrapperPort " + WrapperPort);
		UserType = (String) config.getServletContext().getAttribute("UserType");
		logger.debug("UserType " + UserType);
		InitiateFromActivityId = (String) config.getServletContext().getAttribute("InitiateFromActivityId");
		logger.debug("InitiateFromActivityId " + InitiateFromActivityId);
		InitiateFromActivityName = (String) config.getServletContext().getAttribute("InitiateFromActivityName");
		logger.debug("InitiateFromActivityName " + InitiateFromActivityName);
		ProcessDefId = (String) config.getServletContext().getAttribute("ProcessDefId");
		logger.debug("ProcessDefId " + ProcessDefId);
		ProcessName = (String) config.getServletContext().getAttribute("ProcessName");
		logger.debug("ProcessName " + ProcessName);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BulkInvoiceUploadAddDocumentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.debug("In doPost of AddDocumentServlet!!");
		long starttime = System.currentTimeMillis();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String filePath = null;
		String Sessionid = "";
		String fileName = "";
		String fieldname = "";
		String invNo = "";
		String filesadded = "";
		ArrayList<String> Uploaded_workitems = new ArrayList<String>();
		ArrayList<String> Failed_Workitems = new ArrayList<String>();
		try {
			MultipartUtility session = new MultipartUtility(OD_SessionURL, "UTF-8");
			logger.debug("OD_SessionURL" + OD_SessionURL + "OD_Session_User" + OD_Session_User + "OD_Session_Pwd"
					+ OD_Session_Pwd + "BP_CabinetName" + cabinet + "JTSIP" + jtsIpAddress + "JTSPORT" + jtsPort
					+ "UserType" + UserType);
			Sessionid = session.getSessionValue(OD_SessionURL, OD_Session_User, OD_Session_Pwd, UserType);

			logger.debug("GetSessionOD->Sessionid:::" + Sessionid);

			if (Sessionid == "" || Sessionid == "error"
					|| Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
				logger.debug("Error in getting OD session id!!");
				out.println("Error in getting OD session id!!");
				response.setStatus(500);
				result = "500";
				return;
			}

			String serverPath = System.getProperty("user.dir");
			logger.debug("Working Directory = " + System.getProperty("user.dir"));
			String folderpath = "";
			String wi = "", Docname = "";
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			logger.debug("isMultipartContent::" + isMultipart);
			isMultipart = true;
			if (!isMultipart) {
				response.setStatus(501);
				out.println("is not Multipart Content!!");
				return;
			}
			List items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

			logger.debug("	" + items.size());

			ArrayList<String> bulk_invoice_details = new ArrayList<String>();

			request.setAttribute("SessionID", request.getSession().getId());
			request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

			String values = request.getParameter("values");
			logger.debug("Values  --> " + values);

			String ivalues = request.getParameter("ivalues");
			logger.debug("i Values --> " + ivalues);

			String[] invoiceDetails = values.split("!-");
			for (int i = 0; i <= Integer.parseInt(ivalues); i++) {
				bulk_invoice_details.add(invoiceDetails[i]);
			}

			HashMap<Integer, String> hash_bulk_values = null;

			logger.debug("bulk_invoice_details.size()-->" + bulk_invoice_details.size());

			logger.debug("bulk_invoice_details.get(0).toString()-->" + bulk_invoice_details.get(1));

			for (int i = 1; i < bulk_invoice_details.size(); i++) {
				String[] S_values = bulk_invoice_details.get(i).split("~");
				logger.debug("first value" + S_values[0]);
				logger.debug("Second value" + S_values[1]);
				String invoiceNo = S_values[1];
				String invoiceDate = S_values[2];
				String billingAddress = S_values[3];
				String billingAddrType = S_values[4];
				String currency = S_values[5];
				String typeOfTxn = S_values[6];
				String poNo = S_values[7];
				String reqEmailID = S_values[8];
				String reqName = S_values[9];
				String typeOfInvoice = S_values[10];// Combo //Material Or
													// Service

				logger.debug("invoiceNo --->" + invoiceNo);
				logger.debug("invoiceDate --->" + invoiceDate);
				logger.debug("billingAddress --->" + billingAddress);
				logger.debug("billingAddrType --->" + billingAddrType);
				logger.debug("currency --->" + currency);
				logger.debug("typeOfTxn --->" + typeOfTxn);
				logger.debug("poNo --->" + poNo);
				logger.debug("reqEmailID --->" + reqEmailID);
				logger.debug("reqName --->" + reqName);
				logger.debug("typeOfInvoice --->" + typeOfInvoice);

				String baseValue = S_values[11];
				String serviceTax = S_values[12];
				String sbc = S_values[13];
				String kkc = S_values[14];
				String cst = S_values[15];
				String vat = S_values[16];
				String igst = S_values[17];
				String cgst = S_values[18];
				String sgst = S_values[19];
				String exciseDuty = S_values[20];

				String invoiceValue = S_values[21];
				String pan = S_values[22];
				String tan = S_values[23];
				String serviceRegNo = S_values[24];
				String tin = S_values[25];

				String stPerc = S_values[26];
				String cstPerc = S_values[27];
				String vatPerc = S_values[28];
				String edPerc = S_values[29];

				String vendorCode = S_values[30];
				String userName = (String) request.getAttribute("UserName");
				String vendorName = S_values[31];
				String vendorEmailId = S_values[32];
				String paymenttype = S_values[33];

				logger.debug("pan --->" + pan);
				logger.debug("tan --->" + tan);
				logger.debug("serviceRegNo --->" + serviceRegNo);
				logger.debug("tin --->" + tin);
				logger.debug("vendorCode --->" + vendorCode);
				logger.debug("userName --->" + userName);
				logger.debug("vendorName --->" + vendorName);
				logger.debug("vendorEmailId --->" + vendorEmailId);
				logger.debug("paymenttype -->" + paymenttype);

				if (currency.equalsIgnoreCase("NULL") || currency.equalsIgnoreCase("-- Select --")
						|| currency.equalsIgnoreCase("")) {
					currency = "INR";
				}

				if (ClsUtil.isNullOrEmpty(sbc))
					sbc = "0";
				if (ClsUtil.isNullOrEmpty(kkc))
					kkc = "0";
				if (ClsUtil.isNullOrEmpty(cst))
					cst = "0";
				if (ClsUtil.isNullOrEmpty(vat))
					vat = "0";
				if (ClsUtil.isNullOrEmpty(igst))
					igst = "0";
				if (ClsUtil.isNullOrEmpty(cgst))
					cgst = "0";
				if (ClsUtil.isNullOrEmpty(sgst))
					sgst = "0";
				if (ClsUtil.isNullOrEmpty(invoiceValue))
					invoiceValue = "0";
				if (ClsUtil.isNullOrEmpty(baseValue))
					baseValue = "0";
				if (ClsUtil.isNullOrEmpty(serviceTax))
					serviceTax = "0";
				if (ClsUtil.isNullOrEmpty(stPerc))
					stPerc = "0";
				if (ClsUtil.isNullOrEmpty(cstPerc))
					cstPerc = "0";
				if (ClsUtil.isNullOrEmpty(vatPerc))
					vatPerc = "0";
				if (ClsUtil.isNullOrEmpty(edPerc))
					edPerc = "0";
				if (ClsUtil.isNullOrEmpty(exciseDuty))
					exciseDuty = "0";

				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date d1 = new Date();
				String CreatedDate = dateFormat.format(d1);
				String strInvoiceDate = "";
				Date invdate = null;
				if (!ClsUtil.isNullOrEmpty(invoiceDate)) {
					try {

						SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.MainDateFormat);
						invdate = sdf.parse(invoiceDate);
						strInvoiceDate = dateFormat.format(invdate);

					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				logger.debug("strInvoiceDate-->" + strInvoiceDate);
				logger.debug("baseValue-->" + baseValue);
				logger.debug("serviceTax-->" + serviceTax);
				logger.debug("sbc-->" + sbc);
				logger.debug("cst-->" + cst);
				logger.debug("igst-->" + igst);
				int Invoicenoduplicationcheck;
				InvoiceNoDuplicateCheckDAO invoicenoduplicatecheckDAO = new InvoiceNoDuplicateCheckDAO();
				// Invoicenoduplicationcheck=invoicenoduplicatecheckDAO.checkInvoiceDuplicate(invDetails.getInvoiceno(),
				// invoiceDate, invDetails.getVendorno(), ibps_endurl);
				// logger.debug("Invoicenoduplicationcheck----->"+Invoicenoduplicationcheck);
				// if(Invoicenoduplicationcheck==0)
				{
					// {

					logger.debug("items.size() -->" + items.size());
					if (items.size() == 0) {
						response.setStatus(502);
						out.println("items size is 0!!");

						return;
					}

					ArrayList<String> AddtoSMS_Response_sd = new ArrayList<String>();

					FileItem item_sd = (FileItem) items.get(i - 1);
					logger.debug("no----->" + i);
					if (i != 0) {

						long cdt = System.currentTimeMillis();
						folderpath = serverPath + File.separator + "Documents";
						File file = new File(folderpath);
						if (!file.isDirectory()) {
							file.mkdir();
						}
						String itemName = item_sd.getName();
						logger.debug("Uploaded Document Path---->" + itemName);
						itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());// To
																											// be
																											// handled
																											// here
						fileName = itemName;
						filePath = folderpath + File.separator + cdt + "_" + itemName;
						File savedFile = new File(filePath);
						item_sd.write(savedFile);
						String a = "";
						a = AddToSMS.AddtoSms("Invoice", filePath, Sessionid, WorkitemEndPointurl, jtsIpAddress,
								cabinet, jtsPort, volumeIndex);
						logger.debug("+AddtoSMS_Response_sd--->" + a);
						AddtoSMS_Response_sd.add(a);

					}

					if (AddtoSMS_Response_sd != null) {
						WorkitemDAO workitemDAO = new WorkitemDAO();
						logger.debug("CaseNumber" + result);
						result = invoiceNo + "_" + result;
						Uploaded_workitems.add(result);
					} else {
						result = "";
						result = invoiceNo + "_FAIL";
						Failed_Workitems.add(result);
						logger.debug("inside addtosms response else----->" + result);
					}
				}
				{
					result = "";
					result = invoiceNo + "_DUPLICATEINVOICE";
					Failed_Workitems.add(result);
					logger.debug("outside addtosms response else----->" + result);
				}

				result.replace("\n", "");
				logger.debug("result for AddDocInOD is : " + result);
				logger.debug("i value-->" + i + "bulk_invoice_details size-->" + bulk_invoice_details.size());

				if (i == (bulk_invoice_details.size() - 1)) {

					String a = Uploaded_workitems.toString() + "!_&_!" + Failed_Workitems.toString();
					response.setStatus(200);
					result = a;
					logger.debug("Upload Status " + result);
					out.print(result);
				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			response.setStatus(503);
			e.printStackTrace();
			loggerErr.error("Exception in Uploading Document : " + e.getMessage());
		} catch (JPISException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// }

		logger.debug(" Uploaded_workitems" + Uploaded_workitems.toString());
	}
}
