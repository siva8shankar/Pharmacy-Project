/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ExportUserExcelServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class ExportExcelServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserMasterBean;
import com.newgen.dao.SearchStatusDAO;
import com.newgen.dao.SearchStatusDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsExportExcel;
import com.newgen.util.ClsUtil;

public class ExportUserExcelServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerXml = Logger.getLogger("xmlLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private String IBPSEndPointurl = "";
	private String cabinet = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
		IBPSEndPointurl = (String) config.getServletContext().getAttribute("IBPSEndPointURL");// IBPSEndPointurl
		logger.debug("IBPSEndPointURL is :" + IBPSEndPointurl);
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("cabinet is :" + cabinet);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ExportUserExcelServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		int result = 0;
		String type = "xls";
		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}

			session = request.getSession();
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName")
					+ " Exporting data to excel-------------------");

			request.setAttribute("MSGCODE", null);

			String vendorCode = (String) session.getAttribute("VendorCode");

			VPUserMasterBean usermasterBean = new VPUserMasterBean();

			usermasterBean.setHeader("UserName,UserEmailId,VendorCode,VendorName,VendorAddress,VendorMobileNo");
			usermasterBean.setExportHeader("User Name,User EmailID,Vendor Code, Vendor Name, Vendor Address,Mobile No");
			usermasterBean.setFieldDelimiter("`");
			usermasterBean.setRowDelimiter("~");
			usermasterBean.setFooter("Deloitte P2P Process");

			logger.debug("c Header---->" + usermasterBean.getHeader());
			logger.debug("usermasterBean getFieldDelimiter---->" + usermasterBean.getFieldDelimiter());
			logger.debug("usermasterBean getRowDelimiter---->" + usermasterBean.getRowDelimiter());
			logger.debug("usermasterBean getFooter---->" + usermasterBean.getFooter());

			logger.debug("In ExportUserExcelServlet before Report Generation----");

			// This Method is used to export UserList Report.
			SearchStatusDAOI searchStatusDao = new SearchStatusDAO();
			StringBuffer exportData = searchStatusDao.exportUserMaster(usermasterBean, IBPSEndPointurl);

			loggerXml.debug("In ExportUserExcelServlet ExportData---->" + exportData.toString());

			try {
				OutputStream out = response.getOutputStream();

				ClsExportExcel.exportUserExcel(exportData, usermasterBean.getExportHeader(), usermasterBean,
						session.getId(), getServletContext().getRealPath("temp"));

				response.setHeader("Content-Disposition", "attachment;filename = Report." + type);
				response.setContentType("excel/" + "Report." + type);

				logger.debug("In ExportUserExcelServlet GeneratedPath->" + getServletContext().getRealPath("temp")
						+ File.separator + "ExcelReport" + session.getId() + "." + type);
				FileInputStream in;

				in = new FileInputStream(getServletContext().getRealPath("temp") + File.separator + "ExcelReport"
						+ session.getId() + "." + type);

				logger.debug("before try block------------->");
				try {
					int n = 0;
					byte b[] = new byte[1024];
					while ((n = in.read(b)) != -1) {
						out.write(b, 0, n);
					}
					out.flush();
					logger.debug("file writting.............");
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (in != null) {
						in.close();
					}
					if (out != null) {
						out.close();
					}
				}

				logger.debug("before deleting the file");
				File file;

				file = new File(getServletContext().getRealPath("temp") + File.separator + "ExcelReport"
						+ session.getId() + "." + type);

				try {
					file.delete();
					logger.debug("file deleted successfully...");
				} catch (Exception exc) {
					exc.printStackTrace();
				}

			} catch (Exception ex) {
				loggerErr.error("Exception in exporting data to excel : " + ex.getMessage());
				ex.printStackTrace();
			}
		}

		catch (Exception e) {
			System.out.println("Exception in export " + e);
		}

	}

}
