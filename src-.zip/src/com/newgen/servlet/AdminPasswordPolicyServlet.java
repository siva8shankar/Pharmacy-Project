/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminPasswordPolicyServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminChangePasswordServlet. It is used to Change Password
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.PasswordPolicyBean;
import com.newgen.dao.AdminChangePasswordDAO;
import com.newgen.dao.AdminChangePasswordDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class AdminPasswordPolicyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl is :: " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminPasswordPolicyServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		int result = 0;
		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		logger.debug("AdminPasswordPolicyServlet -> Start Time " + starttime);

		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// used to check session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			request.setAttribute("MSGCODE", null);
			request.setAttribute("UserName", session.getAttribute("UserName"));
			request.setAttribute("SessionID", request.getSession().getId());

			AdminChangePasswordDAOI adminChangePassworddao = new AdminChangePasswordDAO();
			PasswordPolicyBean myPasswordBean = new PasswordPolicyBean();

			logger.debug("Session: " + session.getId() + "UserName:" + userName);
			String passwordLen = request.getParameter("passwordLen");
			String minSplCharCt = request.getParameter("minSplCharCt");
			String minUpperCaseCt = request.getParameter("minUpperCaseCt");
			String minLowerCaseCt = request.getParameter("minLowerCaseCt");
			String minNumCharCt = request.getParameter("minNumCharCt");

			myPasswordBean.setPasswordLen(passwordLen);
			myPasswordBean.setMinSplCharCt(minSplCharCt);
			myPasswordBean.setMinUpperCaseCt(minUpperCaseCt);
			myPasswordBean.setMinLowerCaseCt(minLowerCaseCt);
			myPasswordBean.setMinNumCharCt(minNumCharCt);

			// This Method is used to update password.
			result = adminChangePassworddao.savePasswordPolicy(myPasswordBean, userName, endurl);

			// Password changed successfully
			if (result > 0) {
				logger.debug("Password Settings has been updated successfully");
				session.setAttribute("PasswordPolicyData", myPasswordBean);
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG082);
				request.getRequestDispatcher("JSP/PasswordPolicy.jsp").forward(request, response);
			} else {
				request.setAttribute("Administration", "Password Policy");
				request.getRequestDispatcher("JSP/PasswordPolicy.jsp").forward(request, response);
			}
		} catch (Exception ex) {
			loggerErr.error("Exception in Password Policy By Admin Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;

		logger.debug("Total Time Taken in Changing password By Admin is " + totaltime);

	}

}
