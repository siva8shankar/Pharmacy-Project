/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: FetchVendorDetailsServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class FetchVendorDetailsServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
* sschanged == sivashankar modified code
* ssadded == sivashankar added code
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorMaster;
import com.newgen.dao.NewUserDAO;
import com.newgen.dao.NewUserDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class FetchVendorDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);

	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FetchVendorDetailsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("Fetch Vendor Details by Vendor Code.....");

		HttpSession session = null;
		int result = 0;

		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String vendorCode = (String) session.getAttribute("VendorCode");
			String sessionId = session.getId();
			VendorMaster venMaster = new VendorMaster();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			request.setAttribute("MSGCODE", null);

			NewUserDAOI newUserDao = new NewUserDAO();

			PrintWriter out = response.getWriter();

			venMaster.setVendorCode(vendorCode);
			venMaster = newUserDao.fetchVendorDetailsByVendorCode(vendorCode, endurl);

			if (venMaster != null) {
				out.print(venMaster.getVendorName() + "~@#" + venMaster.getVendorAddress() + "~@#"
						+ ((venMaster.getPAN() == "NULL") ? "PAN is not Available" : venMaster.getPAN()) + "~@#"
						+ ((venMaster.getTAN() == "NULL") ? "TAN is not Available" : venMaster.getTAN()) + "~@#"
						+ ((venMaster.getServiceRegNo() == "NULL") ? "SRN is not Available"
								: venMaster.getServiceRegNo())
						+ "~@#" + ((venMaster.getTIN() == "NULL") ? "TIN is not Available" : venMaster.getTIN()) + "~@#"
						+ ((venMaster.getMobileNo() == "NULL") ? "Mobile is not Available" : venMaster.getMobileNo()));
			} else {
				logger.debug("Invalid Vendor Code");
				out.print(ClsMessageHandler.MSG064);
			}

		} catch (Exception ex) {
			loggerErr.error("Exception in Fetching Vendor Details By vendor Code Servlet:" + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting FetchVendorListServlet is :" + totaltime);
	}

}
