/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminDeleteVendorServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminDeleteDAO;
import com.newgen.dao.AdminDeleteDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class AdminDeleteVendorServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminDeleteVendorServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug(" Deletion of Vendor By Admin");

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		AdminDeleteDAOI adminDeleteDAO = new AdminDeleteDAO();
		int result = 0;
		String[] checkValues = null;
		String[] vndrCodes = null;
		String[] cmpnyCodes = null;
		HttpSession session = null;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName")
					+ " Admin Deleting Vendor");

			request.setAttribute("MSGCODE", null);
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenDeleteInline"))
					&& request.getParameter("hiddenDeleteInline").equalsIgnoreCase("Inline")) {
				vndrCodes = new String[1];
				cmpnyCodes = new String[1];
				vndrCodes[0] = request.getParameter("hiddenVendorCode");
				cmpnyCodes[0] = request.getParameter("hiddenCompanyCode");

				// This Method is used to delete vendor.
				result = adminDeleteDAO.deleteVendor(vndrCodes, cmpnyCodes, endurl);
			} else {
				vndrCodes = new String[(request.getParameterValues("check").length)];
				cmpnyCodes = new String[(request.getParameterValues("check").length)];
				checkValues = request.getParameterValues("check");

				for (int i = 0; i < checkValues.length; i++) {
					vndrCodes[i] = (checkValues[i].substring(0, checkValues[i].indexOf(","))).trim();
					cmpnyCodes[i] = (checkValues[i].substring(checkValues[i].indexOf(",") + 1)).trim();
				}
				result = adminDeleteDAO.deleteVendor(vndrCodes, cmpnyCodes, endurl);
			}
			// Vendor Deleted Successfully
			if (result > 0) {
				logger.debug("Vendor Deleted Successfully");
				request.setAttribute("Administration", "Delete Vendor");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG046);
				request.getRequestDispatcher("AdminVendorListServlet").forward(request, response);
			} else {
				request.setAttribute("Administration", "Delete Vendor");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
				request.getRequestDispatcher("JSP/AdminVendorList.jsp").forward(request, response);
			}

		} catch (Exception ex) {
			loggerErr.error("Exception in Admin Deleting Vendor Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Deleting Vendor is : " + totaltime);
	}
}
