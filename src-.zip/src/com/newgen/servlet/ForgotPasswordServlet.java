/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ForgotPasswordServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class ForgotPasswordServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminUserDAO;
import com.newgen.dao.AdminUserDAOI;
import com.newgen.util.ClsMessageHandler;

public class ForgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ForgotPasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("Forgot Password.....");

		HttpSession session = null;

		try {

			session = request.getSession();

			request.setAttribute("MSGCODE", null);
			String userName = request.getParameter("userNameForgot").trim();

			AdminUserDAOI adminUserDao = new AdminUserDAO();
			// used to send mail
			int result = adminUserDao.sendEmail(userName, endurl);
			logger.debug("sendEmail method of AdminUserDAO" + result);

			if (result > 0) {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG060);
				request.getRequestDispatcher("JSP/ForgotPassword.jsp").forward(request, response);
			} else if (result == -1) {
				logger.debug("User Approved Successfully But Mail Server Is Down.");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG066);
				request.getRequestDispatcher("JSP/ForgotPassword.jsp").forward(request, response);
			} else if (result == -2) {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG073);
				request.getRequestDispatcher("JSP/ForgotPassword.jsp").forward(request, response);
			}
			// Server is down. Please login after sometime.
			else {
				logger.debug("Server is down. Please login after sometime.");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
				request.getRequestDispatcher("JSP/ForgotPassword.jsp").forward(request, response);
			}

		} catch (Exception ex) {
			loggerErr.error("Exception in Forgot Password Servlet:" + ex.getMessage());
			ex.printStackTrace();

			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Reseting Password is :" + totaltime);
	}

}
