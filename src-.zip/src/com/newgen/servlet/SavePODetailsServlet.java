/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SavePODetailsServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class SavePODetailsServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY) 
* 24-July-2017                        ksivashankar          	all response & request commented
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.PODetails;
import com.newgen.dao.UpdatePODetailsDAO;
import com.newgen.dao.UpdatePODetailsDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class SavePODetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SavePODetailsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		int result = 0;
		Date date = null;
		PrintWriter out = response.getWriter();
		SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.CalendarDateFormat);

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));
		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// used to check session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method of adminUserDao is ::" + result);

			String vendorName = (String) session.getAttribute("VendorName");
			request.setAttribute("VendorName", vendorName);

			if (result != 1) {
				// response.sendRedirect(request.getContextPath() +
				// "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--" + sessionId);

				// response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.--" + sessionId);

				// response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			request.setAttribute("MSGCODE", null);

			PODetails poDetails = new PODetails();
			poDetails.setUserName(userName);

			String poNumber = request.getParameter("PONumber");
			poDetails.setPONumber(poNumber);
			String companyAddress = request.getParameter("CompanyAddress");
			poDetails.setCompanyAddress(companyAddress);
			String SubmittoCompany = request.getParameter("SubmittoCompany");
			poDetails.setSubmittoCompany(SubmittoCompany);
			String AttentionTo = request.getParameter("AttentionTo");
			poDetails.setAttentionTo(AttentionTo);
			String VendorCode = request.getParameter("VendorCode");
			poDetails.setVendorCode(VendorCode);
			String VendorName = request.getParameter("VendorName");
			poDetails.setVendorName(VendorName);
			String VendorAddress = request.getParameter("VendorAddress");
			poDetails.setVendorAddress(VendorAddress);
			String InvoiceNumber = request.getParameter("InvoiceNumber");
			poDetails.setInvoiceNumber(InvoiceNumber);
			String InvoiceType = request.getParameter("InvoiceType");
			poDetails.setInvoiceType(InvoiceType);

			String InvoiceDate = request.getParameter("InvoiceDate");

			poDetails.setInvoiceDate(InvoiceDate);

			String Currency = request.getParameter("Currency");
			poDetails.setCurrency(Currency);

			String strEducationCess = request.getParameter("EducationCess");
			poDetails.setEducationCess(strEducationCess);

			String strVat = request.getParameter("VAT");
			poDetails.setVAT(strVat);

			String strFreight = request.getParameter("Freight");
			poDetails.setFreight(strFreight);

			String strDiscount = request.getParameter("Discount");
			poDetails.setDiscount(strDiscount);

			String strServiceTax = request.getParameter("ServiceTax");
			poDetails.setServiceTax(strServiceTax);

			String strGrossAmount = request.getParameter("GrossAmount");
			poDetails.setGrossAmount(strGrossAmount);

			String strNetAmount = request.getParameter("NetAmount");
			poDetails.setNetAmount(strNetAmount);

			String strTotalTax = request.getParameter("TotalTax");
			poDetails.setTotalTax(strTotalTax);

			String strAdditionalVAT = request.getParameter("AdditionalVAT");
			poDetails.setAdditionalVAT(strAdditionalVAT);

			String strAnyOtherTax = request.getParameter("AnyOtherTax");
			poDetails.setAnyOtherTax(strAnyOtherTax);

			String strDeliveryDate = request.getParameter("DeliveryDate");
			logger.debug("strDeliveryDate " + strDeliveryDate);
			poDetails.setDeliveryDate(strDeliveryDate);

			logger.debug("strAnyOtherTax  -->" + strAnyOtherTax);
			String list = request.getParameter("list");
			int list1 = Integer.parseInt(list);
			Map<String, String> map = new HashMap<String, String>();
			StringBuilder strDynamicRows = new StringBuilder();
			strDynamicRows.append("<DynamicRows>");
			for (int x = 1; x < list1; x++) {
				strDynamicRows.append("<VPPOLineItems poNumber='" + poNumber);
				String Desc = request.getParameter("Desc" + x);
				strDynamicRows.append("' Desc='" + Desc);
				String Quantity = request.getParameter("Quantity" + x);
				strDynamicRows.append("' Quantity='" + Quantity);
				String GrossAmt = request.getParameter("GrossAmt" + x);
				strDynamicRows.append("' GrossAmt='" + GrossAmt);
				strDynamicRows.append("' Tax='" + strServiceTax);
				String NetAm = request.getParameter("NetAm" + x);
				strDynamicRows.append("' NetAm='" + NetAm);
				String NetAmount = request.getParameter("NetAmount");
				strDynamicRows.append("' NetAmount='" + NetAmount);
				strDynamicRows.append("' userName='" + userName + "'/>");

			}
			strDynamicRows.append("</DynamicRows>");
			UpdatePODetailsDAOI genPODetailsDao = new UpdatePODetailsDAO();
			logger.debug("SaveDetailsPage === " + strDynamicRows.toString());
			result = genPODetailsDao.UpdatePO(poDetails, endurl, map, strDynamicRows);

			Integer result1 = new Integer(result);
			Integer zero = new Integer(0);

			if (result1 > zero) {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG087);
				// request.getRequestDispatcher("MyPOServlet").forward(request,
				// response);
				logger.debug("PO Details Updated succesfully");

			} else {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG070);
				// request.getRequestDispatcher("MyPOServlet").forward(request,
				// response);
				logger.debug("PO Details Not Updated");
			}
			// }

		} catch (Exception e) {
			loggerErr.error("Exception in Save PODetails Servlet:" + e.getMessage());
			e.printStackTrace();
			// request.getRequestDispatcher("JSP/Error.jsp").forward(request,response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Save PODetails Query is :" + totaltime);
		out.print("PO Details Updated Successfully");// <!-- Added by
														// SivashankarKS
														// 24-July-2017 -->
	}
}
