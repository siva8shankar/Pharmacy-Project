/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminNewUserServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminNewUserServlet, Used for Adding New User By Admin
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserMaster;
import com.newgen.dao.AdminNewUserDAO;
import com.newgen.dao.AdminNewUserDAOI;
import com.newgen.dao.NewUserDAO;
import com.newgen.dao.NewUserDAOI;
import com.newgen.lic.servlet.LicFetch;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class AdminNewUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl is :: " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminNewUserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));
		logger.debug("Adding New User By Admin");

		VPUserMaster userMaster = new VPUserMaster();
		AdminNewUserDAOI adminNewUserDao = new AdminNewUserDAO();
		NewUserDAOI newUserDao = new NewUserDAO();
		int result = 0;

		HttpSession session = null;

		// an
		ArrayList<String> outptXML;
		String maxUserCreated = "";
		String keySaved = "";
		String namedUser1 = "";
		String concUser = "";
		// an-end

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			request.setAttribute("MSGCODE", null);

			outptXML = LicFetch.fetchData(endurl);
			for (int i = 0; i < outptXML.size(); i++) {
				if (i == 0)
					maxUserCreated = outptXML.get(i);
				if (i == 1)
					keySaved = outptXML.get(i);
				if (i == 2)
					namedUser1 = outptXML.get(i);
				if (i == 3)
					concUser = outptXML.get(i);
			}
			int Int_maxUserCreated = Integer.parseInt(maxUserCreated);
			int Int_namedUser1 = Integer.parseInt(namedUser1);
			if (Int_maxUserCreated < Int_namedUser1) {
				if (!(request.getParameter("hiddenButton").equals("checkAvailability"))) {
					userMaster.setUserName(request.getParameter("userName"));
					userMaster.setVendorCode(request.getParameter("vendorCode"));
					userMaster.setVendorName(request.getParameter("vendorName"));
					userMaster.setVendorAddress(request.getParameter("vendorAdd"));
					userMaster.setUserEmailId(request.getParameter("emailId"));
					userMaster.setUserAddress(request.getParameter("address"));
					userMaster.setUserPhoneNumber(request.getParameter("phoneNo"));
					userMaster.setPrivilege(request.getParameter("privilege"));
					userMaster.setUserType(request.getParameter("usertype"));
					userMaster.setExpiryDateTime(request.getParameter("expiryDate"));
					userMaster.setFirstName(request.getParameter("firstName"));
					userMaster.setLastName(request.getParameter("lastName"));

					// This Method is used to add User.
					result = adminNewUserDao.addNewUser(userMaster, endurl);
					logger.debug("result of addNewUser method of adminNewUserDao is ::" + result);

					// User registered successfully
					if (result > 0) {
						logger.debug("User registered successfully");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG030);
						request.setAttribute("Administration", "Add New User");
						request.getRequestDispatcher("JSP/AdminAddUser.jsp").forward(request, response);

					}
					// User Approved Successfully But Mail Server Is Down.
					else if (result == -2) {
						logger.debug("User Approved Successfully But Mail Server Is Down.");
						request.setAttribute("Administration", "Add New User");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG056);
						request.getRequestDispatcher("JSP/AdminAddUser.jsp").forward(request, response);
					}
					// UserName is already exist in database
					else if (result == -1) {
						logger.debug("UserName is already in use. Try different username");
						request.setAttribute("Administration", "Add New User");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG024);
						request.getRequestDispatcher("JSP/AdminAddUser.jsp").forward(request, response);
					}
					// Error occurred while registering user
					else {
						request.setAttribute("Administration", "Add New User");
						logger.debug("Error while registering user. Please try after sometime");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG025);
						request.getRequestDispatcher("JSP/AdminAddUser.jsp").forward(request, response);
					}
				} else {

					// This Method is used to check availability of username.
					result = newUserDao.checkAvailability(request.getParameter("userName"), endurl);
					logger.debug("result of checkAvailability method of newUserDao is ::" + result);

					// UserName is already exist in database
					if (result == -1) {
						request.setAttribute("Administration", "Username Availability Check");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG024);
						request.getRequestDispatcher("JSP/AdminAddUser.jsp").forward(request, response);
					}
					// UserName is available
					else {
						logger.debug("Entered UserName is available");
						request.setAttribute("Administration", "Username Availability Check");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG026);
						request.getRequestDispatcher("JSP/AdminAddUser.jsp").forward(request, response);
					}
				}
			}
			// an
			else // if no of users created exceed licensed number
			{
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG081);
				request.getRequestDispatcher("JSP/Login.jsp").forward(request, response);

			} // an-end

		} catch (Exception ex) {
			loggerErr.error("Exception in Admin Add User Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;

		logger.debug("Total Time Taken in in Adding New User is " + totaltime);
	}

}
