/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GenerateBarCodeServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class GenerateBarCodeServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.SocketException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GenerateBarcodeImage;

public class GenerateBarCodeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GenerateBarCodeServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean error = false;
		long starttime = System.currentTimeMillis();
		GenerateBarcodeImage BarcodeImage = null;
		HttpSession session = null;
		int result = 0;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// to check valid session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method of adminUserDao is ::" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			request.setAttribute("MSGCODE", null);
			String InvoiceNumber = request.getParameter("InvoiceNumber");

			BarcodeImage = new GenerateBarcodeImage();
			int i = BarcodeImage.GenerateBarCode(InvoiceNumber, ClsMessageHandler.BarCodeGeneratedFileExt,
					getServletContext().getRealPath(ClsMessageHandler.BarcodeFontFamily));

			if (i < 0) {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG015);
			} else {
				error = true;
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG016);

				response.reset();
				response.setHeader("Content-Disposition",
						"attachment;filename =" + InvoiceNumber + "." + ClsMessageHandler.BarCodeGeneratedFileExt);

				OutputStream out = response.getOutputStream();
				FileInputStream in = new FileInputStream(
						InvoiceNumber + "." + ClsMessageHandler.BarCodeGeneratedFileExt);
				try {

					response.setContentType("image/" + ClsMessageHandler.BarCodeGeneratedFileExt);

					int n = 0;
					byte b[] = new byte[1024];
					while ((n = in.read(b)) != -1) {
						out.write(b, 0, n);
					}
					out.flush();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (in != null) {
						in.close();
					}
					if (out != null) {
						out.close();
					}
				}
			}

		} catch (SocketException se) {
			loggerErr.error("Socket Exception in Generating BarCode:" + se.getMessage());
			se.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		} catch (Exception e) {
			loggerErr.error("Exception in  Generating BarCode:" + e.getMessage());
			e.printStackTrace();

			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();

		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting GenerateBarCodeServlet is :" + totaltime);

		if (!error) {
			String refer = "";
			String redirect = "";

			if (!ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				refer = request.getHeader("Referer");
				redirect = refer.substring(refer.lastIndexOf("/") + 1);

			}
			if (redirect.equalsIgnoreCase("MyInvoiceServlet")) {
				request.getRequestDispatcher("MyInvoiceServlet").forward(request, response);
			} else if (redirect.equalsIgnoreCase("SearchStatusServlet")) {
				request.getRequestDispatcher("SearchStatusServlet").forward(request, response);
			} else {
				request.getRequestDispatcher("MainServlet").forward(request, response);
			}

		}
	}
}