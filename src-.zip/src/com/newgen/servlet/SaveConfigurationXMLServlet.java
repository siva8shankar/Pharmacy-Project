/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SaveConfigurationXMLServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class SaveConfigurationXMLServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class SaveConfigurationXMLServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SaveConfigurationXMLServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		HttpSession session = null;

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));
		int result = 0;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();
			// used to check session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method of adminUserDao is ::" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--" + sessionId);

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.--" + sessionId);

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Admin Changing Settings, Session: " + session.getId() + "UserName:" + userName);

			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc;

			doc = docBuilder.parse(new File(getServletContext().getRealPath("VendorPortal.xml")));
			// root element
			Element root = doc.getDocumentElement();
			NodeList nodelist = root.getChildNodes();
			for (int i = 1; i < nodelist.getLength(); i++) {

				Node node = nodelist.item(i);
				if (null != node && node.hasChildNodes()) {

					NodeList nodelistChild = node.getChildNodes();
					for (int j = 1; j < nodelistChild.getLength(); j = j + 2) {

						if (j == 0)
							continue;

						Node ChildNode = nodelistChild.item(j);
						ChildNode.setTextContent(request.getParameter(ChildNode.getNodeName()));
					}
				}
			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();

			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			// StringWriter writer = new StringWriter();
			StreamResult changedXML = new StreamResult(getServletContext().getRealPath("VendorPortal.xml"));
			transformer.transform(source, changedXML);

			request.setAttribute("MSGCODE", ClsMessageHandler.MSG068);
			request.getRequestDispatcher("VendorPortalXMLGenerationServlet").forward(request, response);

		} catch (ParserConfigurationException pce) {
			loggerErr.error("ParserConfigurationException in getting Admin Settings Servlet : " + pce.getMessage());

			pce.printStackTrace();
			request.getRequestDispatcher("VendorPortalXMLGenerationServlet").forward(request, response);
		} catch (TransformerException tfe) {
			loggerErr.error("TransformerException in getting Admin Settings Servlet : " + tfe.getMessage());

			tfe.printStackTrace();
			request.getRequestDispatcher("VendorPortalXMLGenerationServlet").forward(request, response);
		} catch (IOException ioe) {
			loggerErr.error("IOException in getting Admin Settings Servlet : " + ioe.getMessage());

			ioe.printStackTrace();
			request.getRequestDispatcher("VendorPortalXMLGenerationServlet").forward(request, response);
		} catch (SAXException sae) {
			loggerErr.error("SAXException in getting Admin Settings Servlet : " + sae.getMessage());

			sae.printStackTrace();
			request.getRequestDispatcher("VendorPortalXMLGenerationServlet").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			loggerErr.error("Exception in getting Admin Settings Servlet : " + e.getMessage());
			request.getRequestDispatcher("VendorPortalXMLGenerationServlet").forward(request, response);

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in changing settings is " + totaltime);
	}

}
