/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SubmitQueryServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class SubmitQueryServlet.It is used to submit a Query
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorQueryDetails;
import com.newgen.dao.SubmitQueryDAO;
import com.newgen.dao.SubmitQueryDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class SubmitQueryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SubmitQueryServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			request.setAttribute("MSGCODE", null);
			GeneralClass generalClass = new GeneralClass();
			String nextQueryNo = null;

			VendorQueryDetails venDetails = new VendorQueryDetails();

			String invoiceNo = request.getParameter("InvoiceNo");
			String transactionNo = request.getParameter("TransactionNo");
			String poTransactionNo = request.getParameter("POTransactionNo");
			String PONumber = request.getParameter("PONumber");
			String userPrivilege = request.getParameter("userPrivilege");
			logger.debug("invoiceNo " + invoiceNo);
			logger.debug("transactionNo " + transactionNo);
			logger.debug("poTransactionNo " + poTransactionNo);
			logger.debug("PONumber " + PONumber);
			logger.debug("userPrivilege " + userPrivilege);
			venDetails.setInvoiceNo(invoiceNo);
			venDetails.setTransactionNo(transactionNo);
			venDetails.setPoTransactionNo(poTransactionNo);
			venDetails.setUserPrivilege(userPrivilege);
			venDetails.setPONumber(PONumber);

			if (!ClsUtil.isNullOrEmpty(invoiceNo)) {
				logger.debug("VendorQueryDetails === ");
				invoiceNo = invoiceNo.trim();
				request.setAttribute("VendorQueryDetails", venDetails);

			}
			String desc = request.getParameter("QueryDesc");

			invoiceNo = request.getParameter("InvoiceNumber");
			venDetails.setDescription(desc);
			venDetails.setCreatedBy(userName);
			String VendorCode = (String) session.getAttribute("VendorCode");
			SubmitQueryDAOI queryDao = new SubmitQueryDAO();

			if (!ClsUtil.isNullOrEmpty(invoiceNo) && !ClsUtil.isNullOrEmpty(desc)) {
				logger.debug("Invoice based SubmitQuery === ");
				// to submit a query
				generalClass = queryDao.submitQuery(VendorCode, venDetails, invoiceNo, false, nextQueryNo, sessionId,
						endurl);
				if (generalClass.getSessionresult() > 0) {
					if (generalClass.getResultCode() > 0) {
						request.setAttribute("GeneratedQueryNumber", generalClass.getQueryNumber());
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG005);
						request.setAttribute("VendorQuery", "Submitted Query Successfully");
						request.getRequestDispatcher("JSP/SubmitQuery.jsp").forward(request, response);
					} else if (generalClass.getResultCode() == -1) {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG008);
						request.setAttribute("VendorQuery", "Submit Query");
						request.getRequestDispatcher("JSP/SubmitQuery.jsp").forward(request, response);

					} else {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG006);
						request.setAttribute("VendorQuery", "Submit Query");
						request.getRequestDispatcher("JSP/SubmitQuery.jsp").forward(request, response);
					}
				} else {
					response.sendRedirect(request.getContextPath() + "/login");
					return;
				}
			} else if (!ClsUtil.isNullOrEmpty(PONumber) && !ClsUtil.isNullOrEmpty(desc)) {
				logger.debug("PONumber based SubmitQuery === ");
				// to submit a query
				generalClass = queryDao.submitQuery(VendorCode, venDetails, invoiceNo, false, nextQueryNo, sessionId,
						endurl);
				if (generalClass.getSessionresult() > 0) {
					if (generalClass.getResultCode() > 0) {
						request.setAttribute("GeneratedQueryNumber", generalClass.getQueryNumber());
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG005);
						request.setAttribute("VendorQuery", "Submitted Query Successfully");
						request.getRequestDispatcher("JSP/SubmitQuery.jsp").forward(request, response);
					} else if (generalClass.getResultCode() == -1) {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG008);
						request.setAttribute("VendorQuery", "Submit Query");
						request.getRequestDispatcher("JSP/SubmitQuery.jsp").forward(request, response);

					} else {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG006);
						request.setAttribute("VendorQuery", "Submit Query");
						request.getRequestDispatcher("JSP/SubmitQuery.jsp").forward(request, response);
					}
				} else {
					response.sendRedirect(request.getContextPath() + "/login");
					return;
				}
			} else {
				logger.debug("InvoiceNumber or PONumber is empty");
				request.getRequestDispatcher("JSP/SubmitQuery.jsp").forward(request, response);
			}
		} catch (Exception e) {

			loggerErr.error("Exception in Submit Query Servlet: : " + e.getMessage());
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			e.printStackTrace();
			session.invalidate();

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Submitting Query is " + totaltime);
	}
}
