/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminHistoryServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminHistoryServlet, Used for Checking History
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminHistoryDAO;
import com.newgen.dao.AdminHistoryDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class AdminHistoryServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminHistoryServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("Admin Checking History");

		AdminHistoryDAOI adminHistoryDAO = new AdminHistoryDAO();
		GeneralClass gen = new GeneralClass();
		String linkType;
		String topNo;
		String lastNo;
		String historyOfUser = null;
		HttpSession session = null;
		int result = 0;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName") + " History");

			request.setAttribute("MSGCODE", null);
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenButton"))
					&& request.getParameter("hiddenButton").trim().equalsIgnoreCase("ShowHistory")) {

				Date dateFrom = null;
				Date dateTo = null;
				SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.CalendarDateFormat);

				try {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("DateFrom"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("DateTo"))) {
						dateFrom = sdf.parse(request.getParameter("DateFrom"));
						dateTo = sdf.parse(request.getParameter("DateTo"));
					}

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					loggerErr.error("Date Parsing Exception while Fetching History: " + e.getMessage());
					e.printStackTrace();
				}

				topNo = request.getParameter("hiddenTopNo");
				lastNo = request.getParameter("hiddenLastNo");
				linkType = request.getParameter("LinkType");
				historyOfUser = request.getParameter("userName");

				gen.setLinkType(linkType);
				gen.setPaginationTopQryNo(topNo);
				gen.setPaginationLastQryNo(lastNo);
				gen.setBatchSize(ClsMessageHandler.BatchSizeHistory);
				gen.setDbConfig(ClsMessageHandler.MainDBConfig);

				// This Method is used to getHistory.
				gen = adminHistoryDAO.getHistory(gen, historyOfUser, dateFrom, dateTo, endurl);

				if (!ClsUtil.isNullOrEmpty(gen.getArrayUserActivity()) && gen.getArrayUserActivity().size() > 0) {
					request.setAttribute("HistoryData", gen.getArrayUserActivity());
					request.setAttribute("TopNo", gen.getPaginationTopQryNo());
					request.setAttribute("LastNo", gen.getPaginationLastQryNo());
					request.setAttribute("PrevFlag", gen.getPrevRecordFlag());
					request.setAttribute("NextFlag", gen.getLastRecordFlag());
					request.setAttribute("userName", historyOfUser);
					request.setAttribute("ToDate", request.getParameter("DateTo"));
					request.setAttribute("FromDate", request.getParameter("DateFrom"));
					request.getRequestDispatcher("JSP/History.jsp").forward(request, response);
				}
				// No History Found
				else if (!ClsUtil.isNullOrEmpty(gen.getArrayUserActivity()) && gen.getArrayUserActivity().size() == 0) {
					logger.debug("No History Found");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG051);
					request.getRequestDispatcher("JSP/History.jsp").forward(request, response);
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.getRequestDispatcher("JSP/History.jsp").forward(request, response);
				}

			} else {
				request.getRequestDispatcher("JSP/History.jsp").forward(request, response);
			}

		} catch (Exception ex) {
			loggerErr.error("Exception in Admin History Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Admin Checking History is : " + totaltime);
	}
}
