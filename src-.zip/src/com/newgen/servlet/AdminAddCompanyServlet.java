/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminAddCompanyServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminAddCompanyServlet, It is used to add and update companies details
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.CompanyMaster;
import com.newgen.dao.AdminNewCompanyDAO;
import com.newgen.dao.AdminNewCompanyDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class AdminAddCompanyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminAddCompanyServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("Adding New Company By Admin");

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		CompanyMaster companyMaster = new CompanyMaster();
		AdminNewCompanyDAOI adminNewCompanyDAO = new AdminNewCompanyDAO();
		int result = 0;

		HttpSession session = null;

		try {

			session = request.getSession();

			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// to check valid session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method of adminUserDao is ::" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			request.setAttribute("MSGCODE", null);

			// Used to Add New company
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenHyperlink"))
					&& request.getParameter("hiddenHyperlink").equalsIgnoreCase("AddNewCompany")) {
				response.sendRedirect("JSP/AdminAddNewCompany.jsp");
			}

			// It is used to update companies details
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenHyperlink"))
					&& request.getParameter("hiddenHyperlink").equalsIgnoreCase("CompanyDetails")) {

				String companyCode = request.getParameter("hiddenCompanyCode");

				// Used to get company details i.e. Company name, code, address
				// etc
				GeneralClass generalClass = adminNewCompanyDAO.getCompanyDetails(companyCode, endurl);

				if (!ClsUtil.isNullOrEmpty(generalClass.getArrayCompanyList())
						&& generalClass.getArrayCompanyList().size() > 0) {
					request.setAttribute("hiddenHyperlink", "CompanyDetails");
					request.setAttribute("ArrayCompanyDetails", generalClass.getArrayCompanyList().get(0));
					request.setAttribute("Administration", "Company Details");
					request.getRequestDispatcher("JSP/AdminAddNewCompany.jsp").forward(request, response);
				} else {
					request.setAttribute("hiddenHyperlink", "CompanyDetails");
					request.setAttribute("Administration", "Company Details");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.getRequestDispatcher("JSP/AdminAddNewCompany.jsp").forward(request, response);
				}

			} else {

				String tempCompanyCode = null;
				String tempCompanyName = null;

				companyMaster.setCompanyCode(request.getParameter("companyCode"));
				companyMaster.setCompanyName(request.getParameter("companyName"));
				companyMaster.setCompanyAddress(request.getParameter("companyAdd"));
				companyMaster.setCountry(request.getParameter("country"));

				if (!ClsUtil.isNullOrEmpty(request.getParameter("ButtonType"))
						&& request.getParameter("ButtonType").equalsIgnoreCase("Update")) {
					tempCompanyCode = request.getParameter("hiddenTempCompanyCode");
					tempCompanyName = request.getParameter("hiddenTempCompanyName");

				}

				result = adminNewCompanyDAO.addNewCompany(companyMaster, request.getParameter("ButtonType"),
						tempCompanyCode, tempCompanyName, endurl);

				if (result > 0) {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("ButtonType"))
							&& request.getParameter("ButtonType").equalsIgnoreCase("Update")) {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG043);
					} else {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG041);
					}
					request.setAttribute("Administration", "Add Company");
					request.getRequestDispatcher("JSP/AdminAddNewCompany.jsp").forward(request, response);

				} else if (result == -1) {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG040);
					request.setAttribute("Administration", "Add Company");
					request.getRequestDispatcher("JSP/AdminAddNewCompany.jsp").forward(request, response);
				} else {
					request.setAttribute("Administration", "Add Company");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG042);
					request.getRequestDispatcher("JSP/AdminAddNewCompany.jsp").forward(request, response);
				}
			}

		} catch (Exception ex) {
			loggerErr.error("Exception in Admin Add Company Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Adding Company is " + totaltime);
	}
}
