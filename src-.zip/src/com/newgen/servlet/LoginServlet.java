/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: LoginServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class LoginServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.newgen.bean.PasswordPolicyBean;
import com.newgen.bean.VPUserMaster;
import com.newgen.dao.AdminChangePasswordDAO;
import com.newgen.dao.AdminChangePasswordDAOI;
import com.newgen.dao.LoginDAO;
import com.newgen.lic.servlet.DESedeEncryption;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	ServletContext servletcontext = null;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		servletcontext = config.getServletContext();
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.info("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();

		HttpSession session = request.getSession();
		ClsUtil utility = new ClsUtil();
		logger.info("In Login Servlet for new SESSION_ID");

		try {
			if ((ClsUtil.isNullOrEmpty(request.getParameter("UserName")))
					|| (ClsUtil.isNullOrEmpty(request.getParameter("Password")))) {

				logger.debug("This is not valid login");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			String enterUserName = request.getParameter("UserName");
			String Password = request.getParameter("hiddenPwd");
			String formPassword = request.getParameter("Password");
			String strPortalFlag = request.getParameter("Portal");

			logger.debug("Hidden Password-->" + Password);
			logger.debug("Form Password-->" + formPassword);
			logger.debug("eToken-->" + session.getAttribute("eToken"));
			logger.debug("strPortalFlag --> " + strPortalFlag);

			if (ClsUtil.isNullOrEmpty(Password))
				Password = formPassword;
			AdminChangePasswordDAOI adminChangePassworddao = new AdminChangePasswordDAO();
			PasswordPolicyBean myPasswordBean = adminChangePassworddao.FetchPasswordPolicy("", "", endurl);
			logger.debug("In LoginServlet ----> Getting Password Settings ********************"
					+ myPasswordBean.getPasswordLen());
			session.setAttribute("PasswordPolicyData", myPasswordBean);

			LoginDAO logindao = new LoginDAO();
			String result = null;
			result = logindao.loginGetPwd(enterUserName, endurl);
			logger.debug("LoginServlet result &&&& --> " + result);

			if (result.equalsIgnoreCase("No Data Exist")) {

				request.setAttribute("MSGCODE", ClsMessageHandler.MSG073);
				request.getRequestDispatcher("login").forward(request, response);
			} else if (result.equalsIgnoreCase("FirstTimeLogin")){
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG084);
				request.getRequestDispatcher("login").forward(request, response);
			} else if (!result.equalsIgnoreCase("No Data Exist")) {
				String dcryptedpwd = null;
				try {
					logger.debug("Start Decryption process......");
					String key = result;
					String randno = key.substring(key.length() - 1);
					String shuffleData = key.substring(0, key.length() - 2);
					DESedeEncryption obj = new DESedeEncryption();
					Character[] charObjectArray = toCharacterArray(shuffleData);
					List<Character> list = new ArrayList<Character>(Arrays.asList(charObjectArray));
					compoundUnshuffle(list, 2, Integer.parseInt(randno));
					StringBuilder sb1 = new StringBuilder();
					for (Character s : list) {
						sb1.append(s);
					}
					String unshuffleData = sb1.toString();
					byte[] decodedBytes = Base64.decodeBase64(unshuffleData.getBytes());
					String decodedBytesStr = new String(decodedBytes);
					dcryptedpwd = obj.decrypt(decodedBytesStr);
					logger.debug("Finished Decryption process......");
				} catch (Exception e) {
					logger.debug("Exception in decrypt in LoginPwd::");
					e.printStackTrace();
					logger.debug("Exception in decrypt in LoginPwd:-->" + e);
				}

				logger.debug("Actual Password value is--->" + Password);
				logger.debug("dcryptedpwd value is--->" + dcryptedpwd);
				if (dcryptedpwd.equals(Password)) {
					logger.debug("dcryptedpwd match Password --> " + dcryptedpwd);
					VPUserMaster userMasterbean = null;
					userMasterbean = logindao.checklogin(enterUserName, "Correct", session.getId(), endurl);
					if (null != userMasterbean.getJspPage()
							&& userMasterbean.getJspPage().equalsIgnoreCase("ResetNewPassword")) {

						request.setAttribute("userName", userMasterbean.getUserName());
						request.setAttribute("activationCode", userMasterbean.getActivationCode());
						request.getRequestDispatcher("JSP/ResetNewPassword.jsp").forward(request, response);
					} else if (null != userMasterbean.getJspPage()
							&& userMasterbean.getJspPage().equalsIgnoreCase("Login")) {

						session = request.getSession(true);
						if (userMasterbean.getMsgCode().equalsIgnoreCase("MSG054"))
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG054);
						if (userMasterbean.getMsgCode().equalsIgnoreCase("MSG058"))
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG058);
						if (userMasterbean.getMsgCode().equalsIgnoreCase("MSG001"))
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG001);
						if (userMasterbean.getMsgCode().equalsIgnoreCase("MSG073"))
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG073);
						if (userMasterbean.getMsgCode().equalsIgnoreCase("MSG014"))
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
						if (userMasterbean.getMsgCode().equalsIgnoreCase("MSG079"))
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG079);
						request.getRequestDispatcher("login").forward(request, response);
					} else if (null != userMasterbean.getJspPage()
							&& userMasterbean.getJspPage().equalsIgnoreCase("MainServlet")) {

						logger.info("In Login Servlet for MainServlet");
						session = request.getSession(true);
						session.setAttribute("VendorCode", userMasterbean.getVendorCode());

						if (!ClsUtil.isNullOrEmpty(userMasterbean.getVendorName()))
							session.setAttribute("VendorName", userMasterbean.getVendorName());
						else
							session.setAttribute("VendorName", "Deloitte");

						session.setAttribute("VendorAdd", userMasterbean.getVendorAddress());
						session.setAttribute("VendorEmailID", userMasterbean.getUserEmailId());
						session.setAttribute("UserName", userMasterbean.getUserName());
						session.setAttribute("flagValue", "Y");
						session.setAttribute("WelcomeNote", ClsMessageHandler.MainWelcomeNote);
						session.setAttribute("PortalFlag", strPortalFlag);
						
						session.setAttribute("Privilege", userMasterbean.getPrivilege());
						String BrowserType = request.getHeader("User-Agent");
						if (null != BrowserType) {
							session.setAttribute("Browser", BrowserType);
						}
						getServletContext().setAttribute("LMPSubmitInvoice", ClsMessageHandler.LMPSubmitInvoice);
						getServletContext().setAttribute("LMPSubmitQuery", ClsMessageHandler.LMPSubmitQuery);
						getServletContext().setAttribute("LMPSearchInvoiceQuery",
								ClsMessageHandler.LMPSearchInvoiceQuery);
						getServletContext().setAttribute("LMPMyInvoice", ClsMessageHandler.LMPMyInvoice);
						getServletContext().setAttribute("LMPMyQuery", ClsMessageHandler.LMPMyQuery);

						getServletContext().setAttribute("LMPAddNewUser", ClsMessageHandler.LMPAddNewUser);
						getServletContext().setAttribute("LMPUserList", ClsMessageHandler.LMPUserList);
						getServletContext().setAttribute("LMPCompanyList", ClsMessageHandler.LMPCompanyList);
						getServletContext().setAttribute("LMPChangeUserPassword",
								ClsMessageHandler.LMPChangeUserPassword);
						getServletContext().setAttribute("LMPVendorList", ClsMessageHandler.LMPVendorList);
						getServletContext().setAttribute("TMPHome", ClsMessageHandler.TMPHome);
						getServletContext().setAttribute("TMPSettings", ClsMessageHandler.TMPSettings);
						getServletContext().setAttribute("TMPHistory", ClsMessageHandler.TMPHistory);
						getServletContext().setAttribute("TMPChangePassword", ClsMessageHandler.TMPChangePassword);
						getServletContext().setAttribute("TMPLogOut", ClsMessageHandler.TMPLogOut);

						if (!ClsUtil.isNullOrEmpty(userMasterbean.getVendorName()))
							request.setAttribute("VendorName", userMasterbean.getVendorName());
						else
							request.setAttribute("VendorName", "MBRDI");

						request.getRequestDispatcher("MainServlet").forward(request, response);
					}

				} else {
					VPUserMaster userMasterbean = null;
					userMasterbean = logindao.checklogin(enterUserName, "InCorrect", session.getId(), endurl);
					if (userMasterbean.getMsgCode().equalsIgnoreCase("MSG079"))
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG079);
					if (userMasterbean.getMsgCode().equalsIgnoreCase("MSG080"))
						request.setAttribute("MSGCODE",
								ClsMessageHandler.MSG080 + userMasterbean.getIncorrectLoginAttempt());
					request.getRequestDispatcher("login").forward(request, response);
				}
			} else {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
				request.getRequestDispatcher("login").forward(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
			loggerErr.error("Exception in LoginServlet Servlet:" + e.getMessage());

			session.setAttribute("errormsg", request.getAttribute("MSGCODE"));
			response.sendRedirect(request.getContextPath() + "/login");
		}

		request.setAttribute("SessionID", session.getId());
		request.setAttribute("Activity", "Login");

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting LoginServlet is :" + totaltime);

	}

	public static void compoundUnshuffle(List<?> list, int repetition, long seed) {
		helper(list, repetition, seed);
	}

	private static <E> void helper(List<E> list, int repetition, long seed) {

		try {
			logger.debug("helper 1 " + list);
			List<Integer> indices = new ArrayList<Integer>();
			int size = list.size();
			for (int i = 0; i < size; i++)
				indices.add(i);
			logger.debug(indices);
			compoundShuffle(indices, repetition, seed);
			List<E> copy = new ArrayList<E>(list);
			for (int i = 0; i < size; i++)
				list.set(indices.get(i), copy.get(i));
		} catch (Exception e) {
			logger.debug("Exception in helper in encryptServlet in VPconsume::");
			e.printStackTrace();

		}

	}

	public static void compoundShuffle(List<?> list, int repetition, long seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < repetition; i++)
			Collections.shuffle(list, rand);

	}

	public static Character[] toCharacterArray(String s) {

		try {
			if (s == null) {
				return null;
			}

			int len = s.length();
			Character[] array = new Character[len];
			for (int i = 0; i < len; i++) {
				array[i] = new Character(s.charAt(i));
			}

			return array;
		} catch (Exception e) {
			logger.debug("Exception in toCharacterArray in encryptServlet in VPconsume::");
			e.printStackTrace();
			return null;
		}

	}
}