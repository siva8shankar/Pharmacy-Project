/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ExportExcelServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class ExportExcelServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.VPReportMaster;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.dao.SearchStatusDAO;
import com.newgen.dao.SearchStatusDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsExportExcel;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class ExportExcelServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerXml = Logger.getLogger("xmlLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private String IBPSEndPointurl = "";
	private String cabinet = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
		IBPSEndPointurl = (String) config.getServletContext().getAttribute("IBPSEndPointURL");// IBPSEndPointurl
		logger.debug("IBPSEndPointURL is :" + IBPSEndPointurl);
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("cabinet is :" + cabinet);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ExportExcelServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.CalendarDateFormat);
		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		int result = 0;
		String type = "";
		String exporttype = request.getParameter("exporttype");
		logger.debug("Export type in export servlet - >" + exporttype);
		if (exporttype.equalsIgnoreCase("xls") || exporttype == "xls") {
			type = "xls";
			logger.debug("Exporting type - >" + type);

		} else {
			type = "xlsx";
			logger.debug("Exporting type - >" + type);
		}
		// till here

		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}

			session = request.getSession();
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName")
					+ " Exporting data to excel-------------------");

			request.setAttribute("MSGCODE", null);

			String vendorCode = (String) session.getAttribute("VendorCode");

			Date date = new Date();
			SimpleDateFormat outFmt = new SimpleDateFormat("yyyy_MM_dd(HH-mm-ss)");
			String strdatetime = outFmt.format(date);

			String archive = "";
			if (!ClsUtil.isNullOrEmpty(request.getParameter("ArchiveSearch"))) {
				archive = request.getParameter("ArchiveSearch");
			}
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenArchive"))) {
				archive = request.getParameter("hiddenArchive");
			}

			VPReportMaster reportBean = new VPReportMaster();

			String priviledge = (String) session.getAttribute("Privilege");

			logger.debug("HiddenSearch--->" + request.getParameter("hiddenSearch"));
			logger.debug("HiddenToDate--->" + request.getParameter("hiddenToDate"));
			logger.debug("hiddenFromDate--->" + request.getParameter("hiddenFromDate"));
			logger.debug("hiddenInvoiceNo--->" + request.getParameter("hiddenInvoiceNo"));

			if ((!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearch"))
					&& request.getParameter("hiddenSearch").equalsIgnoreCase("SearchInvoice"))) {

				logger.debug("Inside if ================================ *************");

				/*reportBean.setHeader(
						"e.invoiceno,e.transactionid,(CASE WHEN w.Status IN ('Pending for Approval','GR Exception','Payment Processing','Pending for Approval1','Pending for GR Exception','Invoice Processing','Pending Approval','Invoice Posting','Invoice Exception','Pending Approval with -John','Pending Approval with -Stuart','Pending Approval with -Mark','Pending Approval with -Henry','Duplicate Invoice','Invoice processed','GR Exception Resolved') OR w.Status IS NULL THEN 'In Progress' ELSE w.Status END) AS Status,e.invoiceamount,e.invoiceDate,e.InitEntryDate,e.Currency,e.InvoiceType,(CASE WHEN w.Status='Rejected to Vendor' THEN e.RejectedReason ELSE '' END)  AS Rejection_Status");
				reportBean.setExportHeader(
						"Document Number,Transaction ID,Document Status,Document Amount,Document Date,Initiation Date,Document Currency,Document Type,Rejected Reason");
*/
				reportBean.setHeader(
						"ItemIndex,PID,Plant,Quantity,CMPLX_TC_Sel_VendorOrders.Structure,Comment,convert(varchar(10),CONVERT(date,EDD,106),103) as 'EDD',CMPLX_TC_Sel_VendorOrders.Insertionorderid,EXT_TC.TCReqNo,convert(varchar(10),CONVERT(date,DeliveryDate,106),103) as 'DeliveryDate',WFINSTRUMENTTABLE.ActivityName,CASE WHEN (WFINSTRUMENTTABLE.Status not in ('Archived') OR WFINSTRUMENTTABLE.ActivityName not in('Exit') OR ( WFINSTRUMENTTABLE.Status IS NULL OR WFINSTRUMENTTABLE.Status='')) THEN 'In Progress' ELSE 'Completed' END AS 'Status'");
				reportBean.setExportHeader(
						"Item Index,PID,Plant,Quantity,Structure,Comment,EDDate,InsertionOrderID,TC Request No,Delivery Date, Activity Name, Status");

				reportBean.setFieldDelimiter("`");
				reportBean.setRowDelimiter("~");
				reportBean.setFooter("Deloitte P2P Process");

				logger.debug("reportBean Header---->" + reportBean.getHeader());
				logger.debug("reportBean getFieldDelimiter---->" + reportBean.getFieldDelimiter());
				logger.debug("reportBean getRowDelimiter---->" + reportBean.getRowDelimiter());
				logger.debug("reportBean getFooter---->" + reportBean.getFooter());

				request.setAttribute("hiddenSearch", "SearchInvoice");
				String InvoiceNumber = null;

				InvoiceNewDetails invoice = new InvoiceNewDetails();

				Date dateFrom = null;
				Date dateTo = null;

				try {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenFromDate"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("hiddenToDate"))) {
						dateFrom = sdf.parse(request.getParameter("hiddenFromDate"));
						dateTo = sdf.parse(request.getParameter("hiddenToDate"));
					}
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					loggerErr.error("Date Parsing Exception while Searching Invoice: " + e.getMessage());
					e.printStackTrace();

				}

				if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenInvoiceNo"))) {
					InvoiceNumber = request.getParameter("hiddenInvoiceNo").trim();
				}
				invoice.setInvoiceno(InvoiceNumber);
				invoice.setFromDate(dateFrom);
				invoice.setToDate(dateTo);
				invoice.setInvoiceCreatedBy(userName);
				invoice.setVendorno(vendorCode);

				logger.debug("In ExportExcelServlet before search----");

				// This Method is used to export Invoice Report.
				SearchStatusDAOI searchStatusDao = new SearchStatusDAO();
				StringBuffer exportData = searchStatusDao.exportInvoice(invoice, archive, reportBean, priviledge,
						IBPSEndPointurl, cabinet);

				loggerXml.debug("In ExportExcelServlet ExportData---->" + exportData.toString());

				try {
					OutputStream out = response.getOutputStream();

					if (type == "xls") {
						ClsExportExcel.exportExcel(exportData, reportBean.getExportHeader(), reportBean,
								session.getId(), getServletContext().getRealPath("temp"));
					} else {
						ClsExportExcel.exportExcelx(exportData, reportBean.getExportHeader(), reportBean,
								session.getId(), getServletContext().getRealPath("temp"));

					}

					response.setHeader("Content-Disposition",
							"attachment;filename = VendorPortal_Report_" + strdatetime + "." + type);
					response.setContentType("excel/" + "VendorPortal_Report_" + strdatetime + "." + type);

					logger.debug("In ExportExcelServlet GeneratedPath->" + getServletContext().getRealPath("temp")
							+ File.separator + "ExcelReport" + session.getId() + "." + type);

					FileInputStream in;
					if (type == "xls") {
						in = new FileInputStream(getServletContext().getRealPath("temp") + File.separator
								+ "ExcelReport" + session.getId() + "." + type);

					} else {
						in = new FileInputStream(getServletContext().getRealPath("temp") + File.separator
								+ "ExcelReport_XLSX" + session.getId() + "." + type);

					}
					try {
						int n = 0;
						byte b[] = new byte[1024];
						while ((n = in.read(b)) != -1) {
							out.write(b, 0, n);
						}
						out.flush();
						logger.debug("file writting.............");
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						if (in != null) {
							in.close();
						}
						if (out != null) {
							out.close();
						}
					}

					logger.debug("before deleting the file");
					File file = null;
					if (type == "xls") {
						file = new File(getServletContext().getRealPath("temp") + File.separator + "ExcelReport"
								+ session.getId() + "." + type);
					} else {
						file = new File(getServletContext().getRealPath("temp") + File.separator + "ExcelReport_XLSX"
								+ session.getId() + "." + type);
					}

					try {
						file.delete();
						logger.debug("file deleted successfully...");
					} catch (Exception exc) {
						exc.printStackTrace();
					}

				} catch (Exception ex) {
					loggerErr.error("Exception in exporting data to excel : " + ex.getMessage());
					ex.printStackTrace();
				}

			} else if ((!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearch"))
					&& request.getParameter("hiddenSearch").equalsIgnoreCase("SearchQuery"))) {

				logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName")
						+ " Searching Query");

				String invoiceNo = null;
				request.setAttribute("hiddenSearch", "SearchQuery");
				request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);
				VendorQueryMaster venMaster = new VendorQueryMaster();

				Date dateFrom = null;
				Date dateTo = null;
				String statusQuery = null;
				String queryNo = null;

				if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenQueryNo"))) {
					queryNo = request.getParameter("hiddenQueryNo").trim();
				}

				statusQuery = request.getParameter("hiddenStatus");

				try {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenFromDate"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("hiddenToDate"))) {
						dateFrom = sdf.parse(request.getParameter("hiddenFromDate"));
						dateTo = sdf.parse(request.getParameter("hiddenToDate"));
					}
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					loggerErr.error("Date Parsing Exception while Searching Query: " + e.getMessage());
					e.printStackTrace();

				}
				if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenInvoiceNo"))) {
					invoiceNo = request.getParameter("hiddenInvoiceNo").trim();
				}

				if (!ClsUtil.isNullOrEmpty(queryNo)) {
					venMaster.setQueryNo(queryNo);
				}
				venMaster.setInvoiceNo(invoiceNo);
				venMaster.setFromDate(dateFrom);
				venMaster.setToDate(dateTo);
				venMaster.setCreatedBy(userName);

				SearchStatusDAO searchStatusDao = new SearchStatusDAO();

				// This Method is used to export Query Report.
				StringBuffer exportData = searchStatusDao.exportQuery(venMaster, archive, statusQuery, reportBean,
						priviledge, vendorCode, endurl);

				response.setHeader("Content-Disposition",
						"attachment;filename = VendorPortal_Report_" + strdatetime + "." + type);

				OutputStream out = response.getOutputStream();
				response.setContentType("excel/" + "VendorPortal_Report_" + strdatetime + "." + type);

				if (type == "xls") {
					ClsExportExcel.exportExcel(exportData, reportBean.getHeader(), reportBean, session.getId(),
							getServletContext().getRealPath("temp"));
				} else {
					ClsExportExcel.exportExcelx(exportData, reportBean.getHeader(), reportBean, session.getId(),
							getServletContext().getRealPath("temp"));
				}
				FileInputStream in = new FileInputStream(
						getServletContext().getRealPath("temp") + "\\ExcelReport" + session.getId() + "." + type);

				try {
					int n = 0;
					byte b[] = new byte[1024];
					while ((n = in.read(b)) != -1) {
						out.write(b, 0, n);
					}
					out.flush();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (in != null) {
						in.close();
					}
					if (out != null) {
						out.close();
					}
				}

				File file = new File(
						getServletContext().getRealPath("temp") + "\\ExcelReport" + session.getId() + "." + type);
				try {
					file.delete();
				} catch (Exception exc) {
					exc.printStackTrace();
				}
			}
		} catch (Exception ex) {
			loggerErr.error("Exception in Export Excel Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in exporting data to excel is : " + totaltime);
	}
}
