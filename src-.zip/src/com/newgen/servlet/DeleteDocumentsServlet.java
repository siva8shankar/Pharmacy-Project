/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: DeleteDocumentsServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class DeleteDocumentsServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class DeleteDocumentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteDocumentsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = null;

		try {
			session = request.getSession();
			int result = 0;

			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}

			String DocumentPath = ClsMessageHandler.DocumentPath;
			String DocumentType = ClsMessageHandler.DocumentType;
			String DocumentSize = ClsMessageHandler.DocumentSize;
			if (!ClsUtil.isNullOrEmpty(request.getParameter("name"))) {
				String name = request.getParameter("name");
				String[] fileDetails = name.split(",");

				// Path of documents
				String path = DocumentPath + File.separator + "Documents";
				String filename = fileDetails[1];
				PrintWriter out = response.getWriter();
				response.setContentType("text/html");
				File file = new File(path);
				if (!filename.equalsIgnoreCase("R")) {
					if (file.isDirectory()) {
						File file1 = new File(path + File.separator + (filename).trim());
						if (file1.isFile()) {
							file1.delete();
							if (!ClsUtil.isNullOrEmpty(request.getSession(true).getAttribute("FilesAddedData"))) {
								String fileAddedData[] = ((String) request.getSession(true)
										.getAttribute("FilesAddedData")).split(";");
								String[] filesadded = fileAddedData[0].split(",");
								String Nfilesadded = null;
								for (int i = 0; i < filesadded.length; i++) {
									if (filename.equalsIgnoreCase(filesadded[i])) {

									} else {
										if (!ClsUtil.isNullOrEmpty(Nfilesadded)) {
											Nfilesadded = Nfilesadded + "," + filesadded[i];
										} else {
											Nfilesadded = filesadded[i];
										}
									}
								}
								if (null != Nfilesadded) {
									String NfileAddedData = Nfilesadded + ";" + path;
									request.getSession(true).setAttribute("FilesAddedData", NfileAddedData);
									out.print("Document is deleted.%" + NfileAddedData);
								} else {
									request.getSession(true).removeAttribute("FilesAddedData");
									out.print("Last document is deleted.% ");
									logger.debug("Last document is deleted.%");

								}
							}
						} else {
							logger.debug("File Not Found");
							out.print("File Not Found");
						}
					} else {
						logger.debug("Directory Not Found");
						out.print("Directory Not Found");

					}
				} else {
					if (file.isDirectory()) {
						String filesExistedname[] = file.list();
						for (int i = 0; i < filesExistedname.length; i++) {
							File file1 = new File(path + File.separator + filesExistedname[i]);
							file1.delete();
							file1 = null;
						}
						file.delete();
					}
					request.getSession(true).removeAttribute("FilesAddedData");
					request.setAttribute("DocumentTypes", ClsMessageHandler.DocumentType);
					request.setAttribute("DocumentSize", ClsMessageHandler.DocumentSize);
				}

			}
		} catch (Exception e) {
			loggerErr.error("Exception occured :" + e.getMessage());
			e.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}
	}
}