/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminCompanyListServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminCompanyListServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminCompanyListDAO;
import com.newgen.dao.AdminCompanyListDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class AdminCompanyListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminCompanyListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		HttpSession session = null;
		int result = 0;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug(" Company List , Session: " + session.getId() + "UserName:" + userName);

			GeneralClass generalClass = new GeneralClass();

			String linkType;
			String topNo;
			String lastNo;

			topNo = request.getParameter("hiddenTopNo");
			lastNo = request.getParameter("hiddenLastNo");
			linkType = request.getParameter("LinkType");
			generalClass.setLinkType(linkType);
			generalClass.setPaginationTopQryNo(topNo);
			generalClass.setPaginationLastQryNo(lastNo);
			generalClass.setBatchSize(ClsMessageHandler.BatchSizeCompanyList);
			generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);

			AdminCompanyListDAOI adminCompanyListDAO = new AdminCompanyListDAO();

			// This Method is used to fetch list of Companies.
			generalClass = adminCompanyListDAO.getCompanyList(generalClass, endurl);

			if (!ClsUtil.isNullOrEmpty(generalClass.getArrayCompanyList())
					&& generalClass.getArrayCompanyList().size() > 0) {
				request.setAttribute("CompanyList", generalClass.getArrayCompanyList());
				request.setAttribute("TopNo", generalClass.getPaginationTopQryNo());
				request.setAttribute("LastNo", generalClass.getPaginationLastQryNo());
				request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
				request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
				request.setAttribute("Administration", "Company List");
				request.getRequestDispatcher("JSP/AdminCompanyList.jsp").forward(request, response);
			}
			// No Company Found
			else {
				logger.debug("No Company Found");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG039);
				request.setAttribute("Administration", "Company List");
				request.getRequestDispatcher("JSP/AdminCompanyList.jsp").forward(request, response);
			}

		} catch (Exception ex) {
			loggerErr.error("Exception in Company List Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting Company List is " + totaltime);
	}
}
