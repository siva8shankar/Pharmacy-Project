/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: DownloadPDFServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.newgen.util.PdfCreator;

public class DownloadPDFServlet extends HttpServlet {
	/**
	 * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
	 * methods.
	 *
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("application/pdf");
		// response.setContentType("text/plain");
		System.out.println("Inside downloadpdf-------------->");
		String sPID = request.getParameter("pk");
		String sTempType = request.getParameter("TT");
		String mode = request.getParameter("mode");
		File file = new PdfCreator().GeneratePDF(sPID, sTempType);
		OutputStream out = response.getOutputStream();
		InputStream is = new FileInputStream(file);
		OutputStream fout = null;
		byte byteArr[] = new byte[8192];
		int input;
		try {
			if (mode.equalsIgnoreCase("v")) {
				System.out.println("========== PDF Mode inside v  ==========");
				// Viewing
				while ((input = is.read()) != -1) {// byteArr,0,byteArr.length
					out.write(input);
				}
			} else if (mode.equalsIgnoreCase("u")) {
				File pdfnew = new File(System.getProperty("user.dir") + File.separator + "POInvoices" + File.separator
						+ sPID + ".PDF");
				fout = new FileOutputStream(pdfnew);

				System.out.println("========== PDF Mode inside u  ==========");
				// Writing
				while ((input = is.read(byteArr, 0, byteArr.length)) != -1) {// byteArr,0,byteArr.length
					fout.write(byteArr, 0, input);
					fout.flush();
					System.out.println("PDF been created on server-  ------------#####");
				}
			} else {
				while ((input = is.read()) != -1) {// byteArr,0,byteArr.length
					out.write(input);
				}
			}
		} finally {
			out.close();
			is.close();
			file.delete();
			if (fout != null)
				fout.close();
		}
	}
	// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on
	// the + sign on the left to edit the code.">

	/**
	 * Handles the HTTP <code>GET</code> method.
	 *
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Handles the HTTP <code>POST</code> method.
	 *
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Returns a short description of the servlet.
	 *
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}// </editor-fold>
}
