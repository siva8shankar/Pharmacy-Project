/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminUserListServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminUserListServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminUserListDAO;
import com.newgen.dao.AdminUserListDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class AdminUserListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminUserListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		AdminUserListDAOI adminUserListDAO = new AdminUserListDAO();

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));
		int result = 0;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(userName)) {

				logger.debug("This is valid not access to this page. Please come via proper login--");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);
			GeneralClass generalClass = new GeneralClass();

			String linkType;
			String topNo;
			String lastNo;

			topNo = request.getParameter("hiddenTopNo");
			lastNo = request.getParameter("hiddenLastNo");
			linkType = request.getParameter("LinkType");
			String searchUser = "";
			String searchType = "";

			session = request.getSession();
			String loggedInUser = userName;

			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearchButton"))
					&& request.getParameter("hiddenSearchButton").equalsIgnoreCase("SearchUser")) {
				searchUser = request.getParameter("userName");
				searchType = "POPUP";
			}
			generalClass.setLinkType(linkType);
			generalClass.setPaginationTopQryNo(topNo);
			generalClass.setPaginationLastQryNo(lastNo);
			generalClass.setBatchSize(ClsMessageHandler.BatchSizeUserList);
			generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);

			logger.debug("UserType ----- " + request.getParameter("UserType"));
			if (!ClsUtil.isNullOrEmpty(request.getParameter("UserType"))) {
				// This Method is used to get UserList With Details.
				generalClass = adminUserListDAO.getUserListWithDetails(request.getParameter("UserType"), generalClass,
						searchUser, loggedInUser, searchType, endurl);
			} else {
				// This Method is used to get UserList With Details.
				generalClass = adminUserListDAO.getUserListWithDetails("RegUser", generalClass, searchUser,
						loggedInUser, searchType, endurl);
			}

			request.setAttribute("hiddenUserType", request.getParameter("UserType"));
			request.setAttribute("hiddenUsrName", request.getParameter("userName"));

			// When Registered User List Found
			if (!ClsUtil.isNullOrEmpty(generalClass.getArrayRegisteredUser())
					&& generalClass.getArrayRegisteredUser().size() > 0) {

				logger.debug("Registered User List Found");
				request.setAttribute("RegisteredUserList", generalClass.getArrayRegisteredUser());
				request.setAttribute("TopNo", generalClass.getPaginationTopQryNo());
				request.setAttribute("LastNo", generalClass.getPaginationLastQryNo());
				request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
				request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
				request.setAttribute("Administration", "Registered User List With Details");
				request.getRequestDispatcher("JSP/AdminUserList.jsp").forward(request, response);
			}

			// When Applied User List Found
			else if (!ClsUtil.isNullOrEmpty(generalClass.getArrayAppliedUser())
					&& generalClass.getArrayAppliedUser().size() > 0) {
				logger.debug("Applied User List Found");

				request.setAttribute("AppliedUserList", generalClass.getArrayAppliedUser());
				request.setAttribute("TopNo", generalClass.getPaginationTopQryNo());
				request.setAttribute("LastNo", generalClass.getPaginationLastQryNo());
				request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
				request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
				request.setAttribute("Administration", "Applied User List With Details");
				request.getRequestDispatcher("JSP/AdminUserList.jsp").forward(request, response);

			}

			// No User Found
			else {
				logger.debug("No User List Found");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG035);
				request.setAttribute("Administration", "User List With Details");
				request.getRequestDispatcher("JSP/AdminUserList.jsp").forward(request, response);
			}

		} catch (Exception e) {
			loggerErr.error("Exception in Admin User List Servlet : " + e.getMessage());
			e.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting User List is: " + totaltime);
	}

}
