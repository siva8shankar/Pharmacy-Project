/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: MyInvoiceServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class MyInvoiceServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY) 
* * 09/01/2018						ksivashankar			Bug 1023790 - Vendor Portal - Mismatch in the data - dashboard shows no data                                      
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.dao.MyInvoiceDAO;
import com.newgen.dao.MyInvoiceDAOI;
import com.newgen.dao.TCMyInvoiceDAO;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class UpdateTCRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private String IBPSEndPointURL = "";
	private String cabinet = "";

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);

		IBPSEndPointURL = (String) config.getServletContext().getAttribute("IBPSEndPointURL");
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");

	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateTCRequestServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.debug("Inside doPost of MyInvoiceServlet");

		long starttime = System.currentTimeMillis();
		HttpSession session = null;

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));
		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--" + sessionId);
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.--" + sessionId);
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (!ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
				request.setAttribute("MSGCODE", request.getAttribute("MSGCODE"));
			}

			logger.debug("Getting My Invoices. Session: " + session.getId() + "UserName:" + userName);

			GeneralClass generalClass = new GeneralClass();
			String linkType;
			String topQueryNo;
			String lastQueryNo;

			topQueryNo = request.getParameter("hiddenTopQueryNo3");
			lastQueryNo = request.getParameter("hiddenLastQueryNo3");
			linkType = request.getParameter("LinkType3");
			generalClass.setLinkType(linkType);
			generalClass.setPaginationTopQryNo(topQueryNo);
			generalClass.setPaginationLastQryNo(lastQueryNo);
			generalClass.setBatchSize(ClsMessageHandler.BatchSizeMyInvoice);

			// InvoiceDetails invoice = new InvoiceDetails();
			InvoiceNewDetails invoice = new InvoiceNewDetails();
			invoice.setInvoiceCreatedBy(userName);
			String VendorCode = (String) session.getAttribute("VendorCode");
			
			String strPortalFlag1 = (String) session.getAttribute("PortalFlag");
			if(!strPortalFlag1.equalsIgnoreCase("") && strPortalFlag1 != null){
				logger.debug("Inside MainServlet Portal Flag ---> "+strPortalFlag1);
				if(strPortalFlag1.equalsIgnoreCase("VendorPortal")){
			
			MyInvoiceDAOI myinvoicedao = new MyInvoiceDAO();
			// to get list of my invoices.
			generalClass = myinvoicedao.searchInvoice(VendorCode, invoice, generalClass, sessionId, endurl,
					IBPSEndPointURL, cabinet);
//			if (generalClass.getSessionresult() > 0) {
				if (generalClass.getArrayInvoiceMaster() != null && generalClass.getArrayInvoiceMaster().size() > 0) {
					request.setAttribute("InvoiceData", generalClass.getArrayInvoiceMaster());
					request.setAttribute("status", generalClass.getArrStatus());
					request.setAttribute("DocumentIDs", generalClass.getArrayDocumentIDs());
					request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
					request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
					request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
					request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
					request.setAttribute("VendorInvoice", "My Invoice");
					request.getRequestDispatcher("/JSP/MyInvoice.jsp").forward(request, response);
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG012);
					request.setAttribute("VendorInvoice", "My Invoice");
					request.getRequestDispatcher("/JSP/MyInvoice.jsp").forward(request, response);
				}
				}
				else{
					
					TCMyInvoiceDAO tcmyinvoicedao = new TCMyInvoiceDAO();
					// to get list of my invoices.
					generalClass = tcmyinvoicedao.searchTCUpdateInvoice(VendorCode, invoice, generalClass, sessionId, endurl,
							IBPSEndPointURL, cabinet);
//					if (generalClass.getSessionresult() > 0) {
						if (generalClass.getArrayTCInvoiceDetails() != null && generalClass.getArrayTCInvoiceDetails().size() > 0) {
							System.out.println("�nside true");
							request.setAttribute("TCInvoiceData", generalClass.getArrayTCInvoiceDetails());
							request.setAttribute("status", generalClass.getArrStatus());
							request.setAttribute("DocumentIDs", generalClass.getArrayDocumentIDs());
							request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
							request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
							request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
							request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
							request.setAttribute("VendorInvoice", "My Invoice");
							request.getRequestDispatcher("/JSP/TCUpdateRequests.jsp").forward(request, response);
						} else {
							System.out.println("�nside false");
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG012);
							request.setAttribute("VendorInvoice", "My Invoice");
							request.getRequestDispatcher("/JSP/TCUpdateRequests.jsp").forward(request, response);
						}
					
				}
			}
//			} else {
//				response.sendRedirect(request.getContextPath() + "/login");
//				return;
//			}
		} catch (Exception e) {
			loggerErr.error("Exception in My Invoice Servlet:" + e.getMessage());
			e.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting My Invoice Servlet is :" + totaltime);
	}

}
