/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ReportServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class ReportServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.newgen.bean.CompanyMaster;
import com.newgen.bean.MyBean;
import com.newgen.bean.VPReportMaster;
import com.newgen.dao.CompanyDataDAO;
import com.newgen.dao.CompanyDataDAOI;
import com.newgen.dao.LoadMyProperties;
import com.newgen.dao.ReportMasterDAO;
import com.newgen.dao.ReportMasterDAOI;
import com.newgen.util.ClsUtil;
import com.newgen.util.VendorPortalXMLGeneration;

public class ReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HashMap<String, String> proMap = null;
	private static Logger logger = Logger.getLogger("consoleLogger");

	private String endurl = "";
	InputStream in = null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ReportServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
		long starttime = System.currentTimeMillis();
		try {

			ReportMasterDAOI reportDao = new ReportMasterDAO();
			HashMap<String, VPReportMaster> reportHashMap = null;
			MyBean myBean = new MyBean();

			// Get report master data
			reportHashMap = reportDao.getReportMasterData(endurl);
			getServletContext().setAttribute("ReportData", reportHashMap);

			CompanyMaster CompanyMaster = new CompanyMaster();
			LinkedHashMap<String, ArrayList<String>> companyMap = null;
			CompanyDataDAOI CompanyDataDAO = new CompanyDataDAO();
			// Getting Company data i.e Company Code, Company Name & Company
			// Address
			companyMap = (LinkedHashMap<String, ArrayList<String>>) CompanyDataDAO.GetCompanyData("shivam", endurl);
			getServletContext().setAttribute("companyMap", companyMap);
			logger.debug("Fetch Company Data Sucessfully.");
			CompanyMaster.setCompanyDataMap(companyMap);

			if (!ClsUtil.isNullOrEmpty(CompanyMaster)) {
				JSONObject jObj = new JSONObject();
				jObj.put("companyData", CompanyMaster.getCompanyDataMap());
				getServletContext().setAttribute("jsonObject", jObj);
			}
			LoadMyProperties loadProperties = new LoadMyProperties();
			proMap = loadProperties.getMyPropertiesFile(myBean);

			logger.debug("footerLine" + proMap.get("footerLine"));
			getServletContext().setAttribute("proMap", proMap);

			VendorPortalXMLGeneration xmlGeneration = new VendorPortalXMLGeneration();

			HashMap<String, String> mapVendorPortalXML = xmlGeneration
					.loadXMLData(getServletContext().getRealPath("VendorPortal.xml"));

			getServletContext().setAttribute("VendorPortalXMLData", mapVendorPortalXML);

			// xmlGeneration.generateXMLJSP(getServletContext().getRealPath("VendorPortal.xml"),getServletContext().getRealPath("JSP/Configuration.jsp"));

		} catch (Exception e) {
			logger.error("Exception in Report Servlet : " + e.getMessage());
			e.printStackTrace();

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;

		logger.debug("Total Time Taken in Report Servlet is : " + totaltime);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setAttribute("proertyMap", proMap);

	}
}
