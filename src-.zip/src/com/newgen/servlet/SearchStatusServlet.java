/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SearchStatusServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class SearchStatusServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.VendorQueryDetails;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.dao.MyQueriesDAO;
import com.newgen.dao.MyQueriesDAOI;
import com.newgen.dao.SearchStatusDAO;
import com.newgen.dao.SearchStatusDAOI;
import com.newgen.dao.SubmitQueryDAO;
import com.newgen.dao.SubmitQueryDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class SearchStatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private String Cabinet = "";

	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		Cabinet = (String) config.getServletContext().getAttribute("Cabinet");
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchStatusServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		int result = 0;

		try {
			session = request.getSession(false);
			if (session == null) {
				logger.debug("Kindly login");
				response.sendRedirect(request.getContextPath() + "/login");
				return;

			}
			if (session != null) {
				if (session.getAttribute("flagValue").equals("Y")) {
					SearchStatusDAOI searchStatusDao = new SearchStatusDAO();
					request.setAttribute("SessionID", request.getSession().getId());
					request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

					// try {
					SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.CalendarDateFormat);
					session = request.getSession();
					String userName = (String) session.getAttribute("UserName");
					String sessionId = session.getId();

					// used to check session
					result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
					logger.debug("result of checkValidSession method of adminUserDao is ::" + result);

					if (result != 1) {
						response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
						return;
					}
					if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
						logger.debug(
								"This is valid not access to this page. Please come via proper login--" + sessionId);
						response.sendRedirect(request.getContextPath() + "/login");
						return;
					}
					if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
						logger.debug("Application has already been opened in other tab.--" + sessionId);
						response.sendRedirect(request.getContextPath() + "/login");
						return;
					}

					GeneralClass generalClass = new GeneralClass();
					String priviledge = (String) session.getAttribute("Privilege");
					logger.debug("SearchStatusServlet doPost method priviledge*******" + priviledge);
					String VendorCode = (String) session.getAttribute("VendorCode");
					generalClass.setPriviledge(priviledge);
					generalClass.setVendorCode(VendorCode);
					String queryNo = null;
					String linkType;
					String topQueryNo;
					String lastQueryNo;
					if (!ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
						request.setAttribute("MSGCODE", request.getAttribute("MSGCODE"));
					}

					String archive = "";
					if (!ClsUtil.isNullOrEmpty(request.getParameter("ArchiveSearch"))) {
						archive = request.getParameter("ArchiveSearch");
					}
					if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenArchive"))) {
						archive = request.getParameter("hiddenArchive");
					}
					if ((!ClsUtil.isNullOrEmpty(request.getParameter("SearchType"))
							&& request.getParameter("SearchType").equalsIgnoreCase("SearchInvoice"))
							|| (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearch"))
									&& request.getParameter("hiddenSearch").equalsIgnoreCase("SearchInvoice"))) {

						request.setAttribute("hiddenSearch", "SearchInvoice");
						String InvoiceNumber = null;

						InvoiceNewDetails invoice = new InvoiceNewDetails();

						Date dateFrom = null;
						Date dateTo = null;

						try {
							if (!ClsUtil.isNullOrEmpty(request.getParameter("DateFrom"))
									&& !ClsUtil.isNullOrEmpty(request.getParameter("DateTo"))) {
								dateFrom = sdf.parse(request.getParameter("DateFrom"));
								dateTo = sdf.parse(request.getParameter("DateTo"));
							}
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							loggerErr.error("Date Parsing Exception while Searching Invoice:" + e.getMessage());
							e.printStackTrace();
						}

						topQueryNo = request.getParameter("hiddenTopQueryNo");
						lastQueryNo = request.getParameter("hiddenLastQueryNo");
						linkType = request.getParameter("LinkType");
						generalClass.setLinkType(linkType);
						generalClass.setPaginationTopQryNo(topQueryNo);
						generalClass.setPaginationLastQryNo(lastQueryNo);
						// generalClass.setBatchSize(ClsMessageHandler.BatchSizeInvoiceSearch);
						generalClass.setBatchSize(ClsMessageHandler.BatchSizeMyInvoice);
						generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);
						if (!ClsUtil.isNullOrEmpty(request.getParameter("InvoiceNumber"))) {
							InvoiceNumber = request.getParameter("InvoiceNumber").trim();
						}
						logger.debug("InvoiceNumber is ~~~~~~~~~~~~~ :" + InvoiceNumber);
						invoice.setInvoiceno(InvoiceNumber);
						invoice.setFromDate(dateFrom);
						invoice.setToDate(dateTo);
						invoice.setInvoiceCreatedBy(userName);
						// used to search invoices
						generalClass = searchStatusDao.searchInvoice(generalClass, invoice, archive, endurl, Cabinet);
						request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);

						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("invoiceRadio")) {
							request.setAttribute("hiddenSearchCriteria", "invoiceRadio");

						}
						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("dateRadio")) {
							request.setAttribute("hiddenSearchCriteria", "dateRadio");
						}
						if (!ClsUtil.isNullOrEmpty(generalClass.getMap()) && generalClass.getMap().size() > 0) {

							request.setAttribute("InvoiceData", generalClass.getMap());
							request.setAttribute("status", generalClass.getArrStatus());
							request.setAttribute("DocumentIDs", generalClass.getArrayDocumentIDs());
							request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
							request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
							request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
							request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
							request.setAttribute("hiddenArchive", archive);
							request.setAttribute("ToDate", request.getParameter("DateTo"));
							request.setAttribute("FromDate", request.getParameter("DateFrom"));
							request.setAttribute("InvNo", InvoiceNumber);
							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/VendorSearch.jsp").forward(request, response);
						} else {
							if (ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
								request.setAttribute("MSGCODE", ClsMessageHandler.MSG012);
							}
							request.setAttribute("VendorSearch", "Search Invoice");
							request.getRequestDispatcher("JSP/VendorSearch.jsp").forward(request, response);
						}
					} else if ((!ClsUtil.isNullOrEmpty(request.getParameter("SearchType"))
							&& request.getParameter("SearchType").equalsIgnoreCase("SearchQuery"))
							|| (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearch"))
									&& request.getParameter("hiddenSearch").equalsIgnoreCase("SearchQuery"))
									&& ((!ClsUtil.isNullOrEmpty(request.getParameter("checkButton"))
											&& request.getParameter("checkButton").equals("SearchButton"))
											|| (!ClsUtil.isNullOrEmpty(request.getParameter("LinkType"))
													&& (request.getParameter("LinkType").equals("next")
															|| request.getParameter("LinkType").equals("prev"))))) {

						String invoiceNo = null;
						request.setAttribute("hiddenSearch", "SearchQuery");
						request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);
						VendorQueryMaster venMaster = new VendorQueryMaster();

						Date dateFrom = null;
						Date dateTo = null;
						String statusQuery = null;

						if (request.getParameter("LinkType").equals("next")
								|| request.getParameter("LinkType").equals("prev")) {
							statusQuery = request.getParameter("hiddenStatus");
							logger.debug("LinkType is ~~~~~~~~~~~~~ :" + statusQuery);
						} else {
							statusQuery = request.getParameter("statusSelect");
							logger.debug("LinkType else is ~~~~~~~~~~~~~ :" + statusQuery);
						}
						try {
							if (!ClsUtil.isNullOrEmpty(request.getParameter("DateFrom"))
									&& !ClsUtil.isNullOrEmpty(request.getParameter("DateTo"))) {
								dateFrom = sdf.parse(request.getParameter("DateFrom"));
								dateTo = sdf.parse(request.getParameter("DateTo"));
							}
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							loggerErr.error("Date Parsing Exception while Searching Query::" + e.getMessage());
							e.printStackTrace();

						}

						if (!ClsUtil.isNullOrEmpty(request.getParameter("InvoiceNumber"))) {
							invoiceNo = request.getParameter("InvoiceNumber").trim();
						}
						if (!ClsUtil.isNullOrEmpty(request.getParameter("QueryNumber"))) {
							queryNo = request.getParameter("QueryNumber").trim();
						}

						topQueryNo = request.getParameter("hiddenTopQueryNo");
						lastQueryNo = request.getParameter("hiddenLastQueryNo");
						linkType = request.getParameter("LinkType");

						if (!ClsUtil.isNullOrEmpty(queryNo)) {
							venMaster.setQueryNo(queryNo);
						}
						venMaster.setInvoiceNo(invoiceNo);
						venMaster.setFromDate(dateFrom);
						venMaster.setToDate(dateTo);
						venMaster.setCreatedBy(userName);
						generalClass.setLinkType(linkType);
						generalClass.setPaginationTopQryNo(topQueryNo);
						generalClass.setPaginationLastQryNo(lastQueryNo);
						// generalClass.setBatchSize(ClsMessageHandler.BatchSizeQuerySearch);
						generalClass.setBatchSize(ClsMessageHandler.BatchSizeMyQuery);
						generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);
						logger.debug("statusQuery is ~~~~~~~~~~~~~ :" + statusQuery);
						// used to search queries
						generalClass = searchStatusDao.searchQuery(venMaster, generalClass, archive, statusQuery,
								endurl);

						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("invoiceRadio")) {
							request.setAttribute("hiddenSearchCriteria", "invoiceRadio");
						}
						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("queryRadio")) {
							request.setAttribute("hiddenSearchCriteria", "queryRadio");
						}
						if (!ClsUtil.isNullOrEmpty(request.getParameter("searchCriteria"))
								&& request.getParameter("searchCriteria").equals("dateRadio")) {
							request.setAttribute("hiddenSearchCriteria", "dateRadio");
						}

						if (!ClsUtil.isNullOrEmpty(generalClass.getArrayQueryMaster())
								&& generalClass.getArrayQueryMaster().size() > 0) {
							request.setAttribute("hiddenStatus", statusQuery);
							request.setAttribute("QueryData", generalClass.getArrayQueryMaster());
							request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
							request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
							request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
							request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
							request.setAttribute("hiddenArchive", archive);

							request.setAttribute("ToDate", request.getParameter("DateTo"));
							request.setAttribute("FromDate", request.getParameter("DateFrom"));
							request.setAttribute("InvNo", invoiceNo);
							request.setAttribute("QryNo", queryNo);
							request.setAttribute("VendorSearch", "Search Query");
							request.getRequestDispatcher("JSP/VendorSearch.jsp").forward(request, response);
						} else {
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG010);
							request.setAttribute("VendorSearch", "Search Query");
							request.getRequestDispatcher("JSP/VendorSearch.jsp").forward(request, response);
						}
					} else if ((!ClsUtil.isNullOrEmpty(request.getParameter("hiddenHyperlink"))
							&& request.getParameter("hiddenHyperlink").equals("hyperlink"))
							|| (!ClsUtil.isNullOrEmpty(request.getParameter("Button1"))
									&& request.getParameter("Button1").equals("Reply"))) {

						boolean status;
						VendorQueryDetails venDetails = new VendorQueryDetails();
						String invoiceNo;
						String poNo;
						GeneralClass genQueryDetails = null;
						MyQueriesDAOI myqueriesdao = new MyQueriesDAO();

						queryNo = request.getParameter("hiddenQueryNo");
						invoiceNo = request.getParameter("hiddenInvoiceNo");
						poNo = request.getParameter("hiddenPONo");
						venDetails.setQueryNo(queryNo);
						venDetails.setCreatedBy(userName);
						venDetails.setUserPrivilege(priviledge);

						if (!ClsUtil.isNullOrEmpty(request.getParameter("Button1"))
								&& request.getParameter("Button1").equals("Reply")) {

							if (!ClsUtil.isNullOrEmpty(request.getParameter("status"))
									&& request.getParameter("status").equals("check")) {
								status = true;
							} else {
								status = false;
							}
							venDetails.setDescription(request.getParameter("QueryReply"));
							SubmitQueryDAOI vendorQueryDao = new SubmitQueryDAO();
							// to get query status
							result = searchStatusDao.getQueryStatus(queryNo, endurl);
							if (result == 0) {
								// to submit a query
								generalClass = vendorQueryDao.submitQuery(VendorCode, venDetails, invoiceNo, status,
										null, sessionId, endurl);
							} else {
								request.setAttribute("MSGCODE", ClsMessageHandler.MSG022);
							}
							// to get Query Details
							// String queryStatusLockResponse =
							// myqueriesdao.queryLockMethod(priviledge,venDetails,
							// archive, sessionId,endurl);
							// logger.debug("queryStatusLockResponse ==
							// "+queryStatusLockResponse);
							genQueryDetails = searchStatusDao.searchQueryDetails(priviledge, venDetails, archive,
									sessionId, endurl);
							String queryStatusUnLockResponse = myqueriesdao.queryUnLockMethod(priviledge, venDetails,
									archive, sessionId, endurl);
							logger.debug("queryStatusUnLockResponse == " + queryStatusUnLockResponse);
							request.setAttribute("history", -1);
						} else {
							// to get Query Details
							String queryStatusLockResponse = myqueriesdao.queryLockMethod(priviledge, venDetails,
									archive, sessionId, endurl);
							logger.debug("queryStatusLockResponse == " + queryStatusLockResponse);
							genQueryDetails = searchStatusDao.searchQueryDetails(priviledge, venDetails, archive,
									sessionId, endurl);
						}
						if (genQueryDetails.getSessionresult() == 0) {
							response.sendRedirect(request.getContextPath() + "/login");
							return;
						}
						// to get query status
						result = searchStatusDao.getQueryStatus(queryNo, endurl);
						if (result != 0) {
							request.setAttribute("checkStatus", "DisableReply");
						}

						request.setAttribute("invNo", invoiceNo);
						request.setAttribute("poNo", poNo);
						request.setAttribute("qryNo", queryNo);
						request.setAttribute("ArchiveDB", archive);
						if (generalClass.getResultCode() == 8) {
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG091);
							request.setAttribute("VendorSearch", "Query Details");
							request.getRequestDispatcher("JSP/SearchQueryDetails.jsp").forward(request, response);
						} else if (generalClass.getResultCode() > 0) {
							request.setAttribute("QueryDataDetails", genQueryDetails.getArrayQueryDetails());
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG005);
							request.setAttribute("VendorSearch", "Query Details");
							request.getRequestDispatcher("JSP/SearchQueryDetails.jsp").forward(request, response);
						} else if (generalClass.getResultCode() == 0) {
							request.setAttribute("QueryDataDetails", genQueryDetails.getArrayQueryDetails());
							request.setAttribute("VendorSearch", "Query Details");
							request.getRequestDispatcher("JSP/SearchQueryDetails.jsp").forward(request, response);
						} else {
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG006);
							request.setAttribute("VendorSearch", "Query Details");
							request.getRequestDispatcher("JSP/SearchQueryDetails.jsp").forward(request, response);
						}

					} else {
						request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);
						request.getRequestDispatcher("JSP/VendorSearch.jsp").forward(request, response);
					}
				} else {
					logger.debug("Kindly login from first page");
					response.sendRedirect(request.getContextPath() + "/login");

					// request.getRequestDispatcher("JSP/login.jsp").include(request,
					// response);
					return;
				}
			}
		} catch (Exception e) {
			loggerErr.error("Exception in Search Status Servlet:" + e.getMessage());
			logger.debug("Exception in Search Status Servlet:" + e.getMessage());
			e.printStackTrace();

			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Searching is :" + totaltime);
	}

}
