/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ExportPdfServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class ExportPdfServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
* 04/10/2017                        ksivashankar       				Bug 1015856 - Vendor Portal - Data is empty while Exporting excel or pdf in reports
* * 09/01/2018						ksivashankar			Bug 1023787 - Vendor Portal - value is not populated in the pdf and allignment issue
************************************************************************************************/

package com.newgen.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.VPReportMaster;
import com.newgen.bean.VendorQueryMaster;
import com.newgen.dao.SearchStatusDAO;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsExportPdf;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class ExportPdfServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private String endurl = "";
	private String IBPSEndPointurl = "";
	private String cabinet = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
		IBPSEndPointurl = (String) config.getServletContext().getAttribute("IBPSEndPointURL");
		logger.debug("IBPSEndPointURL is :" + IBPSEndPointurl);
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("cabinet is :" + cabinet);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ExportPdfServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.CalendarDateFormat);
		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		SearchStatusDAO searchStatusDao = new SearchStatusDAO();
		int result = 0;
		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Exporting data to Pdf. Session: " + session.getId() + "UserName:" + userName);

			request.setAttribute("MSGCODE", null);

			String vendorCode = (String) session.getAttribute("VendorCode");

			String archive = "";
			if (!ClsUtil.isNullOrEmpty(request.getParameter("ArchiveSearch"))) {
				archive = request.getParameter("ArchiveSearch");

			}
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenArchive"))) {
				archive = request.getParameter("hiddenArchive");

			}

			Date date = new Date();
			SimpleDateFormat outFmt = new SimpleDateFormat("yyyy_MM_dd(HH-mm-ss)");
			String strdatetime = outFmt.format(date);
			VPReportMaster reportBean = new VPReportMaster();

			String priviledge = (String) session.getAttribute("Privilege");

			logger.debug("HiddenSearch--->" + request.getParameter("hiddenSearch"));
			logger.debug("HiddenToDate--->" + request.getParameter("hiddenToDate"));
			logger.debug("hiddenFromDate--->" + request.getParameter("hiddenFromDate"));
			logger.debug("hiddenInvoiceNo--->" + request.getParameter("hiddenInvoiceNo"));

			if ((!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearch"))
					&& request.getParameter("hiddenSearch").equalsIgnoreCase("SearchInvoice"))) {
				// Bug 1015856 - Vendor Portal - Data is empty while Exporting
				// excel or pdf in reports
				/*reportBean.setHeader(
						"e.invoiceno,e.transactionid,(CASE WHEN w.Status IN ('Pending for Approval','GR Exception','Payment Processing','Pending for Approval1','Pending for GR Exception','Invoice Processing','Pending Approval','Invoice Posting','Invoice Exception','Pending Approval with -John','Pending Approval with -Stuart','Pending Approval with -Mark','Pending Approval with -Henry','Duplicate Invoice','Invoice processed','GR Exception Resolved') OR w.Status IS NULL THEN 'In Progress' ELSE w.Status END) AS Status,e.invoiceamount,e.invoiceDate,e.InitEntryDate,e.Currency,e.InvoiceType,(CASE WHEN w.Status='Rejected to Vendor' THEN e.RejectedReason ELSE '' END)  AS Rejection_Status");
				reportBean.setExportHeader(
						"Document Number,Transaction ID,Document Status,Document Amount,Document Date,Initiation Date,Document Currency,Document Type,Rejected Reason");
*/
				reportBean.setHeader(
						"ItemIndex,PID,Plant,Quantity,CMPLX_TC_Sel_VendorOrders.Structure,Comment,convert(varchar(10),CONVERT(date,EDD,106),103) as 'EDD',CMPLX_TC_Sel_VendorOrders.Insertionorderid,EXT_TC.TCReqNo,convert(varchar(10),CONVERT(date,DeliveryDate,106),103) as 'DeliveryDate',WFINSTRUMENTTABLE.ActivityName,CASE WHEN (WFINSTRUMENTTABLE.Status not in ('Archived') OR WFINSTRUMENTTABLE.ActivityName not in('Exit') OR ( WFINSTRUMENTTABLE.Status IS NULL OR WFINSTRUMENTTABLE.Status='')) THEN 'In Progress' ELSE 'Completed' END AS 'Status'");
				reportBean.setExportHeader(
						"Item Index,PID,Plant,Quantity,Structure,Comment,EDDate,InsertionOrderID,TC Request No,Delivery Date, Activity Name, Status");

				reportBean.setFieldDelimiter("`");
				reportBean.setRowDelimiter("~");
				reportBean.setFooter("Deloitte - SouthAfrica");

				logger.debug("reportBean Header---->" + reportBean.getHeader());
				logger.debug("reportBean getFieldDelimiter---->" + reportBean.getFieldDelimiter());
				logger.debug("reportBean getRowDelimiter---->" + reportBean.getRowDelimiter());
				logger.debug("reportBean getFooter---->" + reportBean.getFooter());

				request.setAttribute("hiddenSearch", "SearchInvoice");
				String InvoiceNumber = null;

				InvoiceNewDetails invoice = new InvoiceNewDetails();

				Date dateFrom = null;
				Date dateTo = null;

				try {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenFromDate"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("hiddenToDate"))) {

						dateFrom = sdf.parse(request.getParameter("hiddenFromDate"));
						dateTo = sdf.parse(request.getParameter("hiddenToDate"));
					}

				} catch (ParseException e) {
					// TODO Auto-generated catch block
					loggerErr.error("Date Parsing Exception while ExportPdfServlet:" + e.getMessage());
					e.printStackTrace();
				}

				if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenInvoiceNo"))) {

					InvoiceNumber = request.getParameter("hiddenInvoiceNo").trim();
				}

				invoice.setFromDate(dateFrom);
				invoice.setToDate(dateTo);
				invoice.setInvoiceno(InvoiceNumber);
				invoice.setInvoiceCreatedBy(userName);
				invoice.setVendorno(vendorCode);

				// to export invoice report
				StringBuffer exportData = searchStatusDao.exportInvoice(invoice, archive, reportBean, priviledge,
						IBPSEndPointurl, cabinet);
				try {
					response.setHeader("Content-Disposition",
							"attachment;filename = VendorPortal_Report_" + strdatetime + ".pdf");
					OutputStream out = response.getOutputStream();
					response.setContentType("pdf/" + "VendorPortal_Report_" + strdatetime + ".pdf");

					ClsExportPdf.exportPdf(exportData, reportBean.getExportHeader(), reportBean, session.getId(),
							getServletContext().getRealPath("temp"));

					response.setHeader("Content-Disposition",
							"attachment;filename = VendorPortal_Report_" + strdatetime + ".pdf");

					FileInputStream in = new FileInputStream(getServletContext().getRealPath("temp") + File.separator
							+ "PDFReport" + session.getId() + ".pdf");

					try {
						int n = 0;
						byte b[] = new byte[1024];
						while ((n = in.read(b)) != -1) {
							out.write(b, 0, n);
						}
						out.flush();
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						if (in != null) {
							in.close();
						}
						if (out != null) {
							out.close();
						}
					}

					File file = new File(getServletContext().getRealPath("temp") + File.separator + "PDFReport"
							+ session.getId() + ".pdf");
					try {
						file.delete();
					} catch (Exception exc) {
						exc.printStackTrace();
					}

				} catch (Exception ex) {
					loggerErr.error("Exception while creating PDF:" + ex.getMessage());
					ex.printStackTrace();
				}

			} else if ((!ClsUtil.isNullOrEmpty(request.getParameter("hiddenSearch"))
					&& request.getParameter("hiddenSearch").equalsIgnoreCase("SearchQuery"))) {
				logger.debug("Exporting PDF. Session: " + session.getId() + "UserName:" + userName);

				String invoiceNo = null;
				request.setAttribute("hiddenSearch", "SearchQuery");
				request.setAttribute("SearchStatus", ClsMessageHandler.QueryStatusTypes);
				VendorQueryMaster venMaster = new VendorQueryMaster();

				Date dateFrom = null;
				Date dateTo = null;
				String statusQuery = null;
				String queryNo = null;

				if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenQueryNo"))) {
					queryNo = request.getParameter("hiddenQueryNo").trim();
				}
				statusQuery = request.getParameter("hiddenStatus");

				try {
					if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenFromDate"))
							&& !ClsUtil.isNullOrEmpty(request.getParameter("hiddenToDate"))) {
						dateFrom = sdf.parse(request.getParameter("hiddenFromDate"));
						dateTo = sdf.parse(request.getParameter("hiddenToDate"));
					}
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					loggerErr.error("Date Parsing Exception while Searching Query:" + e.getMessage());
					e.printStackTrace();
				}
				if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenInvoiceNo"))) {
					invoiceNo = request.getParameter("hiddenInvoiceNo").trim();
				}

				if (queryNo != null && queryNo.trim() != "") {
					venMaster.setQueryNo(queryNo);
				}
				venMaster.setInvoiceNo(invoiceNo);
				venMaster.setFromDate(dateFrom);
				venMaster.setToDate(dateTo);
				venMaster.setCreatedBy(userName);
				// to export query report
				StringBuffer exportData = searchStatusDao.exportQuery(venMaster, archive, statusQuery, reportBean,
						priviledge, vendorCode, endurl);

				response.setHeader("Content-Disposition",
						"attachment;filename = VendorPortal_Report_" + strdatetime + ".pdf");
				OutputStream out = response.getOutputStream();
				response.setContentType("pdf/" + "Report.pdf");

				ClsExportPdf.exportPdf(exportData, reportBean.getHeader(), reportBean, session.getId(),
						getServletContext().getRealPath("temp"));

				FileInputStream in = new FileInputStream(
						getServletContext().getRealPath("temp") + "\\PDFReport" + session.getId() + ".pdf");

				try {
					int n = 0;
					byte b[] = new byte[1024];
					while ((n = in.read(b)) != -1) {
						out.write(b, 0, n);
					}
					out.flush();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (in != null) {
						in.close();
					}
					if (out != null) {
						out.close();
					}
				}

				File file = new File(
						getServletContext().getRealPath("temp") + "\\PDFReport" + session.getId() + ".pdf");
				try {
					file.delete();
				} catch (Exception exc) {
					loggerErr.error("Exception while creating PDFReport:" + exc.getMessage());
					exc.printStackTrace();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			loggerErr.error("Exception in Export Pdf Servlet:" + ex.getMessage());
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in in exporting data to pdf is :" + totaltime);
	}

}
