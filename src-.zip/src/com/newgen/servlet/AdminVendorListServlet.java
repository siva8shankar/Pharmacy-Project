/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminVendorListServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminVendorListServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminVendorListDAO;
import com.newgen.dao.AdminVendorListDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class AdminVendorListServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	public AdminVendorListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		HttpSession session = null;

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));
		int result = 0;

		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName")
					+ " Admin Viewing Vendor List");

			GeneralClass generalClass = new GeneralClass();

			String linkType;
			String topNo;
			String lastNo;

			topNo = request.getParameter("hiddenTopNo");
			lastNo = request.getParameter("hiddenLastNo");
			linkType = request.getParameter("LinkType");
			generalClass.setLinkType(linkType);
			generalClass.setPaginationTopQryNo(topNo);
			generalClass.setPaginationLastQryNo(lastNo);
			generalClass.setBatchSize(ClsMessageHandler.BatchSizeVendorList);
			generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);

			AdminVendorListDAOI adminVendorListDAO = new AdminVendorListDAO();

			// This Method is used to getVendorList.
			generalClass = adminVendorListDAO.getVendorList(generalClass, endurl);

			// Vendor List Found
			if (!ClsUtil.isNullOrEmpty(generalClass.getArrayVendorList())
					&& generalClass.getArrayVendorList().size() > 0) {
				request.setAttribute("VendorList", generalClass.getArrayVendorList());
				request.setAttribute("TopNo", generalClass.getPaginationTopQryNo());
				request.setAttribute("LastNo", generalClass.getPaginationLastQryNo());
				request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
				request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
				request.setAttribute("Administration", "Vendor List");
				request.getRequestDispatcher("JSP/AdminVendorList.jsp").forward(request, response);

			}
			// No Vendor Found
			else {
				logger.debug("No Vendor Found");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG036);
				request.setAttribute("Administration", "Vendor List");
				request.getRequestDispatcher("JSP/AdminVendorList.jsp").forward(request, response);
			}
		} catch (Exception e) {
			loggerErr.error("Exception in Vendor List Servlet : " + e.getMessage());
			e.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting Vendor List is : " + totaltime);
	}
}
