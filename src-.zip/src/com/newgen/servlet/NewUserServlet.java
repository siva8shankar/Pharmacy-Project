/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: NewUserServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class NewUserServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.newgen.bean.AppliedUser;
import com.newgen.dao.NewUserDAO;
import com.newgen.dao.NewUserDAOI;
import com.newgen.lic.servlet.LicFetch;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class NewUserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NewUserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		logger.debug("Registering New User........");

		AppliedUser appliedUser = new AppliedUser();
		NewUserDAOI newUserDao = new NewUserDAO();
		int result = 0;

		// an
		ArrayList<String> outptXML;
		String maxUserCreated = "";
		String keySaved = "";
		String namedUser1 = "";
		String concUser = "";

		try {
			outptXML = LicFetch.fetchData(endurl);
			for (int i = 0; i < outptXML.size(); i++) {
				if (i == 0)
					maxUserCreated = outptXML.get(i);
				if (i == 1)
					keySaved = outptXML.get(i);
				if (i == 2)
					namedUser1 = outptXML.get(i);
				if (i == 3)
					concUser = outptXML.get(i);
			}
			if (ClsUtil.isNullOrEmpty(keySaved)) {
				request.setAttribute("MSGCODE", "Please take user license....");
				request.getRequestDispatcher("JSP/Login.jsp").forward(request, response);
			} else {
				logger.debug("NewUserServlet maxUserCreated-->" + maxUserCreated);
				logger.debug("NewUserServlet keySaved-->" + keySaved);
				logger.debug("NewUserServlet namedUser1-->" + namedUser1);
				logger.debug("NewUserServlet concUser-->" + concUser);

				int Int_maxUserCreated = Integer.parseInt(maxUserCreated);
				int Int_namedUser1 = Integer.parseInt(namedUser1);
				if (Int_maxUserCreated < Int_namedUser1) {// an-end

					if (null != request.getParameter("hiddenButton")
							&& !(request.getParameter("hiddenButton").equals("checkAvailability"))) {
						appliedUser.setUserName(request.getParameter("newUserName"));
						appliedUser.setVendorCode(request.getParameter("vendorCode"));
						appliedUser.setVendorName(request.getParameter("vendorName"));
						appliedUser.setVendorAdd(request.getParameter("vendorAdd"));
						appliedUser.setEmailId(request.getParameter("emailId"));
						appliedUser.setAddress(request.getParameter("address"));
						appliedUser.setPhoneNo(request.getParameter("phoneNo"));
						appliedUser.setContactPersonName(request.getParameter("contactPersonName"));
						appliedUser.setMobileNo(request.getParameter("mobileNo"));
						appliedUser.setPAN(request.getParameter("PAN"));
						appliedUser.setTAN(request.getParameter("TAN"));
						appliedUser.setServiceRegNo(request.getParameter("serviceRegNo"));
						appliedUser.setTIN(request.getParameter("TIN"));

						result = newUserDao.registerUser(appliedUser, endurl);
						logger.debug("registerUser method of newUserDao class........" + result);

						if (result > 0) {
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG023);
							request.getRequestDispatcher("JSP/Login.jsp").forward(request, response);

						} else if (result == -1) {
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG024);
							request.getRequestDispatcher("JSP/Login.jsp").forward(request, response);
						} else {
							request.setAttribute("MSGCODE", ClsMessageHandler.MSG025);
							request.getRequestDispatcher("JSP/Login.jsp").forward(request, response);
						}
					} else {
						response.sendRedirect(request.getContextPath() + "/login");
						return;
					}
				}
				// an
				else // if no of users created exceed licensed number
				{
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG081);
					request.getRequestDispatcher("JSP/Login.jsp").forward(request, response);

				} // an-end
			}

		} catch (Exception ex) {

			loggerErr.error("Exception in New User Servlet : " + ex.getMessage());
			request.getRequestDispatcher("JSP/Login.jsp").forward(request, response);
			ex.printStackTrace();

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in registering New User is :" + totaltime);
	}

}
