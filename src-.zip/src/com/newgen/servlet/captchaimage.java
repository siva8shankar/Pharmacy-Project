/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: captchaimage.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class captchaimage extends HttpServlet {

	private static final long serialVersionUID = 1L;
	ServletContext servletcontext = null;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		servletcontext = config.getServletContext();

	}

	/**
	 * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
	 * methods.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");

	}

	// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on
	// the + sign on the left to edit the code.">
	/**
	 * Handles the HTTP <code>GET</code> method.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("image/jpg");

		int iTotalChars = 6;

		int iHeight = 40;
		int iWidth = 158;

		Font fntStyle1 = new Font("Arial", 1, 30);
		Font fntStyle2 = new Font("Verdana", 1, 20);

		Random randChars = new Random();
		String sImageCode = Long.toString(Math.abs(randChars.nextLong()), 36).substring(0, iTotalChars);

		BufferedImage biImage = new BufferedImage(iWidth, iHeight, 1);

		Graphics2D g2dImage = (Graphics2D) biImage.getGraphics();

		int iCircle = 15;
		g2dImage.fillRect(0, 0, iWidth, iHeight);
		for (int i = 0; i < iCircle; ++i) {
			g2dImage.setColor(new Color(224, 224, 224));
			int iRadius = (int) (Math.random() * iHeight / 2.0D);
			int iX = (int) (Math.random() * iWidth - iRadius);
			int iY = (int) (Math.random() * iHeight - iRadius);

			g2dImage.fillRoundRect(iX, iY, iRadius * 2, iRadius * 2, 100, 100);
		}
		g2dImage.setFont(fntStyle1);
		for (int i = 0; i < iTotalChars; ++i) {
			g2dImage.setColor(new Color(randChars.nextInt(200), randChars.nextInt(200), randChars.nextInt(200)));

			if (i % 2 == 0)
				g2dImage.drawString(sImageCode.substring(i, i + 1), 25 * i, 24);
			else {
				g2dImage.drawString(sImageCode.substring(i, i + 1), 25 * i, 35);
			}
		}
		HttpSession session = request.getSession();

		session.setAttribute("dns_security_code", sImageCode);

		// servletcontext.setAttribute("dns_security_code", sImageCode);
		System.out.println("dns_security_code" + sImageCode);
		OutputStream osImage = response.getOutputStream();
		ImageIO.write(biImage, "jpeg", osImage);
		osImage.flush();
		osImage.close();

		g2dImage.dispose();

		System.out.println("Captcha code sent back");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Returns a short description of the servlet.
	 * 
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}// </editor-fold>
}
