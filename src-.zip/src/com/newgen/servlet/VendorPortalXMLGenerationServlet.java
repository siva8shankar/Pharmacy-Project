/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorPortalXMLGenerationServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class VendorPortalXMLGenerationServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.newgen.util.VendorPortalXMLGeneration;

public class VendorPortalXMLGenerationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger("consoleLogger");

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VendorPortalXMLGenerationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("Vendor Portal XML generation");
		try {
			VendorPortalXMLGeneration xmlGeneration = new VendorPortalXMLGeneration();
			HashMap<String, String> mapXMLData = xmlGeneration
					.loadXMLData(getServletContext().getRealPath("VendorPortal.xml"));
			request.setAttribute("MAPXMLDATA", mapXMLData);
			request.getRequestDispatcher("JSP/Configuration.jsp").forward(request, response);

		} catch (Exception ex) {
			logger.error("Exception in  Vendor Portal XML generation servlet: : " + ex.getMessage());
			ex.printStackTrace();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in generating dynamic Vendor Portal XML is " + totaltime);
	}

}
