/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: NewUserLinkConfirmationServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  Servlet implementation class NewUserLinkConfirmationServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.PasswordPolicyBean;
import com.newgen.dao.AdminChangePasswordDAO;
import com.newgen.dao.AdminChangePasswordDAOI;
import com.newgen.dao.UserConfirmationDAO;
import com.newgen.dao.UserConfirmationDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class NewUserLinkConfirmationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NewUserLinkConfirmationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		int result = 0;
		HttpSession session = null;
		try {

			session = request.getSession();

			String userLink = request.getParameter("uesgsezwqop");
			logger.info("NewUserLinkConfirmation Method Starts servlet...userLink-----------> "
					+ request.getParameter("userLink"));
			String UserName = userLink.substring(0, userLink.indexOf("$"));
			String encryptedDT = userLink.substring(userLink.indexOf("$") + 1, userLink.lastIndexOf("$"));
			String activationCode = userLink.substring(userLink.lastIndexOf("$") + 1, userLink.length());

			logger.debug("UserName-->" + UserName);
			logger.debug("encryptedDT-->" + encryptedDT);
			logger.debug("activationCode-->" + activationCode);

			String decryptedDT = ClsUtil.getDecryptedDate(encryptedDT);
			logger.debug("decryptedDT-->" + decryptedDT);

			if (!ClsUtil.isNullOrEmpty(decryptedDT)) {
				String currentDT = ClsUtil.getCurrentDateTime();
				logger.debug("currentDT-->" + currentDT);
				boolean isLinkActive = ClsUtil.getDifferenceInHours(decryptedDT, currentDT);
				logger.debug("isLinkActive-->" + isLinkActive);
				if (isLinkActive) {
					if (!ClsUtil.isNullOrEmpty(activationCode)) {
						UserConfirmationDAOI userConfirmationDao = new UserConfirmationDAO();

						// This Method is used to check whether user is valid to
						// change password.
						result = userConfirmationDao.checkValidLink(UserName, activationCode, endurl);
					}

					AdminChangePasswordDAOI adminChangePassworddao = new AdminChangePasswordDAO();
					PasswordPolicyBean myPasswordBean = adminChangePassworddao.FetchPasswordPolicy("", "", endurl);
					logger.debug(
							"In NewUserLinkConfirmation ----> Getting Password Settings ********************PassLength->"
									+ myPasswordBean.getPasswordLen());
					session.setAttribute("PasswordPolicyData", myPasswordBean);
					// Till here

					request.setAttribute("userName", UserName);
					request.setAttribute("activationCode", activationCode);

					if (result > 0) {
						request.setAttribute("Activity", "Redirecting for Change Password");
						request.setAttribute("PasswordLen", myPasswordBean.getPasswordLen());
						request.setAttribute("MinLowerCount", myPasswordBean.getMinLowerCaseCt());
						request.setAttribute("MinNumberCount", myPasswordBean.getMinNumCharCt());
						request.setAttribute("MinSplCount", myPasswordBean.getMinSplCharCt());
						request.setAttribute("MinUpperCount", myPasswordBean.getMinUpperCaseCt());

						request.getRequestDispatcher("JSP/UserConfirmation.jsp").forward(request, response);
					} else if (result == -1) {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG055);
						request.setAttribute("Activity", "Redirecting for Change Password");
						request.getRequestDispatcher("/login").forward(request, response);
					} else {
						// request.setAttribute("MSGCODE",
						// ClsMessageHandler.MSG014);
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG083);
						request.getRequestDispatcher("/login").forward(request, response);
					}
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG085);// Activation
																				// Link
																				// Expired
					request.getRequestDispatcher("/login").forward(request, response);
				}
			} else {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG086);// Invalid
																			// Link
				request.getRequestDispatcher("/login").forward(request, response);
			}
		} catch (Exception ex) {
			loggerErr.error("Exception in New User Link Confirmation Servlet:" + ex.getMessage());
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			ex.printStackTrace();

		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in New User Link Confirmation is :" + totaltime);
	}

}
