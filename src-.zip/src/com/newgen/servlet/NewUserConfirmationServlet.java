/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: NewUserConfirmationServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class NewUserConfirmationServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.newgen.bean.PasswordPolicyBean;
import com.newgen.dao.AdminChangePasswordDAO;
import com.newgen.dao.AdminChangePasswordDAOI;
import com.newgen.dao.UserConfirmationDAO;
import com.newgen.dao.UserConfirmationDAOI;
import com.newgen.lic.servlet.DESedeEncryption;
import com.newgen.util.ClsMessageHandler;

public class NewUserConfirmationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NewUserConfirmationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		int result = 0;
		HttpSession session = null;
		try {
			session = request.getSession();

			logger.info("confirmUser Method Starts servlet...UserName: " + request.getParameter("userName"));
			String userName = request.getParameter("userName");
			String activationCode = request.getParameter("activationCode");
			String EncryptNewPwd = null;
			String EncryptOldPwd = null;
			try {
				String oldPassword = request.getParameter("oldhiddenPwd");

				EncryptOldPwd = oldPassword;
				logger.debug("EncryptOldPwd firstly:" + EncryptOldPwd);
			} catch (Exception e) {
				logger.debug("Exception while encryption in oldPassword....");
				e.printStackTrace();
			}
			try {
				String newPassword = request.getParameter("newhiddenPwd");
				DESedeEncryption obj = new DESedeEncryption();
				String encryptednewpwd = obj.encrypt(newPassword);
				byte[] encodedBytes = Base64.encodeBase64(encryptednewpwd.getBytes());
				String encodeEncryptStr = new String(encodedBytes);
				Character[] charObjectArray = toCharacterArray(encodeEncryptStr);
				List<Character> list = new ArrayList<Character>(Arrays.asList(charObjectArray));
				compoundShuffle(list, 2, 4);
				StringBuilder sb = new StringBuilder();
				for (Character s : list) {
					sb.append(s);
				}
				String shuffleData = sb.toString();
				EncryptNewPwd = shuffleData + "24";
				logger.debug("EncryptNewPwd" + EncryptNewPwd);
			} catch (Exception e) {
				logger.debug("Exception while encryption in newPassword....");
				e.printStackTrace();
			}
			UserConfirmationDAOI userConfirmationDao = new UserConfirmationDAO();

			// This Method is used to confirm user and update the temp password
			// to new password.
			result = userConfirmationDao.confirmUser(userName, activationCode, EncryptOldPwd, EncryptNewPwd, endurl);
			logger.debug("Result-->" + result);
			AdminChangePasswordDAOI adminChangePassworddao = new AdminChangePasswordDAO();
			PasswordPolicyBean myPasswordBean = adminChangePassworddao.FetchPasswordPolicy("", "", endurl);
			logger.debug("In NewUserConfirmation ----> Getting Password Settings ********************PassLength->"
					+ myPasswordBean.getPasswordLen());
			session.setAttribute("PasswordPolicyData", myPasswordBean);
			// Till here

			if (result == 1) {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG020);
				request.getRequestDispatcher("login").forward(request, response);
			} else if (result == 2) {
				// logger.debug("ClsMessageHandler.MSG089"+ClsMessageHandler.MSG089);
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG089);
				request.getRequestDispatcher(
						"JSP/ResetNewPassword.jsp?userName" + userName + "&activationCode=" + activationCode)
						.forward(request, response);
			} else if (result == 3) {
				logger.debug("ClsMessageHandler.MSG090" + ClsMessageHandler.MSG090);
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG090);
				request.getRequestDispatcher(
						"JSP/ResetNewPassword.jsp?userName" + userName + "&activationCode=" + activationCode)
						.forward(request, response);
			} else if (result == -1) {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG052);
				request.getRequestDispatcher(
						"JSP/ResetNewPassword.jsp?userName" + userName + "&activationCode=" + activationCode)
						.forward(request, response);
			} else if (result == -2) {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG033);
				request.getRequestDispatcher(
						"JSP/ResetNewPassword.jsp?userName" + userName + "&activationCode=" + activationCode)
						.forward(request, response);
			} else {
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
				request.getRequestDispatcher(
						"JSP/ResetNewPassword.jsp?userName" + userName + "&activationCode=" + activationCode)
						.forward(request, response);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			loggerErr.error("Exception in New User Confirmation Servlet:" + ex.getMessage());

		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting New User Confirmation  is :" + totaltime);

	}

	public static Character[] toCharacterArray(String s) {

		try {
			if (s == null) {
				return null;
			}

			int len = s.length();
			Character[] array = new Character[len];
			for (int i = 0; i < len; i++) {
				array[i] = new Character(s.charAt(i));
			}

			return array;
		} catch (Exception e) {
			logger.debug("Exception in toCharacterArray in encryption in VP....");
			e.printStackTrace();
			return null;
		}
	}

	public static void compoundShuffle(List<?> list, int repetition, long seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < repetition; i++)
			// logger.debug("compoundShuffle "+list);
			Collections.shuffle(list, rand);

	}
}
