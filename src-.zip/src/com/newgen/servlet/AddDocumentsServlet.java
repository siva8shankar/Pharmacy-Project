/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AddDocumentsServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AddDocumentsServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;

import com.newgen.dao.WorkitemDAO;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.MultipartFileUploader;

public class AddDocumentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private String ibps_endurl = "";
	private String cabinet = "";
	String OD_IP = "";

	private String folderName = "";
	private String volumeIndex = "";
	private String rootFolderPath = "";
	private String jtsIpAddress = "";
	private String jtsPort = "";
	private ServletConfig confi;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		confi = config;
		OD_IP = (String) config.getServletContext().getAttribute("ODIP");

		ibps_endurl = (String) config.getServletContext().getAttribute("IBPSEndPointURL");
		logger.debug("ibps_endurl " + ibps_endurl);
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("cabinet " + cabinet);
		folderName = (String) config.getServletContext().getAttribute("FolderName");
		logger.debug("FolderName " + folderName);
		volumeIndex = (String) config.getServletContext().getAttribute("VolumeIndex");
		logger.debug("VolumeIndex " + volumeIndex);
		rootFolderPath = (String) config.getServletContext().getAttribute("RootFolderPath");
		logger.debug("RootFolderPath " + rootFolderPath);
		jtsIpAddress = (String) config.getServletContext().getAttribute("jtsIpAddress");
		logger.debug("jtsIpAddress " + jtsIpAddress);
		jtsPort = (String) config.getServletContext().getAttribute("jtsPort");
		logger.debug("jtsPort " + jtsPort);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddDocumentsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	public void generateLog(String sLogMessage, String sPath) {

		java.util.Date date = new java.util.Date();
		sLogMessage = date.toString() + ":" + sLogMessage;
		sLogMessage = sLogMessage + "\n";
		FileWriter outFile = null;
		RandomAccessFile randomaccessfile = null;
		try

		{
			File fLog = new File(sPath.substring(0, sPath.lastIndexOf(System.getProperty("file.separator"))));
			fLog.mkdirs();
			fLog = new File(sPath);
			if (!fLog.exists()) {
				outFile = new FileWriter(sPath);
				outFile.close();
				outFile = null;
			}
			randomaccessfile = new RandomAccessFile(fLog, "rw");
			randomaccessfile.seek(randomaccessfile.length());
			randomaccessfile.write(sLogMessage.getBytes());
			randomaccessfile.close();

		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
			sPath = null;
			randomaccessfile = null;
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		String filename = null;
		String invNo = request.getParameter("invoiceno");
		String Sessionid = "";

		try {
			WorkitemDAO session = new WorkitemDAO();
			Sessionid = session.GetSessionOD(ibps_endurl, cabinet, confi);
			String fieldname = null;

			String fieldvalue = null;
			String serverPath = System.getProperty("user.dir");
			String filepath = null;
			String filesadded = "";
			logger.debug("request.getSession(true).getAttribute(FilesAddedData)............"
					+ request.getSession(true).getAttribute("FilesAddedData"));

			if (!ClsUtil.isNullOrEmpty(request.getSession(true).getAttribute("FilesAddedData"))) {
				String fileAddedData[] = ((String) request.getSession(true).getAttribute("FilesAddedData")).split(";");
				filesadded = fileAddedData[0] + ",";
			}
			logger.debug("filesadded" + filesadded);
			List items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
			int DocSize = 0;

			for (int i = 0; i < items.size(); i++) {
				FileItem item = (FileItem) items.get(i);
				fieldname = item.getFieldName();
				if (!item.isFormField()) {

					DocSize = (int) Math.ceil(item.getSize() / 1048576.0); // MB

					if (DocSize > Integer.parseInt(ClsMessageHandler.DocumentSize)) {

						request.setAttribute("DocumentTypes", ClsMessageHandler.DocumentType);
						logger.debug("Document size cannot exceed");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG028);

						request.getRequestDispatcher("JSP/Attachment1.jsp?DocumentTypes="
								+ ClsMessageHandler.DocumentType + "&invoiceno=" + invNo).forward(request, response);
						return;
					}
				}

			}

			logger.debug("items.size()" + items.size());
			for (int i = 0; i < items.size(); i++) {

				FileItem item = (FileItem) items.get(i);

				if (item.isFormField()) {
					logger.debug("shivamif");
					fieldname = item.getFieldName();
					fieldvalue = item.getString();
					logger.debug("fieldname" + fieldname);
					logger.debug("fieldvalue" + fieldvalue);
					if (i == items.size() - 1) {
						filesadded = filesadded + fieldvalue.trim() + "_" + filename;
						logger.debug("filesadded if" + filesadded);
					} else {
						filesadded = filesadded + fieldvalue.trim() + "_" + filename + ",";
						logger.debug("filesadded else" + filesadded);
					}
					filepath = serverPath + File.separator + "Documents";
					File file = new File(filepath);
					if (!file.isDirectory()) {
						file.mkdir();
					}
					filename = serverPath + File.separator + "Documents" + File.separator + fieldvalue.trim() + "_"
							+ filename;
					logger.debug("filename if" + filename);
					if (item.getFieldName().toLowerCase().indexOf("doctype") == -1) {
						continue;
					}
					FileItem itemdoc = (FileItem) items.get(i - 1);
					itemdoc.write(new File(filename));

				}
				// if item is file
				else {
					logger.debug("jatinelse");
					fieldname = item.getFieldName();
					filename = FilenameUtils.getName(item.getName());
					logger.debug("filename else" + filename);
					if (ClsUtil.isNullOrEmpty(filename))
						continue;
				}
			}
			logger.debug("filesadded" + filesadded);
			if (!ClsUtil.isNullOrEmpty(filesadded)) {
				File file = new File(filepath);
				String filesExistedname[] = file.list();
				for (String s : filesExistedname)
					logger.debug("filesExistedname" + s);
				String filesAdded[] = filesadded.split(",");
				for (int i = 0; i < filesExistedname.length; i++) {
					int r = 0;
					for (int j = 0; j < filesAdded.length; j++) {
						if (filesExistedname[i].equalsIgnoreCase(filesAdded[j])) {
							r = 1;
							break;
						}
					}
					if (r == 0) {
						String del = filepath + File.separator + filesExistedname[i];
						File filed = new File(del);

						boolean sucess = filed.delete();
					}
				}

			}

			request.getSession(true).setAttribute("FilesAddedData", filesadded + ";" + filepath);
			logger.debug("request.getSession(true).setAttribute(FilesAddedData)............"
					+ request.getSession(true).getAttribute("FilesAddedData"));
			logger.debug("Document added successfully");
			request.setAttribute("MSGCODE", ClsMessageHandler.MSG027);
			request.getRequestDispatcher("JSP/Attachment1.jsp").forward(request, response);
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			loggerErr.error("Exception in Uploading Document : " + e.getMessage());
			request.setAttribute("DocumentTypes", ClsMessageHandler.DocumentType);
			request.setAttribute("MSGCODE", ClsMessageHandler.MSG029);
			request.getRequestDispatcher("JSP/Attachment1.jsp?DocumentTypes=" + ClsMessageHandler.DocumentType)
					.forward(request, response);
		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Uploading Document is : " + totaltime);

	}

}
