/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: GeneratedInvoiceDetailsServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class GeneratedInvoiceDetailsServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.InvoiceDetails;
import com.newgen.dao.GetInvoiceDetailDAO;
import com.newgen.dao.GetInvoiceDetailDAOI;
import com.newgen.dao.InvoiceDocDAO;
import com.newgen.dao.VendorBankingDetailsDAO;
import com.newgen.dao.VendorBankingDetailsDAOI;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class GeneratedInvoiceDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);

	}

	public GeneratedInvoiceDetailsServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		long starttime = System.currentTimeMillis();
		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));
		HttpSession session = null;
		try {
			session = request.getSession(true);
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			String invoiceId = request.getParameter("hiddenInvId");
			String BarcodeNumber = request.getParameter("BarcodeNumber");
			GeneralClass gen = null;
			VendorBankingDetailsDAOI vendorBankingDetails = new VendorBankingDetailsDAO();
			gen = vendorBankingDetails.GetBankingDetails(userName, sessionId, endurl);
			GetInvoiceDetailDAOI genInvDetailsDao = new GetInvoiceDetailDAO();

			// This Method is used to Get Invoice Details.
			InvoiceDetails invBean = null;// genInvDetailsDao.GetInvoiceDetail(invoiceId,
											// endurl);
			HashMap<Integer, InvoiceDetails> DocListmap = null;
			InvoiceDocDAO DocList = new InvoiceDocDAO();
			// This Method is used to Get Invoice Doc Details.
			DocListmap = DocList.GetInvoiceDoc(invBean.getInvoiceNumberInSystem(), endurl);
			if (gen.getResultCode() > 0) {
				if (!ClsUtil.isNullOrEmpty(gen.getBankdetailmap()) && !ClsUtil.isNullOrEmpty(invBean)) {
					request.setAttribute("InvoicesDetails", invBean);
					request.setAttribute("BarcodeNumber", BarcodeNumber);
					request.setAttribute("BankDetails", gen.getBankdetailmap());
					request.setAttribute("DocListmap", DocListmap);
					request.setAttribute("VendorInvoice", "Invoice Details");
					request.setAttribute("DocumentSize", ClsMessageHandler.DocumentSize);
					request.getRequestDispatcher("JSP/SubmitInvoice.jsp").forward(request, response);

				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.setAttribute("VendorInvoice", "Invoice Details");
					request.getRequestDispatcher("MyInvoiceServlet").forward(request, response);
				}
			} else {
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

		} catch (Exception e) {
			loggerErr.error("Exception in InvoiceDetailsServlet :" + e.getMessage());
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			e.printStackTrace();
			session.invalidate();

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting InvoiceDetailsServlet is :" + totaltime);
	}
}
