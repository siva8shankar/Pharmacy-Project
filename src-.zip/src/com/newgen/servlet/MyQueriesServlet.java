/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: MyQueriesServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class MyQueriesServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
* 09/01/2018			ksivashankar					Bug 1023795 - Vendor Portal - Query lock symbol was required for the Admin module.* 
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorQueryDetails;
import com.newgen.dao.MyQueriesDAO;
import com.newgen.dao.MyQueriesDAOI;
import com.newgen.dao.SearchStatusDAO;
import com.newgen.dao.SearchStatusDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class MyQueriesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MyQueriesServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.debug("inside doPost in MyQueriesServlet...");
		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String priviledge = (String) session.getAttribute("Privilege");
			logger.debug("MyQueriesServlet priviledge ****** " + priviledge);
			String sessionId = session.getId();
			logger.debug("session  === " + sessionId + " userName   == " + userName);
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--" + sessionId);

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.--" + sessionId);

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			GeneralClass generalClass = new GeneralClass();
			String queryNo;
			String linkType;
			String topQueryNo;
			String lastQueryNo;

			if (!(!ClsUtil.isNullOrEmpty(request.getParameter("checkHyperlink"))
					&& request.getParameter("checkHyperlink").equals("QueryDetailsFromMyQueries"))
					|| (!ClsUtil.isNullOrEmpty(request.getParameter("LinkType2"))
							&& (request.getParameter("LinkType2").equals("next")
									|| request.getParameter("LinkType2").equals("prev")))) {

				topQueryNo = request.getParameter("hiddenTopQueryNo2");
				lastQueryNo = request.getParameter("hiddenLastQueryNo2");
				linkType = request.getParameter("LinkType2");
				generalClass.setLinkType(linkType);
				generalClass.setPaginationTopQryNo(topQueryNo);
				generalClass.setPaginationLastQryNo(lastQueryNo);
				generalClass.setBatchSize(ClsMessageHandler.BatchSizeMyQuery);
				generalClass.setDbConfig(ClsMessageHandler.MainDBConfig);

				MyQueriesDAOI myQueriesDao = new MyQueriesDAO();
				// to get list of my queries
				generalClass = myQueriesDao.getMyQueries(priviledge, userName, generalClass, sessionId, endurl);
				if (generalClass.getSessionresult() > 0) {
					if (!ClsUtil.isNullOrEmpty(generalClass.getArrayQueryMaster())
							&& generalClass.getArrayQueryMaster().size() > 0) {
						logger.debug("if case inside MyQuery Servlet...");
						request.setAttribute("MyQueriesData", generalClass.getArrayQueryMaster());
						logger.debug("Query data == " + generalClass.getArrayQueryMaster());
						request.setAttribute("TopQueryNo", generalClass.getPaginationTopQryNo());
						request.setAttribute("LastQueryNo", generalClass.getPaginationLastQryNo());
						request.setAttribute("PrevFlag", generalClass.getPrevRecordFlag());
						request.setAttribute("NextFlag", generalClass.getLastRecordFlag());
						request.setAttribute("VendorQuery", "My Queries");
						request.getRequestDispatcher("JSP/MyQuery.jsp").forward(request, response);
					} else {
						logger.debug("Else case inside MyQuery Servlet...");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG010);
						request.setAttribute("VendorQuery", "My Queries");
						request.getRequestDispatcher("JSP/MyQuery.jsp").forward(request, response);
					}
				} else {
					response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
					return;
				}

			} else {

				logger.debug("Getting Query Detail From My Queries Screen. sessionId : " + sessionId + " Username :"
						+ userName);

				VendorQueryDetails venDetailsFromMyQuery = new VendorQueryDetails();
				String invoiceNo;
				queryNo = request.getParameter("hiddenQryNo");
				invoiceNo = request.getParameter("hiddenInvNo");
				venDetailsFromMyQuery.setCreatedBy(userName);
				venDetailsFromMyQuery.setQueryNo(queryNo);
				SearchStatusDAOI searchStatusDao = new SearchStatusDAO();

				// This Method is used to get Query Details.s
				generalClass = searchStatusDao.searchQueryDetails(priviledge, venDetailsFromMyQuery, "", sessionId,
						endurl);
				if (generalClass.getSessionresult() > 0) {
					if (!ClsUtil.isNullOrEmpty(generalClass.getArrayQueryDetails())
							&& generalClass.getArrayQueryDetails().size() > 0) {
						request.setAttribute("invNo", invoiceNo);
						request.setAttribute("qryNo", queryNo);
						request.setAttribute("QueryDataDetails", generalClass.getArrayQueryDetails());
						request.setAttribute("VendorQuery", "Query Details");
						request.getRequestDispatcher("JSP/SearchQueryDetails.jsp").forward(request, response);
					} else {
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG011);
						request.setAttribute("VendorQuery", "Query Details");
						request.getRequestDispatcher("JSP/MyQuery.jsp").forward(request, response);
					}
				} else {
					response.sendRedirect(request.getContextPath() + "/login");
					return;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			loggerErr.error("Exception in My Queries Servlet:" + e.getMessage());
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting MyQueriesServlet is :" + totaltime);
	}

}
