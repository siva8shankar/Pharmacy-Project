/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AddDocumentServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/08/2017
*    (DD/MM/YYYY)                      
*    Description                            	: File is used to add document in omnidocs
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.newgen.bean.InvoiceNewDetails;
import com.newgen.bean.PropertyBean;
import com.newgen.dao.WorkitemDAO;
import com.newgen.util.AddToSMS;
import com.newgen.util.ClsExportExcel;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.CommonMethod;
import com.newgen.util.GeneralClass;
import com.newgen.util.MultipartFileUploader;
import com.newgen.util.MultipartUtility;
import com.newgen.util.PropReader;

import ISPack.ISUtil.JPISException;

public class AddDocumentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private String ibps_endurl = "";
	private String WorkitemEndPointurl = "";
	private String OD_IP = "";
	private String cabinet = "";
	private String folderName = "";
	private String volumeIndex = "";
	private String rootFolderPath = "";
	private String jtsIpAddress = "";
	private String jtsPort = "";
	private String OD_SessionURL = "", OD_Session_User = "", OD_Session_Pwd = "", WrapperPort = "", UserType = "",
			DataClass = "", DocIndexName1, DocIndexName2 = "";
	private String WI_DocIndexId = "";
	private String File_DocIndexId = "";
	private String InitiateFromActivityId = "";
	private String InitiateFromActivityName = "";
	private String ProcessDefId = "";
	private String ProcessName = "";
	private String result = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		WorkitemEndPointurl = (String) config.getServletContext().getAttribute("WorkItemEndPointURL");
		logger.debug("WorkitemEndPointurl " + WorkitemEndPointurl);
		ibps_endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("ibps_endurl " + ibps_endurl);
		OD_IP = (String) config.getServletContext().getAttribute("ODIP");
		logger.debug("OD_IP " + OD_IP);
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("cabinet " + cabinet);
		volumeIndex = (String) config.getServletContext().getAttribute("VolumeIndex");
		logger.debug("VolumeIndex " + volumeIndex);
		jtsIpAddress = (String) config.getServletContext().getAttribute("jtsIpAddress");
		logger.debug("jtsIpAddress " + jtsIpAddress);
		jtsPort = (String) config.getServletContext().getAttribute("jtsPort");
		logger.debug("jtsPort " + jtsPort);
		OD_SessionURL = (String) config.getServletContext().getAttribute("OD_SessionURL");
		logger.debug("OD_SessionURL " + OD_SessionURL);
		OD_Session_User = (String) config.getServletContext().getAttribute("OD_Session_User");
		logger.debug("OD_Session_User " + OD_Session_User);
		OD_Session_Pwd = (String) config.getServletContext().getAttribute("OD_Session_Pwd");
		logger.debug("OD_Session_Pwd " + OD_Session_Pwd);
		WrapperPort = (String) config.getServletContext().getAttribute("WrapperPort");
		logger.debug("WrapperPort " + WrapperPort);
		UserType = (String) config.getServletContext().getAttribute("UserType");
		logger.debug("UserType " + UserType);
		InitiateFromActivityId = (String) config.getServletContext().getAttribute("InitiateFromActivityId");
		logger.debug("InitiateFromActivityId " + InitiateFromActivityId);
		InitiateFromActivityName = (String) config.getServletContext().getAttribute("InitiateFromActivityName");
		logger.debug("InitiateFromActivityName " + InitiateFromActivityName);
		ProcessDefId = (String) config.getServletContext().getAttribute("ProcessDefId");
		logger.debug("ProcessDefId " + ProcessDefId);
		ProcessName = (String) config.getServletContext().getAttribute("ProcessName");
		logger.debug("ProcessName " + ProcessName);

	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddDocumentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		logger.debug("In doPost of AddDocumentServlet!!");

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		String invoiceNo = request.getParameter("invoiceNo");
		String invoiceDate = request.getParameter("invoiceDate");
		String currency = request.getParameter("currency");// Combo
		String FDocumentType = request.getParameter("FDocumentType");
		String poNo = request.getParameter("poNo");
		String typeOfInvoice = request.getParameter("typeOfInvoice");
		logger.debug("invoiceNo --->" + invoiceNo);
		logger.debug("invoiceDate --->" + invoiceDate);
		logger.debug("currency --->" + currency);
		logger.debug("FDocumentType --->" + FDocumentType);
		logger.debug("poNo --->" + poNo);
		logger.debug("typeOfInvoice --->" + typeOfInvoice);

		String invoiceAmount = request.getParameter("invoiceAmount");
		
		String invoiceSubDate = request.getParameter("invoiceSubDate");
		String invoicePlantCode = request.getParameter("invoicePlantCode");
		String invoiceLocation = request.getParameter("invoiceLocation");
		logger.debug("invoiceAmount --->" + invoiceSubDate);
		logger.debug("exchangeRate --->" + invoicePlantCode);
		logger.debug("invoiceAmountUSD --->" + invoiceLocation);
		logger.debug("invoiceAmount --->" + invoiceAmount);

		String vendorCode = request.getParameter("vendorNo");
		String userName = (String) request.getAttribute("UserName");
		String vendorName = request.getParameter("vendorName");
		String vendorEmailId = request.getParameter("vendorEmailId");

		logger.debug("vendorCode --->" + vendorCode);
		logger.debug("userName --->" + userName);
		logger.debug("vendorName --->" + vendorName);
		logger.debug("vendorEmailId --->" + vendorEmailId);

		if (currency.equalsIgnoreCase("NULL") || currency.equalsIgnoreCase("-- Select --")
				|| currency.equalsIgnoreCase("")) {
			currency = "INR";
		}

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date d1 = new Date();
		String CreatedDate = dateFormat.format(d1);
		String strInvoiceDate = "";
		String strInvoiceSubDate = "";
		Date invdate = null;
		Date invsubdate = null;
		if (!ClsUtil.isNullOrEmpty(invoiceDate)) {
			try {

				SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.MainDateFormat);
				invdate = sdf.parse(invoiceDate);
				strInvoiceDate = dateFormat.format(invdate);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (!ClsUtil.isNullOrEmpty(invoiceSubDate)) {
			try {

				SimpleDateFormat sdf = new SimpleDateFormat(ClsMessageHandler.MainDateFormat);
				invsubdate = sdf.parse(invoiceSubDate);
				strInvoiceSubDate = dateFormat.format(invsubdate);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		

		logger.debug("strInvoiceDate-->" + strInvoiceDate);
		InvoiceNewDetails invDetails = new InvoiceNewDetails();
		invDetails.setInvoiceno(invoiceNo);
		invDetails.setInvoicedate_str(strInvoiceDate);
		invDetails.setCurrency(currency);
		invDetails.setFDocumentType(FDocumentType);
		invDetails.setPono(poNo);
		invDetails.setTypeofinvoice(typeOfInvoice);
		invDetails.setInvoiceAmount(invoiceAmount);
		invDetails.setInvoiceSubDate(strInvoiceSubDate);
		invDetails.setInvoicePlantCode(invoicePlantCode);
		invDetails.setInvoiceLocation(invoiceLocation);
		invDetails.setVendorno(vendorCode);
		invDetails.setInvoiceCreatedDate(CreatedDate);
		invDetails.setInvoiceCreatedBy(userName);
		invDetails.setVendorName(vendorName);
		invDetails.setVendorEmailId(vendorEmailId);
		logger.debug("invDetails.getVendorEmailId()" + invDetails.getVendorEmailId());
		logger.debug("invDetails" + invDetails);
		long starttime = System.currentTimeMillis();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String filePath = null;
		String Sessionid = "";
		String fileName = "";
		String fieldname = "";
		String invNo = "";
		String filesadded = "";
		ArrayList<String> AddtoSMS_Response_sd = null;

		AddtoSMS_Response_sd = new ArrayList<String>();
		WorkitemDAO workitemDAO = new WorkitemDAO();
		logger.debug("workitemDAO " + workitemDAO);
		PropertyBean probBean=null;
		try {
			MultipartUtility session = new MultipartUtility(OD_SessionURL, "UTF-8");
			/*logger.debug("session-->" + session);
			logger.debug("OD_SessionURL" + OD_SessionURL + "OD_Session_User" + OD_Session_User + "OD_Session_Pwd"
					+ OD_Session_Pwd + "BP_CabinetName" + cabinet + "JTSIP" + jtsIpAddress + "JTSPORT" + jtsPort
					+ "UserType" + UserType);
			Sessionid = session.getSessionValue(OD_SessionURL, OD_Session_User, OD_Session_Pwd, UserType);

			logger.debug("GetSessionOD->Sessionid:::" + Sessionid);*/

			logger.debug("************getting sessionID using static user Execution Starts ***************");
			PropReader  propReader = new PropReader();
			probBean = new PropertyBean();
			probBean = propReader.readPropertyFile();
			PropertyBean probBeanConnectRes = CommonMethod.connect(probBean);
			String sessionID = probBeanConnectRes.getUserDBId();
			logger.debug("sessionID :: "+sessionID);
			logger.debug("************getting sessionID using static user Execution Ends ***************");
			Sessionid=sessionID; 
			
			if (Sessionid == "" || Sessionid == "error"
					|| Sessionid.equalsIgnoreCase("Error while getting UserDBId.")) {
				logger.debug("Error in getting OD session id!!");
				logger.debug("Error in getting OD session id!!");
				out.println("Error in getting OD session id!!");
				response.setStatus(500);
				result = "500";
				return;
			}
			logger.debug("sessionID ===> " + Sessionid);
//			logger.debug("OmniDocsSessionid ===> " + OmniDocsSessionid);

			String serverPath = System.getProperty("user.dir");
			logger.debug("Working Directory = " + System.getProperty("user.dir"));
			String folderpath = "";
			String wi = "", Docname = "";
			Docname = request.getParameter("DocumentType");
			logger.debug("DocumentType =====> " + Docname);
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			logger.debug("isMultipartContent::" + isMultipart);
			isMultipart = true;
			if (!isMultipart) {
				response.setStatus(501);
				out.println("is not Multipart Content!!");
				return;
			}
			List items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

			logger.debug("	" + items.size());
			if (items.size() == 0) {
				response.setStatus(502);
				out.println("items size is 0!!");
				result = "502";
				out.print("Requested operation timeout. Please try after sometimes");
				return;

			}

			int j = 0;
			for (int i = 0; i < items.size(); i++) {

				FileItem item_sd = (FileItem) items.get(i); // for supporting
															// document sd
				logger.debug("no----->" + i);
				if (i == 2 || i == 3) {
					if (item_sd.isFormField()) {
						// do nothing
					} else {

						long cdt = System.currentTimeMillis();
						folderpath = serverPath + File.separator + "Documents";
						File file = new File(folderpath);
						if (!file.isDirectory()) {
							file.mkdir();
						}
						String itemName = item_sd.getName();
						itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());// To
																											// be
																											// handled
																											// here
						fileName = itemName;
						filePath = folderpath + File.separator + cdt + "_" + itemName;
						File savedFile = new File(filePath);
						item_sd.write(savedFile);

					}
					if (i == 2) {
						Docname = Docname;
					} else {
						Docname = "SupportingDocument";
					}
					String a = "";
					a = AddToSMS.AddtoSms(Docname, filePath, Sessionid, WorkitemEndPointurl, jtsIpAddress, cabinet,
							jtsPort, volumeIndex);
					logger.debug("+AddtoSMS_Response_sd--->" + a);
					AddtoSMS_Response_sd.add(a);

				}

			}

			if (AddtoSMS_Response_sd != null && AddtoSMS_Response_sd.size() != 0) {

				result = workitemDAO.initiateworkitemwithDocument(invDetails, WorkitemEndPointurl, Sessionid,
						AddtoSMS_Response_sd, ibps_endurl, cabinet, InitiateFromActivityId, InitiateFromActivityName,
						ProcessDefId, ProcessName, Docname);
				logger.debug("CaseNumber" + result);
				CommonMethod.disconCabinet(probBean,Sessionid);
			} else
				result = "";

			result.replace("\n", "");
			logger.debug("result for AddDocInOD is : " + result);

			if (result == "" || result.equals("failed") || result == "pending" || result == "Pending") {
				logger.debug("Upload Status" + result);
				response.setStatus(505);
				result = "505";
				out.print(result);
			}

			else {
				logger.debug("Upload Status" + result);
				request.setAttribute("msg", "Document uploaded succesfully in OD ::" + result);
				request.setAttribute("invNo", invoiceNo);
				request.setAttribute("result", result);
				response.setStatus(200);
				out.print(result);
			}

		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			CommonMethod.disconCabinet(probBean,Sessionid);
			response.setStatus(503);
			e.printStackTrace();
			loggerErr.error("Exception in Uploading Document : " + e.getMessage());
		} catch (JPISException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			if (AddtoSMS_Response_sd != null) {
				AddtoSMS_Response_sd.clear();
			}

			workitemDAO = null;

		}
	}

}
