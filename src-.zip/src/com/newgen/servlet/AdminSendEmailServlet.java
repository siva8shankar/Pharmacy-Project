/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminSendEmailServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminSendEmailServlet, Used for Sending Email To User By Admin
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminUserDAO;
import com.newgen.dao.AdminUserDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class AdminSendEmailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl is :: " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminSendEmailServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		logger.debug("Sending Email To User By Admin");

		AdminUserDAOI adminUserDAO = new AdminUserDAO();
		PrintWriter out = response.getWriter();
		String msg = null;

		int result = 0;

		HttpSession session = null;

		try {
			session = request.getSession();
			String userName1 = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName1, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName1);

			request.setAttribute("MSGCODE", null);
			String userName = request.getParameter("userName");

			// This Method is used to send email
			result = adminUserDAO.sendEmail(userName, endurl);
			logger.debug("result of addNewUser method of adminNewUserDao is ::" + result);

			// Email Sent Successfully.
			if (result > 0) {
				logger.debug("Email Sent Successfully.");
				msg = ClsMessageHandler.MSG065;
				out.print(msg);
				// request.setAttribute("MSGCODE", ClsMessageHandler.MSG065);
			}

			// UserName Doesn't Exist.
			else if (result == -1) {
				logger.debug("UserName Doesn't Exist.");
				msg = ClsMessageHandler.MSG033;
				out.print(msg);
				// request.setAttribute("MSGCODE", ClsMessageHandler.MSG033);
			}
			// Email Not Sent. Email Server may be down.
			else {
				logger.debug("Email Not Sent. Email Server may be down.");
				msg = ClsMessageHandler.MSG066;
				out.print(msg);
				// request.setAttribute("MSGCODE", ClsMessageHandler.MSG066);
			}

			request.setAttribute("Administration", "Send Email");

		} catch (Exception ex) {
			loggerErr.error("Exception in Admin Sending Email To User Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Sending Email To User is " + totaltime);
	}

}
