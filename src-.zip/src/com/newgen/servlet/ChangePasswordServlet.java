/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ChangePasswordServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class ChangePasswordServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.newgen.dao.ChangePasswordDAO;
import com.newgen.dao.ChangePasswordDAOI;
import com.newgen.lic.servlet.DESedeEncryption;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class ChangePasswordServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ChangePasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();

		int result = 0;
		HttpSession session = null;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();
			String EncryptNewPwd = null;

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName")
					+ " User Changing Password");

			request.setAttribute("MSGCODE", null);

			request.setAttribute("SessionID", request.getSession().getId());
			request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

			ChangePasswordDAOI changePassworddao = new ChangePasswordDAO();
			String oldPassword = request.getParameter("oldPassword");
			logger.debug("oldPassword-->" + oldPassword);

			try {
				String newPassword = request.getParameter("newPassword");
				logger.debug("newPassword-->" + newPassword);

				DESedeEncryption obj = new DESedeEncryption();
				String encryptednewpwd = obj.encrypt(newPassword);
				byte[] encodedBytes = Base64.encodeBase64(encryptednewpwd.getBytes());
				String encodeEncryptStr = new String(encodedBytes);
				Character[] charObjectArray = toCharacterArray(encodeEncryptStr);
				List<Character> list = new ArrayList<Character>(Arrays.asList(charObjectArray));
				compoundShuffle(list, 2, 4);
				StringBuilder sb = new StringBuilder();
				for (Character s : list) {
					sb.append(s);
				}
				String shuffleData = sb.toString();
				EncryptNewPwd = shuffleData + "24";
				logger.debug("EncryptNewPwd" + EncryptNewPwd);
			} catch (Exception e) {
				logger.debug("Exception while encryption in newPassword....");
				e.printStackTrace();
			}

			logger.debug("EncryptNewPwd newPassword-->" + EncryptNewPwd);

			if (!ClsUtil.isNullOrEmpty(EncryptNewPwd)) {
				// This Method is used to save password.
				result = changePassworddao.savePassword(oldPassword, EncryptNewPwd, userName, endurl);
			} else {
				result = -2;
			}

			// Password changed successfully
			if (result > 0) {
				logger.debug("Password changed successfully");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG020);
				session.invalidate();
				request.getRequestDispatcher("JSP/Login.jsp").forward(request, response);
			}
			// Entered password was incorrect
			else if (result == -1) {
				logger.debug("Entered password was incorrect");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG021);
				request.getRequestDispatcher("JSP/ChangePassword.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher("JSP/ChangePassword.jsp").forward(request, response);
			}
		} catch (Exception ex) {
			loggerErr.error("Exception in Change Password Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Change Password Servlet: " + totaltime);
	}

	public static Character[] toCharacterArray(String s) {

		try {
			if (s == null) {
				return null;
			}

			int len = s.length();
			Character[] array = new Character[len];
			for (int i = 0; i < len; i++) {
				array[i] = new Character(s.charAt(i));
			}

			return array;
		} catch (Exception e) {
			logger.debug("Exception in toCharacterArray in encryption in VP....");
			e.printStackTrace();
			return null;
		}
	}

	public static void compoundShuffle(List<?> list, int repetition, long seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < repetition; i++)
			Collections.shuffle(list, rand);

	}

}
