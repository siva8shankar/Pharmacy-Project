/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminUserDetailsServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminUserDetailsServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.AppliedUser;
import com.newgen.bean.VPUserMaster;
import com.newgen.dao.AdminUserDetailsDAO;
import com.newgen.dao.AdminUserDetailsDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class AdminUserDetailsServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminUserDetailsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		AdminUserDetailsDAOI userDetailsDao = new AdminUserDetailsDAO();

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		HttpSession session = null;
		int result = 0;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName") + " UserDetails"
					+ ": HiddenUserType: " + request.getParameter("hiddenHyperlink"));

			request.setAttribute("MSGCODE", null);
			String userType = request.getParameter("hiddenUserType");
			logger.debug("Inside AdminUserDetailsServlet UserType ########### " + userType);

			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenHyperlink"))
					&& request.getParameter("hiddenHyperlink").equalsIgnoreCase("UserDetails")) {

				String userName1 = request.getParameter("hiddenUsrName");

				// This Method is used to fetch user details.
				GeneralClass generalClass = userDetailsDao.getUserDetails(userName1, userType, endurl);

				request.setAttribute("hiddenUserType", userType);
				logger.debug("Inside IF AdminUserDetailsServlet ResultCode->" + generalClass.getResultCode());
				logger.debug("Inside  IF AdminUserDetailsServlet UserType->" + userType);
				if (generalClass.getResultCode() == 1) {
					if (!ClsUtil.isNullOrEmpty(userType) && userType.equalsIgnoreCase("RegUser")) {
						request.setAttribute("RegUserDetails", generalClass.getArrayRegisteredUser());
					} else {
						request.setAttribute("AppUserDetails", generalClass.getArrayAppliedUser());
					}
					request.setAttribute("userName1", userName1);
					request.setAttribute("Administration", "User Details");
					request.getRequestDispatcher("JSP/AdminUserDetails.jsp").forward(request, response);

				} else if (generalClass.getResultCode() == -1) {
					request.setAttribute("Administration", "User Details");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG029);
					request.getRequestDispatcher("JSP/AdminUserDetails.jsp").forward(request, response);
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.setAttribute("Administration", "User Details");
					request.getRequestDispatcher("JSP/AdminUserDetails.jsp").forward(request, response);
				}
			} else {
				logger.debug("Inside ELSE AdminUserDetailsServlet " + userType);
				String priviledge = null;
				String isUserActive = null;
				String islocked = null;
				if (!ClsUtil.isNullOrEmpty(userType) && userType.equalsIgnoreCase("RegUser")) {
					logger.debug("Inside ELSE AdminUserDetailsServlet Reg User");
					if (!ClsUtil.isNullOrEmpty(request.getParameter("privilege"))
							&& request.getParameter("privilege").equalsIgnoreCase("Admin")) {
						priviledge = "1";
					} else if (!ClsUtil.isNullOrEmpty(request.getParameter("privilege"))
							&& request.getParameter("privilege").equalsIgnoreCase("Vendor Supervisor")) {
						priviledge = "2";
					} else {
						priviledge = "3";
					}

					if (!ClsUtil.isNullOrEmpty(request.getParameter("isActive"))
							&& request.getParameter("isActive").equalsIgnoreCase("Yes")) {
						logger.debug("User is active");
						isUserActive = "Y";
					} else {
						logger.debug("User is not active");
						isUserActive = "N";
					}
					if (!ClsUtil.isNullOrEmpty(request.getParameter("islocked"))
							&& request.getParameter("islocked").equalsIgnoreCase("Yes")) {
						logger.debug("User is active");
						islocked = "Y";
					} else {
						logger.debug("User is not active");
						islocked = "N";
					}

					VPUserMaster userMaster = new VPUserMaster();
					userMaster.setUserName(request.getParameter("userName"));
					userMaster.setExpiryDateTime(request.getParameter("expiryDate"));
					userMaster.setPrivilege(priviledge);
					userMaster.setIsUserActive(isUserActive);
					userMaster.setLocked(islocked);
					userMaster.setVendorCode(request.getParameter("vendorCode"));
					userMaster.setVendorName(request.getParameter("vendorName"));
					userMaster.setVendorAddress(request.getParameter("vendorAdd"));
					userMaster.setUserEmailId(request.getParameter("emailId"));
					userMaster.setUserAddress(request.getParameter("address"));
					userMaster.setUserPhoneNumber(request.getParameter("phoneNo"));
					userMaster.setContactPersonName(request.getParameter("contactPersonName"));
					userMaster.setMobileNo(request.getParameter("mobileNo"));
					userMaster.setUserType(request.getParameter("usertype"));

					// This Method is used to update registered user
					result = userDetailsDao.updateRegUser(userMaster, endurl);
					logger.debug("Inside ELSE AdminUserDetailsServlet Reg User result--->" + result);

				} else {
					logger.debug("Inside ELSE AdminUserDetailsServlet Applied User" + request.getParameter("userName"));

					AppliedUser appliedUser = new AppliedUser();
					appliedUser.setUserName(request.getParameter("userName"));
					appliedUser.setVendorCode(request.getParameter("vendorCode"));
					appliedUser.setVendorName(request.getParameter("vendorName"));
					appliedUser.setVendorAdd(request.getParameter("vendorAdd"));
					appliedUser.setEmailId(request.getParameter("emailId"));
					appliedUser.setAddress(request.getParameter("address"));
					appliedUser.setPhoneNo(request.getParameter("phoneNo"));
					appliedUser.setContactPersonName(request.getParameter("contactPersonName"));
					appliedUser.setMobileNo(request.getParameter("mobileNo"));
					appliedUser.setPAN(request.getParameter("PAN"));
					appliedUser.setTAN(request.getParameter("TAN"));
					appliedUser.setServiceRegNo(request.getParameter("serviceRegNo"));
					appliedUser.setTIN(request.getParameter("TIN"));

					// This Method is used to update AppliedUser user details
					result = userDetailsDao.updateAppUser(appliedUser, endurl);
				}

				request.setAttribute("hiddenUserType", userType);
				// logger.debug("Inside ELSE AdminUserDetailsServlet Final
				// result--->"+result);

				// User Updated Successfully.
				if (result > 0) {
					logger.debug("User Updated Successfully");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG057);
					request.setAttribute("Administration", "Update User");
					request.getRequestDispatcher("AdminUserListServlet").forward(request, response);
				}

				// Server is down. Please login after sometime.
				else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.setAttribute("Administration", "Update User");
					request.getRequestDispatcher("AdminUserListServlet").forward(request, response);
				}

			}

		} catch (Exception e) {
			loggerErr.error("Exception in User Details Servlet : " + e.getMessage());
			e.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();

		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting User Details is : " + totaltime);
	}

}
