/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: LogOutServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class LogOutServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.VPUserMaster;
import com.newgen.dao.UserMasterDAO;
import com.newgen.dao.UserMasterDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.MultipartUtility;

public class LogOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private String cabinet = "", jtsIpAddress = "", jtsPort = "";
	private String OD_SessionURL = "", OD_Session_User = "", OD_Session_Pwd = "", WrapperPort = "", UserType = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		cabinet = (String) config.getServletContext().getAttribute("Cabinet");
		logger.debug("cabinet " + cabinet);
		OD_SessionURL = (String) config.getServletContext().getAttribute("OD_SessionURL");
		logger.debug("OD_SessionURL " + OD_SessionURL);
		OD_Session_User = (String) config.getServletContext().getAttribute("OD_Session_User");
		logger.debug("OD_Session_User " + OD_Session_User);
		OD_Session_Pwd = (String) config.getServletContext().getAttribute("OD_Session_Pwd");
		logger.debug("OD_Session_Pwd " + OD_Session_Pwd);
		WrapperPort = (String) config.getServletContext().getAttribute("WrapperPort");
		logger.debug("WrapperPort " + WrapperPort);
		UserType = (String) config.getServletContext().getAttribute("UserType");
		logger.debug("UserType " + UserType);
		jtsIpAddress = (String) config.getServletContext().getAttribute("jtsIpAddress");
		logger.debug("jtsIpAddress " + jtsIpAddress);
		jtsPort = (String) config.getServletContext().getAttribute("jtsPort");
		logger.debug("jtsPort " + jtsPort);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LogOutServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();
		HttpSession session = null;
		int result = 0;
		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// to check valid session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method of adminUserDao is ::" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");

				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			String UserName = (String) session.getAttribute("UserName");
			VPUserMaster VPUserMasterDO = new VPUserMaster();
			VPUserMasterDO.setUserName(UserName);

			UserMasterDAOI usermasterDAO = new UserMasterDAO();
			result = usermasterDAO.deleteLoggedInUser(VPUserMasterDO, endurl);
			if (result == 0) {

				session.invalidate();
				if (!ClsUtil.isNullOrEmpty(request.getAttribute("MSGCODE"))) {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG007);
				} else {
					request.setAttribute("MSGCODE", request.getAttribute("MSGCODE"));
				}
				response.sendRedirect(request.getContextPath() + "/login");
			}
		} catch (Exception e) {
			loggerErr.error("Exception in LogOut Servlet:" + e.getMessage());
			e.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in getting LogOut is :" + totaltime);

	}

}
