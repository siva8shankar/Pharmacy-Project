/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminChangePasswordServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminChangePasswordServlet. It is used to Change
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.newgen.dao.AdminChangePasswordDAO;
import com.newgen.dao.AdminChangePasswordDAOI;
import com.newgen.dao.AdminUserDAO;
import com.newgen.dao.AdminUserDAOI;
import com.newgen.lic.servlet.DESedeEncryption;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class AdminChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl is :: " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminChangePasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		int result = 0;
		long starttime = System.currentTimeMillis();
		HttpSession session = null;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// used to check session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			logger.debug("Session: " + session.getId() + "UserName:" + userName);

			request.setAttribute("MSGCODE", null);
			request.setAttribute("UserName", session.getAttribute("UserName"));
			request.setAttribute("SessionID", request.getSession().getId());

			AdminChangePasswordDAOI adminChangePassworddao = new AdminChangePasswordDAO();
			// String newPassword = request.getParameter("newPassword");
			String userName1 = request.getParameter("userName");
			String EncryptNewPwd = null;
			String newPassword = "";

			try {
				newPassword = request.getParameter("newPassword");
				DESedeEncryption obj = new DESedeEncryption();
				String encryptednewpwd = obj.encrypt(newPassword);
				byte[] encodedBytes = Base64.encodeBase64(encryptednewpwd.getBytes());
				String encodeEncryptStr = new String(encodedBytes);
				Character[] charObjectArray = toCharacterArray(encodeEncryptStr);
				List<Character> list = new ArrayList<Character>(Arrays.asList(charObjectArray));
				compoundShuffle(list, 2, 4);
				StringBuilder sb = new StringBuilder();
				for (Character s : list) {
					sb.append(s);
				}
				String shuffleData = sb.toString();
				EncryptNewPwd = shuffleData + "24";
				logger.debug("EncryptNewPwd" + EncryptNewPwd);
			} catch (Exception e) {
				logger.debug("Exception while encryption in newPassword....");
				e.printStackTrace();
			}

			// This Method is used to update password.
			result = adminChangePassworddao.changePassword(EncryptNewPwd, userName1, endurl);

			// Password changed successfully
			if (result > 0) {
				logger.debug("Password changed successfully");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG020);
				request.setAttribute("Administration", "Change Password");

				// Send Email Feature
				AdminUserDAOI adminUserDao = new AdminUserDAO();
				int mailResult = adminUserDao.sendEmailByAdmin(userName1, endurl, "AdminChangedPassword", newPassword);
				logger.debug("sendEmail method of AdminChangePasswordServlet-->" + mailResult);
				// Till Here

				request.getRequestDispatcher("JSP/AdminUserChangePassword.jsp").forward(request, response);
			} else {
				request.setAttribute("Administration", "Change Password");
				request.getRequestDispatcher("JSP/AdminUserChangePassword.jsp").forward(request, response);
			}
		} catch (Exception ex) {
			loggerErr.error("Exception in Changing password By Admin Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();

		}
		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;

		logger.debug("Total Time Taken in Changing password By Admin is " + totaltime);

	}

	public static Character[] toCharacterArray(String s) {

		try {
			if (s == null) {
				return null;
			}

			int len = s.length();
			Character[] array = new Character[len];
			for (int i = 0; i < len; i++) {
				array[i] = new Character(s.charAt(i));
			}

			return array;
		} catch (Exception e) {
			logger.debug("Exception in toCharacterArray in encryption in VP....");
			e.printStackTrace();
			return null;
		}
	}

	public static void compoundShuffle(List<?> list, int repetition, long seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < repetition; i++)
			Collections.shuffle(list, rand);

	}

}
