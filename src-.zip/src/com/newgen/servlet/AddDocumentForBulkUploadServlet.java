
/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AddDocumentForBulkUploadServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/08/2017
*    (DD/MM/YYYY)                      
*    Description                            	: File is used to upload bulk invoices
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/
package com.newgen.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.newgen.dao.WorkitemDAO;
import com.newgen.util.ClsExportExcel;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;
import com.newgen.util.MultipartFileUploader;
import com.newgen.util.MultipartUtility;

public class AddDocumentForBulkUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private String jtsIpAddress = "";
	private String jtsPort = "";
	private String OD_SessionURL = "", OD_Session_User = "", OD_Session_Pwd = "", WrapperPort = "", UserType = "",
			DataClass = "", DocIndexName1, DocIndexName2 = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		jtsIpAddress = (String) config.getServletContext().getAttribute("jtsIpAddress");
		logger.debug("jtsIpAddress " + jtsIpAddress);
		jtsPort = (String) config.getServletContext().getAttribute("jtsPort");
		logger.debug("jtsPort " + jtsPort);

		OD_SessionURL = (String) config.getServletContext().getAttribute("OD_SessionURL");
		logger.debug("OD_SessionURL " + OD_SessionURL);
		OD_Session_User = (String) config.getServletContext().getAttribute("OD_Session_User");
		logger.debug("OD_Session_User " + OD_Session_User);
		OD_Session_Pwd = (String) config.getServletContext().getAttribute("OD_Session_Pwd");
		logger.debug("OD_Session_Pwd " + OD_Session_Pwd);

		UserType = (String) config.getServletContext().getAttribute("UserType");
		logger.debug("UserType " + UserType);

	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddDocumentForBulkUploadServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		logger.debug("In doPost of AddDocumentServlet!!");

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		long starttime = System.currentTimeMillis();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String filePath = null;
		String Sessionid = "";
		String fileName = "";
		String fieldname = "";
		String invNo = "";
		String filesadded = "";
		String rowNo = "";
		try {
			MultipartUtility session = new MultipartUtility(OD_SessionURL, "UTF-8");
			Sessionid = session.getSessionValue(OD_SessionURL, OD_Session_User, OD_Session_Pwd, UserType);

			logger.debug("GetSessionOD->Sessionid:::" + Sessionid);

			ClsExportExcel ex = new ClsExportExcel();

			String serverPath = System.getProperty("user.dir");
			logger.debug("Working Directory = " + System.getProperty("user.dir"));
			String folderpath = "";
			String wi = "", Docname = "";
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			logger.debug("isMultipartContent::" + isMultipart);
			isMultipart = true;
			if (!isMultipart) {
				response.setStatus(501);
				out.println("is not Multipart Content!!");
				return;
			}
			List items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

			logger.debug("ServletFileUpload->items.size()::" + items.size());
			if (items.size() == 0) {
				response.setStatus(502);
				out.println("items size is 0!!");

				return;
			}

			Iterator iter = items.iterator();
			while (iter.hasNext()) {
				FileItem item = (FileItem) iter.next();
				if (item.isFormField()) {
				} else {
					long cdt = System.currentTimeMillis();
					folderpath = serverPath + File.separator + "Documents";
					File file = new File(folderpath);
					if (!file.isDirectory()) {
						file.mkdir();

					}

					String itemName = item.getName();
					itemName = itemName.substring(itemName.lastIndexOf("\\") + 1, itemName.length());// To
																										// be
																										// handled
																										// here
					fileName = itemName;

					filePath = folderpath + File.separator + cdt + "_" + itemName;

					File savedFile = new File(filePath);
					item.write(savedFile);
					logger.debug("filepath to be read: -------->" + savedFile);

					ArrayList<HashMap<Integer, List>> hashMap = new ArrayList<HashMap<Integer, List>>();

					hashMap = ex.readXLSFile(savedFile);
					logger.debug(" Hashmap values in adddoc" + hashMap.toString());
					logger.debug(" " + hashMap.size());
					HashMap<Integer, List> hm = new HashMap<Integer, List>();
					Set<Integer> keys = hashMap.get(0).keySet();
					logger.debug("Key Size" + keys.size());
					logger.debug("List -->" + hm.toString());

					if (hashMap.size() > 0 && ((keys.size() <= 11) && keys.size() > 1)) {
						logger.debug("Invoice List Found");
						logger.debug(hashMap.toString());

						request.setAttribute("SubmitBulkInvoice", hashMap);
						request.getRequestDispatcher("JSP/SubmitBulkInvoice.jsp").forward(request, response);
						hashMap.clear();

					} else {
						logger.debug("No Invoices List Found");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG039);
						request.setAttribute("Administration", "User List With Details");
						request.getRequestDispatcher("JSP/SubmitBulkInvoice.jsp").forward(request, response);
					}

				}
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			response.setStatus(503);
			e.printStackTrace();
			loggerErr.error("Exception in Uploading Document : " + e.getMessage());
		}

	}

}
