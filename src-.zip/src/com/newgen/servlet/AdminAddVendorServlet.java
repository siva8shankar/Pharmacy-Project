/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminAddVendorServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	:  Servlet implementation class AdminAddVendorServlet, It is used to add and update vendor details
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.bean.VendorMaster;
import com.newgen.dao.AdminNewVendorDAO;
import com.newgen.dao.AdminNewVendorDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;
import com.newgen.util.GeneralClass;

public class AdminAddVendorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String endurl = "";
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("endurl " + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminAddVendorServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug("Adding New Vendor By Admin........");

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		VendorMaster vendorMaster = new VendorMaster();
		AdminNewVendorDAOI adminNewVendorDAO = new AdminNewVendorDAO();
		int result = 0;

		HttpSession session = null;

		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// used to check session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session: " + session.getId() + "UserName:" + userName + " HiddenHypeLink===>"
					+ request.getParameter("hiddenHyperlink"));

			request.setAttribute("MSGCODE", null);

			// Used to Add New Vendor
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenHyperlink"))
					&& request.getParameter("hiddenHyperlink").equalsIgnoreCase("AddNewVendor")) {
				request.getRequestDispatcher("JSP/AdminAddNewVendor.jsp").forward(request, response);
			}

			// It is used to update Vendor Details
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenHyperlink"))
					&& request.getParameter("hiddenHyperlink").equalsIgnoreCase("VendorDetails")) {

				String vendorCode = request.getParameter("hiddenVendorCode");

				// Used to get company details i.e. Vendor name, code, address
				// etc
				GeneralClass generalClass = adminNewVendorDAO.getVendorDetails(vendorCode, endurl);
				if (!ClsUtil.isNullOrEmpty(generalClass.getArrayVendorList())
						&& generalClass.getArrayVendorList().size() > 0) {
					request.setAttribute("hiddenHyperlink", "VendorDetails");
					request.setAttribute("Administration", "Vendor Details");
					request.setAttribute("ArrayVendorDetails", generalClass.getArrayVendorList().get(0));
					request.getRequestDispatcher("JSP/AdminAddNewVendor.jsp").forward(request, response);
				} else {
					request.setAttribute("hiddenHyperlink", "VendorDetails");
					request.setAttribute("Administration", "Vendor Details");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.getRequestDispatcher("JSP/AdminAddNewVendor.jsp").forward(request, response);
				}

			} else {

				String tempVendorCode = null;
				String tempCompanyCode = null;
				vendorMaster.setUserId(request.getParameter("userId"));
				vendorMaster.setVendorCode(request.getParameter("vendorCode"));
				vendorMaster.setVendorName(request.getParameter("vendorName"));
				vendorMaster.setVendorAddress(request.getParameter("vendorAdd"));
				vendorMaster.setVendorEmailId(request.getParameter("vendorEmailId"));
				vendorMaster.setContactPersonName(request.getParameter("contactPersonName"));
				vendorMaster.setMobileNo(request.getParameter("mobileNo"));
				vendorMaster.setPAN(request.getParameter("PAN"));
				vendorMaster.setTAN(request.getParameter("TAN"));
				vendorMaster.setServiceRegNo(request.getParameter("serviceRegNo"));
				vendorMaster.setTIN(request.getParameter("TIN"));
				vendorMaster.setFormStatus(request.getParameter("formStatus"));

				vendorMaster.setTelephoneNo(request.getParameter("telephoneNo"));
				if (!ClsUtil.isNullOrEmpty(request.getParameter("ButtonType"))
						&& request.getParameter("ButtonType").equalsIgnoreCase("Update")) {
					tempVendorCode = request.getParameter("hiddenTempVendorCode");
					tempCompanyCode = request.getParameter("hiddenTempCompanyCode");
				}

				// add and update vendor
				result = adminNewVendorDAO.addNewVendor(vendorMaster, request.getParameter("ButtonType"),
						tempVendorCode, tempCompanyCode, endurl);

				// Vendor Updated Successfully
				if (result > 0) {
					if (result == 11) {
						logger.debug("Vendor Updated Successfully");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG044);
					} else if (result == 12) {
						logger.debug("User Added Successfully");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG030);
					} else if (result == 13) {
						logger.debug("Exception while Adding User");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG024);
					} else if (!ClsUtil.isNullOrEmpty(request.getParameter("ButtonType"))
							&& request.getParameter("ButtonType").equalsIgnoreCase("Update")) {
						logger.debug("Vendor Updated Successfully");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG044);
					} else {
						// Vendor Added Successfully.
						logger.debug("Vendor Added Successfully");
						request.setAttribute("MSGCODE", ClsMessageHandler.MSG038);
					}
					request.setAttribute("Administration", "Add Vendor");
					request.getRequestDispatcher("JSP/AdminAddNewVendor.jsp").forward(request, response);

					// When Company Code Not Exist
				} else if (result == -1) {
					logger.debug("Company Code Does Not Exist");
					request.setAttribute("Administration", "Add Vendor");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG045);
					request.getRequestDispatcher("JSP/AdminAddNewVendor.jsp").forward(request, response);

					// When Vendor With Same Vendor Code And Same Company Code.
				} else if (result == -2) {
					logger.debug("Vendor With Same Vendor Code And Same Company Code Exist");
					request.setAttribute("Administration", "Add Vendor");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG067);
					request.getRequestDispatcher("JSP/AdminAddNewVendor.jsp").forward(request, response);
				} else {
					// No Vendor Found
					logger.debug("No Vendor Found");
					request.setAttribute("Administration", "Add Vendor");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG036);
					request.getRequestDispatcher("JSP/AdminAddNewVendor.jsp").forward(request, response);
				}
			}

		} catch (Exception ex) {
			loggerErr.error("Exception in Admin Add Vendor Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Adding Vendor is " + totaltime);
	}

}
