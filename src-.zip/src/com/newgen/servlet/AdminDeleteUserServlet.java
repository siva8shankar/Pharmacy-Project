/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminDeleteUserServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminDeleteUserServlet, Used to Delete User
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminNewUserDAO;
import com.newgen.dao.AdminNewUserDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class AdminDeleteUserServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext()
				.getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminDeleteUserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		long starttime = System.currentTimeMillis();
		logger.debug("Delete User By Admin");
		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName",
				request.getSession().getAttribute("UserName"));

		AdminNewUserDAOI adminNewUserDao = new AdminNewUserDAO();
		int result = 0;
		String[] regUserNames = null;
		HttpSession session = null;

		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId,
					endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath()
						+ "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:"
					+ session.getAttribute("UserName") + " Admin deleting User");

			if (!ClsUtil.isNullOrEmpty(request
					.getParameter("hiddenDeleteInline"))
					&& request.getParameter("hiddenDeleteInline")
							.equalsIgnoreCase("Inline")) {
				regUserNames = new String[1];
				regUserNames[0] = request.getParameter("hiddenUsrName");
				result = adminNewUserDao.deleteUser(regUserNames, endurl);

			} else {
				regUserNames = request.getParameterValues("check");

				// This Method is used to delete User.
				result = adminNewUserDao.deleteUser(regUserNames, endurl);
			}
			// User Deleted Successfully.
			if (result == 2) {
				logger.debug("Admin User(S) cannot be Deleted");
				request.setAttribute("Administration", "Delete User");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG092);
				request.getRequestDispatcher("AdminUserListServlet").forward(
						request, response);

			}
			else if (result > 0) {
				logger.debug("User Deleted Successfully.");
				request.setAttribute("Administration", "Delete User");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG032);
				request.getRequestDispatcher("AdminUserListServlet").forward(
						request, response);

			}
			// UserName Doesn't Exist.
			else if (result == -1) {
				logger.debug("User Doesn't Exist.");
				request.setAttribute("Administration", "Delete User");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG033);
				request.getRequestDispatcher("JSP/AdminUserList.jsp").forward(
						request, response);
			} else {
				request.setAttribute("Administration", "Delete User");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
				request.getRequestDispatcher("JSP/AdminUserList.jsp").forward(
						request, response);
			}

		} catch (Exception ex) {
			loggerErr.error("Exception in Admin Delete User Servlet : "
					+ ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request,
					response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Deleting New User is : " + totaltime);
	}

}
