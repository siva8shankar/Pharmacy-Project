/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminDeleteInvoiceServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminDeleteInvoiceServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminDeleteDAO;
import com.newgen.dao.AdminDeleteDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsUtil;

public class AdminDeleteInvoiceServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminDeleteInvoiceServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug(" Deletion of Invoice By Admin");

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		AdminDeleteDAOI adminDeleteDAO = new AdminDeleteDAO();
		int result = 0;

		HttpSession session = null;

		try {
			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// This Method is used to check the session
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName")
					+ " Deleting Invoice");

			request.setAttribute("MSGCODE", null);
			String invoiceId = request.getParameter("hiddenInvId");

			// This Method is used to delete Invoice.
			result = adminDeleteDAO.deleteInvoice(invoiceId, endurl);

			// Invoice Deleted Successfully.
			if (result > 0) {
				logger.debug("Invoice Deleted Successfully.");
				request.setAttribute("Administration", "Delete Invoice");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG059);
				request.getRequestDispatcher("SearchStatusServlet").forward(request, response);
			} else {
				logger.debug("Server is down. Please login after sometime.");
				request.setAttribute("Administration", "Delete Invoice");
				request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
				request.getRequestDispatcher("JSP/VendorSearch.jsp").forward(request, response);
			}
		} catch (Exception ex) {
			loggerErr.error("Exception in Admin Deleting Invoice Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Deleting Invoice is : " + totaltime);
	}

}
