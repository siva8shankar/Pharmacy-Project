/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: AdminVendorDisableServlet.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: Servlet implementation class AdminVendorDisableServlet
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.newgen.dao.AdminUserDAO;
import com.newgen.dao.AdminUserDAOI;
import com.newgen.dao.UserMasterDAO;
import com.newgen.dao.UserMasterDAOI;
import com.newgen.util.ClsCheckSession;
import com.newgen.util.ClsMessageHandler;
import com.newgen.util.ClsSendEmail;
import com.newgen.util.ClsUtil;

public class AdminVendorDisableServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger("consoleLogger");
	private static Logger loggerErr = Logger.getLogger("errorLogger");
	private static final long serialVersionUID = 1L;
	private String endurl = "";

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		endurl = (String) config.getServletContext().getAttribute("EndPointURL");
		logger.debug("Endurl is :" + endurl);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminVendorDisableServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		long starttime = System.currentTimeMillis();

		logger.debug(" Deletion of Vendor By Admin");

		request.setAttribute("SessionID", request.getSession().getId());
		request.setAttribute("UserName", request.getSession().getAttribute("UserName"));

		UserMasterDAOI userMasterDAO = new UserMasterDAO();
		int result = 0;

		HttpSession session = null;
		String strUserName = null;
		String strVenCodes = null;
		try {

			session = request.getSession();
			String userName = (String) session.getAttribute("UserName");
			String sessionId = session.getId();

			// Method is used to check session, Whether session is valid or not.
			result = ClsCheckSession.checkValidSession(userName, sessionId, endurl);
			logger.debug("result of checkValidSession method is :" + result);

			if (result != 1) {
				response.sendRedirect(request.getContextPath() + "/JSP/Login.jsp");
				return;
			}
			if (ClsUtil.isNullOrEmpty(session.getAttribute("UserName"))) {
				logger.debug("This is valid not access to this page. Please come via proper login--");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}
			if (ClsUtil.isNullOrEmpty(request.getHeader("Referer"))) {
				logger.debug("Application has already been opened in other tab.");
				response.sendRedirect(request.getContextPath() + "/login");
				return;
			}

			logger.debug("Session:" + session.getId() + " UserName:" + session.getAttribute("UserName")
					+ " Admin Deleting Vendor");

			request.setAttribute("MSGCODE", null);
			// Disable vendor
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenDisableInline"))
					&& request.getParameter("hiddenDisableInline").equalsIgnoreCase("DisableVendor")) {

				strVenCodes = new String();
				strVenCodes = request.getParameter("hiddenVendorCode");

				// Method is for disable vendor
				result = userMasterDAO.disableVendor(strVenCodes, endurl);

				// Vendor Disabled Successfully
				if (result > 0) {
					logger.debug("Vendor Disabled Successfully");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG075);
					request.getRequestDispatcher("AdminVendorListServlet").forward(request, response);
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.getRequestDispatcher("JSP/AdminVendorList.jsp").forward(request, response);
				}
			}
			// For Enable vendor
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenDisableInline"))
					&& request.getParameter("hiddenDisableInline").equalsIgnoreCase("EnableVendor")) {

				strVenCodes = new String();
				strVenCodes = request.getParameter("hiddenVendorCode");

				// Method is for disable vendor
				result = userMasterDAO.enableVendor(strVenCodes, endurl);

				// Vendor Enabled Successfully
				if (result > 0) {
					logger.debug("Vendor Enabled Successfully");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG078);

					request.getRequestDispatcher("AdminVendorListServlet").forward(request, response);
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.getRequestDispatcher("JSP/AdminVendorList.jsp").forward(request, response);
				}
			}
			// When Disable User
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenDisableInline"))
					&& request.getParameter("hiddenDisableInline").equalsIgnoreCase("DisableUser")) {
				strUserName = new String();
				strUserName = request.getParameter("hiddenUsrName");

				// Method is for disable vendor
				result = userMasterDAO.disableUser(strUserName, endurl);

				// User Disabled Successfully
				if (result > 0) {
					logger.debug("User Disabled Successfully");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG076);

					AdminUserDAOI adminUserDao = new AdminUserDAO();
					int mailResult = adminUserDao.sendEmailonEnable(strUserName, endurl, "Disable");
					logger.debug("sendEmail method of AdminVendorDisableServlet-->" + mailResult);
					// Till Here

					request.getRequestDispatcher("AdminUserListServlet").forward(request, response);
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.getRequestDispatcher("JSP/AdminUserList.jsp").forward(request, response);
				}
			}

			// Enable User
			if (!ClsUtil.isNullOrEmpty(request.getParameter("hiddenDisableInline"))
					&& request.getParameter("hiddenDisableInline").equalsIgnoreCase("EnableUser")) {
				strUserName = new String();
				strUserName = request.getParameter("hiddenUsrName");

				// Method is for Enable User
				result = userMasterDAO.enableUser(strUserName, endurl);

				// User Enabled Successfully
				if (result > 0) {
					logger.debug("User Enabled Successfully");
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG077);

					AdminUserDAOI adminUserDao = new AdminUserDAO();
					int mailResult = adminUserDao.sendEmailonEnable(strUserName, endurl, "Enable");
					logger.debug("sendEmail method of AdminVendorDisableServlet-->" + mailResult);
					// Till Here

					request.getRequestDispatcher("AdminUserListServlet").forward(request, response);
				} else {
					request.setAttribute("MSGCODE", ClsMessageHandler.MSG014);
					request.getRequestDispatcher("JSP/AdminUserList.jsp").forward(request, response);
				}
			}
		} catch (Exception ex) {
			loggerErr.error("Exception in Admin disabling Vendor Servlet : " + ex.getMessage());
			ex.printStackTrace();
			request.getRequestDispatcher("JSP/Error.jsp").forward(request, response);
			session.invalidate();
		}

		long endTime = System.currentTimeMillis();
		long totaltime = endTime - starttime;
		logger.debug("Total Time Taken in Deleting Vendor is : " + totaltime);
	}
}
