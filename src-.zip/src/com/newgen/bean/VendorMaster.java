/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorMaster.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class VendorMaster {

	String VendorID;
	String VendorCode;
	String VendorName;
	String VendorAddress;
	String VendorEmailId;
	String SPOC;
	String SPOCEmailId;
	String Currency;
	String CompanyCode;
	String IsVendorActive;
	String userId;
	String contactPersonName;
	String mobileNo;
	String telephoneNo;
	String PAN;
	String TAN;
	String serviceRegNo;
	String TIN;
	String formStatus;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}

	public String getPAN() {
		return PAN;
	}

	public void setPAN(String pAN) {
		PAN = pAN;
	}

	public String getTAN() {
		return TAN;
	}

	public void setTAN(String tAN) {
		TAN = tAN;
	}

	public String getServiceRegNo() {
		return serviceRegNo;
	}

	public void setServiceRegNo(String serviceRegNo) {
		this.serviceRegNo = serviceRegNo;
	}

	public String getTIN() {
		return TIN;
	}

	public void setTIN(String tIN) {
		TIN = tIN;
	}

	public void setVendorID(String vendorID) {
		VendorID = vendorID;
	}

	public String getIsVendorActive() {
		return IsVendorActive;
	}

	public void setIsVendorActive(String isVendorActive) {
		IsVendorActive = isVendorActive;
	}

	public String getVendorCode() {
		return VendorCode;
	}

	public void setVendorCode(String pVendorCode) {
		VendorCode = pVendorCode;
	}

	public String getVendorName() {
		return VendorName;
	}

	public void setVendorName(String pVendorName) {
		VendorName = pVendorName;
	}

	public String getVendorAddress() {
		return VendorAddress;
	}

	public void setVendorAddress(String pVendorAddress) {
		VendorAddress = pVendorAddress;
	}

	public String getVendorEmailId() {
		return VendorEmailId;
	}

	public void setVendorEmailId(String pVendorEmailId) {
		VendorEmailId = pVendorEmailId;
	}

	public String getSPOC() {
		return SPOC;
	}

	public void setSPOC(String pSPOC) {
		SPOC = pSPOC;
	}

	public String getSPOCEmailId() {
		return SPOCEmailId;
	}

	public void setSPOCEmailId(String pSPOCEmailId) {
		SPOCEmailId = pSPOCEmailId;
	}

	public String getCurrency() {
		return Currency;
	}

	public void setCurrency(String pCurrency) {
		Currency = pCurrency;
	}

	public String getCompanyCode() {
		return CompanyCode;
	}

	public void setCompanyCode(String pCompanyCode) {
		CompanyCode = pCompanyCode;
	}

	public String getVendorID() {
		return VendorID;
	}

	public String getFormStatus() {
		return formStatus;
	}

	public void setFormStatus(String formStatus) {
		this.formStatus = formStatus;
	}

}
