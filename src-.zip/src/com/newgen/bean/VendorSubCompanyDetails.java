/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorSubCompanyDetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class VendorSubCompanyDetails {

	String SName;
	String SDUNS;
	String SCountry;
	String SAddress;
	String STAXRegistrtn;
	String SWebsite;
	String SEmailId;

	public String getSName() {
		return SName;
	}

	public void setSName(String sName) {
		SName = sName;
	}

	public String getSDUNS() {
		return SDUNS;
	}

	public void setSDUNS(String sDUNS) {
		SDUNS = sDUNS;
	}

	public String getSCountry() {
		return SCountry;
	}

	public void setSCountry(String sCountry) {
		SCountry = sCountry;
	}

	public String getSAddress() {
		return SAddress;
	}

	public void setSAddress(String sAddress) {
		SAddress = sAddress;
	}

	public String getSTAXRegistrtn() {
		return STAXRegistrtn;
	}

	public void setSTAXRegistrtn(String sTAXRegistrtn) {
		STAXRegistrtn = sTAXRegistrtn;
	}

	public String getSWebsite() {
		return SWebsite;
	}

	public void setSWebsite(String sWebsite) {
		SWebsite = sWebsite;
	}

	public String getSEmailId() {
		return SEmailId;
	}

	public void setSEmailId(String sEmailId) {
		SEmailId = sEmailId;
	}

}
