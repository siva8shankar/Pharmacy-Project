/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: InvoiceXML.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class InvoiceXML {

	String Name = "";
	String FieldCaption = "";
	String DataField = "";
	String Length = "";
	String DataType = "";
	String FieldType = "";
	String MaxLength = "";
	String ReadOnly = "";
	String Value = "";
	String Disabled = "";
	String Mandatory = "";
	String id = "";
	String feildOrder;
	String onBlur;
	String onKeyPress;
	String onKeyDown;
	String onChange;
	String onClick;
	String active;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getFieldCaption() {
		return FieldCaption;
	}

	public void setFieldCaption(String fieldCaption) {
		FieldCaption = fieldCaption;
	}

	public String getDataField() {
		return DataField;
	}

	public void setDataField(String dataField) {
		DataField = dataField;
	}

	public String getLength() {
		return Length;
	}

	public void setLength(String length) {
		Length = length;
	}

	public String getDataType() {
		return DataType;
	}

	public void setDataType(String dataType) {
		DataType = dataType;
	}

	public String getFieldType() {
		return FieldType;
	}

	public void setFieldType(String fieldType) {
		FieldType = fieldType;
	}

	public String getMaxLength() {
		return MaxLength;
	}

	public void setMaxLength(String maxLength) {
		MaxLength = maxLength;
	}

	public String getReadOnly() {
		return ReadOnly;
	}

	public void setReadOnly(String readOnly) {
		ReadOnly = readOnly;
	}

	public String getValue() {
		return Value;
	}

	public void setValue(String value) {
		Value = value;
	}

	public String getDisabled() {
		return Disabled;
	}

	public void setDisabled(String disabled) {
		Disabled = disabled;
	}

	public String getMandatory() {
		return Mandatory;
	}

	public void setMandatory(String mandatory) {
		Mandatory = mandatory;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getfeildOrder() {
		return feildOrder;
	}

	public void setfeildOrder(String feildOrder) {
		this.feildOrder = feildOrder;
	}

	public String getOnBlur() {
		return onBlur;
	}

	public void setOnBlur(String onBlur) {
		this.onBlur = onBlur;
	}

	public String getOnKeyPress() {
		return onKeyPress;
	}

	public void setOnKeyPress(String onKeyPress) {
		this.onKeyPress = onKeyPress;
	}

	public String getOnKeyDown() {
		return onKeyDown;
	}

	public void setOnKeyDown(String onKeyDown) {
		this.onKeyDown = onKeyDown;
	}

	public String getOnChange() {
		return onChange;
	}

	public void setOnChange(String onChange) {
		this.onChange = onChange;
	}

	public String getOnClick() {
		return onClick;
	}

	public void setOnClick(String onClick) {
		this.onClick = onClick;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

}
