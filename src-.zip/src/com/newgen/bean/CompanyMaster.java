/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: CompanyMaster.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.ArrayList;
import java.util.HashMap;

public class CompanyMaster {
	int CompanyID;
	String CompanyCode;
	String CompanyName;
	String CompanyAddress;
	String Country;

	HashMap<String, ArrayList<String>> CompanyDataMap;

	public HashMap<String, ArrayList<String>> getCompanyDataMap() {
		return CompanyDataMap;
	}

	public void setCompanyDataMap(HashMap<String, ArrayList<String>> companyDataMap) {
		CompanyDataMap = companyDataMap;
	}

	public int getCompanyID() {
		return CompanyID;
	}

	public void setCompanyID(int pCompanyID) {
		CompanyID = pCompanyID;
	}

	public String getCompanyCode() {
		return CompanyCode;
	}

	public void setCompanyCode(String pCompanyCode) {
		CompanyCode = pCompanyCode;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String pCompanyName) {
		CompanyName = pCompanyName;
	}

	public String getCompanyAddress() {
		return CompanyAddress;
	}

	public void setCompanyAddress(String pCompanyAddress) {
		CompanyAddress = pCompanyAddress;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String pCountry) {
		Country = pCountry;
	}
}
