/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: PoMaster.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class PoMaster {
	int POID;
	String PONumber;
	String VendorCode;
	String CompanyCode;
	String ExpenseGLCode;
	String CostCenter;
	String TaxCode;
	String TaxDescription;
	String CURRENCY;
	String PaymentTerms;
	String PaymentDescription;

	public int getPOID() {
		return POID;
	}

	public String getPONumber() {
		return PONumber;
	}

	public void setPONumber(String pPONumber) {
		PONumber = pPONumber;
	}

	public String getVendorCode() {
		return VendorCode;
	}

	public void setVendorCode(String pVendorCode) {
		VendorCode = pVendorCode;
	}

	public String getCompanyCode() {
		return CompanyCode;
	}

	public void setCompanyCode(String pCompanyCode) {
		CompanyCode = pCompanyCode;
	}

	public String getExpenseGLCode() {
		return ExpenseGLCode;
	}

	public void setExpenseGLCode(String pExpenseGLCode) {
		ExpenseGLCode = pExpenseGLCode;
	}

	public String getCostCenter() {
		return CostCenter;
	}

	public void setCostCenter(String pCostCenter) {
		CostCenter = pCostCenter;
	}

	public String getTaxCode() {
		return TaxCode;
	}

	public void setTaxCode(String pTaxCode) {
		TaxCode = pTaxCode;
	}

	public String getTaxDescription() {
		return TaxDescription;
	}

	public void setTaxDescription(String pTaxDescription) {
		TaxDescription = pTaxDescription;
	}

	public String getCURRENCY() {
		return CURRENCY;
	}

	public void setCURRENCY(String pCURRENCY) {
		CURRENCY = pCURRENCY;
	}

	public String getPaymentTerms() {
		return PaymentTerms;
	}

	public void setPaymentTerms(String pPaymentTerms) {
		PaymentTerms = pPaymentTerms;
	}

	public String getPaymentDescription() {
		return PaymentDescription;
	}

	public void setPaymentDescription(String pPaymentDescription) {
		PaymentDescription = pPaymentDescription;
	}
}
