package com.newgen.bean;

public class TCInvoiceDetails {
	String ItemIndex,PID,Plant,Quantity,Structure,Comment,EDD,DeliveryDate,Status,ActivityName,TCReqNO,Breadth,Cutoff,SKU;
	int InvoiceId;
	
	public String getItemIndex() {
		return ItemIndex;
	}
	public void setItemIndex(String itemIndex) {
		ItemIndex = itemIndex;
	}
	public String getPID() {
		return PID;
	}
	public void setPID(String pID) {
		PID = pID;
	}
	public String getPlant() {
		return Plant;
	}
	public void setPlant(String plant) {
		Plant = plant;
	}
	public String getQuantity() {
		return Quantity;
	}
	public void setQuantity(String quantity) {
		Quantity = quantity;
	}
	public String getStructure() {
		return Structure;
	}
	public void setStructure(String structure) {
		Structure = structure;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}
	public String getEDD() {
		return EDD;
	}
	public void setEDD(String eDD) {
		EDD = eDD;
	}
	public String getDeliveryDate() {
		return DeliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		DeliveryDate = deliveryDate;
	}
	public int getInvoiceId() {
		return InvoiceId;
	}
	public void setInvoiceId(int invoiceId) {
		InvoiceId = invoiceId;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getActivityName() {
		return ActivityName;
	}
	public void setActivityName(String activityName) {
		ActivityName = activityName;
	}
	public String getTCReqNO() {
		return TCReqNO;
	}
	public void setTCReqNO(String tCReqNO) {
		TCReqNO = tCReqNO;
	}
	public String getBreadth() {
		return Breadth;
	}
	public void setBreadth(String breadth) {
		Breadth = breadth;
	}
	public String getCutoff() {
		return Cutoff;
	}
	public void setCutoff(String cutoff) {
		Cutoff = cutoff;
	}
	public String getSKU() {
		return SKU;
	}
	public void setSKU(String sKU) {
		SKU = sKU;
	}
	
	
}
