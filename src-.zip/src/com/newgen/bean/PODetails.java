/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: PODetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.Date;

public class PODetails {
	String POID;

	String PONumber;
	String UserName;
	String SubmittoCompany;
	String CompanyAddress;
	String AttentionTo;
	String VendorCode;
	String VendorName;
	String VendorAddress;
	String InvoiceType;
	String InvoiceNumber;
	String InvoiceDate;

	String Currency;
	String GrossAmount;
	String TotalTax;
	String Freight;
	String Discount;
	String NetAmount;
	String ServiceTax;
	String EducationCess;
	String VAT;
	String AdditionalVAT;
	String AnyOtherTax;
	String DeliveryDate;
	String SearchKey;

	public String getPOID() {
		return POID;
	}

	public void setPOID(String pOID) {
		POID = pOID;
	}

	public String getPONumber() {
		return PONumber;
	}

	public void setPONumber(String pONumber) {
		PONumber = pONumber;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getSubmittoCompany() {
		return SubmittoCompany;
	}

	public void setSubmittoCompany(String submittoCompany) {
		SubmittoCompany = submittoCompany;
	}

	public String getCompanyAddress() {
		return CompanyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		CompanyAddress = companyAddress;
	}

	public String getAttentionTo() {
		return AttentionTo;
	}

	public void setAttentionTo(String attentionTo) {
		AttentionTo = attentionTo;
	}

	public String getVendorCode() {
		return VendorCode;
	}

	public void setVendorCode(String vendorCode) {
		VendorCode = vendorCode;
	}

	public String getVendorName() {
		return VendorName;
	}

	public void setVendorName(String vendorName) {
		VendorName = vendorName;
	}

	public String getVendorAddress() {
		return VendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		VendorAddress = vendorAddress;
	}

	public String getInvoiceType() {
		return InvoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		InvoiceType = invoiceType;
	}

	public String getInvoiceNumber() {
		return InvoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		InvoiceNumber = invoiceNumber;
	}

	public String getInvoiceDate() {
		return InvoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		InvoiceDate = invoiceDate;
	}

	public String getCurrency() {
		return Currency;
	}

	public void setCurrency(String currency) {
		Currency = currency;
	}

	public String getGrossAmount() {
		return GrossAmount;
	}

	public void setGrossAmount(String grossAmount) {
		GrossAmount = grossAmount;
	}

	public String getTotalTax() {
		return TotalTax;
	}

	public void setTotalTax(String totalTax) {
		TotalTax = totalTax;
	}

	public String getFreight() {
		return Freight;
	}

	public void setFreight(String freight) {
		Freight = freight;
	}

	public String getDiscount() {
		return Discount;
	}

	public void setDiscount(String discount) {
		Discount = discount;
	}

	public String getNetAmount() {
		return NetAmount;
	}

	public void setNetAmount(String netAmount) {
		NetAmount = netAmount;
	}

	public String getServiceTax() {
		return ServiceTax;
	}

	public void setServiceTax(String serviceTax) {
		ServiceTax = serviceTax;
	}

	public String getEducationCess() {
		return EducationCess;
	}

	public void setEducationCess(String educationCess) {
		EducationCess = educationCess;
	}

	public String getVAT() {
		return VAT;
	}

	public void setVAT(String vAT) {
		VAT = vAT;
	}

	public String getAdditionalVAT() {
		return AdditionalVAT;
	}

	public void setAdditionalVAT(String additionalVAT) {
		AdditionalVAT = additionalVAT;
	}

	public String getAnyOtherTax() {
		return AnyOtherTax;
	}

	public void setAnyOtherTax(String anyOtherTax) {
		AnyOtherTax = anyOtherTax;
	}

	public String getDeliveryDate() {
		return DeliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		DeliveryDate = deliveryDate;
	}

	public String getSearchKey() {
		return SearchKey;
	}

	public void setSearchKey(String searchKey) {
		SearchKey = searchKey;
	}
	

}
