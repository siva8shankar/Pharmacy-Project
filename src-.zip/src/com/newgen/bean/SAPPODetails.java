/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SAPPODetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 26/10/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class SAPPODetails {
	String PONumber, POAmount, POOpenAmount, VendorName, VendorCode, BusinessArea, CompanyCode, TaxCode, OrderType;
	String POItemNumber, MaterialCode, MaterialDescription, UnitPrice, UnitofMeasure, Quantity, Amount;
	String TransactionID;

	public String getPONumber() {
		return PONumber;
	}

	public void setPONumber(String pONumber) {
		PONumber = pONumber;
	}

	public String getPOAmount() {
		return POAmount;
	}

	public void setPOAmount(String pOAmount) {
		POAmount = pOAmount;
	}

	public String getPOOpenAmount() {
		return POOpenAmount;
	}

	public void setPOOpenAmount(String pOOpenAmount) {
		POOpenAmount = pOOpenAmount;
	}

	public String getVendorName() {
		return VendorName;
	}

	public void setVendorName(String vendorName) {
		VendorName = vendorName;
	}

	public String getVendorCode() {
		return VendorCode;
	}

	public void setVendorCode(String vendorCode) {
		VendorCode = vendorCode;
	}

	public String getBusinessArea() {
		return BusinessArea;
	}

	public void setBusinessArea(String businessArea) {
		BusinessArea = businessArea;
	}

	public String getCompanyCode() {
		return CompanyCode;
	}

	public void setCompanyCode(String companyCode) {
		CompanyCode = companyCode;
	}

	public String getTaxCode() {
		return TaxCode;
	}

	public void setTaxCode(String taxCode) {
		TaxCode = taxCode;
	}

	public String getOrderType() {
		return OrderType;
	}

	public void setOrderType(String orderType) {
		OrderType = orderType;
	}

	public String getPOItemNumber() {
		return POItemNumber;
	}

	public void setPOItemNumber(String pOItemNumber) {
		POItemNumber = pOItemNumber;
	}

	public String getMaterialCode() {
		return MaterialCode;
	}

	public void setMaterialCode(String materialCode) {
		MaterialCode = materialCode;
	}

	public String getMaterialDescription() {
		return MaterialDescription;
	}

	public void setMaterialDescription(String materialDescription) {
		MaterialDescription = materialDescription;
	}

	public String getUnitPrice() {
		return UnitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		UnitPrice = unitPrice;
	}

	public String getUnitofMeasure() {
		return UnitofMeasure;
	}

	public void setUnitofMeasure(String unitofMeasure) {
		UnitofMeasure = unitofMeasure;
	}

	public String getQuantity() {
		return Quantity;
	}

	public void setQuantity(String quantity) {
		Quantity = quantity;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String amount) {
		Amount = amount;
	}

	public String getTransactionID() {
		return TransactionID;
	}

	public void setTransactionID(String transactionID) {
		TransactionID = transactionID;
	}

}
