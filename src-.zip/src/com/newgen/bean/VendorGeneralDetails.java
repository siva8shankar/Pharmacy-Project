/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorGeneralDetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class VendorGeneralDetails {

	String CompanyName;
	String TaxCountry;
	String VendorCode;
	String TaxRegistrationNumber;
	String TaxpayerID;
	String DUNSNumber;
	String Email;
	String FirstName;
	String LastName;
	String PhoneAreaCode;
	String PhoneNumber;
	String PhoneExtension;

	public String getVendorCode() {
		return VendorCode;
	}

	public void setVendorCode(String vendorCode) {
		VendorCode = vendorCode;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public String getTaxCountry() {
		return TaxCountry;
	}

	public void setTaxCountry(String taxCountry) {
		TaxCountry = taxCountry;
	}

	public String getTaxRegistrationNumber() {
		return TaxRegistrationNumber;
	}

	public void setTaxRegistrationNumber(String taxRegistrationNumber) {
		TaxRegistrationNumber = taxRegistrationNumber;
	}

	public String getTaxpayerID() {
		return TaxpayerID;
	}

	public void setTaxpayerID(String taxpayerID) {
		TaxpayerID = taxpayerID;
	}

	public String getDUNSNumber() {
		return DUNSNumber;
	}

	public void setDUNSNumber(String dUNSNumber) {
		DUNSNumber = dUNSNumber;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getPhoneAreaCode() {
		return PhoneAreaCode;
	}

	public void setPhoneAreaCode(String phoneAreaCode) {
		PhoneAreaCode = phoneAreaCode;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getPhoneExtension() {
		return PhoneExtension;
	}

	public void setPhoneExtension(String phoneExtension) {
		PhoneExtension = phoneExtension;
	}

}
