/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: InvoiceBean.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.Date;

public class InvoiceBean {
	String companyCode;

	public void setCompanyCode(String companyCode) {
		;
		this.companyCode = companyCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	String companyName;

	public void setCompanyName(String companyName) {
		;
		this.companyName = companyName;
	}

	public String getCompanyName() {
		return companyName;
	}

	String companyAddress;

	public void setCompanyAddress(String companyAddress) {
		;
		this.companyAddress = companyAddress;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	String vendorCode;

	public void setVendorCode(String vendorCode) {
		;
		this.vendorCode = vendorCode;
	}

	public String getVendorCode() {
		return vendorCode;
	}

	String requestFor;

	public void setRequestFor(String requestFor) {
		;
		this.requestFor = requestFor;
	}

	public String getRequestFor() {
		return requestFor;
	}

	String attentionTo;

	public void setAttentionTo(String attentionTo) {
		;
		this.attentionTo = attentionTo;
	}

	public String getAttentionTo() {
		return attentionTo;
	}

	String vendorName;

	public void setVendorName(String vendorName) {
		;
		this.vendorName = vendorName;
	}

	public String getVendorName() {
		return vendorName;
	}

	String vendorAddress;

	public void setVendorAddress(String vendorAddress) {
		;
		this.vendorAddress = vendorAddress;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	String documentName;

	public void setDocumentName(String documentName) {
		;
		this.documentName = documentName;
	}

	public String getDocumentName() {
		return documentName;
	}

	String documentFolderPath;

	public void setDocumentFolderPath(String documentFolderPath) {
		;
		this.documentFolderPath = documentFolderPath;
	}

	public String getDocumentFolderPath() {
		return documentFolderPath;
	}

	String status;

	public void setStatus(String status) {
		;
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	String createdBy;

	public void setCreatedBy(String createdBy) {
		;
		this.createdBy = createdBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	String createdDate;

	public void setCreatedDate(String createdDate) {
		;
		this.createdDate = createdDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	String modifiedBy;

	public void setModifiedBy(String modifiedBy) {
		;
		this.modifiedBy = modifiedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	String modifiedDate;

	public void setModifiedDate(String modifiedDate) {
		;
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	String invoiceNumber;

	public void setInvoiceNumber(String invoiceNumber) {
		;
		this.invoiceNumber = invoiceNumber;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	String poNo;

	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}

	public String getPoNo() {
		return poNo;
	}

	String invoiceNumberInSystem;

	public void setInvoiceNumberInSystem(String invoiceNumberInSystem) {
		this.invoiceNumberInSystem = invoiceNumberInSystem;
	}

	public String getInvoiceNumberInSystem() {
		return invoiceNumberInSystem;
	}

	Date invoiceDate;

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	String billingCurrency;

	public void setBillingCurrency(String billingCurrency) {
		this.billingCurrency = billingCurrency;
	}

	public String getBillingCurrency() {
		return billingCurrency;
	}

	Double invoiceBaseAmount;

	public void setInvoiceBaseAmount(Double invoiceBaseAmount) {
		this.invoiceBaseAmount = invoiceBaseAmount;
	}

	public Double getInvoiceBaseAmount() {
		return invoiceBaseAmount;
	}

	Double serviceTax;

	public void setServiceTax(Double serviceTax) {
		this.serviceTax = serviceTax;
	}

	public Double getServiceTax() {
		return serviceTax;
	}

	Double educationCess;

	public void setEducationCess(Double educationCess) {
		this.educationCess = educationCess;
	}

	public Double getEducationCess() {
		return educationCess;
	}

	Double higherEducationCess;

	public void setHigherEducationCess(Double higherEducationCess) {
		this.higherEducationCess = higherEducationCess;
	}

	public Double getHigherEducationCess() {
		return higherEducationCess;
	}

	Double vat;

	public void setVat(Double vat) {
		this.vat = vat;
	}

	public Double getVat() {
		return vat;
	}

	Double additionalVatValue;

	public void setAdditionalVatValue(Double additionalVatValue) {
		this.additionalVatValue = additionalVatValue;
	}

	public Double getAdditionalVatValue() {
		return additionalVatValue;
	}

	Double anyOtherTax;

	public void setAnyOtherTax(Double anyOtherTax) {
		this.anyOtherTax = anyOtherTax;
	}

	public Double getAnyOtherTax() {
		return anyOtherTax;
	}

	String anyOtherTaxType;

	public void setAnyOtherTaxType(String anyOtherTaxType) {
		this.anyOtherTaxType = anyOtherTaxType;
	}

	public String getAnyOtherTaxType() {
		return anyOtherTaxType;
	}

	Double freight;

	public void setFreight(Double freight) {
		this.freight = freight;
	}

	public Double getFreight() {
		return freight;
	}

	Double discount;

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public Double getDiscount() {
		return discount;
	}

	Double penaltyDeduction;

	public void setPenaltyDeduction(Double penaltyDeduction) {
		this.penaltyDeduction = penaltyDeduction;
	}

	public Double getPenaltyDeduction() {
		return penaltyDeduction;
	}

	String totalInvoiceAmount;

	public void setTotalInvoiceAmount(String totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}

	public String getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}

	String voucherNarration;

	public void setVoucherNarration(String voucherNarration) {
		this.voucherNarration = voucherNarration;
	}

	public String getVoucherNarration() {
		return voucherNarration;
	}

	Date fromDate;

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getFromDate() {
		return fromDate;
	}

	Date toDate;

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Date getToDate() {
		return toDate;
	}
}