/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ReportsBean.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.Date;

public class ReportsBean {

	int itemIndex;
	String invoiceNo;
	String transactionId;
	String actionFlag;
	String invoiceAmount;
	String invoiceDate;
	String initiation_ExtDate;
	String currency;
	String physical_InvoiceRec;
	Date fromDate;
	Date toDate;
	String Comments;
	String RejectionStatus;

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public int getItemIndex() {
		return itemIndex;
	}

	public void setItemIndex(int itemIndex) {
		this.itemIndex = itemIndex;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getActionFlag() {
		return actionFlag;
	}

	public void setActionFlag(String actionFlag) {
		this.actionFlag = actionFlag;
	}

	public String getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(String invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInitiation_ExtDate() {
		return initiation_ExtDate;
	}

	public void setInitiation_ExtDate(String initiation_ExtDate) {
		this.initiation_ExtDate = initiation_ExtDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPhysical_InvoiceRec() {
		return physical_InvoiceRec;
	}

	public void setPhysical_InvoiceRec(String physical_InvoiceRec) {
		this.physical_InvoiceRec = physical_InvoiceRec;
	}

	public String getRejectionStatus() {
		return RejectionStatus;
	}

	public void setRejectionStatus(String RejectionStatus) {
		this.RejectionStatus = RejectionStatus;
	}

	public String getComments() {
		return Comments;
	}

	public void setComments(String Comments) {
		this.Comments = Comments;
	}
}
