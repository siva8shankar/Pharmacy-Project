/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: SAPConPODetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class SAPConPODetails {
	String PONO, POAmount, POOpenAmount, PODate, POStatus;

	public String getPONO() {
		return PONO;
	}

	public void setPONO(String pONO) {
		PONO = pONO;
	}

	public String getPOAmount() {
		return POAmount;
	}

	public void setPOAmount(String pOAmount) {
		POAmount = pOAmount;
	}

	public String getPOOpenAmount() {
		return POOpenAmount;
	}

	public void setPOOpenAmount(String pOOpenAmount) {
		POOpenAmount = pOOpenAmount;
	}

	public String getPODate() {
		return PODate;
	}

	public void setPODate(String pODate) {
		PODate = pODate;
	}

	public String getPOStatus() {
		return POStatus;
	}

	public void setPOStatus(String pOStatus) {
		POStatus = pOStatus;
	}

}
