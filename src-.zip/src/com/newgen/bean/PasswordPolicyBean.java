/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: PasswordPolicyBean.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.Date;

public class PasswordPolicyBean {

	String passwordLen;
	String minSplCharCt;
	String minNumCharCt;
	String minLowerCaseCt;
	String minUpperCaseCt;
	String createdBy;
	Date createdDateTime;

	public String getPasswordLen() {
		return passwordLen;
	}

	public void setPasswordLen(String passwordLen) {
		this.passwordLen = passwordLen;
	}

	public String getMinSplCharCt() {
		return minSplCharCt;
	}

	public void setMinSplCharCt(String minSplCharCt) {
		this.minSplCharCt = minSplCharCt;
	}

	public String getMinNumCharCt() {
		return minNumCharCt;
	}

	public void setMinNumCharCt(String minNumCharCt) {
		this.minNumCharCt = minNumCharCt;
	}

	public String getMinLowerCaseCt() {
		return minLowerCaseCt;
	}

	public void setMinLowerCaseCt(String minLowerCaseCt) {
		this.minLowerCaseCt = minLowerCaseCt;
	}

	public String getMinUpperCaseCt() {
		return minUpperCaseCt;
	}

	public void setMinUpperCaseCt(String minUpperCaseCt) {
		this.minUpperCaseCt = minUpperCaseCt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
}
