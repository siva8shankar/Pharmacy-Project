/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorContactDirectory.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class VendorContactDirectory {

	String FirstName;
	String LastName;
	String Phone;
	String Email;
	String CPurpose;
	String RequUserAccount;

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getCPurpose() {
		return CPurpose;
	}

	public void setCPurpose(String cPurpose) {
		CPurpose = cPurpose;
	}

	public String getRequUserAccount() {
		return RequUserAccount;
	}

	public void setRequUserAccount(String requUserAccount) {
		RequUserAccount = requUserAccount;
	}

}
