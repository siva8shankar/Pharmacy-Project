/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: InvoiceNewDetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.Date;

public class InvoiceNewDetails {

	int InvoiceId;
	String Invoiceno;
	Date Invoicedate;
	String Invoicedate_str;
	String Currency;
	String FDocumentType;
	String Pono;
	String Typeofinvoice;
	String invoiceAmount;
	String invoiceSubDate;
	String invoicePlantCode;
	String invoiceLocation;
	String Vendorno;
	String InvoiceCreatedDate;
	String InvoiceCreatedBy;
	Date FromDate;
	Date ToDate;
	String DueDate;
	String TransactionId;
	String location;
	String vendorName;
	String vendorEmailId;

	public String getVendorEmailId() {
		return vendorEmailId;
	}

	public void setVendorEmailId(String vendorEmailId) {
		this.vendorEmailId = vendorEmailId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}

	public Date getFromDate() {
		return FromDate;
	}

	public void setFromDate(Date fromDate) {
		FromDate = fromDate;
	}

	public Date getToDate() {
		return ToDate;
	}

	public void setToDate(Date toDate) {
		ToDate = toDate;
	}

	public int getInvoiceId() {
		return InvoiceId;
	}

	public void setInvoiceId(int invoiceId) {
		InvoiceId = invoiceId;
	}

	public String getInvoiceno() {
		return Invoiceno;
	}

	public void setInvoiceno(String invoiceno) {
		Invoiceno = invoiceno;
	}

	public Date getInvoicedate() {
		return Invoicedate;
	}

	public void setInvoicedate(Date invoicedate) {
		Invoicedate = invoicedate;
	}

	public String getInvoicedate_str() {
		return Invoicedate_str;
	}

	public void setInvoicedate_str(String invoicedate) {
		Invoicedate_str = invoicedate;
	}

	public String getCurrency() {
		return Currency;
	}

	public void setCurrency(String currency) {
		Currency = currency;
	}

	public String getPono() {
		return Pono;
	}

	public void setPono(String pono) {
		Pono = pono;
	}

	public String getTypeofinvoice() {
		return Typeofinvoice;
	}

	public void setTypeofinvoice(String typeofinvoice) {
		Typeofinvoice = typeofinvoice;
	}

	public String getVendorno() {
		return Vendorno;
	}

	public void setVendorno(String vendorno) {
		Vendorno = vendorno;
	}

	public String getInvoiceCreatedDate() {
		return InvoiceCreatedDate;
	}

	public void setInvoiceCreatedDate(String invoiceCreatedDate) {
		InvoiceCreatedDate = invoiceCreatedDate;
	}

	public String getInvoiceCreatedBy() {
		return InvoiceCreatedBy;
	}

	public void setInvoiceCreatedBy(String invoiceCreatedBy) {
		InvoiceCreatedBy = invoiceCreatedBy;
	}

	public String getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(String invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public String getFDocumentType() {
		return FDocumentType;
	}

	public void setFDocumentType(String FDocumentType) {
		this.FDocumentType = FDocumentType;
	}

	public String getDueDate() {
		return DueDate;
	}

	public void setDueDate(String dueDate) {
		DueDate = dueDate;
	}

	public String getInvoiceSubDate() {
		return invoiceSubDate;
	}

	public void setInvoiceSubDate(String invoiceSubDate) {
		this.invoiceSubDate = invoiceSubDate;
	}

	public String getInvoicePlantCode() {
		return invoicePlantCode;
	}

	public void setInvoicePlantCode(String invoicePlantCode) {
		this.invoicePlantCode = invoicePlantCode;
	}

	public String getInvoiceLocation() {
		return invoiceLocation;
	}

	public void setInvoiceLocation(String invoiceLocation) {
		this.invoiceLocation = invoiceLocation;
	}
	
}
