/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorQueryDetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class VendorQueryDetails {

	int queryId;
	String queryNo;
	String description;
	String queryType;
	String createdBy;
	String createdDate;
	String invoiceNo;
	String TransactionNo;
	String userPrivilege;
	String PONumber;
	String QueryStatus;
	String LockedBy;
	String poTransactionNo;

	public String getTransactionNo() {
		return TransactionNo;
	}

	public void setTransactionNo(String transactionNo) {
		TransactionNo = transactionNo;
	}

	String queryReplyFlag;

	public String getQueryReplyFlag() {
		return queryReplyFlag;
	}

	public void setQueryReplyFlag(String queryReplyFlag) {
		this.queryReplyFlag = queryReplyFlag;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public int getQueryId() {
		return queryId;
	}

	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}

	public String getQueryNo() {
		return queryNo;
	}

	public void setQueryNo(String queryNo) {
		this.queryNo = queryNo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getQueryType() {
		return queryType;
	}

	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUserPrivilege() {
		return userPrivilege;
	}

	public void setUserPrivilege(String userPrivilege) {
		this.userPrivilege = userPrivilege;
	}

	public String getPONumber() {
		return PONumber;
	}

	public void setPONumber(String pONumber) {
		PONumber = pONumber;
	}

	public String getQueryStatus() {
		return QueryStatus;
	}

	public void setQueryStatus(String queryStatus) {
		QueryStatus = queryStatus;
	}

	public String getLockedBy() {
		return LockedBy;
	}

	public void setLockedBy(String lockedBy) {
		LockedBy = lockedBy;
	}

	public String getPoTransactionNo() {
		return poTransactionNo;
	}

	public void setPoTransactionNo(String poTransactionNo) {
		this.poTransactionNo = poTransactionNo;
	}

}
