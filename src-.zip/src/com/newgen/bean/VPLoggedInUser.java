/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VPLoggedInUser.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.Date;

public class VPLoggedInUser {

	String UserName;
	String Password;
	String UserIndex;
	Date LoginDateTime;
	String UserSessionId;
	Date ModifiedDateTime;

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String pUserName) {
		UserName = pUserName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String pPassword) {
		Password = pPassword;
	}

	public String getUserIndex() {
		return UserIndex;
	}

	public void setUserIndex(String pUserIndex) {
		UserIndex = pUserIndex;
	}

	public String getUserSessionId() {
		return UserSessionId;
	}

	public void setUserSessionId(String pUserSessionId) {
		UserSessionId = pUserSessionId;
	}

	public Date getLoginDateTime() {
		return LoginDateTime;
	}

	public void setLoginDateTime(Date pLoginDateTime) {
		LoginDateTime = pLoginDateTime;
	}

	public Date getModifiedDateTime() {
		return ModifiedDateTime;
	}

	public void setModifiedDateTime(Date pModifiedDateTime) {
		ModifiedDateTime = pModifiedDateTime;
	}
}