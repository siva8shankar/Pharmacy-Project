/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: ComplexPODetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.Date;

public class ComplexPODetails {
	String WIName, CPONO, CServiceConfNo, CGRNNo, CItemName, CConfirmedAmt, CItemQuantity, rowflag, CItemUnit,
			CGenLedgerCode, CGenLedgerDesc, CProfitCentre, CItemNo, CPOItemno, userName;

	public String getWIName() {
		return WIName;
	}

	public void setWIName(String wIName) {
		WIName = wIName;
	}

	public String getCPONO() {
		return CPONO;
	}

	public void setCPONO(String cPONO) {
		CPONO = cPONO;
	}

	public String getCServiceConfNo() {
		return CServiceConfNo;
	}

	public void setCServiceConfNo(String cServiceConfNo) {
		CServiceConfNo = cServiceConfNo;
	}

	public String getCGRNNo() {
		return CGRNNo;
	}

	public void setCGRNNo(String cGRNNo) {
		CGRNNo = cGRNNo;
	}

	public String getCItemName() {
		return CItemName;
	}

	public void setCItemName(String cItemName) {
		CItemName = cItemName;
	}

	public String getCConfirmedAmt() {
		return CConfirmedAmt;
	}

	public void setCConfirmedAmt(String cConfirmedAmt) {
		CConfirmedAmt = cConfirmedAmt;
	}

	public String getCItemQuantity() {
		return CItemQuantity;
	}

	public void setCItemQuantity(String cItemQuantity) {
		CItemQuantity = cItemQuantity;
	}

	public String getRowflag() {
		return rowflag;
	}

	public void setRowflag(String rowflag) {
		this.rowflag = rowflag;
	}

	public String getCItemUnit() {
		return CItemUnit;
	}

	public void setCItemUnit(String cItemUnit) {
		CItemUnit = cItemUnit;
	}

	public String getCGenLedgerCode() {
		return CGenLedgerCode;
	}

	public void setCGenLedgerCode(String cGenLedgerCode) {
		CGenLedgerCode = cGenLedgerCode;
	}

	public String getCGenLedgerDesc() {
		return CGenLedgerDesc;
	}

	public void setCGenLedgerDesc(String cGenLedgerDesc) {
		CGenLedgerDesc = cGenLedgerDesc;
	}

	public String getCProfitCentre() {
		return CProfitCentre;
	}

	public void setCProfitCentre(String cProfitCentre) {
		CProfitCentre = cProfitCentre;
	}

	public String getCItemNo() {
		return CItemNo;
	}

	public void setCItemNo(String cItemNo) {
		CItemNo = cItemNo;
	}

	public String getCPOItemno() {
		return CPOItemno;
	}

	public void setCPOItemno(String cPOItemno) {
		CPOItemno = cPOItemno;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
