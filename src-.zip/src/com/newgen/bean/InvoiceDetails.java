/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: InvoiceDetails.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

import java.util.Date;

public class InvoiceDetails {
	int invoiceId;
	String otherSystemId;
	String invoiceNumber;
	String invoiceNumberInSystem;
	String companyCode;
	String companyName;
	String companyAddress;
	String requestFor;
	String attentionTo;
	String poNo;
	String billingCurrency;
	String vendorCode;
	String vendorName;
	String vendorAddress;
	String invoiceBaseAmount;
	String serviceTax;
	String educationCess;
	String higherEducationCess;
	String vat;
	String additionalVATValue;
	String anyOtherTax;
	String freight;
	String totalInvoiceAmount;
	String discount;
	String penaltyDeduction;
	String voucherNarration;
	String status;
	Date fromDate;
	Date toDate;
	Date invoiceDate;
	String invoiceDt;
	String documentName;
	String documentFolderPath;
	String deletedFlag;
	String createdBy;
	String modifiedBy;
	String createdDate;
	Date modifiedDate;
	String anyOtherTaxType;
	String CaseNumber;
	String DocumentType;

	public String getDocumentType() {
		return DocumentType;
	}

	public void setDocumentType(String documentType) {
		DocumentType = documentType;
	}

	public int getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(int invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getOtherSystemId() {
		return otherSystemId;
	}

	public void setOtherSystemId(String otherSystemId) {
		this.otherSystemId = otherSystemId;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getInvoiceNumberInSystem() {
		return invoiceNumberInSystem;
	}

	public void setInvoiceNumberInSystem(String invoiceNumberInSystem) {
		this.invoiceNumberInSystem = invoiceNumberInSystem;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public String getRequestFor() {
		return requestFor;
	}

	public void setRequestFor(String requestFor) {
		this.requestFor = requestFor;
	}

	public String getAttentionTo() {
		return attentionTo;
	}

	public void setAttentionTo(String attentionTo) {
		this.attentionTo = attentionTo;
	}

	public String getPoNo() {
		return poNo;
	}

	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}

	public String getBillingCurrency() {
		return billingCurrency;
	}

	public void setBillingCurrency(String billingCurrency) {
		this.billingCurrency = billingCurrency;
	}

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	public String getInvoiceBaseAmount() {
		return invoiceBaseAmount;
	}

	public void setInvoiceBaseAmount(String invoiceBaseAmount) {
		this.invoiceBaseAmount = invoiceBaseAmount;
	}

	public String getServiceTax() {
		return serviceTax;
	}

	public void setServiceTax(String serviceTax) {
		this.serviceTax = serviceTax;
	}

	public String getEducationCess() {
		return educationCess;
	}

	public void setEducationCess(String educationCess) {
		this.educationCess = educationCess;
	}

	public String getHigherEducationCess() {
		return higherEducationCess;
	}

	public void setHigherEducationCess(String higherEducationCess) {
		this.higherEducationCess = higherEducationCess;
	}

	public String getVat() {
		return vat;
	}

	public void setVat(String vat) {
		this.vat = vat;
	}

	public String getAdditionalVATValue() {
		return additionalVATValue;
	}

	public void setAdditionalVATValue(String additionalVATValue) {
		this.additionalVATValue = additionalVATValue;
	}

	public String getAnyOtherTax() {
		return anyOtherTax;
	}

	public void setAnyOtherTax(String anyOtherTax) {
		this.anyOtherTax = anyOtherTax;
	}

	public String getFreight() {
		return freight;
	}

	public void setFreight(String freight) {
		this.freight = freight;
	}

	public String getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}

	public void setTotalInvoiceAmount(String totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getPenaltyDeduction() {
		return penaltyDeduction;
	}

	public void setPenaltyDeduction(String penaltyDeduction) {
		this.penaltyDeduction = penaltyDeduction;
	}

	public String getVoucherNarration() {
		return voucherNarration;
	}

	public void setVoucherNarration(String voucherNarration) {
		this.voucherNarration = voucherNarration;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceDt() {
		return invoiceDt;
	}

	public void setInvoiceDt(String invoiceDt) {
		this.invoiceDt = invoiceDt;
	}

	// till here
	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentFolderPath() {
		return documentFolderPath;
	}

	public void setDocumentFolderPath(String documentFolderPath) {
		this.documentFolderPath = documentFolderPath;
	}

	public String getDeletedFlag() {
		return deletedFlag;
	}

	public void setDeletedFlag(String deletedFlag) {
		this.deletedFlag = deletedFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getAnyOtherTaxType() {
		return anyOtherTaxType;
	}

	public void setAnyOtherTaxType(String anyOtherTaxType) {
		this.anyOtherTaxType = anyOtherTaxType;
	}

	public String getCaseNumber() {
		return CaseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		CaseNumber = caseNumber;
	}

}
