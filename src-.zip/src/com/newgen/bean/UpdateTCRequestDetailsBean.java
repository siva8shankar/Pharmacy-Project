package com.newgen.bean;

public class UpdateTCRequestDetailsBean {
	String tcReqID,tcPID,plant,quantity,structure,comment,edd,deliverydate,dispatchedDate,status,vendorCode,vendorName,vendorEmailID,tcInsertionID;

	public String getTcReqID() {
		return tcReqID;
	}

	public void setTcReqID(String tcReqID) {
		this.tcReqID = tcReqID;
	}

	public String getTcPID() {
		return tcPID;
	}

	public void setTcPID(String tcPID) {
		this.tcPID = tcPID;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getStructure() {
		return structure;
	}

	public void setStructure(String structure) {
		this.structure = structure;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getEdd() {
		return edd;
	}

	public void setEdd(String edd) {
		this.edd = edd;
	}

	public String getDeliverydate() {
		return deliverydate;
	}

	public void setDeliverydate(String deliverydate) {
		this.deliverydate = deliverydate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorEmailID() {
		return vendorEmailID;
	}

	public void setVendorEmailID(String vendorEmailID) {
		this.vendorEmailID = vendorEmailID;
	}

	public String getDispatchedDate() {
		return dispatchedDate;
	}

	public void setDispatchedDate(String dispatchedDate) {
		this.dispatchedDate = dispatchedDate;
	}

	public String getTcInsertionID() {
		return tcInsertionID;
	}

	public void setTcInsertionID(String tcInsertionID) {
		this.tcInsertionID = tcInsertionID;
	}
	
	
	
}
