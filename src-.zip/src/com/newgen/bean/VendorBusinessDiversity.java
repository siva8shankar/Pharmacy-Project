/********************************************************************
*    NEWGEN SOFTWARE TECHNOLOGIES LIMITED
*    Group                                     	: CIG
*    Product / Project                  		: Deloitte P2P Automation
*    Module                                  	: VendorPortal
*    File Name                               	: VendorBusinessDiversity.java
*    Author                                    	: ksivashankar
*    Date written                          		: 22/09/2017
*    (DD/MM/YYYY)                      
*    Description                            	: 
*  CHANGE HISTORY
***********************************************************************************************
* Date                                Change By                    Change Description (Bug No. (If Any))
* (DD/MM/YYYY)                                       
************************************************************************************************/

package com.newgen.bean;

public class VendorBusinessDiversity {

	String Column1;
	String Column2;
	String Column3;
	String Column4;
	String Column5;
	String Column6;
	String Column7;
	String Column8;
	String Column9;
	String Column10;
	String Column11;

	public String getColumn1() {
		return Column1;
	}

	public void setColumn1(String column1) {
		Column1 = column1;
	}

	public String getColumn2() {
		return Column2;
	}

	public void setColumn2(String column2) {
		Column2 = column2;
	}

	public String getColumn3() {
		return Column3;
	}

	public void setColumn3(String column3) {
		Column3 = column3;
	}

	public String getColumn4() {
		return Column4;
	}

	public void setColumn4(String column4) {
		Column4 = column4;
	}

	public String getColumn5() {
		return Column5;
	}

	public void setColumn5(String column5) {
		Column5 = column5;
	}

	public String getColumn6() {
		return Column6;
	}

	public void setColumn6(String column6) {
		Column6 = column6;
	}

	public String getColumn7() {
		return Column7;
	}

	public void setColumn7(String column7) {
		Column7 = column7;
	}

	public String getColumn8() {
		return Column8;
	}

	public void setColumn8(String column8) {
		Column8 = column8;
	}

	public String getColumn9() {
		return Column9;
	}

	public void setColumn9(String column9) {
		Column9 = column9;
	}

	public String getColumn10() {
		return Column10;
	}

	public void setColumn10(String column10) {
		Column10 = column10;
	}

	public String getColumn11() {
		return Column11;
	}

	public void setColumn11(String column11) {
		Column11 = column11;
	}

}
