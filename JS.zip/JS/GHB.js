
var activityName=window.parent.stractivityName;
var processName = window.parent.strprocessname;
var pid1=window.parent.strWorkitemName;
var date1= new Date();
var dynamicURL=window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
/*function eventDispatchedAP(pEvent.type)
{
	alert("inside event dispatched HelpDesk.js :"+pEvent.type);
	return true;
}*/

//alert ("In HelpDesk.js");


function formPopulated_GHB(){
	//if(activityName='Clarification_Required'){		
}


function mandateCheck_GHB(controlName, messageString)
{
	var nonzero=0.00;
	var color1=getNGValue('mandcolor');
	if(!color1=="")
	{
		com.newgen.omniforms.formviewer.setNGBackColor(controlName, "#FFFFFF");
	}
     //alert('Mandate Check Running HelpDesk...');
    //if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--'||getNGValue(controlName) ==nonzero)
	if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--' || getNGValue(controlName) == 'Select a Priority' || getNGValue(controlName) == 'Select an Action' || getNGValue(controlName) == 'Select a Type' )//
	//Ended By Harinath on 2017/07/03
    {		
		com.newgen.omniforms.util.showError(controlName,'Please enter the ' + messageString);
		//alert('Please enter the ' + messageString);
        //showError('controlName','PLEASE ENTER THE ' + messageString);   
		com.newgen.omniforms.formviewer.setNGBackColor(controlName,"#F2F5A9");	
        //setNGFocus(controlName);
        var c1=controlName;        
        com.newgen.omniforms.formviewer.setNGValue('mandcolor',c1);
        //alert("gg"+getNGValue('mandcolor'));
        return false;
    }
    return true;

}

//For event handing function
function eventDispatched_GHB(pId, pEvent) 
{
	//alert("inside Event Dispatched Funtion");
	
//alert('processName:'+processName);
//alert('activityName:'+activityName);
	window.status = pId + "_" + pEvent.type;
	//alert(pEvent.type+" "+pEvent.srcElement.id);
	var strSubcategory=getNGValue('SubCategory1');
	var strTypeOfInvoice=getNGValue('TypeOfInvoice');
	var strPORef=getNGValue('PORef'); //PO or NON-PO
	switch(pEvent.type)
    {           
       
	   case 'click':
        {
            switch(pEvent.srcElement.id)
            {				
				case 'btn_Submit':	
                {
					if (!(mandateCheck_GHB('EmpContactNumber', 'Employee Contact Number') 
						&& mandateCheck_GHB('GuestHouseLocation','Guest House Location')
						&& mandateCheck_GHB('FromDate', 'From Date') 
						&& mandateCheck_GHB('ToDate', 'To Date')
						&& mandateCheck_GHB('RequestType', 'Request Type')
						&& mandateCheck_GHB('NoOfPersons', 'No Of Persons')
						&& mandateCheck_GHB('cb_checkin_hh', 'Check In Time in Hours')
						&& mandateCheck_GHB('cb_checkin_mm', 'Check In Time in Minutes')
						&& mandateCheck_GHB('cb_checkout_hh', 'Check Out Time in Hours')
						&& mandateCheck_GHB('cb_checkout_mm', 'Check Out Time in Minutes')
						&& mandateCheck_GHB('Comments', 'Comments')						
						))
						{
							return false;
						}
					return true;					
				}
			   case 'btn_Approve' :
			   {
				return true;	
			   }
			   case 'btn_Cancel' :
			   {
				   if(!(mandateCheck_GHB('OtherComments', 'Comments')))
					{
					  return false;
					}
			   return true;
			   }
			   case 'btn_BookRoom' :
			   {				  
			   return true;
			   }
			   case 'btn_CancelRoom' :
			   {				  
			   return true;
			   }
			   case 'btn_bookOyoRoom' :
			   {
				   if(!(mandateCheck_GHB('OtherComments', 'Comments')))
					{
					  return false;
					}
			   return true;
			   }
			   case 'btn_bookingdetails_add':
                {
                    if (!(mandateCheck_GHB('RoomType', 'Room Type') &&
                            mandateCheck_GHB('RoomName', 'Room Name') &&
                            mandateCheck_GHB('RoomNumber', 'Room Number') &&
                            mandateCheck_GHB('RoomStatus', 'Room Status') &&
							mandateCheck_GHB('BookingFor', 'Booking For') &&
                            mandateCheck_GHB('BookingComments', 'Booking Comments'))) {
                        return false;
                    }
                    return true;
                }
                case 'btn_bookingdetails_modify':
                {
                     if (!(mandateCheck_GHB('RoomType', 'Room Type') &&
                            mandateCheck_GHB('RoomName', 'Room Name') &&
                            mandateCheck_GHB('RoomNumber', 'Room Number') &&
                            mandateCheck_GHB('RoomStatus', 'Room Status') &&
							mandateCheck_GHB('BookingFor', 'Booking For') &&
                            mandateCheck_GHB('BookingComments', 'Booking Comments'))) {
                        return false;
                    }
                    return true;
                }

                case 'btn_bookingdetails_delete':
                {
                    return true;
                }
				case 'btn_cabReq_Add':
                {
                    if (!(mandateCheck_GHB('cabReqLocation', 'Location') &&
                            mandateCheck_GHB('cabReqTypeOfCar', 'Type Of Car') &&
                            mandateCheck_GHB('cabReqDateOfPickup', 'Date Of Pickup') &&
                            mandateCheck_GHB('cabReqPickupTimeInHH', 'Pickup Time In Hours') &&
							mandateCheck_GHB('cabReqPickupTimeInMM', 'Pickup Time In Minutes') &&
							mandateCheck_GHB('cabReqTypeOfTravel', 'Type Of Travel') &&
							mandateCheck_GHB('cabReqFromAddress', 'From Address') &&
                            mandateCheck_GHB('cabReqToAddress', 'To Address'))) {
                        return false;
                    }
                    return true;
                }
                case 'btn_cabReq_Modify':
                {
                     if (!(mandateCheck_GHB('cabReqLocation', 'Location') &&
                            mandateCheck_GHB('cabReqTypeOfCar', 'Type Of Car') &&
                            mandateCheck_GHB('cabReqDateOfPickup', 'Date Of Pickup') &&
                            mandateCheck_GHB('cabReqPickupTimeInHH', 'Pickup Time In Hours') &&
							mandateCheck_GHB('cabReqPickupTimeInMM', 'Pickup Time In Minutes') &&
							mandateCheck_GHB('cabReqTypeOfTravel', 'Type Of Travel') &&
							mandateCheck_GHB('cabReqFromAddress', 'From Address') &&
                            mandateCheck_GHB('cabReqToAddress', 'To Address'))) {
                        return false;
                    }
                    return true;
                }

                case 'btn_cabReq_Delete':
                {
                    return true;
                }
			   case 'btn_SAP_PO' :
			   {
			   return true;
			   }
			   case 'Button_add_attachments':
			   {
			   //window.parent.openDocList();//To Load Document List from Document Button
			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
			   }
			   case 'Button_admin_add_attachments':
			   {
			   //window.parent.openDocList();//To Load Document List from Document Button
			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
			   }
			 
             case 'btn_reverse':
			 {
			 return true;
			 break;
			  }
		  case 'Button_Get_Users_List':	
			{
			return true;
			}
			  //btn_mod_po Newlyy added by Bala.G on 07-09--2018
			 case 'btn_mod_po':
			 {
			 return true;
			 break;
			  }
			}
			//alert("End of Click");
			//return true;
			return false;
			//break;
		}//End of Click
		case 'change':
		{
			switch (pEvent.srcElement.id)
			{
			
			case 'GuestHouseLocation':
				{				
				return true;					
				}
			case 'RoomType':
				{				
				return true;					
				}
			case 'RoomName':
				{				
				return true;					
				}
			case 'RoomNumber':
				{				
				return true;					
				}
			case 'InitUser_TicketAction':
				{	
					var myWindow;
					if(activityName == 'User_Confirmation'){	
						var strInitUserAction = getNGValue('InitUser_TicketAction');						
						if( strInitUserAction == 'Accept'){														
							var len=history.length;   
							history.go(-len);								
							 var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
							 var strInitBy = com.newgen.omniforms.formviewer.getNGValue("InitiationBy");
							 var varEmpName = com.newgen.omniforms.formviewer.getNGValue("EmployeeName");
							 var varEmpMailID = com.newgen.omniforms.formviewer.getNGValue("EmailID");
							var w = 600;
							var h = 600;
							var left = Number((screen.width/2)-(w/2))-200;
							var tops = Number((screen.height/2)-(h/2))+50;				   
							var url="/webdesktop/CustomJSP/Feedback_Form.jsp?ProcInstId="+Pid1+"&emailId="+varEmpMailID+"&empName="+varEmpName;
							myWindow = window.open(url,"FeedBack","toolbar=no,directories=no, status=no, menubar=no,scrollbars=1,resizable=1,width=800,height=570,top="+tops+",left="+left+"");
																									
						}else{
							myWindow.close();
						}
					}
				return true;					
				}				
			case 'EmployeeCode':
				{				
				return true;					
				}
			case 'BillDate':
				{
					 if(!(futuredate_AP('BillDate')))
				   {
					   return false;
					  
				   }
				   
				break;	
				}
				case 'TypeOfInvoice':
				{
				return true;                
				}
				
				case 'cb_entschm_accref':
				{
				return true;                
				}
				case 'cb_entschm_accref':
				{
				return true;                
				}				
				
			}
			//return true;
			return false;
			
		}
		case 'focus':
        {
		
		//alert('In Focus');
            switch (pEvent.srcElement.id) 
            {  
			case 'NoOfNights':
			{
			if (!(mandateCheck_GHB('FromDate', 'From Date'))) {
					return false
				}
				var date_From = getNGValue('FromDate');
				var date_To = getNGValue('ToDate');
				var dayss = Noofdays_AP_bw_2dt_ER('FromDate', 'ToDate');
				setNGValue('NoOfNights', dayss);
				return true;
			}
			case 'RequestType':
			{
			if (!(mandateCheck_GHB('FromDate', 'From Date'))) {
					return false
				}
				var date_From = getNGValue('FromDate');
				var date_To = getNGValue('ToDate');
				var dayss = Noofdays_AP_bw_2dt_ER('FromDate', 'ToDate');
				setNGValue('NoOfNights', dayss);
				return true;
			}
			case 'NoOfPersons':
			{
				if (!(mandateCheck_GHB('FromDate', 'From Date'))) {
					return false
				}
				var date_From = getNGValue('FromDate');
				var date_To = getNGValue('ToDate');
				var dayss = Noofdays_AP_bw_2dt_ER('FromDate', 'ToDate');
				setNGValue('NoOfNights', dayss);
				return true;                
			}
			case 'RoadtaxYN':
			{
				return true;                
			}
			case 'LossYN':
			{
				return true;                
			}
			case 'OctroiYN':
			{
				return true;                
			}
			case 'PackYN':
			{
				return true;                
			}
			
			case 'TypeOfProcess':
			{
				return true;                
			}
			case 'TotInvoiceAmnt':
			{
				return true;                
			}
			case 'ExchangeRate':
			{
				return true;                
			}
			
			
            }
			//alert('End of focus');
			return false;
        }//End of Focus
		case 'blur':
        {
			//alert("blur");
			switch (pEvent.srcElement.id) 
            {  
			
			case 'ToDate':
			{
				if (!(mandateCheck_GHB('FromDate', 'From Date'))) {
					return false
				}
				var date_From = getNGValue('FromDate');
				var date_To = getNGValue('ToDate');
				var dayss = Noofdays_AP_bw_2dt_ER('FromDate', 'ToDate');
				setNGValue('NoOfNights', dayss);
				return true;
			}

			case 'FromDate':
			{

				var date_From = getNGValue('FromDate');
				var date_To = getNGValue('ToDate');

				if (!(date_From == '') && !(date_To == ''))
				{
					var dayss = Noofdays_AP_bw_2dt_ER('FromDate', 'ToDate');

					setNGValue('NoOfNights', dayss);
				}

				return true;
			}
			case 'RoadtaxYN':
			{
				return true;                
			}
			case 'LossYN':
			{
				return true;                
			}
			case 'OctroiYN':
			{
				return true;                
			}
			case 'PackYN':
			{
				return true;                
			}
			
			case 'TypeOfProcess':
			{
				return true;                
			}
			case 'TotInvoiceAmnt':
			{
				return true;                
			}
			case 'ExchangeRate':
			{
				return true;                
			}
			
            }
			return false;
			//return true;
		}//End of blur
		
		case 'keydown':
		{
			switch (pEvent.srcElement.id) 
            { 
			
			case 'EmployeeCode':
				{				
					
				return false;
				break;	
				}
				
				return false;
			}
		
		}//End of event keydown
		
		return false;
		/*default:
		{
		return false;
		break;
		}*/
	}//End of Switch 
	//alert('End of Event dispatched');
	
}//end of eventDispatched_HelpDesk
