
var activityName=window.parent.stractivityName;
var processName = window.parent.strprocessname;
var pid1=window.parent.strWorkitemName;
var date1= new Date();
var dynamicURL=window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
/*function eventDispatchedAP(pEvent.type)
{
	alert("inside event dispatched HelpDesk.js :"+pEvent.type);
	return true;
}*/

//alert ("In HelpDesk.js");


function formPopulated_HelpDesk(){
	//if(activityName='Clarification_Required'){	
	if(activityName == 'Clarification_Required' || activityName == 'User_Confirmation' || activityName == 'Query' || activityName == 'Archival' || activityName == 'Exit'){
		document.getElementById("HelpDesk_Tab_tab_3").style.display = "none";
		document.getElementById("HelpDesk_Tab_tab_5").style.display = "none";
	}
}


function mandateCheck_HelpDesk(controlName, messageString)
{
	var nonzero=0.00;
	var color1=getNGValue('mandcolor');
	if(!color1=="")
	{
		com.newgen.omniforms.formviewer.setNGBackColor(controlName, "#FFFFFF");
	}
     //alert('Mandate Check Running HelpDesk...');
    //if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--'||getNGValue(controlName) ==nonzero)
	if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--' || getNGValue(controlName) == 'Select a Priority' || getNGValue(controlName) == 'Select an Action' )
	//Ended By Harinath on 2017/07/03
    {		
		com.newgen.omniforms.util.showError(controlName,'Please enter the ' + messageString);
		//alert('Please enter the ' + messageString);
        //showError('controlName','PLEASE ENTER THE ' + messageString);   
		com.newgen.omniforms.formviewer.setNGBackColor(controlName,"#F2F5A9");	
        //setNGFocus(controlName);
        var c1=controlName;        
        com.newgen.omniforms.formviewer.setNGValue('mandcolor',c1);
        //alert("gg"+getNGValue('mandcolor'));
        return false;
    }
    return true;

}

//For event handing function
function eventDispatched_HelpDesk(pId, pEvent) 
{
	//alert("inside Event Dispatched Funtion");
	
//alert('processName:'+processName);
//alert('activityName:'+activityName);
	window.status = pId + "_" + pEvent.type;
	//alert(pEvent.type+" "+pEvent.srcElement.id);
	var strSubcategory=getNGValue('SubCategory1');
	var strTypeOfInvoice=getNGValue('TypeOfInvoice');
	var strPORef=getNGValue('PORef'); //PO or NON-PO
	switch(pEvent.type)
    {           
       
	   case 'click':
        {
            switch(pEvent.srcElement.id)
            {				
				case 'Button_iSubmit':	
                {
					if (!(mandateCheck_HelpDesk('TicketFunction', 'Ticket Function') 
						&& mandateCheck_HelpDesk('TicketCategory','Ticket Category')
						&& mandateCheck_HelpDesk('TicketSubCategory', 'Ticket Sub-Category') 
						&& mandateCheck_HelpDesk('TicketSubject', 'Ticket Subject')
						&& mandateCheck_HelpDesk('TicketPriority', 'Ticket Priority')
						&& mandateCheck_HelpDesk('TicketContactNumber', 'Ticket Contact Number')
						&& mandateCheck_HelpDesk('TicketMessage', 'Ticket Message')
						&& mandateCheck_HelpDesk('InitUser_TicketActions', 'Ticket Actions')
						&& mandateCheck_HelpDesk('InitUser_TicketAction', 'Ticket Actions')
						))
						{
							return false;
						}
						if(activityName == 'User_Confirmation'){	
						if (!(mandateCheck_HelpDesk('TicketConfirmation', 'Ticket Comments')))
						{
							return false;
						}
						}
					return true;					
				}
				case 'Button_eSubmit':	
                {
					if (!(mandateCheck_HelpDesk('TicketExternalComments', 'Ticket Comments') 
						&& mandateCheck_HelpDesk('TicketAction','Ticket Action')
						))
						{
							return false;
						}
				return true;
				}			
				case 'Button_Get_Users_List':	
                {
				return true;
				}
				case 'btn_load':	
                {
				return true;
				}				
				case 'btn_SAP_Vendor':	
                {
				return true;
				
				}
				case 'btn_po_up':	
                {
				return true;
				
				}
				case 'btn_po_down':	
                {
				return true;
				
				}
				case 'btn_biss_code':	
                {
				return true;
				
				}
				case 'btn_calc_totamnt':	
                {
				if(strSubcategory=='Salary Advance'||strSubcategory=='House Rent Advance')
				{
					var Advamnt=getNGValue('ClaimedAmount');
					//alert("Advance Amount :"+Advamnt);
					//aler('btn_calc_totamnt click');
					setNGValue('TotalAmount',Advamnt);
					if (!( 
                        mandateCheck_AP('BasicSalary', 'basic salary')
						//&& mandateCheck_AP('EligibleAmount', 'eligible amount')
						&& mandateCheck_AP('RepaymentSchedule','reyayment schedule')
						&& mandateCheck_AP('ClaimedAmount', 'claimed amount')
						)
						)
						{
							return false;
						}
						
						//Added By nanjunda Moorthy on 14/12/2016
						//if(strSubcategory=='Salary Advance' && (parseFloat(getNGValue("ClaimedAmount"))>parseFloat(getNGValue("EligibleAmount"))))
						if(parseFloat(getNGValue("ClaimedAmount"))>parseFloat(getNGValue("EligibleAmount")))				
						{
							//com.newgen.omniforms.util.showError(ClaimedAmount,"Claimed amount cannot be greater than eligible amount");
							showErrorAP('ClaimedAmount','Claimed amount cannot be greater than eligible amount');
							//alert("Claimed amount cannot be greater than eligible amount");
							setNGFocus('ClaimedAmount');
							return false;
						}
				}
				//else if(Moving of Personal Effects)				{				}				
				
				return true;
				}
				case 'btn_cmnthsty':	
                {				
				//Session id need to be captured here
                //var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				
				window.parent.executeAction('1','Y');
				var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				//alert('Pid1:'+Pid1);
				//alert('WorkItemName:'+Pid2);
				//var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ID="+Sessionid+"&ProcessInstanceId="+Sessionid;
				var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ProcessInstanceId="+Pid1;
			    window.open(url,"","scrollbars=1,resizable=1,width=800,height=400");
			    return true;
				break;
				}
				
				case 'btn_DORMail':
			   {
					
				   var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				   var strInitBy = com.newgen.omniforms.formviewer.getNGValue("InitBy");
				   var w = 600;
				   var h = 600;
				   var left = Number((screen.width/2)-(w/2));
                   var tops = Number((screen.height/2)-(h/2));
				   
				   var url="/webdesktop/CustomJSP/APDORMail.jsp?ProcInstId="+Pid1+"&emailId="+strInitBy;

				   window.open(url,"","toolbar=no,directories=no, status=no, menubar=no,scrollbars=1,resizable=1,width=600,height=600,top="+tops+",left="+left+"");
				   return  false;
				   break;
			   }
				
			   case 'btn_trnsdtl':
				{
				//var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				var Emp_Code=com.newgen.omniforms.formviewer.getNGValue("EmployeeCode");
				//Below line added on 03-01-2017  by Bala G for set display details based on subcategory
				var Subcat_1=com.newgen.omniforms.formviewer.getNGValue("SubCategory1");
				//alert('Subcat_1='+Subcat_1);
                //alert("Sessionid :"+Emp_Code);
				var url="/webdesktop/CustomJSP/Transaction.jsp?ID1="+Emp_Code+"&SubCategory1="+Subcat_1+"&ProcessInstanceId="+Pid1;
				
				//var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ProcessInstanceId="+Pid1;
			    window.open(url,"","scrollbars=1,resizable=1,width=800,height=400");
				return false;
				break;
			   }
			   case 'btn_Reject':
			   {
				    
				   if(!(mandateCheck_AP('Comments', 'comments')))
				   {
					   return false;
					   break;
				   }
				   /*if(!(mandateCheck_AP('RejectReason', 'RejectReason')))
				   {
					   return false;
					   break;
				   }*/
				   return true;
				   break;
			   }
			   case 'btn_submit':
			   {

				if (activityName=='Scanning' || activityName=='Indexing') 
				{
				        if(!(
						mandateCheck_VP('InvoiceNo', 'Invoice Number')
						&& mandateCheck_VP('TotInvoiceAmnt', 'Invoice Amount')								
						)
						)
					   {					 
						   return false;
					   }
						if((ValidateSubmitAP())&&(validateDocumentType('Invoice', 'Invoice')))
						 {
							return true;
						 }
						 else
						 {
							return false;
						 }
				}
				else if (activityName=='Manual_Initiation' ) 
				{
						if((ValidateSubmitAP())&&(validateDocumentType('Invoice', 'Invoice')))
						 {
							return true;
						 }
						 else
						 {
							return false;
						 }
				}				
				else
				{
						return true;
				}
				 
				return true;
				break;
			   } 						  
			   case 'btn_add_nonpo' :
			   {
						if(!(
						//mandateCheck_AP('txt_line_sino_nonpo', 'SI NO')
						mandateCheck_AP('txt_line_nonpotext', 'line item text')
						&& mandateCheck_AP('txt_line_itemamnt_nonpo','item amount')
						&& mandateCheck_AP('txt_line_plantcode_nonpo', 'plant code')
						&& mandateCheck_AP('txt_line_bussarea_nonpo', 'bussiness area')
						&& mandateCheck_AP('txt_line_taxcode_nonpo','tax code')
						&& mandateCheck_AP('txt_line_taxamnt_nonpo', 'tax amount')
						&& mandateCheck_AP('txt_line_glcode_nonpo','general ledger code')
						&& mandateCheck_AP('txt_line_cccode_nonpo','cost center code')
						&& mandateCheck_AP('txt_line_pccode_nonpo', 'profit centre code')
						&& mandateCheck_AP('txt_line_intorder_nonpo', 'internal order')
						&& mandateCheck_AP('txt_line_glindic_nonpo', 'special gl indicator')
						&& mandateCheck_AP('txt_line_wbsele_nonpo', 'wbs element')
						)
						)
					   {
						   return false;
					   }
					   return true;
					   break;
			   }
			   case 'btn_mod_nonpo' :
			   {
						if(!(
						mandateCheck_AP('txt_line_sino_nonpo', 'si no')
						&& mandateCheck_AP('txt_line_nonpotext', 'line item text')
						&& mandateCheck_AP('txt_line_itemamnt_nonpo','item amount')
						&& mandateCheck_AP('txt_line_plantcode_nonpo', 'plant code')
						&& mandateCheck_AP('txt_line_bussarea_nonpo', 'bussiness area')
						&& mandateCheck_AP('txt_line_taxcode_nonpo','tax code')
						&& mandateCheck_AP('txt_line_taxamnt_nonpo', 'tax amount')
						&& mandateCheck_AP('txt_line_glcode_nonpo','general ledger code')
						&& mandateCheck_AP('txt_line_cccode_nonpo','cost center code')
						&& mandateCheck_AP('txt_line_pccode_nonpo', 'profit centre code')
						&& mandateCheck_AP('txt_line_intorder_nonpo', 'internal order')
						&& mandateCheck_AP('txt_line_glindic_nonpo', 'special gl indicator')
						&& mandateCheck_AP('txt_line_wbsele_nonpo', 'wbs element')
						)
						)
					   {
						   return false;
					   }
					   return true;
					   break;
			   }
			   case 'btn_del_nonpo' :
			   {
			   return true;
			   }
			   case 'btn_Exception' :
			   {
			   return true;
			   }
			   case 'btn_park' :
			   {
				return true;
			   } 
			   case 'btn_Approve' :
			   {
			  // alert("Inside btn_park");
					if(!(
						mandateCheck_VP('InvoiceNo', 'Invoice Number')
						&& mandateCheck_VP('TotInvoiceAmnt', 'Invoice Amount')
						&& mandateCheck_VP('DocHeadText','Document Header Text')
						&& mandateCheck_VP('Text', 'Text')
						&& mandateCheck_VP('BusiSec', 'bussiness Section/Area')					
						)
						)
					   {
					   //alert("Inside final false");
						   return false;
					   }					 
					 //  alert("Inside final true");
					 //alert("strPORef="+strPORef);
					 if(strPORef=='4') //WBS-code mandatory if its service po 
					 {
					 if(!(
						mandateCheck_VP('WHTCode', 'WHTCode')))
						{
						  return false;
						}
					 
					 }
					   return true;					 
					 //  break;
			   }
			   case 'btn_Rescan' :
			   {
			   return true;
			   }
			   case 'btn_Rescan' :
			   {
			   return true;
			   }
			   case 'Btn_SAP' :
			   {
			   return true;
			   }
			   case 'btn_SAP_PO' :
			   {
			   return true;
			   }
			   case 'Button_add_attachments':
			   {
			   //window.parent.openDocList();//To Load Document List from Document Button
			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
			   }
			   case 'Button_admin_add_attachments':
			   {
			   //window.parent.openDocList();//To Load Document List from Document Button
			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
			   }
			   case 'btn_SAP_Post':
			   {
				   //window.parent.openDivElement('SAP0', 'FBV0', '' , 'SAP');
				   if(getNGValue("InitSts")=='ER'){ 
				   window.parent.openDivElement('SAP0', 'PostTCode', '' , 'SAP');
				   return true;
				   //break;
				   }
				   else if(getNGValue("InitSts")=='VP'){ 
				   
				   return true;				   
				   }
				   else if(getNGValue("InitSts")=='TC'){ 
				   window.parent.openDivElement('SAP0', 'PostTCode', '' , 'SAP');
				   return true;				   
				   }
				   
				   
			   }
			   
			   case 'btn_Travel':
			   {
				   //var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				   var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				   var sWID=getNGValue("WorkID");
				   //alert('Pid1:'+Pid1);
				   //alert('sWID:'+sWID);
				   var url="/webdesktop/CustomJSP/Travel_Xcel.jsp?ID1="+Pid1+"&WorkstepName="+activityName;
				   //window.open(url,"","width=900,height=900");
				   window.open(url,"","scrollbars=1,resizable=1,width=900,height=900");
				   return  false;
				   break;
			   }
			   case 'btn_Cab':
			   {
				   //var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				   var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				   var url="/webdesktop/CustomJSP/Cab_Xcel.jsp?ID1="+Pid1+"&WorkstepName="+activityName;
				   //alert("inside cab btn="+activityName);
				   //window.open(url,"","width=900,height=900");
				   window.open(url,"","scrollbars=1,resizable=1,width=900,height=900");
				   return  false;
				   break;
			   }
			   case 'btn_SAP_MPO':
			   {
			     //alert("Inside btn_SAP_MPO");
			     var CompCode=com.newgen.omniforms.formviewer.getNGValue("CompanyCode");
				 var VendorCode1=com.newgen.omniforms.formviewer.getNGValue("VendCode");
				 var Indicator_val=com.newgen.omniforms.formviewer.getNGValue("Indicate");
				 //alert("CompCode="+CompCode+";VendorCode="+VendorCode1);
				 var url1="/webdesktop/CustomJSP/MPO/Brit_MultiplePO_Main.jsp?CompanyCode="+CompCode+"&VendorCode="+VendorCode1+"&Indicator="+Indicator_val;
				 
				 
				 //alert("dynamicURL:"+dynamicURL);				 
				 //url1=dynamicURL+url1;
			//alert("url1:"+url1);
			
			var newWindow=window.open(url1,"","width=900,height=900");
			
			
				 //sURL=dynamicURL+"/webdesktop/Customisation/Sanmar_FetchPOFromVendorAndGRN_Main.jsp?CompanyCode="+strCompanyCode;
							//var newWindow = window.showModalDialog(dynamicURL+url1, '', "dialogWidth:1000px;dialogHeight:1000px; help:no;border:thin; status:no; center:yes");
							
							//var newWindow = window.open(dynamicURL+url1, '', "dialogWidth:1000px;dialogHeight:1000px; help:no;border:thin; status:no; center:yes");
							
							//newWindow=window.returnValue;
							
							//alert("JSP Result in JS 2:"+newWindow);
							//window.location.href = newWindow;
							
				 				 			
    var timer = setInterval(function ()
    {
        if (newWindow.closed)
        {
            clearInterval(timer);
            var returnValue = newWindow.returnValue;
			alert("returnValue="+returnValue);
			setNGValue("Text_MPO_Output",returnValue.toString());
            callback(returnValue);
        }
    }, 500);
				 
				 return true;
				 break;
			   }
//Newlyy added by Bala.G on 24-08-2018
             case 'btn_reverse':
			 {
			 return true;
			 break;
			  }
			  //btn_mod_po Newlyy added by Bala.G on 07-09--2018
			 case 'btn_mod_po':
			 {
			 return true;
			 break;
			  }
			}
			//alert("End of Click");
			//return true;
			return false;
			//break;
		}//End of Click
		case 'change':
		{
			switch (pEvent.srcElement.id)
			{
			
			case 'TicketFunction':
				{				
				return true;					
				}
			case 'TicketCategory':
				{				
				return true;					
				}
			case 'TicketSubCategory':
				{				
				return true;					
				}
			case 'TicketAction':
				{				
				return true;					
				}
			case 'InitUser_TicketAction':
				{	
					var myWindow;
					if(activityName == 'User_Confirmation'){	
						var strInitUserAction = getNGValue('InitUser_TicketAction');						
						if( strInitUserAction == 'Accept'){														
							var len=history.length;   
							history.go(-len);								
							 var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
							 var strInitBy = com.newgen.omniforms.formviewer.getNGValue("InitiationBy");
							 var varEmpName = com.newgen.omniforms.formviewer.getNGValue("EmployeeName");
							 var varEmpMailID = com.newgen.omniforms.formviewer.getNGValue("EmailID");
							var w = 600;
							var h = 600;
							var left = Number((screen.width/2)-(w/2))-200;
							var tops = Number((screen.height/2)-(h/2))+50;				   
							var url="/webdesktop/CustomJSP/Feedback_Form.jsp?ProcInstId="+Pid1+"&emailId="+varEmpMailID+"&empName="+varEmpName;
							myWindow = window.open(url,"FeedBack","toolbar=no,directories=no, status=no, menubar=no,scrollbars=1,resizable=1,width=800,height=570,top="+tops+",left="+left+"");
																									
						}else{
							myWindow.close();
						}
					}
				return true;					
				}				
			case 'EmployeeCode':
				{				
				return true;					
				}
			case 'BillDate':
				{
					 if(!(futuredate_AP('BillDate')))
				   {
					   return false;
					  
				   }
				   
				break;	
				}
				case 'TypeOfInvoice':
				{
				return true;                
				}
				
				case 'cb_entschm_accref':
				{
				return true;                
				}
				case 'cb_entschm_accref':
				{
				return true;                
				}				
				
			}
			//return true;
			return false;
			
		}
		case 'focus':
        {
		
		//alert('In Focus');
            switch (pEvent.srcElement.id) 
            {  
			
			case 'RoadtaxYN':
			{
				return true;                
			}
			case 'LossYN':
			{
				return true;                
			}
			case 'OctroiYN':
			{
				return true;                
			}
			case 'PackYN':
			{
				return true;                
			}
			
			case 'TypeOfProcess':
			{
				return true;                
			}
			case 'TotInvoiceAmnt':
			{
				return true;                
			}
			case 'ExchangeRate':
			{
				return true;                
			}
			
			
            }
			//alert('End of focus');
			return false;
        }//End of Focus
		case 'blur':
        {
			//alert("blur");
			switch (pEvent.srcElement.id) 
            {  
			
			
			case 'RoadtaxYN':
			{
				return true;                
			}
			case 'LossYN':
			{
				return true;                
			}
			case 'OctroiYN':
			{
				return true;                
			}
			case 'PackYN':
			{
				return true;                
			}
			
			case 'TypeOfProcess':
			{
				return true;                
			}
			case 'TotInvoiceAmnt':
			{
				return true;                
			}
			case 'ExchangeRate':
			{
				return true;                
			}
			
            }
			return false;
			//return true;
		}//End of blur
		
		case 'keydown':
		{
			switch (pEvent.srcElement.id) 
            { 
			
			case 'EmployeeCode':
				{				
					
				return false;
				break;	
				}
				
				return false;
			}
		
		}//End of event keydown
		
		return false;
		/*default:
		{
		return false;
		break;
		}*/
	}//End of Switch 
	//alert('End of Event dispatched');
	
}//end of eventDispatched_HelpDesk
