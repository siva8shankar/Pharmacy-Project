
var activityName=window.parent.stractivityName;
var processName = window.parent.strprocessname;
var pid1=window.parent.strWorkitemName;
var date1= new Date();
var dynamicURL=window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
/*function eventDispatchedAP(pEvent.type)
{
	alert("inside event dispatched HelpDesk.js :"+pEvent.type);
	return true;
}*/

//alert ("In HelpDesk.js");


function formPopulated_LR(){
	
}


function mandateCheck_LR(controlName, messageString)
{
	var nonzero=0.00;
	var color1=getNGValue('mandcolor');
	if(!color1=="")
	{
		com.newgen.omniforms.formviewer.setNGBackColor(controlName, "#FFFFFF");
	}
     //alert('Mandate Check Running HelpDesk...');
    //if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--'||getNGValue(controlName) ==nonzero)
	if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--' || getNGValue(controlName) == 'Select an Action' || getNGValue(controlName) == 'Select a Category' )
	//Ended By Harinath on 2017/07/03
    {		
		com.newgen.omniforms.util.showError(controlName,'Please enter the ' + messageString);
		//alert('Please enter the ' + messageString);
        //showError('controlName','PLEASE ENTER THE ' + messageString);   
		com.newgen.omniforms.formviewer.setNGBackColor(controlName,"#F2F5A9");	
        //setNGFocus(controlName);
        var c1=controlName;        
        com.newgen.omniforms.formviewer.setNGValue('mandcolor',c1);
        //alert("gg"+getNGValue('mandcolor'));
        return false;
    }
    return true;

}

//For event handing function
function eventDispatched_LR(pId, pEvent) 
{
	//alert("inside Event Dispatched Funtion");
	
//alert('processName:'+processName);
//alert('activityName:'+activityName);
	window.status = pId + "_" + pEvent.type;
	//alert(pEvent.type+" "+pEvent.srcElement.id);
	var strSubcategory=getNGValue('SubCategory1');
	var strTypeOfInvoice=getNGValue('TypeOfInvoice');
	var strPORef=getNGValue('PORef'); //PO or NON-PO
	switch(pEvent.type)
    {           
       
	   case 'click':
        {
            switch(pEvent.srcElement.id)
            {				
				case 'btn_submit':	
                {
					if((getNGValue('Flag')) == 'Rework' && (getNGValue('ApprChk1')) == ''){
						if (!(mandateCheck_LR('ComplaintAbout', 'Complaint About') 
						&& mandateCheck_LR('ReferenceComment','Reference Comments')
						&& mandateCheck_LR('DetailsOfTheComplaint', 'Details Of The Complaint') 
						&& mandateCheck_LR('Comments', 'Comments')
						))
						{
							return false;
						}
					}else if((getNGValue('Flag')) == 'Rework' && (getNGValue('ApprChk1')) == 'RegistrationApprove' && (getNGValue('ApprChk2')) == 'RegistrationApprove'){
						if (!(mandateCheck_LR('ActionOnComment', 'Action Taken') 
						))
						{
							return false;
						}
					}else{
						if (!(mandateCheck_LR('ComplaintAbout', 'Complaint About') 
						&& mandateCheck_LR('ReferenceComment','Reference Comments')
						&& mandateCheck_LR('DetailsOfTheComplaint', 'Details Of The Complaint') 
						&& mandateCheck_LR('Comments', 'Comments')
						&& mandateCheck_LR('ComplaintAction', 'Complaint Action')
						))
						{
							return false;
						}
					}										
						if(getNGValue('ComplaintAbout') == 'Others'){	
						if (!(mandateCheck_LR('ComplaintOthersFreeText', 'Complaint Others Free Text')))
						{
							return false;
						}
						}
					return true;					
				}
				case 'btn_approve':	
                {
				return true;
				}			
				case 'btn_searchemployee':	
                {
				return true;
				}
				case 'btn_load':	
                {
				return true;
				}				
				case 'btn_save':	
                {
				return true;
				
				}
				case 'btn_close':	
                {
				onWiCloseMsgClick();
				return true;
				
				}
				case 'btn_rework':	
                {
				return true;
				
				}
				case 'btn_reject':	
                {
				return true;
				
				}
			   case 'Button_add_attachments':
			   {
			   //window.parent.openDocList();//To Load Document List from Document Button
			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
			   }
			   case 'Button_admin_add_attachments':
			   {
			   //window.parent.openDocList();//To Load Document List from Document Button
			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
			   }
			   case 'btn_add_vphr_attachements':
			   {			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
			   }
             case 'btn_reverse':
			 {
			 return true;
			 break;
			  }
			  //btn_mod_po Newlyy added by Bala.G on 07-09--2018
			 case 'btn_mod_po':
			 {
			 return true;
			 break;
			  }
			}
			//alert("End of Click");
			//return true;
			return false;
			//break;
		}//End of Click
		case 'change':
		{
			switch (pEvent.srcElement.id)
			{
			
			case 'q_ComplaintAbout':
				{	
				
				var complaintAbout = $("#q_ComplaintAbout").val();
				   if (complaintAbout[0] == "Others" || complaintAbout[1] == "Others" || complaintAbout[2] == "Others" || complaintAbout[3] == "Others" || complaintAbout[4] == "Others")
					{
						document.getElementById("ComplaintOthersFreeText").value="";
					   document.getElementById("ComplaintOthersFreeText").disabled = false;
					   document.getElementById("ComplaintOthersFreeText").style.background="#fff";
					} else {            
						document.getElementById("ComplaintOthersFreeText").value="";
					   document.getElementById("ComplaintOthersFreeText").disabled = true;
					   document.getElementById("ComplaintOthersFreeText").style.background="rgb(231, 228, 228)";
					}
				return true;					
				}
			case 'ComplaintAction':
				{				
				return true;					
				}
			case 'cb_FinalActionOnComplaint':
				{				
				return true;					
				}
			case 'TicketAction':
				{				
				return true;					
				}
			case 'InitUser_TicketAction':
				{	
					var myWindow;
					if(activityName == 'User_Confirmation'){	
						var strInitUserAction = getNGValue('InitUser_TicketAction');						
						if( strInitUserAction == 'Accept'){														
							var len=history.length;   
							history.go(-len);								
							 var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
							 var strInitBy = com.newgen.omniforms.formviewer.getNGValue("InitiationBy");
							 var varEmpName = com.newgen.omniforms.formviewer.getNGValue("EmployeeName");
							 var varEmpMailID = com.newgen.omniforms.formviewer.getNGValue("EmailID");
							var w = 600;
							var h = 600;
							var left = Number((screen.width/2)-(w/2))-200;
							var tops = Number((screen.height/2)-(h/2))+50;				   
							var url="/webdesktop/CustomJSP/Feedback_Form.jsp?ProcInstId="+Pid1+"&emailId="+varEmpMailID+"&empName="+varEmpName;
							myWindow = window.open(url,"FeedBack","toolbar=no,directories=no, status=no, menubar=no,scrollbars=1,resizable=1,width=800,height=570,top="+tops+",left="+left+"");
																									
						}else{
							myWindow.close();
						}
					}
				return true;					
				}				
			case 'EmployeeCode':
				{				
				return true;					
				}
			case 'BillDate':
				{
					 if(!(futuredate_AP('BillDate')))
				   {
					   return false;
					  
				   }
				   
				break;	
				}
				case 'TypeOfInvoice':
				{
				return true;                
				}
				
				case 'cb_entschm_accref':
				{
				return true;                
				}
				case 'cb_entschm_accref':
				{
				return true;                
				}				
				
			}
			//return true;
			return false;
			
		}
		case 'focus':
        {
		
		//alert('In Focus');
            switch (pEvent.srcElement.id) 
            {  
			
			case 'RoadtaxYN':
			{
				return true;                
			}
			case 'LossYN':
			{
				return true;                
			}
			case 'OctroiYN':
			{
				return true;                
			}
			case 'PackYN':
			{
				return true;                
			}
			
			case 'TypeOfProcess':
			{
				return true;                
			}
			case 'TotInvoiceAmnt':
			{
				return true;                
			}
			case 'ExchangeRate':
			{
				return true;                
			}
			
			
            }
			//alert('End of focus');
			return false;
        }//End of Focus
		case 'blur':
        {
			//alert("blur");
			switch (pEvent.srcElement.id) 
            {  
			
			
			case 'RoadtaxYN':
			{
				return true;                
			}
			case 'LossYN':
			{
				return true;                
			}
			case 'OctroiYN':
			{
				return true;                
			}
			case 'PackYN':
			{
				return true;                
			}
			
			case 'TypeOfProcess':
			{
				return true;                
			}
			case 'TotInvoiceAmnt':
			{
				return true;                
			}
			case 'ExchangeRate':
			{
				return true;                
			}
			
            }
			return false;
			//return true;
		}//End of blur
		
		case 'keydown':
		{
			switch (pEvent.srcElement.id) 
            { 
			
			case 'EmployeeCode':
				{				
					
				return false;
				break;	
				}
				
				return false;
			}
		
		}//End of event keydown
		
		return false;
		/*default:
		{
		return false;
		break;
		}*/
	}//End of Switch 
	//alert('End of Event dispatched');
	
}//end of eventDispatched_LR
