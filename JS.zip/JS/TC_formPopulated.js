//Added by Harinatha R on 13/09/2017
var activityName=window.parent.stractivityName;

function formPopulated_TC() 
{
//alert("inside formPopulated_AP Funtion");
//alert("inside formPopulated_AP Funtion activityName:"+activityName);
com.newgen.omniforms.formviewer.setEnabled("Btn_CmntHistry",true);
//com.newgen.omniforms.formviewer.setEnabled("btn_trnsdtl",true);
//com.newgen.omniforms.formviewer.setEnabled("btn_DORMail",true);
//return true;

	/*if ((activityName=='Manual_Initiation'))
	{
		var TypeOfInvoice=getNGValue("TypeOfInvoice");
		if(TypeOfInvoice=="--Select--" || TypeOfInvoice=="")
		{
		alert('In TC');

		setHeight("frm_tran_details2", 100);

		}

	}*/

}//End of formPopulated_AP