//Added by Nanjunda Moorthy on 03/02/2017
var activityName=window.parent.stractivityName;

function formPopulated_AP() 
{
//alert("inside formPopulated_AP Funtion");
com.newgen.omniforms.formviewer.setEnabled("btn_cmnthsty",true);
com.newgen.omniforms.formviewer.setEnabled("btn_trnsdtl",true);
com.newgen.omniforms.formviewer.setEnabled("btn_DORMail",true);
//return true;

	/*if ((activityName=='Manual_Initiation'))
	{
		var TypeOfInvoice=getNGValue("TypeOfInvoice");
		if(TypeOfInvoice=="--Select--" || TypeOfInvoice=="")
		{
		alert('In TC');

		setHeight("frm_tran_details2", 100);

		}

	}*/

}//End of formPopulated_AP