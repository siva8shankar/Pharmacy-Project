/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


var activityName;
var processName;
var workitemName;
var strProcessinstanceID;
var requestType;
var legislationType;
var period;
var curMonth;
var pfForOnly;
var qFourAdd;
//added for Dynamic URL
var dynamicURL=window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
function eventDispatched_SP(pId, pEvent)
{
    processname=window.parent.strprocessname;
    activityName=window.parent.stractivityName;
    strProcessinstanceID=getNGValue("PID");
    requestType=getNGValue('TypeOfRequest');
    legislationType=getNGValue('StatutoryLegislation');
	pfForOnly=getNGValue('FlagTDS');
	period=getNGValue('Period');
	qFourAdd=getNGValue('CTAddQ4Pay');
	
    curMonth = getCurMonth();
    window.status = pId + "_" + pEvent.type;

    switch (pEvent.type) 
    {
        case 'click':
        {
            switch (pEvent.srcElement.id) 
            {   
                case 'BtnComntHistry':
                {
                    //Session id need to be captured here
                    var Pid1=getNGValue("PID");
                  
                    var url=dynamicURL+"/webdesktop/CustomJSP/CommentsHistory_SP.jsp?ProcessInstanceId="+Pid1;
                    window.open(url,"","width=750,height=325");
                    return true;
                    break;
                }
                
                case 'BtnInitiate':
                {	
					if(requestType=="ISDReversal" || requestType=="ISDInvoice")
					{
						if (!( mandateCheck('Location', 'Location') 
							&& mandateCheck('Region', 'Region') 
							&& mandateCheck('Entity', 'Entity') 
							&& mandateCheck('TypeOfRequest', 'TypeOfRequest') 
							&& mandateCheck('FinancialYear', 'FinancialYear') 
							&& mandateCheck('Period', 'Period') 
							//&& mandateCheck('PaymentFor', 'PaymentFor')
                      
							))
                        {
							return false;
						}
					}
					else
					{
						if (!( mandateCheck('Location', 'Location') 
							&& mandateCheck('Region', 'Region') 
							&& mandateCheck('Entity', 'Entity') 
							&& mandateCheck('TypeOfRequest', 'Type Of Request') 
							&& mandateCheck('FinancialYear', 'Financial Year') 
							&& mandateCheck('Period', 'Period')
							&& mandateCheck('StatutoryLegislation', 'Statutory Legislation') 
							//&& mandateCheck('PaymentFor', 'Payment For')                      
							))
						{
							return false;
						}
					}
                    var EnableFields1=[/*"cmplx_NR_RFA_q_Type2","cmplx_NR_RFA_q_Scope2",*/"cmplx_NR_RFA_q_Subject2","cmplx_NR_RFA_q_CaseNo2","cmplx_NR_RFA_CasePeriodFom2","cmplx_NR_RFA_CasePeriodTo2","cmplx_NR_RFA_q_Principle2","cmplx_NR_RFA_q_Interest2","cmplx_NR_RFA_q_Penalty2","cmplx_NR_RFA_q_PartPaymMode22","cmplx_NR_RFA_q_BalDue2","cmplx_NR_RFA_q_ProviAvail2","cmplx_NR_RFA_PeriodAppvalFrom2","cmplx_NR_RFA_PeriodAppvalTo2","cmplx_NR_RFA_PeriodAppvalTo2","cmplx_NR_RFA_q_InterestPaid2","cmplx_NR_RFA_q_PenaltyPaid2"];
					
                    if(getNGValue('IncludesCST')=='Yes'){
                        
                        enableFields(EnableFields1, "Enable")
                                
                    }
                    else{
                        enableFields(EnableFields1, "Disable")
                    }
					
                    
                    return true;
                    break;
                }
                case 'BtnSubmit':
                {
                    if(activityName=='Initiator' || activityName=='Rework'){
                        //NonRoutineRFA
                        if(requestType=='Non-RoutineRFA'){
                            
                            if (!(/*mandateCheck('cmplx_NR_RFA_q_Type1', 'Type') 
                                    && mandateCheck('cmplx_NR_RFA_q_Scope1', 'Scope') 
                                    && */mandateCheck('cmplx_NR_RFA_q_Subject1', 'Subject') 
                                    && mandateCheck('cmplx_NR_RFA_q_CaseNo1', 'Case Number') 
                                    && mandateCheck('cmplx_NR_RFA_CasePeriodFrm1', 'Case Period From') 
                                    && mandateCheck('cmplx_NR_RFA_CasePeriodTo1', 'Case Period To') 
                                    && mandateCheck('cmplx_NR_RFA_q_Principle1', 'Principle') 
                                    && mandateCheck('cmplx_NR_RFA_q_Interest1', 'Interest') 
                                    && mandateCheck('cmplx_NR_RFA_q_Penalty1', 'Penalty') 
                                    && mandateCheck('cmplx_NR_RFA_q_PartPayMode11', 'Part Payment Made') 
                                    && mandateCheck('cmplx_NR_RFA_q_BalDue1', 'Balance Due') 
                                    && mandateCheck('cmplx_NR_RFA_q_ProviAvail1', 'Provision Available') 
                                    /*
									&& mandateCheck('cmplx_NR_RFA_PeriodAppvlFrm1', 'Period for Approval (From Date)') 
                                    && mandateCheck('cmplx_NR_RFA_PeriodAppvlTo1', 'Period for Approval (To Date)') 
                                    
                                    && mandateCheck('cmplx_NR_RFA_q_PenaltyPaid1', 'Penalty to be Paid')   
                                    && mandateCheck('cmplx_NR_RFA_q_InterestPaid1', 'Interest to be Paid') 
									*/
                                    ))
                                {
                                    return false;
                                }
							if(legislationType=='VAT' || legislationType=='TDS' || legislationType=='Service Tax'){
								if(getNGValue("IncludesCST")=='Yes' || getNGValue("IncludesTCS")=='Yes' || legislationType=='Service Tax'){
									if (!(/*mandateCheck('cmplx_NR_RFA_q_Type2', 'Type') 
                                        && mandateCheck('cmplx_NR_RFA_q_Scope2', 'Scope') 
                                        && */mandateCheck('cmplx_NR_RFA_q_Subject2', 'Subject') 
                                        && mandateCheck('cmplx_NR_RFA_q_CaseNo2', 'Case Number') 
                                        && mandateCheck('cmplx_NR_RFA_CasePeriodFrm2', 'Case Period From') 
                                        && mandateCheck('cmplx_NR_RFA_CasePeriodTo2', 'Case Period To') 
                                        && mandateCheck('cmplx_NR_RFA_q_Principle2', 'Principle') 
                                        && mandateCheck('cmplx_NR_RFA_q_Interest2', 'Interest') 
                                        && mandateCheck('cmplx_NR_RFA_q_Penalty2', 'Penalty') 
                                        && mandateCheck('cmplx_NR_RFA_q_PartPaymMode22', 'Part Payment Made') 
                                        && mandateCheck('cmplx_NR_RFA_q_BalDue2', 'Balance Due') 
                                        && mandateCheck('cmplx_NR_RFA_q_ProviAvail2', 'Provision Available') 
										/*
                                        && mandateCheck('cmplx_NR_RFA_PeriodAppvalFrom2', 'Period for Approval (From Date)') 
                                        && mandateCheck('cmplx_NR_RFA_PeriodAppvalTo2', 'Period for Approval (To Date)') 
                                        && mandateCheck('cmplx_NR_RFA_q_InterestPaid2', 'Interest to be Paid') 
                                        && mandateCheck('cmplx_NR_RFA_q_PenaltyPaid2', 'Penalty to be Paid')  
										*/
                                        ))
                                    {
										return false;
									} 								
								}							
							}								
                        }
                        //Additional RFA
                        if(requestType=='AdditionalRFA'){
						  if(legislationType=='VAT' || legislationType=='TDS'){
                                if(getNGValue("IncludesCST")=='Yes' || getNGValue("IncludesTCS")=='Yes'){
										if (!(mandateCheck('cmplx_AddRFA1_q_AuthGovOrg', 'Authority') 
										&& mandateCheck('cmplx_AddRFA1_q_ReqAmount', 'Requested Amount')
										&& mandateCheck('cmplx_AddRFA1_q_PreYearPay', 'Previous Year Payment')
										&& mandateCheck('cmplx_AddRFA1_q_NoOfInstlmnt', 'Number of Installment Carry Forward')
										&& mandateCheck('cmplx_AddRFA1_q_AmtAdjPerInstall', 'Amount to be adjusted per Installment')
										//&& mandateCheck('AdditionalRFA_ApprvAmt', 'Approved Amount')
										))
										{
										return false;
									}	
								}
								else{
										if (!(mandateCheck('cmplx_AddRFA_q_AuthGovOrg', 'Authority') 
										&& mandateCheck('cmplx_AddRFA_q_ReqAmount', 'Requested Amount')
										&& mandateCheck('cmplx_AddRFA_q_PreYearPay', 'Previous Year Payment')
										&& mandateCheck('cmplx_AddRFA_q_NoOfInstlmnt', 'Number of Installment Carry Forward')
										&& mandateCheck('cmplx_AddRFA_q_AmtAdjPerInstall', 'Amount to be adjusted per Installment')
										//&& mandateCheck('AdditionalRFA_ApprvAmt', 'Approved Amount')
										))
										{
										return false;
									}
								
								}
							}
							else{
                            if (!(mandateCheck('cmplx_AddRFA_q_AuthGovOrg', 'Authority') 
                                && mandateCheck('cmplx_AddRFA_q_ReqAmount', 'Requested Amount')
                                && mandateCheck('cmplx_AddRFA_q_PreYearPay', 'Previous Year Payment')
                                && mandateCheck('cmplx_AddRFA_q_NoOfInstlmnt', 'Number of Installment Carry Forward')
                                && mandateCheck('cmplx_AddRFA_q_AmtAdjPerInstall', 'Amount to be adjusted per Installment')
                                //&& mandateCheck('AdditionalRFA_ApprvAmt', 'Approved Amount')
                                ))
                                {
                                return false;
                            }
							}                        
                        }
                        //Routine RFA
                        if(requestType=='RoutineRFA'){
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="VAT"){
							
                                if (!(
                                    mandateCheck('cmplx_VAT_q_VATOthrRev', 'Other Reversal') 
                                    && mandateCheck('cmplx_VAT_q_VATReb', 'Rebate') 
                                    && mandateCheck('cmplx_VAT_q_VATOthAdj', 'Other Adjustments') 
                                    && mandateCheck('cmplx_VAT_q_VATTolPay', 'Total VAT payable') 
                                    && mandateCheck('cmplx_VAT_q_VATPrvMonPay', 'Prev month Total VAT Payable') 
                                    //&& mandateCheck('cmplx_VAT_q_VATAvgLa3Mon', 'Average last three months') 
                                    //&& mandateCheck('cmplx_VAT_q_VATOthAdjFrmAddRFA', 'VAT Other Adjustments From Additional RFA ') 
                                    //&& mandateCheck('cmplx_VAT_q_VATAppOf', 'VAT Approval Of ') 
                                    //&& mandateCheck('cmplx_VAT_q_VATAppRRFA', 'VAT Approved in Routine RFA ') 
                                    ))
                                    {
                                    return false;
                                }	
                                if(com.newgen.omniforms.formviewer.getNGValue("IncludesCST")=="Yes"){
								
                                    if (!(
                                        mandateCheck('cmplx_VAT_q_CSTOthRev', 'Other Reversal in CST') 
                                        && mandateCheck('cmplx_VAT_q_CSTReb', 'Rebate In CST') 
                                        && mandateCheck('cmplx_VAT_q_CSTOthAdj', 'Other Adjustments in CST') 
                                        && mandateCheck('cmplx_VAT_q_CSTTotpay', 'Total CST payable') 
                                        && mandateCheck('cmplx_VAT_q_CSTPrevMonPay', 'Previous month Total CST Payable') 
                                        //&& mandateCheck('cmplx_VAT_q_CSTAvgLa3Mon', 'Average last three months') 
                                        //&& mandateCheck('cmplx_VAT_q_CSTOthAdjFrmAddRFA', 'CST Other Adjustments From Additional RFA') 
                                        //&& mandateCheck('cmplx_VAT_q_CSTAppOf', 'CST ApprovalOf') 
                                        //&& mandateCheck('cmplx_VAT_q_CSTAppRRFA', 'CST Approved in Routine RFA') 
                                        ))
                                        {
                                        return false;
                                    }
                                } 								
				
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS"){
								if(pfForOnly == "TDS" || (com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS" && pfForOnly != "TCS" && pfForOnly != "TDS")){
                                if (!(
                                    mandateCheck('cmplx_TDS_q_A194', '194 A') 
                                    && mandateCheck('cmplx_TDS_q_C194', '194 C') 
                                    && mandateCheck('cmplx_TDS_q_H194', '194 H') 
                                    && mandateCheck('cmplx_TDS_q_I194', '194 I') 
									&& mandateCheck('cmplx_TDS_q_IA194', '194 IA')
                                    && mandateCheck('cmplx_TDS_q_J194', '194 J') 
                                    && mandateCheck('cmplx_TDS_q_TDSAdjust', 'Adjustments') 
                                    && mandateCheck('cmplx_TDS_q_TDSTotPay', 'Total TDS Payable') 
                                    && mandateCheck('cmplx_TDS_q_TDSPrevMonPaid', 'Previous month TDS paid') 
                                    //&& mandateCheck('cmplx_TDS_q_TDSAvgThreeMon', 'Average TDS paid in the last three months') 
                                    //&& mandateCheck('cmplx_TDS_q_TDSApprovalOf', 'Approval of') 
                                    //&& mandateCheck('cmplx_TDS_q_TDSTotExcl195', 'Total TDS(excludint 195) approved in routine RFA') 
                                    ))
                                    {
										return false;
                                    }
								}								
                                if((com.newgen.omniforms.formviewer.getNGValue("IncludesTCS")=="Yes" && pfForOnly != "TCS" && pfForOnly != "TDS") || pfForOnly == "TCS"){
								
                                    if (!(
                                        mandateCheck('cmplx_TDS_q_C206', '206 C') 
                                        && mandateCheck('cmplx_TDS_q_TCSAdjust', 'Adjustments') 
                                        && mandateCheck('cmplx_TDS_q_TCSTotPay', 'Total TCS payable') 
                                        //&& mandateCheck('cmplx_TDS_q_TCSAvrThreeMon', 'Average TCS paid in the last three months') 
                                        && mandateCheck('cmplx_TDS_q_TCSPrevMonthPaid', 'Previous month TCS paid') 
                                        //&& mandateCheck('cmplx_TDS_q_TCSApprovalOf', 'Approval of') 
                                        //&& mandateCheck('cmplx_TDS_q_TCSTotApprvdRFA', 'Total TCS approved in routine RFA')
                                        ))
                                        {
                                        return false;
                                    }
                                }								
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS195"){
							
                                if (!(
                                    mandateCheck('cmplx_TDS195_q_CustName', 'Customer Name') 
                                    && mandateCheck('cmplx_TDS195_q_CustLocation', 'Customer Location') 
                                    && mandateCheck('cmplx_TDS195_q_ProductDetails', 'Product Details') 
                                    && mandateCheck('cmplx_TDS195_q_SalesValue', 'Sales Values') 
                                    && mandateCheck('cmplx_TDS195_q_ExpInvoiceNo', 'Export Invoice No.') 
                                    && mandateCheck('cmplx_TDS195_q_TDS195Pay', 'TDS 195 Payable') 
									&& mandateCheck('cmplx_TDS195_q_EqualLevied', 'Equalization Lieved')
                                    //&& mandateCheck('cmplx_TDS195_q_ApprovalOf', 'Approval Of') 
                                    //&& mandateCheck('cmplx_TDS195_q_ApprovedInRFA', 'Approved In RFA') 								
                                    ))
                                    {
                                    return false;
                                }								
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Entry Tax"){
							
                                if (!(
                                    mandateCheck('cmplx_Entry_q_Totalpay', 'Total Entry Tax payable') 
                                    //&& mandateCheck('cmplx_Entry_q_OthAdjARFA', 'Other adjustments Additional RFA') 
                                    && mandateCheck('cmplx_Entry_q_PrevMonPay', 'Prev month Total Entry Tax Paid') 
                                    //&& mandateCheck('cmplx_Entry_q_AvgLa3Mon', 'Average last three months') 
                                    //&& mandateCheck('cmplx_Entry_q_ApprvlOf', 'New Approval Amt.') 
                                    //&& mandateCheck('cmplx_Entry_q_TotTaxAppRRFA', 'Approved Amt. in RoutinRFA') 							
                                    ))
                                    {
                                    return false;
                                }								
							
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Excise Duty"){
							
                                if (!(
                                    mandateCheck('cmplx_Excise_q_ExcRegNo', 'Excise registration number') 
                                    && mandateCheck('cmplx_Excise_q_PLAPayable', 'PLA Excise Payable') 
                                    //&& mandateCheck('cmplx_Excise_q_AdjARFA', 'Adjustments - Additional RFA') 
                                    && mandateCheck('cmplx_Excise_q_PrevMonPay', 'Previous month PLA paid') 
                                    //&& mandateCheck('cmplx_Excise_q_AvgLa3Mon', 'Average PLA paid in the last three months') 
                                    && mandateCheck('cmplx_Excise_q_ExcPayble', 'Excise Payable') 
                                    && mandateCheck('cmplx_Excise_q_OBCenCrInput', 'Opening Balance Cenvat credit on input') 
                                    && mandateCheck('cmplx_Excise_q_CCIFTPeriod', 'Current period Cenvat credit on input') 
                                    && mandateCheck('cmplx_Excise_q_PCCIUsage', 'Planned usage Cenvat credit on input') 
                                    && mandateCheck('cmplx_Excise_q_OBCCCapGood', 'Opening Balance Cenvat credit on Capital Goods') 
                                    && mandateCheck('cmplx_Excise_q_CCCapGFTPeriod', 'Current period Cenvat credit on Capital Goods') 
                                    && mandateCheck('cmplx_Excise_q_PCCCapGUsage', 'Planned usage Cenvat credit on Capital Goods') 
                                    && mandateCheck('cmplx_Excise_q_OBCCIService', 'Opening Balance Cenvat credit on input service') 
                                    && mandateCheck('cmplx_Excise_q_CCIService', 'Current period Cenvat credit on input service') 
                                    && mandateCheck('cmplx_Excise_q_PCCISUsage', 'Planned usage Cenvat credit on input service') 
                                    && mandateCheck('cmplx_Excise_q_OthReavCredit', 'Current period Others reavilment of credit etc') 
                                    && mandateCheck('cmplx_Excise_q_POthersReavCr', 'Planned usage Others reavilment of credit etc') 
                                    && mandateCheck('cmplx_Excise_q_PLAOpenBal', 'Current period PLA Opening Balance') 
                                    && mandateCheck('cmplx_Excise_q_PlandPLAUsage', 'Planned usage PLA Opening Balance') 
									&& mandateCheck('cmplx_Excise_q_HigherEduCess', 'Higher Educational cess')
									&& mandateCheck('cmplx_Excise_q_SecEduCess', 'Secondary Educational cess')
									&& mandateCheck('cmplx_Excise_q_PlannedPLAPayable', 'Planned PLA Payable')
                                    //&& mandateCheck('cmplx_Excise_q_Rule63ARevGood', '6(3) A reversal goods') 
                                    //&& mandateCheck('cmplx_Excise_q_Rule63ARevServ', '6(3) A reversal services') 
                                    //&& mandateCheck('cmplx_Excise_q_OthRevGood', 'Other reversals goods') 
                                    //&& mandateCheck('cmplx_Excise_q_OthRevServ', 'Other reversals services') 
                                    ))
                                    {
                                    return false;
                                }								
							
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Service Tax"){
							
                                if (!(
                                    mandateCheck('cmplx_Service_q_TotSTPay', 'Total Service Tax payable') 
                                    && mandateCheck('cmplx_Service_q_TotOSTPay', 'Total output service tax payable tax payable') 
                                    //&& mandateCheck('cmplx_Service_q_AdjARFAST', 'Adjustments - Additional RFA') 
                                    && mandateCheck('cmplx_Service_q_NOSTPayBase', 'Base tax - Net output service tax payable') 
                                    && mandateCheck('cmplx_Service_q_NOSTPaySBC', 'SBC - Net output service tax payable') 
                                    && mandateCheck('cmplx_Service_q_STPrevMonPay', 'Previous month Output service tax paid') 
                                    //&& mandateCheck('cmplx_Service_q_STAvgLa3Mon', 'Average Output service tax paid for last threemonths') 
                                    //&& mandateCheck('cmplx_Service_q_ApprvalOf', 'Approval of') 
                                    //&& mandateCheck('cmplx_Service_q_TotAprvdOSTRRFA', 'Total approved output ST in routine RFA') 
                                    && mandateCheck('cmplx_Service_q_TotRCMSTPay', 'Total RCM service tax Payable') 
                                    //&& mandateCheck('cmplx_Service_q_AdjARFARCM', 'Adjustments - Additional RFA') 
                                    && mandateCheck('cmplx_Service_q_NRCMPayBase', 'Base tax - Net RCM Payable') 
                                    && mandateCheck('cmplx_Service_q_NRCMPaySBC', 'SBC - Net RCM Payable') 
                                    && mandateCheck('cmplx_Service_q_RCMPrevMonPay', 'Previous month RCM paid') 
                                    //&& mandateCheck('cmplx_Service_q_RCMAvgLa3Mon', 'Average RCM paid for last three months') 
                                    //&& mandateCheck('cmplx_Service_q_ApprvalOfRCM', 'Approval of') 
                                    //&& mandateCheck('cmplx_Service_q_TotAprvdRCMRRFA', 'Total approved RCM ST in routine RFA')  
                                    ))
                                    {
                                    return false;
                                }								
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Corporate Tax"){
							
                                if (!(
                                    mandateCheck('cmplx_Corporate_q_PLAccProfitPrev', 'Profit as per P&L Account Previous Year') 
                                    && mandateCheck('cmplx_Corporate_q_PLAccProfit', 'Profit as per P&L Account Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_PLAccProfitRemark', 'Profit as per P&L Account Remarks') 
                                    && mandateCheck('cmplx_Corporate_q_ItemsConSepPrev', 'Items Considered Seperately Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_ItemConSep', 'Items Considered Seperately Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_ItemConSepRemark', 'Items Considered Seperately Remarks')
                                    && mandateCheck('cmplx_Corporate_q_ItemConSepPrev2', 'Items Considered Seperately Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_ItemConSep2', 'Items Considered Seperately Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_ItemConSepRemark2', 'Items Considered Seperately Remarks')
                                    && mandateCheck('cmplx_Corporate_q_SubTotalPrev1', 'SubTotal Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_SubTotal1', 'SubTotal Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_SubTotallRemark1', 'SubTotal Remarks')
                                    && mandateCheck('cmplx_Corporate_q_TimeDiffPrev1', 'Timing Differences Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_TimeDiff1', 'Timing Differences Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_TimeDiffRemark1', 'Timing Differences Remarks')
                                    && mandateCheck('cmplx_Corporate_q_PermDiffPrev1', 'Permanent Differences Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_PermDiff1', 'Permanent Differences Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_PermDiffRemark1', 'Permanent Differences Remarks')
                                    && mandateCheck('cmplx_Corporate_q_SubTotalPrev2', 'Permanent Differences Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_TimeDiffPrev2', 'Permanent Differences Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_PermDiffPrev2', 'Permanent Differences Remarks')
                                    && mandateCheck('cmplx_Corporate_q_STBusIncPrev', 'SubTotal of Business Income Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_SubTotBusInc', 'SubTotal of Business Income Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_STBusIncRemark', 'SubTotal of Business Income Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFHPropPrev', 'Income from House Property Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFHProp', 'Income from House Property Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFHPropRemark', 'Income from House Property Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCIGNIPrev', 'Income from Long Term Capital Gains Non Indexed Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCIGNonIndex', 'Income from Long Term Capital Gains Non Indexed Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFLTCIGNIRemark', 'Income from Long Term Capital Gains Non Indexed Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGPrev', 'Income from Short Term Capital Gains Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGains', 'Income from Short Term Capital Gains Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFSTCGRemark', 'Income from Short Term Capital Gains Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCIGIPrev', 'Income from Long Term Capital Gains Indexed Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCIGIndex', 'Income from Long Term Capital Gains Indexed Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFLTCIGIRemark', 'Income from Long Term Capital Gains Indexed Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFOSPrev', 'Income from Other Sources Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFOSource', 'Income from Other Sources Indexed Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFOSRemark','Income from Other Sources Indexed Remarks')
                                    && mandateCheck('cmplx_Corporate_q_GTIPrev', 'Gross Total Income Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_GtotIncome', 'Gross Total Income Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_GTIRemark','Gross Total Income Remarks')
                                    && mandateCheck('cmplx_Corporate_q_DUCVIAPrev', 'Deductions under Chapter VI A Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_DUChapVIA', 'Deductions under Chapter VI A Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_DUCVIARemark','Deductions under Chapter VI A Remarks')
                                    && mandateCheck('cmplx_Corporate_q_AOElDPrev', 'Any other eligible deductions Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_AOElDeduct', 'Any other eligible deductions Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_AOElDRemark','Any other eligible deductions Remarks')
                                    && mandateCheck('cmplx_Corporate_q_TaxIncPrev', 'Taxable Income Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_TaxIncome', 'Taxable Income Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_TaxIncRemark','Taxable Income Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFBRate', 'Income from Business or Profession Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFBIncome', 'Income from Business or Profession Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFBTax','Income from Business or Profession Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFHPropRate', 'Income from House Property Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFHPropIncome', 'Income from House Property Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFHPropTax','Income from House Property Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGRate', 'Income from Short Term Capital Gains Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGIncome', 'Income from Short Term Capital Gains Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGTax','Income from Short Term Capital Gains Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGIRate', 'Income from Long Term Capital Gains Indexed Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGIIncome', 'Income from Long Term Capital Gains Indexed Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGITax','Income from Long Term Capital Gains Indexed Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGNIRate', 'Income from Long Term Capital Gains Non Indexed Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGNIIncome', 'Income from Long Term Capital Gains Non Indexed Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGNITax','Income from Long Term Capital Gains Non Indexed Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFOSRate', 'Income from Other Sources Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFOSIncome', 'Income from Other Sources Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFOSTax','Income from Other Sources Tax')
                                    && mandateCheck('cmplx_Corporate_q_IncTaxCurYear', 'Income Tax For The Year')
                                    && mandateCheck('cmplx_Corporate_q_TDSCreCurYear', 'TDS Credit For The Year') 
                                    && mandateCheck('cmplx_Corporate_q_NetTaxPay','Net Tax Payable')	
 
                                    ))
                                    {
                                    return false;
                                }	
								
								if(period == "Quarter1"){
                                //if(curMonth == "June" || curMonth =="July"){
                                    //Corporate Tax Q1 can be applied only in the month of June and July					
                                    if (!(
                                        mandateCheck('cmplx_Corporate2_q_MaxDueDateQ1', 'Maximum Due Date for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxPTBPQ1', 'Maximum % to be paid for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumTaxQ1', 'Maximum Cumulative Tax for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTFTQQ1', 'Maximum Tax for the Quarter Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTPFQQ1', 'Maximum Tax paid for the Quarter Q1')  
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumPayQ1', 'Maximum Cumulative payment/ Tax paid for quarter Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxBalPayQ1', 'Maximum Balance Payable for Q1')	
                                        && mandateCheck('cmplx_Corporate2_q_MinDueDateQ1', 'Minimum Due Date for Q1')
                                        && mandateCheck('cmplx_Corporate2_q_MinPerTBPQ1', 'Minimum % to be paid for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MinCumTaxQ1', 'Minimum Cumulative Tax for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTFTQQ1', 'Minimum Tax for the Quarter Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTPFQQ1', 'Minimum Tax paid for the Quarter Q1')  
                                        && mandateCheck('cmplx_Corporate2_q_MinCumPayQ1', 'Minimum Cumulative payment/ Tax paid for quarter Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MinBalPayQ1', 'Minimum Balance Payable for Q1')			
                                        ))
                                        {
                                        return false;
                                    }													
                                }
								if(period == "Quarter2"){
                                //if(curMonth=="September" || curMonth=="October"){
                                    //Corporate Tax Q2 can be applied only in the month of September and October					
                                    if (!(
                                        mandateCheck('cmplx_Corporate2_q_MaxDueDateQ2', 'Maximum Due Date for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxPTBPQ2', 'Maximum % to be paid for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumTaxQ2', 'Maximum Cumulative Tax for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTFTQQ2', 'Maximum Tax for the Quarter Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTPFQQ2', 'Maximum Tax paid for the Quarter Q2')  
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumPaytQ2', 'Maximum Cumulative payment/ Tax paid for quarter Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxBalPayQ2', 'Maximum Balance Payable for Q2')	
                                        && mandateCheck('cmplx_Corporate2_q_MinDueDateQ2', 'Minimum Due Date for Q2')
                                        && mandateCheck('cmplx_Corporate2_q_MinPTBPQ2', 'Minimum % to be paid for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MinCumTaxQ2', 'Minimum Cumulative Tax for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTFTQQ2', 'Minimum Tax for the Quarter Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTPFQQ2', 'Minimum Tax paid for the Quarter Q2')  
                                        && mandateCheck('cmplx_Corporate2_q_MinCumPayQ2', 'Minimum Cumulative payment/ Tax paid for quarter Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MinBalPayQ2', 'Minimum Balance Payable for Q2')			
                                        ))
                                        {
                                        return false;
                                    }													
                                }
								if(period == "Quarter3"){
                                //if(curMonth=="December" || curMonth=="January"){
                                    //Corporate Tax Q3 can be applied only in the month of December and January					
                                    if (!(
                                        mandateCheck('cmplx_Corporate2_q_MaxDueDateQ3', 'Maximum Due Date for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxPTBPQ3', 'Maximum % to be paid for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumTaxQ3', 'Maximum Cumulative Tax for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTFTQQ3', 'Maximum Tax for the Quarter Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTPFQQ3', 'Maximum Tax paid for the Quarter Q3')  
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumPayQ3', 'Maximum Cumulative payment/ Tax paid for quarter Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxBalPayQ3', 'Maximum Balance Payable for Q3')	
                                        && mandateCheck('cmplx_Corporate2_q_MinDueDateQ3', 'Minimum Due Date for Q3')
                                        && mandateCheck('cmplx_Corporate2_q_MinPTBPQ3', 'Minimum % to be paid for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MinCumTaxQ3', 'Minimum Cumulative Tax for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTFTQQ3', 'Minimum Tax for the Quarter Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTPFQQ3', 'Minimum Tax paid for the Quarter Q3')  
                                        && mandateCheck('cmplx_Corporate2_q_MinCumPayQ3', 'Minimum Cumulative payment/ Tax paid for quarter Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MinBalPayQ3', 'Minimum Balance Payable for Q3')			
                                        ))
                                        {
                                        return false;
                                    }													
                                }
								if(period == "Quarter4"){
                                //if(curMonth=="March" || curMonth=="April"){
                                    //Corporate Tax Q4 can be applied only in the month of March and April					
                                    if (!(
                                        mandateCheck('cmplx_Corporate2_q_MaxDueDateQ4', 'Maximum Due Date for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxPTBPQ4', 'Maximum % to be paid for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumTaxQ4', 'Maximum Cumulative Tax for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTFTQQ4', 'Maximum Tax for the Quarter Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTPFQQ4', 'Maximum Tax paid for the Quarter Q4')  
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumPayQ4', 'Maximum Cumulative payment/ Tax paid for quarter Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxBalPayQ4', 'Maximum Balance Payable for Q4')	
                                        && mandateCheck('cmplx_Corporate2_q_MinDueDateQ4', 'Minimum Due Date for Q4')
                                        && mandateCheck('cmplx_Corporate2_q_MinPTBPQ4', 'Minimum % to be paid for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MinCumTaxQ4', 'Minimum Cumulative Tax for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTFTQQ4', 'Minimum Tax for the Quarter Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MTPFQQ4', 'Minimum Tax paid for the Quarter Q4')  
                                        && mandateCheck('cmplx_Corporate2_q_MinCumPayQ4', 'Minimum Cumulative payment/ Tax paid for quarter Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MinBalPayQ4', 'Minimum Balance Payable for Q4')	
                                        //Other fields mandatory check in Quarter-4
                                        && mandateCheck('cmplx_Corporate2_q_TotalPayable', 'Total Payable')
                                        && mandateCheck('cmplx_Corporate2_q_NormalTax', 'Normal Tax')
                                        && mandateCheck('cmplx_Corporate2_q_DeferredTax', 'Deferred tax')
                                        && mandateCheck('cmplx_Corporate2_q_NetTax', 'Net Tax')
                                         //&& mandateCheck('cmplx_Corporate2_q_NetTaxPayable', 'Net Tax Payable')
                                        //&& mandateCheck('cmplx_Corporate2_q_AdvanceTaxPaid', 'Advance Tax Paid')
                                        //&& mandateCheck('cmplx_Corporate2_q_BalPayOnSelfAssmnt', 'Balance payable on Self assessment')
                                       // && mandateCheck('cmplx_Corporate2_q_IPUS234A', 'Interest payable under section 234A')
                                        //&& mandateCheck('cmplx_Corporate2_q_IPUS234B', 'Interest payable under section 234B')
                                        //&& mandateCheck('cmplx_Corporate2_q_IPUS234C', 'Interest payable under section 234C')
										
                                       // && mandateCheck('cmplx_Corporate2_q_NTPQ4Add', 'Interest payable under section 234A')
                                       // && mandateCheck('cmplx_Corporate2_q_ATPQ4Add', 'Interest payable under section 234B')
                                       // && mandateCheck('cmplx_Corporate2_q_BPIQ4Add', 'Interest payable under section 234C')
                                        ))
                                        {
                                        return false;
                                    }													
                                }
								
								if(qFourAdd == "Q4 Additional"){
									if (!(
										mandateCheck('cmplx_Corporate2_q_NTPQ4Add', 'Net Tax Payable')
                                        && mandateCheck('cmplx_Corporate2_q_ATPQ4Add', 'Advance Tax Paid')
                                        && mandateCheck('cmplx_Corporate2_q_BPIQ4Add', 'Balance payable in Q4 additional')
                                        ))
                                        {
                                        return false;
                                    }				
								}
								if(qFourAdd == "Post Self Assessment"){
									if (!(
										mandateCheck('cmplx_Corporate2_q_NetTaxPayable', 'Net Tax Payable')
                                        && mandateCheck('cmplx_Corporate2_q_AdvanceTaxPaid', 'Advance Tax Paid')
                                        && mandateCheck('cmplx_Corporate2_q_BalPayOnSelfAssmnt', 'Balance payable on Self assessment')
                                        && mandateCheck('cmplx_Corporate2_q_IPUS234A', 'Interest payable under section 234A')
                                        && mandateCheck('cmplx_Corporate2_q_IPUS234B', 'Interest payable under section 234B')
                                        && mandateCheck('cmplx_Corporate2_q_IPUS234C', 'Interest payable under section 234C')
                                        ))
                                        {
                                        return false;
                                    }				
								}
	
                                if (!(
                                    mandateCheck('cmplx_Corporate2_q_AdvTaxPaid', 'Advance Tax to be paid (Advance Tax due - Tax already paid )') 
                                    && mandateCheck('cmplx_Corporate2_q_TaxDueForQ', 'Tax Due for the quarter') 
                                    //&& mandateCheck('cmplx_Corporate2_q_AmtRecmByAuth', 'Amount recommended by authority') 
                                    ))
                                    {
                                    return false;
                                }							
                            }                            
                        }
                        //Supplementary RFA 
                        if(requestType=='SupplementaryRFA'){
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="VAT"){
							
                                if (!(
                                    mandateCheck('cmplx_VAT_q_VATOthrRev', 'Other Reversal') 
                                    && mandateCheck('cmplx_VAT_q_VATReb', 'Rebate') 
                                    && mandateCheck('cmplx_VAT_q_VATOthAdj', 'Other Adjustments') 
                                    && mandateCheck('cmplx_VAT_q_VATTolPay', 'Total VAT payable') 
                                    && mandateCheck('cmplx_VAT_q_VATPrvMonPay', 'Prev month Total VAT Payable') 
                                    //&& mandateCheck('cmplx_VAT_q_VATAvgLa3Mon', 'Average last three months') 
                                    //&& mandateCheck('cmplx_VAT_q_VATOthAdjFrmAddRFA', 'VAT Other Adjustments From Additional RFA ') 
                                    && mandateCheck('cmplx_VAT_q_VATAppOf', 'VAT Approval Of ') 
                                    && mandateCheck('cmplx_VAT_q_VATAppRRFA', 'VAT Approved in Routine RFA ') 
                                    ))
                                    {
                                    return false;
                                }	
                                if(com.newgen.omniforms.formviewer.getNGValue("IncludesCST")=="Yes"){
								
                                    if (!(
                                        mandateCheck('cmplx_VAT_q_CSTOthRev', 'Other Reversal in CST') 
                                        && mandateCheck('cmplx_VAT_q_CSTReb', 'Rebate In CST') 
                                        && mandateCheck('cmplx_VAT_q_CSTOthAdj', 'Other Adjustments in CST') 
                                        && mandateCheck('cmplx_VAT_q_CSTTotpay', 'Total CST payable') 
                                        && mandateCheck('cmplx_VAT_q_CSTPrevMonPay', 'Previous month Total CST Payable') 
                                        //&& mandateCheck('cmplx_VAT_q_CSTAvgLa3Mon', 'Average last three months') 
                                        //&& mandateCheck('cmplx_VAT_q_CSTOthAdjFrmAddRFA', 'CST Other Adjustments From Additional RFA') 
                                        && mandateCheck('cmplx_VAT_q_CSTAppOf', 'CST ApprovalOf') 
                                        && mandateCheck('cmplx_VAT_q_CSTAppRRFA', 'CST Approved in Routine RFA') 
                                        ))
                                        {
                                        return false;
                                    }
                                } 								
				
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS"){
								if(pfForOnly == "TDS" || (com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS" && pfForOnly != "TCS" && pfForOnly != "TDS")){
                                if (!(
                                    mandateCheck('cmplx_TDS_q_A194', '194 A') 
                                    && mandateCheck('cmplx_TDS_q_C194', '194 C') 
                                    && mandateCheck('cmplx_TDS_q_H194', '194 H') 
                                    && mandateCheck('cmplx_TDS_q_I194', '194 I')
									&& mandateCheck('cmplx_TDS_q_IA194', '194 IA')
                                    && mandateCheck('cmplx_TDS_q_J194', '194 J') 
                                    && mandateCheck('cmplx_TDS_q_TDSAdjust', 'Adjustments') 
                                    && mandateCheck('cmplx_TDS_q_TDSTotPay', 'Total TDS Payable') 
                                    && mandateCheck('cmplx_TDS_q_TDSPrevMonPaid', 'Previous month TDS paid') 
                                    //&& mandateCheck('cmplx_TDS_q_TDSAvgThreeMon', 'Average TDS paid in the last three months') 
                                    && mandateCheck('cmplx_TDS_q_TDSApprovalOf', 'Approval of') 
                                    && mandateCheck('cmplx_TDS_q_TDSTotExcl195', 'Total TDS(excludint 195) approved in routine RFA') 
                                    ))
                                    {
										return false;
									}
								}
                                if((com.newgen.omniforms.formviewer.getNGValue("IncludesTCS")=="Yes" && pfForOnly != "TCS" && pfForOnly != "TDS") || pfForOnly == "TCS"){
								
                                    if (!(
                                        mandateCheck('cmplx_TDS_q_C206', '206 C') 
                                        && mandateCheck('cmplx_TDS_q_TCSAdjust', 'Adjustments') 
                                        && mandateCheck('cmplx_TDS_q_TCSTotPay', 'Total TCS payable') 
                                        //&& mandateCheck('cmplx_TDS_q_TCSAvrThreeMon', 'Average TCS paid in the last three months') 
                                        && mandateCheck('cmplx_TDS_q_TCSPrevMonthPaid', 'Previous month TCS paid') 
                                        && mandateCheck('cmplx_TDS_q_TCSApprovalOf', 'Approval of') 
                                        && mandateCheck('cmplx_TDS_q_TCSTotApprvdRFA', 'Total TCS approved in routine RFA')
                                        ))
                                        {
                                        return false;
                                    }
                                }								
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS195"){
							
                                if (!(
                                    mandateCheck('cmplx_TDS195_q_CustName', 'Customer Name') 
                                    && mandateCheck('cmplx_TDS195_q_CustLocation', 'Customer Location') 
                                    && mandateCheck('cmplx_TDS195_q_ProductDetails', 'Product Details') 
                                    && mandateCheck('cmplx_TDS195_q_SalesValue', 'Sales Values') 
                                    && mandateCheck('cmplx_TDS195_q_ExpInvoiceNo', 'Export Invoice No.') 
                                    && mandateCheck('cmplx_TDS195_q_TDS195Pay', 'TDS 195 Payable') 
                                    && mandateCheck('cmplx_TDS195_q_EqualLevied', 'Equalization Lieved')
									&& mandateCheck('cmplx_TDS195_q_ApprovalOf', 'Approval Of') 
                                    && mandateCheck('cmplx_TDS195_q_ApprovedInRFA', 'Approved In RFA') 								
                                    ))
                                    {
                                    return false;
                                }								
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Entry Tax"){
							
                                if (!(
                                    mandateCheck('cmplx_Entry_q_Totalpay', 'Total Entry Tax payable') 
                                    //&& mandateCheck('cmplx_Entry_q_OthAdjARFA', 'Other adjustments Additional RFA') 
                                    && mandateCheck('cmplx_Entry_q_PrevMonPay', 'Prev month Total Entry Tax Paid') 
                                    //&& mandateCheck('cmplx_Entry_q_AvgLa3Mon', 'Average last three months') 
                                    && mandateCheck('cmplx_Entry_q_ApprvlOf', 'New Approval Amt.') 
                                    && mandateCheck('cmplx_Entry_q_TotTaxAppRRFA', 'Approved Amt. in RoutinRFA') 							
                                    ))
                                    {
                                    return false;
                                }								
							
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Excise Duty"){
							
                                if (!(
                                    mandateCheck('cmplx_Excise_q_ExcRegNo', 'Excise registration number') 
                                    && mandateCheck('cmplx_Excise_q_PLAPayable', 'PLA Excise Payable') 
                                    //&& mandateCheck('cmplx_Excise_q_AdjARFA', 'Adjustments - Additional RFA') 
                                    && mandateCheck('cmplx_Excise_q_PrevMonPay', 'Previous month PLA paid') 
                                    //&& mandateCheck('cmplx_Excise_q_AvgLa3Mon', 'Average PLA paid in the last three months') 
                                    && mandateCheck('cmplx_Excise_q_ExcPayble', 'Excise Payable') 
                                    && mandateCheck('cmplx_Excise_q_OBCenCrInput', 'Opening Balance Cenvat credit on input') 
                                    && mandateCheck('cmplx_Excise_q_CCIFTPeriod', 'Current period Cenvat credit on input') 
                                    && mandateCheck('cmplx_Excise_q_PCCIUsage', 'Planned usage Cenvat credit on input') 
                                    && mandateCheck('cmplx_Excise_q_OBCCCapGood', 'Opening Balance Cenvat credit on Capital Goods') 
                                    && mandateCheck('cmplx_Excise_q_CCCapGFTPeriod', 'Current period Cenvat credit on Capital Goods') 
                                    && mandateCheck('cmplx_Excise_q_PCCCapGUsage', 'Planned usage Cenvat credit on Capital Goods') 
                                    && mandateCheck('cmplx_Excise_q_OBCCIService', 'Opening Balance Cenvat credit on input service') 
                                    && mandateCheck('cmplx_Excise_q_CCIService', 'Current period Cenvat credit on input service') 
                                    && mandateCheck('cmplx_Excise_q_PCCISUsage', 'Planned usage Cenvat credit on input service') 
                                    && mandateCheck('cmplx_Excise_q_OthReavCredit', 'Current period Others reavilment of credit etc') 
                                    && mandateCheck('cmplx_Excise_q_POthersReavCr', 'Planned usage Others reavilment of credit etc') 
                                    && mandateCheck('cmplx_Excise_q_PLAOpenBal', 'Current period PLA Opening Balance') 
                                    && mandateCheck('cmplx_Excise_q_PlandPLAUsage', 'Planned usage PLA Opening Balance') 
                                    //&& mandateCheck('cmplx_Excise_q_Rule63ARevGood', '6(3) A reversal goods') 
                                    //&& mandateCheck('cmplx_Excise_q_Rule63ARevServ', '6(3) A reversal services') 
                                    //&& mandateCheck('cmplx_Excise_q_OthRevGood', 'Other reversals goods') 
                                    //&& mandateCheck('cmplx_Excise_q_OthRevServ', 'Other reversals services') 
									&& mandateCheck('cmplx_Excise_q_HigherEduCess', 'Higher Educational cess')
									&& mandateCheck('cmplx_Excise_q_SecEduCess', 'Secondary Educational cess')
									&& mandateCheck('cmplx_Excise_q_PlannedPLAPayable', 'Planned PLA Payable')
									
                                    ))
                                    {
                                    return false;
                                }								
							
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Service Tax"){
							
                                if (!(
                                    mandateCheck('cmplx_Service_q_TotSTPay', 'Total Service Tax payable') 
                                    && mandateCheck('cmplx_Service_q_TotOSTPay', 'Total output service tax payable tax payable') 
                                    //&& mandateCheck('cmplx_Service_q_AdjARFAST', 'Adjustments - Additional RFA') 
                                    && mandateCheck('cmplx_Service_q_NOSTPayBase', 'Base tax - Net output service tax payable') 
                                    && mandateCheck('cmplx_Service_q_NOSTPaySBC', 'SBC - Net output service tax payable') 
                                    && mandateCheck('cmplx_Service_q_STPrevMonPay', 'Previous month Output service tax paid') 
                                    //&& mandateCheck('cmplx_Service_q_STAvgLa3Mon', 'Average Output service tax paid for last threemonths') 
                                    && mandateCheck('cmplx_Service_q_ApprvalOf', 'Approval of') 
                                    && mandateCheck('cmplx_Service_q_TotAprvdOSTRRFA', 'Total approved output ST in routine RFA') 
                                    && mandateCheck('cmplx_Service_q_TotRCMSTPay', 'Total RCM service tax Payable') 
                                    //&& mandateCheck('cmplx_Service_q_AdjARFARCM', 'Adjustments - Additional RFA') 
                                    && mandateCheck('cmplx_Service_q_NRCMPayBase', 'Base tax - Net RCM Payable') 
                                    && mandateCheck('cmplx_Service_q_NRCMPaySBC', 'SBC - Net RCM Payable') 
                                    && mandateCheck('cmplx_Service_q_RCMPrevMonPay', 'Previous month RCM paid') 
                                    //&& mandateCheck('cmplx_Service_q_RCMAvgLa3Mon', 'Average RCM paid for last three months') 
                                    && mandateCheck('cmplx_Service_q_ApprvalOfRCM', 'Approval of') 
                                    && mandateCheck('cmplx_Service_q_TotAprvdRCMRRFA', 'Total approved RCM ST in routine RFA')  
                                    ))
                                    {
                                    return false;
                                }								
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Corporate Tax"){		
	
                                if (!(
                                    mandateCheck('cmplx_Corporate_q_PLAccProfitPrev', 'Profit as per P&L Account Previous Year') 
                                    && mandateCheck('cmplx_Corporate_q_PLAccProfit', 'Profit as per P&L Account Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_PLAccProfitRemark', 'Profit as per P&L Account Remarks') 
                                    && mandateCheck('cmplx_Corporate_q_ItemsConSepPrev', 'Items Considered Seperately Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_ItemConSep', 'Items Considered Seperately Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_ItemConSepRemark', 'Items Considered Seperately Remarks')
                                    && mandateCheck('cmplx_Corporate_q_ItemConSepPrev2', 'Items Considered Seperately Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_ItemConSep2', 'Items Considered Seperately Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_ItemConSepRemark2', 'Items Considered Seperately Remarks')
                                    && mandateCheck('cmplx_Corporate_q_SubTotalPrev1', 'SubTotal Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_SubTotal1', 'SubTotal Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_SubTotallRemark1', 'SubTotal Remarks')
                                    && mandateCheck('cmplx_Corporate_q_TimeDiffPrev1', 'Timing Differences Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_TimeDiff1', 'Timing Differences Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_TimeDiffRemark1', 'Timing Differences Remarks')
                                    && mandateCheck('cmplx_Corporate_q_PermDiffPrev1', 'Permanent Differences Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_PermDiff1', 'Permanent Differences Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_PermDiffRemark1', 'Permanent Differences Remarks')
                                    && mandateCheck('cmplx_Corporate_q_SubTotalPrev2', 'Permanent Differences Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_TimeDiffPrev2', 'Permanent Differences Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_PermDiffPrev2', 'Permanent Differences Remarks')
                                    && mandateCheck('cmplx_Corporate_q_STBusIncPrev', 'SubTotal of Business Income Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_SubTotBusInc', 'SubTotal of Business Income Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_STBusIncRemark', 'SubTotal of Business Income Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFHPropPrev', 'Income from House Property Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFHProp', 'Income from House Property Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFHPropRemark', 'Income from House Property Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCIGNIPrev', 'Income from Long Term Capital Gains Non Indexed Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCIGNonIndex', 'Income from Long Term Capital Gains Non Indexed Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFLTCIGNIRemark', 'Income from Long Term Capital Gains Non Indexed Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGPrev', 'Income from Short Term Capital Gains Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGains', 'Income from Short Term Capital Gains Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFSTCGRemark', 'Income from Short Term Capital Gains Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCIGIPrev', 'Income from Long Term Capital Gains Indexed Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCIGIndex', 'Income from Long Term Capital Gains Indexed Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFLTCIGIRemark', 'Income from Long Term Capital Gains Indexed Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFOSPrev', 'Income from Other Sources Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_IFOSource', 'Income from Other Sources Indexed Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_IFOSRemark','Income from Other Sources Indexed Remarks')
                                    && mandateCheck('cmplx_Corporate_q_GTIPrev', 'Gross Total Income Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_GtotIncome', 'Gross Total Income Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_GTIRemark','Gross Total Income Remarks')
                                    && mandateCheck('cmplx_Corporate_q_DUCVIAPrev', 'Deductions under Chapter VI A Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_DUChapVIA', 'Deductions under Chapter VI A Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_DUCVIARemark','Deductions under Chapter VI A Remarks')
                                    && mandateCheck('cmplx_Corporate_q_AOElDPrev', 'Any other eligible deductions Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_AOElDeduct', 'Any other eligible deductions Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_AOElDRemark','Any other eligible deductions Remarks')
                                    && mandateCheck('cmplx_Corporate_q_TaxIncPrev', 'Taxable Income Previous Year')
                                    && mandateCheck('cmplx_Corporate_q_TaxIncome', 'Taxable Income Current Year') 
                                    //&& mandateCheck('cmplx_Corporate_q_TaxIncRemark','Taxable Income Remarks')
                                    && mandateCheck('cmplx_Corporate_q_IFBRate', 'Income from Business or Profession Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFBIncome', 'Income from Business or Profession Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFBTax','Income from Business or Profession Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFHPropRate', 'Income from House Property Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFHPropIncome', 'Income from House Property Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFHPropTax','Income from House Property Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGRate', 'Income from Short Term Capital Gains Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGIncome', 'Income from Short Term Capital Gains Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFSTCGTax','Income from Short Term Capital Gains Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGIRate', 'Income from Long Term Capital Gains Indexed Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGIIncome', 'Income from Long Term Capital Gains Indexed Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGITax','Income from Long Term Capital Gains Indexed Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGNIRate', 'Income from Long Term Capital Gains Non Indexed Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGNIIncome', 'Income from Long Term Capital Gains Non Indexed Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFLTCGNITax','Income from Long Term Capital Gains Non Indexed Tax')
                                    && mandateCheck('cmplx_Corporate_q_IFOSRate', 'Income from Other Sources Rate% ')
                                    && mandateCheck('cmplx_Corporate_q_IFOSIncome', 'Income from Other Sources Income') 
                                    && mandateCheck('cmplx_Corporate_q_IFOSTax','Income from Other Sources Tax')
                                    && mandateCheck('cmplx_Corporate_q_IncTaxCurYear', 'Income Tax For The Year')
                                    && mandateCheck('cmplx_Corporate_q_TDSCreCurYear', 'TDS Credit For The Year') 
                                    && mandateCheck('cmplx_Corporate_q_NetTaxPay','Net Tax Payable')	
 
                                    ))
                                    {
                                    return false;
                                }	
	
                                if(curMonth=="June" || curMonth=="July"){
                                    //Corporate Tax Q1 can be applied only in the month of June and July					
                                    if (!(
                                        mandateCheck('cmplx_Corporate2_q_MaxDueDateQ1', 'Maximum Due Date for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxPTBPQ1', 'Maximum % to be paid for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumTaxQ1', 'Maximum Cumulative Tax for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTFTQQ1', 'Maximum Tax for the Quarter Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTPFQQ1', 'Maximum Tax paid for the Quarter Q1')  
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumPayQ1', 'Maximum Cumulative payment/ Tax paid for quarter Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxBalPayQ1', 'Maximum Balance Payable for Q1')	
                                        && mandateCheck('cmplx_Corporate2_q_MinDueDateQ1', 'Minimum Due Date for Q1')
                                        && mandateCheck('cmplx_Corporate2_q_MinPerTBPQ1', 'Minimum % to be paid for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MinCumTaxQ1', 'Minimum Cumulative Tax for Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTFTQQ1', 'Minimum Tax for the Quarter Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTPFQQ1', 'Minimum Tax paid for the Quarter Q1')  
                                        && mandateCheck('cmplx_Corporate2_q_MinCumPayQ1', 'Minimum Cumulative payment/ Tax paid for quarter Q1') 
                                        && mandateCheck('cmplx_Corporate2_q_MinBalPayQ1', 'Minimum Balance Payable for Q1')			
                                        ))
                                        {
                                        return false;
                                    }													
                                }
                                if(curMonth=="September" || curMonth=="October"){
                                    //Corporate Tax Q2 can be applied only in the month of September and October					
                                    if (!(
                                        mandateCheck('cmplx_Corporate2_q_MaxDueDateQ2', 'Maximum Due Date for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxPTBPQ2', 'Maximum % to be paid for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumTaxQ2', 'Maximum Cumulative Tax for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTFTQQ2', 'Maximum Tax for the Quarter Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTPFQQ2', 'Maximum Tax paid for the Quarter Q2')  
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumPaytQ2', 'Maximum Cumulative payment/ Tax paid for quarter Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxBalPayQ2', 'Maximum Balance Payable for Q2')	
                                        && mandateCheck('cmplx_Corporate2_q_MinDueDateQ2', 'Minimum Due Date for Q2')
                                        && mandateCheck('cmplx_Corporate2_q_MinPTBPQ2', 'Minimum % to be paid for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MinCumTaxQ2', 'Minimum Cumulative Tax for Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTFTQQ2', 'Minimum Tax for the Quarter Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTPFQQ2', 'Minimum Tax paid for the Quarter Q2')  
                                        && mandateCheck('cmplx_Corporate2_q_MinCumPayQ2', 'Minimum Cumulative payment/ Tax paid for quarter Q2') 
                                        && mandateCheck('cmplx_Corporate2_q_MinBalPayQ2', 'Minimum Balance Payable for Q2')			
                                        ))
                                        {
                                        return false;
                                    }													
                                }
                                if(curMonth=="December" || curMonth=="January"){
                                    //Corporate Tax Q3 can be applied only in the month of December and January					
                                    if (!(
                                        mandateCheck('cmplx_Corporate2_q_MaxDueDateQ3', 'Maximum Due Date for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxPTBPQ3', 'Maximum % to be paid for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumTaxQ3', 'Maximum Cumulative Tax for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTFTQQ3', 'Maximum Tax for the Quarter Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTPFQQ3', 'Maximum Tax paid for the Quarter Q3')  
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumPayQ3', 'Maximum Cumulative payment/ Tax paid for quarter Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxBalPayQ3', 'Maximum Balance Payable for Q3')	
                                        && mandateCheck('cmplx_Corporate2_q_MinDueDateQ3', 'Minimum Due Date for Q3')
                                        && mandateCheck('cmplx_Corporate2_q_MinPTBPQ3', 'Minimum % to be paid for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MinCumTaxQ3', 'Minimum Cumulative Tax for Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTFTQQ3', 'Minimum Tax for the Quarter Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTPFQQ3', 'Minimum Tax paid for the Quarter Q3')  
                                        && mandateCheck('cmplx_Corporate2_q_MinCumPayQ3', 'Minimum Cumulative payment/ Tax paid for quarter Q3') 
                                        && mandateCheck('cmplx_Corporate2_q_MinBalPayQ3', 'Minimum Balance Payable for Q3')			
                                        ))
                                        {
                                        return false;
                                    }													
                                }
                                if(curMonth=="March" || curMonth=="April"){
                                    //Corporate Tax Q4 can be applied only in the month of March and April					
                                    if (!(
                                        mandateCheck('cmplx_Corporate2_q_MaxDueDateQ4', 'Maximum Due Date for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxPTBPQ4', 'Maximum % to be paid for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumTaxQ4', 'Maximum Cumulative Tax for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTFTQQ4', 'Maximum Tax for the Quarter Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxTPFQQ4', 'Maximum Tax paid for the Quarter Q4')  
                                        && mandateCheck('cmplx_Corporate2_q_MaxCumPayQ4', 'Maximum Cumulative payment/ Tax paid for quarter Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MaxBalPayQ4', 'Maximum Balance Payable for Q4')	
                                        && mandateCheck('cmplx_Corporate2_q_MinDueDateQ4', 'Minimum Due Date for Q4')
                                        && mandateCheck('cmplx_Corporate2_q_MinPTBPQ4', 'Minimum % to be paid for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MinCumTaxQ4', 'Minimum Cumulative Tax for Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MinTFTQQ4', 'Minimum Tax for the Quarter Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MTPFQQ4', 'Minimum Tax paid for the Quarter Q4')  
                                        && mandateCheck('cmplx_Corporate2_q_MinCumPayQ4', 'Minimum Cumulative payment/ Tax paid for quarter Q4') 
                                        && mandateCheck('cmplx_Corporate2_q_MinBalPayQ4', 'Minimum Balance Payable for Q4')	
                                        //Other fields mandatory check in Quarter-4
                                        && mandateCheck('cmplx_Corporate2_q_TotalPayable', 'Total Payable')
                                        && mandateCheck('cmplx_Corporate2_q_NormalTax', 'Normal Tax')
                                        && mandateCheck('cmplx_Corporate2_q_DeferredTax', 'Deferred tax')
                                        && mandateCheck('cmplx_Corporate2_q_NetTax', 'Net Tax')
                                         //&& mandateCheck('cmplx_Corporate2_q_NetTaxPayable', 'Net Tax Payable')
                                        //&& mandateCheck('cmplx_Corporate2_q_AdvanceTaxPaid', 'Advance Tax Paid')
                                        //&& mandateCheck('cmplx_Corporate2_q_BalPayOnSelfAssmnt', 'Balance payable on Self assessment')
                                       // && mandateCheck('cmplx_Corporate2_q_IPUS234A', 'Interest payable under section 234A')
                                        //&& mandateCheck('cmplx_Corporate2_q_IPUS234B', 'Interest payable under section 234B')
                                        //&& mandateCheck('cmplx_Corporate2_q_IPUS234C', 'Interest payable under section 234C')
										
                                       // && mandateCheck('cmplx_Corporate2_q_NTPQ4Add', 'Interest payable under section 234A')
                                       // && mandateCheck('cmplx_Corporate2_q_ATPQ4Add', 'Interest payable under section 234B')
                                       // && mandateCheck('cmplx_Corporate2_q_BPIQ4Add', 'Interest payable under section 234C')
                                        ))
                                        {
                                        return false;
                                    }													
                                }
								
								if(qFourAdd == "Q4 Additional"){
									if (!(
										mandateCheck('cmplx_Corporate2_q_NTPQ4Add', 'Net Tax Payable')
                                        && mandateCheck('cmplx_Corporate2_q_ATPQ4Add', 'Advance Tax Paid')
                                        && mandateCheck('cmplx_Corporate2_q_BPIQ4Add', 'Balance payable in Q4 additional')
                                        ))
                                        {
                                        return false;
                                    }				
								}
								if(qFourAdd == "Post Self Assessment"){
									if (!(
										mandateCheck('cmplx_Corporate2_q_NetTaxPayable', 'Net Tax Payable')
                                        && mandateCheck('cmplx_Corporate2_q_AdvanceTaxPaid', 'Advance Tax Paid')
                                        && mandateCheck('cmplx_Corporate2_q_BalPayOnSelfAssmnt', 'Balance payable on Self assessment')
                                        && mandateCheck('cmplx_Corporate2_q_IPUS234A', 'Interest payable under section 234A')
                                        && mandateCheck('cmplx_Corporate2_q_IPUS234B', 'Interest payable under section 234B')
                                        && mandateCheck('cmplx_Corporate2_q_IPUS234C', 'Interest payable under section 234C')
                                        ))
                                        {
                                        return false;
                                    }				
								}
	
                                if (!(
                                    mandateCheck('cmplx_Corporate2_q_AdvTaxPaid', 'Advance Tax to be paid (Advance Tax due - Tax already paid )') 
                                    && mandateCheck('cmplx_Corporate2_q_TaxDueForQ', 'Tax Due for the quarter') 
                                    //&& mandateCheck('cmplx_Corporate2_q_AmtRecmByAuth', 'Amount recommended by authority') 
                                    ))
                                    {
                                    return false;
                                }						
                            }
                            //var urlPDF=dynamicURL+"/webdesktop/CustomJSP/index.jsp?ProcessInstanceId="+strProcessinstanceID;
                        }
                        //Reconciliation RFA
                        if(requestType=='Reconciliation'){  
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="VAT"){
							
                                if (!(
                                    mandateCheck('cmplx_Recon_VAT_q_VATOLTaknFrm', 'Output VAT Liability taken from') 
                                    && mandateCheck('cmplx_Recon_VAT_q_VATOLGL', 'Output VAT Liability as in GL') 
                                    && mandateCheck('cmplx_Recon_VAT_q_VITCTaknFrm', 'ITC taken from') 
                                    && mandateCheck('cmplx_Recon_VAT_q_VITCGL', 'ITC as in GL') 
                                    && mandateCheck('cmplx_Recon_VAT_q_ITCCGTaknFrm', 'ITC Capital goods taken from') 
                                    && mandateCheck('cmplx_Recon_VAT_q_ITCCGGL', 'ITC Capital goods as in GL') 
                                    && mandateCheck('cmplx_Recon_VAT_q_VTPayRFA', 'Total VAT paid as in RFA') 
                                    && mandateCheck('cmplx_Recon_VAT_q_VATTotPaySAP', 'Total VAT paid as in SAP') 
                                    && mandateCheck('cmplx_Recon_VAT_q_VATReconDiffAmt', 'Difference') 
                                    ))
                                    {
                                    return false;
                                }	
                                if(com.newgen.omniforms.formviewer.getNGValue("IncludesCST")=="Yes"){
								
                                    if (!(
                                        mandateCheck('cmplx_Recon_VAT_q_CSTTotPayRFA', 'Total CST paid as in RFA') 
                                        && mandateCheck('cmplx_Recon_VAT_q_CSTPTaknFrm', 'CST Payable taken from') 
                                        && mandateCheck('cmplx_Recon_VAT_q_CSTOPGL', 'CST Payable as in GL') 
										&& mandateCheck('cmplx_Recon_VAT_CSTTotPaySAP', 'Total CST as in SAP') 
                                        && mandateCheck('cmplx_Recon_VAT_q_CSTDiffAmt', 'Difference') 
                                        ))
                                        {
                                        return false;
                                    }
                                }								

                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS"){
								if(pfForOnly == "TDS" || (com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS" && pfForOnly != "TCS" && pfForOnly != "TDS")){
									if (!(
                                    mandateCheck('cmplx_Recon_TDS_q_TDSTotPay', 'Total TDS payable excluding 195 payment') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TdsSAP', 'TDS As In SAP') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TCS194CTaknFrm', 'TDS - CONTRACTORS - SEC 194C taken from') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TCS194CGL', 'TDS - CONTRACTORS - SEC 194C as in GL') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TRS194ITaknFrm', 'TDS - RENT - SEC 194I taken from') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TRS194IGL', 'TDS - RENT - SEC 194I as in GL') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TPFS194JTaknFrm', 'TDS - PROFESSIONAL FEES - SEC 194J taken from') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TPFS194JGL', 'TDS - PROFESSIONAL FEES - SEC 194J as in GL') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TCB194HTaknFrm', 'TDS - COMMISSION & BROKERAGE - 194H taken from') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TCB194HGL', 'TDS - COMMISSION & BROKERAGE - 194H as in GL') 
                                    && mandateCheck('cmplx_Recon_TDS_q_TDSDiffrenc', 'Difference') 
                                    ))
                                    {
										return false;
									}	
								}
                                if((com.newgen.omniforms.formviewer.getNGValue("IncludesTCS")=="Yes" && pfForOnly != "TCS" && pfForOnly != "TDS") || pfForOnly == "TCS"){							
								
                                    if (!(
                                        mandateCheck('cmplx_TDS_q_C206', '206 C') 
                                        && mandateCheck('cmplx_Recon_TDS_q_TotTCSPay', 'Total TCS payable') 
                                        && mandateCheck('cmplx_Recon_TDS_q_TCFCSTaknFrm', 'Tax collected from customers -Scrap taken from') 
                                        && mandateCheck('cmplx_Recon_TDS_q_TCFCSGL', 'Tax collected from customers -Scrap as in GL') 
                                        && mandateCheck('cmplx_Recon_TDS_q_TCSDiffrenc', 'Difference') 
                                        ))
                                        {
											return false;
										}
                                }								
						
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="TDS195"){
							
                                if (!(
                                    mandateCheck('cmplx_Recon_TDS195_q_TNRPUS195TaknFrm', 'TDS - NON RESIDENT PAYMENTS - U/S 195 taken from') 
                                    && mandateCheck('cmplx_Recon_TDS195_q_TDSNRPUS195GL', 'TDS - NON RESIDENT PAYMENTS - U/S 195. as in GL') 
                                    && mandateCheck('cmplx_Recon_TDS195_q_TDS195TotPay', 'Total TDS195 Payable') 
                                    && mandateCheck('cmplx_Recon_TDS195_q_TDS195Diffrenc', 'Difference') 							
                                    ))
                                    {
                                    return false;
                                }								
							
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Entry Tax"){
							
                                if (!(
                                    mandateCheck('cmplx_Recon_Entry_q_ETDPATaknFrm', 'Entry Tax/devt payable account GL code') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETDPAGL', 'Entry Tax/devt payable account value in GL') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETFC9TaknFrm', 'Entry Tax- fuel C-9 GL code') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETFCGL', 'Entry Tax- fuel C-9 value in GL') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETFFOTaknFrm', 'Entry Tax - fuel FO GL code') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETFFOGL', 'Entry Tax - fuel FO value in GL') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETFLPGTaknFrm', 'Entry Tax - fuel LPG GL code') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETFLPGGL', 'Entry Tax - fuel LPG value in GL') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETOthTaknFrm', 'Entry Tax - others GL code') 
                                    && mandateCheck('cmplx_Recon_Entry_q_ETOthGL', 'Entry Tax - others value in GL') 
                                    && mandateCheck('cmplx_Recon_Entry_q_TotETValSAP', 'Total Entry Tax in SAP') 
                                    && mandateCheck('cmplx_Recon_Entry_q_TotETPay', 'Entry Tax paid as in RFA') 
                                    && mandateCheck('cmplx_Recon_Entry_q_Diffrnce', 'Difference') 
                                    ))
                                    {
                                    return false;
                                }								
							
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Excise Duty"){
							
                                if (!( mandateCheck('cmplx_Recon_Excise_q_EDPayTaknFrm', 'Excise duty payable  taken from')                                    
                                    //&& mandateCheck('Reconciliation_Excise_Text59', 'Service tax payable value in GL')                                     
									//&& mandateCheck('cmplx_Recon_Excise_q_PLAPay', 'PLA Payable') 									
                                    && mandateCheck('cmplx_Recon_Excise_q_EDPayGross', 'Excise duty payable gross payable in credit side') 
                                    && mandateCheck('cmplx_Recon_Excise_q_CCIUTanknFrm', 'Cenvat credit on input utilized GL code') 
                                    && mandateCheck('cmplx_Recon_Excise_q_CCIUtlized', 'Cenvat credit on input utilized') 
                                    && mandateCheck('cmplx_Recon_Excise_q_CCCGUTaknFrm', 'Cenvat credit on capital goods utilized GL code') 
                                    && mandateCheck('cmplx_Recon_Excise_q_CCCGUtlized', 'Cenvat credit on capital goods utilized') 
                                    && mandateCheck('cmplx_Recon_Excise_q_CCISUTaknFrm', 'Cenvat credit on input services utilized taken from') 
                                    && mandateCheck('cmplx_Recon_Excise_q_CCISUtlized', 'Cenvat credit on input services utilized') 
                                    && mandateCheck('cmplx_Recon_Excise_q_TotEDValSAP', 'PLA as in SAP') 
                                    && mandateCheck('cmplx_Recon_Excise_q_TotEDPayRRFA', 'PLA Paid (as in RFA)') 
                                    && mandateCheck('cmplx_Recon_Excise_q_Diffrnce', 'Difference') 							
                                    ))
                                    {
                                    return false;
                                }								
							
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Service Tax"){
							
                                if (!(
                                    mandateCheck('cmplx_Recon_Service_q_STPayTaknFrm', 'Service tax payable GL code') 
                                    && mandateCheck('cmplx_Recon_Service_q_STPayGL', 'Service tax payable value in GL') 
                                    && mandateCheck('cmplx_Recon_Service_q_SBCPayTaknFrm', 'SBC payable GL code') 
                                    && mandateCheck('cmplx_Recon_Service_q_SBCPayGL', 'SBC payable value in GL') 
                                    && mandateCheck('cmplx_Recon_Service_q_KKCPayTaknFrm', 'KKC payable GL code') 
                                    && mandateCheck('cmplx_Recon_Service_q_KKCPayGL', 'KKC payable value in GL') 
                                    && mandateCheck('cmplx_Recon_Service_q_TotSTTaxValSAP', 'Total Service tax value in SAP') 
                                    && mandateCheck('cmplx_Recon_Service_q_TotSerTaxPay', 'Total service tax paid as in RFA') 
                                    && mandateCheck('cmplx_Recon_Service_q_Diffrnce', 'Difference') 
                                    ))
                                    {
                                    return false;
                                }								
                            }
                            if(com.newgen.omniforms.formviewer.getNGValue("StatutoryLegislation")=="Corporate Tax"){
							
                                if (!(
                                    mandateCheck('cmplx_Recon_Corp_TDSCorpTaknFrm', 'TDS-Corporate taken from') 
                                    && mandateCheck('cmplx_Recon_Corp_q_TDSCorpGL', 'TDS-Corporate as in SAP') 
                                    && mandateCheck('cmplx_Recon_Corp_q_TDSAInRFA', 'TDS-Corporate as in RFA') 
                                    && mandateCheck('cmplx_Recon_Corp_q_Diffrence', 'Difference')  
                                    ))
                                    {
                                    return false;
                                }								
					
                            }
                        }
						//Document Mandatory Check function
						if(documentMandatory()){
						
							return true;
						}else{
							return false;
						}
                    }                     
					
					if(activityName=='ChallanUpload'){
					
						//validateDocumentTypeSP('Challan_1', 'Challan_1');	
						var sInputDocName=["Challan_1"];
						if(validateDocumentTypeSP(sInputDocName)){
						
							return true;
						}else{
						
							return false;
						}
					}
					
					if(activityName=='ReturnsUpload'){
						var sInputDocName=["ReturnsDocument_1"];
						if(validateDocumentTypeSP(sInputDocName)){
						
							return true;
						}else{
						
							return false;
						}
						//validateDocumentTypeSP('ReturnsDocument_1', 'ReturnsDocument_1');					
					}
					
					
					
                    //For Comments Mandatory
                    if(!mandateCheck('Comments', 'Comments')){
                        return false;
                    }
                    return true;
                    break;
                }
                case 'BtnApprove':
                {
                    //For Comments Mandatory
                    if(!mandateCheck('Comments', 'Comments')){
                        return false;
                    }
                    
                    return true;
                    break;
                }
                case 'BtnReject':
                {
                    //For Comments Mandatory
                    if(!mandateCheck('Comments', 'Comments')){
                        return false;
                    }
                    
                    return true;
                    break;
                }
                case 'BtnRework':
                {
                    //For Comments Mandatory
                    if(!mandateCheck('Comments', 'Comments')){
                        return false;
                    }
                    
                    return true;
                    break;
                }
                case 'BtnSAP':
                {
				
                    return true;
                    break;
                } 
				 case 'BtnForward':
                {
                    
                    return true;
                    break;
                }
				case 'Btn_MDApprove':
                {
                    
                    return true;
                    break;
                }
				case 'Btn_MDRework':
                {
                    
                    return true;
                    break;
                }
				case 'Btn_MDReject':
                {
                    
                    return true;
                    break;
                }				
                case 'VAT_BtnVATAdd':	
                {	
                    if (!(
                        mandateCheck('VAT_CmbLegislation', 'Legislation') 
                        && mandateCheck('VAT_VATPF', 'Tax %') 
                        && mandateCheck('VAT_VATOutput', 'Output Payable') 
                        && mandateCheck('VAT_VATCN', 'Credit Note') 
                        && mandateCheck('VAT_VATCNR', 'Credit Note Reversal') 						
                        ))
                        {
                        return false;
                    }
                    if(com.newgen.omniforms.formviewer.getNGValue("VAT_CmbLegislation")=="VAT"){
                        if (!(
                            mandateCheck('VAT_VATInput', 'Input VAT') 
                            && mandateCheck('VAT_VATIR', 'Input VAT Reversal') 						
                            ))
                            {
                            return false;
                        }
						
                    }
                    return true;
                    break;
                }
                case 'VAT_BtnVATMod':	
                {	
                    if (!(
                        mandateCheck('VAT_CmbLegislation', 'Legislation') 
                        && mandateCheck('VAT_VATPF', 'Tax %') 
                        && mandateCheck('VAT_VATOutput', 'Output Payable') 
                        && mandateCheck('VAT_VATCN', 'Credit Note') 
                        && mandateCheck('VAT_VATCNR', 'Credit Note Reversal') 						
                        ))
                        {
                        return false;
                    }
                    if(com.newgen.omniforms.formviewer.getNGValue("VAT_CmbLegislation")=="VAT"){
                        if (!(
                            mandateCheck('VAT_VATInput', 'Input VAT') 
                            && mandateCheck('VAT_VATIR', 'Input VAT Reversal') 						
                            ))
                            {
                            return false;
                        }
						
                    }
                    return true;
                    break;
                }
                case 'VAT_BtnVATDel':	
                {	
                    return true;
                    break;
                }
                case 'ChallanUpload_BtnChallanAdd':	
                {	
                    return true;
                    break;
                }
                case 'ChallanUpload_BtnChallanMod':	
                {	
                    return true;
                    break;
                }
                case 'ChallanUpload_BtnChallanDel':	
                {	
                    return true;
                    break;
                }
                case 'EntryTax_BtnAdd':	
                {	
					
                    return true;
                    break;
                }
                case 'EntryTax_BtnMod':	
                {	

                    return true;
                    break;
                }
                case 'EntryTax_BtnDel':	
                {	
                    return true;
                    break;
                }
                case 'Service_BtnAdd':	
                {	
                    return true;
                    break;
                }
                case 'Service_BtnMod':	
                {	
                    return true;
                    break;
                }
                case 'Service_BtnDel':	
                {	
                    return true;
                    break;
                }
				case 'AdditionalRFA_BtnAdd':	
                {	
                    return true;
                    break;
                }
                case 'AdditionalRFA_BtnMod':	
                {	
                    return true;
                    break;
                }
                case 'AdditionalRFA_BtnDel':	
                {	
                    return true;
                    break;
                }	
				case 'AdditionalRFA1_BtnAdd':	
                {	
                    return true;
                    break;
                }
                case 'AdditionalRFA1_BtnMod':	
                {	
                    return true;
                    break;
                }
                case 'AdditionalRFA1_BtnDel':	
                {	
                    return true;
                    break;
                }	 			
                case 'CB_SendReworkTo':	
                {	
					
                    return true;
                    break;
                } 
				case 'BtnQuery':	
                {	
					
                    return true;
                    break;
                }
            }
        }
        case 'change':
        {
            switch (pEvent.srcElement.id) 
            {
                case 'Entity':
                {
                    return true;
                    break;
                }
                case 'StatutoryLegislation':
                {   
                    return true;
                    break;
                }
                
                case 'TypeOfRequest':
                {
                 
                    return true;
                    break;
                }				
                case 'CTAddQ4Pay':
                {
                 
                    return true;
                    break;
                } 
				case 'PaymentFor':
                {
                 
                    return true;
                    break;
                }	
				
				case 'Period':
                {
                 
                    return true;
                    break;
                }	
				
                case 'VAT_CmbLegislation':
                {
					
                    return true;
                    break;
                }  
                case 'VAT_VATOutput':
                {
                    posvalidate('VAT_VATOutput');
					maxValueCheck('VAT_VATCN','VAT_VATOutput', 'Credit Note cannot be greater than Output Payable ');
                    if(parseFloat(getNGValue('VAT_VATInput'))>((parseFloat(getNGValue('VAT_VATCN'))-parseFloat(getNGValue('VAT_VATCNR')))+parseFloat(getNGValue('VAT_VATOutput')))){
                        alert('VAT payable for this tax percentage becomes Negative');
                        //setNullFocus('VAT_VATOutput');
                        return false;						
                    }
                    return true;
                    break;
                } 
                case 'VAT_VATCN':
                {
                    posvalidate('VAT_VATCN');
                    maxValueCheck('VAT_VATCN','VAT_VATOutput', 'Credit Note cannot be greater than Output Payable ');
                    if(parseFloat(getNGValue('VAT_VATInput'))>( parseFloat(getNGValue('VAT_VATOutput')) - (parseFloat(getNGValue('VAT_VATCN'))-parseFloat(getNGValue('VAT_VATCNR'))))){
                        alert('VAT payable for this tax percentage becomes Negative');
                        //setNullFocus('VAT_VATCN');
                        return false;						
                    }
                    return true;
                    break;
                } 
                case 'VAT_VATCNR':
                {	
                    posvalidate('VAT_VATCNR');
                    maxValueCheck('VAT_VATCNR','VAT_VATCN', 'Credit Note Reversal cannot be greater than Credit Note ');
                    if(parseFloat(getNGValue('VAT_VATInput'))>( parseFloat(getNGValue('VAT_VATOutput')) - (parseFloat(getNGValue('VAT_VATCN'))-parseFloat(getNGValue('VAT_VATCNR'))))){
                        alert('VAT payable for this tax percentage becomes Negative');
                        //setNullFocus('VAT_VATCNR');
                        return false;						
                    }
                    return true;
                    break;
                } 
                case 'VAT_VATInput':
                {
                    posvalidate('VAT_VATInput');
					maxValueCheck('VAT_VATIR','VAT_VATInput', 'Input VAT Reversal cannot be greater than Input VAT ');
                    if(parseFloat(getNGValue('VAT_VATInput'))>( parseFloat(getNGValue('VAT_VATOutput')) - (parseFloat(getNGValue('VAT_VATCN'))-parseFloat(getNGValue('VAT_VATCNR'))))){
                        alert('VAT payable for this tax percentage becomes Negative');
                        //setNullFocus('VAT_VATInput');
                        return false;						
                    }
                    return true;
                    break;
                } 
                case 'VAT_VATIR':
                {	
                    posvalidate('VAT_VATIR');
                    maxValueCheck('VAT_VATIR','VAT_VATInput', 'Input VAT Reversal cannot be greater than Input VAT ');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATOthrRev':
                {
                    posvalidate('cmplx_VAT_q_VATOthrRev');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATReb':
                {
                    posvalidate('cmplx_VAT_q_VATReb');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATOthAdj':
                {
                    posvalidate('cmplx_VAT_q_VATOthAdj');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATTolPay':
                {
                    posvalidate('cmplx_VAT_q_VATTolPay');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATPrvMonPay':
                {
                    posvalidate('cmplx_VAT_q_VATPrvMonPay');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATAvgLa3Mon':
                {
                    posvalidate('cmplx_VAT_q_VATAvgLa3Mon');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATOthAdjFrmAddRFA':
                {
                    posvalidate('cmplx_VAT_q_VATOthAdjFrmAddRFA');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATAppOf':
                {
                    posvalidate('cmplx_VAT_q_VATAppOf');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_VATAppRRFA':
                {
                    posvalidate('cmplx_VAT_q_VATAppRRFA');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTOthRev':
                {
                    posvalidate('cmplx_VAT_q_CSTOthRev');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTReb':
                {
                    posvalidate('cmplx_VAT_q_CSTReb');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTOthAdj':
                {
                    posvalidate('cmplx_VAT_q_CSTOthAdj');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTOthRev':
                {
                    posvalidate('cmplx_VAT_q_CSTOthRev');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTTotpay':
                {
                    posvalidate('cmplx_VAT_q_CSTTotpay');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTPrevMonPay':
                {
                    posvalidate('cmplx_VAT_q_CSTPrevMonPay');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTAvgLa3Mon':
                {
                    posvalidate('cmplx_VAT_q_CSTAvgLa3Mon');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTOthAdjFrmAddRFA':
                {
                    posvalidate('cmplx_VAT_q_CSTOthAdjFrmAddRFA');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTAppOf':
                {
                    posvalidate('cmplx_VAT_q_CSTAppOf');
                    return true;
                    break;
                } 
                case 'cmplx_VAT_q_CSTAppRRFA':
                {
                    posvalidate('cmplx_VAT_q_CSTAppRRFA');
                    return true;
                    break;
                } 

                case 'EntryTax_MaterialType':
                {
					
                    return true;
                    break;
                }  
				case 'EntryTax_Tax':
                {	
					var taxVal =  getNGValue('EntryTax_Tax');
					if(parseFloat(taxVal) < parseFloat(0) || parseFloat(taxVal)>parseFloat(100)){
						alert('Please enter Tax Percentage between 0 and 100');	
						setNullFocus('EntryTax_Tax');
                        return false;					
					}
                    return true;
                    break;
                } 

                case 'EntryTax_MaterialValue':
                {
                    posvalidate('EntryTax_MaterialValue');
                    maxValueCheck('EntryTax_Reversal','EntryTax_MaterialValue', 'Reversal cannot be greater than Value of Material');
                    maxValueCheck('EntryTax_Reversal','EntryTax_EntryTaxAppl', 'Reversal cannot be greater than Entry Tax Applicable');
					
                    return true;
                    break;
                } 
                case 'EntryTax_Reversal':
                {
                    posvalidate('EntryTax_Reversal');
                    maxValueCheck('EntryTax_Reversal','EntryTax_MaterialValue', 'Reversal cannot be greater than Value of Material');
                    maxValueCheck('EntryTax_Reversal','EntryTax_EntryTaxAppl', 'Reversal cannot be greater than Entry Tax Applicable');
                    return true;
                    break;
                }  
                case 'cmplx_Entry_q_Totalpay':
                {
                    posvalidate('cmplx_Entry_q_Totalpay');
                    return true;
                    break;
                }
                case 'cmplx_Entry_q_OthAdjARFA':
                {
                    posvalidate('cmplx_Entry_q_OthAdjARFA');
                    return true;
                    break;
                }
                case 'cmplx_Entry_q_PrevMonPay':
                {
                    posvalidate('cmplx_Entry_q_PrevMonPay');
                    return true;
                    break;
                }
                case 'cmplx_Entry_q_AvgLa3Mon':
                {
                    posvalidate('cmplx_Entry_q_AvgLa3Mon');
                    return true;
                    break;
                }
                case 'cmplx_Entry_q_ApprvlOf':
                {
                    posvalidate('cmplx_Entry_q_ApprvlOf');
                    return true;
                    break;
                }
                case 'cmplx_Entry_q_TotTaxAppRRFA':
                {
                    posvalidate('cmplx_Entry_q_TotTaxAppRRFA');
                    return true;
                    break;
                }				
                case 'cmplx_TDS_q_TDSAdjust':
                {   
                    posvalidate('cmplx_TDS_q_TDSAdjust');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_A194':
                {   
                    posvalidate('cmplx_TDS_q_A194');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_C194':
                {   
                    posvalidate('cmplx_TDS_q_C194');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_H194':
                {   
                    posvalidate('cmplx_TDS_q_H194');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_I194':
                {   
                    posvalidate('cmplx_TDS_q_I194');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_J194':
                {   
                    posvalidate('cmplx_TDS_q_J194');
                    return true;
                    break;
                }
				case 'cmplx_TDS_q_IA194':
                {	
                    posvalidate('cmplx_TDS_q_IA194');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TDSTotPay':
                {   
                    posvalidate('cmplx_TDS_q_TDSTotPay');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TDSPrevMonPaid':
                {   
                    posvalidate('cmplx_TDS_q_TDSPrevMonPaid');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TDSAvgThreeMon':
                {   
                    posvalidate('cmplx_TDS_q_TDSAvgThreeMon');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TDSApprovalOf':
                {   
                    posvalidate('cmplx_TDS_q_TDSApprovalOf');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TDSTotExcl195':
                {   
                    posvalidate('cmplx_TDS_q_TDSTotExcl195');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TCSAdjust':
                {	
                    posvalidate('cmplx_TDS_q_TCSAdjust');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_C206':
                {	
                    posvalidate('cmplx_TDS_q_C206');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TCSTotPay':
                {	
                    posvalidate('cmplx_TDS_q_TCSTotPay');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TCSAvrThreeMon':
                {	
                    posvalidate('cmplx_TDS_q_TCSAvrThreeMon');
                    return true;
                    break;
                }
				
                case 'cmplx_TDS_q_TCSPrevMonthPaid':
                {	
                    posvalidate('cmplx_TDS_q_TCSPrevMonthPaid');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TCSApprovalOf':
                {	
                    posvalidate('cmplx_TDS_q_TCSApprovalOf');
                    return true;
                    break;
                }
                case 'cmplx_TDS_q_TCSTotApprvdRFA':
                {	
                    posvalidate('cmplx_TDS_q_TCSTotApprvdRFA');
                    return true;
                    break;
                }
                case 'cmplx_TDS195_q_ApprovalOf':
                {	
                    posvalidate('cmplx_TDS195_q_ApprovalOf');
                    return true;
                    break;
                }
                case 'cmplx_TDS195_q_ApprovedInRFA':
                {	
                    posvalidate('cmplx_TDS195_q_ApprovedInRFA');
                    return true;
                    break;
                } 
				
				case 'cmplx_TDS195_q_EqualLevied':
                {	
                    posvalidate('cmplx_TDS195_q_EqualLevied');
                    return true;
                    break;
                }

				
				case 'cmplx_TDS195_q_SalesValue':
                {	
                    posvalidate('cmplx_TDS195_q_SalesValue');
					maxValueCheck('cmplx_TDS195_q_TDS195Pay','cmplx_TDS195_q_SalesValue', 'Total TDS195 Payable cannot be greater than Gross Value ');
                    return true;
                    break;
                }
				case 'cmplx_TDS195_q_TDS195Pay':
                {	
                    posvalidate('cmplx_TDS195_q_TDS195Pay');
					maxValueCheck('cmplx_TDS195_q_TDS195Pay','cmplx_TDS195_q_SalesValue', 'Total TDS195 Payable cannot be greater than  Gross Value');
                    return true;
                    break;
                }
                case 'Service_CmbMethod':
                {
                    return true;
                    break;
                }
                case 'Service_CmbServiceType':
                {
                    return true;
                    break;
                }
                case 'Service_Adjust':
                {	
                    //posvalidate('Service_Adjust');
                    return true;
                    break;
                }
                case 'Service_AdjstSBC':
                {	
                    //posvalidate('Service_AdjstSBC');
                    return true;
                    break;
                }
                case 'Service_AdjstKKC':
                {	
                    //posvalidate('Service_AdjstKKC');
                    return true;
                    break;
                }
                case 'Service_BTTax':
                {
                    posvalidate('Service_BTTax');
                    return true;
                    break;
                }
                case 'Service_SBCTax':
                {
                    posvalidate('Service_SBCTax');
                    return true;
                    break;
                }
                case 'Service_KKCTax':
                {
                    posvalidate('Service_KKCTax');
                    return true;
                    break;
                }
                case 'Service_NetBT':
                {	
                    posvalidate('Service_NetBT');
                    return true;
                    break;
                }
                case 'Service_NetSBC':
                {	
                    posvalidate('Service_NetSBC');
                    return true;
                    break;
                }
                case 'Service_NetKKC':
                {	
                    posvalidate('Service_NetKKC');
                    return true;
                    break;
                } 
				case 'cmplx_Service_q_AdjARFAST':
                {	
                    posvalidate('cmplx_Service_q_AdjARFAST');
                    return true;
                    break;
                }
				case 'cmplx_Service_q_AdjARFARCM':
                {	
                    posvalidate('cmplx_Service_q_AdjARFARCM');
                    return true;
                    break;
                }
				case 'Service_GrossValue':
                {	
                    posvalidate('Service_GrossValue');
                    return true;
                    break;
                }
                case 'cmplx_Excise_q_PlandPLAUsage':
                {		
                    posvalidate('cmplx_Excise_q_PlandPLAUsage');
						
                    maxValueCheck('cmplx_Excise_q_PlandPLAUsage','cmplx_Excise_q_PLAOpenBal', 'PLA Opening Balance Planned usage cannot be greater than Current period');

					maxCheckExciseDuty();
                    totExcisePay();
					
                    return true;
                    break;
                }  
                case 'cmplx_Excise_q_PLAOpenBal':
                {		
                    posvalidate('cmplx_Excise_q_PLAOpenBal');
						
                    maxValueCheck('cmplx_Excise_q_PlandPLAUsage','cmplx_Excise_q_PLAOpenBal', 'PLA Opening Balance Planned usage cannot be greater than Current period');					
					
                    return true;
                    break;
                } 
                case 'cmplx_Excise_q_POthersReavCr':
                {	
                    posvalidate('cmplx_Excise_q_POthersReavCr');
					
                    maxValueCheck('cmplx_Excise_q_POthersReavCr','cmplx_Excise_q_NCAvailOthRC', 'Others (reavilment of credit etc) Planned usage cannot be greater than  of Others Net Credit Available');
					maxCheckExciseDuty();
                    totExcisePay();
					
                    return true;
                    break;
                }
                case 'cmplx_Excise_q_OthReavCredit':
                {	
                    posvalidate('cmplx_Excise_q_OthReavCredit');
					var revVal = getNGValue('cmplx_Excise_q_RevOthRC');
					if(parseFloat(revVal) > 0 ){
						maxValueCheck('cmplx_Excise_q_RevOthRC','cmplx_Excise_q_OthReavCredit', 'Others Reversal cannot be greater than  of Others (reavilment of credit etc) Current Period');
					}
					subtractTot3('cmplx_Excise_q_OthReavCredit','cmplx_Excise_q_RevOthRC','cmplx_Excise_q_NCAvailOthRC');		
                    maxValueCheck('cmplx_Excise_q_POthersReavCr','cmplx_Excise_q_NCAvailOthRC', 'Others (reavilment of credit etc) Planned usage cannot be greater than  of Others Net Credit Available');					 
					
                    return true;
                    break;
                } 
				case 'cmplx_Excise_q_RevOthRC':
                {	
                    //posvalidate('cmplx_Excise_q_RevOthRC');
					var revVal = getNGValue('cmplx_Excise_q_RevOthRC');
					if(parseFloat(revVal) > 0 ){
						maxValueCheck('cmplx_Excise_q_RevOthRC','cmplx_Excise_q_OthReavCredit', 'Others Reversal cannot be greater than  of Others (reavilment of credit etc) Current Period');
					}
					subtractTot3('cmplx_Excise_q_OthReavCredit','cmplx_Excise_q_RevOthRC','cmplx_Excise_q_NCAvailOthRC');	
                    maxValueCheck('cmplx_Excise_q_POthersReavCr','cmplx_Excise_q_NCAvailOthRC', 'Others (reavilment of credit etc) Planned usage cannot be greater than  of Others Net Credit Available');					 
					
                    return true;
                    break;
                }

				
                case 'cmplx_Excise_q_PCCIUsage':
                {	
                    posvalidate('cmplx_Excise_q_PCCIUsage');				
					
					maxValueCheck('cmplx_Excise_q_PCCIUsage','cmplx_Excise_q_NCAvailCCI', 'Cenvat credit on input Planned Usage cannot be greater than Cenvat credit on input Net Credit Available');	
                    //maxCheckExcise();
					maxCheckExciseDuty();
					totExcisePay();				
					
                    return true;
                    break;
                }
				
                case 'cmplx_Excise_q_OBCenCrInput':
                {	
                    posvalidate('cmplx_Excise_q_OBCenCrInput');
					maxCheckEDReversal('cmplx_Excise_q_OBCenCrInput','cmplx_Excise_q_CCIFTPeriod','cmplx_Excise_q_RevCCInput');
					netCreditAvail('cmplx_Excise_q_OBCenCrInput','cmplx_Excise_q_CCIFTPeriod','cmplx_Excise_q_RevCCInput','cmplx_Excise_q_NCAvailCCI');					
					maxValueCheck('cmplx_Excise_q_PCCIUsage','cmplx_Excise_q_NCAvailCCI', 'Cenvat credit on input Planned Usage cannot be greater than Cenvat credit on input Net Credit Available');
					
                    return true;
                    break;
                }
                case 'cmplx_Excise_q_CCIFTPeriod':
                {	
                    posvalidate('cmplx_Excise_q_CCIFTPeriod');
					
					maxCheckEDReversal('cmplx_Excise_q_OBCenCrInput','cmplx_Excise_q_CCIFTPeriod','cmplx_Excise_q_RevCCInput');
					netCreditAvail('cmplx_Excise_q_OBCenCrInput','cmplx_Excise_q_CCIFTPeriod','cmplx_Excise_q_RevCCInput','cmplx_Excise_q_NCAvailCCI');					
					maxValueCheck('cmplx_Excise_q_PCCIUsage','cmplx_Excise_q_NCAvailCCI', 'Cenvat credit on input Planned Usage cannot be greater than Cenvat credit on input Net Credit Available');				
					
                    return true;
                    break;
                }
				
				case 'cmplx_Excise_q_RevCCInput':
                {	
                    //posvalidate('cmplx_Excise_q_RevCCInput');
					maxCheckEDReversal('cmplx_Excise_q_OBCenCrInput','cmplx_Excise_q_CCIFTPeriod','cmplx_Excise_q_RevCCInput');
					netCreditAvail('cmplx_Excise_q_OBCenCrInput','cmplx_Excise_q_CCIFTPeriod','cmplx_Excise_q_RevCCInput','cmplx_Excise_q_NCAvailCCI');
					
					maxValueCheck('cmplx_Excise_q_PCCIUsage','cmplx_Excise_q_NCAvailCCI', 'Cenvat credit on input Planned Usage cannot be greater than Cenvat credit on input Net Credit Available');				
					
                    return true;
                    break;
                }
				
                case 'cmplx_Excise_q_PCCCapGUsage':
                {	
                    posvalidate('cmplx_Excise_q_PCCCapGUsage');
					
					maxValueCheck('cmplx_Excise_q_PCCCapGUsage','cmplx_Excise_q_NCAvailCCCG', 'Cenvat credit on Capital Goods Planned Usage cannot be greater than Cenvat credit on Capital Goods Net Credit Available');		
					//maxCheckExcise();
					maxCheckExciseDuty();
                    totExcisePay();					
					
                    return true;
                    break;
                }
                case 'cmplx_Excise_q_OBCCCapGood':
                {	
                    posvalidate('cmplx_Excise_q_OBCCCapGood');
					maxCheckEDReversal('cmplx_Excise_q_OBCCCapGood','cmplx_Excise_q_CCCapGFTPeriod','cmplx_Excise_q_RevCCCG');
					netCreditAvail('cmplx_Excise_q_OBCCCapGood','cmplx_Excise_q_CCCapGFTPeriod','cmplx_Excise_q_RevCCCG','cmplx_Excise_q_NCAvailCCCG');
					
					maxValueCheck('cmplx_Excise_q_PCCCapGUsage','cmplx_Excise_q_NCAvailCCCG', 'Cenvat credit on Capital Goods Planned Usage cannot be greater than Cenvat credit on Capital Goods Net Credit Available');
                    return true;
                    break;
                }
                case 'cmplx_Excise_q_CCCapGFTPeriod':
                {	
                    posvalidate('cmplx_Excise_q_CCCapGFTPeriod');
					
					maxCheckEDReversal('cmplx_Excise_q_OBCCCapGood','cmplx_Excise_q_CCCapGFTPeriod','cmplx_Excise_q_RevCCCG');
					netCreditAvail('cmplx_Excise_q_OBCCCapGood','cmplx_Excise_q_CCCapGFTPeriod','cmplx_Excise_q_RevCCCG','cmplx_Excise_q_NCAvailCCCG');
					
					maxValueCheck('cmplx_Excise_q_PCCCapGUsage','cmplx_Excise_q_NCAvailCCCG', 'Cenvat credit on Capital Goods Planned Usage cannot be greater than Cenvat credit on Capital Goods Net Credit Available');
                    return true;
                    break;
                }	
				
				case 'cmplx_Excise_q_RevCCCG':
                {	
                    //posvalidate('cmplx_Excise_q_RevCCCG');
					maxCheckEDReversal('cmplx_Excise_q_OBCCCapGood','cmplx_Excise_q_CCCapGFTPeriod','cmplx_Excise_q_RevCCCG');
					netCreditAvail('cmplx_Excise_q_OBCCCapGood','cmplx_Excise_q_CCCapGFTPeriod','cmplx_Excise_q_RevCCCG','cmplx_Excise_q_NCAvailCCCG');
					
					maxValueCheck('cmplx_Excise_q_PCCCapGUsage','cmplx_Excise_q_NCAvailCCCG', 'Cenvat credit on Capital Goods Planned Usage cannot be greater than Cenvat credit on Capital Goods Net Credit Available');
                    return true;
                    break;
                }
				
                case 'cmplx_Excise_q_PCCISUsage':
                {	
                    posvalidate('cmplx_Excise_q_PCCISUsage');
					
					maxValueCheck('cmplx_Excise_q_PCCISUsage','cmplx_Excise_q_NCAvailCCIS', 'Cenvat credit on input service Planned Usage cannot be greater than Cenvat credit on input service Net Credit Available');
					//maxCheckExcise();
					maxCheckExciseDuty();
                    totExcisePay();
						
                    return true;
                    break;
                }
                case 'cmplx_Excise_q_CCIService':
                {	
                    posvalidate('cmplx_Excise_q_CCIService');
					maxCheckEDReversal('cmplx_Excise_q_OBCCIService','cmplx_Excise_q_CCIService','cmplx_Excise_q_RevCCIS');
					netCreditAvail('cmplx_Excise_q_OBCCIService','cmplx_Excise_q_CCIService','cmplx_Excise_q_RevCCIS','cmplx_Excise_q_NCAvailCCIS');
					
					maxValueCheck('cmplx_Excise_q_PCCISUsage','cmplx_Excise_q_NCAvailCCIS', 'Cenvat credit on input service Planned Usage cannot be greater than Cenvat credit on input service Net Credit Available');
					
                    return true;
                    break;
                }
                case 'cmplx_Excise_q_OBCCIService':
                {	
                    posvalidate('cmplx_Excise_q_OBCCIService');
					maxCheckEDReversal('cmplx_Excise_q_OBCCIService','cmplx_Excise_q_CCIService','cmplx_Excise_q_RevCCIS');
					netCreditAvail('cmplx_Excise_q_OBCCIService','cmplx_Excise_q_CCIService','cmplx_Excise_q_RevCCIS','cmplx_Excise_q_NCAvailCCIS');
					
					maxValueCheck('cmplx_Excise_q_PCCISUsage','cmplx_Excise_q_NCAvailCCIS', 'Cenvat credit on input service Planned Usage cannot be greater than Cenvat credit on input service Net Credit Available');
						
                    return true;
                    break;
                }
				
				case 'cmplx_Excise_q_RevCCIS':
                {	
                    //posvalidate('cmplx_Excise_q_RevCCIS');
					maxCheckEDReversal('cmplx_Excise_q_OBCCIService','cmplx_Excise_q_CCIService','cmplx_Excise_q_RevCCIS');
					netCreditAvail('cmplx_Excise_q_OBCCIService','cmplx_Excise_q_CCIService','cmplx_Excise_q_RevCCIS','cmplx_Excise_q_NCAvailCCIS');
					
					maxValueCheck('cmplx_Excise_q_PCCISUsage','cmplx_Excise_q_NCAvailCCIS', 'Cenvat credit on input service Planned Usage cannot be greater than Cenvat credit on input service Net Credit Available');
						
                    return true;
                    break;
                }
					
                case 'cmplx_Excise_q_ExcPayble':
                {	
                    posvalidate('cmplx_Excise_q_ExcPayble');
                    maxCheckExciseDuty();
					totExcisePay();
					
                    return true;
                    break;
                }
				case 'cmplx_Excise_q_AdjARFA':
                {	
                    posvalidate('cmplx_Excise_q_AdjARFA');
					totExcisePay();
					
                    return true;
                    break;
                }
				case 'cmplx_Excise_q_PlannedPLAPayable':
                {	
                    posvalidate('cmplx_Excise_q_PlannedPLAPayable');					
					
                    return true;
                    break;
                }
				
				case 'cmplx_Excise_q_HigherEduCess':
                {	
                    posvalidate('cmplx_Excise_q_HigherEduCess');					
					
                    return true;
                    break;
                }
				
				case 'cmplx_Excise_q_SecEduCess':
                {	
                    posvalidate('cmplx_Excise_q_SecEduCess');					
					
                    return true;
                    break;
                }
				
                case 'IncludesCST':
                {
                    var EnableFields1=["cmplx_NR_RFA_q_Type2","cmplx_NR_RFA_q_Scope2","cmplx_NR_RFA_q_Subject2","cmplx_NR_RFA_q_CaseNo2","cmplx_NR_RFA_CasePeriodFom2","cmplx_NR_RFA_CasePeriodTo2","cmplx_NR_RFA_q_Principle2","cmplx_NR_RFA_q_Interest2","cmplx_NR_RFA_q_Penalty2","cmplx_NR_RFA_q_PartPaymMode22","cmplx_NR_RFA_q_BalDue2","cmplx_NR_RFA_q_ProviAvail2","cmplx_NR_RFA_PeriodAppvalFrom2","cmplx_NR_RFA_PeriodAppvalTo2","cmplx_NR_RFA_PeriodAppvalTo2","cmplx_NR_RFA_q_InterestPaid2","cmplx_NR_RFA_q_PenaltyPaid2"];
                    if(getNGValue('IncludesCST')=='Yes'){
                        
                        enableFields(EnableFields1, "Enable")
                                
                    }
                    else{
                        enableFields(EnableFields1, "Disable")
                    }
                    return false;
                    break;
                }
                case 'cmplx_Corporate_q_PLAccProfitPrev':
                {	
                    posvalidate('cmplx_Corporate_q_PLAccProfitPrev');
                    //Subtotal1 Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_PLAccProfitPrev','cmplx_Corporate_q_ItemsConSepPrev','cmplx_Corporate_q_ItemConSepPrev2','cmplx_Corporate_q_SubTotalPrev1');
                    //Subtotal2 calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev1','cmplx_Corporate_q_TimeDiffPrev1','cmplx_Corporate_q_PermDiffPrev1','cmplx_Corporate_q_SubTotalPrev2');
                    //SubTotal of Business Income Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev2','cmplx_Corporate_q_TimeDiffPrev2','cmplx_Corporate_q_PermDiffPrev2','cmplx_Corporate_q_STBusIncPrev');
                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    									
					
                    return true;
                    break;
                } 
                case 'cmplx_Corporate_q_PLAccProfit':
                {	
                    posvalidate('cmplx_Corporate_q_PLAccProfit');
                    //Subtotal1 calculation for Current Year
                    subTot4('cmplx_Corporate_q_PLAccProfit','cmplx_Corporate_q_ItemConSep','cmplx_Corporate_q_ItemConSep2','cmplx_Corporate_q_SubTotal1');
                    //Subtotal2 calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal1','cmplx_Corporate_q_TimeDiff1','cmplx_Corporate_q_PermDiff1','cmplx_Corporate_q_SubTotal2');
                    //SubTotal of Business Income Calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal2','cmplx_Corporate_q_TimeDiff2','cmplx_Corporate_q_PermDiff2','cmplx_Corporate_q_SubTotBusInc');
                    //setNGValue('cmplx_Corporate_q_IFBIncome',getNGValue('cmplx_Corporate_q_SubTotBusInc'));
					subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
                    TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                } 
                case 'cmplx_Corporate_q_ItemConSep':
                {	
                    negvalidate('cmplx_Corporate_q_ItemConSep');
                    //Subtotal1 calculation for Current Year
                    subTot4('cmplx_Corporate_q_PLAccProfit','cmplx_Corporate_q_ItemConSep','cmplx_Corporate_q_ItemConSep2','cmplx_Corporate_q_SubTotal1');
                    //Subtotal2 calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal1','cmplx_Corporate_q_TimeDiff1','cmplx_Corporate_q_PermDiff1','cmplx_Corporate_q_SubTotal2');
                    //SubTotal of Business Income Calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal2','cmplx_Corporate_q_TimeDiff2','cmplx_Corporate_q_PermDiff2','cmplx_Corporate_q_SubTotBusInc');
                    //setNGValue('cmplx_Corporate_q_IFBIncome',getNGValue('cmplx_Corporate_q_SubTotBusInc'));
					subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
                    TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                } 
                case 'cmplx_Corporate_q_ItemsConSepPrev':
                {	
                    negvalidate('cmplx_Corporate_q_ItemsConSepPrev');
                    //Subtotal1 Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_PLAccProfitPrev','cmplx_Corporate_q_ItemsConSepPrev','cmplx_Corporate_q_ItemConSepPrev2','cmplx_Corporate_q_SubTotalPrev1');
                    //Subtotal2 calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev1','cmplx_Corporate_q_TimeDiffPrev1','cmplx_Corporate_q_PermDiffPrev1','cmplx_Corporate_q_SubTotalPrev2');
                    //SubTotal of Business Income Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev2','cmplx_Corporate_q_TimeDiffPrev2','cmplx_Corporate_q_PermDiffPrev2','cmplx_Corporate_q_STBusIncPrev');
                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                   
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_ItemConSep2':
                {	
                    posvalidate('cmplx_Corporate_q_ItemConSep2');
                    //Subtotal1 calculation for Current Year
                    subTot4('cmplx_Corporate_q_PLAccProfit','cmplx_Corporate_q_ItemConSep','cmplx_Corporate_q_ItemConSep2','cmplx_Corporate_q_SubTotal1');
                    //Subtotal2 calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal1','cmplx_Corporate_q_TimeDiff1','cmplx_Corporate_q_PermDiff1','cmplx_Corporate_q_SubTotal2');
                    //SubTotal of Business Income Calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal2','cmplx_Corporate_q_TimeDiff2','cmplx_Corporate_q_PermDiff2','cmplx_Corporate_q_SubTotBusInc');
                    //setNGValue('cmplx_Corporate_q_IFBIncome',getNGValue('cmplx_Corporate_q_SubTotBusInc'));
					subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
                    TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                } 
                case 'cmplx_Corporate_q_ItemConSepPrev2':
                {	
                    posvalidate('cmplx_Corporate_q_ItemConSepPrev2');
                    //Subtotal1 Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_PLAccProfitPrev','cmplx_Corporate_q_ItemsConSepPrev','cmplx_Corporate_q_ItemConSepPrev2','cmplx_Corporate_q_SubTotalPrev1');
                    //Subtotal2 calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev1','cmplx_Corporate_q_TimeDiffPrev1','cmplx_Corporate_q_PermDiffPrev1','cmplx_Corporate_q_SubTotalPrev2');
                    //SubTotal of Business Income Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev2','cmplx_Corporate_q_TimeDiffPrev2','cmplx_Corporate_q_PermDiffPrev2','cmplx_Corporate_q_STBusIncPrev');
                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                    
                    return true;
                    break;
                } 
                case 'cmplx_Corporate_q_SubTotal1':
                {	
			
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_SubTotalPrev1':
                {	
										
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_TimeDiffPrev1':
                {	
                    posvalidate('cmplx_Corporate_q_TimeDiffPrev1');

                    //Subtotal2 calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev1','cmplx_Corporate_q_TimeDiffPrev1','cmplx_Corporate_q_PermDiffPrev1','cmplx_Corporate_q_SubTotalPrev2');
                    //SubTotal of Business Income Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev2','cmplx_Corporate_q_TimeDiffPrev2','cmplx_Corporate_q_PermDiffPrev2','cmplx_Corporate_q_STBusIncPrev');
                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_PermDiffPrev1':
                {	
                    posvalidate('cmplx_Corporate_q_PermDiffPrev1');

                    //Subtotal2 calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev1','cmplx_Corporate_q_TimeDiffPrev1','cmplx_Corporate_q_PermDiffPrev1','cmplx_Corporate_q_SubTotalPrev2');
                    //SubTotal of Business Income Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev2','cmplx_Corporate_q_TimeDiffPrev2','cmplx_Corporate_q_PermDiffPrev2','cmplx_Corporate_q_STBusIncPrev');
                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_SubTotalPrev2':
                {	
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_TimeDiff1':
                {	
                    posvalidate('cmplx_Corporate_q_TimeDiff1');	
                    //Subtotal2 calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal1','cmplx_Corporate_q_TimeDiff1','cmplx_Corporate_q_PermDiff1','cmplx_Corporate_q_SubTotal2');
                    //SubTotal of Business Income Calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal2','cmplx_Corporate_q_TimeDiff2','cmplx_Corporate_q_PermDiff2','cmplx_Corporate_q_SubTotBusInc');
                    //setNGValue('cmplx_Corporate_q_IFBIncome',getNGValue('cmplx_Corporate_q_SubTotBusInc'));
					subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
                    TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_PermDiff1':
                {	
                    posvalidate('cmplx_Corporate_q_PermDiff1');		
                    //Subtotal2 calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal1','cmplx_Corporate_q_TimeDiff1','cmplx_Corporate_q_PermDiff1','cmplx_Corporate_q_SubTotal2');
                    //SubTotal of Business Income Calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal2','cmplx_Corporate_q_TimeDiff2','cmplx_Corporate_q_PermDiff2','cmplx_Corporate_q_SubTotBusInc');
                    //setNGValue('cmplx_Corporate_q_IFBIncome',getNGValue('cmplx_Corporate_q_SubTotBusInc'));
					subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
                    TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
					calcCorporateTax();
					
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_SubTotal2':
                {	
                    posvalidate('cmplx_Corporate_q_SubTotal2');	
					
				
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_TimeDiffPrev2':
                {		
                    negvalidate('cmplx_Corporate_q_TimeDiffPrev2');

                    //SubTotal of Business Income Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev2','cmplx_Corporate_q_TimeDiffPrev2','cmplx_Corporate_q_PermDiffPrev2','cmplx_Corporate_q_STBusIncPrev');
                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_PermDiffPrev2':
                {	
                    negvalidate('cmplx_Corporate_q_PermDiffPrev2');	

                    //SubTotal of Business Income Calculation for Prevoius Year
                    subTot4('cmplx_Corporate_q_SubTotalPrev2','cmplx_Corporate_q_TimeDiffPrev2','cmplx_Corporate_q_PermDiffPrev2','cmplx_Corporate_q_STBusIncPrev');
                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_STBusIncPrev':
                {	
                    posvalidate('cmplx_Corporate_q_STBusIncPrev');					

                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_TimeDiff2':
                {		
                    negvalidate('cmplx_Corporate_q_TimeDiff2');
                    //SubTotal of Business Income Calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal2','cmplx_Corporate_q_TimeDiff2','cmplx_Corporate_q_PermDiff2','cmplx_Corporate_q_SubTotBusInc');
                    //setNGValue('cmplx_Corporate_q_IFBIncome',getNGValue('cmplx_Corporate_q_SubTotBusInc'));
					subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
                    TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_PermDiff2':
                {	
                    negvalidate('cmplx_Corporate_q_PermDiff2');	
                    //SubTotal of Business Income Calculation for Current Year					
                    subTot4('cmplx_Corporate_q_SubTotal2','cmplx_Corporate_q_TimeDiff2','cmplx_Corporate_q_PermDiff2','cmplx_Corporate_q_SubTotBusInc');
                    //setNGValue('cmplx_Corporate_q_IFBIncome',getNGValue('cmplx_Corporate_q_SubTotBusInc'));
					subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
                    TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_SubTotBusInc':
                {	
                    posvalidate('cmplx_Corporate_q_SubTotBusInc');	
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFHPropPrev':
                {	

                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFLTCIGNIPrev':
                {	
                    posvalidate('cmplx_Corporate_q_IFLTCIGNIPrev');					

                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFSTCGPrev':
                {						

                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFLTCIGIPrev':
                {						
                    posvalidate('cmplx_Corporate_q_IFLTCIGIPrev');

                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFOSPrev':
                {						
                    posvalidate('cmplx_Corporate_q_IFOSPrev');

                    //Gross Total Income for Prevoius Year
                    subTot7('cmplx_Corporate_q_STBusIncPrev','cmplx_Corporate_q_IFHPropPrev','cmplx_Corporate_q_IFLTCIGNIPrev','cmplx_Corporate_q_IFSTCGPrev','cmplx_Corporate_q_IFLTCIGIPrev','cmplx_Corporate_q_IFOSPrev','cmplx_Corporate_q_GTIPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_GTIPrev':
                {					
                    posvalidate('cmplx_Corporate_q_GTIPrev');
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFHProp':
                {	
                    setNGValue('cmplx_Corporate_q_IFHPropIncome',getNGValue('cmplx_Corporate_q_IFHProp'));
                    TaxCalc('cmplx_Corporate_q_IFHPropIncome','cmplx_Corporate_q_IFHPropRate','cmplx_Corporate_q_IFHPropTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
					calcCorporateTax();
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFLTCIGNonIndex':
                {						
                    posvalidate('cmplx_Corporate_q_IFLTCIGNonIndex');
                    setNGValue('cmplx_Corporate_q_IFLTCGNIIncome',getNGValue('cmplx_Corporate_q_IFLTCIGNonIndex'));
                    TaxCalc('cmplx_Corporate_q_IFLTCGNIIncome','cmplx_Corporate_q_IFLTCGNIRate','cmplx_Corporate_q_IFLTCGNITax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFSTCGains':
                {						
                    setNGValue('cmplx_Corporate_q_IFSTCGIncome',getNGValue('cmplx_Corporate_q_IFSTCGains'));
                    TaxCalc('cmplx_Corporate_q_IFSTCGIncome','cmplx_Corporate_q_IFSTCGRate','cmplx_Corporate_q_IFSTCGTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_IFLTCIGIndex':
                {						
                    posvalidate('cmplx_Corporate_q_IFLTCIGIndex');
                    setNGValue('cmplx_Corporate_q_IFLTCGIIncome',getNGValue('cmplx_Corporate_q_IFLTCIGIndex'));
                    TaxCalc('cmplx_Corporate_q_IFLTCGIIncome','cmplx_Corporate_q_IFLTCGIRate','cmplx_Corporate_q_IFLTCGITax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    calcCorporateTax();
					
                    return true;
                    break;
                }
                
                case 'cmplx_Corporate_q_IFOSource':
                {						
                    posvalidate('cmplx_Corporate_q_IFOSource');
                    setNGValue('cmplx_Corporate_q_IFOSIncome',getNGValue('cmplx_Corporate_q_IFOSource'));
                    //Tax Calculation
                    TaxCalc('cmplx_Corporate_q_IFOSIncome','cmplx_Corporate_q_IFOSRate','cmplx_Corporate_q_IFOSTax');
                    //Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
                    //Gross Total Income for Current Year
                    subTot7('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_IFHProp','cmplx_Corporate_q_IFLTCIGNonIndex','cmplx_Corporate_q_IFSTCGains','cmplx_Corporate_q_IFLTCIGIndex','cmplx_Corporate_q_IFOSource','cmplx_Corporate_q_GtotIncome');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');                    
					calcCorporateTax();
                    return true;
                    break;
                }
                
                case 'cmplx_Corporate_q_GtotIncome':
                {						
                    posvalidate('cmplx_Corporate_q_GtotIncome');
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_DUCVIAPrev':
                {						
                    negvalidate('cmplx_Corporate_q_DUCVIAPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_AOElDPrev':
                {						
                    negvalidate('cmplx_Corporate_q_AOElDPrev');
                    //Taxable Income calculation for Previous Year
                    subTot4('cmplx_Corporate_q_GTIPrev','cmplx_Corporate_q_DUCVIAPrev','cmplx_Corporate_q_AOElDPrev','cmplx_Corporate_q_TaxIncPrev');
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_TaxIncPrev':
                {						
                    posvalidate('cmplx_Corporate_q_TaxIncPrev');
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_DUChapVIA':
                {						
                    negvalidate('cmplx_Corporate_q_DUChapVIA');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
					TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
					//Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
					calcCorporateTax();
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_AOElDeduct':
                {						
                    negvalidate('cmplx_Corporate_q_AOElDeduct');
                    //Taxable Income calculation for Current Year
                    subTot4('cmplx_Corporate_q_GtotIncome','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_TaxIncome');
                    subTot4('cmplx_Corporate_q_SubTotBusInc','cmplx_Corporate_q_DUChapVIA','cmplx_Corporate_q_AOElDeduct','cmplx_Corporate_q_IFBIncome');
					TaxCalc('cmplx_Corporate_q_IFBIncome','cmplx_Corporate_q_IFBRate','cmplx_Corporate_q_IFBTax');
					//Net tax payable for the year
                    subTot7('cmplx_Corporate_q_IFBTax','cmplx_Corporate_q_IFHPropTax','cmplx_Corporate_q_IFSTCGTax','cmplx_Corporate_q_IFLTCGITax','cmplx_Corporate_q_IFLTCGNITax','cmplx_Corporate_q_IFOSTax','cmplx_Corporate_q_IncTaxCurYear');
					calcCorporateTax();
                    return true;
                    break;
                }
                case 'cmplx_Corporate_q_TaxIncome':
                {						
                    posvalidate('cmplx_Corporate_q_TaxIncome');					
                    return true;
                    break;
                } 
                case 'cmplx_Corporate_q_IncTaxCurYear':
                {						
                    posvalidate('cmplx_Corporate_q_IncTaxCurYear');
                    maxValueCheck('cmplx_Corporate_q_TDSCreCurYear','cmplx_Corporate_q_IncTaxCurYear', 'TDS Credit For The Year cannot be greater than Income Tax For The Year');
                    return true;
                    break;
                } 
                case 'cmplx_Corporate_q_TDSCreCurYear':
                {						
                    negvalidate('cmplx_Corporate_q_TDSCreCurYear');
					maxValueCheck('cmplx_Corporate_q_TDSCreCurYear','cmplx_Corporate_q_IncTaxCurYear', 'TDS Credit For The Year cannot be greater than Income Tax For The Year');                    //For All the Quarter Calculations
					calcCorporateTax();
					
                    return true;
                    break;
                } 
                case 'cmplx_Corporate_q_NetTaxPay':
                {						
                    posvalidate('cmplx_Corporate_q_NetTaxPay');
                    return true;
                    break;
                } 
                case 'cmplx_Corporate2_q_AdvTaxPaid':
                {						
                    posvalidate('cmplx_Corporate2_q_AdvTaxPaid');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_TaxDueForQ':
                {						
                    posvalidate('cmplx_Corporate2_q_TaxDueForQ');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_AmtRecmByAuth':
                {						
                    posvalidate('cmplx_Corporate2_q_AmtRecmByAuth');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_TotalPayable':
                {						
                    posvalidate('cmplx_Corporate2_q_TotalPayable');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_NormalTax':
                {						
                    posvalidate('cmplx_Corporate2_q_NormalTax');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_DeferredTax':
                {						
                    //posvalidate('cmplx_Corporate2_q_DeferredTax');
                    //Q4 Payment Net Tax
                    subTot3('cmplx_Corporate2_q_NormalTax','cmplx_Corporate2_q_DeferredTax','cmplx_Corporate2_q_NetTax');
					setNGValue('cmplx_Corporate2_q_NTPQ4Add', getNGValue('cmplx_Corporate2_q_NetTax'));
					if(qFourAdd == "Q4 Additional" || qFourAdd == "Post Self Assessment"){
						subTot3('cmplx_Corporate2_q_NTPQ4Add','cmplx_Corporate2_q_ATPQ4Add','cmplx_Corporate2_q_BPIQ4Add');
					}
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_NetTax':
                {						
                    posvalidate('cmplx_Corporate2_q_NetTax');
                    return true;
                    break;
                }
                // field is not in use
                /*
				case 'cmplx_Corporate2_q_ForSelfAssmnt':
                {						
					posvalidate('cmplx_Corporate2_q_ForSelfAssmnt');
                    return true;
                    break;
                }
				*/
                case 'cmplx_Corporate2_q_NetTaxPayable':
                {						
                    posvalidate('cmplx_Corporate2_q_NetTaxPayable');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_BalPayOnSelfAssmnt':
                {						
                    posvalidate('cmplx_Corporate2_q_BalPayOnSelfAssmnt');
                    //Q4 Total Payable in Additional
								        //subTot5('cmplx_Corporate2_q_BalPayOnSelfAssmnt','cmplx_Corporate2_q_IPUS234A','cmplx_Corporate2_q_IPUS234B','cmplx_Corporate2_q_IPUS234C','cmplx_Corporate2_q_TotalPayable')
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_IPUS234A':
                {						
                    posvalidate('cmplx_Corporate2_q_IPUS234A');
                    //Q4 Total Payable in Additional
                    //subTot5('cmplx_Corporate2_q_BalPayOnSelfAssmnt','cmplx_Corporate2_q_IPUS234A','cmplx_Corporate2_q_IPUS234B','cmplx_Corporate2_q_IPUS234C','cmplx_Corporate2_q_TotalPayable')
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_IPUS234B':
                {						
                    posvalidate('cmplx_Corporate2_q_IPUS234B');
                    //Q4 Total Payable in Additional
                    //subTot5('cmplx_Corporate2_q_BalPayOnSelfAssmnt','cmplx_Corporate2_q_IPUS234A','cmplx_Corporate2_q_IPUS234B','cmplx_Corporate2_q_IPUS234C','cmplx_Corporate2_q_TotalPayable')
                    
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_IPUS234C':
                {						
                    //posvalidate('cmplx_Corporate2_q_IPUS234C');
                    //Q4 Total Payable in Additional
                    //subTot5('cmplx_Corporate2_q_BalPayOnSelfAssmnt','cmplx_Corporate2_q_IPUS234A','cmplx_Corporate2_q_IPUS234B','cmplx_Corporate2_q_IPUS234C','cmplx_Corporate2_q_TotalPayable')
                    
                    return true;
                    break;
                }
				
                case 'cmplx_Corporate2_q_AdvanceTaxPaid':
                {						
                    negvalidate('cmplx_Corporate2_q_AdvanceTaxPaid');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_NTPQ4Add':
                {						
                    posvalidate('cmplx_Corporate2_q_NTPQ4Add');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_BPIQ4Add':
                {						
                    posvalidate('cmplx_Corporate2_q_BPIQ4Add');
                    //SelfAssessment Net tax Pay
                    //subtractTot3('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_BPIQ4Add','cmplx_Corporate2_q_NetTaxPayable');
                    return true;
                    break;
                }		
                case 'cmplx_Corporate2_q_ATPQ4Add':
                {						
                    negvalidate('cmplx_Corporate2_q_ATPQ4Add');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinPerTBPQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MinPerTBPQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinCumTaxQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MinCumTaxQ1');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ1','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinBalPayQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinTFTQQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MinTFTQQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinTPFQQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MinTPFQQ1');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ1','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinBalPayQ1');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinTPFQQ1','cmplx_Corporate2_q_MinTFTQQ2');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinCumPayQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MinCumPayQ1');
                    subTot3('cmplx_Corporate2_q_MinTPFQQ2','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinCumPayQ2');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ1','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinBalPayQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinBalPayQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MinBalPayQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinPTBPQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MinPTBPQ2');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinCumTaxQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MinCumTaxQ2');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinBalPayQ2');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinTPFQQ1','cmplx_Corporate2_q_MinTFTQQ2');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinTFTQQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MinTFTQQ2');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinTPFQQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MinTPFQQ2');
                    subTot3('cmplx_Corporate2_q_MinTPFQQ2','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinCumPayQ2');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinBalPayQ2');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinTFTQQ3');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinCumPayQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MinCumPayQ2');
                    subTot3('cmplx_Corporate2_q_MinTPFQQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinCumPayQ3');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinBalPayQ2');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinTFTQQ3');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinBalPayQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MinBalPayQ2');
                    return true;
                    break;
                } 				
                case 'cmplx_Corporate2_q_MinPTBPQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MinPTBPQ3');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinCumTaxQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MinCumTaxQ3');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinBalPayQ3');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinTFTQQ3');
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinTFTQQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MinTFTQQ3');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinTPFQQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MinTPFQQ3');
                    subTot3('cmplx_Corporate2_q_MinTPFQQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinCumPayQ3');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinBalPayQ3');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinTFTQQ4');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinCumPayQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MinCumPayQ3');
                    subTot3('cmplx_Corporate2_q_MTPFQQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinCumPayQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinBalPayQ3');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinTFTQQ4');
                    return true;
                    break;
                } 
                case 'cmplx_Corporate2_q_MinBalPayQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MinBalPayQ3');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinPTBPQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MinPTBPQ4');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinCumTaxQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MinCumTaxQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ4','cmplx_Corporate2_q_MinBalPayQ4');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinTFTQQ4');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinTFTQQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MinTFTQQ4');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MTPFQQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MTPFQQ4');
                    subTot3('cmplx_Corporate2_q_MTPFQQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinCumPayQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ4','cmplx_Corporate2_q_MinBalPayQ4');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MinCumPayQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MinCumPayQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ4','cmplx_Corporate2_q_MinBalPayQ4');
                    return true;
                    break;
                } 
                case 'cmplx_Corporate2_q_MinBalPayQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MinBalPayQ4');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxPTBPQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxPTBPQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxCumTaxQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxCumTaxQ1');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ1','cmplx_Corporate2_q_MaxCumPayQ1','cmplx_Corporate2_q_MaxBalPayQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxTFTQQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxTFTQQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxTPFQQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxTPFQQ1');
                    setNGValue('cmplx_Corporate2_q_MinTPFQQ1', getNGValue('cmplx_Corporate2_q_MaxTPFQQ1'));
                    setNGValue('cmplx_Corporate2_q_MaxCumPayQ1', getNGValue('cmplx_Corporate2_q_MaxTPFQQ1'));
                    setNGValue('cmplx_Corporate2_q_MinCumPayQ1', getNGValue('cmplx_Corporate2_q_MaxTPFQQ1'));
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ1','cmplx_Corporate2_q_MaxCumPayQ1','cmplx_Corporate2_q_MaxBalPayQ1');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ2','cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTFTQQ2');
					if(period == "Quarter2"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ2'));
					}
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ1','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinBalPayQ1');
                    //Tax for the Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinTPFQQ1','cmplx_Corporate2_q_MinTFTQQ2');
					
					//Quarter2 Calculations
					
					subTot3('cmplx_Corporate2_q_MinTPFQQ2','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinCumPayQ2');
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinBalPayQ2');
                    //Tax for the Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinTFTQQ3');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ2','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxBalPayQ2');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxTFTQQ3');
					if(period == "Quarter3"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ3'));
                    }
                    subTot3('cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxCumPayQ1','cmplx_Corporate2_q_MaxCumPaytQ2');
					
					//Quarter3 Calculations
					subTot3('cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxCumPayQ3');                    
                    subTot3('cmplx_Corporate2_q_MinTPFQQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinCumPayQ3'); 
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinBalPayQ3');
                    //Tax for the Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinTFTQQ4');
					
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxBalPayQ3');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxTFTQQ4');
					if(period == "Quarter4"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ4'));
					}
					
					// Quarter4 Calculations
					subTot3('cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxCumPayQ4');
                    subTot3('cmplx_Corporate2_q_MTPFQQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinCumPayQ4');
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ4','cmplx_Corporate2_q_MinBalPayQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ4','cmplx_Corporate2_q_MaxBalPayQ4');
					
					if(qFourAdd == "Q4 Additional" || qFourAdd == "Post Self Assessment"){
						subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_ATPQ4Add');
						subTot3('cmplx_Corporate2_q_NTPQ4Add','cmplx_Corporate2_q_ATPQ4Add','cmplx_Corporate2_q_BPIQ4Add');
					}
					
					if(qFourAdd == "Post Self Assessment"){
						
						if(getNGValue('cmplx_Corporate2_q_BPIQ4Add') != ""){
							subTot6('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_BPIQ4Add','cmplx_Corporate2_q_AdvanceTaxPaid');
						}else{				
							subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4',		'cmplx_Corporate2_q_AdvanceTaxPaid');
						}
						subTot3('cmplx_Corporate2_q_NetTaxPayable','cmplx_Corporate2_q_AdvanceTaxPaid','cmplx_Corporate2_q_BalPayOnSelfAssmnt');
					}
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxCumPayQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxCumPayQ1');
                    subTot3('cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxCumPayQ1','cmplx_Corporate2_q_MaxCumPaytQ2');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ1','cmplx_Corporate2_q_MaxCumPayQ1','cmplx_Corporate2_q_MaxBalPayQ1');
					
                    return true;
                    break;
                } 
                case 'cmplx_Corporate2_q_MaxBalPayQ1':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxBalPayQ1');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxPTBPQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxPTBPQ2');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxCumTaxQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxCumTaxQ2');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ2','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxBalPayQ2');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ2','cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTFTQQ2');
					if(period == "Quarter2"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ2'));
					}
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxTFTQQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxTFTQQ2');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxTPFQQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxTPFQQ2');
                    setNGValue('cmplx_Corporate2_q_MinTPFQQ2', getNGValue('cmplx_Corporate2_q_MaxTPFQQ2'));                    
					//Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ2','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxBalPayQ2');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxTFTQQ3');
					if(period == "Quarter3"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ3'));
                    }
                    subTot3('cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxCumPayQ1','cmplx_Corporate2_q_MaxCumPaytQ2');
                    
					subTot3('cmplx_Corporate2_q_MinTPFQQ2','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinCumPayQ2');
					//Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinBalPayQ2');
                    //Tax for the Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinTFTQQ3');                    
					
					//Quarter3 Calculations
					subTot3('cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxCumPayQ3');                    
                    subTot3('cmplx_Corporate2_q_MinTPFQQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinCumPayQ3'); 
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinBalPayQ3');
                    //Tax for the Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinTFTQQ4');
					
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxBalPayQ3');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxTFTQQ4');
					if(period == "Quarter4"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ4'));
					}
					
					// Quarter4 Calculations
					subTot3('cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxCumPayQ4');
                    subTot3('cmplx_Corporate2_q_MTPFQQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinCumPayQ4');
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ4','cmplx_Corporate2_q_MinBalPayQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ4','cmplx_Corporate2_q_MaxBalPayQ4');
				
					if(qFourAdd == "Q4 Additional" || qFourAdd == "Post Self Assessment"){
						subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_ATPQ4Add');
						subTot3('cmplx_Corporate2_q_NTPQ4Add','cmplx_Corporate2_q_ATPQ4Add','cmplx_Corporate2_q_BPIQ4Add');
					}
					
					if(qFourAdd == "Post Self Assessment"){
						
						if(getNGValue('cmplx_Corporate2_q_BPIQ4Add') != ""){
							subTot6('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_BPIQ4Add','cmplx_Corporate2_q_AdvanceTaxPaid');
						}else{				
							subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4',		'cmplx_Corporate2_q_AdvanceTaxPaid');
						}
						subTot3('cmplx_Corporate2_q_NetTaxPayable','cmplx_Corporate2_q_AdvanceTaxPaid','cmplx_Corporate2_q_BalPayOnSelfAssmnt');
					}
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxCumPaytQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxCumPaytQ2');
                    subTot3('cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxCumPayQ3');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ2','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxBalPayQ2');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxTFTQQ3');
					if(period == "Quarter3"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ3'));
                    }
                    
					return true;
                    break;
                } 
                case 'cmplx_Corporate2_q_MaxBalPayQ2':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxBalPayQ2');
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxPTBPQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxPTBPQ3');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxCumTaxQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxCumTaxQ3');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxBalPayQ3');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxTFTQQ3');
					if(period == "Quarter3"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ3'));
                    }
					return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxTFTQQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxTFTQQ3');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxTPFQQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxTPFQQ3');
					setNGValue('cmplx_Corporate2_q_MinTPFQQ3', getNGValue('cmplx_Corporate2_q_MaxTPFQQ3'));
					
                    subTot3('cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxCumPayQ3');                    
                    subTot3('cmplx_Corporate2_q_MinTPFQQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinCumPayQ3'); 
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinBalPayQ3');
                    //Tax for the Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinTFTQQ4');
					
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxBalPayQ3');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxTFTQQ4');
					if(period == "Quarter4"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ4'));
					}
					
					// Quarter4 Calculations
					subTot3('cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxCumPayQ4');
                    subTot3('cmplx_Corporate2_q_MTPFQQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinCumPayQ4');
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ4','cmplx_Corporate2_q_MinBalPayQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ4','cmplx_Corporate2_q_MaxBalPayQ4');
					
					if(qFourAdd == "Q4 Additional" || qFourAdd == "Post Self Assessment"){
						subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_ATPQ4Add');
						subTot3('cmplx_Corporate2_q_NTPQ4Add','cmplx_Corporate2_q_ATPQ4Add','cmplx_Corporate2_q_BPIQ4Add');
					}
					
					if(qFourAdd == "Post Self Assessment"){
						
						if(getNGValue('cmplx_Corporate2_q_BPIQ4Add') != ""){
							subTot6('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_BPIQ4Add','cmplx_Corporate2_q_AdvanceTaxPaid');
						}else{				
							subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4',		'cmplx_Corporate2_q_AdvanceTaxPaid');
						}
						subTot3('cmplx_Corporate2_q_NetTaxPayable','cmplx_Corporate2_q_AdvanceTaxPaid','cmplx_Corporate2_q_BalPayOnSelfAssmnt');
					}
					
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxCumPayQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxCumPayQ3');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxBalPayQ3');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxTFTQQ4');
					if(period == "Quarter4"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ4'));
					}
                    return true;
                    break;
                } 
                case 'cmplx_Corporate2_q_MaxBalPayQ3':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxBalPayQ3');
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxPTBPQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxPTBPQ4');
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxCumTaxQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxCumTaxQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ4','cmplx_Corporate2_q_MaxBalPayQ4');
                    //Tax for the Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxTFTQQ4');
					if(period == "Quarter4"){
						setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ4'));
					}
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxTFTQQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxTFTQQ4');
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxTPFQQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxTPFQQ4');
                    setNGValue('cmplx_Corporate2_q_MTPFQQ4', getNGValue('cmplx_Corporate2_q_MaxTPFQQ4'));
					if(period == "Quarter4"){
						setNGValue('cmplx_Corporate2_q_TotalPayable', getNGValue('cmplx_Corporate2_q_MaxTPFQQ4'));
					}
                    subTot3('cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxCumPayQ4');
                    subTot3('cmplx_Corporate2_q_MTPFQQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinCumPayQ4');
                    //Balance Payable for Quarter Minimum
                    subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ4','cmplx_Corporate2_q_MinBalPayQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ4','cmplx_Corporate2_q_MaxBalPayQ4');
					
					if(qFourAdd == "Q4 Additional" || qFourAdd == "Post Self Assessment"){
						subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_ATPQ4Add');
						subTot3('cmplx_Corporate2_q_NTPQ4Add','cmplx_Corporate2_q_ATPQ4Add','cmplx_Corporate2_q_BPIQ4Add');
					}
					
					if(qFourAdd == "Post Self Assessment"){
						
						if(getNGValue('cmplx_Corporate2_q_BPIQ4Add') != ""){
							subTot6('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_BPIQ4Add','cmplx_Corporate2_q_AdvanceTaxPaid');
						}else{				
							subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4',		'cmplx_Corporate2_q_AdvanceTaxPaid');
						}
						subTot3('cmplx_Corporate2_q_NetTaxPayable','cmplx_Corporate2_q_AdvanceTaxPaid','cmplx_Corporate2_q_BalPayOnSelfAssmnt');
					}
					
                    return true;
                    break;
                }
                case 'cmplx_Corporate2_q_MaxCumPayQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxCumPayQ4');
                    //Balance Payable for Quarter
                    subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ4','cmplx_Corporate2_q_MaxBalPayQ4');
                    return true;
                    break;
                } 
                case 'cmplx_Corporate2_q_MaxBalPayQ4':
                {						
                    posvalidate('cmplx_Corporate2_q_MaxBalPayQ4');
                    return true;
                    break;
                }
				 case 'cmplx_NR_RFA_q_BalDue1':
                {						
                    posvalidate('cmplx_NR_RFA_q_BalDue1');
					 dueBalCheck('cmplx_NR_RFA_q_BalDue1','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1','cmplx_NR_RFA_q_PartPayMode11');

					return true;
                    break;
                } 
				
				 case 'cmplx_NR_RFA_q_Penalty1':
                {						
                    posvalidate('cmplx_NR_RFA_q_Penalty1');					
					var boolVal = partPayMadeCheck('cmplx_NR_RFA_q_PartPayMode11','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1');
					if(boolVal != true){					
						setNullFocus('cmplx_NR_RFA_q_Penalty1');						
					}
					dueBalCheck('cmplx_NR_RFA_q_BalDue1','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1','cmplx_NR_RFA_q_PartPayMode11');

					maxValueCheck('cmplx_NR_RFA_q_PenaltyPaid1','cmplx_NR_RFA_q_Penalty1', 'Penalty to be paid cannot be greater than Penalty');
                    return true;
                    break;
                } 			 

				 case 'cmplx_NR_RFA_q_Interest1':
                {						
                    posvalidate('cmplx_NR_RFA_q_Interest1');					
					var boolVal = partPayMadeCheck('cmplx_NR_RFA_q_PartPayMode11','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1');
					if(boolVal != true){					
						setNullFocus('cmplx_NR_RFA_q_Interest1');					
					}
					 dueBalCheck('cmplx_NR_RFA_q_BalDue1','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1','cmplx_NR_RFA_q_PartPayMode11');

					maxValueCheck('cmplx_NR_RFA_q_InterestPaid1','cmplx_NR_RFA_q_Interest1', 'Interest to be paid cannot be greater than Interest');
					
                    return true;
                    break;
                }
				 case 'cmplx_NR_RFA_q_Principle1':
                {						
                    posvalidate('cmplx_NR_RFA_q_Principle1');					
					var boolVal = partPayMadeCheck('cmplx_NR_RFA_q_PartPayMode11','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1');
					if(boolVal != true){					
						setNullFocus('cmplx_NR_RFA_q_Principle1');						
					}
					dueBalCheck('cmplx_NR_RFA_q_BalDue1','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1','cmplx_NR_RFA_q_PartPayMode11');

                    return true;
                    break;
                }				 					 
				case 'cmplx_NR_RFA_q_PartPayMode11':
                {						
                    posvalidate('cmplx_NR_RFA_q_PartPayMode1');									
					var boolVal = partPayMadeCheck('cmplx_NR_RFA_q_PartPayMode11','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1');
					if(boolVal != true){					
						setNullFocus('cmplx_NR_RFA_q_PartPayMode11');						
					}
					dueBalCheck('cmplx_NR_RFA_q_BalDue1','cmplx_NR_RFA_q_Principle1','cmplx_NR_RFA_q_Interest1','cmplx_NR_RFA_q_Penalty1','cmplx_NR_RFA_q_PartPayMode11');

                    return true;
                    break;
                } 	
				case 'cmplx_NR_RFA_CasePeriodFrm1':
                {						
					//Check for future date 
					futuredateCheck('cmplx_NR_RFA_CasePeriodFrm1');
					//Check From date should be less than To date 
					datecompare("cmplx_NR_RFA_CasePeriodFrm1","cmplx_NR_RFA_CasePeriodTo1",'Case Period From date cannot be greater than Case Period To date');
					datecompare("cmplx_NR_RFA_CasePeriodFrm1","cmplx_NR_RFA_PeriodAppvlFrm1",'Period Approval From date cannot be less than Case Period From date');
                    return true;
                    break;
                } 	
				case 'cmplx_NR_RFA_CasePeriodTo1':
                {						
					//Check for future date 
					futuredateCheck('cmplx_NR_RFA_CasePeriodTo1');
					//Check From date should be less than To date 
					datecompare("cmplx_NR_RFA_CasePeriodFrm1","cmplx_NR_RFA_CasePeriodTo1",'Case Period From date cannot be greater than Case Period To date');
					datecompare("cmplx_NR_RFA_PeriodAppvlTo1","cmplx_NR_RFA_CasePeriodTo1",'Period Approval From date cannot be greater than Case Period To date');
                    
                    return true;
                    break;
                } 				
				
				case 'cmplx_NR_RFA_q_AprvlReqByDate1':
                {						
					//Check for future date 
					pastdateCheck('cmplx_NR_RFA_q_AprvlReqByDate1');
					
                    return true;
                    break;
                } 
				
				case 'cmplx_NR_RFA_q_AprvlReqByDate2':
                {						
					//Check for future date 
					pastdateCheck('cmplx_NR_RFA_q_AprvlReqByDate2');
					
                    return true;
                    break;
                } 
				
				
				case 'cmplx_NR_RFA_CasePeriodFom2':
                {						
					//Check for future date 
					futuredateCheck('cmplx_NR_RFA_CasePeriodFom2');
					//Check From date should be less than To date 
					datecompare("cmplx_NR_RFA_CasePeriodFom2","cmplx_NR_RFA_CasePeriodTo2",'Case Period From date cannot be greater than Case Period To date');
					datecompare("cmplx_NR_RFA_CasePeriodFom2","cmplx_NR_RFA_PeriodAppvalFrom2",'Period Approval From date cannot be less than Case Period From date');
                    return true;
                    break;
                } 	
				case 'cmplx_NR_RFA_CasePeriodTo2':
                {						
					//Check for future date 
					futuredateCheck('cmplx_NR_RFA_CasePeriodTo2');
					//Check From date should be less than To date 
					datecompare("cmplx_NR_RFA_CasePeriodFom2","cmplx_NR_RFA_CasePeriodTo2",'Case Period From date cannot be greater than Case Period To date');
					datecompare("cmplx_NR_RFA_PeriodAppvalTo2","cmplx_NR_RFA_CasePeriodTo2",'Period Approval To date cannot be greater than Case Period To date');
                    return true;
                    break;
                } 	
				
				case 'cmplx_NR_RFA_q_Penalty2':
                {						
                    posvalidate('cmplx_NR_RFA_q_Penalty2');
					var boolVal = partPayMadeCheck('cmplx_NR_RFA_q_PartPaymMode22','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2');
					if(boolVal != true){					
						setNullFocus('cmplx_NR_RFA_q_Interest2');							
					}
					dueBalCheck('cmplx_NR_RFA_q_BalDue2','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2','cmplx_NR_RFA_q_PartPaymMode22');
					/*
					var boolBal = dueBalCheck('cmplx_NR_RFA_q_BalDue2','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2','cmplx_NR_RFA_q_PartPaymMode22');
                    if(boolBal != true){					
						setNullFocus('cmplx_NR_RFA_q_Interest2');						
					}
					*/
					maxValueCheck('cmplx_NR_RFA_q_PenaltyPaid2','cmplx_NR_RFA_q_Penalty2', 'Penalty to be paid cannot be greater than Penalty');
                    return true;
                    break;
                } 
				
				 case 'cmplx_NR_RFA_q_Interest2':
                {						
                    posvalidate('cmplx_NR_RFA_q_Interest2');					
					var boolVal = partPayMadeCheck('cmplx_NR_RFA_q_PartPaymMode22','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2');
					if(boolVal != true){					
						setNullFocus('cmplx_NR_RFA_q_Interest2');					
					}
					dueBalCheck('cmplx_NR_RFA_q_BalDue2','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2','cmplx_NR_RFA_q_PartPaymMode22');

					maxValueCheck('cmplx_NR_RFA_q_InterestPaid2','cmplx_NR_RFA_q_Interest2', 'Interest to be paid cannot be greater than Interest');
                    return true;
                    break;
                }
				 case 'cmplx_NR_RFA_q_Principle2':
                {		
					posvalidate('cmplx_NR_RFA_q_Principle2');
					var boolVal = partPayMadeCheck('cmplx_NR_RFA_q_PartPaymMode22','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2');
					if(boolVal != true){					
						setNullFocus('cmplx_NR_RFA_q_Principle2');							
					}
					dueBalCheck('cmplx_NR_RFA_q_BalDue2','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2','cmplx_NR_RFA_q_PartPaymMode22');

					return true;
                    break;
                }
				 case 'cmplx_NR_RFA_q_PartPaymMode22':
                {						
					posvalidate('cmplx_NR_RFA_q_PartPaymMode22');
					var boolVal = partPayMadeCheck('cmplx_NR_RFA_q_PartPaymMode22','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2');
					if(boolVal != true){					
						setNullFocus('cmplx_NR_RFA_q_PartPaymMode22');					
					}
					dueBalCheck('cmplx_NR_RFA_q_BalDue2','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2','cmplx_NR_RFA_q_PartPaymMode22');

                    return true;
                    break;
                }
				 case 'cmplx_NR_RFA_q_BalDue2':
                {		
					posvalidate('cmplx_NR_RFA_q_BalDue2');
					dueBalCheck('cmplx_NR_RFA_q_BalDue2','cmplx_NR_RFA_q_Principle2','cmplx_NR_RFA_q_Interest2','cmplx_NR_RFA_q_Penalty2','cmplx_NR_RFA_q_PartPaymMode22');

                    return true;
                    break;
                }
				case 'cmplx_AddRFA_q_AmtAdjPerInstall':
                {						
					//AdditionalValidate('cmplx_AddRFA_q_AmtAdjPerInstall','cmplx_AddRFA_q_NoOfInstlmnt','cmplx_AddRFA_q_ReqAmount','Requested amount should not be less');
                    return true;
                    break;
                } 
				case 'cmplx_AddRFA_q_NoOfInstlmnt':
                {	
					//Check for positive number
					posvalidate('cmplx_AddRFA_q_NoOfInstlmnt');
					//Check for Integer Type
					isInt('cmplx_AddRFA_q_NoOfInstlmnt');
					//Check for max Installment
					if(getNGValue('cmplx_AddRFA_q_NoOfInstlmnt')>20){
						setNGValue('cmplx_AddRFA_q_NoOfInstlmnt',"" );
						setNGFocus('cmplx_AddRFA_q_NoOfInstlmnt');
						alert('Number of Installment Carry Forward cannot be greater than 20');
					}
					//Set Amount to be adjusted per installment
					if(getNGValue('cmplx_AddRFA_q_ReqAmount')!="" && getNGValue('cmplx_AddRFA_q_NoOfInstlmnt')!=""){
						var adjAmt= ((parseFloat(getNGValue("cmplx_AddRFA_q_ReqAmount")))/(parseFloat(getNGValue("cmplx_AddRFA_q_NoOfInstlmnt")))); 
						setNGValue('cmplx_AddRFA_q_AmtAdjPerInstall', adjAmt.toFixed(2));
					}else{
						setNGValue('cmplx_AddRFA_q_AmtAdjPerInstall', "");
					}
	
					//AdditionalValidate('cmplx_AddRFA_q_AmtAdjPerInstall','cmplx_AddRFA_q_NoOfInstlmnt','cmplx_AddRFA_q_ReqAmount','Requested amount should not be less');
                    return true;
                    break;
                } 
				case 'cmplx_AddRFA_q_ReqAmount':
                {	
					posvalidate('cmplx_AddRFA_q_ReqAmount');
					//Set Amount to be adjusted per installment		
					if(getNGValue('cmplx_AddRFA_q_ReqAmount')!="" && getNGValue('cmplx_AddRFA_q_NoOfInstlmnt')!=""){					
						var adjAmt= ((parseFloat(getNGValue("cmplx_AddRFA_q_ReqAmount")))/(parseFloat(getNGValue("cmplx_AddRFA_q_NoOfInstlmnt")))); 
						setNGValue('cmplx_AddRFA_q_AmtAdjPerInstall', adjAmt.toFixed(2));
					}else{
						setNGValue('cmplx_AddRFA_q_AmtAdjPerInstall', "");
					}
					//AdditionalValidate('cmplx_AddRFA_q_AmtAdjPerInstall','cmplx_AddRFA_q_NoOfInstlmnt','cmplx_AddRFA_q_ReqAmount','Requested amount should not be less');
                    return true;
                    break;
                } 
				case 'cmplx_AddRFA1_q_AmtAdjPerInstall':
                {						
                    return true;
                    break;
                } 
				case 'cmplx_AddRFA1_q_NoOfInstlmnt':
                {						
					//Check for positive number
					posvalidate('cmplx_AddRFA1_q_NoOfInstlmnt');
					//Check for Integer Type
					isInt('cmplx_AddRFA1_q_NoOfInstlmnt');
					//Check for max Installment
					if(getNGValue('cmplx_AddRFA1_q_NoOfInstlmnt')>20){
						setNGValue('cmplx_AddRFA1_q_NoOfInstlmnt',"" );
						setNGFocus('cmplx_AddRFA1_q_NoOfInstlmnt');
						alert('Number of Installment Carry Forward cannot be greater than 20');
					}
					//Set Amount to be adjusted per installment
					if(getNGValue('cmplx_AddRFA1_q_ReqAmount')!="" && getNGValue('cmplx_AddRFA1_q_NoOfInstlmnt')!=""){
						var adjAmt= ((parseFloat(getNGValue("cmplx_AddRFA1_q_ReqAmount")))/(parseFloat(getNGValue("cmplx_AddRFA1_q_NoOfInstlmnt"))));
						setNGValue('cmplx_AddRFA1_q_AmtAdjPerInstall',adjAmt.toFixed(2) );
					}else{
						setNGValue('cmplx_AddRFA1_q_AmtAdjPerInstall',"");
					}
					//AdditionalValidate('cmplx_AddRFA1_q_AmtAdjPerInstall','cmplx_AddRFA1_q_NoOfInstlmnt','cmplx_AddRFA1_q_ReqAmount','Requested amount should not be less');
                    return true;
                    break;
                } 
				case 'cmplx_AddRFA1_q_ReqAmount':
                {	
					posvalidate('cmplx_AddRFA1_q_ReqAmount');
					if(getNGValue('cmplx_AddRFA1_q_ReqAmount')!="" && getNGValue('cmplx_AddRFA1_q_NoOfInstlmnt')!=""){
						var adjAmt= ((parseFloat(getNGValue("cmplx_AddRFA1_q_ReqAmount")))/(parseFloat(getNGValue("cmplx_AddRFA1_q_NoOfInstlmnt"))));
						setNGValue('cmplx_AddRFA1_q_AmtAdjPerInstall',adjAmt.toFixed(2) );
					}else{
						setNGValue('cmplx_AddRFA1_q_AmtAdjPerInstall',"");
					}
					//AdditionalValidate('cmplx_AddRFA1_q_AmtAdjPerInstall','cmplx_AddRFA1_q_NoOfInstlmnt','cmplx_AddRFA1_q_ReqAmount','Requested amount should not be less');
                    return true;
                    break;
                }
				case 'cmplx_NR_RFA_q_CaseNo1':
                {						
					if(getNGValue("IncludesCST")=='Yes' || getNGValue("IncludesTCS")=='Yes' || legislationType == 'Service Tax'){
						CaseNoCheck();
					}
                    return true;
                    break;
                }
				case 'cmplx_NR_RFA_q_CaseNo2':
                {						
					if(getNGValue("IncludesCST")=='Yes' || getNGValue("IncludesTCS")=='Yes' || legislationType == 'Service Tax'){
						CaseNoCheck();
					}
                    return true;
                    break;
                } 
				case 'ChallanUpload_ChallanDate':
                {						
					//Check for future date 
					futuredateCheck('ChallanUpload_ChallanDate');
                    return true;
                    break;
                }
				case 'cmplx_ReturnsUpload_q_RetFiledDate':
                {						
					//Check for future date 
					futuredateCheck('cmplx_ReturnsUpload_q_RetFiledDate');
                    return true;
                    break;
                }
				case 'cmplx_ReturnsUpload_q_RetFiledDate2':
                {						
					//Check for future date 
					futuredateCheck('cmplx_ReturnsUpload_q_RetFiledDate2');
                    return true;
                    break;
                }
				case 'cmplx_ReturnsUpload_q_RetFiledAmt':
                {						
					posvalidate('cmplx_ReturnsUpload_q_RetFiledAmt');
                    subtractTot3('cmplx_ReturnsUpload_q_RetFiledAmt','cmplx_ReturnsUpload_q_ChalnTotAmt','cmplx_ReturnsUpload_q_DiffrncAmt');
                    return true;
                    break;
                }
				case 'cmplx_ReturnsUpload_q_ChalnTotAmt':
                {						
					
                    return true;
                    break;
                }
				case 'cmplx_ReturnsUpload_q_RetFiledAmt2':
                {						
					posvalidate('cmplx_ReturnsUpload_q_RetFiledAmt2');
                    subtractTot3('cmplx_ReturnsUpload_q_RetFiledAmt2','cmplx_ReturnsUpload_q_ChalnTotAmt2','cmplx_ReturnsUpload_q_DiffrncAmt2');
                    return true;
                    break;
                }
				case 'cmplx_ReturnsUpload_q_ChalnTotAmt2':
                {						
					
                    return true;
                    break;
                }
            }
        }   
        case 'blur':
        {
            switch (pEvent.srcElement.id) 

            {
                
            }
        }
        case 'focus':
        {
            
          
            switch (pEvent.srcElement.id) 
            {
                
            }
        }
    }
}

function setNGFocus(Value)
{
    com.newgen.omniforms.formviewer.setNGFocus(Value);

}
function getNGValue(Value)
{
    return com.newgen.omniforms.formviewer.getNGValue(Value);
}
function setNGValue(control, value)
{
    com.newgen.omniforms.formviewer.setNGValue(control, value);
}

function setNullFocus(controlName) { 
	setNGValue(controlName,"");
    setNGFocus(controlName);
}

function getTop(Control)
{
    com.newgen.omniforms.formviewer.getTop(Control);
}
function setTop(Control, Value)
{
    com.newgen.omniforms.formviewer.setTop(Control, Value);
}
function setNGListIndex(control, i)
{
    com.newgen.omniforms.formviewer.setNGListIndex(control, i);
}
function NGClearSelection(control)
{
    com.newgen.omniforms.formviewer.NGAddDefaultItem(control);
}
function clear(control)
{
    com.newgen.omniforms.formviewer.clear(control);
}
function setHeight(control,i)
{
    com.newgen.omniforms.formviewer.setHeight(control,i);
}
function showError(control, value)
{
    com.newgen.omniforms.util.showError(control, value);
}
function mandateCheck(controlName, messageString)
{
    if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--')
    {
        showError('controlName','Please Enter the ' + messageString);               
        com.newgen.omniforms.formviewer.setNGValue(controlName,"");
		com.newgen.omniforms.formviewer.setNGFocus(controlName);
		com.newgen.omniforms.formviewer.setNGBackColor(controlName,"#E0E2B7"); 
        return false;
    }
    return true;

}
function subTot4(control1,control2,control3,totControl)
{	
    //Function to do total of three input values
    if(getNGValue(control1)!="" && getNGValue(control2)!="" && getNGValue(control3)!=""){
        var subTot4 = ((parseFloat(com.newgen.omniforms.formviewer.getNGValue(control1))) + (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control2))) + (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control3))));	
        com.newgen.omniforms.formviewer.setNGValue(totControl,subTot4);	
    }else{
        com.newgen.omniforms.formviewer.setNGValue(totControl,"");
    }				
		
}

function subTot3(control1,control2,totControl)
{	
    //Function to do total of two input values
    if(getNGValue(control1)!="" && getNGValue(control2)!=""){
        var subTot3 = ((parseFloat(com.newgen.omniforms.formviewer.getNGValue(control1))) + (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control2))));	
        com.newgen.omniforms.formviewer.setNGValue(totControl,subTot3.toFixed());
    }else{
        com.newgen.omniforms.formviewer.setNGValue(totControl,"");
    }		
		
} 

function subTot5(control1,control2,control3,control4,totControl)
{	
    //Function to do total of four input values
    if(getNGValue(control1)!="" && getNGValue(control2)!="" && getNGValue(control3)!="" && getNGValue(control4)!=""){
        var subTot5 = ((parseFloat(getNGValue(control1))) + (parseFloat(getNGValue(control2))) + (parseFloat(getNGValue(control3))) + (parseFloat(getNGValue(control4))));	
        com.newgen.omniforms.formviewer.setNGValue(totControl,subTot5.toFixed());
    }else{
        com.newgen.omniforms.formviewer.setNGValue(totControl,"");
    }		
		
} 

function subTot6(control1,control2,control3,control4,control5,totControl)
{	
    //Function to do total of five input values
    if(getNGValue(control1)!="" && getNGValue(control2)!="" && getNGValue(control3)!="" && getNGValue(control4)!="" && getNGValue(control5)!=""){
        var subTot6 = ((parseFloat(getNGValue(control1))) + (parseFloat(getNGValue(control2))) + (parseFloat(getNGValue(control3))) + (parseFloat(getNGValue(control4))) + (parseFloat(getNGValue(control5))));	
        com.newgen.omniforms.formviewer.setNGValue(totControl,subTot6.toFixed());
    }else{
        com.newgen.omniforms.formviewer.setNGValue(totControl,"");
    }		
		
}

function subtractTot3(control1,control2,totControl)
{	
    //Function to do subtract of two input values
    if(getNGValue(control1)!="" && getNGValue(control2)!=""){
        var subtct = ((parseFloat(com.newgen.omniforms.formviewer.getNGValue(control1))) - (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control2))));
        com.newgen.omniforms.formviewer.setNGValue(totControl,subtct.toFixed());
    }else{
        com.newgen.omniforms.formviewer.setNGValue(totControl,"");
    }	
		
}

function subTot7(control1,control2,control3,control4,control5,control6,totControl)
{	
    //Function to do total of three input values
    if(getNGValue(control1) !="" && getNGValue(control2) !="" && getNGValue(control3) !="" && getNGValue(control3) !="" && getNGValue(control4) !="" && getNGValue(control5) !="" && getNGValue(control6) !="" ){
        var subTot7 = ((parseFloat(com.newgen.omniforms.formviewer.getNGValue(control1))) + (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control2))) + (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control3))) + (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control4))) + (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control5))) + (parseFloat(com.newgen.omniforms.formviewer.getNGValue(control6))) );
        com.newgen.omniforms.formviewer.setNGValue(totControl,subTot7.toFixed());			
    }else{
        com.newgen.omniforms.formviewer.setNGValue(totControl,"");	
    }	
} 



function TaxCalc(control1,control2,totControl)
{	
    //Function to do total of Tax
    if(getNGValue(control1)!="" && getNGValue(control2)!=""){
        //var TaxCalc = ((parseFloat(getNGValue(control1))*parseFloat(getNGValue(control2)))/100);
		var TaxCalc = Math.round((parseFloat(getNGValue(control1)) * parseFloat(getNGValue(control2)))/100);
        setNGValue(totControl,TaxCalc.toFixed());	
    }else {
        com.newgen.omniforms.formviewer.setNGValue(totControl,"");
    }
} 

function calcCorporateTax()	
{
	var period1 = getNGValue('Period');
	var qFourAdd= getNGValue('CTAddQ4Pay');
	
	if(getNGValue('cmplx_Corporate_q_IncTaxCurYear') != "" && getNGValue('cmplx_Corporate_q_TDSCreCurYear') != ""){
		var nettaxpay = ((parseFloat(getNGValue('cmplx_Corporate_q_IncTaxCurYear')))+(parseFloat(getNGValue('cmplx_Corporate_q_TDSCreCurYear'))));
		setNGValue('cmplx_Corporate_q_NetTaxPay',nettaxpay.toFixed());	
	}    
	
	if(getNGValue('cmplx_Corporate_q_NetTaxPay') != ""){
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MaxPTBPQ1','cmplx_Corporate2_q_MaxCumTaxQ1');
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MaxPTBPQ1','cmplx_Corporate2_q_MaxTFTQQ1');
		if(period1 == "Quarter1"){			
			setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ1'));
		}
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MaxPTBPQ2','cmplx_Corporate2_q_MaxCumTaxQ2');
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MaxPTBPQ3','cmplx_Corporate2_q_MaxCumTaxQ3');
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MaxPTBPQ4','cmplx_Corporate2_q_MaxCumTaxQ4');
		if(period == "Quarter4" || qFourAdd == "Q4 Additional" || qFourAdd == "Post Self Assessment"){
			setNGValue('cmplx_Corporate2_q_NormalTax', getNGValue('cmplx_Corporate2_q_MaxCumTaxQ4'));
			subTot3('cmplx_Corporate2_q_NormalTax','cmplx_Corporate2_q_DeferredTax','cmplx_Corporate2_q_NetTax');
			setNGValue('cmplx_Corporate2_q_NTPQ4Add', getNGValue('cmplx_Corporate2_q_NetTax'));
			
			if(qFourAdd == "Q4 Additional" || qFourAdd == "Post Self Assessment"){
				subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_ATPQ4Add');
				subTot3('cmplx_Corporate2_q_NTPQ4Add','cmplx_Corporate2_q_ATPQ4Add','cmplx_Corporate2_q_BPIQ4Add');
			}
			if(qFourAdd == "Post Self Assessment"){
				setNGValue('cmplx_Corporate2_q_NetTaxPayable', getNGValue('cmplx_Corporate2_q_MaxCumTaxQ4'));
				if(getNGValue('cmplx_Corporate2_q_BPIQ4Add') != ""){
					subTot6('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_BPIQ4Add','cmplx_Corporate2_q_AdvanceTaxPaid');
				}else{				
					subTot5('cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTPFQQ2','cmplx_Corporate2_q_MaxTPFQQ3','cmplx_Corporate2_q_MaxTPFQQ4','cmplx_Corporate2_q_AdvanceTaxPaid');
				}
				subTot3('cmplx_Corporate2_q_NetTaxPayable','cmplx_Corporate2_q_AdvanceTaxPaid','cmplx_Corporate2_q_BalPayOnSelfAssmnt');
			}
		}
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MinPerTBPQ1','cmplx_Corporate2_q_MinCumTaxQ1');
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MinPerTBPQ1','cmplx_Corporate2_q_MinTFTQQ1');
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MinPTBPQ2','cmplx_Corporate2_q_MinCumTaxQ2');
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MinPTBPQ3','cmplx_Corporate2_q_MinCumTaxQ3');
		TaxCalc('cmplx_Corporate_q_NetTaxPay','cmplx_Corporate2_q_MinPTBPQ4','cmplx_Corporate2_q_MinCumTaxQ4');
		//Tax for the Quarter
		subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinTPFQQ1','cmplx_Corporate2_q_MinTFTQQ2');
		subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinTFTQQ3');
		subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinTFTQQ4');

		subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ2','cmplx_Corporate2_q_MaxTPFQQ1','cmplx_Corporate2_q_MaxTFTQQ2');
		if(period1 == "Quarter2"){
			setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ2'));
		}
		subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxTFTQQ3');
		if(period1 == "Quarter3"){
			setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ3'));
        }
		subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxTFTQQ4');
		if(period1 == "Quarter4"){
			setNGValue('cmplx_Corporate2_q_TaxDueForQ', getNGValue('cmplx_Corporate2_q_MaxTFTQQ4'));
		}

		//Balance Payable for Quarter
		subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ4','cmplx_Corporate2_q_MaxCumPayQ4','cmplx_Corporate2_q_MaxBalPayQ4');
		subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ3','cmplx_Corporate2_q_MaxCumPayQ3','cmplx_Corporate2_q_MaxBalPayQ3');
		subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ2','cmplx_Corporate2_q_MaxCumPaytQ2','cmplx_Corporate2_q_MaxBalPayQ2');
		subtractTot3('cmplx_Corporate2_q_MaxCumTaxQ1','cmplx_Corporate2_q_MaxCumPayQ1','cmplx_Corporate2_q_MaxBalPayQ1');

		subtractTot3('cmplx_Corporate2_q_MinCumTaxQ4','cmplx_Corporate2_q_MinCumPayQ4','cmplx_Corporate2_q_MinBalPayQ4');
		subtractTot3('cmplx_Corporate2_q_MinCumTaxQ3','cmplx_Corporate2_q_MinCumPayQ3','cmplx_Corporate2_q_MinBalPayQ3');
		subtractTot3('cmplx_Corporate2_q_MinCumTaxQ2','cmplx_Corporate2_q_MinCumPayQ2','cmplx_Corporate2_q_MinBalPayQ2');
		subtractTot3('cmplx_Corporate2_q_MinCumTaxQ1','cmplx_Corporate2_q_MinCumPayQ1','cmplx_Corporate2_q_MinBalPayQ1');
	}	
}


function netCreditAvail(control1,control2,control3,totControl)
{	
    //Function to do total of three input values
    if(getNGValue(control1)!="" && getNGValue(control2)!="" && getNGValue(control3)!=""){
        var netCrAvail = ((parseFloat(getNGValue(control1))) + (parseFloat(getNGValue(control2))) - (parseFloat(getNGValue(control3))));	
        com.newgen.omniforms.formviewer.setNGValue(totControl,netCrAvail);
		
		var requestTypeED = getNGValue('TypeOfRequest');

		if(requestTypeED == 'SupplementaryRFA'){
			if(getNGValue('cmplx_Excise_q_PLAPayable')!="" && getNGValue('cmplx_Excise_q_PLAApprvdRRFA')!=""){
				var valApprvl = ((parseFloat(getNGValue('cmplx_Excise_q_PLAPayable'))) - (parseFloat(getNGValue('cmplx_Excise_q_PLAApprvdRRFA'))))
				setNGValue('cmplx_Excise_q_ApprovalOf',valApprvl);
			}
		}
		
		
			
    }else{
        com.newgen.omniforms.formviewer.setNGValue(totControl,"");
    }			
		
}

function maxCheckExcise()
{	
    //Function to do total of three input values
     if(getNGValue('cmplx_Excise_q_ExcPayble')!="" && getNGValue('cmplx_Excise_q_PCCIUsage')!="" && getNGValue('cmplx_Excise_q_PCCCapGUsage')!="" && getNGValue('cmplx_Excise_q_PCCISUsage')!="" && getNGValue('cmplx_Excise_q_POthersReavCr')!=""){
        
		if((parseFloat(getNGValue('cmplx_Excise_q_PCCIUsage'))+parseFloat(getNGValue('cmplx_Excise_q_PCCCapGUsage'))+parseFloat(getNGValue('cmplx_Excise_q_PCCISUsage'))+parseFloat(			getNGValue('cmplx_Excise_q_POthersReavCr'))) > parseFloat(getNGValue('cmplx_Excise_q_ExcPayble'))) {
			alert('Sum of Planned Usages canot be greater than Excise PLA Payable');
			setNGValue('cmplx_Excise_q_PLAPayable',"");
			setNGValue('cmplx_Excise_q_ExcPayble',"");
		}	
    }
}



function maxCheckExciseDuty()
{	
    //Function to do total of three input values
	if(getNGValue('cmplx_Excise_q_ExcPayble')!="" && getNGValue('cmplx_Excise_q_PCCIUsage')!="" && getNGValue('cmplx_Excise_q_PCCCapGUsage')!="" && getNGValue(				       		   	'cmplx_Excise_q_PCCISUsage')!="" && getNGValue('cmplx_Excise_q_POthersReavCr')!="" && getNGValue('cmplx_Excise_q_PlandPLAUsage')!=""){
        
		if((parseFloat(getNGValue('cmplx_Excise_q_PCCIUsage'))+parseFloat(getNGValue('cmplx_Excise_q_PCCCapGUsage'))+parseFloat(getNGValue('cmplx_Excise_q_PCCISUsage'))+						parseFloat(getNGValue('cmplx_Excise_q_POthersReavCr')) + parseFloat(getNGValue('cmplx_Excise_q_PlandPLAUsage'))) > parseFloat(getNGValue('cmplx_Excise_q_ExcPayble'))) {
			alert('Sum of Planned Usages canot be greater than Excise PLA Payable');
			setNGValue('cmplx_Excise_q_PLAPayable',"");
			setNGValue('cmplx_Excise_q_PlandPLAUsage',"");
		}	
	}
}

function maxCheckEDReversal(control1,control2,controlRev)
{	
	var text = getNGValue(controlRev);	    
    if(text!=0){
        var pospatrn = /-/;              		
        if (!pospatrn.test(text))	
        {
            if(parseFloat(getNGValue(controlRev))>(parseFloat(getNGValue(control1))+parseFloat(getNGValue(control2))))
            {	
                alert('Revrsal cannot be greater than Cenvat credit on input Opening Balance + Current period');	
				setNullFocus(controlRev);
                return false;
            }
        }
    }
}
					
					
					

function totExcisePay()
{		
	
    if(getNGValue('cmplx_Excise_q_ExcPayble')!="" && getNGValue('cmplx_Excise_q_PCCIUsage')!="" && getNGValue('cmplx_Excise_q_PCCCapGUsage')!="" && getNGValue('cmplx_Excise_q_PCCISUsage')!="" && getNGValue('cmplx_Excise_q_POthersReavCr')!="" && getNGValue('cmplx_Excise_q_PlandPLAUsage')!=""){
	
        var totExcise = ((parseFloat(getNGValue('cmplx_Excise_q_ExcPayble'))-parseFloat(getNGValue('cmplx_Excise_q_PCCIUsage'))-parseFloat(getNGValue('cmplx_Excise_q_PCCCapGUsage'))-parseFloat(getNGValue('cmplx_Excise_q_PCCISUsage'))-parseFloat(getNGValue('cmplx_Excise_q_POthersReavCr'))) - parseFloat(getNGValue('cmplx_Excise_q_PlandPLAUsage')));		
        
		setNGValue('cmplx_Excise_q_PLAPayable',totExcise.toFixed());
		setNGValue('cmplx_Excise_q_PlannedPLAPayable',totExcise.toFixed());
		setNGValue('Excise_TotED',totExcise.toFixed());	
		
		if(getNGValue('cmplx_Excise_q_AdjARFA')!=""){
			var valApprvl = ((parseFloat(getNGValue('Excise_TotED'))) - (parseFloat(getNGValue('cmplx_Excise_q_AdjARFA'))))
				setNGValue('cmplx_Excise_q_PLAPayable',valApprvl);
				setNGValue('cmplx_Excise_q_PlannedPLAPayable',valApprvl);
		}
		var requestTypeED = getNGValue('TypeOfRequest');
		if(requestTypeED=='SupplementaryRFA'){
			if(getNGValue('cmplx_Excise_q_PLAPayable')!="" && getNGValue('cmplx_Excise_q_PLAApprvdRRFA')!=""){
				var valApprvlSRFA = ((parseFloat(getNGValue('cmplx_Excise_q_PLAPayable'))) - (parseFloat(getNGValue('cmplx_Excise_q_PLAApprvdRRFA'))))
				setNGValue('cmplx_Excise_q_ApprovalOf',valApprvlSRFA);
			}
		}
    
	}else{
        com.newgen.omniforms.formviewer.setNGValue('cmplx_Excise_q_PLAPayable',"");	
    }		
}



function posvalidate(controlName)
{		
    var text = getNGValue(controlName);
	    
    if(text!=0){
        var pospatrn = /-/;              		
        if (pospatrn.test(text))	
        {
            alert('Please enter only positive values');
            com.newgen.omniforms.formviewer.setNGFocus(controlName);
            com.newgen.omniforms.formviewer.setNGValue(controlName,"");
            return false;
        }
    }
    return true;
}

function negvalidate(controlName)
{		
    var text = getNGValue(controlName);
    if(text!=0){
        var pospatrn = /-/;              		
        if (!pospatrn.test(text))	
        {
            alert('Please enter only negative values');
            com.newgen.omniforms.formviewer.setNGFocus(controlName);
            com.newgen.omniforms.formviewer.setNGValue(controlName,"");
            return false;
        }
    }
    return true;
}

function maxValueCheck(control1,control2, messageString)
{
    if(parseFloat(com.newgen.omniforms.formviewer.getNGValue(control1))>parseFloat(com.newgen.omniforms.formviewer.getNGValue(control2)))
    {
        alert(messageString);       
        com.newgen.omniforms.formviewer.setNGFocus(control1);
        com.newgen.omniforms.formviewer.setNGValue(control1,"");
        return false;
    }
    return true;
}

function getCurMonth() {
    var month = new Array();
    month[0] = "January";
    month[1] = "February";
    month[2] = "March";
    month[3] = "April";
    month[4] = "May";
    month[5] = "June";
    month[6] = "July";
    month[7] = "August";
    month[8] = "September";
    month[9] = "October";
    month[10] = "November";
    month[11] = "December";

    var curDate = new Date();
    return month[curDate.getMonth()];    
}

function enableFields(Fields,option)
{
	
    for(var i=0;i<Fields.length;i++){
		
        if(option=="Enable"){
			
            com.newgen.omniforms.formviewer.setEnabled(Fields[i], true);
		   
        }
        if(option=="Disable"){
            com.newgen.omniforms.formviewer.setEnabled(Fields[i], false);
        }
    }
}
function visibleFields(Fields,option)
{
	
    for(var i=0;i<Fields.length;i++){
        if(option=="Enable"){
            com.newgen.omniforms.formviewer.setVisible(Fields[i], true);
		   
        }
        if(option=="Disable"){
            com.newgen.omniforms.formviewer.setVisible(Fields[i], false);
        }
    }
}

function CaseNoCheck()
{
    caseNo1=getNGValue("cmplx_NR_RFA_q_CaseNo1");
    caseNo2=getNGValue("cmplx_NR_RFA_q_CaseNo2");
    if(!(caseNo1==""&&caseNo2=="")){
        if(caseNo1==caseNo2)
        {
            showError("cmplx_NR_RFA_q_CaseNo2","Same Case Number cannot be used");
            setNGFocus("cmplx_NR_RFA_q_CaseNo2");
			com.newgen.omniforms.formviewer.setNGValue("cmplx_NR_RFA_q_CaseNo2","");
            return false;
        
        }
    }
}

/*
function NonRoutineCheck(prinValue,intValue,penValue,partValue)
{   
    prin=com.newgen.omniforms.formviewer.getNGValue(prinValue);
    inter=com.newgen.omniforms.formviewer.getNGValue(intValue);
    pen=com.newgen.omniforms.formviewer.getNGValue(penValue);
    part=com.newgen.omniforms.formviewer.getNGValue(partValue);
    
    tot=eval(prin)+eval(inter)+eval(pen);
    
    
    if(part.toString()>tot.toString()){
        showError(partValue, "Part Payment cannot be greater than Principle, Interest and Penalty");
        
        setNGFocus(partValue);
        return false;   
    
    }
    
    return true;
}
*/
function partPayMadeCheck(partPayControl,princControl,intrControl,penalControl)
{      
	if(getNGValue(princControl)!="" && getNGValue(intrControl)!="" && getNGValue(penalControl)!="" && getNGValue(partPayControl)!=""){
        var partPM = ((parseFloat(getNGValue(princControl))) + (parseFloat(getNGValue(intrControl))) + (parseFloat(getNGValue(penalControl))));	
		if( getNGValue(partPayControl) > partPM ){
			showError(partPayControl, "Part Payment cannot be greater than Principle, Interest and Penalty");
			//setNGFocus(partPayControl);
			return false;
		}
		
		return true;
	}  
    return true;
}

function dueBalCheck(dueBalControl,princControl,intrControl,penalControl,partPMControl)
{      
	if(getNGValue(princControl)!="" && getNGValue(intrControl)!="" && getNGValue(penalControl)!="" && getNGValue(partPMControl)!=""){
        
		var dueBal = ((parseFloat(getNGValue(princControl))) + (parseFloat(getNGValue(intrControl))) + (parseFloat(getNGValue(penalControl))) - (parseFloat(getNGValue(partPMControl))));	
		com.newgen.omniforms.formviewer.setNGValue(dueBalControl,dueBal);
		
	}
}

/*
function NonRoutineCheck1(balValue)
{
    
    bal=getNGValue(balValue);    
    
    var balTot=tot-part;
    if(bal>balTot){
        showError(balValue,"Balance due cannot be greater than Principle, Interest and Penalty");
        setNGFocus(balValue);
        return false;
    }
    
    return true;
}
*/

/*
function NonRoutineCheck2(penPaidValue)
{
    penPaid=getNGValue(penPaidValue);
    if(penPaid>pen){
        showError(penPaidValue,"Penality to be paid cannot be greater than Penality");
        setNGFocus(penPaidValue);
        return false;
    }
    
    return true;
}
*/


/*
function NonRoutineCheck3(intPaidValue)
{
    interPaid=getNGValue(intPaidValue);
    if(interPaid>inter){
        showError(intPaidValue,"Interest to be paid cannot be greater than Interest");
        setNGFocus(intPaidValue);
        return false;
    }
    
    return true;
} 
*/

/*
function DateValidate1(fromDate,toDate,comment)
{
    fDate=getNGValue(fromDate);
    tDate=getNGValue(toDate);
    //  alert("From date "+fDate);
    //   alert("To date "+tDate);
    if (Date.parse(fDate) > Date.parse(tDate)) {
        showError(toDate,comment);
        setNGFocus(toDate);
        return false;
    }

}
*/

/*
function AdditionalValidate(amtAdjust,noOfInstall,reqAmount,addComm)
{
    amtAdj=getNGValue(amtAdjust);
    noOfInst=getNGValue(noOfInstall);
    reqAmt=getNGValue(reqAmount);
    addTot=amtAdj*noOfInst;
    if(addTot>reqAmt){
        showError(noOfInstall,addComm);
        setNGFocus(noOfInstall);
        return false;
    }
    return true;
}
*/

function datecompare(controlName1,controlName2,errMsg)
{ 
    var dt3 = com.newgen.omniforms.formviewer.getNGValue(controlName1);
    var dt4 = com.newgen.omniforms.formviewer.getNGValue(controlName2);
    var date1= new Date(); 
    var hh=date1.getHours(); // => 9
    var mm=date1.getMinutes(); // =>  30
    var ss=date1.getSeconds(); // => 51
    var temp2 = "";
    var temp1 = "";
    var str2 = dt3;
    var dt2  = str2.substring(0,2);
    var mon2 = str2.substring(3,5);
    var yr2  = str2.substring(6,10); 
    temp1 = hh +":" + mm +":" + ss ; 
    temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
    var ctd1 = Date.parse(temp2,temp1);
    var date3 = new Date(ctd1);
       
    var hh=date1.getHours(); // => 9
    var mm=date1.getMinutes(); // =>  30
    var ss=date1.getSeconds(); // => 51
    var temp2 = "";
    var temp1 = "";
    var str2 = dt4;
    var dt2  = str2.substring(0,2);
    var mon2 = str2.substring(3,5);
    var yr2  = str2.substring(6,10); 
    mm=mm+2;
    temp1 = hh +":" + mm +":" + ss ; 
    temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
    var ctd2 = Date.parse(temp2,temp1);
    var date4 = new Date(ctd2);
       
	if(getNGValue(controlName1)!="" && getNGValue(controlName2) !=""){
		if(date3 > date4 || isNaN(date3) || isNaN(date4)) 
		{ 
			com.newgen.omniforms.util.showError(controlName1,errMsg);
			//com.newgen.omniforms.util.showError(controlName1,"FromDate should be lower than the ToDate!!!!!");
			setNGValue(controlName1,"" );
			//setNGBackColor(controlName1, new Color(123, 255, 250));
			setNGValue(controlName2,"" );
			//setNGBackColor(controlName2, new Color(123, 255, 250));
			setNGFocus(controlName1);
			return false;
		}
	}
    return true;
 
}

//Function to avoid future dates selection
function futuredateCheck(controlName)
{      //formObject.setNGBackColor(controlName, new Color(255, 255, 255));
      var d2 = com.newgen.omniforms.formviewer.getNGValue(controlName);
      var date1= new Date(); 
      var hh=date1.getHours(); // => 9
      var mm=date1.getMinutes(); // =>  30
      var ss=date1.getSeconds(); // => 51
      var temp2 = "";
      var temp1 = "";
      var str2 = d2;
      var dt2  = str2.substring(0,2);
      var mon2 = str2.substring(3,5);
      var yr2  = str2.substring(6,10); 
      mm=mm-1;
      temp1 = hh +":" + mm +":" + ss ; 
      temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
      var ctd = Date.parse(temp2,temp1);
      var date2 = new Date(ctd);
      var age = date1.getFullYear() - date2.getFullYear();
      var m = date1.getMonth() - date2.getMonth(); 
    if(date1 < date2|| isNaN(date2)) 
       { 
		com.newgen.omniforms.util.showError(controlName,"Future Date is not allowed..!!!");
        //com.newgen.omniforms.util.showError(controlName,"Future Date is not allowed..!!!");
        setNGValue(controlName,"" );
        setNGFocus(controlName);
        return false;
       }
    return true;
}


//Function to avoid past dates selection
function pastdateCheck(controlName)
{      //formObject.setNGBackColor(controlName, new Color(255, 255, 255));
      var d2 = com.newgen.omniforms.formviewer.getNGValue(controlName);
      var date1= new Date(); 
      var hh=date1.getHours(); // => 9
      var mm=date1.getMinutes(); // =>  30
      var ss=date1.getSeconds(); // => 51
      var temp2 = "";
      var temp1 = "";
      var str2 = d2;
      var dt2  = str2.substring(0,2);
      var mon2 = str2.substring(3,5);
      var yr2  = str2.substring(6,10); 
      mm=mm-1;
      temp1 = hh +":" + mm +":" + ss ; 
      temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
      var ctd = Date.parse(temp2,temp1);
      var date2 = new Date(ctd);
      var age = date1.getFullYear() - date2.getFullYear();
      var m = date1.getMonth() - date2.getMonth(); 
    if(date1 > date2|| isNaN(date2)) 
       { 
		com.newgen.omniforms.util.showError(controlName,"Past Date is not allowed..!!!");        
        setNGValue(controlName,"" );
        setNGFocus(controlName);
        return false;
       }
    return true;
}




//Function to check the number is Int type
function isInt(controlName) { 
	var n = getNGValue(controlName);
   if(typeof n == 'number' && Math.Round(n) % 1 == 0) {
       return true;
   } else {
       return false;
	   setNGValue(controlName,"" );
	   setNGFocus(controlName);
	   alert('Please enter only integer values!!!');
   }
}


//Documents type validate function "For Loop"
function validateDocumentTypeSP(sInputDocName)
{
    try
    {
        var xmlOut = window.parent.getInterfaceData("DLIST"); //list the doc type values
        var sDocName = "";
        while (xmlOut.indexOf("<DocumentName>") > 0)
        {
            sDocName = sDocName + xmlOut.substring(xmlOut.indexOf('<DocumentName>') + 14, xmlOut.indexOf('</DocumentName>')) + "||";
            xmlOut = xmlOut.substring(xmlOut.indexOf('</Document>') + 11, xmlOut.length);//for multiple Documents 
        }
        //alert(sDocName);
		
		for(var i=0;i<sInputDocName.length;i++){
			if (sDocName.indexOf(sInputDocName[i]) == -1)
			{
				//alert(sDocName);
				alert(sInputDocName[i] + " document is mandatory");
				return false;
			}
			
		}
        
    }
    catch (ex) 
	{
		
    }
    return true;
}


//Function for Document Mandatory Check
function documentMandatory()
{

	var docTypeList = new Array();
	processname=window.parent.strprocessname;
	activityName=window.parent.stractivityName;
	requestType=getNGValue('TypeOfRequest');
    legislationType=getNGValue('StatutoryLegislation');
	
	if(activityName=='Initiator' || activityName=='Rework'){
			if(requestType == 'ISDReversal')
			{
        
				docTypeList=["RegionalReversals"];
			}
			
			if(requestType == 'ISDInvoice')
			{
				
				docTypeList=["InvoiceCalculation"];
			}
			
			if((requestType == 'RoutineRFA' || requestType == 'SupplementaryRFA' ) && legislationType == 'Service Tax')
			{
        
				docTypeList=["ST_Working"];
			}
			if((requestType == 'RoutineRFA' || requestType == 'SupplementaryRFA' ) && legislationType == 'TDS')
			{
        
				docTypeList=["TDS_Calculation"];
			}
			if((requestType == 'RoutineRFA' || requestType == 'SupplementaryRFA' ) && legislationType == 'TDS195')
			{
        
				docTypeList=["TDS195_Calculation"];
			}
			if((requestType == 'RoutineRFA' || requestType == 'SupplementaryRFA' ) && legislationType == 'VAT')
			{
        
				docTypeList=["VAT_Calculation"];
			}
			if((requestType == 'RoutineRFA' || requestType == 'SupplementaryRFA' ) && legislationType == 'Entry Tax')
			{
        
				docTypeList=["Entry_Calculation"];
			}
			if((requestType == 'RoutineRFA' || requestType == 'SupplementaryRFA' ) && legislationType == 'Excise Duty')
			{
        
				docTypeList=["ExciseDuty_Calculation"];
			}
			if((requestType == 'RoutineRFA' || requestType == 'SupplementaryRFA' ) && legislationType == 'Corporate Tax')
			{
        
				docTypeList=["Profit Figures Mail"];
			}
			//
			if((requestType == 'Reconciliation' || requestType == 'Non-RoutineRFA'  || requestType == 'AdditionalRFA' ) && (legislationType == 'Service Tax')) 
			{
        
				docTypeList=["ST_Working"];
			}
			if((requestType == 'Reconciliation' || requestType == 'Non-RoutineRFA' || requestType == 'AdditionalRFA' ) && (legislationType == 'TDS') )
			{
        
				docTypeList=["TDS_Calculation"];
			}
			if((requestType == 'Reconciliation' || requestType == 'Non-RoutineRFA'  || requestType == 'AdditionalRFA' ) && (legislationType == 'TDS195'))
			{
        
				docTypeList=["TDS195_Calculation"];
			}
			if((requestType == 'Reconciliation' || requestType == 'Non-RoutineRFA'  || requestType == 'AdditionalRFA' ) && (legislationType == 'VAT'))
			{
        
				docTypeList=["VAT_Calculation"];
			}
			if((requestType == 'Reconciliation' || requestType == 'Non-RoutineRFA' || requestType == 'AdditionalRFA' ) && (legislationType == 'Entry Tax'))
			{
        
				docTypeList=["Entry_Calculation"];
			}
			if((requestType == 'Reconciliation' || requestType == 'Non-RoutineRFA'  || requestType == 'AdditionalRFA' ) && (legislationType == 'Excise Duty'))
			{
        
				docTypeList=["ExciseDuty_Calculation"];
			}
			//
			if(requestType == 'MIS' && legislationType == 'TDS')
			{
        
				docTypeList=["TDS_MIS"];
			}
			if(requestType == 'MIS' && legislationType == 'VAT')
			{
        
				docTypeList=["VAT_MIS"];
			}
			if(requestType == 'MIS' && legislationType == 'Entry Tax')
			{
        
				docTypeList=["Entrytax_MIS"];
			}
			if(requestType == 'MIS' && legislationType == 'Custom Duty')
			{
        
				docTypeList=["CustomsDuty_MIS"];
			}
		
			if(validateDocumentTypeSP(docTypeList)){
			
				return true;
			}else{
			
				return false;
			}
			
		}
	return true;
}
