/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


var activityName;
var processName;
var workitemName;
var strProcessinstanceID;

//added for Dynamic URL
var dynamicURL=window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
function eventDispatched_TC(pId, pEvent)
{
    processname=window.parent.strprocessname;
    activityName=window.parent.stractivityName;
    strProcessinstanceID=getNGValue("PID");
	
    curMonth = getCurMonth();
    window.status = pId + "_" + pEvent.type;

    switch (pEvent.type) 
    {
        case 'click':
        {
            switch (pId) 
            {   
                case 'Btn_CmntHistry':
                {
                    //Session id need to be captured here
                    var Pid1=getNGValue("PID");
                  
                    var url=dynamicURL+"/webdesktop/CustomJSP/TCEDDAudit.jsp?ProcessInstanceId="+Pid1;
                    window.open(url,"","width=800,height=500");
                    return true;
                    break;
                }

                case 'Btn_Submit':
                {	
					if (!(
                        mandateCheck('Brand', 'Brand') 
                        //&& mandateCheck('Structure', 'Structure') 
                        && mandateCheck('SKU', 'SKU') 
						&& mandateCheck('Breadth', 'Breadth')
                        && mandateCheck('Cutoff', 'Cutoff') 
						&& mandateCheck('BusinesssClass', 'Business Classification') 						
                        ))
                        {
							return false;
						}
					
                    //For Comments Mandatory
                    if(!mandateCheck('TCComments', 'Comments')){
                        return false;
                    }
                    
                    return true;
                    break;
                }
                case 'Btn_Approve':
                {
                    //For Comments Mandatory
                    if(!mandateCheck('TCComments', 'Comments')){
                        return false;
                    }
                    
                    return true;
                    break;
                }
                case 'Btn_Reject':
                {
                    //For Comments Mandatory
                    if(!mandateCheck('TCComments', 'Comments')){
                        return false;
                    }
                    
                    return true;
                    break;
                }    
				case 'Btn_Add':
                {
                    
                    return true;
                    break;
                }
				case 'Btn_Modify':
                {
                    
                    return true;
                    break;
                }
				case 'Btn_Delete':
                {
                    
                    return true;
                    break;
                }
				case 'Btn_MoveDown':
                {
                    
                    return true;
                    break;
                }
				case 'Btn_MoveUp':
                {
                    
                    return true;
                    break;
                }
				case 'Btn_AttachDoc':
				{
					//window.parent.openDocList();//To Load Document List from Document Button
			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
				}
				
				//Added BY Harinatha R on 2017/09/13
				case 'q_SelVendorOrders':
                {
                    //alert('on click of listview');
                    return true;
                    break;
                }
				//Ended BY Harinatha R on 2017/09/13
				//Added BY Sivashankar KS on 2019/01/28 starts  here
				case 'Btn_TCRequests':
                {           					
                    return true;
                    break;
                }
				case 'Btn_TCCSubmit':
                {    
					if(!mandateCheck('WorkID', 'WorkID')){
                        return false;
                    }

					if(!mandateCheck('TCC_VendorComments', 'Comments')){
                        return false;
                    }
				
                    return true;
                    break;
                }
				case 'Btn_TCCApprove':
                {     
				
					if(!mandateCheck('TCC_ApproverComments', 'Comments')){
                        return false;
                    }
				
                    return true;
                    break;
                }
				case 'Btn_TCCReject':
                {    

					if(!mandateCheck('TCC_ApproverComments', 'Comments')){
                        return false;
                    }
				
                    return true;
                    break;
                }
				//Added BY Sivashankar KS on 2019/01/28 ends  here
				/*
                case 'VendorOrders_BtnAdd':	
                {	
                    if (!(
                        mandateCheck('VendorOrders_Plant', 'Plant') 
                        && mandateCheck('VendorOrders_Quantity', 'Quantity') 
                        && mandateCheck('VendorOrders_Structure', 'Structure')
						&& mandateCheck('VendorOrders_Comment', 'Comment') 
                        //&& mandateCheck('VendorOrders_Vendor', 'Vendor') 
                        //&& mandateCheck('VendorOrders_DelvryStat', 'Delivery Status') 	
						//&& mandateCheck('VendorOrders_Feedback', 'Feedback')											
                        ))
                        {
                        return false;
                    }
					
                    //if(com.newgen.omniforms.formviewer.getNGValue("VAT_CmbLegislation")=="VAT"){
                     //   if (!(
                     //       mandateCheck('VAT_VATInput', 'Input VAT') 
                    //        && mandateCheck('VAT_VATIR', 'Input VAT Reversal') 						
                    //        ))
                    //        {
                    //        return false;
                    //    }
						
                    //}
					
                    return true;
                    break;
                }
                case 'VendorOrders_BtnMod':	
                {	
                   if (!(
                        mandateCheck('VendorOrders_Plant', 'Plant') 
                        && mandateCheck('VendorOrders_Quantity', 'Quantity')
						&& mandateCheck('VendorOrders_Structure', 'Structure')						
                        && mandateCheck('VendorOrders_Comment', 'Comment') 
                        //&& mandateCheck('VendorOrders_Vendor', 'Vendor') 
                        //&& mandateCheck('VendorOrders_DelvryStat', 'Delivery Status') 	
						//&& mandateCheck('VendorOrders_Feedback', 'Feedback')											
                        ))
                        {
							return false;
						}
					
                    return true;
                    break;
                }
                case 'VendorOrders_BtnDel':	
                {	
                    return true;
                    break;
                }
				*/
				
				/*
				case 'VendorOrders_Btn_MoveDown':	
                {	
					if (!(
                        mandateCheck('VendorOrders_Vendor', 'Vendor') 
                        //&& mandateCheck('VendorOrders_Quantity', 'Quantity') 
                        //&& mandateCheck('VendorOrders_Comment', 'Comment') 										
                        ))
                        {
							return false;
						}
				
                    return true;
                    break;
                }
				case 'VendorOrders_Btn_MoveUp':	
                {	
                    return true;
                    break;
                }
			*/
            }
        }
		
        case 'change':
        {
            switch (pId) 
            {
                case 'Brand':
                {
                    return true;
                    break;
                }
                case 'Structure':
                {   
                    return true;
                    break;
                }  
				case 'SKU':
                {   
                    return true;
                    break;
                } 
				case 'KLD':
                {   
                    return true;
                    break;
                } 
				case 'Breadth':
                {   
                    return true;
                    break;
                } 
				case 'Vendor': 
                {   
                    return true;
                    break;
                }
				case 'Txt_Plant': 
                {   
                    return true;
                    break;
                }
				case 'Txt_Quantity': 
                {   
                    return true;
                    break;
                }
				case 'Txt_Structure': 
                {   
                    return true;
                    break;
                }
				case 'Txt_Comment': 
                {   
                    return true;
                    break;
                } 
				case 'Txt_DeliveyDate': 
                {   
					pastdateCheck_TC('Txt_DeliveyDate');
                    return true;
                    break;
                }
				case 'Txt_EDD': 
                {   
					pastdateCheck_TC('Txt_EDD');
                    return true;
                    break;
                }
				case 'Txt_VendorCode': 
                {   
                    return true;
                    break;
                }
				case 'Txt_VendorName': 
                {   
                    return true;
                    break;
                }
				case 'Txt_DeliveryStatus': 
                {   
					
                    return true;
                    break;
                }
				case 'Txt_DeliveredDate': 
                {   
					datecompare_TC("Txt_EDD","Txt_DeliveredDate",'Delivered date cannot be greater than Estimated delivery date');
					//datecompare_TC("cmplx_NR_RFA_CasePeriodFrm1","cmplx_NR_RFA_CasePeriodTo1",'Case Period From date cannot be greater than Case Period To date');
                    return true;
                    break;
                } 
				case 'Txt_Feedback': 
                {   
                    return true;
                    break;
                }
				


				
				/*
				case 'VendorOrders_Quantity': 
                {   
                    return true;
                    break;
                } 
				case 'VendorOrders_Plant': 
                {   
                    return true;
                    break;
                } 
				case 'VendorOrders_Vendor': 
                {   
                    return true;
                    break;
                } 
				case 'VendorOrders_EDD': 
                {   
                    return true;
                    break;
                }
				case 'VendorOrders_DelvryStat': 
                {   
                    return true;
                    break;
                }
				case 'VendorOrders_Feedback': 
                {   
                    return true;
                    break;
                }
				*/
                /*
                case 'VAT_VATInput':
                {
                    posvalidate('VAT_VATInput');
					maxValueCheck('VAT_VATIR','VAT_VATInput', 'Input VAT Reversal cannot be greater than Input VAT ');
                    if(parseFloat(getNGValue('VAT_VATInput'))>( parseFloat(getNGValue('VAT_VATOutput')) - (parseFloat(getNGValue('VAT_VATCN'))-parseFloat(getNGValue('VAT_VATCNR'))))){
                        alert('VAT payable for this tax percentage becomes Negative');
                        //setNullFocus('VAT_VATInput');
                        return false;						
                    }
                    return true;
                    break;
                } 
				*/
            }
        }   
        case 'blur':
        {
            switch (pId) 

            {
                
            }
        }
        case 'focus':
        {           
          
            switch (pId) 
            {
                
            }
        }
    }
}

function setNGFocus(Value)
{
    com.newgen.omniforms.formviewer.setNGFocus(Value);

}
function getNGValue(Value)
{
    return com.newgen.omniforms.formviewer.getNGValue(Value);
}
function setNGValue(control, value)
{
    com.newgen.omniforms.formviewer.setNGValue(control, value);
}

function setNullFocus(controlName) { 
	setNGValue(controlName,"");
    setNGFocus(controlName);
}

function getTop(Control)
{
    com.newgen.omniforms.formviewer.getTop(Control);
}
function setTop(Control, Value)
{
    com.newgen.omniforms.formviewer.setTop(Control, Value);
}
function setNGListIndex(control, i)
{
    com.newgen.omniforms.formviewer.setNGListIndex(control, i);
}
function NGClearSelection(control)
{
    com.newgen.omniforms.formviewer.NGAddDefaultItem(control);
}
function clear(control)
{
    com.newgen.omniforms.formviewer.clear(control);
}
function setHeight(control,i)
{
    com.newgen.omniforms.formviewer.setHeight(control,i);
}
function showError(control, value)
{
    com.newgen.omniforms.util.showError(control, value);
}
function mandateCheck(controlName, messageString)
{
    if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--')
    {
        showError('controlName','Please Enter the ' + messageString);               
        com.newgen.omniforms.formviewer.setNGValue(controlName,"");
		com.newgen.omniforms.formviewer.setNGFocus(controlName);
		com.newgen.omniforms.formviewer.setNGBackColor(controlName,"#E0E2B7"); 
        return false;
    }
    return true;

}

function enableFields(Fields,option)
{
	
    for(var i=0;i<Fields.length;i++){
		
        if(option=="Enable"){
			
            com.newgen.omniforms.formviewer.setEnabled(Fields[i], true);
		   
        }
        if(option=="Disable"){
            com.newgen.omniforms.formviewer.setEnabled(Fields[i], false);
        }
    }
}

function visibleFields(Fields,option)
{
	
    for(var i=0;i<Fields.length;i++){
        if(option=="Enable"){
            com.newgen.omniforms.formviewer.setVisible(Fields[i], true);
		   
        }
        if(option=="Disable"){
            com.newgen.omniforms.formviewer.setVisible(Fields[i], false);
        }
    }
}

function datecompare_TC(controlName1,controlName2,errMsg)
{ 
    var dt3 = com.newgen.omniforms.formviewer.getNGValue(controlName1);
    var dt4 = com.newgen.omniforms.formviewer.getNGValue(controlName2);
    var date1= new Date(); 
    var hh=date1.getHours(); // => 9
    var mm=date1.getMinutes(); // =>  30
    var ss=date1.getSeconds(); // => 51
    var temp2 = "";
    var temp1 = "";
    var str2 = dt3;
    var dt2  = str2.substring(0,2);
    var mon2 = str2.substring(3,5);
    var yr2  = str2.substring(6,10); 
    temp1 = hh +":" + mm +":" + ss ; 
    temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
    var ctd1 = Date.parse(temp2,temp1);
    var date3 = new Date(ctd1);
       
    var hh=date1.getHours(); // => 9
    var mm=date1.getMinutes(); // =>  30
    var ss=date1.getSeconds(); // => 51
    var temp2 = "";
    var temp1 = "";
    var str2 = dt4;
    var dt2  = str2.substring(0,2);
    var mon2 = str2.substring(3,5);
    var yr2  = str2.substring(6,10); 
    mm=mm+2;
    temp1 = hh +":" + mm +":" + ss ; 
    temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
    var ctd2 = Date.parse(temp2,temp1);
    var date4 = new Date(ctd2);
       
	if(getNGValue(controlName1)!="" && getNGValue(controlName2) !=""){
		if(date3 > date4 || isNaN(date3) || isNaN(date4)) 
		{ 
			com.newgen.omniforms.util.showError(controlName1,errMsg);
			//com.newgen.omniforms.util.showError(controlName1,"FromDate should be lower than the ToDate!!!!!");
			
			//setNGValue(controlName1,"" );
			//setNGBackColor(controlName1, new Color(123, 255, 250));
			//setNGValue(controlName2,"" );
			//setNGBackColor(controlName2, new Color(123, 255, 250));
			setNGFocus(controlName1);
			return false;
		}
	}
    return true;
 
}


//Function to avoid past dates selection
function pastdateCheck_TC(controlName)
{      //formObject.setNGBackColor(controlName, new Color(255, 255, 255));
      var d2 = com.newgen.omniforms.formviewer.getNGValue(controlName);
      var date1= new Date(); 
      var hh=date1.getHours(); // => 9
      var mm=date1.getMinutes(); // =>  30
      var ss=date1.getSeconds(); // => 51
      var temp2 = "";
      var temp1 = "";
      var str2 = d2;
      var dt2  = str2.substring(0,2);
      var mon2 = str2.substring(3,5);
      var yr2  = str2.substring(6,10); 
      mm=mm-1;
      temp1 = hh +":" + mm +":" + ss ; 
      temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
      var ctd = Date.parse(temp2,temp1);
      var date2 = new Date(ctd);
      var age = date1.getFullYear() - date2.getFullYear();
      var m = date1.getMonth() - date2.getMonth(); 
    if(date1 > date2|| isNaN(date2)) 
       { 
		com.newgen.omniforms.util.showError(controlName,"Past Date is not allowed..!!!");        
        setNGValue(controlName,"" );
        setNGFocus(controlName);
        return false;
       }
    return true;
}

