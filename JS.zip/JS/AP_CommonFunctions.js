var activityName=window.parent.stractivityName;
var processName = window.parent.strprocessname;
var pid1=window.parent.strWorkitemName;
var date1= new Date();

function setLocked(control, value)
{
com.newgen.omniforms.formviewer.setLocked(control,value);
}
function setEnabled(control, value)
{
//alert('Inside Set Enabled');
com.newgen.omniforms.formviewer.setEnabled(control,value);
}
function RaiseEvent(control) 
{
	com.newgen.omniforms.formviewer.RaiseEvent(control);
}
function setNGValue(control, value) 
{
	com.newgen.omniforms.formviewer.setNGValue(control, value);
}
function setNGFocus(Value)
{
    com.newgen.omniforms.formviewer.setNGFocus(Value);
}
function getNGValue(Value)
{
    return com.newgen.omniforms.formviewer.getNGValue(Value);
}
function setNGValue(control, value)
{
    com.newgen.omniforms.formviewer.setNGValue(control, value);
}
function getTop(Control)
{
    com.newgen.omniforms.formviewer.getTop(Control);
}
function setTop(Control, Value)
{
    com.newgen.omniforms.formviewer.setTop(Control, Value);
}
function setNGListIndex(control, i)
{
    com.newgen.omniforms.formviewer.setNGListIndex(control, i);
}
function NGClearSelection(control)
{
    com.newgen.omniforms.formviewer.NGAddDefaultItem(control);
}
function clear(control)
{
    com.newgen.omniforms.formviewer.clear(control);
}
function setHeight(control,i)
{
    com.newgen.omniforms.formviewer.setHeight(control,i);
}
function showError(control, value)
{
    com.newgen.omniforms.util.showError(control, value);
}
function showErrorAP(control, value)
{
    com.newgen.omniforms.util.showError(control, value);
}
function mandateCheck_AP(controlName, messageString)
{
	var nonzero=0.00;
	var color1=getNGValue('mandcolor');
	if(!color1=="")
	{
		com.newgen.omniforms.formviewer.setNGBackColor(controlName, "#FFFFFF");
	}
     //alert('Mandate Check Running AP ...');
    //Modified By Harinath on 2017/07/03
    //if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--'||getNGValue(controlName) ==nonzero)
	if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--')
	//Ended By Harinath on 2017/07/03
    {		
		com.newgen.omniforms.util.showError(controlName,'Please enter the ' + messageString);
		//alert('Please enter the ' + messageString);
        //showError('controlName','PLEASE ENTER THE ' + messageString);   
		com.newgen.omniforms.formviewer.setNGBackColor(controlName,"#F2F5A9");	
        //setNGFocus(controlName);
        var c1=controlName;        
        com.newgen.omniforms.formviewer.setNGValue('mandcolor',c1);
        //alert("gg"+getNGValue('mandcolor'));
        return false;
    }
    return true;

}
function mandateCheck_AP1(controlName, messageString)
{
	var color1=getNGValue('mandcolor');
	if(!color1=="")
	{
		com.newgen.omniforms.formviewer.setNGBackColor(controlName, "#FFFFFF");
	}
     //alert('Mandate Check Running AP ...');
    if (getNGValue(controlName) == '' || getNGValue(controlName) == '--Select--')
    {
		com.newgen.omniforms.util.showError(controlName,'Please enter the ' + messageString);
		//alert('Please enter the ' + messageString);
        //showError('controlName','PLEASE ENTER THE ' + messageString);   
		com.newgen.omniforms.formviewer.setNGBackColor(controlName,"#F2F5A9");	
        //setNGFocus(controlName);
        var c1=controlName;        
        com.newgen.omniforms.formviewer.setNGValue('mandcolor',c1);        
        return false;
    }
    return true;

}
function futuredate_AP(controlName)
{
	var enteredDate1=com.newgen.omniforms.formviewer.getNGValue(controlName);		
	var dateParts1 = enteredDate1.split("/");	
	var date1 = new Date(dateParts1[2], dateParts1[1] - 1, dateParts1[0]);
	var date2 = new Date();	
	//alert(date1);
	//alert(date2);
	 if(date1>date2)
	 
	 {
	 //alert('First date is greater than second date');
	 com.newgen.omniforms.util.showError(controlName,"Future date is not allowed !!!");
	 setNGValue(controlName,"" );
	 return false;
	 }
		
    return true;

}
/*
function futuredate_AP2(controlName)
{						
						var d2 = com.newgen.omniforms.formviewer.getNGValue(controlName);
						var date1= new Date(); 
						var hh=date1.getHours(); // => 9
						var mm=date1.getMinutes(); // =>  30
						var ss=date1.getSeconds(); // => 51
						var temp2 = "";
						var temp1 = "";
						var str2 = d2;
						var dt2  = str2.substring(0,2);
						var mon2 = str2.substring(3,5);
						var yr2  = str2.substring(6,10); 
						//mm=mm-1;
						temp1 = hh +":" + mm +":" + ss ; 
						temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
						var ctd = Date.parse(temp2,temp1);
						var date2 = new Date(ctd);
						var age = date1.getFullYear() - date2.getFullYear();
						var m = date1.getMonth() - date2.getMonth(); 
				//alert('Future Date Check Running AP in future date>>>>>>>>>>>>>>>>>>>>>>>>> ...');
				if(date1 < date2|| isNaN(date2)) 
							{ 
								com.newgen.omniforms.util.showError(controlName,"Future date is not allowed!!!!!");
								//alert('Future date is not allowed!!!!!');
								setNGValue(controlName,"" );
								//setNGFocus(controlName);
								return false;
							}
    return true;

}*/


function Noofmonths_AP(controlName) {

    var enteredDate=com.newgen.omniforms.formviewer.getNGValue(controlName);
	var Nomonths;
	var dateParts = enteredDate.split("/");	
	var date1 = new Date(dateParts[2], dateParts[1] - 1, dateParts[0]);
	//var date1 = new Date(enteredDate);
	var date2 = new Date();
	/*alert(date1);
	alert(date2);
	alert(date1.getFullYear());
	alert(date2.getFullYear());
	*/
    Nomonths= (date2.getFullYear() - date1.getFullYear()) * 12;
	/*alert('Yr:'+Nomonths);
	alert('Month dt1 :'+date1.getMonth() );
	alert('Month dt2 :'+date2.getMonth() );
	*/
    Nomonths-= date1.getMonth() + 1;
	//alert('dt1 Month:'+Nomonths);
    Nomonths+= date2.getMonth() +1; // we should add + 1 to get correct month number
	//alert('Nomonths:'+Nomonths);
    return Nomonths <= 0 ? 0 : Nomonths;
}
function Noofdays_AP_bw_2dt(enteredDate1,enteredDate2) {

    //var enteredDate1=com.newgen.omniforms.formviewer.getNGValue(controlName1);
	//var enteredDate2=com.newgen.omniforms.formviewer.getNGValue(controlName2);	
	var dateParts1 = enteredDate1.split("/");	
	var date1 = new Date(dateParts1[2], dateParts1[1] - 1, dateParts1[0]);
	//var date1 = new Date(enteredDate);
	var dateParts2 = enteredDate2.split("/");
	var date2 = new Date(dateParts2[2], dateParts2[1] - 1, dateParts2[0]);
	//alert(date1);
	//alert(date2);
	
	var oneDay = 24*60*60*1000; 
	//alert(oneDay);
	var diffDays = Math.round(Math.abs((date1.getTime() - date2.getTime())/(oneDay)));
	//alert(diffDays);
		
    return diffDays;
}

function Noofdays_AP_bw_2dt_ER(controlName1,controlName2) {

    var enteredDate1=com.newgen.omniforms.formviewer.getNGValue(controlName1);
	var enteredDate2=com.newgen.omniforms.formviewer.getNGValue(controlName2);	
	var dateParts1 = enteredDate1.split("/");	
	var date1 = new Date(dateParts1[2], dateParts1[1] - 1, dateParts1[0]);
	//var date1 = new Date(enteredDate);
	var dateParts2 = enteredDate2.split("/");
	var date2 = new Date(dateParts2[2], dateParts2[1] - 1, dateParts2[0]);
	//alert(date1);
	//alert(date2);
	
	var oneDay = 24*60*60*1000; 
	//alert(oneDay);
	var diffDays = Math.round(Math.abs((date1.getTime() - date2.getTime())/(oneDay)));
	//alert(diffDays);
		
    return diffDays;
}

function futuredate_AP_bw_2dt(controlName1,controlName2) {

    var enteredDate1=com.newgen.omniforms.formviewer.getNGValue(controlName1);
	var enteredDate2=com.newgen.omniforms.formviewer.getNGValue(controlName2);	
	var dateParts1 = enteredDate1.split("/");	
	var date1 = new Date(dateParts1[2], dateParts1[1] - 1, dateParts1[0]);
	//var date1 = new Date(enteredDate);
	var dateParts2 = enteredDate2.split("/");
	var date2 = new Date(dateParts2[2], dateParts2[1] - 1, dateParts2[0]);
	//alert(date1);
	//alert(date2);
	 if(date1>date2)
	 
	 {
	 //alert('First date is greater than second date');
	 return false;
	 }
		
    return true;
}
function datecompare_AP(controlName1,controlName2)
{

	var enteredDate1=com.newgen.omniforms.formviewer.getNGValue(controlName1);
	var enteredDate2=com.newgen.omniforms.formviewer.getNGValue(controlName2);	
	var dateParts1 = enteredDate1.split("/");	
	var date1 = new Date(dateParts1[2], dateParts1[1] - 1, dateParts1[0]);
	//var date1 = new Date(enteredDate);
	var dateParts2 = enteredDate2.split("/");
	var date2 = new Date(dateParts2[2], dateParts2[1] - 1, dateParts2[0]);
	//alert(date1);
	//alert(date2);
	
	if(date1>date2)
	 
	 {
	 //alert('First date is greater than second date');
	 com.newgen.omniforms.util.showError(controlName2,"From date should be lower than the to date !!!");
	 return false;
	 }
		
    return true;

}
/*
function datecompare_AP2(controlName1,controlName2)
{	
				
				var dt3 =	com.newgen.omniforms.formviewer.getNGValue(controlName1);
				var dt4 =	com.newgen.omniforms.formviewer.getNGValue(controlName2);
						var date1= new Date(); 
						var hh=date1.getHours(); // => 9
						var mm=date1.getMinutes(); // =>  30
						var ss=date1.getSeconds(); // => 51
						var temp2 = "";
						var temp1 = "";
						var str2 = dt3;
						var dt2  = str2.substring(0,2);
						var mon2 = str2.substring(3,5);
						var yr2  = str2.substring(6,10); 
						temp1 = hh +":" + mm +":" + ss ; 
						temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
						var ctd1 = Date.parse(temp2,temp1);
						var date3 = new Date(ctd1);
						 
						var hh=date1.getHours(); // => 9
						var mm=date1.getMinutes(); // =>  30
						var ss=date1.getSeconds(); // => 5
						var temp2 = "";
						var temp1 = "";
						var str2 = dt4;
						var dt2  = str2.substring(0,2);
						var mon2 = str2.substring(3,5);
						var yr2  = str2.substring(6,10); 
						//mm=mm+2;
						temp1 = hh +":" + mm +":" + ss ; 
						temp2 = mon2 + "/" + dt2 + "/" + yr2 + " " +temp1 ;
						var ctd2 = Date.parse(temp2,temp1);
						var date4 = new Date(ctd2);
				
				
				//alert("From Date:"+date3);
				//alert("To Date:"+date4);
				//alert('Future Date Check Running AP in Date compare>>>>>>>>>>>>>> ...');
				if(date3 > date4 || isNaN(date3) || isNaN(date4)) 
							{ 
								com.newgen.omniforms.util.showError(controlName2,"From date should be lower than the to date!!!!!");
								//alert('From date should be lower than the to date!!!!!');								
								//setNGValue(controlName2,"" );
								//setNGBackColor(controlName2, new Color(123, 255, 250));
								//setNGFocus(controlName2);
								return false;
							}
    return true;

}*/

//Added bala on 15-12-2016
//Documents type validate function
function validateDocumentType(sInputDocName, sDisplayStr)
{
    try
    {
        var xmlOut = window.parent.getInterfaceData("DLIST"); //list the doc type values
        var sDocName = "";
        while (xmlOut.indexOf("<DocumentName>") > 0)
        {
            sDocName = sDocName + xmlOut.substring(xmlOut.indexOf('<DocumentName>') + 14, xmlOut.indexOf('</DocumentName>')) + "||";
            xmlOut = xmlOut.substring(xmlOut.indexOf('</Document>') + 11, xmlOut.length);//for multiple Documents 
        }
        //alert(sDocName);
        if (sDocName.indexOf(sInputDocName) == -1)
        {
            //alert(sDocName);
			com.newgen.omniforms.util.showError("btn_ImportDoc",sDisplayStr + " document is mandatory");
            //alert(sDisplayStr + " document is mandatory");
            return false;
        }
    }
    catch (ex) 
	{
    }
    return true;
}


function ValidateSubmitAP()
{
	//alert("AP.js="+processName);
	//alert("AP.js="+activityName);
	//Below code for initiation and indexing
	if(processName=='AP')  
	{
		//alert("activityName="+activityName);
		//alert("Value="+getNGValue("InitSts"));
		if (((activityName=='ER_Initiation')|| (activityName=='Rework')) || ( (activityName=='Indexing') && (getNGValue("InitSts")=='ER') )) 
		{
			//for amount calculation
			//var brokage=getNGValue('Amount');
			
			
			
			   //alert("Inside indexing/Initiation");
			if (!( 
                        mandateCheck_AP('DateOfReq', 'date of request')
						//&& futuredate_AP('DateOfReq')
						&& mandateCheck_AP('TypeOfProcess', 'type of process')
						&& mandateCheck_AP('CompanyCode',' company code')
						&& mandateCheck_AP('Region', 'region')
						&& mandateCheck_AP('TypeOfInvoice', 'type of invoice')
						&& mandateCheck_AP('SubCategory1', 'subcategory1')
						&& mandateCheck_AP('RequestFor', 'request for')
						&& mandateCheck_AP('EmployeeCode', 'employee code')
						&& mandateCheck_AP('EmployeeName', 'employee name')
						&& mandateCheck_AP('VendorCode', 'vendor code')
						&& mandateCheck_AP('Designation', 'designation')
						&& mandateCheck_AP('Department', 'department')
						&& mandateCheck_AP('Grade', 'grade')
						&& mandateCheck_AP('CostCenter', 'cost center')
						&& mandateCheck_AP('BusinessArea', 'business area')
						&& mandateCheck_AP('OriginalLocation', 'original location')
						//&& mandateCheck_AP('TotalAmount', 'total amount')
						
						)
						) 
				
				{
					return false;
				}
				var strTypeofinvoice=getNGValue('TypeOfInvoice');
				var strSubcategory=getNGValue('SubCategory1');
				
				if(strSubcategory=='Mobile Re-Imbursements')
				{
					var BillValue=getNGValue('BillValueLessTax');
					var Personal=getNGValue('ValueOfPersonalCalls');
					var ST=getNGValue('ServiceTax_BillValue');
					var PersonalST=getNGValue('ServiceTax_ValueOfPersonalCalls');
					var temp6=((ST)-(PersonalST));
					var mobiletot=(BillValue)-(Personal)+(temp6);
					//alert("TotalAmount:"+mobiletot);
					setNGValue('TotalAmount',mobiletot);
					if (!( 
                        mandateCheck_AP('MobileNo', 'mobile number')
						&& mandateCheck_AP('BillDate', 'bill date')
						&& futuredate_AP('BillDate')
						&& mandateCheck_AP('CompanyCode',' company code')
						//&& mandateCheck_AP('EligibleAmount_MobileClaim', 'eligible amount')
						//&& mandateCheck_AP('BlackBerryCharges', 'BLACKBERRY CHARGES')
						&& mandateCheck_AP('FromPeriod', 'from period')
						&& futuredate_AP('FromPeriod')
						&& mandateCheck_AP('ToPeriod', 'to period')
						&& futuredate_AP('ToPeriod')
						&& datecompare_AP('FromPeriod','ToPeriod')
						&& mandateCheck_AP('BillPlan', 'bill plan')
						&& mandateCheck_AP('ServiceProvider', 'service provider')
						&& mandateCheck_AP('ConType','connection type')
						&& mandateCheck_AP('BillValueLessTax', 'bill value less service tax')
						//&& mandateCheck_AP('ServiceTax_BillValue', 'SERVICE TAX IN BILL VALUE LESS SERVICE TAX')
						&& mandateCheck_AP1('ValueOfPersonalCalls', 'value of personal calls')
						//&& mandateCheck_AP('ServiceTax_ValueOfPersonalCalls', 'SERVICE TAX IN VALUE OF PERSONAL CALLS')
						&& mandateCheck_AP('MBillNo', 'mobile bill number')
						//&& mandateCheck_AP('TotalAmount', 'TOTAL AMOUNT')
						)						
						)
						{
						return false;
						}
						if(getNGValue('BillPlan')=='Others')
						{
							if (!( 
							mandateCheck_AP('BillPlanOthers', 'bill plan others')))
							{
							return false;
							}
						}
						
						if(getNGValue('ConType') != 'Prepaid') {
							if( parseInt( Noofdays_AP_bw_2dt(getNGValue('FromPeriod'),getNGValue('ToPeriod')))>=32)
							{
								com.newgen.omniforms.util.showError('FromPeriod',"From Period and To Period can't be more than 31 days");
								return false;
							}
						}
						/*
						//Changed from fromperiod to billdate and from 2 months to 3 months- By Harinath on 20/06/2016												 
						 if(parseInt(Noofmonths_AP('BillDate'))>3 && activityName=='ER_Initiation')
						 //if(parseInt(Noofmonths_AP('BillDate'))>7)
						 {						 
							com.newgen.omniforms.util.showError('BillDate',"Bill Date should be within last two months");
							//com.newgen.omniforms.util.showError('BillDate',"Bill Date should be with in January-2017");
							return false;
						 } //Ended By Harinath on 20/06/2016
						 */
						 if(!futuredate_AP_bw_2dt('FromPeriod','BillDate'))
						 {						
							com.newgen.omniforms.util.showError('FromPeriod',"From period can't be greater than bill date");
							return false;
						 }

						//Added By nanjunda Moorthy on 25/12/2016						
						//if(parseFloat(getNGValue("TotalAmount"))>parseFloat(getNGValue("EligibleAmount_MobileClaim")))						
						//{
							//alert("Total amount cannot be greater than eligible amount");
							//setNGFocus('EligibleAmount_MobileClaim');
						//	return false;
						//}					
				}
				if(strSubcategory=='Salary Advance' || strSubcategory=='House Rent Advance' || strSubcategory=='Imprest Cash')
				{
					var Advamnt=getNGValue('ClaimedAmount');
					//alert("Advance Amount :"+Advamnt);
					//alert('In Submit');
					setNGValue('TotalAmount',Advamnt);
					if (!( 
                        //mandateCheck_AP('BasicSalary', 'basic salary')
						//&& mandateCheck_AP('EligibleAmount', 'eligible amount')
						mandateCheck_AP('RepaymentSchedule','reyayment schedule')
						&& mandateCheck_AP('ClaimedAmount', 'claimed amount')
						)
						)
						{
							return false;
						}
						
						//Added By nanjunda Moorthy on 14/12/2016
						//if(strSubcategory=='Salary Advance' && (parseFloat(getNGValue("ClaimedAmount"))>parseFloat(getNGValue("EligibleAmount"))))
						if(parseFloat(getNGValue("ClaimedAmount"))>parseFloat(getNGValue("EligibleAmount")))				
						{
							//com.newgen.omniforms.util.showError(ClaimedAmount,"Claimed amount cannot be greater than eligible amount");
							//alert('In validation check');
							com.newgen.omniforms.util.showError('ClaimedAmount','Claimed amount cannot be greater than eligible amount..!!!');
							//showErrorAP('ClaimedAmount','Claimed amount cannot be greater than eligible amount');
							//alert("Claimed amount cannot be greater than eligible amount");
							//setNGFocus('ClaimedAmount');
							return false;
						}
				}
				if(strSubcategory=='Exceptional Advances')
				{
					var Advamnt=getNGValue('ClaimedAmount');					
					setNGValue('TotalAmount',Advamnt);
					if (!( 
                        //mandateCheck_AP('BasicSalary', 'basic salary')
						//&& mandateCheck_AP('RepaymentSchedule','reyayment schedule')
						mandateCheck_AP('ClaimedAmount', 'claimed amount')
						)
						)
						{
							return false;
						}
				}				
				if(strSubcategory=='Moving of Personal Effects')
				{
					var moving=0;
					if(getNGValue('RoadtaxYN')=='Yes')
					{
						var road=getNGValue('RoadTax');
						moving=parseFloat(moving)+parseFloat(road);
						if (!(mandateCheck_AP('RoadTax', 'road tax')))
						{
							setNGFocus(RoadTax);
							return false;
						}
					}
					if(getNGValue('LossYN')=='Yes')
					{
						var loss=getNGValue('LossOnPreClosureLease');
						moving=parseFloat(moving)+parseFloat(loss);
						if (!( 
                        mandateCheck_AP('LossOnPreClosureLease', 'loss on pre closure lease')					
						)
						)
						{
							setNGFocus(LossOnPreClosureLease);
							return false;
						}
					}
					if(getNGValue('OctroiYN')=='Yes')
					{
						var Octroi=getNGValue('OctroiPay');
						moving=parseFloat(moving)+parseFloat(Octroi);
						if (!( 
                        mandateCheck_AP('OctroiPay', 'octroi pay')					
						)
						)
						{
							setNGFocus(OctroiPay);
							return false;
						}
					}
					if(getNGValue('PackYN')=='Yes')
					{
						var pack=getNGValue('PackMove');
						moving=parseFloat(moving)+parseFloat(pack);
						if (!( 
                        mandateCheck_AP('PackMove', 'packers and movers')					
						)
						)
						{
							setNGFocus(PackMove);
							return false;
						}
					}
					if(getNGValue('SchlfeeYN')=='Yes')
					{
						if (!( 
                        mandateCheck_AP('SchlfeenoYN', 'no of children')					
						)
						)
						{
							setNGFocus(SchlfeenoYN);
							return false;
						}
							if(getNGValue('SchlfeenoYN')=='1')
							{
								var fee=getNGValue('SchlfeeClaimamnt');
								moving=parseFloat(moving)+parseFloat(fee);
								if (!( 
								mandateCheck_AP('NameChild1', 'name of children1')	
								&&	mandateCheck_AP('SchlfeeElbamnt', 'eligible amount') 
								&&	mandateCheck_AP('SchlfeeClaimamnt', 'claimed amount')
								)
								)
								{
									return false;
								}
							}	
							if(getNGValue('SchlfeenoYN')=='2')
							{
								var fee=getNGValue('SchlfeeClaimamnt');
								moving=parseFloat(moving)+parseFloat(fee);
								if (!( 
								mandateCheck_AP('NameChild1', 'name of children1')	
								&&	mandateCheck_AP('NameChild2', 'name of children2')
								&&	mandateCheck_AP('SchlfeeElbamnt', 'eligible amount') 
								&&	mandateCheck_AP('SchlfeeClaimamnt', 'claimed amount')
								)
								)
								{
									return false;
								}
							}	
						
					}
					//var moving=fee+Octroi+road+loss+pack;
					setNGValue('TotalAmount',moving);
					//alert("TotalAmount:"+moving);
					if (!( mandateCheck_AP('TotalAmount', 'total amount')))
					{
						return false;
					}	 
					
				}
				if(strSubcategory=='Brokerage Fee')
				{
					if (!( 
						 //BROKAGE FEE
                        mandateCheck_AP('TypeOfTransfer', 'type of transfer')
						&& mandateCheck_AP('DateOfJoining', 'date of joining')
						&& futuredate_AP('DateOfJoining')
						//&& mandateCheck_AP('DateOfTransfer','DATE OF TRANSFER')
						//&& futuredate_AP('DateOfTransfer')
						&& mandateCheck_AP('Amount', 'amount')
						//&& mandateCheck_AP('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						//&& mandateCheck_AP('TypeOfTravel','TYPE OF TRAVEL')
						)
						)
						{
							return false;
						}
				}
				if(strSubcategory=='Joining Expense')
				{	
					/*frm_brokage_fees 
					frm_travel_fare
					frm_hotel_fare
					frm_convey
					frm_misc
					frm_medical_expense
					frm_summary*/
					if (!( //BROKAGE FEE
                        mandateCheck_AP('TypeOfTransfer', 'type of transfer')
						//&& mandateCheck_AP('DateOfJoining', 'DATE OF JOINING')
						//&& futuredate_AP('DateOfJoining')
						//&& mandateCheck_AP('DateOfTransfer','DATE OF TRANSFER')
						//&& futuredate_AP('DateOfTransfer')
						//&& mandateCheck_AP('Amount', 'AMOUNT')
						//&& mandateCheck_AP('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						//&& mandateCheck_AP('TypeOfTravel','TYPE OF TRAVEL')
						)
						)
						{
							return false;
						}
//						if(getNGValue("Trvlcount") == 0)
//						{
//                            alert('Kindly add atleast one Travel Fare details');
//                            return false;
//                        }
//						if(getNGValue("Hotelcount") == 0)
//						{
//                            alert('Kindly add atleast one Hotel Fare details');
//                            return false;
//                        } 
//						if(getNGValue("Conveycount") == 0)
//						{
//                            alert('Kindly add atleast one Conveyance details');
//                            return false;
//                        }
//						if(getNGValue("Misccount") == 0)
//						{
//                            alert('Kindly add atleast one Miscellaneous details');
//                            return false;
//                        }  
//						if(getNGValue("Medcount") == 0)
//						{
//                            alert('Kindly add atleast one Medical Expense details');
//                            return false;
//                        } 
						/*if(!( //summary
						mandateCheck_AP('TicketExpense', 'TICKET EXPENSE')
						&& mandateCheck_AP('HotelExpense','HOTEL EXPENSE')
						//&& mandateCheck_AP('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck_AP('Conveyance', 'CONVEYANCE')
						&& mandateCheck_AP('Miscellaneous','MISCELLANEOUS')
						&& mandateCheck_AP('MedicalExpense', 'MEDICAL EXPENSE')
						)
						)
						{
							return false;
						}*/
				}
				if(strSubcategory=='Look and See Visit')
				{
					/*
					frm_family_info
					frm_brokage_fees 
					frm_travel_fare
					frm_hotel_fare
					frm_daily_allw
					frm_convey
					frm_misc
					frm_summary
					if(getNGValue("FmlyCount") == 0)
						{
                            alert('Kindly add atleast one Family details');
                            return false;
                        }*/	 
					/*if (!( 
					//BROKAGE FEE
                        mandateCheck_AP('TypeOfTransfer', 'TYPE OF TRANSFER')
						&& mandateCheck_AP('DateOfJoining', 'DATE OF JOINING')
						&& futuredate_AP('DateOfJoining')
						//&& mandateCheck_AP('DateOfTransfer','DATE OF TRANSFER')
						//&& futuredate_AP('DateOfTransfer')
						//&& mandateCheck_AP('Amount', 'AMOUNT')
						&& mandateCheck_AP('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						&& mandateCheck_AP('TypeOfTravel','TYPE OF TRAVEL')
						)
						)
						{
							return false;
						}*/
//						if(getNGValue("Trvlcount") == 0)
//						{
//                            alert('Kindly add atleast one Travel Fare details');
//                            return false;
//                        } 
//						if(getNGValue("Hotelcount") == 0)
//						{
//                            alert('Kindly add atleast one Hotel Fare details');
//                            return false;
//                        }
//						
//						else(getNGValue("Dailycount") == 0)
//						{
//                            alert('Kindly add atleast one Daily Allowance details');
//                            return false;
//                        } 
//						if(getNGValue("Conveycount") == 0)
//						{
//                            alert('Kindly add atleast one Conveyance details');
//                            return false;
//                        }
//						if(getNGValue("Misccount") == 0)
//						{
//                            alert('Kindly add atleast one Miscellaneous details');
//                            return false;
//                        }
						/*if(!( //summary
						mandateCheck_AP('TicketExpense', 'TICKET EXPENSE')
						&& mandateCheck_AP('HotelExpense','HOTEL EXPENSE')
						&& mandateCheck_AP('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck_AP('Conveyance', 'CONVEYANCE')
						&& mandateCheck_AP('Miscellaneous','MISCELLANEOUS')
						//&& mandateCheck_AP('MedicalExpense', 'MEDICAL EXPENSE')
						)
						)
						{
							return false;
						}*/
				}
				if((strSubcategory=='Out of Pocket Expense')||(strSubcategory=='Relocation-Travel Expense'))
				{	
					 
					/*
					frm_family_info
					frm_brokage_fees 
					frm_travel_fare
					frm_daily_allw
					frm_convey
					frm_misc
					frm_summary
					if(getNGValue("FmlyCount") == 0)
						{
                            alert('Kindly add atleast one Family details');
                            return false;
                        }*/
					if (!(
						 //BROKAGE FEE
                        mandateCheck_AP('TypeOfTransfer', 'type of transfer')
						&& mandateCheck_AP('DateOfJoining', 'date of joining')
						&& futuredate_AP('DateOfJoining')
						//&& mandateCheck_AP('DateOfTransfer','DATE OF TRANSFER')
						//&& futuredate_AP('DateOfTransfer')
						//&& mandateCheck_AP('Amount', 'AMOUNT')
						//&& mandateCheck_AP('TravelReqNo', 'TRAVEL REQUEST NUMBER')
						&& mandateCheck_AP('TypeOfTravel','type of travel')
						)
						)
						{
							return false;
						}
//						if(getNGValue("Trvlcount") == 0)
//						{
//                            alert('Kindly add atleast one Travel Fare details');
//                            return false;
//                        } 
//						if(getNGValue("Dailycount") == 0)
//						{
//                            alert('Kindly add atleast one Daily Allowance details');
//                            return false;
//                        } 
//						if(getNGValue("Conveycount") == 0)
//						{
//                            alert('Kindly add atleast one Conveyance details');
//                            return false;
//                        }
//						if(getNGValue("Misccount") == 0)
//						{
//                            alert('Kindly add atleast one Miscellaneous details');
//                            return false;
//                        }
						/*if(!( //summary
						mandateCheck_AP('TicketExpense', 'TICKET EXPENSE')
						&& mandateCheck_AP('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck_AP('Conveyance', 'CONVEYANCE')
						&& mandateCheck_AP('Miscellaneous','MISCELLANEOUS')
						)
						)
						{
							return false;
						}*/
				}
				if(strSubcategory=='Relocation-TravelExpense-Own Vehicle')
				{
					/*
					frm_family_info
					frm_travel_fare
					frm_daily_allw
					frm_convey
					frm_misc
					frm_summary*/
//					if(getNGValue("FmlyCount") == 0)
//						{
//                            alert('Kindly add atleast one Family details');
//                            return false;
//                        }
//					if(getNGValue("Trvlcount") == 0)
//						{
//                            alert('Kindly add atleast one Travel Fare details');
//                            return false;
//                        } 
//						if(getNGValue("Dailycount") == 0)
//						{
//                            alert('Kindly add atleast one Daily Allowance details');
//                            return false;
//                        } 
//						if(getNGValue("Conveycount") == 0)
//						{
//                            alert('Kindly add atleast one Conveyance details');
//                            return false;
//                        }
//						if(getNGValue("Misccount") == 0)
//						{
//                            alert('Kindly add atleast one Miscellaneous details');
//                            return false;
//                        }
						/*if(!( //summary
						mandateCheck_AP('TicketExpense', 'TICKET EXPENSE')
						//&& mandateCheck_AP('HotelExpense','HOTEL EXPENSE')
						&& mandateCheck_AP('DailyAllowance', 'DAILY ALLOWANCE')
						&& mandateCheck_AP('Conveyance', 'CONVEYANCE')
						&& mandateCheck_AP('Miscellaneous','MISCELLANEOUS')
						)
						)
						{
							return false;
						}*/
				}
				if((strSubcategory=='Self Education Scheme')||(strSubcategory=='Entertainment')||(strSubcategory=='Others'))
				{
					
					/*
					frm_ent_scheme
					*/
					//com.newgen.omniforms.formviewer.getNGValue
//						if(getNGValue("EntCount") == 0)
//						{
//							//formObject.getItemCount("list_travel");
//                            alert('Kindly add atleast one Entertainment details');
//                            return false;
//                        }
						
				}
		   return true;
		}
	
		//alert("Activity Name="+activityName);
		if ((activityName=='Scanning')) 
		{
			 //alert("Inside Scanning=");
					if (!( 
                        mandateCheck_AP('DateOfReq', 'date of request')
						//&& futuredate_AP('DateOfReq')	
						&& mandateCheck_AP('TypeOfProcess', 'type of process')
						&& mandateCheck_AP('CompanyCode',' company code')
						&& mandateCheck_AP('Region', 'region')
						&& mandateCheck_AP('TypeOfInvoice', 'type of invoice')
						&& mandateCheck_AP('SubCategory1', 'subcategory1')
						&& mandateCheck_AP('SubCat2', 'subcategory3')
						&& mandateCheck_AP('SubCat3', 'subcategory3')
						)
						) 
				{
					//alert("Validation Fails");
					return false;
				}
				//alert("Initial valisation sucess");
				var strSubcategory=getNGValue('TypeOfProcess');
				
				if(strSubcategory=='PO')
				{
					if (!( 
                        mandateCheck_AP('PONumber', 'po number')
						&& mandateCheck_AP('VendCode', 'vendor code')
						&& mandateCheck_AP('VendName',' vendor name')
						&& mandateCheck_AP('FiscalYr', 'fiscal year')
						&& mandateCheck_AP('PurchaseGrp', 'purchasing group')
						&& mandateCheck_AP('InvoiceNo', 'invoice number')
						&& mandateCheck_AP('InvoiceDate', 'invoice date')
						&& futuredate_AP('InvoiceDate')
						//&& mandateCheck_AP('Currency', 'currency')
						&& mandateCheck_AP('TotInvoiceAmnt', 'total invoice amount')
						)
						) 
					{
					return false;
					}
				
				}
				else if(strSubcategory=='NONPO')
				{
					if (!( 
                           mandateCheck_AP('VendCode', 'vendor code')
						&& mandateCheck_AP('VendName',' company code')
						&& mandateCheck_AP('FiscalYr', 'fiscal year')
						//&& mandateCheck_AP('PurchaseGrp', 'PURCHASING GROUP')
						&& mandateCheck_AP('InvoiceNo', 'invoice number')
						&& mandateCheck_AP('InvoiceDate', 'invoice date')
						&& futuredate_AP('InvoiceDate')
						//&& mandateCheck_AP('Currency', 'currency')
						&& mandateCheck_AP('TotInvoiceAmnt', 'total invoice amount')
						)
						) 
					{
					return false;
					}
				
				}
				
			return true;
		}
		
		
		
	    if((activityName=='Manual_Initiation')||( (activityName=='Indexing') && (getNGValue("InitSts")=='TC') ))
		{
			var typeofprocess=getNGValue('TypeOfProcess');
			if (!( 
                        mandateCheck_AP('DateOfReq', 'date of request')
						//&& futuredate_AP('DateOfReq')	
						&& mandateCheck_AP('TypeOfProcess', 'type of process')
						&& mandateCheck_AP('CompanyCode',' company code')
						&& mandateCheck_AP('Region', 'region')
						&&mandateCheck_AP('TypeOfInvoice', 'type of invoice')
						&& mandateCheck_AP('SubCategory1', 'subcategory1')
						&& mandateCheck_AP('SubCat2', 'subcategory3')
						&& mandateCheck_AP('SubCat3', 'subcategory3')
						)
						) 
				{
					return false;
				}
				
				if(typeofprocess=='NONPO')
				{
					if (!( 
                           mandateCheck_AP('VendCode', 'vendor code')
						&& mandateCheck_AP('VendName',' vendor name')
						//&& mandateCheck_AP('FiscalYr', 'FISCAL YEAR')
						//&& mandateCheck_AP('PurchaseGrp', 'PURCHASING GROUP')
						&& mandateCheck_AP('InvoiceNo', 'invoice number')
						&& mandateCheck_AP('InvoiceDate', 'invoice date')
						&& futuredate_AP('InvoiceDate')
						//&& mandateCheck_AP('Currency', 'currency')
						&& mandateCheck_AP('TotInvoiceAmnt', 'total invoice amount')
						)
						) 
					{
					return false;
					}
				
				}
				
			return true;
		}
		if((activityName=='Parking')&& (getNGValue("InitSts")=='VP') )
		{
			var strSubcategory=getNGValue('TypeOfProcess');
			if(strSubcategory=='PO')
				{
					if (!( 
                        mandateCheck_AP('TanNo', 'tan number')
						&& mandateCheck_AP('StateCode', 'state code')
						&& mandateCheck_AP('TINNO',' tin number')
						&& mandateCheck_AP('ServiceTaxRegNo', 'service tax reg no')
						&& mandateCheck_AP('Assignment', 'assginment')
						&& mandateCheck_AP('BusiSec','business section')
						&& mandateCheck_AP('PaytermsCode', 'payterms code')
						&& mandateCheck_AP('DocHeadText', 'document header text')
						&& mandateCheck_AP('Text',' TEXT')
						//&& mandateCheck_AP('SearchTerm', 'SEARCH TERM')
						&& mandateCheck_AP('BaseLineDt',' baseline date')
						&& mandateCheck_AP('DueDate', 'due date')
						//&& mandateCheck_AP('SAPDocRefNo','SAP DOC REFERENCE NO')
						//&& mandateCheck_AP('MMDocNo', 'MM DOCUMENT NO')
						)
						) 
					{
					return false;
					}
				
				}
			if(strSubcategory=='NONPO')
				{
					if (!( 
                        mandateCheck_AP('TanNo', 'tan number')
						&& mandateCheck_AP('StateCode', 'state code')
						&& mandateCheck_AP('TINNO',' tin number')
						&& mandateCheck_AP('ServiceTaxRegNo', 'service tax reg no')
						&& mandateCheck_AP('Assignment', 'assginment')
						&& mandateCheck_AP('BusiSec','business section')
						&& mandateCheck_AP('PaytermsCode', 'payterms code')
						&& mandateCheck_AP('DocHeadText', 'document header text')
						&& mandateCheck_AP('BaseLineDt',' baseline date')
						//&& mandateCheck_AP('SAPDocRefNo','SAP DOC REFERENCE NO')
						)
						) 
					{
					return false;
					}
				
				}
			
			
			return true;
		}
		
		
	}
	return true;

}

//Added By Sivashankar KS on 15-July-2019 starts here
function check_gst(gst){
    if(gst.length != 15){
		com.newgen.omniforms.formviewer.setNGBackColor('txt_hotelfare_vendor_gst',"#F2F5A9");	
		com.newgen.omniforms.util.showError('txt_hotelfare_vendor_gst','Invalid Length of GSTIN');
        return false;
    }else{
        var state = parseInt(gst.substring(0, 2)); 
        // FIRST 2 CHARACTERS STATE CODE
        if(state < 1 || state > 37){
			com.newgen.omniforms.formviewer.setNGBackColor('txt_hotelfare_vendor_gst',"#F2F5A9");	
			com.newgen.omniforms.util.showError('txt_hotelfare_vendor_gst','Invalid First Two Characters of GSTIN');
            return false;
        }
		var txt_BritanniaGST = getNGValue('txt_hotelfare_britannia_gst');
		var txt_VendorGST = getNGValue('txt_hotelfare_vendor_gst');
		if (!(txt_BritanniaGST.substring(0,2) == txt_VendorGST.substring(0,2)))
		{
				com.newgen.omniforms.formviewer.setNGBackColor('txt_hotelfare_vendor_gst',"#F2F5A9");	
				com.newgen.omniforms.util.showError('txt_hotelfare_vendor_gst','Britannia GST & Vendor GST should be same state');
				return false;
		}
        // NEXT 10 CHARACTERS PAN NO. VALIDATION
        var pan = gst.substring(2, 12).toUpperCase();
        var regex = /[a-zA-Z]{3}[PCHFATBLJG]{1}[a-zA-Z]{1}[0-9]{4}[a-zA-Z]{1}$/;
        if( !regex.test(pan) ){
			com.newgen.omniforms.formviewer.setNGBackColor('txt_hotelfare_vendor_gst',"#F2F5A9");	
			com.newgen.omniforms.util.showError('txt_hotelfare_vendor_gst','Invalid GSTIN');
            return false;
        }
        // DEFAULT 14TH CHARACTER 'Z'
        var char14 = gst[13].toUpperCase();
        if(char14 != "Z"){
			com.newgen.omniforms.formviewer.setNGBackColor('txt_hotelfare_vendor_gst',"#F2F5A9");	
			com.newgen.omniforms.util.showError('txt_hotelfare_vendor_gst','14th character of GSTIN should be Z');
            return false;
        }
        // CHECKSUM DIGIT 
        if(check_gst_checksum(gst.substring(0, 14)) != gst[14]){
			com.newgen.omniforms.formviewer.setNGBackColor('txt_hotelfare_vendor_gst',"#F2F5A9");	
			com.newgen.omniforms.util.showError('txt_hotelfare_vendor_gst','Invalid GSTIN');
            return false;
        }

        return true;

    }
}
String.prototype.getw = function( value ) {
    for( var prop in this ) {
        if( this.hasOwnProperty( prop ) ) {
            if( this[ prop ] === value )
                return prop;
        }
    }
}
function check_gst_checksum(gst_wo){
    weight_c = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    gst = gst_wo.toUpperCase();
    var total_a1 = 0;
    for (var i = 0; i < gst.length; i++) {
        var weight = weight_c.getw(gst[i]);
        var factor = ( (i % 2) +1 );
        var product = weight * factor;
        var qu = Math.floor( product/36 );
        var re = product % 36;
        var a1 = qu + re;
        total_a1 += a1;
    }
    var d = total_a1 % 36;
    //var dd = 36 - d;
	var dd;
    if(d == 0){
		dd=0;
    }else{
    	dd = 36 - d;	
    }
    return weight_c[dd];
}
//Added By Sivashankar KS on 15-July-2019 ends here