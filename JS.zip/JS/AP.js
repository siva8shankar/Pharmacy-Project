
var activityName=window.parent.stractivityName;
var processName = window.parent.strprocessname;
var pid1=window.parent.strWorkitemName;
var date1= new Date();
var dynamicURL=window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');

/*
//Added by Harinatha R on 2017/10/06 Code to get current date with '/' separated
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();

if(dd<10) {
    dd = '0'+dd
}
if(mm<10) {
    mm = '0'+mm
}
today = dd + '/' + mm + '/' + yyyy;
//Ended by Harinatha R on 2017/10/06 Code to get current date with '/' separated

*/

/*function eventDispatchedAP(pEvent.type)
{
	alert("inside event dispatched AP.js :"+pEvent.type);
	return true;
}*/

//alert ("In Ap.js");




//For event handing function

function eventDispatched_AP(pId, pEvent) 
{
	// alert("inside Event Dispatched Funtion");

	window.status = pId + "_" + pEvent.type;
	//alert(pEvent.type+" "+pEvent.srcElement.id);
	var strSubcategory=getNGValue('SubCategory1');
	var strTypeOfInvoice=getNGValue('TypeOfInvoice');
	switch(pEvent.type)
    {           
       
	   case 'click':
        {
            switch(pEvent.srcElement.id)
            {
				case 'btn_sub':	
                {
				return true;
				}
				case 'btn_load':	
                {
				return true;
				}
				case 'btn_emp_detail':	
                {
				return true;
				
				}
				case 'btn_trvl_class':	
                {
				return true;
				
				}
				case 'btn_SAP_Vendor':	
                {
				return true;
				
				}
				case 'btn_po_up':	
                {
				return true;
				
				}
				case 'btn_po_down':	
                {
				return true;
				
				}
				case 'btn_biss_code':	
                {
				return true;
				
				}
				case 'btn_calc_totamnt':	
                {
				if(strSubcategory=='Salary Advance'||strSubcategory=='House Rent Advance')
				{
					var Advamnt=getNGValue('ClaimedAmount');
					//alert("Advance Amount :"+Advamnt);
					//aler('btn_calc_totamnt click');
					setNGValue('TotalAmount',Advamnt);
					if (!( 
                        mandateCheck_AP('BasicSalary', 'basic salary')
						//&& mandateCheck_AP('EligibleAmount', 'eligible amount')
						&& mandateCheck_AP('RepaymentSchedule','reyayment schedule')
						&& mandateCheck_AP('ClaimedAmount', 'claimed amount')
						)
						)
						{
							return false;
						}
						
						//Added By nanjunda Moorthy on 14/12/2016
						//if(strSubcategory=='Salary Advance' && (parseFloat(getNGValue("ClaimedAmount"))>parseFloat(getNGValue("EligibleAmount"))))
						if(parseFloat(getNGValue("ClaimedAmount"))>parseFloat(getNGValue("EligibleAmount")))				
						{
							//com.newgen.omniforms.util.showError(ClaimedAmount,"Claimed amount cannot be greater than eligible amount");
							showErrorAP('ClaimedAmount','Claimed amount cannot be greater than eligible amount');
							//alert("Claimed amount cannot be greater than eligible amount");
							setNGFocus('ClaimedAmount');
							return false;
						}
				}
				//else if(Moving of Personal Effects)				{				}				
				
				return true;
				}
				case 'btn_cmnthsty':	
                {				
				//Session id need to be captured here
                //var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				//alert('Pid1:'+Pid1);
				var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				//alert('WorkItemName:'+Pid2);
				//var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ID="+Sessionid+"&ProcessInstanceId="+Sessionid;
				var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ProcessInstanceId="+Pid1;
			    window.open(url,"","scrollbars=1,resizable=1,width=800,height=400");
			    return false;
				break;
				}
				
				case 'btn_DORMail':
			    {
					
				   var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				   var strInitBy = com.newgen.omniforms.formviewer.getNGValue("InitBy");
				   var w = 600;
				   var h = 600;
				   var left = Number((screen.width/2)-(w/2));
                   var tops = Number((screen.height/2)-(h/2));
				   
				   var url="/webdesktop/CustomJSP/APDORMail.jsp?ProcInstId="+Pid1+"&emailId="+strInitBy;

				   window.open(url,"","toolbar=no,directories=no, status=no, menubar=no,scrollbars=1,resizable=1,width=600,height=600,top="+tops+",left="+left+"");
				   return  false;
				   break;
			   }
				
			   case 'btn_trnsdtl':
				{
				//var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				var Emp_Code=com.newgen.omniforms.formviewer.getNGValue("EmployeeCode");
				//Below line added on 03-01-2017  by Bala G for set display details based on subcategory
				var Subcat_1=com.newgen.omniforms.formviewer.getNGValue("SubCategory1");
				//alert('Subcat_1='+Subcat_1);
                //alert("Sessionid :"+Emp_Code);
				var url="/webdesktop/CustomJSP/Transaction.jsp?ID1="+Emp_Code+"&SubCategory1="+Subcat_1+"&ProcessInstanceId="+Pid1;
				
				//var url="/webdesktop/CustomJSP/CommentsHistory.jsp?ProcessInstanceId="+Pid1;
			    window.open(url,"","scrollbars=1,resizable=1,width=800,height=400");
				return false;
				break;
			   }
			   case 'btn_Reject':
			   {
				    
				   if(!(mandateCheck_AP('Comments', 'comments')))
				   {
					   return false;
					   break;
				   }
				   /*if(!(mandateCheck_AP('RejectReason', 'RejectReason')))
				   {
					   return false;
					   break;
				   }*/
				   return true;
				   break;
			   }
			   case 'btn_submit':
			   {
//			     if(ValidateSubmitAP()) //Modified by bala on 15-12-2016  added docValidate con
//				 {
//				 return true;
//				 }
//				 else
//				 {
//				 return false;
//				 }

				if (activityName=='ER_Initiation' || activityName=='Rework') 				
				{
				if((strSubcategory=='House Rent Advance')||(strSubcategory=='Brokerage Fee')||(strSubcategory=='Joining Expense'))
				 {
					 //if((ValidateSubmitAP())&&(validateDocumentType('Supportingdocuments-1', 'Supportingdocuments-1')))
					 if((ValidateSubmitAP())&&(validateDocumentType('Invoice', 'Invoice')))
					 {
						return true;
					 }
					 else
					 {
						return false;
					 }
				 }
				 else if((strSubcategory=='Salary Advance') || (strSubcategory=='Exceptional Advances') ||(strSubcategory=='Travel Request') || (strSubcategory=='Imprest Cash')) 
					{
						//alert('Salary Advance submit>>>>');
						if(ValidateSubmitAP())
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					//Added By Harinath on 2017/06/21
					else if((strSubcategory=='Travel Expense')) 
					{				
												
						if(com.newgen.omniforms.formviewer.getLVWRowCount("list_daily")>=1 && com.newgen.omniforms.formviewer.getLVWRowCount("list_hotel")==0
							&& com.newgen.omniforms.formviewer.getLVWRowCount("list_convey")==0 && com.newgen.omniforms.formviewer.getLVWRowCount("list_misc")==0){ 

								if(ValidateSubmitAP())
								{
									return true;
								}
								else
								{
									return false;
								}
						
							}else{
								if((ValidateSubmitAP())&&(validateDocumentType('Invoice', 'Invoice')))
								{
									return true;
								}
								else
								{
									return false;
								}
							}
					
						
					}
					//Ended By Harinath on 2017/06/21
					else if((ValidateSubmitAP())&&(validateDocumentType('Invoice', 'Invoice')))
					 {
						
						return true;
					 }
					
				else
					 {
						return false;
					 }
				
				}//Enf of ER
				else if (activityName=='Scanning' || activityName=='Indexing') 
				{
						if((ValidateSubmitAP())&&(validateDocumentType('Invoice', 'Invoice')))
						 {
							return true;
						 }
						 else
						 {
							return false;
						 }
				}
				else if (activityName=='Manual_Initiation' ) 
				{
						if((ValidateSubmitAP())&&(validateDocumentType('Invoice', 'Invoice')))
						 {
							return true;
						 }
						 else
						 {
							return false;
						 }
				}
				
				else
				{
						return true;
				}
				 
				return true;
				break;
			   }
			   
			   
			   case 'btn_add_ent':
			   {
				   
				   if (!( 
                        mandateCheck_AP('txt_entschm_dtlofexp', 'details of expense')
						&& mandateCheck_AP('txt_entschm_billno', 'bill number')
						&& mandateCheck_AP('dp_entschm_billdate', 'bill date')
						&& futuredate_AP('dp_entschm_billdate')
						&& mandateCheck_AP('cb_entschm_accref', 'account reference')
						&&mandateCheck_AP('txt_entschm_glcode', 'gl code')
						&& mandateCheck_AP('txt_entschm_amnt', 'amount')
						)
						)
					{
					return false;
					}

					/*
					if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_entschm_billdate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_entschm_billdate',"Bill date can not be more than 90 days");
						return false;
					}

					*/
					
				   return true;
				   break;
			   }
			   case 'btn_mod_ent':
			   {
				   if (!( 
                        mandateCheck_AP('txt_entschm_dtlofexp', 'details of expense')
						&& mandateCheck_AP('txt_entschm_billno', 'bill number')
						&& mandateCheck_AP('dp_entschm_billdate', 'bill date')
						&& futuredate_AP('dp_entschm_billdate')
						&& mandateCheck_AP('cb_entschm_accref', 'account reference')
						&&mandateCheck_AP('txt_entschm_glcode', 'gl code')
						&& mandateCheck_AP('txt_entschm_amnt', 'amount')
						)
						)
					{
					return false;
					}

					/*
					if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_entschm_billdate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_entschm_billdate',"Bill date can not be more than 90 days");
						return false;
					}

				  */
					return true;
					break;
			   }
			   case 'btn_del_ent':
			   {
				   return true;
				   break;
			   }
			   case 'btn_add_trvl':
			   {   
				   if(strSubcategory=='Travel Request'){
					if (!( 
                        mandateCheck_AP('txt_trvl_fromloc', 'from location')
						&& mandateCheck_AP('txt_trvl_toloc', 'to location')
						&& mandateCheck_AP('dp_trvl_trvl', 'date of travel')						
						&& mandateCheck_AP('cb_trvl_mode', 'travel mode')
						&& mandateCheck_AP('cb_trvl_class', 'travel class')
						)
						)
						{
							return false;
						}

					/*
						if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_trvl_trvl'),today))>=92)
						{
							com.newgen.omniforms.util.showError('dp_trvl_trvl',"Travel date can not be more than 90 days");
							return false;
						}

					*/
				   }
				   	else{
				   //Modified By Harinath on 2017/07/03
						if (!( 
							mandateCheck_AP('txt_trvl_fromloc', 'from location')
							&& mandateCheck_AP('txt_trvl_toloc', 'to location')
							&& mandateCheck_AP('dp_trvl_trvl', 'date of travel')
							&& futuredate_AP('dp_trvl_trvl')
							&& mandateCheck_AP1('cb_trvl_hh', 'time of travel hours')
							&& mandateCheck_AP1('cb_trvl_mm', 'time of travel minutes')
							&& mandateCheck_AP('cb_trvl_mode', 'travel mode')
							&& mandateCheck_AP('cb_trvl_class', 'travel class')
							//&& mandateCheck_AP('txt_trvl_tcktno', 'ticket number')
							&& mandateCheck_AP('cb_trvl_paidby', 'paid by')
							&& mandateCheck_AP('txt_trvl_amnt', 'travel amount')
							)
							)
							{
								return false;
							}
							
						if(getNGValue("cb_trvl_mode") !='Self'){
							if (!(mandateCheck_AP('txt_trvl_tcktno', 'ticket number')
								&& mandateCheck_AP('txt_trvl_amnt', 'travel amount')
							))
							{
								return false;
							}
					
						}	

						/*
						if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_trvl_trvl'),today))>=92)
						{
							com.newgen.omniforms.util.showError('dp_trvl_trvl',"Travel date can not be more than 90 days");
							return false;
						}

						*/
					//Ended By Harinath on 2017/07/03
					}
					
					
					return true;
				    break;
			   }
			   case  'btn_mod_trvl':
			   {	 
				   if(strSubcategory=='Travel Request'){
					if (!( 
                        mandateCheck_AP('txt_trvl_fromloc', 'from location')
						&& mandateCheck_AP('txt_trvl_toloc', 'to location')
						&& mandateCheck_AP('dp_trvl_trvl', 'date of travel')						
						&& mandateCheck_AP('cb_trvl_mode', 'travel mode')
						&& mandateCheck_AP('cb_trvl_class', 'travel class')
						)
						)
					{
					return false;
					}

					/*
					 if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_trvl_trvl'),today))>=92)
					 {
						com.newgen.omniforms.util.showError('dp_trvl_trvl',"Travel date can not be more than 90 days");
						return false;
					 }

					*/	
				   }
				   
				   else{
					//Modified By Harinath on 2017/07/03
						if (!( 
							mandateCheck_AP('txt_trvl_fromloc', 'from location')
							&& mandateCheck_AP('txt_trvl_toloc', 'to location')
							&& mandateCheck_AP('dp_trvl_trvl', 'date of travel')
							&& futuredate_AP('dp_trvl_trvl')
							&& mandateCheck_AP1('cb_trvl_hh', 'time of travel hours')
							&& mandateCheck_AP1('cb_trvl_mm', 'time of travel minutes')
							&& mandateCheck_AP('cb_trvl_mode', 'travel mode')
							&& mandateCheck_AP('cb_trvl_class', 'travel class')
							//&& mandateCheck_AP('txt_trvl_tcktno', 'ticket number')
							&& mandateCheck_AP('cb_trvl_paidby', 'paid by')
							&& mandateCheck_AP('txt_trvl_amnt', 'travel amount')
							)
							)
							{
								return false;
							}
							
							if(getNGValue("cb_trvl_mode") !='Self'){
								if (!(mandateCheck_AP('txt_trvl_tcktno', 'ticket number')
								&& mandateCheck_AP('txt_trvl_amnt', 'travel amount')
								))
								{
									return false;
								}
					
							}

							/*
							if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_trvl_trvl'),today))>=92)
						    {
								com.newgen.omniforms.util.showError('dp_trvl_trvl',"Travel date can not be more than 90 days");
								return false;
						    }

							*/
						//Ended By Harinath on 2017/07/03
						}
					
					return true;
				    break;
				}
				case 'btn_del_trvl':
			   {
				   return true;
				   break;
			   }
			   case 'btn_add_fmly':
			   {
					if (!( 
                        mandateCheck_AP('txt_fmly_name', 'name of person')
						&& mandateCheck_AP('cb_fmlyinfo_reln', 'relationship with employee')
						)
						)
					{
					return false;
					}
					return true;
				    break;
			   }
			   case 'btn_mod_fmly':
			   {
					if (!( 
                        mandateCheck_AP('txt_fmly_name', 'name of person')
						&& mandateCheck_AP('cb_fmlyinfo_reln', 'relationship with employee')
						)
						)
					{
					return false;
					}
					return true;
				    break;
			   }
			   case 'btn_del_fmly':
			   {
				   return true;
				   break;
			   }
			   case 'btn_add_htl':
			   {	
					
				   if(!(
					mandateCheck_AP('dp_hotelfare_checkindt', 'check in date')
					&& futuredate_AP('dp_hotelfare_checkindt')
					&& mandateCheck_AP('dp_hotelfare_checkoutdt', 'check out date')
					&& futuredate_AP('dp_hotelfare_checkoutdt')
					&& datecompare_AP('dp_hotelfare_checkindt','dp_hotelfare_checkoutdt')
					&& mandateCheck_AP('cb_hotelfare_paidby', 'paid by')
					&& mandateCheck_AP('txt_hotelfare_amnt', 'amount')
					&& mandateCheck_AP('txt_hotelfare_particulars', 'particulars')
					&& mandateCheck_AP('HF_BillNo', 'Bill No')
					)
					)
				   {
					   return false;
				   }

				   /*
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_hotelfare_checkindt'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_hotelfare_checkindt',"Check In date can not be more than 90 days");
						return false;
					}
					if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_hotelfare_checkoutdt'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_hotelfare_checkoutdt',"Check Out date can not be more than 90 days");
						return false;
					}

				   */
					return true;
				   break;
			   }
			   case 'btn_mod_htl':
			   {
					
				   if(!(
					mandateCheck_AP('dp_hotelfare_checkindt', 'check in date')
					&& futuredate_AP('dp_hotelfare_checkindt')
					&& mandateCheck_AP('dp_hotelfare_checkoutdt', 'check out date')
					&& futuredate_AP('dp_hotelfare_checkoutdt')
					&& datecompare_AP('dp_hotelfare_checkindt','dp_hotelfare_checkoutdt')
					&& mandateCheck_AP('cb_hotelfare_paidby', 'paid by')
					&& mandateCheck_AP('txt_hotelfare_amnt', 'amount')
					&& mandateCheck_AP('txt_hotelfare_particulars', 'particulars')
					&& mandateCheck_AP('HF_BillNo', 'Bill No')
					)
					)
				   {
					   return false;
				   }

				   /*
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_hotelfare_checkindt'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_hotelfare_checkindt',"Check In date can not be more than 90 days");
						return false;
					}
					if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_hotelfare_checkoutdt'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_hotelfare_checkoutdt',"Check Out date can not be more than 90 days");
						return false;
					}

				   */
				   	return true;
				   break;
			   }
			   case 'btn_del_htl':
			   {
				   return true;
				   break;
			   }
			   //Modified By Harinath on 2017/07/24
			   case 'btn_add_dly':
			   {
				  
					if(!(
					mandateCheck_AP('dp_dailyallw_fromdate', 'from date')
					&& futuredate_AP('dp_dailyallw_fromdate')
					&& mandateCheck_AP('dp_dailyallw_todate', 'to date')
					&& futuredate_AP('dp_dailyallw_todate')
					&& datecompare_AP('dp_dailyallw_fromdate','dp_dailyallw_todate')
					&& mandateCheck_AP('txt_dailyallw_noofdays', 'number of days')
					&& mandateCheck_AP('txt_dailyallw_entilperday', 'entitled per day')
					&& mandateCheck_AP('txt_dailyallw_calcda', 'calculated da')
					&& mandateCheck_AP('txt_dailyallw_actualdaclaim', 'actual da claimed')
					)
					)
				   {
					   return false;
				   }
				   
				   if(getNGValue('Grade') == 'Management Trainee'){
						if(!(
							mandateCheck_AP('txt_dailyallw_CityType', 'City Type')
							&& mandateCheck_AP('txt_dailyallw_City', 'City')					
						))
						{
							return false;
						}
				   }

				   /*
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_dailyallw_fromdate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_dailyallw_fromdate',"Daily allowance From date can not be more than 90 days");
						return false;
					}
				   
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_dailyallw_todate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_dailyallw_todate',"Daily allowance To date can not be more than 90 days");
						return false;
					}

				   */
				   return true;
				   break;				  
			   }
			   case 'btn_mod_dly':
			   {
					
				   if(!(
					mandateCheck_AP('dp_dailyallw_fromdate', 'from date')
					&& futuredate_AP('dp_dailyallw_fromdate')
					&& mandateCheck_AP('dp_dailyallw_todate', 'to date')
					&& futuredate_AP('dp_dailyallw_todate')
					&& datecompare_AP('dp_dailyallw_fromdate','dp_dailyallw_todate')
					&& mandateCheck_AP('txt_dailyallw_noofdays', 'number of days')
					&& mandateCheck_AP('txt_dailyallw_entilperday', 'entitled per day')
					&& mandateCheck_AP('txt_dailyallw_calcda', 'calculated da')
					&& mandateCheck_AP('txt_dailyallw_actualdaclaim', 'actual da claimed')
					//&& mandateCheck_AP('DA_BillNo', 'Bill No')
					)
					)
				   {
					   return false;
				   }
				   
				   if(getNGValue('Grade') == 'Management Trainee'){
						if(!(
							mandateCheck_AP('txt_dailyallw_CityType', 'City Type')
							&& mandateCheck_AP('txt_dailyallw_City', 'City')					
						))
						{
							return false;
						}
				   }

				   /*
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_dailyallw_fromdate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_dailyallw_fromdate',"Daily allowance From date can not be more than 90 days");
						return false;
					}
				   
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_dailyallw_todate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_dailyallw_todate',"Daily allowance To date can not be more than 90 days");
						return false;
					}

				   */
				   return true;
				   break;				  
			   }
			   //Ended By Harinath on 2017/07/24
			   case 'btn_del_dly':
			   {
				   return true;
				   break;
			   }
			   case 'btn_add_con':
			   { 
					
				   
					if(!(
					mandateCheck_AP('dp_convey_fromdate', 'from date')
					&& futuredate_AP('dp_convey_fromdate')
					&& mandateCheck_AP('dp_convey_todate', 'to date')
					&& futuredate_AP('dp_convey_todate')
					&& datecompare_AP('dp_convey_fromdate','dp_convey_todate')
					&& mandateCheck_AP('txt_convey_nameofcab', 'name of the cab')
					&& mandateCheck_AP('txt_convey_amnt', 'amount')
					&& mandateCheck_AP('txt_convey_particularls', 'particulars')
					&& mandateCheck_AP('Con_BillNo', 'Bill No')
					)
					)
				   {
					   return false;
				   }

				   /*
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_convey_fromdate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_convey_fromdate',"Conveyance From date can not be more than 90 days");
						return false;
					}
				   
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_convey_todate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_convey_todate',"Conveyance To date can not be more than 90 days");
						return false;
					}

				   */
				   return true;
				   break;
			   }
			   case 'btn_mod_con':
			   { 
					
					if(!(
					mandateCheck_AP('dp_convey_fromdate', 'from date')
					&& futuredate_AP('dp_convey_fromdate')
					&& mandateCheck_AP('dp_convey_todate', 'to date')
					&& futuredate_AP('dp_convey_todate')
					&& datecompare_AP('dp_convey_fromdate','dp_convey_todate')
					&& mandateCheck_AP('txt_convey_nameofcab', 'name of the cab')
					&& mandateCheck_AP('txt_convey_amnt', 'amount')
					&& mandateCheck_AP('txt_convey_particularls', 'particulars')
					&& mandateCheck_AP('Con_BillNo', 'Bill No')
					)
					)
				   {
					   return false;
				   }
				   

				   /*
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_convey_fromdate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_convey_fromdate',"Conveyance From date can not be more than 90 days");
						return false;
					}
				   
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_convey_todate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_convey_todate',"Conveyance To date can not be more than 90 days");
						return false;
					}

				   */
				   return true;
				   break;
			   }
			   case 'btn_del_con':
			   {
				   return true;
				   break;
			   }
			   case 'btn_add_misc':
			   {
				  
			
				  if(!(
					mandateCheck_AP('dp_misc_fromdate', 'from date')
					&& futuredate_AP('dp_misc_fromdate')
					&& mandateCheck_AP('dp_misc_todate', 'to date')
					&& futuredate_AP('dp_misc_todate')
					&& datecompare_AP('dp_misc_fromdate','dp_misc_todate')
					&& mandateCheck_AP('txt_misc_amnt', 'amount')
					&& mandateCheck_AP('txt_misc_particulars', 'particulars')
					&& mandateCheck_AP('Mis_BillNo', 'Bill No')
					)
					)
				   {
					   return false;
				   }				   

				   /*
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_misc_fromdate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_misc_fromdate',"Misc From date can not be more than 90 days");
						return false;
					}
				   
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_misc_todate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_misc_todate',"Misc To date can not be more than 90 days");
						return false;
					}

				   */
				   return true;
				   break;
			   }
			   case 'btn_mod_misc':
			   {				   

				  if(!(
					mandateCheck_AP('dp_misc_fromdate', 'from date')
					&& futuredate_AP('dp_misc_fromdate')
					&& mandateCheck_AP('dp_misc_todate', 'to date')
					&& futuredate_AP('dp_misc_todate')
					&& datecompare_AP('dp_misc_fromdate','dp_misc_todate')
					&& mandateCheck_AP('txt_misc_amnt', 'amount')
					&& mandateCheck_AP('txt_misc_particulars', 'particulars')
					)
					)
				   {
					   return false;
				   }

				   /*
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_misc_fromdate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_misc_fromdate',"Misc From date can not be more than 90 days");
						return false;
					}
				   
				   if(parseInt(Noofdays_AP_bw_2dt(getNGValue('dp_misc_todate'),today))>=92)
					{
						com.newgen.omniforms.util.showError('dp_misc_todate',"Misc To date can not be more than 90 days");
						return false;
					}

				   */
				   return true;
				   break;
			   }
			   case 'btn_del_misc':
			   {
				   return true;
				   break;
			   }
			   case 'btn_add_med':
			   { 
			   
				  if(!(
					mandateCheck_AP('dp_medexp_fromdate', 'from date')
					&& futuredate_AP('dp_medexp_fromdate')
					//&& mandateCheck_AP('dp_medexp_todate', 'TO DATE')
					//&& futuredate_AP('dp_medexp_todate')
					//&& datecompare_AP('dp_medexp_fromdate','dp_medexp_todate')
					&& mandateCheck_AP('txt_medexp_amnt', 'amount')
					&& mandateCheck_AP('txt_medexp_particulars', 'particulars')
					)
					)
				   {
					   return false;
				   }
				   return true;
				   break;
			   }
			   case 'btn_mod_med':
			   { 
			   			   

				  if(!(
					mandateCheck_AP('dp_medexp_fromdate', 'from date')
					&& futuredate_AP('dp_medexp_fromdate')
					//&& mandateCheck_AP('dp_medexp_todate', 'TO DATE')
					//&& futuredate_AP('dp_medexp_todate')
					//&& datecompare_AP('dp_medexp_fromdate','dp_medexp_todate')
					&& mandateCheck_AP('txt_medexp_amnt', 'amount')
					&& mandateCheck_AP('txt_medexp_particulars', 'particulars')
					)
					)
				   {
					   return false;
				   }
				   return true;
				   break;
			   }
			   case 'btn_del_med':
			   {
				   return true;
				   break;
			   }
			   case 'btn_add_nonpo' :
			   {
						if(!(
						//mandateCheck_AP('txt_line_sino_nonpo', 'SI NO')
						mandateCheck_AP('txt_line_nonpotext', 'line item text')
						&& mandateCheck_AP('txt_line_itemamnt_nonpo','item amount')
						&& mandateCheck_AP('txt_line_plantcode_nonpo', 'plant code')
						&& mandateCheck_AP('txt_line_bussarea_nonpo', 'bussiness area')
						&& mandateCheck_AP('txt_line_taxcode_nonpo','tax code')
						&& mandateCheck_AP('txt_line_taxamnt_nonpo', 'tax amount')
						&& mandateCheck_AP('txt_line_glcode_nonpo','general ledger code')
						&& mandateCheck_AP('txt_line_cccode_nonpo','cost center code')
						&& mandateCheck_AP('txt_line_pccode_nonpo', 'profit centre code')
						&& mandateCheck_AP('txt_line_intorder_nonpo', 'internal order')
						&& mandateCheck_AP('txt_line_glindic_nonpo', 'special gl indicator')
						&& mandateCheck_AP('txt_line_wbsele_nonpo', 'wbs element')
						)
						)
					   {
						   return false;
					   }
					   return true;
					   break;
			   }
			   case 'btn_mod_nonpo' :
			   {
						if(!(
						mandateCheck_AP('txt_line_sino_nonpo', 'si no')
						&& mandateCheck_AP('txt_line_nonpotext', 'line item text')
						&& mandateCheck_AP('txt_line_itemamnt_nonpo','item amount')
						&& mandateCheck_AP('txt_line_plantcode_nonpo', 'plant code')
						&& mandateCheck_AP('txt_line_bussarea_nonpo', 'bussiness area')
						&& mandateCheck_AP('txt_line_taxcode_nonpo','tax code')
						&& mandateCheck_AP('txt_line_taxamnt_nonpo', 'tax amount')
						&& mandateCheck_AP('txt_line_glcode_nonpo','general ledger code')
						&& mandateCheck_AP('txt_line_cccode_nonpo','cost center code')
						&& mandateCheck_AP('txt_line_pccode_nonpo', 'profit centre code')
						&& mandateCheck_AP('txt_line_intorder_nonpo', 'internal order')
						&& mandateCheck_AP('txt_line_glindic_nonpo', 'special gl indicator')
						&& mandateCheck_AP('txt_line_wbsele_nonpo', 'wbs element')
						)
						)
					   {
						   return false;
					   }
					   return true;
					   break;
			   }
			   case 'btn_del_nonpo' :
			   {
			   return true;
			   }
			   case 'btn_Exception' :
			   {
			   return true;
			   }
			   case 'btn_Approve' :
			   {
					if(activityName == 'Parking'){
						setEnabled('btn_Approve', false);
					}
				return true;
			   } 
			   case 'btn_park' :
			   {
					if(activityName == 'Parking'){	
						setEnabled('btn_park', false);
					}	
				return true;
			   }
			   case 'btn_Rescan' :
			   {
			   return true;
			   }
			   case 'btn_Rescan' :
			   {
			   return true;
			   }
			   case 'Btn_SAP' :
			   {
			   return true;
			   }
			   case 'btn_SAP_PO' :
			   {
			   return true;
			   }
			   case 'btn_ImportDoc':
			   {
			   //window.parent.openDocList();//To Load Document List from Document Button
			   
				   var flag = window.parent.ImportDocClick();// To Invoke Import Document Window
					if(flag==true) 
					{
						window.parent.openImportDocWin();
					}
				   return false;
				   break;
			   }
			   case 'btn_SAP_Post':
			   {
				   //window.parent.openDivElement('SAP0', 'FBV0', '' , 'SAP');
				   if(getNGValue("InitSts")=='ER'){ 
				   window.parent.openDivElement('SAP0', 'PostTCode', '' , 'SAP');
				   return true;
				   //break;
				   }
				   else if(getNGValue("InitSts")=='VP'){ 
				   
				   return true;				   
				   }
				   else if(getNGValue("InitSts")=='TC'){ 
				   window.parent.openDivElement('SAP0', 'PostTCode', '' , 'SAP');
				   return true;				   
				   }
				   
				   
			   }
			   
			   case 'btn_Travel':
			   {
				   //var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				   var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				   var sWID=getNGValue("WorkID");
				   //alert('Pid1:'+Pid1);
				   //alert('sWID:'+sWID);
				   var url="/webdesktop/CustomJSP/Travel_Xcel.jsp?ID1="+Pid1+"&WorkstepName="+activityName;
				   //window.open(url,"","width=900,height=900");
				   window.open(url,"","scrollbars=1,resizable=1,width=900,height=900");
				   return  false;
				   break;
			   }
			   case 'btn_Cab':
			   {
				   //var Pid1=com.newgen.omniforms.formviewer.getNGValue("PostSts");
				   var Pid1=com.newgen.omniforms.formviewer.getNGValue("WorkItemName");
				   var url="/webdesktop/CustomJSP/Cab_Xcel.jsp?ID1="+Pid1+"&WorkstepName="+activityName;
				   //alert("inside cab btn="+activityName);
				   //window.open(url,"","width=900,height=900");
				   window.open(url,"","scrollbars=1,resizable=1,width=900,height=900");
				   return  false;
				   break;
			   }
			   case 'btn_SAP_MPO':
			   {
			     //alert("Inside btn_SAP_MPO");
			     var CompCode=com.newgen.omniforms.formviewer.getNGValue("CompanyCode");
				 var VendorCode1=com.newgen.omniforms.formviewer.getNGValue("VendCode");
				 //alert("CompCode="+CompCode+";VendorCode="+VendorCode1);
				 var url1="/webdesktop/CustomJSP/MPO/Brit_MultiplePO_Main.jsp?CompanyCode="+CompCode+"&VendorCode="+VendorCode1;
				 
				 
				 //alert("dynamicURL:"+dynamicURL);				 
				 //url1=dynamicURL+url1;
			//alert("url1:"+url1);
			
			//var newWindow=window.open(url1,"","width=900,height=900");
				 //sURL=dynamicURL+"/webdesktop/Customisation/Sanmar_FetchPOFromVendorAndGRN_Main.jsp?CompanyCode="+strCompanyCode;
							var newWindow = window.showModalDialog(dynamicURL+url1, '', "dialogWidth:1000px;dialogHeight:1000px; help:no;border:thin; status:no; center:yes");
							
							//var newWindow = window.open(dynamicURL+url1, '', "dialogWidth:1000px;dialogHeight:1000px; help:no;border:thin; status:no; center:yes");
							
							//newWindow=window.returnValue;
							
							//alert("JSP Result in JS 2:"+newWindow);
							//window.location.href = newWindow;
							
				 setNGValue("Text_MPO_Output",newWindow.toString());
				 return true;
				 break;
			   }
			   
			   case 'btn_fromloc':
			   {			  
				return true;
			   }
			   case 'btn_toloc':
			   {
				return true;
			   }
			  
				
			}
			//alert("End of Click");
			//return true;
			return false;
			//break;
		}//End of Click
		case 'change':
		{
			switch (pEvent.srcElement.id)
			{
			case 'RequestFor':
				{
					if ((activityName=='ER_Initiation')|| (activityName=='Rework'))
					{
					var Request = getNGValue('RequestFor');
						setNGValue("CompanyCode", "");
                        setNGValue("Region", "");
                        setNGValue("EmployeeName", "");
                        setNGValue("VendorCode", "");
                        setNGValue("Designation", "");
                        setNGValue("Department", "");
                        setNGValue("Grade", "");
                        setNGValue("CostCenter", "");
                        setNGValue("BusinessArea", "");
                        setNGValue("OriginalLocation", "");
                        setNGValue("BasicSalary", "");
                        setNGValue("DateOfJoining", "");
                        setNGValue("DateOfTransfer", "");
                        setNGValue("PrevLoc", "");
                        setNGValue("PrevSubLoc", "");
						
						if (Request=="Others") {
                            setNGValue("EmployeeCode", "");
                            setLocked("EmployeeCode", false);
                        }
                        if (Request=="Self") {
                            setNGValue("EmployeeCode", "");
                            setLocked("EmployeeCode", true);
                        }
						if (Request=="Consultant") {
                            setNGValue("EmployeeCode", "");
                            setLocked("EmployeeCode", true);
                        }
					}
				return true;					
				}
			case 'EmployeeCode':
				{				
					/*if ((activityName=='ER_Initiation')|| (activityName=='Rework'))
					{
						setNGValue('CompanyCode', '');
                        setNGValue('Region', '');
                        setNGValue('EmployeeName', '');
                        setNGValue('VendorCode', '');
                        setNGValue('Designation', '');
                        setNGValue('Department', '');
                        setNGValue('Grade', '');
                        setNGValue('CostCenter', '');
                        setNGValue('BusinessArea', '');
						alert('EmployeeCode Change');
					}*/
				return false;					
				}
			case 'BillDate':
				{
					 if(!(futuredate_AP('BillDate')))
				   {
					   return false;
					  
				   }
				   
				break;	
				}
			//Modified By Harinath on 2017/03/27
			case 'TypeOfTravel':
			{	
				/*
				if(strTypeOfInvoice=='Travel Request'  && getNGValue('TypeOfTravel')=='Domestic'){
				setNGValue('txt_trvl_fromloc','');
				setNGValue('txt_trvl_toloc','');
				setEnabled('txt_trvl_fromloc',false);
				setEnabled('txt_trvl_toloc',false);
				
				}
				else
				{
				setNGValue('txt_trvl_fromloc','');
				setNGValue('txt_trvl_toloc','');
				setEnabled('txt_trvl_fromloc',true);
				setEnabled('txt_trvl_toloc',true);
				}
				*/
				return true;	
			}  
			case 'txt_trvl_fromloc': 
			{
				return true;                
			}
			case 'txt_trvl_toloc': 
			{
				return true;                
			}
			//Ended By Harinath on 2017/03/27
			
			//Added By Harinath on 2017/05/29
			case 'txt_trvl_tcktno': 
			{
				return true;                
			}
			//Ended By Harinath on 2017/05/29
			case 'FromPeriod':
				{
					 if(!(futuredate_AP('FromPeriod')))
				   {
					   return false;
				   }
				
					   break;		
				}
			case 'ToPeriod':
				{
				 if(!(futuredate_AP('ToPeriod')))
					{
					   return false;
					   
					}
				if(!(datecompare_AP('FromPeriod','ToPeriod')))
					{
					
					   return false;
					 }
					  break;
				}
				//Added by Deva on 25/12/2016
				case 'MobileNo':
				{
					var validatemobno = com.newgen.omniforms.formviewer.getNGValue('MobileNo');
					if (validatemobno.length<10)
						{
							com.newgen.omniforms.util.showError('MobileNo',"Mobile number should be 10 numbers!!!!!");
							//alert('Mobile number should be 10 numbers!!!!!');
							setNGFocus('MobileNo');
							return false;
						}
					else if ((validatemobno.charAt(0)!="9")&&(validatemobno.charAt(0)!="8")&&(validatemobno.charAt(0)!="7")&&(validatemobno.charAt(0)!="6"))
					   {
							
							com.newgen.omniforms.util.showError('MobileNo',"Mobile number should be start with 9 or 8 or 7 or 6!!!!!");
							//alert('Mobile number should be start with 9 or 8 or 7 or 6!!!!!');
							setNGFocus('MobileNo');
							return false
					   }
					   return true;
				}
				
				//
				case 'TypeOfInvoice':
				{
				return true;                
				}
				case 'BillPlan':
				{
				return true;                
				}
				case 'cb_trvl_mode':
				{
				return true;                
				}				
				case 'cb_trvl_class':
				{
				return true;                
				}
				case 'cb_entschm_accref':
				{
				return true;                
				}
				case 'cb_entschm_accref':
				{
				return true;                
				}
				//Added By Harinath 2017/03/21
				//Modified By Harinath 2017/07/07
				case 'dp_dailyallw_fromdate':
				{
					futuredate_AP('dp_dailyallw_fromdate');
					datecompare_AP('dp_dailyallw_fromdate','dp_dailyallw_todate');
					return true;                
				}
				case 'dp_dailyallw_todate':
				{
					futuredate_AP('dp_dailyallw_todate');
					datecompare_AP('dp_dailyallw_fromdate','dp_dailyallw_todate');
					return true;                
				}		
				case 'txt_dailyallw_actualdaclaim':
				{
					return true;                
				}				
				//Ended By Harinath 2017/07/07
				//Added By Harinath 2017/07/24
				case 'txt_dailyallw_CityType':
				{
				return true;                
				}
				case 'txt_dailyallw_City':
				{
				return true;                
				}
				//Ended By Harinath 2017/07/24 
				case 'txt_dailyallw_Loc':
				{
				return true;                
				}
			}
			//return true;
			return false;
			
		}
		case 'focus':
        {
            switch (pEvent.srcElement.id) 
            {  
			case 'BillValueLessTax':
			{
				return false;
                //break;
			}
			case 'ValueOfPersonalCalls':
			{
				return false;                
			}
			case 'ClaimedAmount':
			{
				return true;                
			}
			case 'RoadtaxYN':
			{
				return true;                
			}
			case 'LossYN':
			{
				return true;                
			}
			case 'OctroiYN':
			{
				return true;                
			}
			case 'PackYN':
			{
				return true;                
			}
			case 'SchlfeeYN':
			{
				return true;                
			}
			case 'SchlfeeClaimamnt':
			{
				return true;                
			}
			case 'SchlfeenoYN':
			{
				return true;                
			}
			case 'TypeOfProcess':
			{
				return true;                
			}
			case 'TotInvoiceAmnt':
			{
				return true;                
			}
			case 'ExchangeRate':
			{
				return true;                
			}
			
			
            }
			return false;
        }//End of Focus
		case 'blur':
        {
			//alert("blur");
			switch (pEvent.srcElement.id) 
            {  
			case 'BillValueLessTax':
			{
				return false;
                
			}
			case 'ValueOfPersonalCalls':
			{
				return false;               
			}
			case 'ClaimedAmount':
			{
				return true;                
			}
			case 'RoadtaxYN':
			{
				return true;                
			}
			case 'LossYN':
			{
				return true;                
			}
			case 'OctroiYN':
			{
				return true;                
			}
			case 'PackYN':
			{
				return true;                
			}
			case 'SchlfeeYN':
			{
				return true;                
			}
			case 'SchlfeeClaimamnt':
			{
				return true;                
			}
			case 'SchlfeenoYN':
			{
				return true;                
			}
			case 'TypeOfProcess':
			{
				return true;                
			}
			case 'TotInvoiceAmnt':
			{
				return true;                
			}
			case 'ExchangeRate':
			{
				return true;                
			}
			
            }
			return false;
			//return true;
		}//End of blur
		
		case 'keydown':
		{
			switch (pEvent.srcElement.id) 
            { 
			
			case 'EmployeeCode':
				{				
					if ((activityName=='ER_Initiation')|| (activityName=='Rework'))
					{
						setNGValue('CompanyCode', '');
                        setNGValue('Region', '');
                        setNGValue('EmployeeName', '');
                        setNGValue('VendorCode', '');
                        setNGValue('Designation', '');
                        setNGValue('Department', '');
                        setNGValue('Grade', '');
                        setNGValue('CostCenter', '');
                        setNGValue('BusinessArea', '');
						//alert('EmployeeCode keydown');
					}
				return false;
				break;	
				}
				
				return false;
			}
		
		}//End of event keydown
		
		return false;
		/*default:
		{
		return false;
		break;
		}*/
	}//End of Switch 
	
}//end of eventDispatched_AP
