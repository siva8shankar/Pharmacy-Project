package resources;

import java.io.File;
import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class logcode {

    private static String mstrlog4jConfigFilePath;
    
    public static Logger mErrLogger = Logger.getLogger("Errorlog");
    public static Logger mRepLogger = Logger.getLogger("Reportlog");

    public static void InitLog() {
        try {
            mstrlog4jConfigFilePath = System.getProperty("user.dir") + System.getProperty("file.separator") + "Config"
                    + System.getProperty("file.separator")
                    + "log4j.properties";
            File lobjFile = new File(mstrlog4jConfigFilePath);
            if (!(lobjFile.exists())) {
                mRepLogger.info("Logger Config file doesnot exists !" + mstrlog4jConfigFilePath);
            } else {
                ConfigureLogger(mstrlog4jConfigFilePath);
            }
            lobjFile = null;
        } catch (Exception lobjExcp) {
            mRepLogger.info("Exception Occurs during Logger Initialization: " + lobjExcp.toString());
            mRepLogger.info("Exception Occurs during Logger Initialization: " + lobjExcp
                    .toString());
        }
    }

    /**
     * ******************************************************************
     * Function Name : ConfigureLogger Date Written : 11-Sep-2017 Author :
     * G.Girivasu Input Parameters : nothing Output Parameters : nothing Return
     * Values : nothing Description : Configuring loggers
     *
     ***********************************************************************
     */
    public static void ConfigureLogger(String plog4jConfigFilePath)
            throws Exception {
        String lExceptionId = new String("com.newgen.lns.myqueue.process.configureLogger.");
        try {
            FileInputStream lobjFileInputStream = null;
            lobjFileInputStream = new FileInputStream(plog4jConfigFilePath);
            Properties lobjPropertiesINI = new Properties();
            lobjPropertiesINI.load(lobjFileInputStream);
            lobjPropertiesINI = LoadProperties(lobjPropertiesINI);
            PropertyConfigurator propertyConfigurator = new PropertyConfigurator();
            propertyConfigurator.doConfigure(lobjPropertiesINI, LogManager.getLoggerRepository());

        } catch (Exception lobjExcp) {
            mRepLogger.info(lExceptionId + ": Exception occurs during Logger Initialization: " + lobjExcp.toString());
            mRepLogger.info(lExceptionId + ": Exception occurs during Logger Initialization: " + lobjExcp
                    .toString());
            throw lobjExcp;
        }
    }

    /**
     * ******************************************************************
     * Function Name : LoadProperties Date Written : 11-Sep-2017 Author :
     * ksivashankar Input Parameters : pobjProperties Output Parameters :
     * Properties Return Values : nothing Description : Loading log4j file
     *
     ***********************************************************************
     */
    public static Properties LoadProperties(Properties pobjProperties)
            throws Exception {
        Properties lobjProperties = pobjProperties;
        try {
            Enumeration lobjEnumeration = null;
            lobjEnumeration = lobjProperties.keys();

            while (lobjEnumeration.hasMoreElements()) {
                String str1 = "";
                String s1 = ((String) lobjEnumeration.nextElement()).trim();
                if (!(s1.startsWith("log4j.logger."))) {
                    continue;
                }
                String s4 = lobjProperties.getProperty(s1);
                StringTokenizer stringtokenizer = new StringTokenizer(s4, ",");

                while (stringtokenizer.hasMoreTokens()) {
                    String s7 = stringtokenizer.nextToken();
                    String s2 = "log4j.appender." + s7.trim() + ".File";
                    str1 = lobjProperties.getProperty(s2);
                }

                stringtokenizer = null;
            }
        } catch (Exception lobjExcp) {
            mRepLogger.info("LoadProperties : Exception occurs during Logger Initialization: " + lobjExcp.toString());
            mRepLogger.info("LoadProperties : Exception occurs during Logger Initialization: " + lobjExcp.toString());
            throw lobjExcp;
        }

        return lobjProperties;
    }
}
