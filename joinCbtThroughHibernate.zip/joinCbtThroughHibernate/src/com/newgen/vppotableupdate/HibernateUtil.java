/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.vppotableupdate;

import java.io.File;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author girivasu.g
 */
public class HibernateUtil {

    private static final SessionFactory sessionFactory = buildSessionFactory();
    static String mstrlog4jConfigFilePath = "";

//    public static org.apache.log4j.Logger mErrLogger = org.apache.log4j.Logger.getLogger("Errorlog");
//    public static org.apache.log4j.Logger mRepLogger = org.apache.log4j.Logger.getLogger("Reportlog");

    private static SessionFactory buildSessionFactory() {
        try {
            // Create the SessionFactory from hibernate.cfg.xml
           // mRepLogger.info("---------------------------------------------");
            Configuration cfg = new AnnotationConfiguration();
            cfg.configure("resources/hibernate.cfg.xml");
            SessionFactory sf = cfg.buildSessionFactory();
            // mRepLogger.info("Initial SessionFactory creation Successfully");
            return sf;
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
           // mErrLogger.error("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}