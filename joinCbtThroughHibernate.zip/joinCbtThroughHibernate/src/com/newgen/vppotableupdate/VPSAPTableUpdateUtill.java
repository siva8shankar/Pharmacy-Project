/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.vppotableupdate;

import beans.POStatusBean;
import beans.PODetailsBean;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import resources.logcode;

/**
 *
 * @author G Giri vasu
 */
public class VPSAPTableUpdateUtill {

    private static String[] data;
    private static String ErrMsg;
    static String mstrlog4jConfigFilePath = "";
    public static org.apache.log4j.Logger mErrLogger = org.apache.log4j.Logger.getLogger("Errorlog");
    public static org.apache.log4j.Logger mRepLogger = org.apache.log4j.Logger.getLogger("Reportlog");
    
    static public String userName;
    static public String password;
    static public String strIP;
    static public String strPort;
    static public int iPort;
    static public String strAppServerType;
    static public String cvsSplitBy;
    static public String poStatusPath;
    static public String poDetailsPath;
     
    public static void ReadProperty() {
        
        try {
            mRepLogger.info("-----------------ReadProperty-----------------");
     logcode log1 = new logcode();
        log1.InitLog();       
     
            mRepLogger.info("Reading property file.....");
            String strPropertyPath = System.getProperty("user.dir") + File.separator + "Settings.ini";
            FileInputStream File_Ini = new FileInputStream(strPropertyPath);
            Properties prop = new Properties();
            prop.load(File_Ini);
            
            cvsSplitBy = "~";
           
            poStatusPath="C://Users/girivasu.g/Desktop/Masters/POStatus";
            poDetailsPath="C://Users/girivasu.g/Desktop/Masters/PO";  
            
        } catch (Exception e) {
            
            mErrLogger.info("[Error]** Exception in ReadProperty " + e.toString());
            e.printStackTrace();
        }
      
    }

    public static void main(String args[]) throws IOException {
        mRepLogger.info("-------------VPSAPPODetails Update started------------------------");
        ReadProperty();
        Session session = HibernateUtil.getSessionFactory().openSession();
        Session session2 = HibernateUtil.getSessionFactory().openSession();
        
       
        String postatus = poStatusPath;
        String podetails = poDetailsPath;
        FetchOpenClosePOData(postatus, session);
        FetchPODetails(podetails, session2);

    }

   
    
    static void FetchOpenClosePOData(String inputPath, Session session) {
      mRepLogger.info("Inside FetchOpenClosePOData ...................");
        BufferedReader br = null;
        int i = 0;
        String line = "";
       // String cvsSplitBy = "~";
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        try {
     mRepLogger.info("---------------------------------------------------------------");
    File inputFile=new File(inputPath);
    File[] dir_contents = inputFile.listFiles();
  mRepLogger.info("---------------------------------------------------------------");
mRepLogger.info("-----------------------------"+dir_contents.length);
    for (int k= 0; k < dir_contents.length; k++) {
        mRepLogger.info("---------------------------------------------------------------");
        mRepLogger.info(inputPath+"/"+dir_contents[k].getName());
           File mainPath=new File(inputPath+"/"+dir_contents[k].getName());
            
            br = new BufferedReader(new FileReader(mainPath));

            while ((line = br.readLine()) != null) {

                session.beginTransaction();
                System.out.println("line:-" + line);
                if (!line.contains("Vendor Code")) {
                    String[] poData = line.split(cvsSplitBy);
                    System.out.println("Fetch: " + poData);


                    //Add new Employee object
                    POStatusBean po = new POStatusBean();
                    i = i + 1;
                    System.out.println("i==" + i);
                    String poId = Integer.toString(i);
                    System.out.println("poId" + poId);
                    // po.setPOID(i);
                    System.out.println("GetpoId" + po.getPOID());
                    po.setVendorCode(poData[0]);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

                    DateFormat formatter1 = new SimpleDateFormat("dd/mm/yyyy");
                    try {
                        System.out.println("country[1]:-" + poData[1]);

                        Date datestr = sdf.parse(poData[1]);
                        String dateString = formatter.format(datestr);
                        Date format = formatter.parse(dateString);
                        System.out.println("datestr:-" + format);
                        po.setPO_CreatedDate(format);
                    } catch (ParseException ex) {
                        Logger.getLogger(VPSAPTableUpdateUtill.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    System.out.println("-----" + poData.length);
                    po.setVendorName(poData[2]);
                    po.setPO_Number(poData[3]);
                    po.setPO_Amount(Float.parseFloat(poData[4]));
                    po.setPO_Currency(poData[5]);
                    po.setAdvance_Paid(Float.parseFloat(poData[6]));
                    po.setPO_Status(poData[7]);
                    if ((poData.length) > 8) {
                        System.out.println("-----" + isNullOrEmpty(poData[8]));
                        if (isNullOrEmpty(poData[8])) {
                            po.setWHT_Types("");
                        } else {
                            po.setWHT_Types(poData[8]);
                        }
                    } else {
                        po.setWHT_Types("");
                    }
                    if ((poData.length) > 9) {
                        if (isNullOrEmpty(poData[9])) {
                            po.setWHT_Codes("");
                        } else {
                            po.setWHT_Codes(poData[9]);
                        }
                    } else {
                        po.setWHT_Codes("");
                    }

                    session.merge(po);



                }
                session.getTransaction().commit();
            }

            session.close();
    }
        } catch (FileNotFoundException e) {
            session.close();
            e.printStackTrace();
        } catch (IOException e) {
            session.close();
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    static void FetchPODetails(String inputPath, Session session) {
      //  String csvFile = "C://Users//girivasu.g//Desktop//Masters/v1.csv";
        BufferedReader br = null;
        String line = "";
      //  String cvsSplitBy = "~";
        int i = 0;
        try {
     File inputFile=new File(inputPath);
    File[] dir_contents = inputFile.listFiles();
  

    for (int k= 0; k < dir_contents.length; k++) {
        
           File mainPath=new File(inputPath+"/"+dir_contents[i].getName());
            
            br = new BufferedReader(new FileReader(mainPath));
            while ((line = br.readLine()) != null) {
                System.out.println("i==" + i);
                System.out.println("line:-" + line);
                if (!line.contains("Vendor Code")) {
                    String[] poData = line.split(cvsSplitBy);

                    session.beginTransaction();

                    PODetailsBean po = new PODetailsBean();
                    i = i + 1;
                    String poId = Integer.toString(i);

                    //po.setPOID(i);
                    po.setPO_Number(poData[1]);
                    po.setCompany_Code(poData[2]);
                    po.setVendorCode(poData[3]);
                    po.setVendorName(poData[4]);

                    po.setPO_Creator_Name(poData[5]);
                    po.setPO_CReator_EmailId(poData[6]);
                    po.setPO_Currency(poData[7]);

                    po.setExchange_Rate(Float.parseFloat(poData[8]));

                    session.merge(po);

                    //Commit the transaction
                    session.getTransaction().commit();
                    //HibernateUtil.shutdown();



                }
                //  i=i+1;
            }
    }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static boolean isNullOrEmpty(Object object) {
        if (object != null && !object.toString().trim().equalsIgnoreCase("") && !object.toString().trim().equalsIgnoreCase("null")) {
            return false;
        }
        return true;
    }
}