/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 *
 * @author girivasu.g
 */

public class PODetailsBean {

    private int POID;
    String VendorCode;
    String Company_Code;
    String VendorName;
    String PO_Number;
    String PO_Currency;
    String PO_Creator_Name;
    String PO_CReator_EmailId;
    Float Exchange_Rate;

    public int getPOID() {
        return POID;
    }

    public void setPOID(int pOID) {
        this.POID = pOID;
    }

    public String getVendorCode() {
        return VendorCode;
    }

    public void setVendorCode(String vendorCode) {
        VendorCode = vendorCode;
    }

    public String getCompany_Code() {
        return Company_Code;
    }

    public void setCompany_Code(String company_Code) {
        Company_Code = company_Code;
    }

    public String getVendorName() {
        return VendorName;
    }

    public void setVendorName(String vendorName) {
        VendorName = vendorName;
    }

    public String getPO_Number() {
        return PO_Number;
    }

    public void setPO_Number(String pO_Number) {
        PO_Number = pO_Number;
    }

    public String getPO_Currency() {
        return PO_Currency;
    }

    public void setPO_Currency(String pO_Currency) {
        PO_Currency = pO_Currency;
    }

    public String getPO_Creator_Name() {
        return PO_Creator_Name;
    }

    public void setPO_Creator_Name(String pO_Creator_Name) {
        PO_Creator_Name = pO_Creator_Name;
    }

    public String getPO_CReator_EmailId() {
        return PO_CReator_EmailId;
    }

    public void setPO_CReator_EmailId(String pO_CReator_EmailId) {
        PO_CReator_EmailId = pO_CReator_EmailId;
    }

    public Float getExchange_Rate() {
        return Exchange_Rate;
    }

    public void setExchange_Rate(Float exchange_Rate) {
        Exchange_Rate = exchange_Rate;
    }
}
