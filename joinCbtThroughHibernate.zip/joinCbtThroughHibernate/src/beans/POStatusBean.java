/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.UniqueConstraint;

/**
 *
 * @author girivasu.g
 */

public class POStatusBean {

   
   private int  POID;
    String VendorCode;
    String VendorName;
    String PO_Number;
    String PO_Currency;
    String PO_Status;
    String WHT_Types;
    String WHT_Codes;
    Date PO_CreatedDate;
    Float PO_Amount;
    Float Advance_Paid;

    public int getPOID() {
        return POID;
    }

    public void setPOID(int POID) {
       this.POID = POID;
    }

    public String getVendorCode() {
        return VendorCode;
    }

    public void setVendorCode(String vendorCode) {
        VendorCode = vendorCode;
    }

    public String getVendorName() {
        return VendorName;
    }

    public void setVendorName(String vendorName) {
        VendorName = vendorName;
    }

    public String getPO_Number() {
        return PO_Number;
    }

    public void setPO_Number(String pO_Number) {
        PO_Number = pO_Number;
    }

    public String getPO_Currency() {
        return PO_Currency;
    }

    public void setPO_Currency(String pO_Currency) {
        PO_Currency = pO_Currency;
    }

    public String getPO_Status() {
        return PO_Status;
    }

    public void setPO_Status(String pO_Status) {
        PO_Status = pO_Status;
    }

    public String getWHT_Codes() {
        return WHT_Codes;
    }

    public void setWHT_Codes(String wHT_Codes) {
        WHT_Codes = wHT_Codes;
    }

    public String getWHT_Types() {
        return WHT_Types;
    }

    public void setWHT_Types(String wHT_Types) {
        WHT_Types = wHT_Types;
    }

    public Date getPO_CreatedDate() {
        return PO_CreatedDate;
    }

    public void setPO_CreatedDate(Date pO_CreatedDate) {
        PO_CreatedDate = pO_CreatedDate;
    }

    public Float getPO_Amount() {
        return PO_Amount;
    }

    public void setPO_Amount(Float pO_Amount) {
        PO_Amount = pO_Amount;
    }

    public Float getAdvance_Paid() {
        return Advance_Paid;
    }

    public void setAdvance_Paid(Float advance_Paid) {
        Advance_Paid = advance_Paid;
    }

   
}
