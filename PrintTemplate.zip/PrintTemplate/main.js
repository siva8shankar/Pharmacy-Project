function openPDFFile()
{
var mode="u";//v-for view; u-for upload 
url="http://"+PrintTempIPAddress+":"+PrintTempPort+"/PrintTemplate/downloadPDF?pk=" + PONumber + "&TT=" + sTT + "&mode="+mode+"";//pk - PrimaryKey column :: STT - TemplateType :: mode -  v-for view; u-for upload
	window.open(url)
}