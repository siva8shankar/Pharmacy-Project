function trim(myString)     
{     
	return myString.replace(/^\s+|\s+$/g, '');    
}

function CalculateTotalInvoiceAmount(){
	
	var baseValue = '0.0';
	var serviceTax = '0.0';
	var sbc = '0.0';
	var kkc = '0.0';
	var cst = '0.0';
	var vat = '0.0';
	var igst = '0.0';
	var cgst = '0.0';
	var sgst = '0.0';
	var exciseDuty = '0.0';
	var TotalInvoiceAmount='0.0';

	if (null != document.getElementById("baseValue") && document.getElementById("baseValue").value != ''){
		baseValue = document.getElementById("baseValue").value;
		//written by devi 27-oct-16
		baseValue=baseValue.replace(/,/g, '');
		baseValue=parseFloat(baseValue,10);
		
	} 
	if (null != document.getElementById("serviceTax") && document.getElementById("serviceTax").value != ''){
		serviceTax = document.getElementById("serviceTax").value;
		//written by devi 27-oct-16
		serviceTax=serviceTax.replace(/,/g, '');
		serviceTax=parseFloat(serviceTax,10);
		
	} 
	if (null != document.getElementById("sbc") && document.getElementById("sbc").value != ''){
		sbc = document.getElementById("sbc").value;
		//written by devi 27-oct-16
		sbc=sbc.replace(/,/g, '');
		sbc=parseFloat(sbc,10);
	} 
	if (null != document.getElementById("kkc") && document.getElementById("kkc").value != ''){
		kkc = document.getElementById("kkc").value;
		//written by devi 27-oct-16
		kkc=kkc.replace(/,/g, '');
		kkc=parseFloat(kkc,10);
	} 
	if (null != document.getElementById("cst") && document.getElementById("cst").value != ''){
		cst = document.getElementById("cst").value;
		//written by devi 27-oct-16
		cst=cst.replace(/,/g, '');
		cst=parseFloat(cst,10);
	} 
	if (null != document.getElementById("vat") && document.getElementById("vat").value != ''){
		vat = document.getElementById("vat").value;
		//written by devi 27-oct-16
		vat=vat.replace(/,/g, '');
		vat=parseFloat(vat,10);
		
	} 
	if (null != document.getElementById("igst") && document.getElementById("igst").value != ''){
		igst = document.getElementById("igst").value;
		//written by devi 27-oct-16
		igst=igst.replace(/,/g, '');
		igst=parseFloat(igst,10);
	} 
	if (null != document.getElementById("cgst") && document.getElementById("cgst").value != ''){
		cgst = document.getElementById("cgst").value;
		//written by devi 27-oct-16
		cgst=cgst.replace(/,/g, '');
		cgst=parseFloat(cgst,10);
	} 
	if (null != document.getElementById("sgst") && document.getElementById("sgst").value != ''){
		sgst = document.getElementById("sgst").value;
		//written by devi 27-oct-16
		sgst=sgst.replace(/,/g, '');
		sgst=parseFloat(sgst,10);
	}
	if (null != document.getElementById("exciseDuty") && document.getElementById("exciseDuty").value != ''){
		exciseDuty = document.getElementById("exciseDuty").value;
		//written by devi 27-oct-16
		exciseDuty=exciseDuty.replace(/,/g, '');
		exciseDuty=parseFloat(exciseDuty,10);
	}

	TotalInvoiceAmount = (parseFloat(baseValue) + parseFloat(serviceTax) + parseFloat(sbc)
			+ parseFloat(kkc) + parseFloat(cst) + parseFloat(vat) + parseFloat(igst) + parseFloat(cgst) + parseFloat(sgst) + parseFloat(exciseDuty));
	TotalInvoiceAmount = parseFloat(TotalInvoiceAmount.toFixed(3));
	
	// by devi 
	//document.getElementById("invoiceValue").value = TotalInvoiceAmount;//Math.round(TotalInvoiceAmount); 

	//written by devi 27-oct-16
	
	 tmp = TotalInvoiceAmount.toString().split('').reverse().join('').replace(/(\d{3})/g, '$1,').split('').reverse().join('').replace(/^\./, '');       
	 TotalInvoiceAmount = tmp.replace(/ /, "");
     while(TotalInvoiceAmount.charAt( 0 ) == ',' )
    TotalInvoiceAmount= TotalInvoiceAmount.slice( 1 );
  
     document.getElementById("invoiceValue").value = TotalInvoiceAmount;
	
	/*var InvoiceBaseAmount = '0.0';
	var ServiceTax = '0.0';
	var EducationCess = '0.0';
	var HEducationCess = '0.0';
	var VAT = '0.0';
	var AdditionalVatValue = '0.0';
	var AnyOtherTax = '0.0';
	var Freight = '0.0';
	var Discount = '0.0';
	var PenaltyDeduction = '0.0';
	var TotalInvoiceAmount='0.0';
	var GrossAmount='0.0';

	if (null != document.getElementById("InvoiceBaseAmt") && document.getElementById("InvoiceBaseAmt").value != ''){
		InvoiceBaseAmount = document.getElementById("InvoiceBaseAmt").value;
	} 
	if (null != document.getElementById("GrossAmount") && document.getElementById("GrossAmount").value != ''){
		InvoiceBaseAmount = document.getElementById("GrossAmount").value;
	} 
	if (null != document.getElementById("ServiceTax") && document.getElementById("ServiceTax").value != ''){
		ServiceTax = document.getElementById("ServiceTax").value;
	} 
	if (null != document.getElementById("EducationCess") && document.getElementById("EducationCess").value != ''){
		EducationCess = document.getElementById("EducationCess").value;
	} 
	if (null != document.getElementById("HigherEducationCess") && document.getElementById("HigherEducationCess").value != ''){
		HEducationCess = document.getElementById("HigherEducationCess").value;
	} 
	if (null != document.getElementById("Vat") && document.getElementById("Vat").value != ''){
		VAT = document.getElementById("Vat").value;
	} 
	if (null != document.getElementById("AdditionalVat") && document.getElementById("AdditionalVat").value != ''){
		AdditionalVatValue = document.getElementById("AdditionalVat").value;
	} 
	if (null != document.getElementById("AnyOtherTax") && document.getElementById("AnyOtherTax").value != ''){
		AnyOtherTax = document.getElementById("AnyOtherTax").value;
	} 
	if (null != document.getElementById("Freight") && document.getElementById("Freight").value != ''){
		Freight = document.getElementById("Freight").value;
	} 
	if (null != document.getElementById("Discount") && document.getElementById("Discount").value != ''){
		Discount = document.getElementById("Discount").value;
	} 
	if (null != document.getElementById("PenaltyDeduction") && document.getElementById("PenaltyDeduction").value != ''){
		PenaltyDeduction = document.getElementById("PenaltyDeduction").value;
	} 

	TotalInvoiceAmount = ((parseFloat(InvoiceBaseAmount) + parseFloat(ServiceTax) + parseFloat(EducationCess)
			+ parseFloat(HEducationCess) + parseFloat(VAT) + parseFloat(AdditionalVatValue) + parseFloat(AnyOtherTax) + parseFloat(Freight))
			- (parseFloat(Discount) + parseFloat(PenaltyDeduction)));
	TotalInvoiceAmount = parseFloat(TotalInvoiceAmount.toFixed(3));
	document.getElementById("TotalInvAmt").value = TotalInvoiceAmount;//Math.round(TotalInvoiceAmount);*/
	
	

}

/*function myWindow(){
	var InvoiceNumberInSystemcrt = document.getElementById("InvoiceNumberInSystem");
	var CompanyCode = document.getElementById("CompanyCode");
	var InvoiceNumberInSystem = document.getElementById("InvoiceNumberInSystem");
	var DocumentTypes = document.getElementById("DocumentType").value;
	if(CompanyCode==null|| trim(CompanyCode.options[CompanyCode.selectedIndex].text)==""){
		alert("First enter Company Code");
		CompanyCode.focus();
	}
	else if(InvoiceNumberInSystem.value==null|| trim(InvoiceNumberInSystem.value)==""){
		alert("First enter Invoice Number");
		InvoiceNumberInSystem.focus();
	}
	else{
		if(!document.getElementById('InvoiceNumberInSystem').readOnly){
			alert("Invoice number cannot be edited once documents are attached.");
		}
		var win = window.open("JSP/Attachment.jsp?InvoiceNumber="+InvoiceNumberInSystem.value+"&DocumentTypes="+DocumentTypes+"&DocumentSize='${requestScope.DocumentSize}'","dataitem","Height=300px,Width=520px, scrollbars=yes,dependent=yes,menubar=no,toolbar=no,status=no,modal=yes,alwaysRaised=yes, Left=280, top=300");
		win.onunload =onun; 

	    function onun() {
	        if(win.location != "about:blank") // This is so that the function 
	                                          // doesn't do anything when the 
	                                          // window is first opened.
	        {// alert("closed");}
	    	}
		}	
}
}*/

function ClearFields()
{	
	if(null!=document.getElementById("RequestFor")){
		document.getElementById("RequestFor").value='PO';
	}
	if(null!=document.getElementById("AttentionTo")){
		document.getElementById("AttentionTo").value='';
	}

	if(null!=document.getElementById("InvoiceNumberInSystem")){
		document.getElementById("InvoiceNumberInSystem").value='';
		document.getElementById("InvoiceNumberInSystem").readOnly =false;
	}

	if(null!=document.getElementById("InvoiceDate")){
		document.getElementById("InvoiceDate").value='';
	}

	if(null!=document.getElementById("BillingCurrency")){
		document.getElementById("BillingCurrency").value='INR';
	}

	if(null!=document.getElementById("InvoiceBaseAmount")){
		document.getElementById("InvoiceBaseAmount").value='';
	}
	if(null!=document.getElementById("ServiceTax")){
		document.getElementById("ServiceTax").value='';
	}

	if(null!=document.getElementById("EducationCess")){
		document.getElementById("EducationCess").value='';
	}
	document.getElementById("EducationCess").value='';
	if(null!=document.getElementById("HigherEducationCess")){
		document.getElementById("HigherEducationCess").value='';
	}

	if(null!=document.getElementById("Vat")){
		document.getElementById("Vat").value='';
	}

	if(null!=document.getElementById("AdditionalVatValue")){
		document.getElementById("AdditionalVatValue").value='';
	}

	if(null!=document.getElementById("AnyOtherTax")){
		document.getElementById("AnyOtherTax").value='';
	}

	if(null!=document.getElementById("Freight")){
		document.getElementById("Freight").value='';
	}

	if(null!=document.getElementById("TotalInvoiceAmount")){
		document.getElementById("TotalInvoiceAmount").value='';
	}

	if(null!=document.getElementById("Discount")){
		document.getElementById("Discount").value='';
	}

	if(null!=document.getElementById("PenaltyDeduction")){
		document.getElementById("PenaltyDeduction").value='';
	}

	if(null!=document.getElementById("VoucherNarration")){
		document.getElementById("VoucherNarration").value='';
	}

	if(null!=document.getElementById("FromDate")){
		document.getElementById("FromDate").value='';
	}

	if(null!=document.getElementById("ToDate")){
		document.getElementById("ToDate").value='';
	}

	if(null!=document.getElementById("PoNo")){
		document.getElementById("PoNo").value='';
	}

	if(null!=document.getElementById("AnyOtherTaxType")){
		document.getElementById("AnyOtherTaxType").value='';
	}


}
function SetEditable(){

	fieldEnable("RequestFor");
	fieldEnable("AttentionTo");
	fieldEnable("InvoiceNumberInSystem");
	fieldEnable("InvoiceDate");
	fieldEnable("BillingCurrency");
	fieldEnable("InvoiceBaseAmount");
	fieldEnable("ServiceTax");
	fieldEnable("EducationCess");
	fieldEnable("HigherEducationCess");
	fieldEnable("Vat");
	fieldEnable("AdditionalVatValue");
	fieldEnable("AnyOtherTax");
	fieldEnable("Freight");
	fieldEnable("Discount");
	fieldEnable("PenaltyDeduction");
	fieldEnable("TotalInvoiceAmount");
	fieldEnable("VoucherNarration");
	fieldEnable("FromDate");
	fieldEnable("ToDate");
	fieldEnable("PoNo");
	fieldEnable("AnyOtherTaxType");
	calanderDisable('NonCalander3');
	calanderEnable('calander3');
	calanderDisable('NonCalander19');
	calanderEnable('calander19');
	calanderDisable('NonCalander20');
	calanderEnable('calander20');
}

function SetDisable(){
	fieldDisable("RequestFor");
	fieldDisable("AttentionTo");
	fieldDisable("InvoiceNumberInSystem");
	fieldDisable("InvoiceDate");
	fieldDisable("BillingCurrency");
	fieldDisable("InvoiceBaseAmount");
	fieldDisable("ServiceTax");
	fieldDisable("EducationCess");
	fieldDisable("HigherEducationCess");
	fieldDisable("Vat");
	fieldDisable("AdditionalVatValue");
	fieldDisable("AnyOtherTax");
	fieldDisable("Freight");
	fieldDisable("Discount");
	fieldDisable("PenaltyDeduction");
	fieldDisable("TotalInvoiceAmount");
	fieldDisable("VoucherNarration");
	fieldDisable("FromDate");
	fieldDisable("ToDate");
	fieldDisable("PoNo");
	fieldDisable("AnyOtherTaxType");
	calanderDisable('calander3');
	calanderEnable('NonCalander3');
	calanderDisable('calander19');
	calanderEnable('NonCalander19');
	calanderDisable('calander20');
	calanderEnable('NonCalander20');
}

function validation(){
	var CompanyCode = document.getElementById("CompanyCode");
	var VendorCode = document.getElementById("VendorCode");
	var CompanyName = document.getElementById("CompanyName");
	var VendorName = document.getElementById("VendorName");
	var InvoiceNumberInSystem = document.getElementById("InvoiceNumberInSystem");
	var InvoiceDate = document.getElementById("InvoiceDate");
	var InvoiceBaseAmount = document.getElementById("InvoiceBaseAmount");
	var RequestFor = document.getElementById("RequestFor");
	var TotalInvoiceAmount = document.getElementById("TotalInvoiceAmount");
	var FromDate = document.getElementById("FromDate");
	var ToDate = document.getElementById("ToDate");
	var PoNo = document.getElementById("PoNo");
	var fileadded =document.getElementById("addedDocumends").value;

	if(CompanyCode.value==null||trim(CompanyCode.options[CompanyCode.selectedIndex].text)==""){
		alert("Company Code must be entered.");
		CompanyCode.focus();
		return false;
	}
	else if(VendorCode.value==null||trim(VendorCode.value)==""){
		alert("Vendor Code must be entered.");
		VendorCode.focus();
		return false;
	}
	else if(CompanyName.value==null||trim(CompanyName.value)==""){
		alert("Company Name must be entered.");
		CompanyName.focus();
		return false;
	}
	else if(VendorName.value==null||trim(VendorName.value)==""){
		alert("Vendor Name must be entered.");
		VendorName.focus();
		return false;
	}
	else if(trim(RequestFor.value)=='PO' && (PoNo.value==null||trim(PoNo.value)==""))
	{
		alert("PO No must be entered if Request For is PO.");
		PoNo.focus();
		return false;
	}
	else if(null != document.getElementById("mandatoryFeildList") && trim(document.getElementById("mandatoryFeildList").value) != "" ){
		var mandatoryfeilds = document.getElementById("mandatoryFeildList").value;
		var mandatoryFeildsList = mandatoryfeilds.split(",");
		for(var i=0;i<mandatoryFeildsList.length-1;i++){
			var feildsdetails = mandatoryFeildsList[i].split("=");
			var feildname = feildsdetails[0];
			var feildDisplayName = feildsdetails[1];
			if(!feildMandatory(feildname, feildDisplayName)){
				return false;
				break;
			}

		}
	}
	if((trim(fileadded)=="" || fileadded==null)||(trim(fileadded)!="" && fileadded.indexOf("Invoice Document") == -1)){
		alert("Invoice Document must be attached");
		return false;
	}
	else if(ToDate.value!=null&&trim(ToDate.value)!=""&&trim(FromDate.value)==""){
		alert("From Date must be entered if To Date is entered.");
		FromDate.focus();
		return false;
	}
	else{
		if(trim(FromDate.value)!=""){
			if(!feildMandatory("ToDate","To Date")){
				return false;
			}
			else{
				var FromDatearr = FromDate.value.split("/");
				var ToDatearr = ToDate.value.split("/");
				if(FromDatearr[2]>ToDatearr[2]){
					alert("From Date cannot be greater than To Date");
					return false;
				}
				else if(FromDatearr[2] == ToDatearr[2] && FromDatearr[1]>ToDatearr[1]){
					alert("From Date cannot be greater than To Date");
					return false;
				}
				else if(FromDatearr[2] == ToDatearr[2] && FromDatearr[1] == ToDatearr[1] && FromDatearr[0]>ToDatearr[0]){
					alert("From Date cannot be greater than To Date");
					return false;
				}	
			}					
		}
		return true;
	}

}

function feildMandatory(feildName, feildDisplayName){
	if(document.getElementById(feildName).value==null||trim(document.getElementById(feildName).value)==""){
		alert(feildDisplayName+" must be entered.");
		document.getElementById(feildName).focus();
		return false;
	}
	else{
		return true;
	}
}
function numberCheck(feild,key){
	var keycode = (key.which) ? key.which : key.keyCode;
	var feild = document.getElementById(feild);
	if(feild.value.length==0 && keycode==46 ){
		return false;
	}
	if (keycode == 08 || keycode == 127 || keycode==09){
		return true;
	}
	if (!(keycode==08 || keycode==46 || keycode == 127)&&(keycode < 48 || keycode > 57)){
		return false;
	}
	else{
		if (feild.value.length <17 && feild.value.length!=13 ){
			if(feild.value.indexOf('.')>=0 && keycode==46){
				return false;
			}
			else{
				if(feild.value.indexOf('.')>=0){
					var valuesplit = feild.value.split('.');
					if(valuesplit[1].length<2){
						return true;
					}
					else{
						return false;
					}
				}
				else{
					return true;
				}
				return true;
			}
		}
		else if(feild.value.length==13){
			if(feild.value.indexOf('.')<0 && keycode==46){
				return true;
			}
			else if(feild.value.indexOf('.')>=0 && keycode!=46){
				var valuesplit = feild.value.split('.');
				if(valuesplit[1].length<2){
					return true;
				}
				else{
					return false;
				}
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
}

//written by devi 27-oct-16
function currencyformat(field) {
 
   var num= field.value.replace(/[\.\,]/g, "");

   if (/^0/.test(field.value)) {

       field.value = field.value.substring(0, 1);
   }
if(field.value.substring(0, 1)=="." || field.value.substring(0, 1)==",")
   {
       var tmp = field.value.replace(/[\.\,]/g, "");
         field.value = tmp.replace(/ /, "");

   }
   if(num.length >= 13)
   { 
       field.value = num.substring(0,13);
   }
if (Number(field.value.replace(/[\\,]/g, ""))) {
       var tmp = field.value.replace(/[\\,]/g, "");
       tmp = tmp.toString().split('').reverse().join('').replace(/(\d{3})/g, '$1,').split('').reverse().join('').replace(/^\./, '');       
       field.value = tmp.replace(/ /, "");
     
   }
   
   else {
       // field.value = field.value.replace(/[^\d\,\.]/g, "").replace(/ /, "");
       field.value ="";
   }

var num= field.value;

while( num.charAt( 0 ) == ',' )
   num= num.slice( 1 );

         field.value = num;

}

function rsch(field,key)
{
var keycode = (key.which) ? key.which : key.keyCode;
if ((keycode >= 60 && keycode<64))  {
return false;
}
}

function allowedch(field,key)
{
var keycode = (key.which) ? key.which : key.keyCode;
if ((keycode >= 45 && keycode< 59) || (keycode >= 65 && keycode< 91) || keycode == 44 || keycode == 92 || keycode == 95 || keycode == 32 || (keycode >= 97 && keycode< 123) )  {
return true;
}
else
{
return false;
}
}
   
function setReadonlyFalse(){
	fieldReadWrite("AttentionTo");
	fieldReadWrite("RequestFor");
	fieldReadWrite("InvoiceNumberInSystem");
	fieldReadWrite("BillingCurrency");
	fieldReadWrite("InvoiceBaseAmount");
	fieldReadWrite("ServiceTax");
	fieldReadWrite("EducationCess");
	fieldReadWrite("HigherEducationCess");
	fieldReadWrite("Vat");
	fieldReadWrite("AdditionalVatValue");
	fieldReadWrite("AnyOtherTax");
	fieldReadWrite("Freight");
	fieldReadWrite("TotalInvoiceAmount");
	fieldReadWrite("Discount");
	fieldReadWrite("PenaltyDeduction");
	fieldReadWrite("VoucherNarration");
	fieldReadWrite("PoNo");
	fieldReadWrite("AnyOtherTaxType");

	calanderDisable('calander3');
	calanderEnable('NonCalander3');
	calanderDisable('calander19');
	calanderEnable('NonCalander19');
	calanderDisable('calander20');
	calanderEnable('NonCalander20');
}

function back(){
	window.history.back();
}

function home(){
	 window.location.assign("/portal/MainServlet");
}

function setDateEditable(){
	calanderDisable('NonCalander3');
	calanderEnable('calander3');
	calanderDisable('NonCalander19');
	calanderEnable('calander19');
	calanderDisable('NonCalander20');
	calanderEnable('calander20');
}
function ResetTable(){
	if( null != document.getElementById('InvoiceNumberInSystem') && document.getElementById('InvoiceNumberInSystem').readOnly){
		var name = document.getElementById('InvoiceNumberInSystem').value+",R";
		xmlhttpPost(name);
		element = document.getElementById('divfiles');
		element.parentNode.removeChild(element);
	}
	ClearFields();

}


function checkInvoice(key){
	var keycode = (key.which) ? key.which : key.keyCode;
	if(null != document.getElementById('InvoiceNumberInSystem') && document.getElementById('InvoiceNumberInSystem').readOnly && keycode == 08){
		return false;
	}

}
function CheckCompanyCodeandVendorCode(){

	if(document.getElementById("CompanyCode").value==null||trim(document.getElementById("CompanyCode").options[document.getElementById("CompanyCode").selectedIndex].text)==''){
		SetDisable();
		//alert("Please Enter Company Code");
	}
	else if(document.getElementById("VendorCode").value==null||trim(document.getElementById("VendorCode").value)==''){
		SetDisable();
		//alert("Please Enter Vendor Code");
	}
	else{
		SetEditable();
	}

}


function keycheck(id, event){

	if(event.keyCode==27||event.keyCode==122){
		return false;
	}
	if ((event.keyCode==08)&&(event.srcElement.type!='text'&& event.srcElement.type!='textarea'&& event.srcElement.type!='password'))
	{
		return false;
	}
	else if((event.srcElement.readOnly==true)){
		return false;
	}
}

function disableFieldsOnCheck(fieldToBeCompared,valueToBeCompared, fieldToBeDisabled ){
	if (fieldToBeCompared == null || document.getElementById(fieldToBeCompared).value == ''){
		document.getElementById(fieldToBeDisabled).value='';
		document.getElementById(fieldToBeDisabled).disabled=false;
		return false;
	}
	else{
		if (trim(document.getElementById(fieldToBeCompared).value) == valueToBeCompared){
			document.getElementById(fieldToBeDisabled).value='';
			document.getElementById(fieldToBeDisabled).disabled=true;
			document.getElementById(fieldToBeDisabled).style.backgroundColor="#a0a0a0";
			return true;
		}
		else{
			//document.getElementById(fieldToBeDisabled).value='';
			document.getElementById(fieldToBeDisabled).disabled=false;
			return false;
		}
	}
}
function ltrimString(str) { 
	for(var k = 0; k < str.length && isWhitespace(str.charAt(k)); k++);
	return str.substring(k, str.length);
}
function rtrimString(str) {
	for(var j=str.length-1; j>=0 && isWhitespace(str.charAt(j)) ; j--) ;
	return str.substring(0,j+1);
}
function trimString(str) {
	return ltrimString(rtrimString(str));
}

function ShowCompanyData(){
	var CompanyName =  document.getElementById("CompanyName").value;		
}

function calcTaxValue(id)
{ 	
	var baseValue = '';
	var serviceTax = '';	//serviceTax
	var cst = '';//cst
	var vat = '';	//vat
	var exciseDuty = '';//exciseDuty
	
	var objValue = parseFloat(document.getElementById(id).value);
	baseValue = parseFloat(document.getElementById("baseValue").value);
	
	if(!isNaN(objValue) && !isNaN(baseValue))
	{			
		if(id=="stPerc"){					
			serviceTax = ((objValue / 100) * baseValue).toFixed(2);			
			document.getElementById('serviceTax').value=serviceTax;
		}			
		if(id=="cstPerc"){
			cst = ((objValue / 100) * baseValue).toFixed(2);	
			document.getElementById('cst').value=cst;
		}
		if(id=="vatPerc"){
			vat = ((objValue / 100) * baseValue).toFixed(2);	
			document.getElementById('vat').value=vat;
		}
		if(id=="edPerc"){
			exciseDuty = ((objValue / 100) * baseValue).toFixed(2);	
			document.getElementById('exciseDuty').value=exciseDuty;
		}
	}
	else
	{
		if(id=="stPerc"){	
			document.getElementById('serviceTax').value='';
		}			
		if(id=="cstPerc"){
			document.getElementById('cst').value='';
		}
		if(id=="vatPerc"){
			document.getElementById('vat').value='';
		}
		if(id=="edPerc"){
			document.getElementById('exciseDuty').value='';
		}
	}
	CalculateTotalInvoiceAmount();
	
}

function customOnBlur(id, event){

	if(id=="baseValue"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="serviceTax"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="sbc"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="kkc"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="cst"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="vat"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="igst"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="cgst"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="sgst"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="exciseDuty"){
		CalculateTotalInvoiceAmount();
	}
	
	/*if(id=="InvoiceBaseAmt"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="GrossAmount"){
		CalculateTotalInvoiceAmount();
	}

	if(id=="ServiceTax"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="EducationCess"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="HigherEducationCess"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="Vat"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="AdditionalVatValue"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="AnyOtherTax"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="Freight"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="Discount"){
		CalculateTotalInvoiceAmount();
	}
	if(id=="PenaltyDeduction"){
		CalculateTotalInvoiceAmount();
	}
	
	if(id=="RequestFor"){
		disableFieldsOnCheck(id, 'Non PO', 'PoNo')
	}*/
	
	/*if(id=="VendorCode"){
		CheckCompanyCodeandVendorCode();
	}
	//Code changes on 2013-04-24 by Abhishek S
	if(id=="InvoiceNumberInSystem"){
		//checkInvoiceNumber(id,event);
	}*/
	//Code changed end here - 2013-04-24
}
function customOnClick(id, event){
	if(id=="Reset"){
		ResetTable();
	}
	if(id=="Attachments"){
		myWindow();
	}
	if(id=="hrefBack"){
		back();
	}
	if(id=="hrefHome"){
		home();
	}
	if(id=="hrefCloseWin"){
		this.window.close();
	}
	if(id=="hrefRefresh"){
		this.window.location.reload();
	}
	
}
function customOnKeyPress(id, event){
	
	if(id=="baseValue"){
		return numberCheck(id, event);
	}
	else if(id=="serviceTax"){
		return numberCheck(id, event);
	}
	else if(id=="sbc"){
		return numberCheck(id, event);
	}
	else if(id=="kkc"){
		return numberCheck(id, event);
	}
	else if(id=="cst"){
		return numberCheck(id, event);
	}
	else if(id=="vat"){
		return numberCheck(id, event);
	}
	else if(id=="igst"){
		return numberCheck(id, event);
	}
	else if(id=="cgst"){
		return numberCheck(id, event);
	}
	else if(id=="sgst"){
		return numberCheck(id, event);
	}
	else if(id=="invoiceValue"){
		return numberCheck(id, event);
	}
	else  if(id=="exciseDuty"){
		return numberCheck(id, event);
	}
	else if(id=="billingAddress" && document.getElementById("billingAddress").value.length > 999){
		return false;
	}
	
	/*if(id=="InvoiceBaseAmt"){
		return numberCheck(id, event);
	}
	else if(id=="ServiceTax"){
		return numberCheck(id, event);
	}
	else if(id=="GrossAmount"){
		return numberCheck(id, event);
	}
	else if(id=="TotalTax"){
		return numberCheck(id, event);
	}

	else if(id=="EducationCess"){
		return numberCheck(id, event);
	}
	else if(id=="HigherEducationCess"){
		return numberCheck(id, event);
	}
	else if(id=="VAT"){
		return numberCheck(id, event);
	}
	else if(id=="AdditionalVAT"){
		return numberCheck(id, event);
	}
	else if(id=="AnyOtherTax"){
		return numberCheck(id, event);
	}
	else if(id=="Freight"){
		return numberCheck(id, event);
	}
	else if(id=="Discount"){
		return numberCheck(id, event);
	}
	else if(id=="PenaltyDeduction"){
		return numberCheck(id, event);
	}
	else if(id=="TotalInvAmt"){
		return numberCheck(id, event);
	}
	else if(id=="RequestFor"&& event.keyCode==08){
		return false;
	}
	else if(id=="VoucherNarration" && document.getElementById("VoucherNarration").value.length > 999){
		return false;
	}*/
}
function customOnSubmit(id, event){
	if(id=="InvoiceDetails"){
		return validation();
	}

}
function customOnKeydown(id, event){
	if(id=="InvoiceformBody"){
		return keycheck(id, event);
	}
	if(id="loginpage"){
		return keycheck(id, event);
	}
}
function customOnChange(id, event){
	if(id=="CompanyName"){
		ShowCompanyData();
	}

}
function fieldDisable(id){
	if(null != document.getElementById(id)){
		document.getElementById(id).disabled=true;
		if(id != "RequestFor" && id != "BillingCurrency")
			document.getElementById(id).value='';
	}
}
function fieldEnable(id){
	if(null != document.getElementById(id)){
		document.getElementById(id).disabled=false;
	}
}
function fieldReadWrite(id){
	if(null != document.getElementById(id)){
		document.getElementById(id).readOnly="readOnly";
	}
}
function calanderEnable(id){
	if(null != document.getElementById(id)){
		document.getElementById(id).style.display='';
	}
}
function calanderDisable(id){
	if(null != document.getElementById(id)){
		document.getElementById(id).style.display='none';
	}
}

function PasswordValidation(id){
	if(id.value != ''){
		var passwordRegEx1 = /[a-z]/g;
		var passwordRegEx2 = /[A-Z]/g;
		var passwordRegEx3 = /[0-9]/g;
		if(id.value.length < 8){
			alert("Please enter a valid Password.Password should be atleast of 8 characters.Password should contain atleast 1 numeral, 1 lower case letter and 1 upper case letter");
			id.focus(true);
		}else{
			var matching = passwordRegEx1.test(id.value);
			if(!matching){
				alert("Please enter a valid Password.Password should be atleast of 8 characters.Password should contain atleast 1 numeral, 1 lower case letter and 1 upper case letter");
				id.focus(true);
			}else{
				matching = passwordRegEx2.test(id.value);
				if(!matching){
					alert("Please enter a valid Password.Password should be atleast of 8 characters.Password should contain atleast 1 numeral, 1 lower case letter and 1 upper case letter");
					id.focus(true);
				}else{
					matching = passwordRegEx3.test(id.value);
					if(!matching){
						alert("Please enter a valid Password.Password should be atleast of 8 characters.Password should contain atleast 1 numeral, 1 lower case letter and 1 upper case letter");
						id.focus(true);
					}
				}
			}
		}
	}
}

function verifyEmail(id){

	var status = true;     
	if(trim(id.value)!=''){
		var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;

		if (id.value.search(emailRegEx) == -1) {

			alert("Please enter a valid email address.");
			status = false;
			id.focus(true);
		}
		
		if(status && id.name=='reqEmailID')
		{
			var arrayData = id.value.split("@");			
			if(trim(arrayData[1])=='daimler.com')
			{				
				status=true;
			}
			else
			{
				alert("Email ID should belongs to daimler Domain");
				status=false;
				id.focus(true);
			}
		}
	}
	return status;	
}

function phoneCheck(feild,key){

	var keycode = (key.which) ? key.which : key.keyCode;
	if(keycode == 08 || keycode == 127 || (keycode >= 48 && keycode <= 57)){
		return true;
	}else{
		return false;
	}
}

function avoidInputYash(feild,key){

	var keycode = (key.which) ? key.which : key.keyCode;
	if(keycode == 35){
		return false;
	}else{
		return true;
	}
}

function methodOnlyAlphabets(feild,key){

	var keycode = (key.which) ? key.which : key.keyCode;
	if(keycode == 32 || (keycode >=65 && keycode <= 90) || (keycode >=97 && keycode <= 122)){
		return true;
	}else{
		return false;
	}
}

function methodOnlyAlphaNumeric(feild,key){

	var keycode = (key.which) ? key.which : key.keyCode;
	if(keycode == 32 || (keycode >=65 && keycode <= 90) || (keycode >=97 && keycode <= 122)  || (keycode >= 48 && keycode <= 57)){
		return true;
	}else{
		return false;
	}
}

function trim(str)
{
	return str.replace(/^\s+|\s+$/g, '');
}


function doPostAjax(url,sParams)
{

	var retval="-1";
	var req = getACTObj();
	req.onreadystatechange = processRequest;
	req.open("POST",url, false);
	req.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	req.send(sParams);
	function processRequest()
	{
		if (req.readyState == 4)
		{

			if (req.status == 200)
				parseMessages();
			else
				retval='-1';
		}
	}
	function parseMessages()
	{
		retval=trim(req.responseText);
		//alert("Barcode Generated Successfully");
	}
	//document.getElementById('err').style.display = 'block';

	
	return retval;
}

function getACTObj()
{
	if(window.XMLHttpRequest)
		return new XMLHttpRequest

		var a=["Microsoft.XMLHTTP","MSXML2.XMLHTTP.6.0","MSXML2.XMLHTTP.5.0","MSXML2.XMLHTTP.4.0","MSXML2.XMLHTTP.3.0","MSXML2.XMLHTTP"];
	for(var c=0;c<a.length;c++)
	{
		try
		{
			return new ActiveXObject(a[c])
		}
		catch(b)
		{
			alert('Exception-'+b);
		}
	}
	return null;
}

function Fun_Ajax(url,params)				
{
	try
	{
		params=escape(params);
		var response="";			
		xmlReq = null;
		if(window.XMLHttpRequest) xmlReq = new XMLHttpRequest();
		else if(window.ActiveXObject) xmlReq = new ActiveXObject("Microsoft.XMLHTTP");
		if(xmlReq==null) return; // Failed to create the request
		request.open("POST",url,false);  
	 	 //request.setRequestHeader('Content-Type', 'multipart/form-data');
	 	   	var data = new FormData();
	 	   	data.append('InvoiceNo', document.getElementById('invoiceNo').value.trim());   
	 	   	data.append('DocType', document.getElementById('DocumentType').value); 
	 	   	data.append('file', document.getElementById('adddoc').files[0]);
	 	   	if((document.getElementById('adddocSupport').files.length)==1)
	 	   	{ 
	 		   data.append('file', document.getElementById('adddocSupport').files[0]);// newly added
	 	   	}
	 	   	request.send(data);
	 	   	alert("request sent");
		
		xmlReq.onreadystatechange = function()
		{	 
			switch(xmlReq.readyState)
			{
			case 0: // Uninitialized
				//alert("Uninitialized");
				break;
			case 1: // Loading
				//alert("Loading");
				break;
			case 2: // Loaded
				//alert("Loaded");
				break;
			case 3: // Interactive
				//alert("Interactive");
				break;
			case 4: // Done!
				if (xmlReq.status==200) 
				{
					response=xmlReq.responseText;						
				}
				else if (xmlReq.status==404)
				{
					//alert("URL doesn't exist!");
					response='FAIL';
				}
				else 
				{
					if(xmlReq.status==500)
						alert("Please RE-LOGIN");							
					else
						//alert("Status is "+xmlReq.status);							

						response='FAIL';
				}

				break;
			default:
				alert(xmlReq.status);
			response='FAIL';
			break;
			}
			addrow();
		}
		// Make the request	
		xmlReq.open('POST',url,false);		
		xmlReq.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		xmlReq.send(params);	
		document.getElementById('err').style.display = 'block';
	
		return response;
	}
	catch(e)
	{
		alert("Exception from Fun_Ajax() in UW_Ajax.js : "+e);
	}

}
function GetDocList(InvNo)
{
		//alert("Inside SecondScreenWebservice ");
		var str='';    
		var Transection_ID=InvNo;		
		
		var Grid_Table = document.getElementById('docDetails');   
	
		for(var row=1; row<Grid_Table.rows.length; row++)        
		{             
			for(var col=0; col<Grid_Table.rows[row].cells.length-1; col++)           
			{                 
				if(col==0)                   
				if(document.all)
				{		
					str=str+Transection_ID+','				
					str=str+Grid_Table.rows[row].cells[col].innerText;      
				}				
				else 
				{
					str=str+Transection_ID+','
					str=str+Grid_Table.rows[row].cells[col].textContent;      
				}				
				else   
				if(document.all)                         
				str=str+','+Grid_Table.rows[row].cells[col].innerText;                     
				else                         
				str=str+','+Grid_Table.rows[row].cells[col].textContent;            
			}            
				str=str+'~';            
		}       
		return str;
}

function fnValidatePAN(Obj) 
{
    if (Obj == null) Obj = window.event.srcElement;	
    if (trim(Obj.value) != "") {	
        ObjVal = Obj.value;
        var panPat = /^([a-zA-Z]{5})(\d{4})([a-zA-Z]{1})$/;
        //var code = /([C,P,H,F,A,T,B,L,J,G])/;
        //var code_chk = ObjVal.substring(3,4);        
		if (ObjVal.search(panPat) == -1) {
            return false;
        }
		return true;
        //if (code.test(code_chk) == false) {            
            //return false;
        //}
    }
	return true;
}

function fnValidateTAN(Obj) 
{
    if (Obj == null) Obj = window.event.srcElement;
    if (trim(Obj.value) != "") {	
        ObjVal = Obj.value;
        var tanPattern = /^([a-zA-Z]{4})(\d{5})([a-zA-Z]{1})$/;
        //var code = /([C,P,H,F,A,T,B,L,J,G])/;
        //var code_chk = ObjVal.substring(3,4);        
		if (ObjVal.search(tanPattern) == -1) {
            return false;
        }
		return true;
        //if (code.test(code_chk) == false) {            
            //return false;
        //}
    }
	return true;
}

function disableFields()
{
	setCursor();
	document.getElementById('invoiceNo').disabled=true;
	document.getElementById('invoiceDate').disabled=true;
	document.getElementById('billingAddrType').disabled=true;
	document.getElementById('billingAddress').disabled=true;
	document.getElementById('currency').disabled=true;
	document.getElementById('typeOfTxn').disabled=true;
	document.getElementById('poNo').disabled=true;
	document.getElementById('reqEmailID').disabled=true;
	document.getElementById('reqName').disabled=true;
	document.getElementById('typeOfInvoice').disabled=true;
	document.getElementById('baseValue').disabled=true;
	document.getElementById('serviceTax').disabled=true;
	document.getElementById('sbc').disabled=true;
	document.getElementById('kkc').disabled=true;
	document.getElementById('cst').disabled=true;
	document.getElementById('vat').disabled=true;
	document.getElementById('igst').disabled=true;
	document.getElementById('cgst').disabled=true;
	document.getElementById('sgst').disabled=true;
	document.getElementById('exciseDuty').disabled=true;
	document.getElementById('invoiceValue').disabled=true;
	document.getElementById('pan').disabled=true;
	document.getElementById('tan').disabled=true;
	document.getElementById('serviceRegNo').disabled=true;
	document.getElementById('tin').disabled=true;
	document.getElementById('stPerc').disabled=true;
	document.getElementById('cstPerc').disabled=true;
	document.getElementById('vatPerc').disabled=true;
	document.getElementById('edPerc').disabled=true;
}

function checkInvoiceDate(id) 
{
	var EnteredDate = id.value; //for javascript
	if(EnteredDate != null)
	{
		var invDateArr = EnteredDate.split("/");
		var date = invDateArr[0];
		var month = invDateArr[1];
		var year = invDateArr[2];				
		var myDate = new Date(year, month - 1, date);		
		var today = new Date();
		if (myDate > today) {
			return false;
		}			
	}
	return true;		
}

function checkAccountExpiryDate(id) 
{
	var EnteredDate = id.value; //for javascript
	if(EnteredDate != null)
	{
		var invDateArr = EnteredDate.split("/");
		var date = invDateArr[0];
		var month = invDateArr[1];
		var year = invDateArr[2];				
		var myDate = new Date(year, month - 1, date);		
		var today = new Date();
		if (myDate < today) {
			return false;
		}			
	}
	return true;		
}
function setCursor()
{
	 document.body.style.cursor = "progress";	
}
function ResetCursor()
{
	 document.body.style.cursor = "default";	
}


function  saveInvoiceData()
{

	try
	{	
		 setCursor();
		/*var VendorCode=document.getElementById('VendorCode').value;
		var CompanyName=document.getElementById('CompanyName').value;
		var VendorName=document.getElementById('VendorName').value;
		var AttentionTo=document.getElementById('AttentionTo').value;
		var InvoiceType=document.getElementById('RequestFor').value.trim();
		var VendorAddress=document.getElementById('VendorAddress').value;
		var CompanyAddress1=document.getElementById('CompanyAddress1').value;
		var InvoiceNumberInSystem=document.getElementById('InvoiceNumberInSystem').value;
		var InvoiceDate=document.getElementById('InvoiceDate').value;
		var VAT=document.getElementById('VAT').value;
		var OtherTax=document.getElementById('OtherTax').value;
		var OtherTaxType = document.getElementById("OtherTaxType").value;
		var Freight=document.getElementById('Freight').value;
		var Discount=document.getElementById('Discount').value;
		var AdditionalVAT=document.getElementById('AdditionalVAT').value;
		var PenaltyDeduction=document.getElementById('PenaltyDeduction').value;
		var TotalInvAmt=document.getElementById('TotalInvAmt').value;
		var VoucherNarration=document.getElementById('VoucherNarration').value;
		var FromDate=document.getElementById('FromDate').value;
		var ToDate=document.getElementById('ToDate').value;
		var CompanyCode=document.getElementById('CompanyCode').value;
		var InvoiceBaseAmt=document.getElementById('InvoiceBaseAmt').value;
		var PoNo=document.getElementById("PoNo").value;
		var BillingCurrency=document.getElementById("BillingCurrency").value.trim();
		var HigherEducationCess=document.getElementById("HigherEducationCess").value;
		var EducationCess=document.getElementById("EducationCess").value;
		var ServiceTax=document.getElementById("ServiceTax").value;*/
		
		var invoiceNo = document.getElementById('invoiceNo');
		var invoiceDate = document.getElementById('invoiceDate');
		var billingAddrType = document.getElementById('billingAddrType');
		var billingAddress = document.getElementById('billingAddress');
		var currency = document.getElementById('currency');
		var typeOfTxn = document.getElementById('typeOfTxn');
		var poNo = document.getElementById('poNo');
		var reqEmailID = document.getElementById('reqEmailID');//NON-PO
		var reqName = document.getElementById('reqName');//NON-PO
		var typeOfInvoice = document.getElementById('typeOfInvoice');
		var baseValue = document.getElementById('baseValue');
		var serviceTax = document.getElementById('serviceTax');
		var sbc = document.getElementById('sbc');
		var kkc = document.getElementById('kkc');
		var cst = document.getElementById('cst');
		var vat = document.getElementById('vat');
		var igst = document.getElementById('igst');
		var cgst = document.getElementById('cgst');
		var sgst = document.getElementById('sgst');
		var exciseDuty = document.getElementById('exciseDuty');
		var invoiceValue  = document.getElementById('invoiceValue');
		var pan = document.getElementById('pan');
		var tan  = document.getElementById('tan');
		var serviceRegNo = document.getElementById('serviceRegNo');
		var tin = document.getElementById('tin'); 
		
		//New Fields
		var stPerc = document.getElementById('stPerc');
		var cstPerc = document.getElementById('cstPerc');
		var vatPerc = document.getElementById('vatPerc');
		var edPerc = document.getElementById('edPerc');
		
		var vendorNo = document.getElementById('vendorNo').value;
		var vendorName = document.getElementById('vendorName').value;
		var vendorEmailId = document.getElementById('hiddenVendorEmailId').value;
		
		var filedata="";
	 	filedata=document.getElementById("adddoc");
		
		if(invoiceNo.value==null ||invoiceNo.value=='')
		{
			alert("Please Enter Invoice Number");
			invoiceNo.focus();
			return false;
		}
		 if(invoiceDate.value==null ||invoiceDate.value=='')
		{
			alert("Please Enter Invoice Date");
			invoiceDate.focus();
			return false;
		}
		if(!checkInvoiceDate(invoiceDate))
		{
			alert("Invoice Date cannot be greater than Current date ");
			invoiceDate.focus();
			return false;
		}
		if(billingAddrType.value==null ||billingAddrType.value=='')
		{
			alert("Please Choose Billing Address Type");
			billingAddrType.focus();
			return false;
		}
		if(billingAddress.value==null || billingAddress.value=='')
		{
			alert("Please Enter Billing Address");
			billingAddress.focus();
			return false;
		}
		 if(currency.value==null || currency.value=='')
		{
			alert("Please Select Currency");
			currency.focus();
			return false;
		} 
		 if(typeOfTxn.value==null || typeOfTxn.value=='' || typeOfTxn.value=="-- Select --")
		{
			alert("Please Select Type Of Transaction");
			typeOfTxn.focus();
			return false;	    
		}
		if((poNo.value==null || poNo.value=='') && typeOfTxn.value=='PO')
		{
			alert("Please Enter PO NO");
			poNo.focus();
			return false;
		}
		 if((reqEmailID.value==null || reqEmailID.value=='') && typeOfTxn.value=='Non PO')
		{
			alert("Please Enter Requestor Email ID");
			reqEmailID.focus();
			return false;
		}
		 if((reqName.value==null ||reqName.value=='') && typeOfTxn.value=='Non PO')
		{
			alert("Please Enter Requestor Name");
			reqName.focus();
			return false;
		}
		 if((typeOfInvoice.value==null || typeOfInvoice.value=='' || typeOfInvoice.value=="-- Select --") && typeOfTxn.value=='PO')
		{
			alert("Please Select Type Of Invoice");
			typeOfInvoice.focus();
			return false;	    
		}
		
		 if(baseValue.value==null || baseValue.value=='')
		{
			alert("Please Enter Base Value");
			baseValue.focus();
			return false;	    
		}
		/*if(serviceTax.value==null || serviceTax.value=='' )
		{
			alert("Please Enter Service Tax");
			serviceTax.focus();
			return false;	    
		}	*/
		//if(stPerc.value==null || stPerc.value=='' || stPerc.value=="-- Select --")
		//{
			//alert("Please Select Service Tax %");
			//stPerc.focus();
			//return false;	    
		//}
		/*
		if(sbc.value==null || sbc.value=='')
		{
			alert("Please Enter Swachh Bharat Cess");
			sbc.focus();
			return false;	    
		}
		if(kkc.value==null || kkc.value=='')
		{
			alert("Please Enter Krishi Kalyan Cess");
			kkc.focus();
			return false;	    
		}*/
		//if(cstPerc.value==null || cstPerc.value=='' || cstPerc.value=="-- Select --")
		//{
			//alert("Please Select CST %");
			//cstPerc.focus();
			//return false;	    
		//}		
		/*if(cst.value==null || cst.value=='')
		{
			alert("Please Enter CST");
			cst.focus();
			return false;	    
		}*/
		//if(vatPerc.value==null || vatPerc.value=='' || vatPerc.value=="-- Select --")
		//{
			//alert("Please Select VAT %");
			//vatPerc.focus();
			//return false;	    
		//}
		/*
		if(vat.value==null || vat.value=='')
		{
			alert("Please Enter VAT");
			vat.focus();
			return false;	    
		}
		if(igst.value==null || igst.value=='')
		{
			alert("Please Enter IGST");
			igst.focus();
			return false;	    
		}
		if(cgst.value==null || cgst.value=='')
		{
			alert("Please Enter CGST");
			cgst.focus();
			return false;	    
		}
		if(sgst.value==null || sgst.value=='' )
		{
			alert("Please Enter SGST");
			sgst.focus();
			return false;	    
		}
		*/
		//if(edPerc.value==null || edPerc.value=='' || edPerc.value=="-- Select --")
		//{
			//alert("Please Select ED %");
			//edPerc.focus();
			//return false;	    
		//}
		/*
		if(exciseDuty.value==null || exciseDuty.value=='')
		{
			alert("Please Enter Excise Duty");
			exciseDuty.focus();
			return false;	    
		}*/
	
		if(invoiceValue.value==null || invoiceValue.value=='')
		{
			alert("Please Enter Invoice Value");
			invoiceValue.focus();
			return false;	    
		}
		/*if(pan.value==null || pan.value=='')
		{
			alert("Please Enter PAN");
			pan.focus();
			return false;	    
		}
		if(tan.value==null || tan.value=='')
		{
			alert("Please Enter TAN");
			tan.focus();
			return false;	    
		}
		if(serviceRegNo.value==null || serviceRegNo.value=='')
		{
			alert("Please Enter Service Registration No");
			serviceRegNo.focus();
			return false;	    
		}
		if(tin.value==null || tin.value=='')
		{
			alert("Please Enter TIN");
			tin.focus();
			return false;	    
		}*/
		
		if(filedata.value==null ||filedata.value=='')
	  	{
	  		alert("Please Choose a file");
	  		filedata.focus();
	  		return false;
	  	}
		
		var format = getFileExtension(document.getElementById("adddoc")).toUpperCase();
	 	if(!(format=='PDF' ||  format=='TIF' || format=='TIFF'))
		{
	 		alert("Kindly upload the document in PDF/TIF/TIFF format");
	  		document.getElementById('adddoc').focus();
	  		return false;
		}//till here
	 	
	 	
	// 	alert("file length"+document.getElementById("adddocSupport").files.length);
	 	if(document.getElementById("adddocSupport").files.length!=0)
	 	{
	 		var format = getFileExtension(document.getElementById("adddocSupport")).toUpperCase();
	 		if(!(format=='PDF' ||  format=='TIF' || format=='TIFF'))
	 		{
	 		alert("Kindly upload the document in PDF/TIF/TIFF format");
	  		document.getElementById('adddocSupport').focus();
	  		return false;
	 		}
	 	} //till here
	 	
	 	if(GetFileSize())
		{		 						
	 	var params = "?invoiceNo="+invoiceNo.value;
		params += "&vendorNo="+vendorNo;
		params += "&vendorName="+vendorName;
		params += "&vendorEmailId="+vendorEmailId;
		params += "&invoiceDate="+invoiceDate.value;
		params += "&billingAddrType="+billingAddrType.value;
		params += "&billingAddress="+billingAddress.value;
		params += "&currency="+currency.value;
		params += "&typeOfTxn="+typeOfTxn.value;
		params += "&poNo="+poNo.value;
		params += "&reqEmailID="+reqEmailID.value;
		params += "&reqName="+reqName.value;
		params += "&typeOfInvoice="+typeOfInvoice.value;
		params += "&baseValue="+baseValue.value;
		params += "&serviceTax="+serviceTax.value;
		params += "&sbc="+sbc.value;
		params += "&kkc="+kkc.value;
		params += "&cst="+cst.value;
		params += "&vat="+vat.value;
		params += "&igst="+igst.value;
		params += "&cgst="+cgst.value;
		params += "&sgst="+sgst.value;
		params += "&exciseDuty="+exciseDuty.value;
		params += "&invoiceValue="+invoiceValue.value; 
		params += "&pan="+pan.value;
		params += "&tan="+tan.value;
		params += "&serviceRegNo="+serviceRegNo.value;
		params += "&tin="+tin.value;
		//New Added
		params += "&stPerc="+stPerc.value;
		params += "&cstPerc="+cstPerc.value;
		params += "&vatPerc="+vatPerc.value;
		params += "&edPerc="+edPerc.value;
		
	//	var url = "JSP/SubmitInvoiceDetails.jsp";
	//	url = url + params;		
		
		
		var url="${pageContext.request.contextPath}/AddDocumentServlet?pid="+params;
		
		alert("url--->"+url);
		//alert("Final URL---->"+url);`	
		//var url="JSP/SubmitInvoiceDetails.jsp"+"?"+"&VendorCode="+VendorCode+"&CompanyName="+CompanyName+"&VendorName="+VendorName+"&AttentionTo="+AttentionTo+"&RequestFor="+InvoiceType+"&VendorAddress="+VendorAddress+"&CompanyAddress1="+CompanyAddress1+"&InvoiceNumberInSystem="+InvoiceNumberInSystem+"&InvoiceDate="+InvoiceDate+"&VAT="+VAT+"&OtherTax="+OtherTax+"&Freight="+Freight+"&Discount="+Discount+"&AdditionalVAT="+AdditionalVAT+"&PenaltyDeduction="+PenaltyDeduction+"&TotalInvAmt="+TotalInvAmt+"&VoucherNarration="+VoucherNarration+"&FromDate="+FromDate+"&ToDate="+ToDate+"&CompanyCode="+CompanyCode+"&InvoiceBaseAmt="+InvoiceBaseAmt+"&PoNo="+PoNo+"&BillingCurrency="+BillingCurrency+"&HigherEducationCess="+HigherEducationCess+"&EducationCess="+EducationCess+"&ServiceTax="+ServiceTax+"&OtherTaxType="+OtherTaxType;
		//alert(url);
		$(".loader").fadeIn("slow");		 
		var ReturnVal=Fun_Ajax(url,"");
		//alert(trim(ReturnVal));
		if(trim(ReturnVal)=='No Response' || trim(ReturnVal)=='FAIL' || trim(ReturnVal)=='' || trim(ReturnVal)==null || trim(ReturnVal)=='Pending')
		{
			document.getElementById("err").innerHTML="Internal Error while connecting to iBPS Server. Please try again...";
			document.getElementById("error").style.display='';
		//	document.getElementById('Add-Document').disabled = true;//Disable the Attach Document Button
		}
		else
		{   setCursor();
			//document.getElementById("err").innerHTML="Invoice Data has been validated successfully. Kindly initiate this Invoice";
			document.getElementById("error").style.display='';
			if(document.getElementById('BtnSubmit')!=null || (document.getElementById('BtnSubmit')!="null"))
			{	
	          //  document.getElementById('BtnSubmit').disabled = true;
	          //  document.getElementById('Add-Document').disabled = false;//Enable the Attach Document Button
	            document.getElementById('h_PID').value=trim(ReturnVal);
	            disableFields();
	            addDoc(); 
	        } 
		}
		
		$(".loader").fadeOut("slow");
		ResetCursor();
		alert(document.getElementById("err").innerHTML);
		//window.scrollTo(0, 0);
		
		/*var array=ReturnVal.split("~");
		var barcodeno=array[1];
		document.getElementById("hiddenNextInvNo").value=barcodeno;
		$(".loader").fadeOut("slow");
		document.getElementById("err").innerHTML=ReturnVal;
		document.getElementById("error").style.display='';
		if(document.getElementById('BtnSubmit')!=null || (document.getElementById('BtnSubmit')!="null")){
            document.getElementById('BtnSubmit').disabled = true;
        } 
		if(document.getElementById('btnbarcode')==null || (document.getElementById('btnbarcode')=="null")){

		}
		else
		{
			document.getElementById('btnbarcode').style.display="block";
		}
		window.scrollTo(0, 0);*/
		}
	 	 else
	  	 {
	 	  	alert("Document size cannot exceed more than 2 MB.");	 
	 	 } // till here
	 	
	}catch(e)
	{
		alert("Exception from saveInvoiceData function"+e);
	}

}

//Method to show mandatory fields
function setMandatoryFocus(Mfield)
{
	var MfieldFocus=null;
	MfieldFocus=new Array();
	var NOTMfieldFocus=null;
	NOTMfieldFocus=new Array();
	for(var i=0;i<Mfield.length;i++)
	{
		var fvalue=document.getElementById(Mfield[i]).value;
		if(!fvalue)
			MfieldFocus.push(Mfield[i]);
		else NOTMfieldFocus.push(Mfield[i]);


	}

	for(var i=0;i<MfieldFocus.length;i++)
	{
		document.getElementById(MfieldFocus[i]).style.border="2px solid red";
		document.getElementById(MfieldFocus[i]).focus();
	}
	for(var i=0;i<NOTMfieldFocus.length;i++)
		document.getElementById(NOTMfieldFocus[i]).style.border="1px solid #ccc";
	return  MfieldFocus;

}

function submitForm(){

	var vendorCode=document.getElementById('vendorCode').value;

	var vendorName=document.getElementById('vendorName').value;
	var companyCode=document.getElementById('companyCode').value;
	var ButtonType=document.getElementById('ButtonType').value;
	var hiddenLink=document.getElementById('hiddenLink').value;


	var	vendorAdd = document.getElementById('vendorAdd').value;
	var vendorEmailId = document.getElementById('vendorEmailId').value;
	var sPOC = document.getElementById('sPOC').value;
	var sPOCEmailId = document.getElementById('sPOCEmailId').value;
	var currency = document.getElementById('currency').value ;
	var url="";

	if(trim(document.getElementById('vendorCode').value) == ''){
		alert("Please Enter Vendor Code");
		document.getElementById('vendorCode').focus();
	}else if(document.getElementById('vendorName').value == ''){
		alert("Please Enter Vendor Name");
		document.getElementById('vendorName').focus();
	}else if(trim(document.getElementById('companyCode').value) == ''){
		alert("Please Enter Company Code");
		document.getElementById('companyCode').focus();
	}else{
		if(document.getElementById('hiddenLink').value != null && document.getElementById('hiddenLink').value != 'null' && document.getElementById('hiddenLink').value == 'VendorDetails'){
			ButtonType = 'Update';
			url="JSP/SubmitNewVendor.jsp"+"?"+"&vendorCode="+vendorCode+"&vendorName="+vendorName+"&companyCode="+companyCode+"&ButtonType="+ButtonType+"&hiddenLink="+hiddenLink+"&vendorAdd="+vendorAdd+"&vendorEmailId="+vendorEmailId+"&sPOC="+sPOC+"&sPOCEmailId="+sPOCEmailId+"&currency="+currency;

		}else{
			ButtonType = 'Insert';
			url="SubmitNewVendor.jsp"+"?"+"&vendorCode="+vendorCode+"&vendorName="+vendorName+"&companyCode="+companyCode+"&ButtonType="+ButtonType+"&hiddenLink="+hiddenLink+"&vendorAdd="+vendorAdd+"&vendorEmailId="+vendorEmailId+"&sPOC="+sPOC+"&sPOCEmailId="+sPOCEmailId+"&currency="+currency;

		}

		var ReturnVal=Fun_Ajax(url,"");
//		alert(trim(ReturnVal));
	}
}


/* This method is used to check whether Company name is null, 
 * If we select company address field, First we have select Company Name.
 */

function checkCompanyName()
{
	var CompanyName=document.getElementById('CompanyName').value;
	if(CompanyName==null ||CompanyName=='')
	{
		alert("Select Company Name");
		document.getElementById('CompanyName').focus();
		return false;
	}
}

function getHttpObject(){
	var xmlhttp;
	if (window.XMLHttpRequest)   
	{
		xmlhttp=new XMLHttpRequest();   
	} else{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); 
		
	}
	return xmlhttp;	
}


/* This function is used for User name validation */
function UserNameValidation(id){   
	if(id.value != ''){
		var userNameRegEx = /^[A-Za-z0-9.-@_]*$/;
		var matching = id.value.match(userNameRegEx);
		if(matching == null){
			alert("Please Enter a valid User ID.\n Allowed Characters are [a-z], [A-Z], [0-9], @, -, _, .");
			id.focus(true);
			return false;
		}
	}
	return true;
}


//Declaring valid date character, minimum year and maximum year
var dtCh= "/";
var minYear=1900;
var maxYear=2100;

function isInteger(s){
	var i;
    for (i = 0; i < s.length; i++){   
        // Check that current character is number.
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    // All characters are numbers.
    return true;
}

function stripCharsInBag(s, bag){
	var i;
    var returnString = "";
    // Search through string's characters one by one.
    // If character is not in bag, append to returnString.
    for (i = 0; i < s.length; i++){   
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}

function daysInFebruary (year){
	// February has 29 days in any year evenly divisible by four,
    // EXCEPT for centurial years which are not also divisible by 400.
    return (((year % 4 == 0) && ( (!(year % 100 == 0)) || (year % 400 == 0))) ? 29 : 28 );
}
function DaysArray(n) {
	for (var i = 1; i <= n; i++) {
		this[i] = 31
		if (i==4 || i==6 || i==9 || i==11) {this[i] = 30}
		if (i==2) {this[i] = 29}
   } 
   return this;
}

function isDate(dtStr){
	var daysInMonth = DaysArray(12);
	var pos1=dtStr.indexOf(dtCh);
	var pos2=dtStr.indexOf(dtCh,pos1+1);
	var strDay=dtStr.substring(0,pos1);
	var strMonth=dtStr.substring(pos1+1,pos2);
	var strYear=dtStr.substring(pos2+1);
	strYr=strYear;
	if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1);
	if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1);
	for (var i = 1; i <= 3; i++) {
		if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1);
	}
	month=parseInt(strMonth);
	day=parseInt(strDay);
	year=parseInt(strYr);
	if (pos1==-1 || pos2==-1){
		alert("Date format should be : dd/mm/yyyy");
		return false;
	}
	if (strMonth.length<1 || month<1 || month>12){
		alert("Please Enter a valid month");
		return false;
	}
	if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
		alert("Please Enter a valid day");
		return false;
	}
	if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
		alert("Please Enter a valid 4 digit year between "+minYear+" and "+maxYear);
		return false;
	}
	if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
		alert("Please Enter a valid date");
		return false;
	}
	return true;
}

function validateDateFormat(id){
	var dt=document.getElementById(id);
	if(trim(dt.value)!='')
	{
		if (isDate(dt.value)==false){
			dt.focus();
			return false;
		}
	}
    return true;
 }
