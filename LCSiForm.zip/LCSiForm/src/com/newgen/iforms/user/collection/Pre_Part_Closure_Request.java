package com.newgen.iforms.user.collection;

import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.FormDef;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.iforms.user.collection.services.CollectionCommonServices;
import com.newgen.iforms.user.collection.services.Status;

/********************************************************************
 * NEWGEN SOFTWARE TECHNOLOGIES LIMITED Group : CIG Product / Project : CAGL_LCS
 * Module : <IFormUser> File Name : <File Name> Author : <Sidhant Mittal> Date
 * written : 13/07/2020 (DD/MM/YYYY) Description : <Description> CHANGE HISTORY
 ***********************************************************************************************
 * Date Change By Change Description (Bug No. (If Any)) (DD/MM/YYYY)
 ************************************************************************************************/

public class Pre_Part_Closure_Request implements IFormServerEventHandler {
	private IFormReference ifr = null;
	CollectionCommonMethod cm = null;

	public Pre_Part_Closure_Request(CollectionCommonMethod cm, IFormReference ifr) {
		cm.mRepLogger.info("<--Inside Pre_Part_Closure_Request-->");
		// logger = new CustomLogger();
		this.ifr = ifr;
		this.cm = cm;
	}

	@Override
	public void beforeFormLoad(FormDef arg0, IFormReference arg1) {
		// TODO Auto-generated method stub
	}

	@Override
	public String executeCustomService(FormDef arg0, IFormReference arg1, String arg2, String arg3, String arg4) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONArray executeEvent(FormDef arg0, IFormReference arg1, String arg2, String arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String executeServerEvent(IFormReference ifr, String ControlID, String EventType, String JSdata) {
		cm.mRepLogger.info("Pre_Part_Closure_Request: Inside executeServerEvent");
		cm.mRepLogger.info("Pre_Part_Closure_Request: ControlID : " + ControlID);
		cm.mRepLogger.info("Pre_Part_Closure_Request: EventType : " + EventType);
		cm.mRepLogger.info("Pre_Part_Closure_Request: JSdata : " + JSdata);

		// this.ifr = ifr;

		// CollectionCommonMethod cm = new CollectionCommonMethod(ifr);

		if (EventType.equalsIgnoreCase("formLoad")) {

		}
		if (ControlID.equalsIgnoreCase("preClosureFetch")) {
			return cm.fetchPreClosure();
		}
		if (ControlID.equalsIgnoreCase("PrePartClosureRequestFormSubmit")) {
			cm.mRepLogger.info("PrePartClosureRequestFormSubmit");
			String nextWorkstep = ifr.getValue("Target_Workstep").toString();
			if (nextWorkstep.equalsIgnoreCase("Charge_Waiver") || nextWorkstep.equalsIgnoreCase("Payment_Posting")) {
				return cm.getNextApprover(nextWorkstep, "").toString();
			} else {
				ifr.setValue("QRole", "");
			}

		}
		if (ControlID.equalsIgnoreCase("customApproveRejectLogicOnFormSubmit")) {
			cm.mRepLogger.info("Initiator executeServerEvent Inside customApproveRejectLogicOnFormSubmit: ");
			cm.mRepLogger.info("For Control ID -->" + JSdata);
			String targetWS = cm.PopulateTargetWsOnFormSubmitForDecisionAction(ifr.getActivityName(), ifr);
			return targetWS;
		}
		if (ControlID.equalsIgnoreCase("OnchangePTPdays")) {

			return cm.OnchangePTPdays(JSdata);

		}
		if (ControlID.equalsIgnoreCase("OnchangeFPTPdays")) {

			return cm.OnchangeFPTPdays(JSdata);
		}
		if (ControlID.equalsIgnoreCase("SkipTraceFetchBtn")) {
			String columnNames1 = "Questions,options,Traced,Remarks";
			String inputQuery = "SELECT Questionnaire,'' as Options,'' AS traced,'' AS Remarks FROM NG_LCS_Master_Questions ";
			String controlName1 = "SkipTraceListView";
			cm.populateListView(columnNames1, inputQuery, controlName1, ifr);
			String OptionQuery = "SELECT  Options FROM NG_LCS_Master_Questions WITH (NOLOCK)";
			cm.populateListViewComboTable(OptionQuery, controlName1, ifr, 1);// (1-options)

		}
		if (ControlID.equalsIgnoreCase("PARVisitFetchBtn")) {
			String columnNames2 = "Questions,Options,Remarks";
			String inputQuery = "SELECT Questionnaire,'' as Options,'' AS Remarks FROM NG_LCS_Master_Questions WITH (NOLOCK) WHERE Stage='QCO-Skip Customer' OR Stage = 'QCO-Skip Vehicle' OR Stage = 'QCO-PAR'";
			String controlName2 = "PARVisitListView";
			cm.populateListView(columnNames2, inputQuery, controlName2, ifr);
			String OptionQuery = "SELECT  Options FROM NG_LCS_Master_Questions WITH (NOLOCK) WHERE Stage='QCO-Skip Customer' OR Stage = 'QCO-Skip Vehicle' OR Stage = 'QCO-PAR'";
			cm.populateListViewComboTable(OptionQuery, controlName2, ifr, 1);

		}

		if (ControlID.equalsIgnoreCase("DocumentGeneration")) {
			if (EventType.equalsIgnoreCase("FormLoad")) {
				return cm.onformLoadHandler_OutDocument_CAGL(ifr, ControlID, EventType, JSdata, ifr.getActivityName());
			} else {
				// Generate Document - By Vaibhav
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WITH(NOLOCK) WHERE Document_Name='"
						+ doctype + "'";
				cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
				try {

					Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
					JSONObject jRet = new JSONObject();
					jRet.put("Status", Boolean.toString(docStatus.isStatus()));
					jRet.put("Msg", docStatus.getMsg());
					jRet.put("SubMsg", docStatus.getSubMsg());
					jRet.put("DocName", doctype);
					// saving the outward document grid.
					cm.saveDocData();
					return jRet.toString();

				} catch (Exception e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					cm.mErrLogger.info("Error in executeserverevent-->" + e.getMessage());
				}

			}

		}
		if (ControlID.equalsIgnoreCase("Document_ID_CHECK")) {

			return cm.getDocumentId(JSdata, ifr);
		}

		if (ControlID.equalsIgnoreCase("Inward_Doc_ID")) {
			return cm.getDocumentId(JSdata, ifr);
		}
		if (ControlID.equalsIgnoreCase("Applicanttypewithname-Inward")) {
			String processInstanceId = ifr.getObjGeneralData().getM_strProcessInstanceId();
			cm.mRepLogger.info("PROCESS INSTANCE ID IS  ----->" + processInstanceId);

			String OptionQuery = "SELECT concat(Applicant_Type,' - ',customer_full_name) "
					+ "AS Applicant_Type ,Customer_ID  FROM CMPLX_COLL_CI_CustomerInformation_Details_Grid with(nolock) where TransactionId='"
					+ processInstanceId + "'";
			cm.mRepLogger.info("OptionQuery " + OptionQuery);

			String controlName = "InwardDocumentGrid_ApplicantTypewithName";
			cm.populateListViewCombo(OptionQuery, controlName, ifr);

		}
		if (ControlID.equalsIgnoreCase("InwardDocumentGrid_ApplicantTypewithName")) {
			String processInstanceId = ifr.getObjGeneralData().getM_strProcessInstanceId();
			cm.mRepLogger.info("PROCESS INSTANCE ID IS  ----->" + processInstanceId);
			String Query = "SELECT concat(Applicant_Type,' - ',customer_full_name) "
					+ "AS Applicant_Type  FROM CMPLX_COLL_CI_CustomerInformation_Details_Grid with(nolock) where TransactionId='"
					+ processInstanceId + "' AND Customer_ID='"
					+ ifr.getValue("InwardDocumentGrid_ApplicantTypewithName") + "'";
			cm.mRepLogger.info("Query " + Query);
			List<List<String>> OptionsArray = ifr.getDataFromDB(Query);
			cm.mRepLogger.info("OptionsArray " + OptionsArray);
			int arraySize = OptionsArray.size();
			if (arraySize > 0) {
				ifr.setValue("InwardDocumentGrid_hiddenApplicantTypewithName", OptionsArray.get(0).get(0));

			}
		}
		if (ControlID.equalsIgnoreCase("fetchOnDemandData")) {
			cm.mRepLogger.info("executeServerEvent Inside fetchOnDemandData: ");
			cm.mRepLogger.info("For Control ID -->" + JSdata);
			cm.populateDumpData(JSdata, ifr.getValue("Loan_Account_No").toString(), ifr);

			//setting the role of the user in the role variable only if user clicks the decision tab.
			if(JSdata.contains("fetchBtnActionHistory")){ 
				cm.setRoleOfUser();
			}

		}
		if (ControlID.equalsIgnoreCase("postDocGenOrUpdate")) {

			// saving the outward document grid.
			cm.saveDocData();
		}
		if (ControlID.equalsIgnoreCase("apportionmentFetch")) {

			// saving the outward document grid.
			cm.fetchApportionmentData(JSdata);
		}
		if(ControlID.equalsIgnoreCase("DisableTabOnLoad")) {
			 cm.disableTabsOnLoad();
			
		}
		
		if(ControlID.equalsIgnoreCase("getTabIdToValidate")) {
			return cm.getTabIdToValidate(JSdata);
			
		}
		if(ControlID.equalsIgnoreCase("repaymentScheduleFetch")) {
			return cm.fetchRepaySchedule();
			
		}
		if(ControlID.equalsIgnoreCase("validateWaiveOffAmt")){ 
			
			return cm.validateWaiveOffAmt();
		}
		if(ControlID.equalsIgnoreCase("getWaiveOffIDs")){ 
			
			return cm.getWaiveOffIDs();
		}
		if(ControlID.equalsIgnoreCase("OnChangeActionCode")) {
			
			cm.mRepLogger.info("Inside OnChangeActionCode");
			String fieldsToCLear = cm.actionCodeOnChange(JSdata);
			cm.mRepLogger.info("Returning Old Fields that are to be cleared -->" + fieldsToCLear);
			return fieldsToCLear;
		}
		if(ControlID.equalsIgnoreCase("getCurrentUserRole")) {

			return cm.getCurrentUserRole();

		}
		if(ControlID.equalsIgnoreCase("getMandatoryInwardDocsToValidate")) {
			
			return cm.getMandatoryInwardDocsToValidate(JSdata);
		}
		
		if(ControlID.equalsIgnoreCase("ManualReceiptValidation")) {
			return cm.ManualreceiptValidation(JSdata);
		
		}
		
		if(ControlID.equalsIgnoreCase("ActionHistoryData")) {
			cm.actionAndDecisionHistoryUpdation("ActionHistory",JSdata);
			
		}
	
		if(ControlID.equalsIgnoreCase("DecisionHistoryData")) {
			cm.actionAndDecisionHistoryUpdation("DecisionHistory",JSdata);
			
		}
		if(ControlID.equalsIgnoreCase("setInwardDocumentCategory")) {
			
			return cm.setInwardDocumentCategory(JSdata);
		}
		
		if(ControlID.equalsIgnoreCase("GenerateSOA")) {

		CollectionCommonServices cs = new CollectionCommonServices(ifr);
		JSONObject jRet=new JSONObject();
		
		try {

			String st=cs.GenerateSOA(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);

			if(st!=null && st.equalsIgnoreCase("SUCCESS")){ 
				
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
						+ doctype + "'";
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
				
				cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
				jRet.put("Status", Boolean.toString(docStatus.isStatus()));
				jRet.put("Msg", docStatus.getMsg());
				jRet.put("SubMsg", docStatus.getSubMsg());
				jRet.put("DocName", doctype);
				
			}else if(st!=null && st.startsWith("FAILED")){ 
				
				jRet.put("Status", Boolean.toString(false));
				jRet.put("Msg", st.split("~~")[1]);
				jRet.put("SubMsg", "NA");
				jRet.put("DocName", "SOA");
				
			}
			
			// saving the outward document grid.
			cm.saveDocData();
			
		} catch (Exception e) {
			cm.mErrLogger.info("Error in generating the SOA execute server event-->",e);
			jRet.put("Status", Boolean.toString(false));
			jRet.put("Msg", "Issue in generating the Document :");
			jRet.put("SubMsg", "NA");
			jRet.put("DocName", "SOA");
		}
		
		return jRet.toString();
		
//		return cs.GenerateSOA(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);
		
		//below code to be removed and above return statement to be uncommented.
		/*String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='SOA'";
		cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
		List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
		cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
		try {
			cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
		
		if(ControlID.equalsIgnoreCase("GenerateRepaymentSchedule")) {
		CollectionCommonServices cs = new CollectionCommonServices(ifr);
		JSONObject jRet=new JSONObject();
		
		try {

			String st=cs.GenerateRepaymentSchedule(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);
			
			if(st!=null && st.equalsIgnoreCase("SUCCESS")){ 
				
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
						+ doctype + "'";
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
				
				cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
				jRet.put("Status", Boolean.toString(docStatus.isStatus()));
				jRet.put("Msg", docStatus.getMsg());
				jRet.put("SubMsg", docStatus.getSubMsg());
				jRet.put("DocName", doctype);
				
			}else if(st!=null && st.startsWith("FAILED")){ 
				
				jRet.put("Status", Boolean.toString(false));
				jRet.put("Msg", st.split("~~")[1]);
				jRet.put("SubMsg", "NA");
				jRet.put("DocName", "Loan Repayment Schedule");
				
			}
			
			// saving the outward document grid.
			cm.saveDocData();
			
		} catch (Exception e) {
			cm.mErrLogger.info("Error in generating the Loan Repayment Schedule execute server event-->",e);
			jRet.put("Status", Boolean.toString(false));
			jRet.put("Msg", "Issue in generating the Document :");
			jRet.put("SubMsg", "NA");
			jRet.put("DocName", "Loan Repayment Schedule");
		}
		
		return jRet.toString();

	}
		
		if(ControlID.equalsIgnoreCase("validateSettlement")){ 
			
			return cm.validateSettlement();
		}
		return "Pre_Part_Closure_Request Complete!!";
	}

	@Override
	public String getCustomFilterXML(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String setMaskedValue(String arg0, String arg1) {
		// TODO Auto-generated method stub
		return arg1;
	}

	@Override
	public JSONArray validateSubmittedForm(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}
}