
/*      
'-----------------------------------------------------------------------------------------------
'      NEWGEN SOFTWARE TECHNOLOGIES LIMITED
'   Group                  : EMEA
'   Product/Project/Utility: BOM - Mobility
'   Module                 : CMS - Server Implementaion
'   File Name              : ReadProperty.java
'   Author                 : Alex,Aseesh
'   Date created           : 30.07.2019
'   Description            : Custom file for reading the property files.
'   ---------------------------------------------------------------------------------------------
'   CHANGE HISTORY
'   ---------------------------------------------------------------------------------------------
'   Date:        Bug ID:   Change By :     Change Description
'   ---------------------------------------------------------------------------------------------
*/
package com.newgen.iforms.user.collection;


//import com.newgen.mcap.core.external.logging.concrete.LogMe;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
//import com.newgen.mcap.core.external.logging.concrete.LogMe;


public class ReadProperty {

    private Properties prop = new Properties();
    static Map<String, String> Mmap = null;
    static ReadProperty SingleObj = null;

    private ReadProperty() 
    {
        
    }

    private ReadProperty(String path) {
        try {
              
            FileInputStream In = new FileInputStream(path);
            prop.load(In);
            In.close();
            Load();
          //  NGUtil.writeConsoleLog("TransactionFree", "CMS", "loaded the ODD property file");
        } catch (FileNotFoundException ex) {
//        	 LogMe.logMe(LogMe.LOG_LEVEL_DEBUG,"File not Found Exception Occured while reading the config file");
        } catch (IOException ex) {
//        	LogMe.logMe(LogMe.LOG_LEVEL_DEBUG, "IO Exception Occured while reading the config file");
        }

    }

    public static ReadProperty getInstance(String Path) {
       //if (SingleObj == null) {
            SingleObj = new ReadProperty(Path);
       // }
        return SingleObj;
    }
    //    -------------------------------------------------------------------
/*
     Function Name           : Load
     Input Parameters        : void
     Output parameters       : void
     Return Values           : void
     Description             : To Load the property file into map
     Global variables        : Mmap,property Object
     Author                  : Aravindan P
     Date                    : 23/03/2018
     */

    private void Load() {
        if (Mmap == null) {
            Mmap = new HashMap<>();
        }
        Set<String> name = prop.stringPropertyNames();
        for(String Name : name)
        {
             Mmap.put(Name, prop.getProperty(Name));
        }
//        name.stream().forEach((Name) -> {
//            Mmap.put(Name, prop.getProperty(Name));
//        });

    }
    //    -------------------------------------------------------------------
/*
     Function Name           : getvalue
     Input Parameters        : Property Name
     Output parameters       : void
     Return Values           : void
     Description             : To Load the property file into map
     Global variables        : Mmap,property Object
     Author                  : Aravindan P
     Date                    : 23/03/2018
     */

    public String getvalue(String Name) {
        return Mmap.get(Name);
    }

}
