package com.newgen.iforms.user.collection;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import com.newgen.iforms.FormDef;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.iforms.user.collection.services.CollectionCommonServices;
import com.newgen.iforms.user.collection.services.Status;
import com.newgen.json.parser.JSONParser;

import jdk.nashorn.internal.scripts.JS;

/********************************************************************
 * NEWGEN SOFTWARE TECHNOLOGIES LIMITED Group : CIG Product / Project : CAGL_LCS
 * Module : <IFormUser> File Name : <File Name> Author : <Sidhant Mittal> Date
 * written : 13/07/2020 (DD/MM/YYYY) Description : <Description> CHANGE HISTORY
 ***********************************************************************************************
 * Date Change By Change Description (Bug No. (If Any)) (DD/MM/YYYY)
 ************************************************************************************************/

public class Initiator implements IFormServerEventHandler {
	private IFormReference ifr = null;
	CollectionCommonMethod cm = null;
	CollectionCommonServices cs = null;
	public Initiator(CollectionCommonMethod cm,IFormReference ifr) {
		cm.mRepLogger.info("<--Inside Initiator-->");
		// logger = new CustomLogger();
		this.ifr = ifr;
		this.cm=cm;
	}

	@Override
	public void beforeFormLoad(FormDef arg0, IFormReference arg1) {
		// TODO Auto-generated method stub
	}

	@Override
	public String executeCustomService(FormDef arg0, IFormReference arg1, String arg2, String arg3, String arg4) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONArray executeEvent(FormDef arg0, IFormReference arg1, String arg2, String arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String executeServerEvent(IFormReference ifr, String ControlID, String EventType, String JSdata) {
		cm.mRepLogger.info("Initiator: Inside executeServerEvent");
		cm.mRepLogger.info("Initiator: ControlID : " + ControlID);
		cm.mRepLogger.info("Initiator: EventType : " + EventType);
		cm.mRepLogger.info("Initiator: JSdata : " + JSdata);

//		this.ifr = ifr;

//		CollectionCommonMethod cm = new CollectionCommonMethod(ifr);
		// Document_Generation dg = new Document_Generation();

		/*
		 * if (EventType.equalsIgnoreCase("formLoad")) {
		 * 
		 * }
		 * 
		 * if (ControlID.equalsIgnoreCase("InitiatorFormSubmit")) {
		 * cm.mRepLogger.info("Inside Control ID:InitiatorFormSubmit"); String
		 * nextWorkstep = ifr.getValue("Target_Workstep").toString(); if
		 * (nextWorkstep.equalsIgnoreCase("Collection_Escalation") ||
		 * nextWorkstep.equalsIgnoreCase("Payment_Posting")) {
		 * cm.getNextApprover(nextWorkstep, ""); }
		 * 
		 * }
		 * 
		 * if (ControlID.equalsIgnoreCase("OnChangeActionCode")) {
		 * cm.mRepLogger.info("Inside OnChangeActionCode");
		 * cm.actionCodeOnChange(JSdata); }
		 */

		String columnNames = "";
		String fieldNames = "";
		String tableName = "";
		switch (ControlID) {
		case "GetActionCodeValue": {
			cm.mRepLogger.info("Initiator executeServerEvent Inside GetActionCodeValue: ");
			return cm.getActionCodeValues(ifr.getActivityName(), ifr);
		}
		case "fetchOnDemandData": {
			cm.mRepLogger.info("Initiator executeServerEvent Inside fetchOnDemandData: ");
			cm.mRepLogger.info("For Control ID -->" + JSdata);
			cm.populateDumpData(JSdata, ifr.getValue("Loan_Account_No").toString(), ifr);
			
			//setting the role of the user in the role variable only if user clicks the decision tab.
			if(JSdata.contains("fetchBtnActionHistory")){ 
				cm.setRoleOfUser();
			}
			
			break;
		}
		case "populateApplicantTypeAndName": {
			cm.mRepLogger.info("Inside populateApplicantTypeAndName");
			return cm.populateApplicantType(ifr);
		}
		case "getWIInitiatorRole": {

			cm.mRepLogger.info("Initiator executeServerEvent Inside getWIInitiatorRole: ");
			String userName = ifr.getUserName();
			String query = "select LCS_User_Group from RLOS_master_users with (NOLOCK) where user_id = '" + userName + "'";
			cm.mRepLogger.info("Executing Query-->" + query);
			List<List<String>> userRole = ifr.getDataFromDB(query);
			cm.mRepLogger.info("Output -->" + userRole);
			cm.mRepLogger.info("userRole.get(0).get(0) -->" + userRole.get(0).get(0));
			if (userRole != null && !userRole.isEmpty()) {
				cm.mRepLogger.info("User Role at Initiator Not Null");
				ifr.setValue("Initiator_Role", userRole.get(0).get(0));
				
				if(userRole.get(0).get(0).equalsIgnoreCase("telecaller")){ 
					
					ifr.setStyle("qContactRecording_Contacted", "visible", "true");
					ifr.setStyle("qContactRecording_Contacted", "mandatory", "true");
				}else{ 
					
					ifr.setStyle("qContactRecording_Contacted", "visible", "false");
					ifr.setStyle("qContactRecording_Contacted", "mandatory", "false");
				}
				
			}
			break;
		}

		case "OnChangeActionCode": {

			cm.mRepLogger.info("Inside OnChangeActionCode");
			String fieldsToCLear = cm.actionCodeOnChange(JSdata);
			cm.mRepLogger.info("Returning Old Fields that are to be cleared -->" + fieldsToCLear);
			return fieldsToCLear;
		}

		case "InitiatorFormSubmit": {

			cm.mRepLogger.info("Inside Control ID:InitiatorFormSubmit");
			String nextWorkstep = ifr.getValue("Target_Workstep").toString();
			String wsArray[] = { "Collection_Escalation","Payment_Posting","Legal","Repo_and_Sale",
								 "PTP","Pre_Part_Closure_Request" };
			JSONObject jobj=new JSONObject();
			if(Arrays.asList(wsArray).contains(nextWorkstep)) {
				JSONParser parser=new JSONParser();
				jobj=cm.getNextApprover(nextWorkstep, "");
				cm.mRepLogger.info("final jobj::"+jobj.get("Status")+","+jobj.get("Message"));
			}else{ 
				jobj.put("Status", "true");
			}

			// saving the outward document grid.
//			cm.saveDocData(); // commented this as this is getting called on click of generate button 
							  // as well as on modify of grid.
			
			// validating the doc gen check for intimation letter and recall notice.
			
			if(jobj.get("Status").toString().equalsIgnoreCase("true")){ 
				
				Status s = cm.validateDocGen();
				if (s.isStatus()) {
					// validating the pre-closure initiation.
					Status s1=cm.preClosureCheck();
					if(s1.isStatus()){ 
						return Boolean.toString(s1.isStatus());
					}else{ 
						jobj.put("Status", "false");
						jobj.put("Message", s1.getMsg());
						return jobj.toString();
					}
					
				} else {
					jobj.put("Status", "false");
					jobj.put("Message", s.getMsg());
					return jobj.toString();
				}
			}else{ 
				
				return jobj.toString();
			}
			

		}
		
		case "postDocGenOrUpdate":{ 
			
			// saving the outward document grid.
			cm.saveDocData();
			break;
		}

		case "populateInitiateRepoDetails": {
			cm.mRepLogger.info("Inside populateInitiateRepoDetails");

			cm.mRepLogger.info("Populating Document Grid");
			String query = "select document_name,Generated_Date,Sent_Date,Acknowledge_Date,Return_Date,Return_Status from ng_cmplx_document_gen_Details where Loan_Acct_No = '"
					+ ifr.getValue("Loan_Account_No").toString()
					+ "' AND document_Name IN ('Demand Letter 1 English','Demand Letter 1 Hindi','Demand Letter 1 Kannada','Demand Letter 1 Marathi','Demand Letter 1 Tamil','Demand Letter 2 English','Demand Letter 2 Hindi','Demand Letter 2 Kannada','Demand Letter 2 Marathi','Demand Letter 2 Tamil','Demand Letter 3 English','Demand Letter 3 Hindi','Demand Letter 3 Kannada','Demand Letter 3 Marathi','Demand Letter 3 Tamil','Recall Notice English','Recall Notice Hindi','Recall Notice Kannada','Recall Notice Marathi','Recall Notice Tamil');";
			cm.mRepLogger.info("Executing query-->" + query);
			String columnName = "Document Type,Generated Date,Sent Date,Acknowledge Date,Return Date,Return Status";
			cm.populateListView(columnName, query, "InitiateRepoDocumentGrid", ifr);

			cm.mRepLogger.info("Populating Pending PDD's Grid");
			query = "select docname,overall_pdd_status from RLOS_EXT_PDD with (NOLOCK) where Loan_Account_No = '"
					+ ifr.getValue("Loan_Account_No").toString() + "'";
			columnName = "Type Of PDD,Status";
			cm.populateListView(columnName, query, "InitiateRepoPendingPDDGrid", ifr);

			cm.mRepLogger.info("Populating Vehicle Registration");
			query = "select veh_reg_no from NG_DUMP_ASSET with (NOLOCK) where l_acct_no = '"
					+ ifr.getValue("Loan_Account_No").toString() + "'";
			cm.mRepLogger.info("Executing query-->" + query);
			List<List<String>> opt = ifr.getDataFromDB(query);
			if (opt != null && !opt.isEmpty()) {
				ifr.setValue("qRepoDetails_Vehicle_Registration_No", opt.get(0).get(0));
			}

			cm.mRepLogger.info("Populating Last Payment Date");
			query = "select Top 1 Payment_Date from NG_DUMP_PAYMENT_HISTORY with (NOLOCK) where L_ACCT_NO = '"
					+ ifr.getValue("Loan_Account_No").toString() + "' order by Payment_Date desc";
			cm.mRepLogger.info("Executing query-->" + query);
			opt = ifr.getDataFromDB(query);
			if (opt != null && !opt.isEmpty()) {
				ifr.setValue("qRepoDetails_Last_Payment_Received_Date", opt.get(0).get(0));
			}
			break;
		}

		case "ContactRecSave": {

			cm.mRepLogger.info("Inside Control ID:ContactRecSave");

			break;
		}
		case "generateContactUpdationOTP": {

			cm.mRepLogger.info("Inside Control ID:generateContactUpdationOTP");
			String timeout = cm.generateContactUpdationOTP(JSdata);
			return timeout;
		}

		case "OtpExpireTimeout": {

			cm.mRepLogger.info("Inside Control ID:OtpExpireTimeout");
			cm.OtpExpireTimeout(JSdata);
			break;
		}

		case "verifyContactUpdationOTP": {

			cm.mRepLogger.info("Inside Control ID:verifyContactUpdationOTP");
			String verified = cm.verifyContactUpdationOTP(JSdata,
					ifr.getValue("qContactnumberupdationdetails_otpnumber").toString());
			return verified;
		}

		case "openTabOnClick": {
			return cm.openTabOnclick(JSdata);
		}
		case "SkipTraceFetchBtn": {
			/*String columnNames1 = "Questions,options,Traced,Remarks";
			String inputQuery = "SELECT Questionnaire,'' as Options,'' AS traced,'' AS Remarks FROM NG_LCS_Master_Questions ";
			String controlName1 = "SkipTraceListView";
			cm.populateListView(columnNames1, inputQuery, controlName1, ifr);
			String OptionQuery = "SELECT  Options FROM NG_LCS_Master_Questions WITH (NOLOCK)";
			cm.populateListViewComboTable(OptionQuery, controlName1, ifr, 1);// (1-options)*/
			
			cm.populateQuestionnaire(ControlID);
			String pid=ifr.getValue("pInstanceID").toString();
			JSONArray returnval=cm.updateQuestionnaire(ControlID,pid);
			String ret=(returnval.size()>0) ? returnval.toString() : "";
			return ret;
			
		}
		case "PARVisitFetchBtn":{
			/*String columnNames2 = "Questions,Options,Remarks";
			String inputQuery = "SELECT Questionnaire,'' as Options,'' AS Remarks FROM NG_LCS_Master_Questions WITH (NOLOCK) WHERE Stage='QCO-Skip Customer' OR Stage = 'QCO-Skip Vehicle' OR Stage = 'QCO-PAR'";
			String controlName2 = "PARVisitListView";
			cm.populateListView(columnNames2, inputQuery, controlName2, ifr);
			String OptionQuery = "SELECT  Options FROM NG_LCS_Master_Questions WITH (NOLOCK) WHERE Stage='QCO-Skip Customer' OR Stage = 'QCO-Skip Vehicle' OR Stage = 'QCO-PAR'";
			cm.populateListViewComboTable(OptionQuery, controlName2, ifr, 1);*/
			cm.populatePar_Check_Questionnaire(ControlID);
			String pid=ifr.getValue("pInstanceID").toString();
			JSONArray returnval=cm.update_PAR_Check_Questionnaire(ControlID,pid);
			String ret=(returnval.size()>0) ? returnval.toString() : "";
			return ret;
		}
		case "Applicanttypewithname-Inward": {
			String processInstanceId = ifr.getObjGeneralData().getM_strProcessInstanceId();

			String OptionQuery = "SELECT concat(Applicant_Type,'-',customer_full_name) "
					+ "AS Applicant_Type ,Customer_ID  FROM CMPLX_COLL_CI_CustomerInformation_Details_Grid with(nolock) where TransactionId='"
					+ processInstanceId + "'";
			cm.mRepLogger.info("OptionsQuery is " + OptionQuery);

			String controlName = "InwardDocumentGrid_ApplicantTypewithName";
			//ifr.clearCombo("InwardDocumentGrid_ApplicantTypewithName");
			cm.populateListViewCombo(OptionQuery, controlName, ifr);
			break;
		}
		case "InwardDocumentGrid_ApplicantTypewithName": {
			String processInstanceId = ifr.getObjGeneralData().getM_strProcessInstanceId();
			cm.mRepLogger.info("PROCESS INSTANCE ID IS  ----->" + processInstanceId);
			String Query = "SELECT concat(Applicant_Type,'-',customer_full_name) "
					+ "AS Applicant_Type  FROM CMPLX_COLL_CI_CustomerInformation_Details_Grid with(nolock) where TransactionId='"
					+ processInstanceId + "' AND Customer_ID='"
					+ ifr.getValue("InwardDocumentGrid_ApplicantTypewithName") + "'";
			cm.mRepLogger.info("Query " + Query);
			List<List<String>> OptionsArray = ifr.getDataFromDB(Query);
			cm.mRepLogger.info("OptionsArray " + OptionsArray);
			int arraySize = OptionsArray.size();
			if (arraySize > 0) {
				ifr.setValue("InwardDocumentGrid_hiddenApplicantTypewithName", OptionsArray.get(0).get(0));

			}
			break;
		}

		case "OnchangePTPdays": {

			return cm.OnchangePTPdays(JSdata);

		}
		case "OnchangeFPTPdays": {

			return cm.OnchangeFPTPdays(JSdata);
		}
		case "OnchangePickupdays": {
			
			return cm.OnchangePickupdays(JSdata);
		}

		case "DocumentGeneration": {
			if (EventType.equalsIgnoreCase("FormLoad")) {
				return cm.onformLoadHandler_OutDocument_CAGL(ifr, ControlID, EventType, JSdata, ifr.getActivityName());
				
			} else {
				// Generate Document - By Vaibhav
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
						+ doctype + "'";
				cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
				try {

					Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
					JSONObject jRet=new JSONObject();
					cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
					jRet.put("Status", Boolean.toString(docStatus.isStatus()));
					jRet.put("Msg", docStatus.getMsg());
					jRet.put("SubMsg", docStatus.getSubMsg());
					jRet.put("DocName", doctype);
					
					// saving the outward document grid.
					cm.saveDocData();
					
					return jRet.toString();

				} catch (Exception e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					cm.mErrLogger.info("Error in executeserverevent-->" + e.getMessage());
				}
				break;

			}
		}
		case "getAddressforPickupMeeting": {

			return cm.getAddrForPickupMeeting(ifr, JSdata);

		}
		case "apportionmentFetch": {

			cm.fetchApportionmentData(JSdata);
			break;
		}
		case "Document_ID_CHECK": {

			return cm.getDocumentId(JSdata, ifr);
		}
		case "repaymentScheduleFetch": {
			return cm.fetchRepaySchedule();
		}
		case "preClosureFetch": {
			return cm.fetchPreClosure();
		}

		case "Inward_Doc_ID": {
			return cm.getDocumentId(JSdata, ifr);
		}

		case "docGenValidation": {

			Status s = cm.validateDocGen();
			cm.mRepLogger.info(s.getMsg()+",");cm.mRepLogger.info(s.getSubMsg()+",");cm.mRepLogger.info(s.isStatus()+",");cm.mRepLogger.info(s.isSubStatus());
			if (s.isStatus()) {
				return Boolean.toString(s.isStatus());
			} else {
				return s.getMsg();
			}

		}
		
		case "getTabIdToValidate": {
			
			return cm.getTabIdToValidate(JSdata);


		}
		
		case "DisableTabOnLoad": {
			
			cm.disableTabsOnLoad();//disable tabs onload
			
			//loading the customer tab on load for the documents to work for the parent WI's
			String parentFlg=ifr.getValue("isParent").toString();
			if(parentFlg!=null && parentFlg.trim().equalsIgnoreCase("yes")){ 
				cm.populateDumpData("fetchBtnCustomerInformation", ifr.getValue("Loan_Account_No").toString(), ifr);
			}
			
			break;

		}
		
		case "ActionHistoryData":{
				cm.actionAndDecisionHistoryUpdation("ActionHistory",JSdata);
				break;
		}
		
		case "DecisionHistoryData":{
			cm.actionAndDecisionHistoryUpdation("DecisionHistory",JSdata);
			break;
		}
		
		case "GenerateRepaymentSchedule":{
			if(cs==null){ 
				cs = new CollectionCommonServices(ifr);
			}
			JSONObject jRet=new JSONObject();
			
			try {

				String st=cs.GenerateRepaymentSchedule(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);
				
				if(st!=null && st.equalsIgnoreCase("SUCCESS")){ 
					
					String doctype = EventType;
					String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
							+ doctype + "'";
					List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
					Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
					
					cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
					jRet.put("Status", Boolean.toString(docStatus.isStatus()));
					jRet.put("Msg", docStatus.getMsg());
					jRet.put("SubMsg", docStatus.getSubMsg());
					jRet.put("DocName", doctype);
					
				}else if(st!=null && st.startsWith("FAILED")){ 
					
					jRet.put("Status", Boolean.toString(false));
					jRet.put("Msg", st.split("~~")[1]);
					jRet.put("SubMsg", "NA");
					jRet.put("DocName", "Loan Repayment Schedule");
					
				}
				
				// saving the outward document grid.
				cm.saveDocData();
				
			} catch (Exception e) {
				cm.mErrLogger.info("Error in generating the Loan Repayment Schedule execute server event-->",e);
				jRet.put("Status", Boolean.toString(false));
				jRet.put("Msg", "Issue in generating the Document :");
				jRet.put("SubMsg", "NA");
				jRet.put("DocName", "Loan Repayment Schedule");
			}
			
			return jRet.toString();

		}
		
		case "GenerateSOA":{ 
			cm.mRepLogger.info("<<<<<<<<<<<GENERATING SOA>>>>>>>>>>>");
			if(cs==null){ 
				cs = new CollectionCommonServices(ifr);
			}
			JSONObject jRet=new JSONObject();
			
			try {

				String st=cs.GenerateSOA(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);

				if(st!=null && st.equalsIgnoreCase("SUCCESS")){ 
					
					String doctype = EventType;
					String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
							+ doctype + "'";
					List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
					Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
					
					cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
					jRet.put("Status", Boolean.toString(docStatus.isStatus()));
					jRet.put("Msg", docStatus.getMsg());
					jRet.put("SubMsg", docStatus.getSubMsg());
					jRet.put("DocName", doctype);
					
				}else if(st!=null && st.startsWith("FAILED")){ 
					
					jRet.put("Status", Boolean.toString(false));
					jRet.put("Msg", st.split("~~")[1]);
					jRet.put("SubMsg", "NA");
					jRet.put("DocName", "SOA");
					
				}
				
				// saving the outward document grid.
				cm.saveDocData();
				
			} catch (Exception e) {
				cm.mErrLogger.info("Error in generating the SOA execute server event-->",e);
				jRet.put("Status", Boolean.toString(false));
				jRet.put("Msg", "Issue in generating the Document :");
				jRet.put("SubMsg", "NA");
				jRet.put("DocName", "SOA");
			}
			
			return jRet.toString();
			
//			return cs.GenerateSOA(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);
			
			//below code to be removed and above return statement to be uncommented.
			/*String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='SOA'";
			cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
			List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
			cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
			try {
				cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		}
		
		case "ManualReceiptValidation" :{
			return cm.ManualreceiptValidation(JSdata);
			
		}
		
		case "Referal":{
			return cm.AddReferalToTempAllocation();
		}
		
		case "getMandatoryInwardDocsToValidate":{ 
			
			return cm.getMandatoryInwardDocsToValidate(JSdata);
		}
		
		case "setInwardDocumentCategory":{ 
			
			return cm.setInwardDocumentCategory(JSdata);
		}
		
		case "fetchFinalResaleAmt":{ 
			Status s=cm.saleSettlementShortfallCheck();
			if(s.isStatus()){ 
				return Boolean.toString(s.isStatus());
			}else{ 
				return s.getMsg();
			}
			
		}
		
		case "repoCheck":{ 
			Status s=cm.repoCheck();
			if(s.isStatus()){ 
				return Boolean.toString(s.isStatus());
			}else{ 
				return s.getMsg();
			}
		}
		
		case "getLegalAndRepoFlags":{ 
			cm.setRoleOfUser();
			return cm.getLegalAndRepoFlags();
		}
		
		case "onClickSendRequest":{
		     cm.mRepLogger.info("Inside onClickSendRequest");
				try {
					return cm.onClickSendRequest(ifr,cm);
				} catch (Exception e) {
					 cm.mErrLogger.info("Exception ::"+e.getMessage());
					 System.out.println("Exception ::"+e.getMessage());
					e.printStackTrace();
				}
		  }
		
		  case "onClickCheckStatus":{
		     cm.mRepLogger.info("Inside onClickCheckStatus");
				try {
					return cm.checkUPIPayment(ifr,cm);
				} catch (Exception e) {
					 cm.mErrLogger.info("Exception ::"+e.getMessage());
					 System.out.println("Exception ::"+e.getMessage());
					 e.printStackTrace();
				}
		  }
		  
		  case "calculateRequestTime":{
			  cm.mRepLogger.info("Inside calculateRequestTime");
			  String timelimitquery="Select DISTINCT TIMER from dbo.NEMF_UPI_TIMER WITH (NOLOCK) where SERVICE = 'singleCollect' ";//, [UPITimerArray,'singleCollect']);
			  List<List<String>> timelimitresp = ifr.getDataFromDB(timelimitquery);
			  cm.mRepLogger.info("After query execution timelimit in minutes::"+timelimitresp.get(0).get(0));
			  String timelimit=timelimitresp.get(0).get(0);
			  cm.mRepLogger.info("Inside calculateRequestTime timelimit in minutes::"+timelimit);
			  int timeexpire=Integer.parseInt(timelimit);
			  timeexpire =(timeexpire*60)*1000;
			  timelimit= Integer.toString(timeexpire);
			  cm.mRepLogger.info("Inside calculateRequestTime timelimit in milli seconds::"+timeexpire);
			  return timelimit;
		  }
		  case "merchantVPA":{
			  cm.mRepLogger.info("Inside merchantVPA");
			  String merchantvpa="";
			  String upitype=ifr.getValue("qUpiPaymentDet_PaymentType").toString();
			  cm.mRepLogger.info("Inside merchantVPA UPI Type:"+upitype);
			  if(upitype.equalsIgnoreCase("Push to VPA")){
				  cm.mRepLogger.info("Inside merchantVPA call for "+upitype);
				  String push2vpaquery="Select DISTINCT MerchantVPA from dbo.NG_MASTER_UPI_PARAMS WITH (NOLOCK) where UPITYPE='QR'";
				  List<List<String>> push2vparesp = ifr.getDataFromDB(push2vpaquery);
				  cm.mRepLogger.info("After query execution merchant vpa::"+push2vparesp.get(0).get(0));
				  merchantvpa=push2vparesp.get(0).get(0);
				  cm.mRepLogger.info("Final log in merchantVPA - Merchant VPA::"+merchantvpa);
			  }
			  else if(upitype.equalsIgnoreCase("Dynamic VPA")){
				  cm.mRepLogger.info("Inside merchantVPA call for "+upitype);
				  String dynamicpaquery="Select DISTINCT StaticMerchantVPA1,StaticMerchantVPA2 from dbo.NG_MASTER_UPI_PARAMS WITH (NOLOCK) where UPITYPE='Dynamic VPA'";
				  List<List<String>> dynamicvparesp = ifr.getDataFromDB(dynamicpaquery);
				  cm.mRepLogger.info("After query execution merchant vpa::"+dynamicvparesp);
				  cm.mRepLogger.info("Static Part Of Merchant VPA-- Part1::"+dynamicvparesp.get(0).get(0)+"  Part2::"+dynamicvparesp.get(0).get(1));
				  merchantvpa=dynamicvparesp.get(0).get(0)+","+dynamicvparesp.get(0).get(1);
				  cm.mRepLogger.info("Final log in merchantVPA - Merchant VPA::"+merchantvpa);
			  }
			  return merchantvpa;
		  }
		  
		}

		return "true";
	}

	@Override
	public String getCustomFilterXML(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String setMaskedValue(String arg0, String arg1) {
		// TODO Auto-generated method stub
		return arg1;
	}

	@Override
	public JSONArray validateSubmittedForm(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}
}