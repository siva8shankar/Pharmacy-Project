package com.newgen.iforms.user.collection;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.opc.OPCPackage;
//import org.apache.poi.xwpf.converter.pdf.PdfConverter;
//import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import fr.opensagres.poi.xwpf.converter.pdf.PdfOptions;
import fr.opensagres.poi.xwpf.converter.pdf.PdfConverter;

import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.newgen.aproj2.template.BusinessDataVO;
import com.newgen.aproj2.template.BusinessValidation;
import com.newgen.aproj2.template.ReadXmlData;
//import com.newgen.iform.user.readproperty.InitConfigPropChildWork;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.user.collection.services.CollectionCommonServices;
import com.newgen.iforms.user.collection.services.Status;
import com.newgen.iforms.user.collection.CommonWebserviceCalls;
import com.newgen.iforms.user.collection.HTTPRequestResponse;
//import com.newgen.mcap.core.external.configuration.entities.concrete.Configuration;
//import com.newgen.mcap.core.external.logging.concrete.LogMe;
import com.newgen.iforms.user.collection.ReadProperty;
import com.newgen.niplj.generic.NGIMException;
import com.newgen.omni.wf.util.xml.XMLParser;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;
import com.newgen.wfdesktop.xmlapi.WFXmlResponse;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;

import java.util.Properties;
import java.util.StringTokenizer;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.stream.Collectors;

import org.apache.log4j.*;

//import static com.newgen.custom.log.CustomLogger.CustomInfoLogger;
//import static com.newgen.custom.log.CustomLogger.CustomInfoLogger;
import static custom.CallBroker.*;

/********************************************************************
 * NEWGEN SOFTWARE TECHNOLOGIES LIMITED Group : CIG Product / Project : CAGL_LCS
 * Module : <IFormUser> File Name : <File Name> Author : <Sidhant Mittal> Date
 * written : 08/07/2020 (DD/MM/YYYY) Description : <Description> CHANGE HISTORY
 ***********************************************************************************************
 * Date Change By Change Description (Bug No. (If Any)) (DD/MM/YYYY)
 ************************************************************************************************/

public class CollectionCommonMethod {
//   private static Configuration configuration;
//	
//	public CollectionCommonMethod(Configuration config)
//	{
//		this.configuration = config;
//	}
	public static final int XML_LOG = 1;
	public static final int SUCCESS_LOG = 2;
	public static final int ERROR_LOG = 3;
	// Used as return values for various calls
	public static final boolean SUCCESS = true;
	public static final boolean FAILURE = false;
	// Used as return values for various calls
	public static final String SUCCESS_STR = "SUCCESS";
	public static final String FAILURE_STR = "FAILURE";
	// The filename for the log types
	public static final String XML_LOG_NAME = "Xml.log";
	public static final String SUCCESS_LOG_NAME = "Success.log";
	public static final String ERROR_LOG_NAME = "Error.log";
	// To check if log file generation is required
	public static final String LOG_FILE_REQUIRED = "Y";
	public static final String LOG_FILE_NOT_REQUIRED = "N";
	public static final String FILE_SAPARATOR = File.separator;

	private Properties actionCodeProperties = null;
	private Properties serviceProperties = null;
	private Properties FetchDumpDataProperties = null;
	private Properties commonProperties = null;
	private static Properties staticcommonProperties=null;
	private IFormReference ifr = null;
	private static String dateColumns = "";
	private static String gridAmountColumns = "";
	static String fieldAmountColumns = "";
	static String mstrlog4jConfigFilePath = "";
	static Map currentServiceProperty = new HashMap();
	private String pID = "";
	Hashtable<String, String> ht = new Hashtable<String, String>();
	public static final org.apache.log4j.Logger mLogger = org.apache.log4j.Logger.getLogger("mLogger");
	public static final org.apache.log4j.Logger mRepLogger = org.apache.log4j.Logger.getLogger("Reportlog");
	public static final org.apache.log4j.Logger mErrLogger = org.apache.log4j.Logger.getLogger("Errorlog");
	public static ReadProperty propertyReader;

	public CollectionCommonMethod(IFormReference ifr) {
		this.ifr = ifr;
		// mRepLogger.info("Inside CommonMethods!");
		initlog();
		mRepLogger.info("Inside CommonMethods!");

		// logger = new CustomLogger();
		
	}
	 /*
	   *Method Name       :    getJSONArrayFromList
	   *Input Parameters  :    (Db data in List of List of String datatype, Column names of Grid,Name of Grid).
	   *Return Values     :    JSONArray
	  * Author            :    Aseesh
	   *Description       :    This method frames a JSON Array from the db values and column names provided as Input.
	   */

	public static JSONArray getJSONArrayFromList(List<List<String>> dbList, String columnNames, String controlID) {

		String dateArray[] = (dateColumns == null || dateColumns.equals("")) ? new String[0] : dateColumns.split(",");
		String amountArray[] = (gridAmountColumns == null || gridAmountColumns.equals("")) ? new String[0]
				: gridAmountColumns.split(",");
		// String columnSplit[] = columnNames.split(",");
		JSONObject formDetailsJson = null;
		JSONArray jsonArray = new JSONArray();
		List<String> columns = Arrays.asList(columnNames.split("\\s*,\\s*"));
		int counter = 1; // Counter for A01,C01,C02,G01 logic
		for (int i = 0; i < dbList.size(); i++) {
			formDetailsJson = new JSONObject();
			for (int j = 0; j < columns.size(); j++) {

				// parsing the date or date time to desired format before pushing to grids.
				String val = dbList.get(i).get(j);
				if (ArrayUtils.contains(dateArray, columns.get(j) + "(D)")) {

					if (val != null && !val.equals("")) {
						Date date1 = parseDate(val,false);
						if(date1!=null)
						val = new SimpleDateFormat("dd/MM/yyyy").format(date1);	
					}

				} else if (ArrayUtils.contains(dateArray, columns.get(j) + "(DT)")) {

					if (val != null && !val.equals("")) {
						Date date1 = parseDate(val,true);
						if(date1!=null)
						val = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(date1);
					}

				} else if (ArrayUtils.contains(amountArray, columns.get(j))) {

					if (val != null && !val.equals("") && !val.contains(".")) {
						val = val + ".00";

					}

				}

				formDetailsJson.put(columns.get(j), val);

				if (controlID.equalsIgnoreCase("CustomerInformationGrid")
						&& columns.get(j).equalsIgnoreCase("Applicant Type")) {
					mRepLogger.info("Demographic Details Uniquie Id Case ->" + val);
					if (val != null && val.equalsIgnoreCase("Applicant")) {
						formDetailsJson.put("uniqueID", "A01");
					} else if (val != null && val.equalsIgnoreCase("Guarantor")) {
						formDetailsJson.put("uniqueID", "G01");
					} else if (val != null && val.equalsIgnoreCase("Co-Applicant")) {
						formDetailsJson.put("uniqueID", ("C0" + counter));
						counter++;
					}
				}

			}
			jsonArray.add(formDetailsJson);
		}
		 mRepLogger.info("CollectionCommonMethod getJSONArrayFromList jsonArray final" + jsonArray);
		return jsonArray;

	}
	 /*
	   *Method Name       :    PopulateTargetWsOnFormSubmitForDecisionAction
	   *Input Parameters  :    (Name of Current Workstep and Iform Reference object).
	   *Return Values     :    TargetWorkstep - String
	  * Author            :    Aseesh
	   *Description       :    Returns name of Target Workstep on form submit which is fetched from Master table based on Current Workstep and Decision selected
	   */

	public String PopulateTargetWsOnFormSubmitForDecisionAction(String currentWS, IFormReference ifr) {
		mRepLogger.info("<--Inside PopulateTargetWsOnFormSubmitForDecisionAction-->");
		String DecisionAction = ifr.getValue("DecisionAction").toString();
		String query = "select distinct targetWS from ng_master_decisions with (NOLOCK) where workstep = '" + currentWS
				+ "' and decision = '" + DecisionAction + "'";
		mRepLogger.info("Executing query -->" + query);
		List<List<String>> targetWS = ifr.getDataFromDB(query);
		mRepLogger.info("Query Output -->" + targetWS);
		if (targetWS != null && !targetWS.isEmpty()) {
			mRepLogger.info("Output in format targetWS.get(0).get(0)-->" + targetWS.get(0).get(0));
			return targetWS.get(0).get(0);
		} else {
			return "";
		}

	}
	/*
	   *Method Name       :    populateListViewComboTable
	   *Input Parameters  :    (Query for Combo values,Grid control Id,Iform Reference Object ,Grid Column number).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods fetches combo values from DB and adds item in table cell combo.
	   */

	public void populateListViewComboTable(String OptionQuery, String controlName, IFormReference ifr, int columnNumber) {
		mRepLogger.info("CollectionCommonMethod populateComboListView columnNumber:::::" + columnNumber);
		mRepLogger.info("CollectionCommonMethod populateComboListView OptionQuery:::::" + OptionQuery);
		mRepLogger.info("CollectionCommonMethod populateComboListView controlName:::::" + controlName);
		mRepLogger.info("CollectionCommonMethod populateComboListView ifr:::::" + ifr);

		// ifr.addItemInTableCellCombo(controlName, rowVal, colName,viewText, exactVal);

		List<List<String>> OptionsArray = ifr.getDataFromDB(OptionQuery);
		int arraySize = OptionsArray.size();
		int k = 0;
		for (k = 0; k < arraySize; k++) {
			String optionVal[] = OptionsArray.get(k).get(0).trim().split(",");
			int i = 0;
			for (i = 0; i < optionVal.length; i++) {
				ifr.addItemInTableCellCombo(controlName, k, columnNumber, optionVal[i], optionVal[i]);

			}

		}

	}
	/*
	   *Method Name       :    populateListViewCombo
	   *Input Parameters  :    (Query for Combo values,Combo control Id,Iform Reference Object).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods fetches combo values from DB and adds item in combo using label with its value and tooltip.
	   */
	public void populateListViewCombo(String OptionQuery, String controlName, IFormReference ifr) {
		mRepLogger.info("CollectionCommonMethod populateComboListView OptionQuery:::::" + OptionQuery);
		mRepLogger.info("CollectionCommonMethod populateComboListView controlName:::::" + controlName);
		mRepLogger.info("CollectionCommonMethod populateComboListView ifr:::::" + ifr);
		String exactVal="";
		String viewText="";
		
		// ifr.addItemInTableCellCombo(controlName, rowVal, colName,viewText, exactVal);
try {
		List<List<String>> OptionsArray = ifr.getDataFromDB(OptionQuery);
		mRepLogger.info("OptionsArray "+OptionsArray);
		int arraySize = OptionsArray.size();
		int k = 0;
		for (k = 0; k < arraySize; k++) {
			 exactVal = OptionsArray.get(k).get(0).trim();
             viewText = OptionsArray.get(k).get(1).trim();
			
				ifr.addItemInCombo(controlName, exactVal ,viewText );
				mRepLogger.info("Addding " + viewText +" / "+exactVal +" to "+controlName);
		}}
				catch (Exception e) {
					
					mRepLogger.info("Exception in populate list view +> "+e.getMessage());
				}
		}

	/*
	   *Method Name       :    populateListView
	   *Input Parameters  :    (Grid Column Names,Query to get Values from DB,Iform Reference Object).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods fetches Listview Data from DB and adds it to Listview/Table .
	   */

	public void populateListView(String columnNames, String inputQuery, String controlName, IFormReference ifr) {
		mRepLogger.info("CollectionCommonMethod populateListView columnNames:::::" + columnNames);
		mRepLogger.info("CollectionCommonMethod populateListView inputQuery:::::" + inputQuery);
		mRepLogger.info("CollectionCommonMethod populateListView controlName:::::" + controlName);
		mRepLogger.info("CollectionCommonMethod populateListView ifr:::::" + ifr);

		List<List<String>> queryList = ifr.getDataFromDB(inputQuery);
		mRepLogger.info("Query Output -->" + queryList);
		mRepLogger.info("CollectionCommonMethod populateListView queryList " + queryList);
		ifr.clearTable(controlName);

		ifr.addDataToGrid(controlName, getJSONArrayFromList(queryList, columnNames, controlName));

	}
	
	/*
	   *Method Name       :    populateListViewDocument
	   *Input Parameters  :    (Grid Column Names,Query to get Values from DB,Iform Reference Object).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods fetches Listview Data from DB and adds it to Listview/Table (same as populateListView, but the input parameters change to avoid executing execution of query multiple times).
	   */

	public void populateListViewDocument(String columnNames, List<List<String>> queryList, String controlName, IFormReference ifr) {
		mRepLogger.info("CollectionCommonMethod populateListView columnNames:::::" + columnNames);
//		mRepLogger.info("CollectionCommonMethod populateListView inputQuery:::::" + inputQuery);
		mRepLogger.info("CollectionCommonMethod populateListView controlName:::::" + controlName);
		mRepLogger.info("CollectionCommonMethod populateListView ifr:::::" + ifr);

//		List<List<String>> queryList = ifr.getDataFromDB(inputQuery);
		mRepLogger.info("Query Output -->" + queryList);
		mRepLogger.info("CollectionCommonMethod populateListView queryList " + queryList);
		ifr.clearTable(controlName);

		ifr.addDataToGrid(controlName, getJSONArrayFromList(queryList, columnNames, controlName));

	}
	
	/*
	   *Method Name       :    populateFields
	   *Input Parameters  :    (Fieldnames to which data has to be populated,Iform Reference Object).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods fetches Data from DB and populates against specified field names .
	   */

	public void populateFields(String fieldNames, String query, IFormReference ifr) {
		mRepLogger.info("CollectionCommonMethod populateFields fieldNames:::::" + fieldNames);
		mRepLogger.info("CollectionCommonMethod populateFields ifr:::::" + ifr);

		String dateArray[] = (dateColumns == null || dateColumns.equals("")) ? new String[0] : dateColumns.split(",");
		String amountArray[] = (fieldAmountColumns == null || fieldAmountColumns.equals("")) ? new String[0]
				: fieldAmountColumns.split(",");

		String[] fields = fieldNames.split(",");
		List<List<String>> queryList = ifr.getDataFromDB(query);
		mRepLogger.info("Query Output -->" + queryList);
		if (queryList.size() > 0) {
			for (int i = 0; i < fields.length; i++) {
				mRepLogger.info(fields[i] + ":" + queryList.get(0).get(i));
				if (queryList.get(0).get(i).isEmpty() || queryList.get(0).get(i) == null
						|| queryList.get(0).get(i).equals(" ")) {
					ifr.setValue(fields[i], "");
				} else {

					String val = queryList.get(0).get(i).trim();
					// parsing the date & datetime fields to desired format
					if (ArrayUtils.contains(dateArray, fields[i] + "(D)")) {

						if (val != null && !val.equals("")) {
							Date date1 = parseDate(val,false);
							if(date1!=null)
							val = new SimpleDateFormat("dd/MM/yyyy").format(date1);
						}
					} else if (ArrayUtils.contains(dateArray, fields[i] + "(DT)")) {

						if (val != null && !val.equals("")) {
							Date date1 = parseDate(val,true);
							if(date1!=null)
							val = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(date1);
						}
					} else if (ArrayUtils.contains(amountArray, fields[i])) {

						if (val != null && !val.equals("") && !val.contains(".")) {
							val = val + ".00";

						}

					}
					// Uncomment once resolved
					// if (fieldAmountColumns != null && !fieldAmountColumns.equalsIgnoreCase("")) {
					// if (fieldAmountColumns.contains(fields[i])) {
					// mRepLogger.info("Match Fount for -->" + fields[i]);
					// if (val != null && !val.equals("")) {
					// mRepLogger.info("Val-->" + val);
					// if (!val.contains(".")) {
					// val = val + ".00";
					// mRepLogger.info("New Value-->" + val);
					// }
					// }
					// }
					// }
					
					if(fields[i].equalsIgnoreCase("qRepoExpenses_Repo_Agency_Charges")){ 
						if(ifr.getValue(fields[i])==null || ifr.getValue(fields[i]).toString().trim().equals(""))
						ifr.setValue(fields[i], val);
					}else if(fields[i].equalsIgnoreCase("qRepoExpenses_StockYardCharges")){ 
						if(ifr.getValue(fields[i])==null || ifr.getValue(fields[i]).toString().trim().equals(""))
						ifr.setValue(fields[i], val);
					}else{ 
						ifr.setValue(fields[i], val);
					} 
					
					
				}
			}
		}

		mRepLogger.info("CollectionCommonMethod populateFields complete");
	}
	/*
	   *Method Name       :    getFetchDumpDataProperties()
	   *Input Parameters  :    NA.
	   *Return Values     :    Properties
	  * Author            :    Aseesh
	   *Description       :    This methods loads the FetchDumpData.properties file.
	   */

	public Properties getFetchDumpDataProperties() {

		if (FetchDumpDataProperties == null) {

			FileInputStream fis = null;

			try {
				String path = System.getProperty("jboss.home.dir") + File.separator + "bin" + File.separator
						+ "customProperties" + File.separator + "FetchDumpData.properties";
				fis = new FileInputStream(path);
				FetchDumpDataProperties = new Properties();
				FetchDumpDataProperties.load(fis);
			} catch (Exception e) {
				mErrLogger.info("Exception " + e.getMessage());
				// e.printStackTrace();
			} finally {
				try {
					if (fis != null)
						fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
				}
			}
		}

		return FetchDumpDataProperties;

	}
	/*
	   *Method Name       :    populateDumpData
	   *Input Parameters  :    (Grid Control Id,Loan Account Number,Iform Reference Object).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods populates data from Dump tables into Grids.Grid Query, Column names are read from the fetch dump data properties file.
	   */

	public void populateDumpData(String controlID, String loanAccountNumber, IFormReference ifr) {
		mRepLogger.info("Inside populateDumpData");
		String FromDate="";
		String ToDate="";
		String pid = ifr.getValue("pInstanceID").toString();
		if (controlID != null && !controlID.equals("")) {
			
			Properties p = getFetchDumpDataProperties();
			String ids[] = controlID.split(",");

			for (int i = 0; i < ids.length; i++) {
				
				//deleting the actionhistory in actionhistory table before saving the form (to avoid the repetition of data).
				//commenting the below code as there is no option of records getting duplicated as the form mapping to grid was removed and save is customised.
				/*if(ids[i].equalsIgnoreCase("deleteActionHistory")){ 
					String loanNo = ifr.getValue("Loan_Account_No").toString();
					String docDelQuery="Delete from ng_cmplx_actionhistory where GridTransactionID in "
							+ "(select pinstanceid from EXT_Collection WITH(NOLOCK) where Loan_Account_No = "
							+ "'"+loanNo+"')";
					ifr.getDataFromDB(docDelQuery);
				}
				
				else */
				
				if (ids[i].equalsIgnoreCase("fetchBtnAssetDetails")) {
					hideShowPropertyAssetDetails(loanAccountNumber);
				}

				if (p.getProperty("C_" + ids[i]) != null && !p.getProperty("C_" + ids[i]).isEmpty()) {
					mRepLogger.info("Current id-->" + ids[i]);
//					mRepLogger.info("Populating Grid");
					String columnNames = p.getProperty("C_" + ids[i]);
					dateColumns = p.getProperty("DT_" + ids[i]);
//					mRepLogger.info("dateColumns-->" + dateColumns);
					gridAmountColumns = p.getProperty("AMT_" + ids[i]);
//					mRepLogger.info("gridAmountColumns-->" + gridAmountColumns);
					String query = p.getProperty("Q_" + ids[i]);
//					mRepLogger.info("Query fetched from property file-->" + query);
					//Code added for Action History Date Filter
					if(ids[i].equalsIgnoreCase("fetchBtnActionHistory")) {
//						mRepLogger.info("Control Inside ActionHistory date Filter");
//						SimpleDateFormat formatter=new SimpleDateFormat("MM/dd/yyyy");
//						SimpleDateFormat formatter1=new SimpleDateFormat("dd/MM/yyyy");
						 FromDate=ifr.getValue("Action_History_From_Date").toString();
						 ToDate=ifr.getValue("Action_History_To_Date").toString();
						if(FromDate!=null && !FromDate.isEmpty() && ToDate!=null && !ToDate.isEmpty())
						{
							/*try {
								FromDate=formatter.format(formatter1.parse(FromDate));
								ToDate=formatter.format(formatter1.parse(ToDate));
							} catch (ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}*/
							
							try{ 
								Date actFrmDt = parseDate(FromDate,false);
								Date actToDt = parseDate(ToDate,false);
								String valFrm = new SimpleDateFormat("yyyy-MM-dd").format(actFrmDt);		
								String valTo = new SimpleDateFormat("yyyy-MM-dd").format(actToDt);
								query=query.replace("##FROM_DATE_REPLACEMENT##",valFrm).replace("##TO_DATE_REPLACEMENT##",valTo);
							}catch(Exception e){ 
								mErrLogger.info("Error in parsing the from dt and to dt to fetch actionhistory : "+e.getMessage());
							}
							query = query.replace("##LOAN_ACCOUNT_NUMBER_REPLACEMENT##", loanAccountNumber);
						    mRepLogger.info("Executing query -->" + query);
							
						}
						else {
							mRepLogger.info("Invalid Date : "+FromDate+ " "+ToDate);
						}
					}
					else if(ids[i].equalsIgnoreCase("fetchDecisionHistory")) { 
						query = query.replace("##PID##", pid);
						mRepLogger.info("Executing query -->" + query);
						
					}
					else {
					query = query.replace("##LOAN_ACCOUNT_NUMBER_REPLACEMENT##", loanAccountNumber);
					mRepLogger.info("Executing query -->" + query);
					}
					String gridID = p.getProperty("G_" + ids[i]);
					mRepLogger.info("Populating in grid -->" + gridID);
					populateListView(columnNames, query, gridID, ifr);
					
				}

				if (p.getProperty("F_" + ids[i]) != null && !p.getProperty("F_" + ids[i]).isEmpty()
						&& p.getProperty("QF_" + ids[i]) != null && !p.getProperty("QF_" + ids[i]).isEmpty()) {
//					mRepLogger.info("Populating Fields");
					String fields = p.getProperty("F_" + ids[i]);
					dateColumns = p.getProperty("DT_" + ids[i]);
					fieldAmountColumns = p.getProperty("AMT_F_" + ids[i]);
//					mRepLogger.info("fieldAmountColumns-->" + fieldAmountColumns);
					String query = p.getProperty("QF_" + ids[i]);
//					mRepLogger.info("Query fetched from property file-->" + query);
					query = query.replace("##LOAN_ACCOUNT_NUMBER_REPLACEMENT##", loanAccountNumber);
//					mRepLogger.info("Executing query -->" + query);
//					mRepLogger.info("Populating in fields -->" + fields);
					populateFields(fields, query, ifr);
				}
			}

		}

	}
	/*
	   *Method Name       :    hideShowPropertyAssetDetails
	   *Input Parameters  :    (Loan Account Number).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods Hides/Shows- Property and Asset Details Grids based on loan Numbers.
	   */
	
	public void hideShowPropertyAssetDetails(String loanAccountNumber) {
		mRepLogger.info("Inside hideShowPropertyAssetDetails");
		String query = "select Product FROM NG_DUMP_LOAN_DET WITH (NOLOCK) WHERE L_ACCT_NO='"
				+ loanAccountNumber + "'";
		mRepLogger.info("Executing query -->" + query);
		List<List<String>> opt = ifr.getDataFromDB(query);
		mRepLogger.info("Query Output-->" + opt);
		if (opt != null && !opt.isEmpty()) {
			
			if (opt.get(0).get(0).equalsIgnoreCase("Grameen Savaari Loan") || 
					opt.get(0).get(0).equalsIgnoreCase("Grameen Vaahan Loan")) {
				ifr.setStyle("AssetDetailsLabel", "visible", "true");
				ifr.setStyle("AssetDetailsGrid", "visible", "true");
				ifr.setStyle("PropertyDetailsLabel", "visible", "false");
				ifr.setStyle("PropertyDetailsGrid", "visible", "false");
			} else if(opt.get(0).get(0).equalsIgnoreCase("Grameen Gruha Vikas Loan") || 
					opt.get(0).get(0).equalsIgnoreCase("Grameen Vikas Loan")){
				ifr.setStyle("AssetDetailsLabel", "visible", "false");
				ifr.setStyle("AssetDetailsGrid", "visible", "false");
				ifr.setStyle("PropertyDetailsLabel", "visible", "true");
				ifr.setStyle("PropertyDetailsGrid", "visible", "true");
			} else{ 
				ifr.setStyle("AssetDetailsLabel", "visible", "false");
				ifr.setStyle("AssetDetailsGrid", "visible", "false");
				ifr.setStyle("PropertyDetailsLabel", "visible", "false");
				ifr.setStyle("PropertyDetailsGrid", "visible", "false");
				
			}
		}
	}

	/*
	 * public void scoreCardFields(File file) { for(int i=0; i<fields.length; i++) {
	 * mRepLogger.info(fields[i]+":"+queryList.get(0).get(i+1));
	 * if(queryList.get(0).get(i+1)=="" || queryList.get(0).get(i+1)==null) {
	 * ifr.setValue(fields[i], "NA"); }else { ifr.setValue(fields[i],
	 * queryList.get(0).get(i+1).trim()); } } }
	 */
	
	/*
	   *Method Name       :    getNextApprover
	   *Input Parameters  :    (Current Workstep Name,Current Approver Level).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods sets the next approver for the workstep.Approvers are fetched from Master table based on current workstep and current approver level.
	   */

	public JSONObject getNextApprover(String workstep, String level) {
		
		JSONObject jobjRet=new JSONObject();
		jobjRet.put("Status", "true");
		jobjRet.put("Message","Success");
		String nextApprover = "";
		String nextLevel = "";
		mRepLogger.info("<--Inside getNextApprover-->");
		String query = "";
		mRepLogger.info("Previous Approver level -->" + level);
		if (level.isEmpty()) {
			level = "l1";
		} else {
			level = level.substring(0, 1) + String.valueOf(Integer.valueOf(level.substring(1)) + 1);
		}
		mRepLogger.info("Current Approver level -->" + level);
		nextLevel = level;
		query = "SELECT 1 FROM sys.columns WITH(NOLOCK) WHERE Name = N'" + level
				+ "'AND Object_ID = Object_ID(N'dbo.ng_master_approvers')";
		mRepLogger.info("Executing -->" + query);
		if (ifr.getDataFromDB(query) != null) {
			mRepLogger.info("New approver Column Exists");

			String userRole = ifr.getValue("Initiator_Role").toString();
			
			if((ifr.getActivityName().equalsIgnoreCase("Pre_Part_Closure_Request") && workstep.equalsIgnoreCase("Payment_Posting")) || 
					(ifr.getActivityName().equalsIgnoreCase("PTP") && workstep.equalsIgnoreCase("Payment_Posting")) || 
					(ifr.getActivityName().equalsIgnoreCase("Collection_PickUp") && workstep.equalsIgnoreCase("Payment_Posting")) || 
					(ifr.getActivityName().equalsIgnoreCase("Payment_Correction") && workstep.equalsIgnoreCase("Payment_Posting"))){ 
				String rolequery = "select LCS_User_Group from RLOS_master_users with (NOLOCK) where user_id = '" + ifr.getUserName() + "'";
				List<List<String>> userRoleList = ifr.getDataFromDB(rolequery);
				userRole=userRoleList.get(0).get(0);
			}
			mRepLogger.info("User Role to fetch the next approver-->" + userRole);
			if (!userRole.isEmpty() && userRole != null) {
				query = "select distinct " + level + " from ng_master_approvers WITH (NOLOCK) where workstep = '"
						+ workstep + "'";
				if (workstep.equalsIgnoreCase("Expense_Approval") || workstep.equalsIgnoreCase("Repo_Release_Approval")
						|| workstep.equalsIgnoreCase("Initiate_Sale_Approval")
						|| workstep.equalsIgnoreCase("Repo_and_Sale") || workstep.equalsIgnoreCase("Quote_Approval")) {
					String previousWS = ifr.getValue("PreviousWS").toString();

					if(previousWS!=null && !previousWS.equalsIgnoreCase(workstep)){ 
						query += "AND Initiation_Stage = '" + previousWS + "'";
					}
					
				} else {
					query += "AND Initiator = '" + userRole + "'";
				}
				if (workstep.equalsIgnoreCase("Payment_Posting")) {
					query += " AND Payment_Mode = '" + ifr.getValue("qCollectionEntry_CollectionEntryType").toString()
							+ "'";
				//adding the condition for the cheque/dd in payment_through
					String payThrough=ifr.getValue("qCollectionEntry_Mode_Of_Payment").toString();
					if(payThrough.equalsIgnoreCase("cheque") || payThrough.equalsIgnoreCase("dd")){ 
						query += " AND '"+payThrough+"' IN (SELECT items FROM split(Payment_Through,','))";
					}
					
				} else if (workstep.equalsIgnoreCase("Collection_Escalation")) {
					query += " AND Action_Code = '" + ifr.getValue("qContactRecording_Action_Code").toString() + "'";
				}/* else if(workstep.equalsIgnoreCase("Skip_Cases_Escalation")){ 
					
					String traced=ifr.getValue("Vehicle_Traced").toString();
					query += " AND Action_Code = '" + traced + "'";
					
				}*/
				
				if(workstep.equalsIgnoreCase("PTP")){ 
					String channelMode=ifr.getValue("qContactRecording_Paid_Channel_Mode").toString();
					query += " AND Action_Code = '" + ifr.getValue("qContactRecording_Action_Code").toString() + "' AND Channel_Mode='"+channelMode+"'";
				}

				// Executing Query
				mRepLogger.info("Executing -->" + query);
				List<List<String>> opt = ifr.getDataFromDB(query);
				mRepLogger.info("Query output-->" + opt);
				if (!opt.isEmpty() && opt != null) {
					
					
					nextApprover = opt.get(0).get(0);
					setNextApproverAndWorkstep(nextApprover, nextLevel);
				}else if(opt.size()==0){ 
					//error in getting the next approver / approver not found
//					ifr.setValue("QRole", "");
//					ifr.setValue("qApproverLevel", "");
					jobjRet.put("Status", "false");
					jobjRet.put("Message","Error in getting the next approver, Please contact Administrator!");
				}
			} else {
				nextApprover = "";
				mRepLogger.info("User does not have a role!!");
			}

		}
		
		mRepLogger.info("Final status that is returned ::getnextapprover::"+jobjRet.get("Status")+","+jobjRet.get("Message"));
		return jobjRet;
	}
	/*
	   *Method Name       :    setNextApproverAndWorkstep
	   *Input Parameters  :    (Next Approver,Next Approver Level).
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods sets the next approver level into Hidden form fields.
	   */

	public void setNextApproverAndWorkstep(String nextApprover, String nextLevel) {
		mRepLogger.info("<--Inside setNextApproverAndWorkstep-->");
		mRepLogger.info("Setting Next Approver -->" + nextApprover);
		mRepLogger.info("Setting Next Workstep -->" + nextLevel);
		
		//10th June
		//emptying the next level if approver is not available, as this is effecting reports.
		if(nextApprover==null || nextApprover.trim().equals("")){ 
			nextLevel="";
		}
		ifr.setValue("QRole", nextApprover);
		ifr.setValue("qApproverLevel", nextLevel);
		

	}
	
	/*
	   *Method Name       :    getActionCodeProperties()
	   *Input Parameters  :    NA.
	   *Return Values     :    Properties
	  * Author            :    Aseesh
	   *Description       :    This methods loads the ActionCodeEvent.properties file.
	   */

	public Properties getActionCodeProperties() {

		if (actionCodeProperties == null) {

			FileInputStream fis = null;

			try {
				String path = System.getProperty("jboss.home.dir") + File.separator + "bin" + File.separator
						+ "customProperties" + File.separator + "actioncodeEvent.properties";
				fis = new FileInputStream(path);
				actionCodeProperties = new Properties();
				actionCodeProperties.load(fis);
			} catch (Exception e) {
				mErrLogger.info("Exceptioon Occured getActionCodeProperties" + e.getMessage());
				// e.printStackTrace();
			} finally {
				try {
					if (fis != null)
						fis.close();
				} catch (IOException e) {
					mErrLogger.info("Exceptioon Occured getActionCodeProperties finally" + e.getMessage());
					// e.printStackTrace();
				}
			}
		}

		return actionCodeProperties;

	}
	
	public Properties getServiceProperties() {

		if (serviceProperties == null) {

			FileInputStream fis = null;

			try {
				String path = System.getProperty("jboss.home.dir") + File.separator + "bin" + File.separator
						+ "customServiceProperties" + File.separator + "serviceINI.properties";
				fis = new FileInputStream(path);
				serviceProperties = new Properties();
				serviceProperties.load(fis);
			} catch (Exception e) {
				mErrLogger.info("Exceptioon Occured getServiceProperties" + e.getMessage());
				// e.printStackTrace();
			} finally {
				try {
					if (fis != null)
						fis.close();
				} catch (IOException e) {
					mErrLogger.info("Exceptioon Occured getServiceProperties finally" + e.getMessage());
					// e.printStackTrace();
				}
			}
		}

		return serviceProperties;

	}
	
	/*
	   *Method Name       :    actionCodeOnChange
	   *Input Parameters  :    JSdata.
	   *Return Values     :    String - FieldsToClear
	  * Author            :    Aseesh
	   *Description       :    This methods hides all fields related old action code and Shows fields related to new Action code.Fields related to each actioncode are kept in actioncodeevent.properties file.
	   */

	public String actionCodeOnChange(String JSdata) {

		mRepLogger.info("Inside Control ID:OnChangeActionCode");
		String fieldsToClear = "";
		try{ 
			
			String ActionCode = ifr.getValue("qContactRecording_Action_Code").toString();
			String OldActionCode = ifr.getValue("OldActionCode").toString();
			ActionCode = ActionCode.replace(" ", "_");
			ActionCode = ActionCode.trim();
			OldActionCode = OldActionCode.replace(" ", "_");
			OldActionCode = OldActionCode.trim();
			mRepLogger.info("ActionCode::" + ActionCode + ", OldActionCode::" + OldActionCode);
			
			Properties p = getActionCodeProperties();
			if (OldActionCode != null && !OldActionCode.equals("") && !OldActionCode.equalsIgnoreCase(ActionCode)) {
				// hiding the fields which are already shown for the old action code.
				mRepLogger.info("hiding the fields which are already shown for the old action code");
				if (p.getProperty("M_" + OldActionCode) != null && !p.getProperty("M_" + OldActionCode).isEmpty()) {
					String Mfields[] = p.getProperty("M_" + OldActionCode).split(",");
					mRepLogger.info("Mandatory fields -->" + p.getProperty("M_" + OldActionCode));
					for (int i = 0; i < Mfields.length; i++) {

						ifr.setStyle(Mfields[i].trim(), "mandatory", "false");

					}
				}
				if (p.getProperty("F_" + OldActionCode) != null && !p.getProperty("F_" + OldActionCode).isEmpty()) {
					fieldsToClear = p.getProperty("F_" + OldActionCode);
					String fields[] = fieldsToClear.split(",");
					mRepLogger.info("Fields-->" + p.getProperty("F_" + OldActionCode));
					for (int i = 0; i < fields.length; i++) {

						ifr.setStyle(fields[i].trim(), "visible", "false");

					}
				}
				if (p.getProperty("T_" + OldActionCode) != null && !p.getProperty("T_" + OldActionCode).isEmpty()) {
					String Tfields[] = p.getProperty("T_" + OldActionCode).split(",");
					mRepLogger.info("Tabs -->" + p.getProperty("T_" + OldActionCode));
					for (int i = 0; i < Tfields.length; i++) {
						
						if(Tfields[i].contains("~")){ //before the ~ is tabid & after ~ is the frame names to be made mandatory in WS
							if (Integer.valueOf(Tfields[i].split("~")[0].trim()) > 4) {
								ifr.setTabStyle("tab2", Tfields[i].split("~")[0].trim(), "visible", "false");
							}
						}else{ 
							if (Integer.valueOf(Tfields[i].trim()) > 4) {
								ifr.setTabStyle("tab2", Tfields[i].trim(), "visible", "false");
							}
						}
						
						
					}
				}

			}
			// show the fields for the current selected action code.
			mRepLogger.info("show the fields for the current selected action code");
			if (ActionCode.equalsIgnoreCase("Legal") && 
					(ifr.getActivityName().equalsIgnoreCase("Initiator") || 
							ifr.getActivityName().equalsIgnoreCase("Legal"))) {
				//If legal as action code we should not show any tab in initiator & legal WS as this tab will be enabled only in initiate legal action WS.
				mRepLogger.info("Action code -->" + ActionCode + "at Initiator or Legal");
				ifr.setStyle("qContactRecording_Comments", "mandatory", "true");
				
			} else {
				ifr.setStyle("qContactRecording_Comments", "mandatory", "false");
				if (p.getProperty("T_" + ActionCode) != null && !p.getProperty("T_" + ActionCode).isEmpty()) {
					String TfldStr = p.getProperty("T_" + ActionCode);
					mRepLogger.info("Tabs to be shown -->" + TfldStr);
					String Tflds[] = TfldStr.split(",");
					for (int i = 0; i < Tflds.length; i++) {
						
						if(Tflds[i].contains("~")){ //before the ~ is tabid & after ~ is the frame names to be made mandatory in WS
							ifr.setTabStyle("tab2", Tflds[i].split("~")[0].trim(), "visible", "true");
						}else{ 
							ifr.setTabStyle("tab2", Tflds[i].trim(), "visible", "true");
						}
						

					}
				}

				if (p.getProperty("F_" + ActionCode) != null && !p.getProperty("F_" + ActionCode).isEmpty()) {
					String fldStr = p.getProperty("F_" + ActionCode);
					mRepLogger.info("Fields to be shown -->" + fldStr);
					String flds[] = fldStr.split(",");
					for (int i = 0; i < flds.length; i++) {

						ifr.setStyle(flds[i].trim(), "visible", "true");

					}
				}

				if (p.getProperty("M_" + ActionCode) != null && !p.getProperty("M_" + ActionCode).isEmpty()) {
					String MfldStr = p.getProperty("M_" + ActionCode);
					mRepLogger.info("Mandatory fields-->" + MfldStr);
					String Mflds[] = MfldStr.split(",");
					for (int i = 0; i < Mflds.length; i++) {

						ifr.setStyle(Mflds[i].trim(), "mandatory", "true");

					}
				}
			}
			
		}catch(Exception e){ 
			fieldsToClear="ERROR"; // error occured on change of action code
			mErrLogger.info("Error in actioncode onchange ::"+e.getMessage());
			mErrLogger.info("",e);
		}finally{ 
			
			//setting the target WS for the changed Action Code.
			if(!setTargetWS()){ 
				fieldsToClear="ERROR"; // error occured on setting the target WS.
			}
			
		}
		
		return fieldsToClear;
	}
	/*
	   *Method Name       :    disableTabsOnLoad()
	   *Input Parameters  :    NA
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods hides/disables tabs based on Action Code.Tabs related to each actioncode are kept in actioncodeevent.properties file.
	   */
	
	public void disableTabsOnLoad() {
		mRepLogger.info("Inside disableTabsOnLoad Method");
		mRepLogger.info("ActionCode::" + ifr.getValue("qContactRecording_Action_Code") + "\n" + "Activity Name : "+ ifr.getActivityName());
		Properties p = getActionCodeProperties();
		if(p.getProperty(ifr.getActivityName())!=null && !p.getProperty(ifr.getActivityName()).isEmpty())
		{
			String TabList []=p.getProperty(ifr.getActivityName()).split(",");
			mRepLogger.info("List of Tabs/Frames to be made Non Editable :"+"\n"+ Arrays.toString(TabList));
			for(int i=0;i<TabList.length;i++)
			{
				if(TabList[i].startsWith("T_"))
				{
					ifr.setTabStyle("tab2",TabList[i].split("_")[1], "disable","true");
				}
				else if (TabList[i].startsWith("F_")) {
					
					ifr.setStyle(TabList[i].split("_")[1],"disable","true");
				}	
			}
		}
		else {
			mRepLogger.info("No Tabs/Frames to be made Non-Editable");
		}
	}
	
	/*
	   *Method Name       :    openTabOnclick
	   *Input Parameters  :    Property Key
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This methods hides/disables tabs based on Action Code.Tabs related to each actioncode are kept in actioncodeevent.properties file.
	   */

	public String openTabOnclick(String propKey) {

		mRepLogger.info("Inside Control ID:openTabOnclick");
		String tabVal = "";
		propKey = propKey.replace(" ", "_");
		if (propKey != null && !propKey.equals("")) {
			Properties p = getActionCodeProperties();
			String tabPropVal = p.getProperty("T_" + propKey);
			if (tabPropVal != null && !tabPropVal.equals("")) {
				//before the ~ is tabid & after ~ is the frame names to be made mandatory in WS
				tabVal = tabPropVal.split(",")[0].split("~")[0];
			}

		}

		return tabVal;
	}
	
	/*
	   *Method Name       :    getTabIdToValidate
	   *Input Parameters  :    ActionCode
	   *Return Values     :    String- Tab id
	  * Author            :    Aseesh
	   *Description       :    This method returns the tab id's based on action code for checking if mandatory fields/frames were filled or not.
	   */

	//gets the tab name to display error alert if the mandatory fields in the tab were filled.
	public String getTabIdToValidate(String propKey) {

		mRepLogger.info("Inside Control getTabIdToValidate");
		String tabIDs="";
		propKey = propKey.replace(" ", "_");
		if (propKey != null && !propKey.equals("")) {
			Properties p = getActionCodeProperties();
			tabIDs = p.getProperty("T_" + propKey);
			
		}
		if(!tabIDs.contains("4")){ 
			tabIDs+=",4";
		}
		if(!tabIDs.contains("21")){ 
			tabIDs+=",21";
		}

		return tabIDs;
	}
	
	/*
	   *Method Name       :    getActionCodeValues
	   *Input Parameters  :    Activity Name, Iform Reference
	   *Return Values     :    String- List of Action codes
	  * Author            :    Aseesh
	   *Description       :    This method returns list of Action code accessible to a particular User Role. 
	   This approach is used to populate the list of action codes in the contact recording drop down based on user role.
	   */
	
	public String getActionCodeValues(String ActivityName, IFormReference ifr) {
		List<List<String>> ActionCodeValues = null;
		String query = "";
		String returnValue = "";
		String returnDisableVal="";
		String currentUserRole = "";
		int noRoleFoundFlag = 0;
		JSONObject jobj=new JSONObject();
		if (ActivityName.equalsIgnoreCase("Initiator")) {
			query = "select LCS_User_Group from RLOS_MASTER_USERS WITH (NOLOCK) where user_id = '" + ifr.getUserName()
					+ "'";
//			mRepLogger.info("Executing query -->" + query);
			List<List<String>> role = ifr.getDataFromDB(query);
//			mRepLogger.info("Output -->" + role);
			if (role != null && !role.isEmpty()) {
				currentUserRole = role.get(0).get(0);

				query = "select distinct ActionCode,roles,Module,Status,Sub_Status,Contacted,ac_order from NG_Master_Action_Code WITH (NOLOCK) where WorkstepName = '"
						+ ActivityName + "' and VisibleFlag='Y' ORDER BY ac_order ASC";
//				mRepLogger.info("Executing Query -->" + query);
				List<List<String>> actionAndRoles = ifr.getDataFromDB(query);
//				mRepLogger.info("actionAndRoles Result -->" + actionAndRoles);
				
				if(actionAndRoles.size()>0){ 
//					mRepLogger.info("<<<<<<<<>>>>>>" + ifr.getValue("Loan_Account_No").toString());
					String statusQuery="SELECT L_GK_Case_Status,L_GK_Case_Sub_Status,Product FROM NG_DUMP_LOAN_DET "
							+ "WITH(NOLOCK) WHERE L_ACCT_NO = '"+ifr.getValue("Loan_Account_No").toString()+"'";
//					mRepLogger.info("Status & Substatus Query -->" + statusQuery);
					List<List<String>> statusVals = ifr.getDataFromDB(statusQuery); 
					String cs="";
					String css="";
					String prod="";
					try{ 
//						mRepLogger.info("Status & Substatus  -->"+statusVals);
						cs=statusVals.get(0).get(0);
						css=statusVals.get(0).get(1);
						prod=statusVals.get(0).get(2);
						mRepLogger.info("Status Values -->"+cs+","+css);
					}catch(Exception e){ 
						
						mRepLogger.info("<-- Status Values is not available. -->");
					}
					
					try{ 
						
						for (int i = 0; i < actionAndRoles.size(); i++) {
							// int flag = 0;
							//first checking if the action code is applicable for Branch or not.

							String[] module=actionAndRoles.get(i).get(2).split(",");
							if(!Arrays.asList(module).contains("B")){ 
								continue;
							}

							String[] splitRoles = actionAndRoles.get(i).get(1).split(",");
							for (int j = 0; j < splitRoles.length; j++) {
								if (currentUserRole.equalsIgnoreCase(splitRoles[j])) {
									// flag = 1;
									//checking if the contacted is yes/no for the role telecaller and load the action codes based on the same.
									if(currentUserRole.equalsIgnoreCase("telecaller")){ 

										String contacted=ifr.getValue("qContactRecording_Contacted").toString();
										String currContVal=actionAndRoles.get(i).get(5);
										if(contacted==null || contacted.trim().equals("") || currContVal==null || currContVal.trim().equals("") || currContVal.equalsIgnoreCase("null")){ 
											continue;
										}
										else if(!contacted.equalsIgnoreCase(currContVal)){ 
											continue;
										}
									}
									
									String casStatus=actionAndRoles.get(i).get(3);
									casStatus=(casStatus==null || casStatus.trim().equals("")) ? "" : casStatus;
									String casSubStatus=actionAndRoles.get(i).get(4);
									casSubStatus=(casSubStatus==null || casSubStatus.trim().equals("")) ? "" : casSubStatus;
									
									String[] casStatusArr=casStatus.split("/");
									String[] casSubStatusArr=casSubStatus.split("/");
									
									boolean f=true;
									if(!Arrays.asList(casStatusArr).contains("ALL")){ 
										
										if(cs==null || cs.trim().equals("") || !Arrays.asList(casStatusArr).contains(cs)){ 
											returnDisableVal+=actionAndRoles.get(i).get(0) + ",";
											f=false;
										}
									}
									
									if(f){ 
										if(!Arrays.asList(casSubStatusArr).contains("ALL")){ 
											
											if(css==null || css.trim().equals("") || !Arrays.asList(casSubStatusArr).contains(css)){ 
												returnDisableVal+=actionAndRoles.get(i).get(0) + ",";
												f=false;
											}
										}
									}
									
									if(f && actionAndRoles.get(i).get(0).equalsIgnoreCase("Initiate Repo")){ 
										String prodArray[] = { "Grameen Vaahan Loan","Grameen Savaari Loan" };
										if(!Arrays.asList(prodArray).contains(prod)){ 
											returnDisableVal+=actionAndRoles.get(i).get(0) + ",";
										}
									}
									
									returnValue += actionAndRoles.get(i).get(0) + ",";
//									mRepLogger.info("ActionCode added -->" + actionAndRoles.get(i).get(0));
									break;
								}
							}
						}
					}catch(Exception e){ 
						
						mErrLogger.info("Error in adding action codes to the String :::"+e.getMessage(),e);
						
					}
					
				
				}
				
				if(returnValue.contains(",")){ 
					returnValue = returnValue.substring(0, returnValue.lastIndexOf(","));
				}
				
				

			} else {
				mRepLogger.info("<-- This User is not present in table or does not have a role assigned -->");
				// query = "select distinct ActionCode from NG_Master_Action_Code where
				// WorkstepName = '" + ActivityName + "'";
				// noRoleFoundFlag = 1;
			}
			
		} else {
			query = "select distinct ActionCode from NG_Master_Action_Code WITH (NOLOCK) where WorkstepName = '"
					+ ActivityName + "' and VisibleFlag='Y'";
			noRoleFoundFlag = 1;
		}
		if (noRoleFoundFlag == 1) {
//			mRepLogger.info("Executing query -->" + query);
			ActionCodeValues = ifr.getDataFromDB(query);
//			mRepLogger.info("Output Obtained --> " + ActionCodeValues);
			if (ActionCodeValues != null && !ActionCodeValues.isEmpty()) {
				returnValue = ActionCodeValues.toString().replace("[", "");
				returnValue = returnValue.replace("]", "");
//				mRepLogger.info("Return Value -->" + returnValue);
			}

		}

		jobj.put("ActionCodes", returnValue);
		jobj.put("StatusValues", returnDisableVal);
		return jobj.toString();

	}
	/*
	 * public long milliToDays(long timeInMilli) { long days = 0; long oneDay = (24
	 * * 60 * 60 * 1000); days = timeInMilli / oneDay;
	 * 
	 * 
	 * 
	 * long rem = timeInMilli % oneDay; if (rem > 0) { days += 1; } return days; }
	 */
	
	/*
	   *Method Name       :    OnchangePTPdays
	   *Input Parameters  :    NA
	   *Return Values     :    String- Ptp days- error Message
	  * Author            :    Aseesh
	   *Description       :    This method is used to validate whether the Selected promise to pay date is between the current date and Max ptp days configured in property file.
	   						   If the condition is not satisfied , error msg wuld be returned comprising of range of possible Ptp date that can be selected.
	   */
	public String OnchangePTPdays(String JSData) {
		String retStatus = "true";
		String strPTPDate = ifr.getValue("qContactRecording_promisetopaydate").toString();

		if (strPTPDate != null && !("".equals(strPTPDate))) {
			try {
				SimpleDateFormat Formatter = new SimpleDateFormat("dd/MM/yyyy");
				Date selDate = Formatter.parse(strPTPDate);
				LocalDate PTPDate = selDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				LocalDate currentDate = LocalDate.now();
				long diffInDays = ChronoUnit.DAYS.between(currentDate, PTPDate);

				Properties p = getCommonProperties();
				int ptpMaxDays = Integer.parseInt(p.getProperty("PTPDaysMax"));
				LocalDate maxPTPDt = currentDate.plusDays(ptpMaxDays);

				if (diffInDays < 0 || diffInDays > ptpMaxDays) {

					retStatus = "false~Promise to Pay Date should be between "
							+ currentDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " and "
							+ maxPTPDt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				}

			} catch (Exception e) {
				mErrLogger.info("Exceptioon Occured OnchangePTPdays" + e.getMessage());
				// e.printStackTrace();
			}
		} else {
			mRepLogger.info("PTP date is empty");
			retStatus = "false~Promise to Pay Date is empty";
		}

		return retStatus;
	}
	/*
	   *Method Name       :    OnchangeFPTPdays
	   *Input Parameters  :    NA
	   *Return Values     :    String- Ptp days- error Message
	  * Author            :    Aseesh
	   *Description       :    This method is used to validate whether the Selected promise to pay date is between the (current date + PTPMax days) and (current date + FTPMaxdays) configured in property file.
	   						   If the condition is not satisfied , error msg wuld be returned comprising of range of possible Ptp date that can be selected.
	   */

	public String OnchangeFPTPdays(String JSData) {
		String strFPTPDate = ifr.getValue("qContactRecording_promisetopaydate").toString();
		String retStatus = "true";
		if (strFPTPDate != null && !("".equals(strFPTPDate))) {
			try {
				Properties p = getCommonProperties();
				int fPtpMinDays = Integer.parseInt(p.getProperty("PTPDaysMax"));
				int fPtpMaxDays = 0;
				String fPtpMaxDaysStr = p.getProperty("FPTPDaysMax");

				LocalDate mindt = LocalDate.now().plusDays(fPtpMinDays);
				LocalDate maxdt = null;

				if (fPtpMaxDaysStr != null && fPtpMaxDaysStr.equalsIgnoreCase("eom")) {

					maxdt = YearMonth.now().atEndOfMonth();

				} else {

					fPtpMaxDays = Integer.parseInt(fPtpMaxDaysStr);
					int finalFptpMaxDays = fPtpMinDays + fPtpMaxDays; // the FPTP starting date starts from next day of
																		// max PTP date.
					maxdt = LocalDate.now().plusDays(finalFptpMaxDays);

				}

				SimpleDateFormat Formatter = new SimpleDateFormat("dd/MM/yyyy");
				Date selDate = Formatter.parse(strFPTPDate);
				LocalDate selLocalDt = selDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

				if (selLocalDt.isAfter(mindt) && (selLocalDt.isBefore(maxdt) || selLocalDt.isEqual(maxdt))) {

					retStatus = "true";
				} else {

					retStatus = "false~Promise to Pay Date should be between "
							+ mindt.plusDays(1).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " and "
							+ maxdt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

				}

			} catch (Exception e) {
				mErrLogger.info(e);

			}
		} else {
			mRepLogger.info("FPTP Date is empty");
			retStatus = "false~Promise to Pay date is empty";
		}

		return retStatus;
	}
	
	/*
	   *Method Name       :    OnchangePickupdays
	   *Input Parameters  :    NA
	   *Return Values     :    String- Pickup days- error Message
	  * Author            :    Aseesh
	   *Description       :    This method is used to validate whether the Selected Pickup date is between the current date and (current date + Max Online/Regular Pickup days) configured in property file.
	   						   If the condition is not satisfied , error msg wuld be returned comprising of range of possible Pickup date that can be selected.
	   */
	
	public String OnchangePickupdays(String JsData)
	{
		String retStatus = "true";
		String Action_Code=ifr.getValue("qContactRecording_Action_Code").toString();
		String Pick_upDate=ifr.getValue("qCR_Pickup_Pick_Up_Date").toString();
		int MaxDays=0;
		Properties p = getCommonProperties();
		if(Action_Code.equalsIgnoreCase("Online Pick Up"))
		{
			MaxDays=Integer.parseInt(p.getProperty("Online_Pickup"));
			mRepLogger.info("Max days for Online Pickup " +MaxDays);
		}
		else if(Action_Code.equalsIgnoreCase("Regular Pick Up")) {
			MaxDays=Integer.parseInt(p.getProperty("Regular_Pickup"));
			mRepLogger.info("Max days for Regular Pickup " +MaxDays);
		}
		try {
			SimpleDateFormat Formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date pickupDate = Formatter.parse(Pick_upDate);
			LocalDate PickupDate = pickupDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			LocalDate currentDate = LocalDate.now();
			LocalDate maxPickupDt = currentDate.plusDays(MaxDays);
			long diffInDays = ChronoUnit.DAYS.between(currentDate,PickupDate);
			
			if(diffInDays < 0 || diffInDays >MaxDays) {
				
				retStatus = "false~ "+Action_Code.trim()+" Date should be between "
						+ currentDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " and "
						+ maxPickupDt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
			}
			
		}catch (Exception e){
			mErrLogger.info(e);
			
		}
		
		return retStatus;
	}
	
	/*
	   *Method Name       :    getCommonProperties
	   *Input Parameters  :    NA.
	   *Return Values     :    Properties
	  * Author            :    Aseesh
	   *Description       :    This methods loads the CommonProperties.properties file.
	   */

	public Properties getCommonProperties() {

		if (commonProperties == null) {

			FileInputStream fis = null;

			try {
				String path = System.getProperty("jboss.home.dir") + File.separator + "bin" + File.separator
						+ "customProperties" + File.separator + "commonProp.properties";
				fis = new FileInputStream(path);
				commonProperties = new Properties();
				commonProperties.load(fis);
			} catch (Exception e) {
				mRepLogger.info("Exception Occured getCommonProperties:" + e.getMessage());
				// e.printStackTrace();
			} finally {
				try {
					if (fis != null)
						fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					mRepLogger.info("Exception Occured getCommonProperties finally:" + e.getMessage());
					// e.printStackTrace();
				}
			}
		}

		return commonProperties;

	}
	
	public static Properties getCommonPropertiesStatic() {

		if (staticcommonProperties == null) {

			FileInputStream fis = null;

			try {
				String path = System.getProperty("jboss.home.dir") + File.separator + "bin" + File.separator
						+ "customProperties" + File.separator + "commonProp.properties";
				fis = new FileInputStream(path);
				staticcommonProperties = new Properties();
				staticcommonProperties.load(fis);
			} catch (Exception e) {
				mRepLogger.info("Exception Occured getCommonPropertiesStatic:" + e.getMessage());
				// e.printStackTrace();
			} finally {
				try {
					if (fis != null)
						fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					mRepLogger.info("Exception Occured getCommonPropertiesStatic finally:" + e.getMessage());
					// e.printStackTrace();
				}
			}
		}

		return staticcommonProperties;

	}
	
	/*
	   *Method Name       :    populateApplicantType
	   *Input Parameters  :    Iform Reference
	   *Return Values     :    String- Name of Applicant, Co-Applicant, Gurantor's based on Loan number.
	  * Author            :    Aseesh
	   *Description       :    This method is used to compute the names of Applicant, Co-Applicant, Gurantors of a loan from dump based on loan number.
	   */

	public String populateApplicantType(IFormReference ifr) {
		mRepLogger.info("Inside populateApplicantType");
		String output = "";
		List<List<String>> opt;
		String query = "";
		String loanAcctNo = ifr.getValue("Loan_Account_No").toString();

		// Applicant
		query = "select [Name.1] from NG_DUMP_DEMOGRAPHIC with (NOLOCK) where L_ACCT_NO = '##REPLACEMENT_LOAN_NO##' and L_App_Type = 'Applicant'";
		query = query.replace("##REPLACEMENT_LOAN_NO##", loanAcctNo);
		mRepLogger.info("Executing query-->" + query);
		opt = ifr.getDataFromDB(query);
		mRepLogger.info("Query opt-->" + opt);
		if (opt != null && !opt.get(0).get(0).toString().equalsIgnoreCase("")) {
			output += "Applicant - " + opt.get(0).get(0).toString() + "--break--";
		}

		mRepLogger.info("<---After Applicant--->");
		// Co_Applicant
		query = "select [Name.1] from NG_DUMP_DEMOGRAPHIC with (NOLOCK) where L_ACCT_NO = '##REPLACEMENT_LOAN_NO##' and L_App_Type = 'Co-Applicant' ORDER BY Customer";
		query = query.replace("##REPLACEMENT_LOAN_NO##", loanAcctNo);
		mRepLogger.info("Executing query-->" + query);
		opt = ifr.getDataFromDB(query);
		mRepLogger.info("Query opt-->" + opt);
		if (opt != null && !opt.toString().equalsIgnoreCase("[]")) {
			for (int i = 0; i < opt.size(); i++) {
				output += "Co-Applicant - " + opt.get(i).get(0).toString() + "--break--";
			}
			output += "--break--";
		}

		mRepLogger.info("<---After Co-Applicant--->");

		// Guarantor
		query = "select [Name.1] from NG_DUMP_DEMOGRAPHIC with (NOLOCK) where L_ACCT_NO = '##REPLACEMENT_LOAN_NO##' and L_App_Type = 'Guarantor'";
		query = query.replace("##REPLACEMENT_LOAN_NO##", loanAcctNo);
		mRepLogger.info("Executing query-->" + query);
		opt = ifr.getDataFromDB(query);
		mRepLogger.info("Query opt-->" + opt);
		if (opt != null && !opt.toString().equalsIgnoreCase("[]")) {
			for (int i = 0; i < opt.size(); i++) {
				output += "Guarantor - " + opt.get(i).get(0).toString() + "--break--";
			}
		}

		mRepLogger.info("<---After Guarantor--->");

		mRepLogger.info("Final output String returning-->" + output);
		return output;
	}
	
	/*
	   *Method Name       :    generateDocument
	   *Input Parameters  :    Iform Reference,Document Name,Row index in Document Grid
	   *Return Values     :    Status
	  * Author            :    Aseesh
	   *Description       :    This method generates outward documents by filling the template configured in server with Complex/Ext table data.
	   */

	public Status generateDocument(IFormReference ifr, String docType, String rowIndex) throws Exception {
		mRepLogger.info("Document Name is"+docType);
//		String gtSuccess = "false";
		WFXmlResponse xmlResponse = null;
		String addDocOutXML = "";
		String upldDocType="";
		Status s=new Status();
		s.setStatus(false);
		s.setMsg("Issue in generating the document : ");
		mRepLogger.info("Inside generateDocument function...");
		Properties p = getCommonProperties();
		String[] closDtDocs=p.getProperty("DocumentsHavingClosureDate").split(",");
		//first checking the closure data is available in the closed dump for the preclosure/partpayment documents.
		if(Arrays.asList(closDtDocs).contains(docType)){ 
			String loanNo = ifr.getValue("Loan_Account_No").toString();
			List<List<String>> clsDtQuery=ifr.getDataFromDB(p.getProperty("ClosureDtQuery").replace("##Loan_Account_No##", loanNo));
			if(clsDtQuery.size()==0){ 
				mRepLogger.info("Loan is not yet closed in T24, So skipping the document generation.");
				s.setStatus(false);
				s.setMsg("The loan is not yet closed in T24, So cannot generate the document: ");
				return s;
			}
		}
		
		String[] docsListWS=p.getProperty("DocParamsFromWS").split(",");
		
		//getting the doc parameters from the WebService.
		if(Arrays.asList(docsListWS).contains(docType))
		{
			String pid = ifr.getValue("pInstanceID").toString();
			String loanNo = ifr.getValue("Loan_Account_No").toString();
			CollectionCommonServices cs = new CollectionCommonServices(ifr);
			String respFlag=cs.fetchDocParams(pid,loanNo);
			if (!respFlag.startsWith("SUCCESS")) {
				s.setStatus(false);
				if (respFlag.contains("~~")) {
					s.setMsg("Error in getting the values from T24 : "+respFlag.split("~~")[1]+" for Document : ");
					return s;
				} else {
					s.setMsg("Issue in getting values from T24 for Document : ");
					return s;
					
				}
	
			}
		
		}
		//getting the document names from property file
		try{
//			mRepLogger.info("Status"+p.getProperty("Document_convert_Words").contains(docType));
		if(p.getProperty("Document_convert_Words").contains(docType))
		{
			document_number_field(docType,ifr,p);
			
		}
		if(docType.equalsIgnoreCase("Quote_format_for_purchasing_repossession_vehicle")){ 
			
			setQuoteAmountsToWords();
		}
		}
		catch(Exception e)
		{
			mRepLogger.info("Error in reading the document from propert file");
		}
		
		
		// GenerateTemplate gt = null;
		String destinationPath = "";
		String docPath = null;
		try {

			//getting the preferred language to generate the document in preferred language if applicable.
			if(docType.toLowerCase().startsWith("demand_letter") || 
					docType.equalsIgnoreCase("intimation_letter") ||
					docType.equalsIgnoreCase("recall_notice")){ 
				List<List<String>> prefLang=null;
				String prefLanguageQry=p.getProperty("PreferredLanguage");
				if(prefLanguageQry!=null){ 
					prefLang = ifr.getDataFromDB(prefLanguageQry.replaceAll("##Loan_Acc_No##", ifr.getValue("Loan_Account_No").toString()));
					
				}
				
				if(prefLang!=null && prefLang.size()>0 && prefLang.get(0).get(0)!=null && !prefLang.get(0).get(0).trim().equals("")){ 
					mRepLogger.info("Pref Lang for Doc ---"+docType+" is ---> " + prefLang.get(0).get(0));
					upldDocType=docType;//for maintaining the same doc name instead of vernacular suffix.
					docType=docType+"_"+prefLang.get(0).get(0);
				}else{ 
					
					s.setStatus(false);
					s.setMsg("Preferred language not available for document : ");
					
					return s;
				}
				
				
			}else{ 
				upldDocType=docType;//passing the same doc name if the generated doc is a non vernacular doc.
			}
			
			XMLParser generalDataParser = null;
			destinationPath = generateTemplate(ifr, generalDataParser, docType, upldDocType);// send template name
			mRepLogger.info("Document type is ----" + docType);
			mRepLogger.info("Destination Path -----> " + destinationPath);


		} catch (Exception e) {
			mErrLogger.info("Error while generating document..." + e.getMessage());
			// e.printStackTrace();

		}
		// Add to SMS
		if (destinationPath != null && destinationPath != "") {
			mRepLogger.info("Inside Add to SMS block");
			List<List<String>> folderIndex = ifr.getDataFromDB(
					"select folderindex from pdbfolder where name = '" + ifr.getValue("pInstanceID") + "'");
			mRepLogger.info("Folder Index ------> " + folderIndex.get(0).get(0));
			String volumeId = p.getProperty("VolumeId");
			mRepLogger.info("Volume ID ------> " + volumeId);

			String destinationPath_PDF = destinationPath.replaceAll(".docx", ".pdf"); // destinationPath.substring(0,
																						// destinationPath.lastIndexOf("."))+".pdf";
			mRepLogger.info("destinationPath_PDF  ------> " + destinationPath_PDF);
			
			boolean finalB=false;
			String finalDestPath="";
			if(docType.equalsIgnoreCase("SOA")){ 
				
				if(createPDF(destinationPath, destinationPath_PDF)){ 
					finalB=true;
					finalDestPath=destinationPath_PDF;
				}	
				
			}else{ 
				finalB=true;
				finalDestPath=destinationPath;
			}
			
			if (finalB) {

				String smsRet=AddtoSMS(finalDestPath, folderIndex.get(0).get(0), upldDocType, ifr, p);
				mRepLogger.info("SmsRet  ------> " + smsRet);
				xmlResponse = new WFXmlResponse(smsRet);
				mRepLogger.info("Document Index  ------> " +xmlResponse.getVal("DocumentIndex"));
				if(! "E".equalsIgnoreCase(smsRet)) {
//					gtSuccess = "true";
					s.setStatus(true);
					s.setMsg("Successfully generated : ");
					s.setSubMsg(smsRet.replace("\n", ""));
					
//					addDocInfo(docType);
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");  
				    LocalDateTime now = LocalDateTime.now();  
				   
					ifr.setTableCellValue("Outward_Document_ListView", Integer.parseInt(rowIndex), 
							Integer.parseInt(p.getProperty("DocGenDateColumn")), dtf.format(now).toString());
					
					ifr.setTableCellValue("Outward_Document_ListView",Integer.parseInt(rowIndex),
							Integer.parseInt(p.getProperty("DocIndexColumn")),xmlResponse.getVal("DocumentIndex"));
					
					//delete the files which are uploaded successfully to DMS.
					File fDel=new File(destinationPath);
					try{ 
						fDel.delete();
					}catch(Exception e){ 
						mErrLogger.info("Error in deleting the file:"+destinationPath,e);
					}
					fDel=new File(destinationPath_PDF);
					try{ 
						fDel.delete();
					}catch(Exception e){ 
						mErrLogger.info("Error in deleting the file:"+destinationPath_PDF,e);
					}
				}
			
			} else {
				mRepLogger.info(" PDF Creation is Failed");
				s.setStatus(false);
				s.setMsg("Issue in converting to PDF of document : ");
			}

		} else {
			mRepLogger.info("DestinationPath is null");
			s.setStatus(false);
			s.setMsg("Issue in generating the document : ");

		}

		return s;
	}
	/*
	   *Method Name       :    AddtoSMS
	   *Input Parameters  :    Path of document to be added to SMS, Parent Folder,Document Name, Iform Reference,Property obj.
	   *Return Values     :    String- Status
	  * Author            :    Aseesh
	   *Description       :    This method adds the generated document to SMS.
	   */

	public static String AddtoSMS(String docPath, String parentfolder, String sDocName, IFormReference ifr, Properties p)
			throws NGIMException, Exception {

		mRepLogger.info("docPath, parentfolder, sDocName at AddtoSMS in ODDocumentUpload = " + docPath + ", "
				+ parentfolder + ", " + sDocName);

		String stvDocumentType = "";
		String sRetVal = "";
		long lgvDocSize = 0;
		try {
			File doc = new File(docPath);
			String simgVolId1 = "";
			String simgDocId = "";
			String sExt = docPath.substring(docPath.lastIndexOf(".") + 1, docPath.length());
			JPDBRecoverDocData docDBData = new JPDBRecoverDocData();
			JPISIsIndex isIndex = new JPISIsIndex();
			File obvFile = doc;
			lgvDocSize = obvFile.length();
			String sDocSize = Long.toString(lgvDocSize);
			int nNoOfPages = 0;
			try {

				nNoOfPages = 1;// Tif6.getPageCount(docPath);
				// wFLogger.writeXML("No of Pages "+nNoOfPages);

				stvDocumentType = "N"; // Docx

			} catch (Exception e) {
				mErrLogger.info("Error Occured : " + e.getMessage());
				// e.printStackTrace();
			}
//			String volumeId = p.getProperty("VolumeId");
			mRepLogger.info("VolumeID is ..." + p.getProperty("VolumeId"));
			mRepLogger.info("Before AddDocument1_MT call....");
//			mRepLogger.info("ifr.getServerIp().. " + ifr.getServerIp());
//			mRepLogger.info("ifr.getServerPort().. " + ifr.getServerPort());
			mRepLogger.info("Docpath........ " + docPath);
//			InitConfigPropChildWork getConfigProp = new InitConfigPropChildWork();
//			mRepLogger.info("getConfigProp.serverIP().. " + getConfigProp.serverIP());
//			mRepLogger.info("getConfigProp.wrapperPort().. " + getConfigProp.wrapperPort());
			mRepLogger.info("Running CPISDocumentTxn.AddDocument_MT with following properties ");
			mRepLogger.info("IP : "+p.getProperty("IP")+", Port : "+Short.parseShort(p.getProperty("Port"))+" , "
					+ "CabName : "+p.getProperty("Cabinet")+" , Volumeid :"+Short.parseShort(p.getProperty("VolumeId"))+" , isIndex : "+isIndex);
			CPISDocumentTxn.AddDocument_MT(null, p.getProperty("IP"), Short.parseShort(p.getProperty("Port")),
					p.getProperty("Cabinet"), Short.parseShort(p.getProperty("VolumeId")), docPath, docDBData, "", isIndex);
			mRepLogger.info("Control after AddDocument_MT function call");
			simgVolId1 = simgVolId1 + isIndex.m_sVolumeId;
			simgDocId = simgDocId + isIndex.m_nDocIndex;
			String sISIndex = simgDocId + "#" + simgVolId1;

			sRetVal = AddDocument(parentfolder, nNoOfPages, sDocName, sDocSize, sISIndex, sExt, stvDocumentType, doc,
					ifr,p);
			mRepLogger.info("Document added successfully from " + doc.toString());

			mRepLogger.info("Document added ..... " + sRetVal);

			return sRetVal;
		} catch (IOException e) {
			mErrLogger.info("IOException at AddtoSMS in ODDocumentUpload = " + e.getMessage());

			return "E";
		} catch (JPISException e) {
			mErrLogger.info("JPISException at AddtoSMS in ODDocumentUpload = " + e.getMessage());

			return "E";
		} catch (Exception e) {
			mErrLogger.info("Exception..." + e);
			return "E";
		}

	}

	// Add to document
	/*
	   *Method Name       :    AddDocument
	   *Input Parameters  :    FolderId, Page count,Document Name,Isindex
	   *Return Values     :    String-Status
	  * Author            :    Aseesh
	   *Description       :    This method calls NGOAddDocument API to for adding documents to SMS.
	   */
	
	public static String AddDocument(String strFolderId, int sPage, String sDocName, String sDocSize, String sIsIndex,
			String sExtention, String sDocumentType, File f, IFormReference ifr,Properties p) throws IOException, JPISException {

		WFXmlResponse xmlResponse = null;
		List<List<String>> sessionId = ifr.getDataFromDB(
				"select randomnumber from pdbconnection where userindex = (select userindex from pdbuser where username= '"
						+ ifr.getUserName() + "' )");
		mRepLogger.info(
				"strFolderId, sPage, sDocName, sDocSize, sIsIndex, sExtention, sDocumentType, file at changeFolderProperty in ODDocumentUpload = "
						+ strFolderId + ", " + sPage + ", " + sDocName + ", " + sDocSize + ", " + sIsIndex + ", "
						+ sExtention + ", " + sDocumentType + ", " + f);
		mRepLogger.info("Session id..." + sessionId);
		String sRetVal = "";
		try {
			String InputXML = "<?xml version='1.0'?><NGOAddDocument_Input><Option>NGOAddDocument</Option><CabinetName>"
					+ ifr.getCabinetName() + "</CabinetName><Password></Password><UserDBId>" + sessionId.get(0).get(0)
					+ "</UserDBId><GroupIndex>0</GroupIndex><Document><ParentFolderIndex>" + strFolderId.trim()
					+ "</ParentFolderIndex><NoOfPages>" + sPage + "</NoOfPages><AccessType>I</AccessType><DocumentName>"
					+ sDocName.trim()
					+ "</DocumentName><CreationDateTime></CreationDateTime><VersionFlag>Y</VersionFlag>"
					+ "<DuplicateName>V</DuplicateName>" + "<DocumentType>" + sDocumentType.trim()
					+ "</DocumentType><DocumentSize>" + sDocSize.trim() + "</DocumentSize><CreatedByAppName>"
					+ sExtention.trim() + "</CreatedByAppName><ISIndex>" + sIsIndex.trim()
					+ "</ISIndex><ODMADocumentIndex></ODMADocumentIndex>"
					+ "<Comment></Comment><EnableLog>Y</EnableLog><FTSFlag>PP</FTSFlag><Keywords></Keywords>"
					+ "</Document></NGOAddDocument_Input>";
			mRepLogger.info("InputXML at AddDocument in ODDocumentUpload = " + InputXML);
//			InitConfigPropChildWork getConfigProp = new InitConfigPropChildWork();
			mRepLogger.info("Before WFCallBroker call....");
//			mRepLogger.info("ifr.getServerIp().. " + ifr.getServerIp());
//			mRepLogger.info("ifr.getServerPort().. " + ifr.getServerPort());
//			mRepLogger.info("getConfigProp.serverIP().. " + getConfigProp.serverIP());
//			mRepLogger.info("getConfigProp.wrapperPort().. " + getConfigProp.wrapperPort());
			
			mRepLogger.info("WFCallBroker called with below properties ");
			mRepLogger.info("IP : "+p.getProperty("IP")+" , WrapperPort : "+Integer.parseInt(p.getProperty("WrapperPort")));
			
			String OutputXML = WFCallBroker.execute(InputXML, p.getProperty("IP"),
					Integer.parseInt(p.getProperty("WrapperPort")), 0);

			/*
			 * String OutputXML = DMSCallBroker.execute(InputXML.toString(),
			 * ifr.getServerIp().toString(), Integer.parseInt(ifr.getServerPort()) , 1);
			 */

			mRepLogger.info("Output xml ...." + OutputXML);
			// DMSXmlResponse xmlResponse=new DMSXmlResponse(OutputXML);
			xmlResponse = new WFXmlResponse(OutputXML);
			// SuccessLog("Document added successfully = " + f.toString()); sRetVal = new
			sRetVal = xmlResponse.getVal("Status");
			mRepLogger.info("Status " + sRetVal);
			if (sRetVal.equalsIgnoreCase("0")) {
				// f.delete(); // deleting the document after it is added in OD --added on
				// 19-05-20
				String docIndex = xmlResponse.getVal("DocumentIndex");
				String parentFolderIndex = xmlResponse.getVal("ParentFolderIndex");
				mRepLogger.info("DocIndex " + docIndex + " Parent FolderIndex " + parentFolderIndex);
			}
			return xmlResponse.toString();
		} catch (Exception e) {
			mErrLogger.info("xception in add document..." + e.getMessage());
			// e.printStackTrace();
			// sRetVal = "E";
		}

		return (xmlResponse != null ? xmlResponse.toString() : "");
	}
	
	/*
	   *Method Name       :    generateTemplate
	   *Input Parameters  :    Iform Reference, Xml Parser,Template name, Upload Document type
	   *Return Values     :    String-Status
	  * Author            :    Aseesh
	   *Description       :    This method does the following things
	   						   1) Reads the Template XML file
	   						   2) Computes Template path
	   						   3) Computes Document destination path
	   						   4) Validate Template XML data
	   */

	public String generateTemplate(IFormReference ifr, XMLParser generalDParser, String templateName, String upldDocType) {

		mRepLogger.info("Inside GenerateTemplate function...");

		pID = (String) ifr.getValue("pInstanceID");
		mRepLogger.info("PID ---> " + pID);
		// writeToDocumentLog(XML_LOG, "Inside generateTemplate()...");
		String processName = "";
		String templatePath = "";
		String destinationPath = "";
		String documentName = "";
		ReadXmlData readxmldata = null;
		String extTblName = "";
		ArrayList arrExtlist = null;
		boolean readstatus = false;
		boolean bReturn = false;
		try {
			processName = ifr.getProcessName();
			mRepLogger.info("Process -->" + processName);

			try {
				readCabProperty(templateName, processName);
				documentName = (String) currentServiceProperty.get("DOCUMENTNAME");
				templateName = (String) currentServiceProperty.get("XMLFILENAME");
				// viewer = (String) currentServiceProperty.get("VIEWER");
				extTblName = (String) currentServiceProperty.get("EXTTABLENAME");
				mRepLogger.info("documentname from INI -->" + documentName + ":template name from INI -->"
						+ templateName + ":extTblName from INI -->" + extTblName);

				templatePath = System.getProperty("user.dir") + System.getProperty("file.separator")
						+ "TemplateGeneration" + System.getProperty("file.separator") + "preGeneratedtemplates"
						+ System.getProperty("file.separator") + processName + System.getProperty("file.separator") + documentName + "." + "docx";
				mRepLogger.info("template path ----- -->" + templatePath);

				destinationPath = System.getProperty("user.dir") + System.getProperty("file.separator")
						+ "TemplateGeneration" + System.getProperty("file.separator") + "generatedTemplates"
						+ System.getProperty("file.separator") + pID;
				mRepLogger.info("destination generated path ----- -->" + destinationPath);
				
				//if the docname is null or "" then return, as the document not found.
				if(documentName==null || documentName.trim().equalsIgnoreCase("null") || documentName.trim().equals("")){ 
					mRepLogger.info("Document name is null from the ini file, so returning null.");
					return null;
				}else{ 
					
				File dirpath = new File(destinationPath);
				if (!dirpath.isDirectory()) {
					dirpath.mkdir();
				}
				dirpath = null;
				
				if(upldDocType.toLowerCase().startsWith("demand_letter") || 
						upldDocType.equalsIgnoreCase("intimation_letter") ||
						upldDocType.equalsIgnoreCase("recall_notice")){ 
					documentName=upldDocType;
				}
				destinationPath = System.getProperty("user.dir") + System.getProperty("file.separator")
						+ "TemplateGeneration" + System.getProperty("file.separator") + "generatedTemplates"
						+ System.getProperty("file.separator") + pID + System.getProperty("file.separator")
						+ documentName + "." + "docx";
				mRepLogger.info("destination  path ----- -->" + destinationPath);
				readstatus = true;

				/*
				 * finalPDFPath = System.getProperty("user.dir") +
				 * System.getProperty("file.separator") + "TemplateGeneration" +
				 * System.getProperty("file.separator") + "generatedTemplates" +
				 * System.getProperty("file.separator") + ifr.getValue("PID") +
				 * System.getProperty("file.separator") + documentName + "." + "pdf";
				 * writeToDocumentLog(XML_LOG, "pdf destination  path ----- -->" +
				 * finalPDFPath);
				 */
				
			}

			} catch (Exception exp) {
				readstatus = false;
				mErrLogger.info("Error in reading the Property File :=" + exp);
			}
			
			

			if (readstatus) {
				mRepLogger.info("Inside if");
				try {
					mRepLogger.info("Inside try");
					readxmldata = new ReadXmlData();
					mRepLogger.info("After readxmldata Constructor call");
					arrExtlist = new ArrayList();
					mRepLogger.info("After arrExtList object creation");
					System.out
							.println("Readed Xml contents into ArrayList filepath-->" + (System.getProperty("user.dir")
									+ System.getProperty("file.separator") + "TemplateGeneration"
									+ System.getProperty("file.separator") + "preGeneratedtemplates"
									+ System.getProperty("file.separator") + processName + System.getProperty("file.separator") + templateName + ".xml"));
					if (readxmldata.readData(System.getProperty("user.dir") + System.getProperty("file.separator")
							+ "TemplateGeneration" + System.getProperty("file.separator") + "preGeneratedtemplates"
							+ System.getProperty("file.separator") + processName + System.getProperty("file.separator") + templateName + ".xml")) {

						mRepLogger.info("Readed External table Xml contents into ArrayList");
					}

					arrExtlist = readxmldata.getXmlDataRecords();
					
					boolean extFlag = validateData(ifr, generalDParser, arrExtlist, pID, extTblName);

					bReturn = generateDoc(ht, templatePath, destinationPath, ifr);
					mRepLogger.info("bReturn = " + bReturn);
					if (bReturn) {
						// createPDF(destinationPath, finalPDFPath);
						// convertWordToPdf(destinationPath,pdfdestinationPath);
						mRepLogger.info("Template Generated Successfully = " + bReturn);
						return destinationPath;
					} else {
						mRepLogger.info("Template generation failed");
						destinationPath = "";
					}

				} catch (Exception ex) {
					mErrLogger.info(ex + "Error in reading Xml file" + ex.getMessage());
					destinationPath = "";
					// ex.printStackTrace();
				}
			}

		} catch (Exception exp) {
			mErrLogger.info("exception in catch -->" + exp.getMessage());
			destinationPath = "";
			// exp.printStackTrace();
		} finally {
			try {
				processName = null;
				processName = "";
				templatePath = "";
//				destinationPath = "";
				documentName = "";
				readxmldata = null;
				extTblName = "";
				readstatus = false;
				arrExtlist = null;
			} catch (Exception e) {
				mErrLogger.info("exception in catch -->" + e.getMessage());
				// e.printStackTrace();
			}
		}
		mRepLogger.info("!!!!!....Document generated destination path before return....!!!!!");
		return destinationPath;
	}
	
	/*
	   *Method Name       :    validateData
	   *Input Parameters  :    Iform Reference object,XML parser,Array List of records from Template xml,Winame,Table name
	   *Return Values     :    Boolean
	  * Author            :    Aseesh
	   *Description       :    This method forms a query to fetch data from db to replace in documents.
	   */

	private boolean validateData(IFormReference ifr, XMLParser generalDParser, ArrayList alRecordsValidation,
			String swi_name, String mstTblName) {

		mRepLogger.info("1-->");
		String extName = "";
		String tempName = "";
		String isFormat = "";
		String format = "";
		String sReturnValue = "";
		String sErrorCode = "";
		String QueryResult = "";
		String scolnames = "";
		String Finalcolnames = "";
		String sorgcolnames = "";
		String stempcolnames = "";
		String orgFinalcolnames = "";
		String tempFinalcolnames = "";
		String swiname = "";
		String whereval = "";
		boolean bReturn = false;
		// XMLParser xmlParserobject = null;
		BusinessDataVO dc = null;
		BusinessDataVO df = null;
		BusinessValidation bv = null;
		// String strEngineName = "";
		// String jtsIP = "";
		// String port = "";
		// int jtsPort;

		// strEngineName = ifr.getCabinetName();

		// String cabinetName = strEngineName;

		try {
			// String wi_name = (String) ifr.getValue("PID");
			// String process = ifr.getProcessName();

			mRepLogger.info("2-->");
			bv = new BusinessValidation();
			mRepLogger.info("3-->" + alRecordsValidation);
			df = (BusinessDataVO) alRecordsValidation.get(0);
			swiname = df.getExtName();
			mRepLogger.info("swiname-->  " + swiname);
			mRepLogger.info("4-->");
			for (int i = 0; i < alRecordsValidation.size(); i++) {
				dc = (BusinessDataVO) alRecordsValidation.get(i);
				extName = dc.getExtName();
				mRepLogger.info("extName--> " + extName);
				tempName = dc.getTempName();
				mRepLogger.info("tempName--> " + tempName);
				// isFormat = dc.getIsFormat();
				// format = dc.getFormat();

				sorgcolnames = sorgcolnames.concat(extName).concat(",");
				orgFinalcolnames = sorgcolnames.substring(0, sorgcolnames.lastIndexOf(","));
				mRepLogger.info("orgFinalcolnames--> " + orgFinalcolnames);

				stempcolnames = stempcolnames.concat(tempName).concat(",");
				tempFinalcolnames = stempcolnames.substring(0, stempcolnames.lastIndexOf(","));
				mRepLogger.info("+tempFinalcolnames--> " + tempFinalcolnames);

				// sErrorCode = extName;
				if (extName.equalsIgnoreCase("GETDATE()")) {
					extName = "convert(varchar, " + extName + ", 103) AS SYS_DATE";
					
				} else {
					// Noting
				}
				scolnames = scolnames.concat(extName).concat(",");
				mRepLogger.info("scolnames--> " + scolnames);

			}
			Finalcolnames = scolnames.substring(0, scolnames.lastIndexOf(","));
			mRepLogger.info("Finalcolnames-->" + Finalcolnames);
			whereval = swi_name;

			/*
			 * Added By Toseef---Starts
			 */
			Finalcolnames = "DISTINCT " + Finalcolnames;
			/*
			 * Ends
			 */

			QueryResult = bv.DynamicQuery(Finalcolnames, whereval, "test", mstTblName);

			QueryResult = QueryResult.replaceAll("wi_name", "pInstanceID");

			mRepLogger.info("getNGDataFromDataCache skoutputXml QueryResult := " + QueryResult);

			/*
			 * Code added by Toseef To get result on the basis of Product and for Applicant
			 * Only -----------------------STARTS--------------------------------
			 */

			/*
			 * List<List<String>> output = null;
			 * 
			 * /* ----------------------ENDS----------------------------------
			 */
			List<List<String>> result = ifr.getDataFromDB(QueryResult);
			// List<List<String>> outputXml = null;
			// outputXml = ifr.getDataFromDB(QueryResult);
			mRepLogger.info("getNGDataFromDataCache skoutputXml := " + result);

			// xmlParserobject = new XMLParser();
			// xmlParserobject.setInputXML(outputXml.toString());
			// if (!outputXml.isEmpty()) {
			if (!result.isEmpty()) {
				String arrcol[] = orgFinalcolnames.split(",");
				String arrtempcol[] = tempFinalcolnames.split(",");
				// mRepLogger.info("getNGDataFromDataCache arrcol := " + arrcol);
				// mRepLogger.info(arrcol.toString());
				// mRepLogger.info("getNGDataFromDataCache arrtempcol := " + arrtempcol);
				// mRepLogger.info(arrtempcol.toString());

				for (List<String> viewList : result) {
					for (int i = 0; i < arrcol.length; i++) {

						try {
							mRepLogger.info("Got value	:	" + viewList.get(i));
							if (!viewList.get(i).equalsIgnoreCase("--Select--")) {
								ht.put("" + arrtempcol[i] + "", viewList.get(i));
								mRepLogger.info("put ColumnName" + arrtempcol[i] + "#put value#" + viewList.get(i));
							} else {
								ht.put("" + arrtempcol[i] + "", "");
								mRepLogger.info("Got --Select-- , put ColumnName" + arrtempcol[i] + "#put value#" + "");
							}
						} catch (NullPointerException e) {
							ht.put("" + arrtempcol[i] + "", "");
							mErrLogger.info("Got Null value for Column : " + arrtempcol[i]
									+ " .Replacing it with Blank String");
						} catch (Exception e2) {
							mErrLogger.info("Some Exception Occurred While parsing retrieved DB data from List....."
									+ e2.toString());
						}
					}
					bReturn = true;
				}
			} else {

				mRepLogger.info("getNGDataFromDataCache skoutputXml is emty := " + result);
			}

		} catch (Exception ex) {
			bReturn = false;
			// ex.printStackTrace();
			mErrLogger.info("Error during External table field Validations." + ex.getMessage());
		}
		// mRepLogger.info("Bingo " + ht);
		return bReturn;
	}
	
	/*
	   *Method Name       :    validateData
	   *Input Parameters  :    Hash Map of details,templatePathFilename,outputPath
	   *Return Values     :    Boolean
	  * Author            :    Aseesh
	   *Description       :    This method replaces Document content with Details fetched with data from db.
	   */

	private boolean generateDoc(Map<String, String> ht, String templatePathFilename, String outputPathFilename,
			IFormReference ifr) {
		boolean bReturn = false;
		XWPFDocument xwpfDoc = null;
		try {

			mRepLogger.info("template file path file name in generate doc" + templatePathFilename);

			xwpfDoc = new XWPFDocument(OPCPackage.open(templatePathFilename));
			mRepLogger.info("after open" + xwpfDoc);
			if (ht.isEmpty()) {
				mRepLogger.info("inside if" + ht.size());
				mRepLogger.info("Body text not being changed");
			} else {
				mRepLogger.info("inside else");
				xwpfDoc = ReplaceBodyContent(xwpfDoc, outputPathFilename);

				xwpfDoc = replaceComplexDataContent(xwpfDoc, outputPathFilename, ifr);
				mRepLogger.info("After replaceComplexDataContent call");
				
				int pageCount=
				xwpfDoc.getProperties().getExtendedProperties().getUnderlyingProperties().getPages();
				
				
				mRepLogger.info("<<<<<<<About to start the Linear table data replacement>>>>>>>");
				//Code Added for Replacing Linear Tabular Data
				String LinearData=(String)currentServiceProperty.get("LinearTableData");
				mRepLogger.info("Linear Tables Indexes ::"+LinearData);
				if(LinearData!=null && !LinearData.trim().equals("")){ 
					
					String[] linrArr=LinearData.split(",");
					for(int lt=0;lt<linrArr.length;lt++){ 
						mRepLogger.info("Current Linear Table Index ::"+linrArr[lt]);
						if(linrArr[lt].startsWith("Y"))
						{
							mRepLogger.info("<<<<<<Starts with Y>>>>>>");
							String linearTableIndex=linrArr[lt].split("-")[1];
							xwpfDoc=replaceLinearTabularData(xwpfDoc, outputPathFilename, ifr,linearTableIndex,pageCount);
							mRepLogger.info("Replace Tabular Data Call");
						}
					}
				}

				
				
				
			}

			try {
				xwpfDoc.write(new FileOutputStream(outputPathFilename));
			} catch (FileNotFoundException e) {
				mErrLogger.info("--------------------->>>>>>>>>.catch exception in generate doc file not founf"
						+ e.getMessage());
				// TODO Auto-generated catch block
				// e.printStackTrace();
			} catch (IOException e) {
				mErrLogger.info("--------------------->>>>>>>>>.catch exception in generate doc  io" + e.getMessage());
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
			mRepLogger.info("output path file name in generate doc" + outputPathFilename);
			bReturn = true;
		} catch (Exception ex) {
			mErrLogger.info("--------------------->>>>>>>>>.catch exception in generate doc" + ex.getMessage());
			// ex.printStackTrace();
		}
		return bReturn;
	}
	
	/*
	   *Method Name       :    ReplaceBodyContent
	   *Input Parameters  :    XWPFDocument- doc object,outputPathFilename
	   *Return Values     :    XWPFDocument
	  * Author            :    Aseesh
	   *Description       :    This method replaces Document body content with Details fetched with data from db.
	   */

	public XWPFDocument ReplaceBodyContent(XWPFDocument doc, String outputPathFilename) {
		// Replace free texts
		List<XWPFRun> runs = null;
		String text = "";
		try {
			// doc.getHeaderArray(0).getParagraphs().get(0);
			mRepLogger.info("inside replase body::"+ht);

			for (XWPFParagraph p : doc.getParagraphs()) {
				mRepLogger.info("inside for loopS");
				p.getParagraphText();
				p.getText();
				mRepLogger.info("p.getParagraphText().... " + p.getParagraphText());
				mRepLogger.info("p.getText().... " + p.getText());
				runs = p.getRuns();

				if (runs != null) {
					for (XWPFRun r : runs) {
//						mRepLogger.info("runs  " + runs);
						text = r.getText(0);
						if (text == null || text.trim() == "")
							continue;
//						mRepLogger.info("text...  " + text);
						for (String key : ht.keySet()) {
//							mRepLogger.info("key  " + key);

							if (text != null && (text.contains(key))) {

//								mRepLogger.info("text  " + text);
//								mRepLogger.info("key text---  " + ht.get(key));
								
//								mRepLogger.info("Flags" + key.contains("##")+","+(ht.get(key)!=null)+","+(ht.get(key).contains("##")));
								if(ht.get(key)!=null && ht.get(key).contains("~")){ 
//									mRepLogger.info("final content contains ##::");
									String[] finalContent=ht.get(key).split("~");
									for(int k=0;k<finalContent.length;k++){ 
										String fc=finalContent[k];
										
										if(Character.toString(key.charAt(key.length()-1)).equals(fc.split("##")[0])){ 
											String removingChar=fc.replace("##","");
											if(removingChar.contains("A01") || removingChar.contains("C01") || removingChar.contains("C02") || removingChar.contains("C03") || removingChar.contains("C04") || removingChar.contains("C05") || removingChar.contains("G01")){ 
												removingChar=removingChar.substring(5);
											}
											text = text.replace(key, removingChar);
											r.setText(text,0);
										}
										
									}
								}else{ 
//									mRepLogger.info("final content doesnot contains ##::");
									text = text.replace(key, ht.get(key));
									// Add convert to word
									r.setText(text, 0);
								}
								/*String[] finalContent=ht.get(key).split("##NL##");
								if(finalContent.length>1){ 
									mRepLogger.info("final content contains \n::");
									
									for(int k=0;k<finalContent.length;k++){ 
										String fc=finalContent[k];
										text = text.replace(key, fc);
										r.setText(text,0);
										r.addBreak();
									}
								}else{ 
									mRepLogger.info("final content doesnot contains \n::");
									text = text.replace(key, ht.get(key));
									// Add convert to word
									r.setText(text, 0);
								}*/
								continue;
							}

						}
					}
				}
			}
		} catch (Exception e) {
			mErrLogger.info("paragraph error" + e.getMessage());
			// e.printStackTrace();
		}
		/*
		 * runs = null; text = "";
		 */

		// Replace text formated with some tables
		try {
			for (XWPFTable tbl : doc.getTables()) {
				mRepLogger.info("Replacing text in table format");
				// wFLogger.writeXML("Replacing text in table format");
				// textReplaceintable(ht, tbl);
			}
		} catch (Exception e) {
			mErrLogger.info("table error temp" + e.getMessage());
			// e.printStackTrace();
		}

		// Replace text in Header table
		/*
		 * try { //XWPFHeader header = doc.getHeaderArray(1);
		 * 
		 * 
		 * XWPFHeaderFooterPolicy policy= doc.getHeaderFooterPolicy(); XWPFHeader header
		 * = policy.getFirstPageHeader(); XWPFHeader header2 = policy.getHeader(1);
		 * writeToDocumentLog(XML_LOG, "header...!!!! " + header);
		 * writeToDocumentLog(XML_LOG, "header2...!!!! " + header2);
		 * writeToDocumentLog(XML_LOG, "header.getText()...!!!! " + header.getText());
		 * 
		 * for (XWPFTable tbl : header.getTables()) { writeToDocumentLog(XML_LOG,
		 * "header.getTable()..tbl.!!!! " + tbl); writeToDocumentLog(XML_LOG,
		 * "Replacing text in header table format"); //
		 * wFLogger.writeXML("Replacing text in table format"); textReplaceintable(ht,
		 * tbl); } } catch (Exception e) { writeToDocumentLog(XML_LOG,
		 * "table error temp" + e.toString()); e.printStackTrace(); }
		 */
		return doc;

	}
	
	/*
	   *Method Name       :    replaceComplexDataContent
	   *Input Parameters  :    XWPFDocument- doc object,outputPathFilename,Iform Reference object
	   *Return Values     :    XWPFDocument
	  * Author            :    Aseesh
	   *Description       :    This method adds tabular data fetched from db to documents.
	   */

	private XWPFDocument replaceComplexDataContent(XWPFDocument doc, String outputPathFilename, IFormReference ifr) {

		try {
			String TABLEIDVIEW = (String) currentServiceProperty.get("TABLEIDVIEW");
			String tableViewColumns = (String) currentServiceProperty.get("TABLEVIEWCOLUMNS");
			mRepLogger.info("TABLEIDVIEW...:..: " + TABLEIDVIEW);
			
			//getting the document name from the path to identify the complex data.
			String s=outputPathFilename;
			s=s.substring(s.lastIndexOf("\\")+1,s.lastIndexOf("."));
			
			if (TABLEIDVIEW != null) {
				String[] tableIdViewPair = TABLEIDVIEW.split(",");

				for (int i = 0; i < tableIdViewPair.length; i++) {
					mRepLogger.info("tableIdViewPair...: " + tableIdViewPair[i]);
					String tableId = tableIdViewPair[i].split("-")[0];
					String viewName = tableIdViewPair[i].split("-")[1];
					String viewColumns = tableViewColumns.split("#")[i];
					mRepLogger.info("tableId...:..: " + tableId);
					mRepLogger.info("viewName...:..: " + viewName);

					List<List<String>> viewDataList = getViewData(viewName, ifr, viewColumns);
					addTableEntryCard(doc, tableId, viewDataList, viewColumns,s);

				}
			}
		} catch (Exception e) {
			mErrLogger.info("Inside catch replaceComplexDataContent..." + e.getMessage());
			// e.printStackTrace();
		}
		return doc;

	}
	
	/*
	   *Method Name       :    replaceLinearTabularData
	   *Input Parameters  :    XWPFDocument- doc object,outputPathFilename,Iform Reference object
	   *Return Values     :    XWPFDocument
	  * Author            :    Aseesh
	   *Description       :    This method replaces linear Tabular data fetched from db in Documents.
	   */
	
	private XWPFDocument replaceLinearTabularData(XWPFDocument doc, String outputPathFilename, IFormReference ifr,
			String TABLEID, int pgcount) {

		String Text = "";
		// String TABLEID = (String)
		// currentServiceProperty.get("LinearTableData");
		// mRepLogger.info("TableID " +TABLEID);
		// TABLEID=TABLEID.split("-")[1];
		mRepLogger.info("TableID ::" + TABLEID + ", NO PAGES ::" + pgcount);
		List<XWPFTable> tables = doc.getTables();
		XWPFTable tableOne = tables.get(Integer.parseInt(TABLEID));
		List<XWPFTableRow> tableRows = tableOne.getRows();
		// System.out.println("Table Rows: "+tableRows.toString());
		for (int j = 0; j < tableRows.size(); j++) {
			XWPFTableRow tableRow = tableRows.get(j);
			List<XWPFTableCell> Tablecells = tableRow.getTableCells();
			for (int i = 0; i < Tablecells.size(); i++) {
				XWPFTableCell Tablecell = Tablecells.get(i);
				Text = Tablecell.getText();
				if (Text.contains("PGCOUNT")) {
					Tablecell.removeParagraph(0);
					Tablecell.setText(Integer.toString(pgcount));
					
				}else{ 
					for (String key : ht.keySet()) {
//						mRepLogger.info("key  " + key);
						 if (Text != null && (Text.contains(key))) {
							Tablecell.removeParagraph(0);
							Tablecell.setText(ht.get(key));
							continue;
						}
					}
				}

			}
		}

		return doc;
	}
	
	/*
	   *Method Name       :    getViewData
	   *Input Parameters  :    Viewname,Iform Reference object,View Columns
	   *Return Values     :    List<List<String>>
	  * Author            :    Aseesh
	   *Description       :    This method fetches data from view configured for tabular document data.
	   */

	private List<List<String>> getViewData(String viewName, IFormReference ifr, String viewColumns) {

		List<List<String>> result = null;
		try {
			String viewNameOnly = viewName.split("#")[0];
			// String isSerialNo = viewName.split("#")[1];
			// String tableViewColumns = (String)
			// currentServiceProperty.get("TABLEVIEWCOLUMNS");
			mRepLogger.info("viewColumns...: " + viewColumns);
			String query = "";
			if(viewName!=null && viewName.equalsIgnoreCase("NG_COLL_SOA_CMPLX_DATA")){ 
				query = "select " + viewColumns + " from " + viewNameOnly + " where pInstanceID = '"
						+ ifr.getValue("pInstanceID").toString() + "' order by convert(DATE,TRANSDATE, 103) ASC";
			}else{ 
				query = "select " + viewColumns + " from " + viewNameOnly + " where pInstanceID = '"
						+ ifr.getValue("pInstanceID").toString() + "'";
			}
			
			mRepLogger.info("Query getViewData...: " + query);
			result = ifr.getDataFromDB(query);
			mRepLogger.info("Result getViewData...: " + result);
		} catch (Exception e) {
			mErrLogger.info("Inside catch getViewData..." + e.getMessage());
			// e.printStackTrace();
		}

		return result;

	}
	
	/*
	   *Method Name       :    addTableEntryCard
	   *Input Parameters  :    XWPFDocument- doc object,tableID,ViewData
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method Adds tabular add to tables in Document Templates.Multiple rows of data can be added to a table
	   */

	private void addTableEntryCard(XWPFDocument doc, String tableId, List<List<String>> viewDataList,
			String viewColumns,String docName) {
		Properties sp=getServiceProperties();
		try {
			int iFontsize=12;
			String fontFamily = "Arial";
			List<XWPFTable> tables = doc.getTables();
			XWPFTable tableOne = tables.get(Integer.parseInt(tableId));
			List<XWPFTableRow> tableRows = tableOne.getRows();
			XWPFTableRow tableRow = tableRows.get(0);
			// XWPFTableCell tableRowNew = tableRows.get(0);
			
			if(docName!=null && docName.equalsIgnoreCase("soa") && tableId.equals("3")){ 
				mRepLogger.info("Inside the SOA table, so considering the 2nd row");
				tableRow = tableRows.get(1);
			}
			
			int NoOfColumn = tableRow.getTableCells().size();
			mRepLogger.info("table11...." + tableRow.getCell(0).getText());
			List<XWPFTableCell> tableCells = tableRow.getTableCells();
			mRepLogger.info("List of tableCells...: " + tableCells);
			mRepLogger.info("Number of columns...: " + NoOfColumn);
			
			XWPFParagraph p1 = tableCells.get(0).getParagraphs().get(0);
			for (XWPFRun r : p1.getRuns()) {
				mRepLogger.info("r.getText...." + r.getText(0));
				r.setBold(false);
				iFontsize = r.getFontSize();
				fontFamily = r.getFontFamily();
				mRepLogger.info("Font SIze...: " + iFontsize);
				mRepLogger.info("Font family...: " + fontFamily);

			}

			for (int i = 0; i < viewDataList.size(); i++) {
				XWPFTableRow tableOneRowTwo = tableOne.createRow();
				
				//adding 3 extra cells as the SOA has 3 extra cells which is not recognised by the xwpfdocument.
				if(docName!=null && docName.equalsIgnoreCase("soa") && tableId.equals("3")){ 
					tableOneRowTwo.addNewTableCell();
					tableOneRowTwo.addNewTableCell();
					tableOneRowTwo.addNewTableCell();
					fontFamily = sp.getProperty("SOAGridFontName");
					iFontsize = Integer.parseInt(sp.getProperty("SOAGridFontSize"));
				}
				
				List<String> tableValueArray = viewDataList.get(i);
				mRepLogger.info("tableValueArray... " + tableValueArray);
				mRepLogger.info("tableValueArray size... " + tableValueArray.size());
				for (int k = 0; k < tableValueArray.size(); k++) {
					mRepLogger.info("inside for loopS tableValueArray...."+k);
					XWPFTableCell cell = tableOneRowTwo.getCell(k);
					
					XWPFParagraph p = cell.getParagraphs().get(0);
					XWPFRun r = p.createRun();

					r.setFontSize(iFontsize);
					r.setFontFamily(fontFamily);
					r.setText(tableValueArray.get(k));
					mRepLogger.info("Run after setText.... " + r);
					p.setSpacingAfter(0);
				}
			}

		} catch (Exception e) {
			mErrLogger.info("Exception... " + e.getMessage());
			mErrLogger.info("",e);
			// e.printStackTrace();
		}

	}
	
	/*
	   *Method Name       :    repoQuotationDetailsAutoPopulate
	   *Input Parameters  :    IformReference ifr
	   *Return Values     :    String -Result
	  * Author            :    Aseesh
	   *Description       :    This method checks the Recommended flag in RepoQuotationDetailsGrid.Returns "" if there is no Recommended quotation.
	   */

	public String repoQuotationDetailsAutoPopulate(IFormReference ifr) {
		mRepLogger.info("Inside repoQuotationDetailsAutoPopulate");
		JSONArray quotationGrid = ifr.getDataFromGrid("RepoQuotationDetailsGrid");
		String result = "";
		if (quotationGrid != null) {
			for (int i = 0; i < quotationGrid.size(); i++) {
				JSONObject obj = (JSONObject) quotationGrid.get(i);
				if (obj.get("Recommended (Flag)").toString().equalsIgnoreCase("Yes")) {
					mRepLogger.info("Recommended object found-->" + obj);
					result = obj.toString();
//					String qa;
//					if(obj.get("Quote Amount").equals("") || obj.get("Quote Amount") == null) {
//						qa = "0";
//					}else {
//						qa = obj.get("Quote Amount").toString();
//					}
//					ifr.setValue("q_Repo_QD_Quotation_Details_Final_Resale_Amount", qa);
//					String pn;
//					if(obj.get("Purchaser Name").equals("") || obj.get("Purchaser Name") == null) {
//						pn = "";
//					}else {
//						pn =obj.get("Purchaser Name").toString();
//					}
//					ifr.setValue("q_Repo_QD_Quotation_Details_Authorized_By_Buyer",pn);
//					String mn;
//					if(obj.get("Mobile Number").equals("") || obj.get("Mobile Number") == null) {
//						mn = "";
//					}else {
//						mn =obj.get("Mobile Number").toString();
//					}
//					ifr.setValue("q_Repo_QD_Quotation_Details_Authorised_Buyer_Mobile_Number",mn);
//					String ad;
//					if(obj.get("Address").equals("") || obj.get("Address") == null) {
//						ad = "";
//					}else {
//						ad =obj.get("Address").toString();
//					}
//					ifr.setValue("q_Repo_QD_Quotation_Details_Authorized_Buyer_address", ad);
				}
			}
		}

//		String query = "select L_GK_Total_Os from NG_DUMP_LOAN_DET where L_ACCT_NO = '"
//				+ ifr.getValue("Loan_Account_No").toString() + "'";
//		mRepLogger.info("Executing query-->" + query);
//		List<List<String>> opt = ifr.getDataFromDB(query);
//		if (opt != null && opt.size() > 0) {
//			ifr.setValue("q_Repo_QD_Quotation_Details_Total_Outstanding", opt.get(0).get(0));
//		}
//
//		String fra = ifr.getValue("q_Repo_QD_Quotation_Details_Final_Resale_Amount").toString();
//		String tos = ifr.getValue("q_Repo_QD_Quotation_Details_Total_Outstanding").toString();
//		Float amount;
//		if (tos == null || tos.equals("")) {
//			tos = "0";
//		}
//		if (fra == null || fra.equals("")) {
//			fra = "0";
//		}
//		amount = Float.parseFloat(tos) - Float.parseFloat(fra);
//		ifr.setValue("q_Repo_QD_Quotation_Details_Shortfall_Amount", amount.toString());
//		amount = amount * -1;
//		ifr.setValue("q_Repo_QD_Quotation_Details_POS_loss_amount_and", amount.toString());
//		if (amount > 0) {
//			Float posprecentage = ((Float.parseFloat(fra) - amount) / amount) * 100;
//			ifr.setValue("Total_Principal_Outstanding", posprecentage.toString());
//		}
		
		return result;

	}
	
	/*
	   *Method Name       :    readCabProperty
	   *Input Parameters  :    Document Template Name,Process Name
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method loads details related to Templates like 1) Document Name of template
	   *																		   2) XMLfile Name of Template
	   *																		   3) ExtTable/ViewName
	   *																		   4) Viewer Name
	                           into hash map. This hash map is used to retrive data throughout the document Generation Process
	   */

	public void readCabProperty(String sectionName, String processName) {
		currentServiceProperty.clear();
		String INI = System.getProperty("user.dir") + System.getProperty("file.separator") + "TemplateGeneration"
				+ System.getProperty("file.separator") + "preGeneratedtemplates" + System.getProperty("file.separator")
				+ processName + ".ini";

		mRepLogger.info("INI---- " + INI);
		mRepLogger.info("sectionName---- " + sectionName);
		String line = "";
		String sSection = "";
		String temp = "";
		RandomAccessFile raf = null;
		try {
			raf = new RandomAccessFile(INI, "rw");
			for (line = raf.readLine(); line != null; line = raf.readLine()) {
				if (line.equalsIgnoreCase("")) {
					continue;
				}
				line = line.trim();
//				mRepLogger.info(line);
				if ((line.charAt(0) != '[') || (line.charAt(line.length() - 1) != ']')
						|| (!line.substring(1, line.length() - 1).equalsIgnoreCase(sectionName))) {
//					mRepLogger.info("Inside if 1");
					continue;
				}
				sSection = line.substring(1, line.length() - 1);
//				mRepLogger.info("sSection " + sSection);

				if (!sSection.equalsIgnoreCase(sectionName)) {
//					mRepLogger.info("Inside if 2");
					continue;

				}
				sSection = "";
				for (line = raf.readLine(); line != null; line = raf.readLine()) {
					if (line.equalsIgnoreCase("")) {
//						mRepLogger.info("Inside if 3");
						continue;
					}
					line = line.trim();
					if (line.charAt(0) == '[') {
//						mRepLogger.info("Inside if 4");
						break;
					}
					int i = line.indexOf('=');

					temp = line.substring(0, i);
//					mRepLogger.info("temp: " + temp);
//					mRepLogger.info("line substring " + line.substring(i + 1));

					currentServiceProperty.put(temp.trim(), line.substring(i + 1));
					temp = "";
				}
				break;
			}
			if (raf != null) {
				raf.close();
			}
			mRepLogger.info("Map " + currentServiceProperty);
		} catch (Exception e) {
			mErrLogger.info("ReadPRoperty Exception in main try" + e.getMessage());
			// e.printStackTrace();
			// raf = null;
			line = "";
			sSection = "";
			temp = "";
		} finally {

			try {
				if (raf != null) {
					raf.close();
				}

				line = "";
				sSection = "";
				temp = "";
			} catch (Exception e) {
				mErrLogger.info("ReadPRoperty Exception in finally " + e.getMessage());
				// e.printStackTrace();
			}

		}
	}
	/*
	   *Method Name       :    onformLoadHandler_OutDocument_CAGL
	   *Input Parameters  :    IformReference ifr,Activity Name
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method populates details like Document Name, Generated Date,Sent Date,Acknowledge Date,Return Date,Return Status into Outward_Document_ListView if documents are generated for that loan Number. Else list of Documents based on Activity are loaded into the listview.
	   */

	public String onformLoadHandler_OutDocument_CAGL(IFormReference ifr, String control, String event, String value,
			String Activity_Name) {

		mRepLogger.info("Inside onformLoadHandler_OutDocument_CAGL function");
		Properties p=getCommonProperties();
		String rowsToDisable="";
		try {
			
			/*SimpleDateFormat sdf1=new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
			
			SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MM-dd");*/
			
			
			String loanNo = ifr.getValue("Loan_Account_No").toString();
			
			ifr.clearTable("Outward_Document_ListView");
			
			String cmplxQry="SELECT Document_Name,Generated_Date, Sent_Date, Acknowledge_Date, Return_Date, Return_Status, DocIndex, From_Date, To_Date FROM "
					+ "ng_cmplx_outward_document_Details WITH(NOLOCK) WHERE Loan_Acct_No='"+loanNo+"'";
			
			List<List<String>> cmplxData=ifr.getDataFromDB(cmplxQry);
		
			if(cmplxData.size()>0){ 
				String sQueryDD = p.getProperty("OutwardDocsProductWise1").replace("##ActivityName##", Activity_Name);
				mRepLogger.info("query to get the docs from master ::"+sQueryDD);
				List<List<String>> sQueryDDData=ifr.getDataFromDB(sQueryDD);
				mRepLogger.info("data returned for docs from master ::"+sQueryDDData);
				
				JSONArray jarray=new JSONArray();
				
				for(int i=0;i<sQueryDDData.size();i++){

					String docName=sQueryDDData.get(i).get(0);
					docName=(docName!=null) ? docName : "";
					
					boolean b=false;
					
					for(int j=0;j<cmplxData.size();j++){ 
						
						String cmplxDName=cmplxData.get(j).get(0);
						
						cmplxDName=(cmplxDName!=null) ? cmplxDName : "";
						
						if(cmplxDName.equalsIgnoreCase(docName)){ 
							
							b=true;
							
							JSONObject jobj=new JSONObject();
							
							jobj.put("Document Name", (cmplxData.get(j).get(0)!=null ? cmplxData.get(j).get(0) : ""));
							
							jobj.put("Generate","Generate");
							
							jobj.put("View","View");
							mRepLogger.info("GenDate==>"+cmplxData.get(j).get(1));
							jobj.put("Generated Date", ((cmplxData.get(j).get(1)!=null && !cmplxData.get(j).get(1).trim().equals("")) ? new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(parseDate(cmplxData.get(j).get(1),true)) : ""));
							mRepLogger.info("SentDate==>"+cmplxData.get(j).get(2));
							jobj.put("Sent Date", ((cmplxData.get(j).get(2)!=null && !cmplxData.get(j).get(2).trim().equals("")) ? new SimpleDateFormat("dd/MM/yyyy").format(parseDate(cmplxData.get(j).get(2),false)) : ""));
							mRepLogger.info("AckDate==>"+cmplxData.get(j).get(3));
							jobj.put("Acknowledge Date", ((cmplxData.get(j).get(3)!=null && !cmplxData.get(j).get(3).trim().equals("")) ? new SimpleDateFormat("dd/MM/yyyy").format(parseDate(cmplxData.get(j).get(3),false)) : ""));
							mRepLogger.info("RetDate==>"+cmplxData.get(j).get(4));
							jobj.put("Return Date", ((cmplxData.get(j).get(4)!=null && !cmplxData.get(j).get(4).trim().equals("")) ? new SimpleDateFormat("dd/MM/yyyy").format(parseDate(cmplxData.get(j).get(4),false)) : ""));
							
							jobj.put("Return Status", (cmplxData.get(j).get(5)!=null ? cmplxData.get(j).get(5) : ""));
							
							jobj.put("DocIndex", (cmplxData.get(j).get(6)!=null ? cmplxData.get(j).get(6) : ""));
							
							mRepLogger.info("FrmDate==>"+cmplxData.get(j).get(7));
							jobj.put("From Date", ((cmplxData.get(j).get(7)!=null && !cmplxData.get(j).get(7).trim().equals("")) ? new SimpleDateFormat("dd/MM/yyyy").format(parseDate(cmplxData.get(j).get(7),false)) : ""));
							mRepLogger.info("ToDate==>"+cmplxData.get(j).get(8));
							jobj.put("To Date", ((cmplxData.get(j).get(8)!=null && !cmplxData.get(j).get(8).trim().equals("")) ? new SimpleDateFormat("dd/MM/yyyy").format(parseDate(cmplxData.get(j).get(8),false)) : ""));
							
							jarray.add(jobj);
							
							break;
						}
					}
					
					if(!b){ 
						
						JSONObject jobj=new JSONObject();
						jobj.put("Document Name", docName);
						jobj.put("Generate","Generate");
						jobj.put("View","View");
						jobj.put("Generated Date", "");
						jobj.put("Sent Date", "");
						jobj.put("Acknowledge Date", "");
						jobj.put("Return Date", "");
						jobj.put("Return Status", "");
						jobj.put("DocIndex", "");
						jobj.put("From Date", "");
						jobj.put("To Date", "");
						jarray.add(jobj);
					}
					
					
				}
				
				ifr.addDataToGrid("Outward_Document_ListView", jarray);
				if(sQueryDDData.size()>0){ 
					rowsToDisable=enableOrDisableOutDocBasedOnProd(sQueryDDData,1);
				} 
				
			}else{ 
				
				String sQueryDD = p.getProperty("OutwardDocsProductWise2").replace("##ActivityName##", Activity_Name);
				mRepLogger.info("Query for Document Grid on doc tab click " + sQueryDD);
//				populateListView("Document Name,Generate,View", sQueryDD, "Outward_Document_ListView", ifr);
				
				List<List<String>> data=ifr.getDataFromDB(sQueryDD);
				populateListViewDocument("Document Name,Generate,View", data, "Outward_Document_ListView", ifr);
				if(data.size()>0){ 
					rowsToDisable=enableOrDisableOutDocBasedOnProd(data,3);
				}
				
			}
			
		} catch (Exception e) {
			mErrLogger.info("Error in populating the outward document grid with the data :"+e.getMessage());
		}finally{ 
			
			setSanctionAmount();
		}
		
		return rowsToDisable;
	}
	
	
	public String enableOrDisableOutDocBasedOnProd(List<List<String>> d,int prodCol){ 
		mRepLogger.info("<<<<<<<<<Inside enabling & disabling the outward document rows based on the product>>>>>>>");
		String rows="";
		String currProdType=ifr.getValue("Product_Name").toString();
		
		JSONArray jarr=ifr.getDataFromGrid("Outward_Document_ListView");
		for(int i=0;i<jarr.size();i++){ 
			
			JSONObject jobjRow=(JSONObject) jarr.get(i);
			String currD=(String) jobjRow.get("Document Name");
//			mRepLogger.info("jobj row ="+i+"=>"+jarr);
//			mRepLogger.info("docname==>"+currD);
			
			//looping through the data & making the row disable.
			for(int j=0;j<d.size();j++){ 
				List<String> lRow=d.get(j);
				String doc=lRow.get(0);
				String prods=lRow.get(prodCol);
				if(doc.equalsIgnoreCase(currD) && prods!=null && !prods.trim().equals("")){ 
					String[] prodArr=prods.split(",");
					if(!currProdType.equalsIgnoreCase("Grameen Vaahan Loan") && !Arrays.asList(prodArr).contains(currProdType)){ 
						rows=rows+i+",";
					}else if(currProdType.equalsIgnoreCase("Grameen Vaahan Loan") && !Arrays.asList(prodArr).contains("Grameen Vaahan-New Loan")){ 
						rows=rows+i+",";
					}
					break;
				}
			}
			
		}
		if(rows.endsWith(",")){ 
			
			rows=rows.substring(0, rows.length()-1);
		}
		mRepLogger.info("Final Rows to disable:::"+rows);
		
		return rows;
	}
	
	/*
	   *Method Name       :    getAddrForPickupMeeting
	   *Input Parameters  :    IformReference ifr,Loan Number
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method computes address of Applicant by checking in ng_cmplx_address_updation for latest address. If the data is not available then address is fetched from the Dump table based on loan number. Address is auto populated in Address if Meeting Field.
	   */

	public String getAddrForPickupMeeting(IFormReference ifr, String loanNo) {

		String addr = "";
		String query = "SELECT TOP 1 Line1, Line2, Line3, Area, CityTown,Pincode, State, Country "
				+ "FROM ng_cmplx_address_updation WITH(NOLOCK) WHERE pid IN (SELECT PID FROM EXT_Collection WITH(NOLOCK) "
				+ "WHERE Loan_Account_No='" + loanNo + "') AND date_Time is NOT NULL ORDER BY date_Time DESC";
		mRepLogger.info("Executing query for any updated address-->" + query);
		List<List<String>> output;
		output = ifr.getDataFromDB(query);
		mRepLogger.info("Query opt-->" + output);
		if (output != null && output.size() > 0) {
			for (int i = 0; i < output.size(); i++) {
				for (int j = 0; j < output.get(i).size(); j++) {
					if (output.get(i).get(j) != null && !output.get(i).get(j).equals("")) {
						addr += output.get(i).get(j) + ",";
					}
				}

			}
		} else {

			query = "SELECT TOP 1 L_GK_Line_1, L_GK_Line_2, L_GK_Line_3, L_GK_Landmark, L_GK_Pincode, L_GK_Area, L_GK_City, L_GK_State, "
					+ "L_GK_Country FROM NG_DUMP_ADDRESS WITH(NOLOCK) WHERE L_ACCT_NO='" + loanNo
					+ "' AND L_App_Type='Applicant' " + "AND L_GK_ADDR_TYPE='Present'";
			mRepLogger.info("Executing query present address-->" + query);
			output = ifr.getDataFromDB(query);
			mRepLogger.info("Query opt-->" + output);
			if (output != null && output.size() > 0) {
				for (int i = 0; i < output.size(); i++) {
					for (int j = 0; j < output.get(i).size(); j++) {
						if (output.get(i).get(j) != null && !output.get(i).get(j).equals("")) {
							addr += output.get(i).get(j) + ",";
						}
					}

				}
			}else{ 
				
				query = "SELECT TOP 1 L_GK_Line_1, L_GK_Line_2, L_GK_Line_3, L_GK_Landmark, L_GK_Pincode, L_GK_Area, L_GK_City, L_GK_State, "
						+ "L_GK_Country FROM NG_DUMP_ADDRESS WITH(NOLOCK) WHERE L_ACCT_NO='" + loanNo
						+ "' AND L_App_Type='Applicant' " + "AND L_GK_ADDR_TYPE='PERMANENT'";
				mRepLogger.info("Executing query permanent address-->" + query);
				output = ifr.getDataFromDB(query);
				mRepLogger.info("Query opt-->" + output);
				if (output != null && output.size() > 0) {
					for (int i = 0; i < output.size(); i++) {
						for (int j = 0; j < output.get(i).size(); j++) {
							if (output.get(i).get(j) != null && !output.get(i).get(j).equals("")) {
								addr += output.get(i).get(j) + ",";
							}
						}

					}
				}
			}
		}

		if (addr.endsWith(",")) {
			addr = addr.substring(0, addr.length() - 1);
		}
		return addr;
	}
	
	/*
	   *Method Name       :    updateRepo
	   *Input Parameters  :    String -Repo Flag
	   *Return Values     :    String -Statusmsg
	  * Author            :    Aseesh
	   *Description       :    This method triggers the integration services and updates the repo status based on current status.
	   */

	public String updateRepo(String flagType) {

		String statusMsg = (flagType.equals("1")) ? "Repo Marked in T24 Successfully."
				: "Repo Release updated in T24 successfully";
		String pid = ifr.getValue("pInstanceID").toString();
		String loanNo = ifr.getValue("Loan_Account_No").toString();
		CollectionCommonServices cs = new CollectionCommonServices(ifr);

		String respFlag = cs.triggerFlaggingAndUnFlagging(flagType, pid, loanNo);
		if (!respFlag.equalsIgnoreCase("success")) {
			if (respFlag.contains("~~")) {
				statusMsg = respFlag.split("~~")[1];
			} else {
				if (flagType.equals("1")) {
					statusMsg = "Issue in marking Repo in T24. Please try after sometime.";
				} else if (flagType.equals("2")) {
					statusMsg = "Issue in marking Release in T24. Please try after sometime.";
				}
			}

		}

		return statusMsg;
	}
	/*
	   *Method Name       :    fetchRepaySchedule
	   *Input Parameters  :    NA
	   *Return Values     :    String -Statusmsg
	  * Author            :    Aseesh
	   *Description       :    This method triggers the integration services for fetching the repayment schedule based on loan number .
	   */
	
	public String fetchRepaySchedule() {

		String statusMsg = "";
		String pid = ifr.getValue("pInstanceID").toString();
		String loanNo = ifr.getValue("Loan_Account_No").toString();
		CollectionCommonServices cs = new CollectionCommonServices(ifr);

		String respFlag = cs.fetchRepaymentSchedule(pid, loanNo);
		if (!respFlag.startsWith("SUCCESS")) {
			if (respFlag.contains("~~")) {
				statusMsg = respFlag.split("~~")[1];
			} else {
				statusMsg = "Issue in fetching Repayment Schedule. Please try after sometime.";
//				if (flagType.equals("1")) {
//					statusMsg = "Issue in marking Repo in T24. Please try after sometime.";
//				} else if (flagType.equals("2")) {
//					statusMsg = "Issue in marking Release in T24. Please try after sometime.";
//				}
			}

		}else if(respFlag.startsWith("SUCCESS")){ 
			
			if(Integer.parseInt(respFlag.split("~~")[1])>0){ 
				
				statusMsg = "Repayment Schedule fetched successfully";
			}else{ 
				
				statusMsg = "No Records available for the current loan";
			}
		}

		return statusMsg;
	}
	/*
	   *Method Name       :    fetchPreClosure
	   *Input Parameters  :    NA
	   *Return Values     :    String -Statusmsg
	  * Author            :    Aseesh
	   *Description       :    This method triggers the integration services fetching pre-closure enquiry details based on loan number .
	   */

	public String fetchPreClosure(){ 
		
		String statusMsg = "";
		String pid = ifr.getValue("pInstanceID").toString();
		String loanNo = ifr.getValue("Loan_Account_No").toString();
		CollectionCommonServices cs = new CollectionCommonServices(ifr);

		String respFlag = cs.fetchPreClosure(pid, loanNo);
		if (!respFlag.startsWith("SUCCESS")) {
			if (respFlag.contains("~~")) {
				statusMsg = respFlag.split("~~")[1];
			} else {
				statusMsg = "Issue in fetching Repayment Schedule. Please try after sometime.";

			}
			
			ifr.clearTable("preClosureSettlementGrid");//clearing the grid data if preclosure fetch is unsuccessful
			
		}else if(respFlag.startsWith("SUCCESS")){ 
			
			statusMsg="Pre Closure Enquiry is successful.";
			
			setValuestoApportAfterChargesWaiveoff();
		}

		return statusMsg;
		
	}
	/*
	   *Method Name       :    generateContactUpdationOTP
	   *Input Parameters  :    Activity ID
	   *Return Values     :    String -Timeout period
	  * Author            :    Aseesh
	   *Description       :    This method generates OTP and inserts the OTP, Language,pid,stage,etc into CAGLLCSMessageQueueTable from which sms utility picks the cases and triggers sms.
	   */
	
	public String generateContactUpdationOTP(String activityId) {
		mRepLogger.info("Inside generateContactUpdationOTP common method");
		Properties p = getCommonProperties();
		String wiID = activityId;
		String stage = p.getProperty("otpStage");
		String loanNo = ifr.getValue("Loan_Account_No").toString();
		String phoneNumber = ifr.getValue("qContactnumberupdationdetails_primarymobileno").toString();
		String Language = "English"; // Setting default value as English
		String statusFlag = "N";
		String otp = "" + ((int) (Math.random() * 9000) + 1000);

		String query = p.getProperty("PreferredLanguage");
		query = query.replace("##Loan_Acc_No##", loanNo);
		mRepLogger.info("Executing query -->" + query);
		List<List<String>> opt = ifr.getDataFromDB(query);
		mRepLogger.info("output Language -->" + opt);
		if (opt != null && !otp.equals("") && !opt.toString().equalsIgnoreCase("[[]]")
				&& !opt.toString().equalsIgnoreCase("[]")) {
			Language = opt.get(0).get(0);
		}

		query = "insert into CAGLLCSMessageQueueTable values('" + wiID + "','" + stage + "','" + loanNo + "','"
				+ phoneNumber + "','" + Language + "','" + statusFlag + "','" + otp + "')";
		mRepLogger.info("Executing query-->" + query);
		ifr.getDataFromDB(query);

		query = "update EXT_Collection set contactupdationotp = '" + otp + "' where pinstanceid = '" + wiID + "'";
		mRepLogger.info("Executing query -->" + query);
		ifr.getDataFromDB(query);

		String timeout = p.getProperty("otpTimeout");
		return timeout;
	}
	/*
	   *Method Name       :    OtpExpireTimeout
	   *Input Parameters  :    Activity ID
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method generates OTP and inserts the OTP, Language,pid,stage,etc into CAGLLCSMessageQueueTable from which sms utility picks the cases and triggers sms.OTP is also stored in EXT table for verification
	   */

	public void OtpExpireTimeout(String activityId) {
		mRepLogger.info("Inside OtpExpireTimeout common method");
		String query = "update EXT_Collection set contactupdationotp = '' where pinstanceid = '" + activityId + "'";
		mRepLogger.info("Executing query -->" + query);
		ifr.getDataFromDB(query);
	}
	
	/*
	   *Method Name       :    verifyContactUpdationOTP
	   *Input Parameters  :    String -Activity ID,OTP
	   *Return Values     :    String -Yes/No
	  * Author            :    Aseesh
	   *Description       :    This method is used to validate the OTP entered by the user with the OTP stored in EXT table.Returns true if OTP matches else false.
	   */
	
	public String verifyContactUpdationOTP(String activityId, String otp) {
		mRepLogger.info("Inside verifyContactUpdationOTP common method");
		String query = "select contactupdationotp from EXT_Collection where pinstanceid = '" + activityId + "'";
		List<List<String>> opt = ifr.getDataFromDB(query);
		mRepLogger.info("output Language -->" + opt);
		if (opt != null && !otp.equals("") && !opt.toString().equalsIgnoreCase("[[]]")
				&& !opt.toString().equalsIgnoreCase("[]")) {
			if (otp.equalsIgnoreCase(opt.get(0).get(0))) {
				return "True";
			}
		}
		return "False";
	}
	
	/*
	   *Method Name       :    fetchApportionmentData
	   *Input Parameters  :    String -Collection Type
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method populates Apportionment fields with data from dump based on the Collection Type selected. Queries for fetching data based on Collection type are configured in Property file
	   */

	public void fetchApportionmentData(String collType) {

		String loanAcctNo = ifr.getValue("Loan_Account_No").toString();
		Properties p = getCommonProperties();
		if (collType.equalsIgnoreCase("normal")) {

			String query = p.getProperty("apportionmentQueryNormal");
			mRepLogger.info("Query fetched-->" + query);
			query = query.replace("##Loan_Account_No##", loanAcctNo);
			mRepLogger.info("Executing query-->" + query);

			List<List<String>> apportData = ifr.getDataFromDB(query);
			mRepLogger.info("query opt -->" + apportData);
			if (apportData.size() > 0) {

				List<String> normalCollData = apportData.get(0);
				ifr.setValue("q_Apportionment_I_EMI_DueOverdue", normalCollData.get(0));
				ifr.setValue("q_Apportionment_I_Bounce_Charges", normalCollData.get(1));
				ifr.setValue("q_Apportionment_I_LP_Charges", normalCollData.get(2));
				ifr.setValue("q_Apportionment_I_Credit_Balance_Advance_EMI", normalCollData.get(3));
			}
		} else if (collType.equalsIgnoreCase("Part Payment")) {
			//checking if any charges were available to waive-off
			/*String pid=ifr.getValue("pInstanceID").toString();
			String waievrQ=p.getProperty("pre_part_closure_waiver_query").replaceAll("##PID##", pid);
			List<List<String>> waiverAmts=ifr.getDataFromDB(waievrQ);*/
			
			String query = p.getProperty("apportionmentQueryPartPayment");
			mRepLogger.info("Query fetched-->" + query);
			query = query.replace("##Loan_Account_No##", loanAcctNo);
			mRepLogger.info("Executing query-->" + query);

			List<List<String>> apportData = ifr.getDataFromDB(query);
			mRepLogger.info("query opt -->" + apportData);
			if (apportData.size() > 0) {

				List<String> normalCollData = apportData.get(0);
				
//				BigDecimal bounceChrg=(normalCollData.get(3)!=null && !normalCollData.get(3).trim().equals("")) ? 
//									(new BigDecimal(normalCollData.get(3)).subtract(getAmountsfromWaiver("Bounce Charges",waiverAmts))) : new BigDecimal("0.00");
//				BigDecimal lpChrg=(normalCollData.get(4)!=null && !normalCollData.get(4).trim().equals("")) ? 
//											(new BigDecimal(normalCollData.get(4)).subtract(getAmountsfromWaiver("LP Charges",waiverAmts))) : new BigDecimal("0.00");					

				ifr.setValue("q_Apportionment_I_Principal_OS", normalCollData.get(0));
				ifr.setValue("q_Apportionment_I_Interest_Accrued_till_date", normalCollData.get(1));
				ifr.setValue("q_Apportionment_I_EMI_due_if_any", normalCollData.get(2));
				ifr.setValue("q_Apportionment_I_Bounce_Charges",normalCollData.get(3));
				ifr.setValue("q_Apportionment_I_LP_Charges", normalCollData.get(4));
				ifr.setValue("q_Apportionment_I_Credit_Balance_Advance_EMI", normalCollData.get(5));
				
				setValuestoApportAfterChargesWaiveoff();
			}
		} else if (collType.equalsIgnoreCase("Pre Closure")) {
			CollectionCommonServices cms=new CollectionCommonServices(ifr);
			cms.setPreClosureDataToApportionMentOnTabClick();
			setValuestoApportAfterChargesWaiveoff();
			//commenting the below code as its made part of the T24 fetch.
			//checking if any charges were available to waive-off
			/*String pid=ifr.getValue("pInstanceID").toString();
			String waievrQ=p.getProperty("pre_part_closure_waiver_query").replaceAll("##PID##", pid);
			List<List<String>> waiverAmts=ifr.getDataFromDB(waievrQ);
			
			String query = p.getProperty("apportionmentQueryPreClosure");
			mRepLogger.info("Query fetched-->" + query);
			query = query.replace("##Loan_Account_No##", loanAcctNo);
			mRepLogger.info("Executing query-->" + query);

			List<List<String>> apportData = ifr.getDataFromDB(query);
			mRepLogger.info("query opt -->" + apportData);
			if (apportData.size() > 0) {

				List<String> normalCollData = apportData.get(0);
				
				BigDecimal bounceChrg=(normalCollData.get(3)!=null && !normalCollData.get(3).trim().equals("")) ? 
						(new BigDecimal(normalCollData.get(3)).subtract(getAmountsfromWaiver("Bounce Charges",waiverAmts))) : new BigDecimal("0.00");
				BigDecimal lpChrg=(normalCollData.get(4)!=null && !normalCollData.get(4).trim().equals("")) ? 
											(new BigDecimal(normalCollData.get(4)).subtract(getAmountsfromWaiver("LP Charges",waiverAmts))) : new BigDecimal("0.00");					

				ifr.setValue("q_Apportionment_I_Principal_OS", normalCollData.get(0));
				ifr.setValue("q_Apportionment_I_Interest_Accrued_till_date", normalCollData.get(1));
				ifr.setValue("q_Apportionment_I_EMI_due_if_any", normalCollData.get(2));
				ifr.setValue("q_Apportionment_I_Bounce_Charges", bounceChrg.toString());
				ifr.setValue("q_Apportionment_I_LP_Charges", lpChrg.toString());
				ifr.setValue("q_Apportionment_I_Credit_Balance_Advance_EMI", normalCollData.get(5));

			}*/
		} else if (collType.equalsIgnoreCase("Sale") || collType.equalsIgnoreCase("Settlement")
				|| collType.equalsIgnoreCase("Shortfall")) {

			String query = p.getProperty("apportionmentQuerySSettlementS");
			mRepLogger.info("Query fetched-->" + query);
			query = query.replace("##Loan_Account_No##", loanAcctNo);
			mRepLogger.info("Executing query-->" + query);

			List<List<String>> apportData = ifr.getDataFromDB(query);
			mRepLogger.info("query opt -->" + apportData);
			if (apportData.size() > 0) {

				List<String> normalCollData = apportData.get(0);
				ifr.setValue("q_Apportionment_I_Principal_OS", normalCollData.get(0));
				ifr.setValue("q_Apportionment_I_Interest_Accrued_till_date", normalCollData.get(1));
				ifr.setValue("q_Apportionment_I_Bounce_Charges", normalCollData.get(2));
				ifr.setValue("q_Apportionment_I_LP_Charges", normalCollData.get(3));
				ifr.setValue("q_Apportionment_I_Other_Charges", normalCollData.get(4));
				ifr.setValue("q_Apportionment_I_Credit_Balance_Advance_EMI", normalCollData.get(5));
				ifr.setValue("q_Apportionment_Incidental_Charges", normalCollData.get(6));
				
				//below is commented & the value will be fetched from quotation details once 
				//the repo child has crossed quotation approval stage.
//				ifr.setValue("q_Apportionment_I_Sale_Settlement_Amount",
//						ifr.getValue("q_Repo_QD_Quotation_Details_Final_Resale_Amount").toString());
				saleSettlementShortfallCheck();
			}
		}

	}
	
	/*
	   *Method Name       :    getDocumentId
	   *Input Parameters  :    String -Document_Name,Iform Reference ifr
	   *Return Values     :    String- Document ID
	  * Author            :    Aseesh
	   *Description       :    This method returns the Document ID fetched from product tables and master tables based on ProcessInstance ID and Document Name
	   */

	public String getDocumentId(String Document_Name, IFormReference ifr) {
		String processInstanceId = ifr.getObjGeneralData().getM_strProcessInstanceId();
		mRepLogger.info("PROCESS INSTANCE ID IS  ----->" + processInstanceId);

		String query = " Select top 1 a.DocumentIndex from PDBDocument a"
				+ " left join PDBDocumentContent b on a.DocumentIndex=b.DocumentIndex"
				+ " left join WFINSTRUMENTTABLE c on b.ParentFolderIndex=c.VAR_REC_1"
				+ " left join nG_LCS_Master_Documents_List mas on a.name = mas.Org_ExactDocType"
				+ " where c.ProcessInstanceID='" + processInstanceId + "' and mas.Document_Name='" + Document_Name + "'"
				+ " order by a.CreatedDateTime desc";
		mRepLogger.info("QUERY RESULT IS ----->" + query);

		// log.consoleLog(ifr, " GetDocumentIndex:" + query);
		// result = rlos.getResultFromDB(query, ifr);
		// getDataFromDB
		// ifr.getDa
		List<List<String>> result = ifr.getDataFromDB(query);
		// . log.consoleLog(ifr, "Inside Document_ID:" + result.get(0).get(0));
		mRepLogger.info("RESULT IS ------>" + result);
		return result.get(0).get(0);

	}
	
	/*
	   *Method Name       :    createPDF
	   *Input Parameters  :    String -Generated Doc Pat,OutputPDFfilepath
	   *Return Values     :    Boolean
	  * Author            :    Aseesh
	   *Description       :    This method converts the existing Docx file into PDF.It consumes the Generated Doc path of docx and converts it into PDF at the specified filepath.
	   */

	public boolean createPDF(String generatedDocPath, String outputPdfFilePath) {
		boolean retOut = true;
		OutputStream out = null;
		try {

			mRepLogger.info("create pdf called");
			mRepLogger.info("create pdf called with outputPdfFilePath::" + outputPdfFilePath);
			mRepLogger.info("create pdf called with generatedDocPath::" + generatedDocPath);
			long start = System.currentTimeMillis();
			// fr.open
			// 1) Load DOCX into XWPFDocument
			InputStream is = new FileInputStream(new File(generatedDocPath));

			XWPFDocument document = new XWPFDocument(is);
			mRepLogger.info("create pdf called 1 ::");
			
			try { // 2) Prepare Pdf options
				PdfOptions options = PdfOptions.create();
				mRepLogger.info("create pdf called 2 ::");

				// 3) Convert XWPFDocument to Pdf
				out = new FileOutputStream(new File(outputPdfFilePath));
				mRepLogger.info("create pdf called 3 ::");
				// mRepLogger.info("document := " +
				// document!=null?"not NULL":"NULL");
				// mRepLogger.info("out := " + out!=null?"not NULL":"NULL");
				// mRepLogger.info("options := " +
				// options!=null?"not NULL":"NULL");
				PdfConverter.getInstance().convert(document, out, options);
				mRepLogger.info("create pdf called 4 ::");
				System.err.println("Generate pdf with " + (System.currentTimeMillis() - start) + "ms");

				mRepLogger.info("create pdf END");
				if (out != null) {
					out.flush();
					out.close();
				}
			} catch (Exception e) {
				retOut = false;
				mErrLogger.info("Exception in create pdf 1::" + e.getMessage());
				// mRepLogger.info("Exception in create pdf ::" +
				// ExceptionUtils.getStackTrace(e));
				mErrLogger.info(e); // V7-24
			} finally {

				try {

					if (out != null) {
						out.flush();
						out.close();
					}

				} catch (Exception e) {
					mErrLogger.info("Exceptioon Occured" + e.getMessage());
					// e.printStackTrace();
				}

			}

		} catch (Exception e) {
			retOut = false;
			mErrLogger.info("Exception in create pdf 2::" + e.getMessage());
			// mRepLogger.info("Exception in create pdf ::" +
			// ExceptionUtils.getStackTrace(e));
			mErrLogger.info(e); // V7-24
		} finally {

			try {

				if (out != null) {
					out.flush();
					out.close();
				}

			} catch (Exception e) {
				mErrLogger.info("Exceptioon Occured" + e.getMessage());
				// e.printStackTrace();
			}

		}

		return retOut;
	}
	/*
	   *Method Name       :    initlog
	   *Input Parameters  :    NA
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method initializes the custom logging system.
	   */

	public static void initlog() {
		try {
			mRepLogger.info("Inside InitLog");
			mstrlog4jConfigFilePath = System.getProperty("user.dir") + System.getProperty("file.separator")
					+ "LCS_Config" + System.getProperty("file.separator") + "log4j.properties";
			File lobjFile = new File(mstrlog4jConfigFilePath);
			if (!lobjFile.exists()) {
				System.out.print("Logger Config file doesnot exists !" + mstrlog4jConfigFilePath);
			} else {
				configureLogger(mstrlog4jConfigFilePath);
			}
			// lobjFile = null;

		} catch (Exception lobjExcp) {
			System.out.print("Exception occurs during logger initialization: " + lobjExcp.toString());
		}
	}
	
	/*
	   *Method Name       :    configureLogger
	   *Input Parameters  :    String - Log4j.property filepath
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method configures the custom logger system.
	   */

	public static void configureLogger(String plog4jConfigFilePath) throws Exception {

		String lExceptionId = new String("com.newgen.lns.myqueue.process.configureLogger.");
		FileInputStream lobjFileInputStream = null;
		Properties lobjPropertiesINI = null;
		try {
			mRepLogger.info("Inside configureLogger");
			// FileInputStream lobjFileInputStream = null;
			lobjFileInputStream = new FileInputStream(plog4jConfigFilePath);
			lobjPropertiesINI = new Properties();
			lobjPropertiesINI.load(lobjFileInputStream);
			lobjPropertiesINI = loadProperties(lobjPropertiesINI);
			PropertyConfigurator propertyConfigurator = new PropertyConfigurator();
			propertyConfigurator.doConfigure(lobjPropertiesINI, LogManager.getLoggerRepository());
		} catch (Exception lobjExcp) {
			System.out.print(
					lExceptionId + ": Exception occurs during logger initialization1111: " + lobjExcp.toString());
			throw lobjExcp;
		} finally {
			if (lobjFileInputStream != null)
				lobjFileInputStream.close();
		}

	}
	/*
	   *Method Name       :    loadProperties
	   *Input Parameters  :    Properties
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method loads the configured custom logger system.
	   */

	public static Properties loadProperties(Properties pobjProperties) throws Exception {
		Properties lobjProperties = pobjProperties;
		try {
			mRepLogger.info("loadProperties");
			Enumeration lobjEnumeration = null;
			lobjEnumeration = lobjProperties.keys();

			while (lobjEnumeration.hasMoreElements()) {
				String s1 = ((String) lobjEnumeration.nextElement()).trim();
				if (!s1.startsWith("log4j.logger.")) {
					continue;
				}
				String s4 = lobjProperties.getProperty(s1);
				StringTokenizer stringtokenizer = new StringTokenizer(s4, ",");

				while (stringtokenizer.hasMoreTokens()) {
					String s7 = stringtokenizer.nextToken();
					String s2 = "log4j.appender." + s7.trim() + ".File";
					lobjProperties.getProperty(s2);
				}

//				stringtokenizer = null;
			}

		} catch (Exception lobjExcp) {
			System.out.print("loadProperties : Exception occurs during logger initialization: " + lobjExcp.toString());
			throw lobjExcp;
		}

		return lobjProperties;
	}
	
	/*
	   *Method Name       :    document_number_field
	   *Input Parameters  :    String -Empty String
	   *Return Values     :    NA
	  * Author            :    Aseesh
	   *Description       :    This method computes the fields in document which has numerical amount in words from the property file and calculates its equivalent in words .
	   */
	
public static String document_number_field(String Document_Name, IFormReference ifr,Properties p)
{
	String pid = ifr.getValue("pInstanceID").toString();
	mRepLogger.info("PROCESS INSTANCE ID IS  ----->" + pid);
	String[] tableList=p.getProperty(Document_Name).split("~");
	mRepLogger.info("Table list is"+tableList);
	for(int i=0;i<tableList.length;i++)
	{
		String tableName = tableList[i].split("#")[0];
		String columnName  = tableList[i].split("#")[1];
		String[] columnNameList  = tableList[i].split("#")[1].split(",");
		String whereKey = tableList[i].split("#")[2];
		String query_get_vals="SELECT "+columnName+" FROM "+tableName+" with(nolock) WHERE "+whereKey+"='"+pid+"'";
		
		List<List<String>> result_val = ifr.getDataFromDB(query_get_vals);
		mRepLogger.info("query is "+query_get_vals);
		if(result_val.size()>0)
		{
			for(int j=0;j<columnNameList.length;j++)
			{
			String amount = result_val.get(0).get(j).replaceAll(",", "");
			mRepLogger.info("amount is"+amount);//1000.00
			if(! amount.equalsIgnoreCase(""))
			{
			
			Float f=Float.parseFloat(amount);
			int intValue = f.intValue() ;


			String words= numberToWord(intValue);

			mRepLogger.info("words is"+words);
			String update_query="UPDATE "+tableName+" SET "+columnNameList[j]+"_IN_Words = '"+words+"' WHERE "+whereKey+"='"+pid+"'";
			mRepLogger.info("update query is"+update_query);
			ifr.getDataFromDB(update_query);

		    ifr.getDataFromDB(update_query);
//			mRepLogger.info("update query result is"+result);
			}

		}
	}
	}
	if(Document_Name.equalsIgnoreCase("Demand_Letter_1_English")||Document_Name.equalsIgnoreCase("Demand_Letter_1_Hindi")||Document_Name.equalsIgnoreCase("Demand_Letter_1_Kannada")||
			Document_Name.equalsIgnoreCase("Demand_Letter_1_Marathi")||Document_Name.equalsIgnoreCase("Demand_Letter_1_Tamil"))	{
		String pInstanced = ifr.getValue("pInstanceID").toString();

		String query_get_vals="SELECT dump.Sanction_Amount FROM NG_DUMP_DOCUMENT_DET dump WITH(nolock) LEFT JOIN  EXT_Collection ext WITH(nolock) ON ext.Loan_Account_No=dump.L_ACCT_NO where pInstanceID='" +pInstanced+ "'"; 
		String update_query="UPDATE EXT_Collection  SET Sanction_Amount_IN_Words = '##updatedValue##'  WHERE pInstanceID ='"+pInstanced+"'" ;

		document_select_update(query_get_vals,update_query,ifr);
		
		
}
	return " ";

	}

/*
 *Method Name       :    document_select_update
 *Input Parameters  :    String -SelectQuery,UpdateQuery ,IformReference ifr 
 *Return Values     :    NA
* Author            :    Aseesh
 *Description       :    This method translates amount to its equivalent in words .
 */

public static void document_select_update(String selectQuery,String updateQuery,IFormReference ifr)
{
	List<List<String>> result_val = ifr.getDataFromDB(selectQuery);
	int arraysize=result_val.size();
		mRepLogger.info("query is "+selectQuery);
	if(arraysize>0)
	{
	
		String amount = result_val.get(0).get(0).replaceAll(",", "");
		mRepLogger.info("amount is"+amount);//1000.00
		if(! amount.equalsIgnoreCase(""))
		{
		Float f=Float.parseFloat(amount);
		int intValue = f.intValue() ;


		String words= numberToWord(intValue);
		mRepLogger.info("words is"+words);
		
		updateQuery = updateQuery.replaceAll("##updatedValue##", words);
				
		mRepLogger.info("update query is"+updateQuery);
		ifr.getDataFromDB(updateQuery);

	    ifr.getDataFromDB(updateQuery);
//		mRepLogger.info("update query result is"+result);
		}
	}

}

/*
 *Method Name       :    numberToWor
 *Input Parameters  :    Int-number
 *Return Values     :    String - NUmber in Words
* Author            :    Aseesh
 *Description       :    This method converts Number to words .
 */

public static String numberToWord(int number) 
{
	 mRepLogger.info("break 1");
        // variable to hold string representation of number 
        int flag = 0;
        String words = "";
        String  unitsArray[]={"zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};
String tensArray[]= {"Zero","Ten","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"};
if(number==0) {
            mRepLogger.info("break 2");
            return "zero";
}
//add minus before conversion if the number is less than 0
if(number<0) {// convert the number to a string
String numberStr = "" + number;
// remove minus before the number 
numberStr = numberStr.substring(1);
mRepLogger.info("break numberStr==" + numberStr);
// add minus before the number and convert the rest of number 
//Float f=Float.parseFloat(numberStr);
//int intValue = f.intValue() ;
return "minus " + numberToWord(Integer.parseInt(numberStr));

}
/*if (number < 0) {​​​​​​​ // convert the number to a string 
    String numberStr = "" + number;
    // remove minus before the number 
    numberStr = numberStr.substring(1);
    System.out.println("break numberStr==" + numberStr);
    // add minus before the number and convert the rest of number 
    return "minus " + numberToWord(Integer.parseInt(numberStr));
}​​​​​​​
*/
        // check if number is divisible by 1 million
if((number/1000000)>0)
{
 words += numberToWord(number / 1000000) + " Million ";
 number %= 1000000;
 mRepLogger.info("num%==" + number);
 flag++;
 mRepLogger.info("The flag has been triggered;");

}
//check if number is divisible by 1 Lakh

if((number/100000)>0) {
words += numberToWord(number / 100000) + " Lakh ";
number %= 100000;
mRepLogger.info("num%==" + number);
flag++;
mRepLogger.info("The flag has been triggered;");
}
//check if the number is divisible by Thousand
       if((number/1000)>0) {
    	   words += numberToWord(number / 1000) + " Thousand ";
            number %= 1000;
            mRepLogger.info("num%1==" + number);
            flag++;
            mRepLogger.info("The flag has been triggered;");  
       }
        // check if number is divisible by 1 hundred
       if((number/100)>0) {
    	   words += numberToWord(number / 100) + " Hundred ";
            number %= 100;
            mRepLogger.info("num%2==" + number);
            flag++;
            mRepLogger.info("The flag has been triggered;");
   }
       if(number>0) {
//check whether the number is within tens	       
if(number<20) {
 // fetch the appropriate value from unit array 
if(flag!=0) {
	words+=" and ";
}words+=unitsArray[number];
}else {
// fetch the appropriate value from tens array 
if(flag!=0) {
	words+=" and ";
}
   words+=tensArray[number/10];
if(number %10 >0)
{
words+="-" +unitsArray[number%10];
}
}
       }
mRepLogger.info("num%3=="+number);
return words;
}

/*
 *Method Name       :    addDocInfo
 *Input Parameters  :    String Doctype
 *Return Values     :    NA
* Author            :    Aseesh
 *Description       :    This method updates the document data to cmplx_coll_IR_DemandLetterGrd if the generated document is Demand_Letter or Recall_Notice .
 */


public void addDocInfo(String docType){ 
	
	mRepLogger.info("Inside the addDocInfo method to update the generated doc data to cmplx table for: "+docType);
	
	try{ 
		
		if(docType.startsWith("Demand_Letter") || docType.startsWith("Recall_Notice")){ 
			String query="INSERT INTO cmplx_coll_IR_DemandLetterGrd (pid, Document_Type, Generated_Date) "
					+ "VALUES ('"+ifr.getValue("pInstanceID").toString()+"', '"+docType+"', getDate())";
			mRepLogger.info("Query to insert the doc data to cmplx grid : "+query);	
			ifr.getDataFromDB(query);
		}
				
	}catch(Exception e){
		
		mErrLogger.info("Exception in adding the generated doc data to cmplx table : "+e.getMessage());
	}
		
}

/*
 *Method Name       :    demanLetterCheck
 *Input Parameters  :    String DocName,Loan number,ActionCode
 *Return Values     :    NA
* Author            :    Aseesh
 *Description       :    This method computes whether selected Document can be generated or not by checking if it is already generated or in process.
 */

public Status demanLetterCheck(String docName,String loanNo,String actCode){ 
	
	mRepLogger.info("Inside validating the document generation for the selected document demanLetterCheck");
	
	Status s=new Status();
//	String doc="";
	try{ 
		mRepLogger.info(docName+","+loanNo+","+actCode);
		
		if(!actCode.equals("") && !loanNo.equals("")){ 
				String q="";
				if(actCode.equalsIgnoreCase("")){ 
					mRepLogger.info("---------Inside actcode empty-----------");
					q="SELECT a.DispositionCode,a.ChildPID FROM ng_cmplx_actionhistory a "
							+ "WITH(NOLOCK) LEFT JOIN EXT_Collection e WITH(NOLOCK) ON (a.Pid=e.PID) WHERE "
							+ "e.Loan_Account_No='"+loanNo+"' AND a.DispositionCode ='"+actCode+"' AND "
									+ "a.Demand_Letter_Type='"+docName+"' GROUP BY a.DispositionCode,a.ChildPID";
//					doc=docName.replaceAll(" ", "_").trim();
				}else{ 
					mRepLogger.info("---------Inside actcode not empty-----------");
					q="SELECT a.DispositionCode,a.ChildPID FROM ng_cmplx_actionhistory a "
							+ "WITH(NOLOCK) LEFT JOIN EXT_Collection e WITH(NOLOCK) ON (a.Pid=e.PID) WHERE "
							+ "e.Loan_Account_No='"+loanNo+"' AND a.DispositionCode ='"+actCode+"' and a.Demand_Letter_Type='"+docName+"' "
									+ "GROUP BY a.DispositionCode,a.ChildPID";
//					doc=docName.replaceAll("Initiate ","").replaceAll(" ", "_");	
				}
				
				mRepLogger.info("Query to execute for validating the doc generation :"+q);
				
				List<List<String>> res=ifr.getDataFromDB(q);
//				mRepLogger.info("result 1==>"+res);
				if(res.size()>0){ 
					
					for(int k=0;k<res.size();k++){ 
						
						List<String> row=res.get(k);
						String cpid=row.get(1);
//						mRepLogger.info("curr Row->"+row+", "+cpid);
						if(cpid!=null){ 
							/*String qry="SELECT Document_Type FROM cmplx_coll_IR_DemandLetterGrd WITH(NOLOCK) "
									+ "WHERE pid='"+cpid+"' and Document_Type LIKE '"+doc+"%'";*/
							String qry="SELECT Document_Name FROM ng_cmplx_outward_document_Details WITH(NOLOCK) "
									+ "WHERE pid='"+cpid+"' and Document_Name='"+docName+"'";
//							mRepLogger.info("query 2==>"+qry);
							
							List<List<String>> chk=ifr.getDataFromDB(qry);
//							mRepLogger.info("result 2==>"+chk);
							if(chk.size()>0){ 
								
								s.setStatus(false);
								s.setSubStatus(false);
								s.setMsg(docName+" already generated for this loan.");
								break;
							}else{ 
								
								String actQry="SELECT activityname FROM WFINSTRUMENTTABLE WITH(NOLOCK) WHERE ProcessInstanceID='"+cpid+"'";
								List<List<String>> act=ifr.getDataFromDB(actQry);
//								mRepLogger.info("query 3==>"+actQry);
//								mRepLogger.info("result 3==>"+act);
								if(act.size()>0 && (act.get(0).get(0).equalsIgnoreCase("exit") || 
										act.get(0).get(0).equalsIgnoreCase("DMS_Archival"))){ 
//									s.setStatus(true);
									continue;
								}else{ 
									
									s.setStatus(false);
									s.setSubStatus(true);
									s.setMsg(docName+" is already in process.");
									break;
								}
							}
						}
						
					}
					
				}else{ 
					
					s.setStatus(true);
					
				}
			
			
		}
			
		
	}catch(Exception e){ 
		
		mErrLogger.info("Exception in validating the selected doc in the current loan : "+e.getMessage());
		s.setStatus(false);
		s.setMsg("Error in selected document type validation");
	}
	
	return s;
	
	
}

/*
 *Method Name       :    validateDocGen
 *Input Parameters  :    NA
 *Return Values     :    Status
* Author            :    Aseesh
 *Description       :    This method validates document generation process for a selected document.If the conditions are not satisfied error message is thrown and selected document is not generated.
 */

public Status validateDocGen(){ 
	
mRepLogger.info("Inside validating the document generation for the selected document :");
	
	Status s=new Status();
	s.setStatus(true);
	
	try{ 
		
		Object obj=ifr.getValue("qContactRecording_Action_Code");
		String actCode=(obj!=null ? obj.toString() : "");
		Object loanObj=ifr.getValue("Loan_Account_No");
		String loanNo=(loanObj!=null ? loanObj.toString() : "");
		
		if(!actCode.equals("") && !loanNo.equals("")){ 
			
			if(actCode.equalsIgnoreCase("Initiate Demand Letter")){ 
				Object obj2=ifr.getValue("qContactRecording_typeofdemandletter");
				String docName=(obj2!=null ? obj2.toString() : "");

				if(!docName.trim().equals("")){ 
					
					//getting the already created childs to validate.
					Properties p=getCommonProperties();
					String q=p.getProperty("DemandletterValidationQuery").replace("##Loan_Account_Number##", loanNo);
					
					mRepLogger.info("Query for the demandletter query :"+q);
					List<List<String>> data=ifr.getDataFromDB(q);
					mRepLogger.info("Data from the demandletter query :"+data);
					if(data.size()>0){ 
						String nextDocName="";
						String msg="";
						for(int i=0;i<data.size();i++){ 
							
							List<String> currRow=data.get(i);
							
							if((currRow.get(3).equalsIgnoreCase("exit") || currRow.get(3).equalsIgnoreCase("dms_archival")) &&
									currRow.get(2)!=null && !currRow.get(2).trim().equals("")){ 
								//this is the final doc generated
								String dn=currRow.get(1);
								int lastDoc=Character.getNumericValue(dn.charAt(dn.trim().length()-1));
								if(lastDoc<3){ 
									nextDocName=dn.substring(0,dn.length()-1)+(Integer.toString(lastDoc+1));									
								}else if(lastDoc==3){ 
									nextDocName=dn.substring(0,dn.length()-1)+"1";	
								}
								if(!docName.equalsIgnoreCase(nextDocName)){ 
									s.setStatus(false);
									s.setMsg("Only "+nextDocName+" can be raised.");
									return s;
								}
							}else if(!currRow.get(3).equalsIgnoreCase("exit") && !currRow.get(3).equalsIgnoreCase("dms_archival")){ 
								//this doc is in process
								String dn=currRow.get(1);
								if(dn.equalsIgnoreCase(docName)){ 
									s.setMsg(dn+" is already in process.");
								}else{ 
									s.setMsg(dn+" is in process. Cannot initiate "+docName);
								}
								s.setStatus(false);
								return s;

							}else if((currRow.get(3).equalsIgnoreCase("exit") || currRow.get(3).equalsIgnoreCase("dms_archival")) &&
									(currRow.get(2)==null || currRow.get(2).trim().equals(""))){ 
								//this doc is raised, but not generated, so only this doc can be raised now.
								String dn=currRow.get(1);
								if(!dn.equalsIgnoreCase(docName)){ 
									s.setStatus(false);
									s.setMsg("Only "+dn+" can be raised.");
									return s;									
									
								}
							}
							break;
							
						}

					}

				}else{ 
					
					s.setStatus(false);
					s.setMsg("Please select Type of Demand Letter.");
					return s;
				}
				
			}else if(actCode.equalsIgnoreCase("Initiate Intimation Letter")){ 
				
				//getting the already created childs to validate.
				Properties p=getCommonProperties();
				String q=p.getProperty("IntimationLetterValidationQuery").replace("##Loan_Account_Number##", loanNo);
				
				mRepLogger.info("Query for the Intimation Letter query :"+q);
				List<List<String>> data=ifr.getDataFromDB(q);
				mRepLogger.info("Data from the Intimation Letter query :"+data);
				
				if(data.size()>0){ 
					
					for(int i=0;i<data.size();i++){ 
						
						List<String> currRow=data.get(i);
						String genDt=currRow.get(2);
						String ws=currRow.get(3);
						if(genDt!=null && !genDt.trim().equals("")){ 
							
							s.setStatus(false);
							s.setMsg("Cannot generate Intimation letter as Demand letter is already generated for this loan no.");
							return s;
						}else if((genDt==null || genDt.trim().equals("")) && 
								(!ws.equalsIgnoreCase("exit") && !ws.equalsIgnoreCase("dms_archival"))){ 
							
							s.setStatus(false);
							s.setMsg("Cannot generate Intimation letter as Demand letter is in process for this loan no.");
							return s;
						}
					}
					
				}
				
			}
			
			
			/*else if(actCode.equalsIgnoreCase("Initiate Recall Notice")){ 
				
				return demanLetterCheck(actCode,loanNo,actCode);
			}*/
			
		}else{ 
			
			s.setStatus(false);
			s.setMsg("Action code or Loan No. is empty.");
			return s;
		}
			
		
	}catch(Exception e){ 
		
		mErrLogger.info("Exception in validating the selected doc in the current loan : "+e.getMessage());
		s.setStatus(false);
		s.setMsg("Error in selected document type validation");
		
	}
	
	return s;
	
}

/*
 *Method Name       :    saveDocData
 *Input Parameters  :    NA
 *Return Values     :    NA
* Author            :    Aseesh
 *Description       :    This method saves outward document grid data into ng_cmplx_outward_document_Details table .
 */

public void saveDocData(){ 
	
	mRepLogger.info("Inside saving the outward document data to DB");
	
	Properties p = getCommonProperties();
	String pid = ifr.getValue("pInstanceID").toString();
	String loanNo = ifr.getValue("Loan_Account_No").toString();
	String docCol=p.getProperty("DocColumns");
	docCol=(docCol!=null) ? docCol : "";
	
	try{
	
	if(!docCol.trim().equals("") && !pid.trim().equals("") && !loanNo.trim().equals("")){ 
		//getting the doc docs that are visible for the current WS and deleting only those to insert updated ones.
		String docVisibleQ="SELECT Document_Name FROM NG_LCS_Master_Documents_List WITH(NOLOCK) WHERE Doc_Type='O'  AND IsActive='Y' AND "+ifr.getActivityName()+"='Y'";
		List<List<String>> data=ifr.getDataFromDB(docVisibleQ);
		if(data.size()>0){ 
			String availableDocs="";
			
			for(int l=0;l<data.size();l++){ 
				
				String doc=data.get(l).get(0);
				availableDocs=availableDocs.equals("") ? doc : availableDocs+","+doc;
			}
			
			availableDocs="'"+availableDocs.replaceAll(",", "','")+"'";
			
			String[] docCollArr=docCol.split(",");
			String docDelQuery="DELETE FROM ng_cmplx_outward_document_Details WHERE Loan_Acct_No='"+loanNo+"' and Document_Name in ("+availableDocs+")";
			ifr.getDataFromDB(docDelQuery);
			
			JSONArray docTableData=ifr.getDataFromGrid("Outward_Document_ListView");
			
//			mRepLogger.info("Data available in the doc grid :"+docTableData);
			
			String insertQuery="INSERT INTO ng_cmplx_outward_document_Details "
					+ "(Loan_Acct_No, PID, Document_Name, Generated_Date, Sent_Date, "
					+ "Acknowledge_Date, Return_Date, Return_Status,DocIndex,From_Date, To_Date) VALUES";
			
			String vals="";
			String v="";
			for(int i=0;i<docTableData.size();i++){ 
				JSONObject row=(JSONObject) docTableData.get(i);
				
				//saving the data only if the user updated any row in doc grid.
				if(row.get("Generated Date").equals("") && row.get("Sent Date").equals("") &&
						row.get("Acknowledge Date").equals("") && row.get("Return Date").equals("") && 
						row.get("Return Status").equals("") &&
						row.get("From Date").equals("") && row.get("To Date").equals("")){ 
					
					continue;
				}
				
				vals="('"+loanNo+"','"+pid;
				for(int k=0;k<docCollArr.length;k++){ 
					if(docCollArr[k].equalsIgnoreCase("Generated Date")){ 
						
						if(row.get(docCollArr[k])!=null && !row.get(docCollArr[k]).equals("")){ 
							mRepLogger.info("GenDate Save==>"+row.get(docCollArr[k]));
							Date date1 = parseDate(row.get(docCollArr[k]).toString(),true);
							String dateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date1);
							vals=vals.endsWith("NULL") ? (vals+",'"+dateStr) : (vals+"','"+dateStr);
						}else{ 
							
							vals=vals.endsWith("NULL") ? (vals+",NULL") : (vals+"',NULL") ;
						}
						
					}else if(docCollArr[k].equalsIgnoreCase("Sent Date") ||
							docCollArr[k].equalsIgnoreCase("Acknowledge Date") ||
							docCollArr[k].equalsIgnoreCase("Return Date") || 
							docCollArr[k].equalsIgnoreCase("From Date") || 
							docCollArr[k].equalsIgnoreCase("To Date")){ 
						
						if(row.get(docCollArr[k])!=null && !row.get(docCollArr[k]).equals("")){ 
							mRepLogger.info("OtherDates Save==>"+row.get(docCollArr[k]));
							Date date1 = parseDate(row.get(docCollArr[k]).toString(),false);
							String dateStr = new SimpleDateFormat("yyyy-MM-dd").format(date1);
							vals=vals.endsWith("NULL") ? (vals+",'"+dateStr) : (vals+"','"+dateStr);
						}else{ 
							
							vals=vals.endsWith("NULL") ? (vals+",NULL") : (vals+"',NULL") ;
						}
						
					}else{ 
						vals=vals.endsWith("NULL") ? (vals+",'"+row.get(docCollArr[k])) : (vals+"','"+row.get(docCollArr[k])) ;
					}
					
					
				}
				vals=vals.endsWith("NULL") ? vals+")" : vals+"')";
				v=(v.equals("")?vals:v+","+vals);
			}
			
			mRepLogger.info("Final insert query for the doc data to save :"+insertQuery+v);
			
			if(!v.equals("")){ 
				
				ifr.getDataFromDB(insertQuery+v);
			}
			
		}
		
	}
	
}catch(Exception e){ 
	
	mErrLogger.info("Error in saving the doc data in cmplx table :"+e.getMessage());
}
	
}

/*
 *Method Name       :    populateQuestionnaire
 *Input Parameters  :    String -Fetch Button ID
 *Return Values     :    NA
* Author            :    Aseesh
 *Description       :    This method populates Questionnaire in grid based on selected actioncode .
 */
//questionnaire.
public void populateQuestionnaire(String btn){ 
	
	mRepLogger.info("Inside the populate questionnaire method");
	String pid = ifr.getValue("pInstanceID").toString();
	String actCode = ifr.getValue("qContactRecording_Action_Code").toString();
	Properties p = getFetchDumpDataProperties();
	String control=p.getProperty("G_"+btn);
	String QuestColumns=p.getProperty("C_MASTER_Quest_"+btn);
	String OptColumns=p.getProperty("C_MASTER_Opt_"+btn);
	try{ 
		//first populating the grid with master data.
		String masterQuestQuery=p.getProperty("Q_MASTER_Quest_"+btn).replaceAll("##STAGE##", "QCO-"+actCode).replaceAll("##Product##", ifr.getValue("Product_Name").toString());
		mRepLogger.info("Master_Quest_Query: "+masterQuestQuery);
		populateListView(QuestColumns, masterQuestQuery, control, ifr);
		String masterOptQuery=p.getProperty("Q_MASTER_Opt_"+btn).replaceAll("##STAGE##", "QCO-"+actCode).replaceAll("##Product##", ifr.getValue("Product_Name").toString());
		List<List<String>> db_Values = ifr.getDataFromDB(masterOptQuery);
		int i = 0, j = 0, k=0;

			for (List<String> options_values : db_Values) {
				
				String ParentSplitter= options_values.get(0).trim();
				String opt[]=ParentSplitter.split(",");
//				String traced[]=ParentSplitter[1].trim().split(",");
				for (i = 0; i < opt.length; i++) {
					
					ifr.addItemInTableCellCombo(control, j, 2, opt[i], opt[i]);

				}
//				for (k = 0; k < traced.length; k++) {
//					
//					ifr.addItemInTableCellCombo(control, j, 2, traced[k], traced[k]);
//
//				}

				j++;

			}
		

	}catch(Exception e){ 
		
		mErrLogger.info("Error in populateQuestionnaire :"+e.getMessage());
	}
	
	
}

/*
 *Method Name       :    populatePar_Check_Questionnaire
 *Input Parameters  :    String -Fetch Button ID
 *Return Values     :    NA
* Author            :    Aseesh
 *Description       :    This method populates Questionnaire in grid based on selected actioncode .
 */

public void populatePar_Check_Questionnaire(String btn) {
	mRepLogger.info("Inside populatePar_Check_Questionnaire Method");
	String pid = ifr.getValue("pInstanceID").toString();
	String actCode = ifr.getValue("qContactRecording_Action_Code").toString();
	Properties p = getFetchDumpDataProperties();
	String control=p.getProperty("G_"+btn);
	String QuestColumns=p.getProperty("C_MASTER_Quest_"+btn);
	String OptColumns=p.getProperty("C_MASTER_Opt_"+btn);
	
	try{ 
		//first populating the grid with master data.
		String masterQuestQuery=p.getProperty("Q_MASTER_Quest_"+btn).replaceAll("##STAGE##", "QCO-"+actCode).replaceAll("##Product##", ifr.getValue("Product_Name").toString());
		mRepLogger.info("MasterQuestQuery "+masterQuestQuery);
		populateListView(QuestColumns, masterQuestQuery, control, ifr);
		String masterOptQuery=p.getProperty("Q_MASTER_Opt_"+btn).replaceAll("##STAGE##", "QCO-"+actCode).replaceAll("##Product##", ifr.getValue("Product_Name").toString());
		mRepLogger.info("masterOptQuery "+masterOptQuery);
		List<List<String>> db_Values = ifr.getDataFromDB(masterOptQuery);
		int i = 0, j = 0, k=0;
		for (List<String> options_values : db_Values) {
			
			String ParentSplitter[] = options_values.get(0).trim().split("~~");
			String opt[]=ParentSplitter[0].trim().split(",");
			for (i = 0; i < opt.length; i++) {
				
				ifr.addItemInTableCellCombo(control, j, 2, opt[i], opt[i]);

			}
			j++;
		}
	}
	catch(Exception e){ 
		
		mErrLogger.info("Error in populateQuestionnaire :"+e.getMessage());
	}
	
}

/*
 *Method Name       :    updateQuestionnaire
 *Input Parameters  :    String -ControlID,PID
 *Return Values     :    JSONArray
* Author            :    Aseesh
 *Description       :    This method responses of the questionnaire from the complex table if any
 */
public JSONArray updateQuestionnaire(String ControlID,String pid)
{
	mRepLogger.info("Inside UpdateQustionnaire From Complex table");
	Properties p = getFetchDumpDataProperties();
	String control=p.getProperty("G_"+ControlID);
	String actCode = ifr.getValue("qContactRecording_Action_Code").toString();
	//String Check_Query="SELECT QCOQuestionnaire,Options,Traced,Remarks FROM CMPLX_COLL_SkipTrace_Details_Grid WITH (NOLOCK) WHERE TransactionId='"+pid+"'";
	String UpdateQuery=p.getProperty("Q_MASTER_Quest_Update_"+ControlID).replaceAll("##PID##",pid).replaceAll("##STAGE##","QCO-"+actCode);
	mRepLogger.info("UpdateQuery "+UpdateQuery);
	List<List<String>> db_Values=ifr.getDataFromDB(UpdateQuery);
	
	/*mRepLogger.info("DB VAlues: "+db_Values);
	mRepLogger.info("DB VAlues size: "+db_Values.size());
	mRepLogger.info("DB VAlues1 db_Values.get(0) : "+db_Values.get(0));
	mRepLogger.info("DB VAlues2: db_Values.get(0).get(0): "+db_Values.get(0).get(0));*/
	
	JSONArray jarr=new JSONArray();
	
	for(int i=0;i<db_Values.size();i++) { 
		JSONObject jobj=new JSONObject();
		jobj.put("S.NO",db_Values.get(i).get(0));
		jobj.put("Questions",db_Values.get(i).get(1));
		jobj.put("Options",db_Values.get(i).get(2));
//		jobj.put("Traced",db_Values.get(i).get(2));
		jobj.put("Remarks",db_Values.get(i).get(3));
		
		jarr.add(jobj);
	}
	
	mRepLogger.info("JsonARRAY: "+jarr);
	
	return jarr;
	//int count=Integer.parseInt(db_Values.get(0).get(0));
	//mRepLogger.info("No of rows in Complex table "+count);
	//Load the questionnaire responses from the complex table
	/*if(count>0)
	{
		
		ifr.getTableCellValue(control, ,0);
		
	}*/
	

}
/*
 *Method Name       :    update_PAR_Check_Questionnaire
 *Input Parameters  :    String -ControlID,PID
 *Return Values     :    JSONArray
* Author            :    Aseesh
 *Description       :    This method updates the questionnaire grid with questions ,options,remarks fetched from db using query configured in Property file.
 */
public JSONArray update_PAR_Check_Questionnaire(String ControlID,String pid) {
	mRepLogger.info("Inside Update_PAR_Check_Qustionnaire From Complex table");
	Properties p = getFetchDumpDataProperties();
	String control=p.getProperty("G_"+ControlID);
	String UpdateQuery=p.getProperty("Q_MASTER_Quest_Update_"+ControlID).replaceAll("##PID##",pid);
	mRepLogger.info("UpdateQuery "+UpdateQuery);
	List<List<String>> db_Values=ifr.getDataFromDB(UpdateQuery);
	JSONArray jarr=new JSONArray();
	
	for(int i=0;i<db_Values.size();i++) { 
		JSONObject jobj=new JSONObject();
		jobj.put("S.NO",db_Values.get(i).get(0));
		jobj.put("Questions",db_Values.get(i).get(1));
		jobj.put("Options",db_Values.get(i).get(2));
		jobj.put("Remarks",db_Values.get(i).get(3));
		jarr.add(jobj);
	}
	
	mRepLogger.info("JsonARRAY: "+jarr);
	
	return jarr;
	
	
}

/*
 *Method Name       :    validateWaiveOffAmt
 *Input Parameters  :    NA
 *Return Values     :    String -true/false
* Author            :    Aseesh
 *Description       :    This method is used to compare the entered waiveoff amount with the Master value based on collection type and waiver type. If entered value < master Value then returns true else false
 */

public String validateWaiveOffAmt(){ 
	mRepLogger.info("Inside the validateWaiveOffAmt, validating the entered waiveoff amount");
	String b="true";
	String collType=ifr.getValue("qCollectionEntry_CollectionEntryType").toString();
	String charge=ifr.getValue("q_chargewaiver_WaiverType").toString();
	String value=ifr.getValue("q_chargewaiver_AmountWaivedOff").toString();
	
	if(value!=null && !value.trim().equals("")){ 
		
		String query="SELECT ApportionFieldID FROM NG_Master_WaiveOff_Types WITH(NOLOCK) WHERE "
				+ "CollectionType='"+collType+"' AND WaiveOffType='"+charge+"'";
		List<List<String>> idList=ifr.getDataFromDB(query);
		if(idList.size()>0 && idList.get(0).get(0)!=null){ 
			
			String actValue=(ifr.getValue(idList.get(0).get(0))!=null && !ifr.getValue(idList.get(0).get(0)).toString().trim().equals("")) ?  ifr.getValue(idList.get(0).get(0)).toString() : "0";
			
			if(actValue!=null && !actValue.trim().equals("") && (Double.valueOf(value)>Double.valueOf(actValue))){ 
				b="false";
			}
			
		}else{ 
			
			b="false";
		}
		
	}else{ 
		
		b="false";
	}
	return b;
	
}
/*
 *Method Name       :    ActionHistoryUpdation
 *Input Parameters  :    NA
 *Return Values     :    String -""
* Author            :    Aseesh
 *Description       :    This method is used for Action History Updation on form Submit.The action history Columns are configured in property file. Insert Statements are formed by fetching these columns and its value
 */

	public String actionAndDecisionHistoryUpdation(String historyName,String value) {
		Properties p = getCommonProperties();
		String fieldname = "";
		String data = "";
		mRepLogger.info("Inside "+historyName);
//		mRepLogger.info("Json obj : " + value);
		JSONParser parser = new JSONParser();
		JSONObject jsonobj;
		try {
			jsonobj = (JSONObject) parser.parse(value);
			Set<String> s = jsonobj.keySet();
			Iterator<String> i = s.iterator();
			while (i.hasNext()) {
				String key = i.next().toString();
//				 mRepLogger.info("Keys : "+key);
				if (p.getProperty(key.replace(" ", "_")).contains("(N)")) {
					 mRepLogger.info("Numeric FieldName : "+key);
					fieldname += p.getProperty(key.replace(" ", "_")).replace("(N)", "") + ",";
					// mRepLogger.info("FieldName : "+fieldname);
					if (jsonobj.get(key) != null && !jsonobj.get(key).equals("")) {
						data += jsonobj.get(key) + ",";
					} else {
						data += "null" + ",";

					}
				} else if(p.getProperty(key.replace(" ", "_")).contains("(D)")){ 
					
					fieldname += p.getProperty(key.replace(" ", "_")).replace("(D)", "") + ",";
					if (jsonobj.get(key) != null && !jsonobj.get(key).equals("")) {
						try {
							Date date1 = parseDate(jsonobj.get(key).toString(),false);
							String val = new SimpleDateFormat("yyyy-MM-dd").format(date1);
							data += "'" + val + "',";
						} catch (Exception e) {
							mErrLogger.info("Error in parsing the date in "+historyName+" grid and saving to DB-->" + e.getMessage());
							
						}

					}else{ 
						
						data += "null" + ",";
					}
					
				} else if(p.getProperty(key.replace(" ", "_")).contains("(DT)")){ 
					
					fieldname += p.getProperty(key.replace(" ", "_")).replace("(DT)", "") + ",";
					if (jsonobj.get(key) != null && !jsonobj.get(key).equals("")) {
						try {
							Date date1 = parseDate(jsonobj.get(key).toString(),true);
							String val = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(date1);
							data += "'" + val + "',";
						} catch (Exception e) {
							mErrLogger.info("Error in parsing the datetime in "+historyName+" grid and saving to DB-->" + e.getMessage());
							
						}

					}else{ 
						
						data += "null" + ",";
					}
					
				} else {
					fieldname += p.getProperty(key.replace(" ", "_")) + ",";
//					 mRepLogger.info("FieldName : "+fieldname);
					if (jsonobj.get(key) != null && !jsonobj.get(key).equals("")) {
						data += "'" + jsonobj.get(key) + "'" + ",";
					} else {
						data += "null" + ",";
					}
					
					//adding the grid transaction id to PID.
					if(key!=null && key.equalsIgnoreCase("Transaction ID")){ 
						
						fieldname += "PID,";
						data+= "'" + jsonobj.get(key) + "'" + ",";
					}
				}
//				mRepLogger.info("Data : " + data);
			}
			String tableName="";
			if(historyName.equalsIgnoreCase("ActionHistory")){ 
				
				tableName="ng_cmplx_actionhistory";
			}else{ 
				
				tableName="ng_cmplx_decisionhistory";
			}
			String insertquery = "INSERT INTO "+tableName+"(" + fieldname.substring(0, fieldname.length() - 1)
					+ ") VALUES (" + data.substring(0, data.length() - 1) + ")";
			mRepLogger.info("Insert Query : " + insertquery);
			//adding the newline characters if any in the remarks/comments.
			insertquery=insertquery.replaceAll("##NL##", "'+CHAR(10)+'");
			mRepLogger.info("Insert Query after replace of NL: " + insertquery);
			ifr.getDataFromDB(insertquery);
			mRepLogger.info("---"+tableName+" row added successfully---"+ifr.getValue("pInstanceID").toString()+" : "+new Date());
		} catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mErrLogger.info("Error in action history insert :"+e.getMessage());
			mErrLogger.info("Error in action history insert :"+e.getMessage(),e);
		}

		return "";
	}
	



/*
	 *Method Name       :    getWaiveOffIDs
	 *Input Parameters  :    NA
	 *Return Values     :    NA
	* Author            :    Aseesh
	 *Description       :    This method gets the charge waive off value from the master.
	 */
public String getWaiveOffIDs(){ 
	
	mRepLogger.info("Inside the getWaiveOffIDs, to get the waiveoff ids to waiveoff charges");
	
	JSONObject jobj=new JSONObject();
	String collType=ifr.getValue("qCollectionEntry_CollectionEntryType").toString();
	String q="SELECT WaiveOffType,ApportionFieldID FROM NG_Master_WaiveOff_Types WITH(NOLOCK) "
			+ "WHERE CollectionType='"+collType+"'";
	
	List<List<String>> idList=ifr.getDataFromDB(q);

	for(int i=0;i<idList.size();i++){ 
		List<String> l=idList.get(i);
		jobj.put(l.get(0), l.get(1));
	}
	
	return jobj.toString();

}

/*
 *Method Name       :    setRoleOfUser
 *Input Parameters  :    NA
 *Return Values     :    NA
* Author            :    Aseesh
 *Description       :    This method updates the role of the user in the role variable for updating in the decision history.
 */
public void setRoleOfUser(){ 
	
	mRepLogger.info("Inside setting the role of the user to role variable for decision history in method : setRoleOfUser");
	
	String username=ifr.getUserName();
	String roleQuery="SELECT LCS_User_Group FROM RLOS_MASTER_USERS WITH(NOLOCK) WHERE USER_ID='"+username+"'";
	List<List<String>> role=ifr.getDataFromDB(roleQuery);
	if(role.size()>0 && role.get(0).size()>0 && role.get(0).get(0)!=null){ 
		String r=role.get(0).get(0).split(",")[0];
		ifr.setValue("Role", r);
		
		
	}
	
	mRepLogger.info("Setting the Role variable to : "+ifr.getValue("Role").toString()+", referrig the user master.");
	
}
/*
 *Method Name       :    AddReferalToTempAllocation
 *Input Parameters  :    NA
 *Return Values     :    String -returnmsg
* Author            :    Aseesh
 *Description       :    This method inserts the referals made from front-end into NG_COLL_TemporaryAllocation table.
 */

public String AddReferalToTempAllocation()
{
	
	mRepLogger.info("Inside Add Referal Functionality");
	String returnmsg="false";
	//Calculate From and To date
	SimpleDateFormat Formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
	Properties p = getCommonProperties();
	int ReferMaxDays = Integer.parseInt(p.getProperty("ReferMaxDays"));
	Date date=new Date();
	Calendar c=Calendar.getInstance();
	c.setTime(date);
	c.add(Calendar.DATE,ReferMaxDays);
	//Get other details
	
	String FromUser=ifr.getUserName().toString();
	String ToUser=ifr.getValue("qRefer_Collection_Executive").toString();
	String LoanNumber=ifr.getValue("Loan_Account_No").toString();
	String Query="SELECT o.Org_Area,d.L_GK_Case_Status,L_GK_Case_Sub_Status,dbo.Bucket_Name (L_GK_PAR_Days) AS BucketName,Disbursement_Mode FROM NG_DUMP_LOAN_DET d\r\n" + 
			"INNER JOIN RLOS_MASTER_ORGANISATION o WITH (NOLOCK) ON d.Bank_Branch=o.Org_Unique_ID WHERE d.L_ACCT_NO='"+LoanNumber+"'";
	mRepLogger.info("Details Query : "+Query);
	List<List<String>> result=ifr.getDataFromDB(Query);
	mRepLogger.info("Result : "+result);
	String Case_Status=result.get(0).get(1).toString();
	String Case_Sub_Status=result.get(0).get(2).toString();	
	String Area=result.get(0).get(0).toString();
	String RepaymentMode=result.get(0).get(4).toString();
	String DPDBucket=result.get(0).get(3).toString();

	mRepLogger.info("From User : "+FromUser);
	mRepLogger.info("Case Status : "+Case_Status);
	mRepLogger.info("Case Sub Status : "+Case_Sub_Status);
	mRepLogger.info("DPD Bucket : "+DPDBucket);
	mRepLogger.info("To User : "+ToUser);
	mRepLogger.info("Area : " +Area);
	mRepLogger.info("RepaymentMode : "+RepaymentMode);
	mRepLogger.info("Loan Number : "+LoanNumber);
	mRepLogger.info("Current Date : "+Formatter.format(date));
	mRepLogger.info("To Date : "+Formatter.format(c.getTime()));
	
	//Form Insert Query
	if(!FromUser.equals("") && !Case_Status.equals("") && !Case_Sub_Status.equals("") && !DPDBucket.equals("") && !ToUser.equals("") && !Area.equals("") && !RepaymentMode.equals("") && !LoanNumber.equals(""))
	{
	returnmsg="true";
	String InsertQuery="INSERT INTO dbo.NG_COLL_TemporaryAllocation (Area, From_User, Case_Status, Case_Sub_Status, DPD_Bucket, Repayment_Mode, Loan_Number, To_User, From_Date, To_Date)\r\n" + 
			"VALUES ('"+Area+"','"+FromUser+"','"+Case_Status+"','"+Case_Sub_Status+"','"+DPDBucket+"','"+RepaymentMode+"','"+LoanNumber+"','"+ToUser+"','"+Formatter.format(date)+"','"+Formatter.format(c.getTime())+"')";
	mRepLogger.info("Insert Query  : "+InsertQuery);
	ifr.getDataFromDB(InsertQuery);
	}
return returnmsg;
}

/*
 *Method Name       :    ManualreceiptValidation
 *Input Parameters  :    String -receipt Number
 *Return Values     :    String -Flag
* Author            :    Aseesh
 *Description       :    This method checks if entered manual receiptNumber already exists are not  .
 */
public String ManualreceiptValidation(String receiptNumber) {
	String retFlag="true";
	String pid=ifr.getValue("pInstanceID").toString();
	mRepLogger.info("Inside ManualreceiptValidation method ");
	mRepLogger.info("Manual Receipt Number : "+receiptNumber);
	String sQuery="SELECT TOP 1 TransactionId FROM CMPLX_COLL_CRE_Collection_Receipt_Entry WITH (NOLOCK) WHERE Manual_Receipt_No='"+receiptNumber+"' AND TransactionId!='"+pid+"'";
	mRepLogger.info("Select Query : "+sQuery);
	List<List<String>> output=ifr.getDataFromDB(sQuery);
	mRepLogger.info("Query Output : "+output);
	if(!output.get(0).get(0).equalsIgnoreCase("") && output.get(0).get(0)!=null )
	{
		mRepLogger.info("Transaction ID  : "+output.get(0).get(0));
		retFlag="false";
	}
	
return retFlag;
}



//updating the wallet remaining cash limit for the field agents.

/*public void updateWalletAmtOnApproval(){ 
	
	mRepLogger.info("Inside updating the wallet amt to specific user after the Approval in method : updateWalletAmtOnApproval");
	
	
	
	
}*/


public boolean setTargetWS(){ 
	
	mRepLogger.info("<<<<<<<<<<<<Inside setting the Target WS for the selected action code>>>>>>>>>>>"+ ifr.getUserName());
	boolean b=true;
	
	try{ 
			String ac = ifr.getValue("qContactRecording_Action_Code").toString();
			
			if(ac!=null && !ac.trim().equals("")){ 
			
			String pid=ifr.getValue("pInstanceID").toString();
			Date d=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy HH:MM:SS");
			String ws = ifr.getActivityName();
			String query="select TargetWS from NG_Master_Action_Code WITH(NOLOCK) where "
					+ "WorkstepName = '"+ws+"' and ActionCode = '"+ac+"'";
			mRepLogger.info("<<<<<<<<<Actioncode Change for the PID>>>>>>>>"+pid+", Time ::::"+sdf.format(d));
			mRepLogger.info("Query for the TargetWS==>"+query);
			
			List<List<String>> Tws=ifr.getDataFromDB(query);
			if(Tws.size()>0 && Tws.get(0).size()>0){ 
				String finalTws=Tws.get(0).get(0);
				if(finalTws!=null && !finalTws.trim().equals("") && !finalTws.equalsIgnoreCase("null")){ 
					ifr.setValue("Target_Workstep", finalTws);
				}else{ 
					ifr.setValue("Target_Workstep", "");
				}
				
				mRepLogger.info("TargetWS==>"+finalTws);
				mRepLogger.info("<<<<<<<<<<<<>>>>>>>>>>");
				mRepLogger.info("TargetWS after setting to variable==>"+ifr.getValue("Target_Workstep").toString());
			}else{ 
				ifr.setValue("Target_Workstep", "");
				mRepLogger.info("TargetWS Not Found");
			}
			
		}else{ 
			ifr.setValue("Target_Workstep", "");
			mRepLogger.info("Action Code is empty, so skipping the query for TWS.");
		}
	
	}catch(Exception e){ 
		b=false;
		mErrLogger.info("Erro in setting the target WS::"+e.getMessage());
		mErrLogger.info("",e);
	}
	
	return b;
}

public String getMandatoryInwardDocsToValidate(String ws){ 
	mRepLogger.info("<<<<<<<<<<<<Inside getting the mandatory docs based on the action code & WS>>>>>>>>>>>");
//	String mandDocs="";
	String jsData="";
	String ac=ifr.getValue("qContactRecording_Action_Code").toString().replaceAll(" ", "_");
	Properties p = getCommonProperties();
	if(ac.equalsIgnoreCase("address_updation")){ 
		String adrType="";
		JSONArray addrData=ifr.getDataFromGrid("AddressUpdateTable");
		for(int i=0;i<addrData.size();i++){ 
			JSONObject row=(JSONObject) addrData.get(i);
			adrType=(String) row.get("Address Type");	
			jsData="Address Type "+adrType;
		}
		ac=ac+"_"+adrType;
	}
	String docs=p.getProperty("I_Doc_"+ws+"_"+ac);
	String docGrid=p.getProperty("I_DocGridID");
	JSONObject jobj=new JSONObject();
	jobj.put("docs",docs);
	jobj.put("docGrid",docGrid);
	jobj.put("jsData", jsData);
	return jobj.toString();
}

public String getCurrentUserRole(){ 
	
	mRepLogger.info("Initiator executeServerEvent Inside getCurrentUserRole: ");
	String userName = ifr.getUserName();
	String query = "select LCS_User_Group from RLOS_master_users with (NOLOCK) where user_id = '" + userName + "'";
	mRepLogger.info("Executing Query-->" + query);
	List<List<String>> userRole = ifr.getDataFromDB(query);
	mRepLogger.info("Output -->" + userRole);
	mRepLogger.info("userRole.get(0).get(0) -->" + userRole.get(0).get(0));
	if (userRole != null && !userRole.isEmpty()) {
		mRepLogger.info("User Role at Initiator Not Null");
		if(userRole.get(0).get(0).equalsIgnoreCase("telecaller")){ 
			
			ifr.setStyle("qContactRecording_Contacted", "visible", "true");
//			ifr.setStyle("qContactRecording_Contacted", "mandatory", "true");
		}else{ 
			
			ifr.setStyle("qContactRecording_Contacted", "visible", "false");
//			ifr.setStyle("qContactRecording_Contacted", "mandatory", "false");
		}
		
	}
	
	return userRole.get(0).get(0);
}

public BigDecimal getAmountsfromWaiver(String waiverType,List<List<String>> amts){ 
	
	BigDecimal d=new BigDecimal("0.00");
	
	if(amts.size()>0){ 
		for(int i=0;i<amts.size();i++){ 
			String type=amts.get(i).get(0);
			String amt=amts.get(i).get(1);
			if(waiverType!=null && type.equalsIgnoreCase(waiverType) && amt!=null && !amt.trim().equals("")){ 
				
				d=new BigDecimal(amt);
				break;
			}
		}
	}
	return d;
	
}


public String setInwardDocumentCategory(String appType){ 
	
	mRepLogger.info("Inside  setting the dropdown for the doc category for the inward documents");
	
	String returnVal="";
	
	try{ 
		Properties p=getCommonProperties();
		String activityName=ifr.getActivityName();
		String q="";
		if(appType!=null && appType.toLowerCase().startsWith("applicant")){ 
			q=p.getProperty("InwardDocCategoryApplicant").replace("##Activity##", activityName).replace("##App##", "applicant");
		}else if(appType.toLowerCase().startsWith("co-applicant") || appType.toLowerCase().startsWith("guarantor")){ 
			String s="";
			if(appType.toLowerCase().startsWith("co-applicant")){ 
				s="co-applicant";
			}else{ 
				s="guarantor";
			}
			q=p.getProperty("InwardDocCategoryCoApplicant").replace("##Activity##", activityName).replace("##CoApp##", s);
		}
		mRepLogger.info("Final query for the doc category :::"+q);

		List<List<String>> vals=ifr.getDataFromDB(q);
		for(int i=0;i<vals.size();i++){ 
			
			List<String> currv=vals.get(i);
			returnVal+=currv.get(0)+",";
		}
		if(returnVal.endsWith(",")){ 
			
			returnVal=returnVal.substring(0,returnVal.length()-1);
		}
		
	}catch(Exception e){ 
		
		mErrLogger.info("Error in setting the document category for the inward documents :"+e.getMessage());
	}

	return returnVal;
}

//setitng the pre closure apportionment details after waiveoff.
//getting the details fetched from per closure settlement, getting the approved details from waiver grid, 
//if any and then subtracting the waiver amounts and display in apportinment feilds.
public void setValuestoApportAfterChargesWaiveoff(){ 
	
	mRepLogger.info("<<<<<<<<<Inside setValuestoApportAfterChargesWaiveoff>>>>>>>>>>>");
	
	Map<String,BigDecimal> waiverMap=new HashMap<String,BigDecimal>();
	BigDecimal totalChrge=BigDecimal.ZERO;
	String collType=ifr.getValue("q_pre_part_closure_TypeOfSettlement").toString();
	JSONArray jarrWaiver=ifr.getDataFromGrid("ChargerWaiverTable");
	Properties p = getCommonProperties();
	String expiryQ=p.getProperty("WaiveOffExpiryQuery").toString();
	List<List<String>> expiryDaysList=ifr.getDataFromDB(expiryQ);
	int expiryDays=Integer.parseInt(expiryDaysList.get(0).get(0));
	
	if(jarrWaiver!=null)
	for(int i=0;i<jarrWaiver.size();i++){ 
		
		JSONObject jobjRow=(JSONObject) jarrWaiver.get(i);
		String charge=jobjRow.get("Waiver Type").toString();
		String status=jobjRow.get("Approval Status").toString();
		String approvedDt=jobjRow.get("Approved On").toString();
		if(status!=null && !status.trim().equals("") && status.equalsIgnoreCase("approved")){ 
			//checking the waiver is expired or not.
			Date appDt=parseDate(approvedDt,true);
			if(appDt!=null){ 
				Calendar c1 = Calendar.getInstance();
				c1.setTime(appDt);
				c1.add(Calendar.DATE, expiryDays);
				
				Calendar c2 = Calendar.getInstance();
				c2.setTime(new Date());

				mRepLogger.info(c1.getTime()+","+c2.getTime());
				if(c2.before(c1) || c2.equals(c1)){ 
					String amt=(jobjRow.get("Amt. Waived Off")==null || 
							jobjRow.get("Amt. Waived Off").toString().trim().equals("")) ? "0" : jobjRow.get("Amt. Waived Off").toString();
					if(!amt.equals("0")){ 
						if(waiverMap.containsKey(charge)){ 
							waiverMap.put(charge,waiverMap.get(charge).add(new BigDecimal(amt)));
						}else{ 
							waiverMap.put(charge, new BigDecimal(amt));
						}
						totalChrge=totalChrge.add(new BigDecimal(amt));
					}
				}
			}
			
		}
	}
	
	try{ 
		String chargApportMappingQ=p.getProperty("ApportChargerMappingQuery").replace("##COLL_TYPE##", collType);
		String closureID=collType.equalsIgnoreCase("pre closure") ? p.getProperty("ApportPreClosureAmtID") : p.getProperty("ApportPartPaymentAmtID");
		if(waiverMap.size()>0){ 
			//charges available for waiveoff
			mRepLogger.info("Charges waived off & approved:::"+waiverMap);
			mRepLogger.info("chargApportMappingQ::::::::"+chargApportMappingQ);
			List<List<String>> data=ifr.getDataFromDB(chargApportMappingQ);
			mRepLogger.info("chargApportMappingQ DATA::::::::"+data);
			for(int j=0;j<data.size();j++){ 
				
				List<String> l=data.get(j);
				String id=l.get(1);
				String chrg=l.get(0);
				String appChrge=(ifr.getValue(id)==null) ? "" : ifr.getValue(id).toString();
				if(waiverMap.containsKey(chrg)){ 
					
					BigDecimal waivChrge=waiverMap.get(chrg);
					if(!appChrge.trim().equals("") && 
							!new BigDecimal(appChrge).equals(BigDecimal.ZERO) && (waivChrge.compareTo(new BigDecimal(appChrge))==0 || waivChrge.compareTo(new BigDecimal(appChrge))==-1)){ 
						ifr.setValue(id, new BigDecimal(appChrge).subtract(waivChrge).toString());
					}
				}
				
			}
			
			Object o=ifr.getValue(closureID);
			String strTotApp="0";
			if(o!=null && !ifr.getValue(closureID).toString().trim().equals("")){ 
				strTotApp=ifr.getValue(closureID).toString();
			}
			BigDecimal totApp=(strTotApp.equals("0")) ? BigDecimal.ZERO : new BigDecimal(strTotApp);

//			BigDecimal totApp=(ifr.getValue(closureID)==null) ? BigDecimal.ZERO : new BigDecimal(ifr.getValue(closureID).toString());
			if(collType.equalsIgnoreCase("pre closure") && BigDecimal.ZERO.compareTo(totalChrge)==-1 && totalChrge.compareTo(totApp)==-1){ 
				ifr.setValue(closureID, totApp.subtract(totalChrge).toString());
//				mRepLogger.info("coll amt before : "+ifr.getValue("qCollectionEntry_Collection_Amount").toString());
				ifr.setValue("qCollectionEntry_Collection_Amount", totApp.subtract(totalChrge).toString());
//				mRepLogger.info("coll amt before : "+ifr.getValue("qCollectionEntry_Collection_Amount").toString());
			}else if(collType.equalsIgnoreCase("part payment")){ 
				ifr.setValue("qCollectionEntry_Collection_Amount", ifr.getValue(closureID).toString());
			}
			
			ifr.setValue("ForeclosureFlag","Waive off");//setting this for the T24 posting
		}else{ 
			//No charges available to waiveoff.
			ifr.setValue("ForeclosureFlag","No waive off");//setting this for the T24 posting
			ifr.setValue("qCollectionEntry_Collection_Amount", ifr.getValue(closureID).toString());
		}

		
	}catch(Exception e){ 
		
		mErrLogger.info("Error in subtracting the charges from the fetched data : "+e.getMessage());
		mErrLogger.info("---",e);
	}

}


//checking the date / datetime pattern
public static Date parseDate(String dt,boolean timeFlg){ 
	
		Properties p=getCommonPropertiesStatic();
		String availablePatterns="";
		if(timeFlg){ 
			availablePatterns=p.getProperty("AvailableDateTimePatterns");
		}else{ 
			availablePatterns=p.getProperty("AvailableDatePatterns");
		}
		
		String[] patternsArr=availablePatterns.split(",");
		for(int i=0;i<patternsArr.length;i++){ 
			
			try{ 
				Date date1 = new SimpleDateFormat(patternsArr[i]).parse(dt);
				return date1;
			}catch(ParseException e){ 
				
			}
			
		}
	mErrLogger.info("Unable to find the date format to parse the date ::::"+dt);
	return null;
}

//validating the pre closure (pre-closure should be raised only once for a loan No)
public Status preClosureCheck(){ 
	
	mRepLogger.info("<<<<Inside checking whether pre-closure is raised already for this current loan or not>>>>>");
	Object obj=ifr.getValue("qContactRecording_Action_Code");
	String actCode=(obj!=null ? obj.toString() : "");
	String loanNo=ifr.getValue("Loan_Account_No").toString();
	Status s=new Status();
	s.setStatus(true);	
	if(actCode.equalsIgnoreCase("Initiate Pre Closure")){ 
		Properties p=getCommonProperties();
		String q=p.getProperty("PreClosureCheck").replace("##Loan_Account_Number##", loanNo);
		
		List<List<String>> data= ifr.getDataFromDB(q);
		
		if(data.size()>0){ 
			String repayFlg=data.get(0).get(1);
			String ws=data.get(0).get(2);
			if(repayFlg!=null && !repayFlg.trim().equals("")){ 
				s.setStatus(false);
				s.setMsg("Pre Closure is already raised for this loan.");
				return s;
			}
			if((repayFlg==null || repayFlg.trim().equals("")) && 
					!ws.equalsIgnoreCase("exit") && !ws.equalsIgnoreCase("dms_archival")){ 
				s.setStatus(false);
				s.setMsg("Pre Closure is already raised for this loan");
				return s;
			}
		}		
	}

	
	
	return s;
}

//validating the sale/settlement/shortfall & populating the sale amt in apportionment based on the 
//selection of the collection type.
public Status saleSettlementShortfallCheck(){ 

	mRepLogger.info("<<<<Inside checking whether repo child has crossed quoteapproval & getting the final resale amt>>>>>");
	String collType=ifr.getValue("qCollectionEntry_CollectionEntryType").toString();
	String loanNo=ifr.getValue("Loan_Account_No").toString();
	Status s=new Status();
	s.setStatus(true);	
	
	if(collType.equalsIgnoreCase("sale") || collType.equalsIgnoreCase("settlement") || collType.equalsIgnoreCase("shortfall")){ 
		Properties p=getCommonProperties();
		String q=p.getProperty("SaleSettlementShortfallCheck").replace("##Loan_Account_Number##", loanNo);
		mRepLogger.info("Final query to check the sale/settlement/shortfall ::"+q);
		List<List<String>> data= ifr.getDataFromDB(q);
		mRepLogger.info("Data to check the sale/settlement/shortfall ::"+data);
		
		if(data.size()==0){ 
			s.setStatus(false);
			s.setMsg("First Repo has to be initiated on this loan no.");
			return s;
		}
		boolean b=false;
		for(int i=0;i<data.size();i++){ 
			String ws=data.get(i).get(1);
			String resaleAmt=data.get(i).get(2);
			if(ws!=null && ws.equalsIgnoreCase("Auction")){
				mRepLogger.info("YAY!!!!-- auction found");
				b=true;
				ifr.setValue("q_Apportionment_I_Sale_Settlement_Amount",resaleAmt);
				break;
			}
		}
		if(!b){ 
			s.setStatus(false);
			s.setMsg("First process the Quote Approval in the Repo Initiation.");
			ifr.setValue("q_Apportionment_I_Sale_Settlement_Amount","0");
			return s;
		}else{ 
			s.setStatus(true);
			return s;
		}
				
	}

	return s;
}

public Status repoCheck(){ 
	
	mRepLogger.info("<<<<Inside checking whether repo is already raised for this loan or not : repoCheck>>>>>");
	Status s=new Status();
	s.setStatus(true);	
	String loanNo=ifr.getValue("Loan_Account_No").toString();
	try{ 
		Properties p=getCommonProperties();
		String q=p.getProperty("RepoCheck").replace("##Loan_Account_Number##", loanNo);
		mRepLogger.info("Final query to check the repo::"+q);
		List<List<String>> l=ifr.getDataFromDB(q);
		for(int i=0;i<l.size();i++){ 
			List<String> sl=l.get(i);
			String flg=sl.get(0);
			String ws=sl.get(1);
			
			if(flg!=null && !flg.trim().equals("")){ 
				s.setStatus(false);
				s.setMsg("Repo already initiated for this loan no.");
				break;
			}
			if((flg==null || flg.trim().equals("")) && !ws.equalsIgnoreCase("exit") && !ws.equalsIgnoreCase("DMS_Archival")){ 
				s.setStatus(false);
				s.setMsg("Repo already initiated for this loan no.");
				break;
			}
		}
		
	}catch(Exception e){ 
		mErrLogger.info("Error in checking the repo is already raised or not : repoCheck "+e.getMessage());
		mErrLogger.info("",e);
	}
	
	return s;
	
}

public String getLegalAndRepoFlags(){ 
	
	mRepLogger.info("<<<<<<<<<<<<<<Inside getting the legal & repo flags for enabling the collection type values : getLegalAndRepoFlags>>>>>>>>>>> ");
	String r="false";
	String l="false";
	String role=ifr.getValue("Role").toString();
	
	try{ 
		
		if(role!=null && (role.equalsIgnoreCase("OE-B") || role.equalsIgnoreCase("OM-B"))){ 
			
			String ac=ifr.getValue("qContactRecording_Action_Code").toString();
			if(ac!=null && ac.equalsIgnoreCase("collection entry")){ 
				String loan=ifr.getValue("Loan_Account_No").toString();
				try{ 
					Properties p=getCommonProperties();
					String repoFlag=p.getProperty("GetRepoMarkingFlag").replace("##Loan_Acc_No##", loan);
					String legalFlag=p.getProperty("GetLegalMarkingFlag").replace("##Loan_Acc_No##", loan);
					List<List<String>> rl=ifr.getDataFromDB(repoFlag);
					List<List<String>> ll=ifr.getDataFromDB(legalFlag);
					
					for(int i=0;i<rl.size();i++){ 
						String s=rl.get(i).get(1);
						if(s!=null && (s.trim().equals("1-1"))){ 
							r="true";
							break;
						}
					}
					for(int j=0;j<ll.size();j++){ 
						String s=ll.get(j).get(1);
						if(s!=null && (s.trim().equals("1-1"))){ 
							l="true";
							break;
						}
					}
					
				}catch(Exception e){ 
					mErrLogger.info("Error in getLegalAndRepoFlags :::"+e.getMessage());
					mErrLogger.info("",e);
				}
			}
		}
		
	}catch(Exception e){ 
		
		mErrLogger.info("Error in getting the flags for the legal & repo"+e.getMessage());
		mErrLogger.info("",e);
	}
	
	return r+","+l;
}

public String getMandatoryOutwardDocsToValidate(String ws){ 
	mRepLogger.info("<<<<<<<<<<<<Inside getting the mandatory outward docs based on the WS>>>>>>>>>>>");
//	String mandDocs="";
	String jsData="";
	
	Properties p = getCommonProperties();

	String docs=p.getProperty("O_Doc_"+ws);
	String docGrid=p.getProperty("O_DocGridID");
	JSONObject jobj=new JSONObject();
	jobj.put("docs",docs);
	jobj.put("docGrid",docGrid);
	jobj.put("jsData", jsData);
	return jobj.toString();
}

public void setSanctionAmount(){ 
	mRepLogger.info("<<<<<<<<<<<<Inside getting the & setting the sanction amount to ext table>>>>>>>>>>>");
	
	try{
		Properties p = getCommonProperties();
		String loanNo=ifr.getValue("Loan_Account_No").toString();
		String pid = ifr.getValue("pInstanceID").toString();
		String q=p.getProperty("SanctionAmountQuery").replace("##Loan_Account_No##", loanNo).replace("##PID##", pid);
		ifr.getDataFromDB(q);
		
		/*if(l.size()>0 && l.get(0).size()>0 && l.get(0).get(0)!=null && !l.get(0).get(0).trim().equals("")){ 
			
			ifr.setValue("Sanction_Amount", l.get(0).get(0));
		}*/
	}catch(Exception e){ 
		
		mErrLogger.info("Error in setting the sanction amount ::"+e.getMessage());
		mErrLogger.info("",e);
	}
}

public void setQuoteAmountsToWords(){ 
	mRepLogger.info("<<<<<<<<<<<<Inside getting the & setting the quote amount to words in the cmplx table for document purpose>>>>>>>>>>>");
	
	try{
		String pid=ifr.getValue("pInstanceID").toString();
		String q="SELECT insertionOrderId,Quote_Amount FROM cmplx_repo_qd_grid WITH(NOLOCK) WHERE pid='"+pid+"'";
		List<List<String>> l=ifr.getDataFromDB(q);
		for(int i=0;i<l.size();i++){ 
			
			List<String> currL=l.get(i);
			String amt=currL.get(1);
			String ioid=currL.get(0);
			mRepLogger.info("amounts to convert to words in quote grid ::"+amt);
			if(amt!=null && !amt.trim().equals("")){ 
				
				String words=numberToWord(Integer.parseInt(amt));
				mRepLogger.info("words equivalent of ::"+amt+" ::"+words);
				
				String updtQ="UPDATE cmplx_repo_qd_grid SET QuoteAmountWords='"+words+"' WHERE insertionOrderId="+ioid;
				ifr.getDataFromDB(updtQ);
			}
			
		}
		
		
	}catch(Exception e){ 
		
		mErrLogger.info("Error in setting the quote amounts to words ::"+e.getMessage());
		mErrLogger.info("",e);
	}
}

public Status auctionCheck(){ 
	
	mRepLogger.info("<<<<Inside checking whether sale/settlement/shortfall is already raised for this loan or not with collection entry action code: auctionCheck>>>>>");
	Status s=new Status();
	s.setStatus(true);	
	String loanNo=ifr.getValue("Loan_Account_No").toString();
	try{ 
		Properties p=getCommonProperties();
		String q=p.getProperty("AuctionCheck").replace("##Loan_Acc_No##", loanNo);
		mRepLogger.info("Final query to check the auction check::"+q);
		List<List<String>> l=ifr.getDataFromDB(q);
		mRepLogger.info("Final data to check the auction check::"+l);
		
		if(l.size()>0){ 
			
			mRepLogger.info("Sale/shortfall/settlement raised in the parent WI, Please proceed releasing the vehicle");
		}else{ 
			mRepLogger.info("Sale/shortfall/settlement not found in the parent WI. First raise it and then submit the WI from auction.");
			
			s.setStatus(false);
			s.setMsg("First perform Collection entry with Sale/Settlement/Shortfall in parent WI before submitting.");
			
		}

		
	}catch(Exception e){ 
		mErrLogger.info("Error in checking the repo is already raised or not : repoCheck "+e.getMessage());
		mErrLogger.info("",e);
	}
	
	return s;
	
}

//UPI Payment Request and Status Check  

public static String txnID = "";

public String onClickSendRequest(IFormReference ifr, CollectionCommonMethod cm) throws Exception{
  try{
	  mRepLogger.info("Inside onClickSendRequest in CollectionCommonMethod.java");    
  String msg = "";
	String flag = "";
	JSONObject jObjReturn = new JSONObject();
	String inputStream = "";
	JSONParser jParse = new JSONParser();
	JSONObject inputjson = new JSONObject();
	JSONObject resjson=new JSONObject();
//	inputStream = new String(data.getStream(), "UTF-8");
//	inputjson = (JSONObject) jParse.parse(inputStream);
	mRepLogger.info( "Inside onClickSendRequest() call with request from client::");
	System.out.println("Inside onClickSendRequest() call with request from client::");
	
	//String paymentType = (String) inputjson.get("paymentType");
	//String pid = (String) inputjson.get("pid");
	//String loanNo = (String) inputjson.get("loanNo");
	
	String paymentType =ifr.getValue("qUpiPaymentDet_PaymentType").toString();
	String pid =ifr.getValue("pInstanceID").toString();
	String loanNo = ifr.getValue("Loan_Account_No").toString();
   
	mRepLogger.info("paymentType:"+paymentType+" pid:"+pid+" loanNo:"+loanNo);
	
	propertyReader = ReadProperty.getInstance(System.getProperty("user.dir") + System.getProperty("file.separator")
			+ "Config" + System.getProperty("file.separator") + "commonServices.ini");

	if (paymentType != null && !paymentType.trim().equals("")) {

		if (paymentType.equalsIgnoreCase("Single Collect")) {

			String url = propertyReader.getvalue("ValidateVPAURL").trim();
			String merchantquery="Select DISTINCT MerchantID,MerchantChanID from dbo.NG_MASTER_UPI_PARAMS WITH (NOLOCK) where UPITYPE='QR'";
		   List<List<String>> merchantresp=ifr.getDataFromDB(merchantquery);
		   mRepLogger.info("Merchant Details Query Result::"+merchantresp);
		   //String merchId = propertyReader.getvalue("MerchantID").trim();
			String merchId=merchantresp.get(0).get(0);
			//String merchChanId = propertyReader.getvalue("MerchantChanID").trim();
		   String merchChanId=merchantresp.get(0).get(1);
//			String merchId = propertyReader.getvalue("MerchantID").trim();
//			String merchChanId = propertyReader.getvalue("MerchantChanID").trim();
			
			String custVPA = ifr.getValue("qUpiPaymentDet_CustVPA").toString();
			String amt = ifr.getValue("qCollectionEntry_Collection_Amount").toString();
			String unqCustID = ifr.getValue("CustomerID").toString();
			String txndtl = ifr.getValue("qUpiPaymentDet_Pay_Remarks").toString();	
			//txndtl = "ok";
			mRepLogger.info("url:"+url+" merchId:"+merchId+" merchChanId:"+merchChanId+" custVPA:"+custVPA);
			if (url != null && merchId != null && merchChanId != null && custVPA != null) {

				// first validate the cust VPA
				mRepLogger.info("PublicKey:"+propertyReader.getvalue("PublicKey"));
				String validateVPA = validateCustVPA(pid, loanNo, url, merchId, merchChanId, custVPA,
						propertyReader.getvalue("PublicKey"), cm);
             resjson=(JSONObject)jParse.parse(validateVPA);
             validateVPA=(String)resjson.get("result");
      
				if (validateVPA.equalsIgnoreCase("SUCCESS")) {
//					merchChanId=merchChanId.trim();
					url = propertyReader.getvalue("SingleCollectURL").trim();
					String collectStatusres = singleCollect(pid, loanNo, url, merchId, merchChanId, custVPA,
							propertyReader.getvalue("PublicKey"), amt, propertyReader.getvalue("Currency"),
							unqCustID, txndtl, propertyReader.getvalue("SingleCollectCallBack"),
							propertyReader.getvalue("SingleCollectExpiry"), cm);
					mRepLogger.info("Amount:"+amt+" Currency:"+propertyReader.getvalue("Currency")+" SingleCollectCallBack:"+propertyReader.getvalue("SingleCollectCallBack")+" txndtl:"+txndtl+" SingleCollectExpiry:"+propertyReader.getvalue("SingleCollectExpiry"));
					JSONObject singlecollectres=(JSONObject) jParse.parse(collectStatusres);
					String collectStatus="";
					collectStatus=(String)singlecollectres.get("result");

					if (collectStatus.equalsIgnoreCase("Accepted Collect Request")) {
						msg = "Collect Request successfully sent";
						flag = "True";
						jObjReturn.put("Status", flag);
						jObjReturn.put("Msg", msg);
						jObjReturn.put("TxnID", txnID);
						//sr.setStream(jObjReturn.toString().getBytes());
						return (jObjReturn.toString());

					} else {

						msg =collectStatus;
						flag = "False";
						jObjReturn.put("Status", flag);
						jObjReturn.put("Msg", msg);
						//sr.setStream(jObjReturn.toString().getBytes());
						return (jObjReturn.toString());
					}
				} else {

					msg = validateVPA;
					flag = "False";
					jObjReturn.put("Status", flag);
					jObjReturn.put("Msg", msg);
					//sr.setStream(jObjReturn.toString().getBytes());
					return (jObjReturn.toString());
				}
			} else {

				msg = "Please enter all the required data";
				flag = "False";
				jObjReturn.put("Status", flag);
				jObjReturn.put("Msg", msg);
				//sr.setStream(jObjReturn.toString().getBytes());
				return (jObjReturn.toString());
			}

		}
	} else {
		msg = "Payment Type is not valid.";
		flag = "False";
		jObjReturn.put("Status", flag);
		jObjReturn.put("Msg", msg);
		//sr.setStream(jObjReturn.toString().getBytes());
		return (jObjReturn.toString());

	}
	return (jObjReturn.toString());
	
	  
  }
  catch(Exception e){
	  JSONObject errjson=new JSONObject();
	  mRepLogger.info("Exception ::"+e.getMessage());
	  mErrLogger.info("Exception ::"+e.getMessage());
	  System.out.println("Exception ::"+e.getMessage());
		e.printStackTrace();
		errjson.put("Status","False");
		errjson.put("Msg",e.getMessage());
		return (errjson.toString());
  }

}
public String validateCustVPA(String pid, String loanNo, String url, String merchID, String merchChanID,
		String custVPA, String pubKey, CollectionCommonMethod cm) {
	try{


		 boolean b = true;
		 String userName = "";
		 String resp="";
	   String session = "";
	   String Status="";
	   JSONParser jParse = new JSONParser();
	   LocalDateTime myDateObj = LocalDateTime.now();
		DateTimeFormatter DBFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		String dateforDB=myDateObj.format(DBFormatObj);
//		Set<String> NColumns = FinalJson.keySet();
		mRepLogger.info("Inside validateCustVPA");
		System.out.println("Inside validateCustVPA");
		try {
			mRepLogger.info("Inside try block of validateCustVPA");
			String checksum = merchID.trim() + merchChanID.trim() + custVPA.trim();
			mRepLogger.info("Checksum in validateCustVPA: "+checksum);
			mRepLogger.info("Public Key in validateCustVPA::"+pubKey);//
			CommonWebserviceCalls cws = new CommonWebserviceCalls();
			String enc_checksum = cws.encryptData(pubKey, checksum,cm);
			mRepLogger.info("Encrypted checksum in validateCustVPA: "+enc_checksum);
			// calling the service.
			JSONObject jobj = new JSONObject();
			jobj.put("merchId", merchID.trim());
			jobj.put("merchChanId", merchChanID.trim());
			jobj.put("customerVpa", custVPA.trim());
			jobj.put("checkSum", enc_checksum.trim());
			mRepLogger.info(  "Final Request::"+jobj);
			System.out.println("Final Request::"+jobj);
//			String resp = cws.sendHTTPRequest(url, "Content-Type", jobj.toString());
//			JSONObject resp = validateUPIExecution(url, merchID, merchChanID, custVPA, enc_checksum);
			HTTPRequestResponse hrr=new HTTPRequestResponse();
			resp =hrr.sendHTTPRequest(url, "ValidateCustVPA", jobj.toString(),cm);
			mRepLogger.info( "Final Response::"+resp);
			System.out.println("Final Response::"+resp);
			// handling the response below to check the cust vpa validation
			// inserting the req & resp in history table
//			sUser user = (User) ThreadUtils.getThreadVariable("user");
//				if (user == null || user.getAuthenticationToken() == null)
//					throw new Exception("cannot fetch without user");
	//
//				userName = user.getUserName();
//				session = user.getAuthenticationToken();			
	//
//			} else if (AuthFlag.equalsIgnoreCase("LDAP")) {
//				String user = getXMLValueOfKey("LCS", "LDAP", "STypeUserName");
//				String pass = getXMLValueOfKey("LCS", "LDAP", "STypeUserPass");
//				session = LoanCustomRequest.connectCabinetLDAPMethod(ip, port, cabinet, user, pass, session, AuthFlag);
	//
//			}
	     JSONObject validatecustVPAres=(JSONObject) jParse.parse(resp);					
			Status=(String)validatecustVPAres.get("result");
			
			String values = "'" + pid + "','" + loanNo + "','"+dateforDB+"','validateCustVPA','" + jobj.toString() + "','"+ resp + "','" + Status + "','" + custVPA + "'";
			String columns = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,CUST_VPA";
			String table = "LCS_UPI_History_Table";
			String InsertQuery="INSERT INTO dbo."+table+" ("+columns+") VALUES ("+values+")";
			mRepLogger.info("Insert Query  : "+InsertQuery);
			List<String> result = ifr.getDataFromDB(InsertQuery);
			mRepLogger.info("Validation of Customer VPA details is updated in LCS_UPI_History_Table"+result);
			System.out.println("Validation of Customer VPA details is updated in LCS_UPI_History_Table"+result);
			

		} catch (Exception e) {
			JSONObject errjson=new JSONObject();
			  mRepLogger.info("Exception ::"+e.getMessage());
			  mErrLogger.info("Exception ::"+e.getMessage());
			  System.out.println("Exception ::"+e.getMessage());
				e.printStackTrace();
				errjson.put("Status","False");
				errjson.put("Msg",e.getMessage());
				return (errjson.toString());
		}

		return resp;
		
	}
	catch(Exception e){
		JSONObject errjson=new JSONObject();
		  mRepLogger.info("Exception ::"+e.getMessage());
		  mErrLogger.info("Exception ::"+e.getMessage());
		  System.out.println("Exception ::"+e.getMessage());
			e.printStackTrace();
			errjson.put("Status","False");
			errjson.put("Msg",e.getMessage());
			return (errjson.toString());
	}
}

// single collect request
public String singleCollect(String pid, String loanNo, String url, String merchID, String merchChanID,
		String custVPA, String pubkey, String amt, String Currency, String unqCustID, String txndtl,
		String SingleCollectCallBack, String SingleCollectExpiry, CollectionCommonMethod cm) {

	boolean b = true;
	String userName = "";
	String session = "";
 String resp="";
 String merchtranid="";
 String status="";
 String type="Single Collect";
 JSONParser jparse=new JSONParser();
 JSONObject singlecollres=new JSONObject();
 mRepLogger.info( "Inside singleCollect() call ");
 System.out.println("Inside singleCollect() call");
 mRepLogger.info( "Parameters:: pid:"+pid+" loanNo:"+loanNo+" url:"+url+" merchID:"+merchID+" merchChanID:"+merchChanID+" custVPA:"+custVPA+" pubkey:"+pubkey+" amt:"+amt+" Currency:"+Currency+" unqCustID:"+unqCustID+" txndtl:"+txndtl+" SingleCollectCallBack:"+SingleCollectCallBack+" SingleCollectExpiry:"+SingleCollectExpiry);
 try {
		LocalDateTime myDateObj = LocalDateTime.now();
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss");
		DateTimeFormatter DBFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		String dateforDB=myDateObj.format(DBFormatObj);
		String formattedDate = myDateObj.format(myFormatObj);
		String unqOrderID = "O" + unqCustID.concat(formattedDate);
		txnID = "T" + unqCustID.concat(formattedDate);
     
		mRepLogger.info( "txnID:"+txnID);
		String checksum = merchID.trim() + merchChanID.trim() + txnID.trim() + unqCustID.trim() + amt.trim() + txndtl.trim() + Currency.trim() + unqOrderID.trim() + custVPA.trim()
				+ SingleCollectExpiry.trim() + SingleCollectCallBack.trim();
		mRepLogger.info("Checksum in singleCollect:"+checksum);
		CommonWebserviceCalls cws = new CommonWebserviceCalls();
		String enc_checksum = cws.encryptData(pubkey, checksum,cm);
		mRepLogger.info("Encrypted checksum in singleCollect:"+enc_checksum);
		// calling the service.
		JSONObject jobj = new JSONObject();
		jobj.put("amount", amt.trim());
		jobj.put("currency", Currency.trim());
		jobj.put("customervpa", custVPA.trim());
		jobj.put("expiry", SingleCollectExpiry.trim());
		jobj.put("merchchanid", merchChanID.trim());
		jobj.put("merchid", merchID.trim());
		jobj.put("orderid", unqOrderID.trim());
		jobj.put("txndtl", txndtl.trim());
		jobj.put("unqcustid", unqCustID.trim());
		jobj.put("unqtxnid", txnID.trim());
		jobj.put("callBackUrl", SingleCollectCallBack.trim());
		jobj.put("checksum", enc_checksum.trim());
		mRepLogger.info( "Request before HTTPRequestResponse Call::"+jobj);
//		String resp = cws.sendHTTPRequest(url, "Context-Type", jobj.toString());
		HTTPRequestResponse hrr=new HTTPRequestResponse();
		resp=hrr.sendHTTPRequest(url, type , jobj.toString(), cm);
		mRepLogger.info("Response from HTTPRequestResponse Call::"+resp);
		singlecollres=(JSONObject)jparse.parse(resp);		
		merchtranid=(String)singlecollres.get("merchTranId");
		status=(String)singlecollres.get("result");
	   
		//start of updating UPI payment for single collect request
		String values = "'" + pid + "','" + loanNo + "','"+dateforDB+"','singleCollect','" + jobj.toString() + "','"+ resp + "','"+status+"','" + txnID + "','" + unqOrderID +"','" + custVPA + "','"+merchtranid+"'" ;
		String columns = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,TXNID,ORDERID,CUST_VPA,MERCHTRANID";
		String table = "LCS_UPI_History_Table";
		
		mRepLogger.info("Single Collect VPA details is getting updated in LCS_UPI_History_Table");
		System.out.println("Single Collect VPA details is getting updated in LCS_UPI_History_Table");			
		String InsertQuery="INSERT INTO dbo."+table+" ("+columns+") VALUES ("+values+")";
		mRepLogger.info("Insert Query  : "+InsertQuery);
		List<String> result = ifr.getDataFromDB(InsertQuery);
		mRepLogger.info("Single Collect VPA details is updated in LCS_UPI_History_Table"+result);
		System.out.println("Single Collect VPA details is updated in LCS_UPI_History_Table"+result);

		//End of updating UPI payment for single collect request

	} catch (Exception e) {
		mRepLogger.info("Exception ::"+e.getMessage());
		mErrLogger.info("Exception ::"+e.getMessage());
		System.out.println("Exception ::"+e.getMessage());
		e.printStackTrace();
		b = false;

	}
	mRepLogger.info( "Response send to client::"+resp);
	System.out.println("Response send to client::"+resp);
	return resp;
}

//For Checking the UPI Payment Status
public String checkUPIPayment(IFormReference ifr, CollectionCommonMethod cm) throws Exception {
	try{
       

	    mRepLogger.info("checkUPIPayment called-->");

	    String msg = "";
	    String flag = "";
	    String type = "";
	    JSONObject jObjReturn = new JSONObject();
	    String inputStream = "";
	    JSONParser jParse = new JSONParser();
	    JSONObject inputjson = new JSONObject();
	    //inputStream = new String(data.getStream(), "UTF-8");
	    //inputjson = (JSONObject) jParse.parse(inputStream);
	    mRepLogger.info("Inside checkUPIPayment() call with request from client::");
	    System.out.println("Inside checkUPIPayment() call with request from client::");

	    String checkStatusres = "";
	    String pid = ifr.getValue("pInstanceID").toString();
	    String loanNo = ifr.getValue("Loan_Account_No").toString();
	    String paymentType = ifr.getValue("qUpiPaymentDet_PaymentType").toString();
	    propertyReader = ReadProperty.getInstance(System.getProperty("user.dir") + System.getProperty("file.separator") +
	        "Config" + System.getProperty("file.separator") + "commonServices.ini");

       String merchantquery="Select DISTINCT MerchantID,MerchantChanID from dbo.NG_MASTER_UPI_PARAMS WITH (NOLOCK) where UPITYPE='QR'";
       List<List<String>> merchantresp=ifr.getDataFromDB(merchantquery);
       mRepLogger.info("Merchant Details Query Result::"+merchantresp);
       //String merchId = propertyReader.getvalue("MerchantID").trim();
	    String merchId=merchantresp.get(0).get(0);
	    //String merchChanId = propertyReader.getvalue("MerchantChanID").trim();
       String merchChanId=merchantresp.get(0).get(1);
       
	    String unqCustID = ifr.getValue("CustomerID").toString();
	    String txndtl = ifr.getValue("qUpiPaymentDet_Pay_Remarks").toString();
	    String UPIMobileNo = ifr.getValue("qUpiPaymentDet_MobNo").toString();

	    String collectStatus = "";
	    String push2VPAStatus = "";
	    String token = "";
	    String url = "";
	    String TransTempID = "";
	    String userName = "";
	    String session = "";
	    String axistxnid = "";
	    String merchtranid = "";
	    
	    String currency = propertyReader.getvalue("Currency").toString();
	    String transID = ifr.getValue("qUpiPaymentDet_TranID").toString();
	    String custVPA = ifr.getValue("qUpiPaymentDet_CustVPA").toString();
	    
	    JSONObject jobj = new JSONObject();
		 JSONObject p2vrequest=new JSONObject();
		
	    mRepLogger.info("pid:"+pid+" loanNo:"+loanNo+" paymentType:"+paymentType+" merchId:"+merchId+" merchChanId:"+merchChanId+" unqCustID:"+unqCustID+" txndtl:"+txndtl+" UPIMobileNo:"+UPIMobileNo+" transID:"+transID+" custVPA:"+custVPA);
	    LocalDateTime myDateObj = LocalDateTime.now();
	    DateTimeFormatter DBFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	    String dateforDB = myDateObj.format(DBFormatObj);

	    //cabinet and session details obtaining starts 		  
//	    String cabinet = getXMLValueOfKey("LCS", "DataBase", "cabinet");
//	    String ip = getXMLValueOfKey("LCS", "DataBase", "ip");
//	    String port = getXMLValueOfKey("LCS", "DataBase", "port");
//	    String AuthFlag = getValueFromXMLCustom("AuthenticationType", "LoginType");
//	    if (AuthFlag.equalsIgnoreCase("OD")) {
//	        User user = (User) ThreadUtils.getThreadVariable("user");
//	        if (user == null || user.getAuthenticationToken() == null)
//	            throw new Exception("cannot fetch without user");
//	        userName = user.getUserName();
//	        session = user.getAuthenticationToken();
//	    } else if (AuthFlag.equalsIgnoreCase("LDAP")) {
//	        String user = getXMLValueOfKey("LCS", "LDAP", "STypeUserName");
//	        String pass = getXMLValueOfKey("LCS", "LDAP", "STypeUserPass");
//	        session = LoanCustomRequest.connectCabinetLDAPMethod(ip, port, cabinet, user, pass, session, AuthFlag);
//	    }
	    // cabinet and session details obtaining ends



	    if (paymentType.equalsIgnoreCase("Single Collect") || paymentType.equalsIgnoreCase("QR")) {
	    	mRepLogger.info("UPI Payment Type::" + paymentType);
	        System.out.println("UPI Payment Type::" + paymentType);
	        //	        String amt = ((String) inputjson.get("amt")).trim();
	        type = "Check Status";

	        if (paymentType.equalsIgnoreCase("Single Collect"))
	            url = propertyReader.getvalue("SingleCollectCheckStatusURL").trim();
	        else if (paymentType.equalsIgnoreCase("QR"))
	            url = propertyReader.getvalue("QRCheckStatusURL").trim();
	        
	        mRepLogger.info(paymentType+" URL:"+url);
	        String checksum = merchId.trim() + merchChanId.trim() + transID.trim() + UPIMobileNo.trim();
	        CommonWebserviceCalls cws = new CommonWebserviceCalls();
	        String enc_checksum = cws.encryptData(propertyReader.getvalue("PublicKey"), checksum,cm);

	        if (url != null && merchId != null && merchChanId != null) {
	            jobj.put("merchid", merchId.trim());
	            jobj.put("merchchanid", merchChanId.trim());
	            jobj.put("tranid", transID.trim());
	            jobj.put("mobilenumber", UPIMobileNo.trim());
	            jobj.put("checksum", enc_checksum.trim());
	            mRepLogger.info("Request for HTTPRequestResponse Call::" + jobj);
	            System.out.println("Request for HTTPRequestResponse Call::" + jobj);
	            HTTPRequestResponse hrr = new HTTPRequestResponse();
	            checkStatusres = hrr.sendHTTPRequest(url, type, jobj.toString(), cm);
	            System.out.println("Response for Check Status ::" + checkStatusres);
	            mRepLogger.info("Response from HTTPRequestResponse Call::" + checkStatusres);
	            JSONObject singlecollectres = (JSONObject) jParse.parse(checkStatusres);
	            collectStatus = (String) singlecollectres.get("result");
	            TransTempID = (String) singlecollectres.get("tranid");
	            axistxnid = (String) singlecollectres.get("txnid");

	            if (collectStatus.equalsIgnoreCase("S")) {
	                msg = "Success";
	                flag = "True";

	            } else {
	                if (collectStatus.equalsIgnoreCase("P"))
	                    msg = "Pending";
	                else if (collectStatus.equalsIgnoreCase("E"))
	                    msg = "Expired";
	                else if (collectStatus.equalsIgnoreCase("R"))
	                    msg = "Reject";
	                else if (collectStatus.equalsIgnoreCase("F"))
	                    msg = "Failed";
	                else if (collectStatus.equalsIgnoreCase("D"))
	                    msg = "Deemed";
	                else
	                    msg = collectStatus;
	                flag = "False";
	            }
	            //updating transaction details in Database  transID  custVPA
	            String values = "'" + pid + "','" + loanNo + "','" + dateforDB + "','checkUPIPayment','" + jobj.toString() + "','" +checkStatusres + "','" + msg + "','" + transID + "','" + custVPA + "','" + axistxnid + "'";
	            String columns = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,TXNID,CUST_VPA,ORDERID";
	            String table = "LCS_UPI_History_Table";

	            mRepLogger.info(paymentType + " VPA details for checkUPIPayment is getting updated in LCS_UPI_History_Table");
	            System.out.println(paymentType + " VPA details for checkUPIPaymentt is getting updated in LCS_UPI_History_Table");
	            String InsertQuery="INSERT INTO dbo."+table+" ("+columns+") VALUES ("+values+")";
	    		    mRepLogger.info("Insert Query  : "+InsertQuery);
	    		    List<String> result = ifr.getDataFromDB(InsertQuery);
	            mRepLogger.info(paymentType + " VPA details for checkUPIPayment is updated in LCS_UPI_History_Table" + result);
	            System.out.println(paymentType + " VPA details for checkUPIPayment is updated in LCS_UPI_History_Table" + result);
	        }
	    } else if(paymentType.equalsIgnoreCase("Push to VPA")){
			type="Push to VPA";
			LocalDateTime myDtObj = LocalDateTime.now();
			DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss");
			DateTimeFormatter DBFormatOb = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String formattedDate = myDtObj.format(myFormatObj);
			String transactionID = "T" + unqCustID.concat(formattedDate);
			String unqOrderID = "O" + unqCustID.concat(formattedDate);
		    String amt = ifr.getValue("qCollectionEntry_Collection_Amount").toString().trim();//
		    String customerVpa = ifr.getValue("qUpiPaymentDet_CustVPA").toString().trim();
		    String remarks = ifr.getValue("qUpiPaymentDet_Pay_Remarks").toString().trim();
		    String customerMobileno = ifr.getValue("qUpiPaymentDet_MobNo").toString().trim();
			String CollectTxnID="";
			String custrefID="";
			String checkstatus="";
		    flag="False";
		   url = propertyReader.getvalue("TokenGenerationURL").trim();
		   String checksum = merchId.trim() + merchChanId.trim() + transactionID.trim() + amt.trim() + customerVpa.trim() + currency.trim() + remarks.trim();
	       CommonWebserviceCalls cws = new CommonWebserviceCalls();
	       String enc_checksum = cws.encryptData(propertyReader.getvalue("PublicKey"), checksum,cm);
		   if (url != null && merchId != null && merchChanId != null) {
//                    JSONObject jobj=new JSONObject();
                    jobj.put("merchId", merchId.trim());
                    jobj.put("merchChanId", merchChanId.trim());
                    jobj.put("unqTxnId", transactionID.trim());
                    jobj.put("amount", amt.trim());
                    jobj.put("customerVpa", customerVpa.trim());
                    jobj.put("currency", currency.trim());
                    jobj.put("remarks", remarks.trim());
                    jobj.put("orderId", unqOrderID.trim());
                    jobj.put("customerMobileno", customerMobileno.trim());
                    jobj.put("checkSum", enc_checksum.trim());
                    System.out.println( "Request for HTTPRequestResponse Call::"+jobj);
                    mRepLogger.info( "Request for HTTPRequestResponse Call::"+jobj);
					HTTPRequestResponse hrr=new HTTPRequestResponse();
					checkStatusres =hrr.sendHTTPRequest(url, type , jobj.toString(),cm);	//Token Generation Call			
					System.out.println("Response for Check Status ::"+checkStatusres);
					 mRepLogger.info( "Response from HTTPRequestResponse Call::"+checkStatusres);
					JSONObject push2VPARes=(JSONObject) jParse.parse(checkStatusres);
					push2VPAStatus=(String)push2VPARes.get("result");
					token=(String)push2VPARes.get("data");
//					merchtranid=(String)push2VPARes.get("merchTranId");
					msg=push2VPAStatus;
					
					//start of updating UPI Payment call for Token Generation(Push To VPA)
		              String values = "'" + pid + "','" + loanNo + "','"+dateforDB+"','Token Generation','" +jobj.toString() + "','"+ checkStatusres + "','"+push2VPAStatus+"','" + unqOrderID +"','" + custVPA+"'" ;
		            	 String columns = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,ORDERID,CUST_VPA";
		            	 String table = "LCS_UPI_History_Table";
		              mRepLogger.info(paymentType + " VPA details for checkUPIPayment(Token Generation(Push To VPA)) is getting updated in LCS_UPI_History_Table");
			           System.out.println(paymentType + " VPA details for checkUPIPayment(Token Generation(Push To VPA)) is getting updated in LCS_UPI_History_Table");
			           String InsertQuery="INSERT INTO dbo."+table+" ("+columns+") VALUES ("+values+")";
			    		   mRepLogger.info("Insert Query  : "+InsertQuery);
			    		   List<String> result = ifr.getDataFromDB(InsertQuery);
			           mRepLogger.info(paymentType + " VPA details for checkUPIPayment(Token Generation(Push To VPA)) is updated in LCS_UPI_History_Table" + result);
			           System.out.println(paymentType + " VPA details for checkUPIPayment(Token Generation(Push To VPA)) is updated in LCS_UPI_History_Table" + result);
			        //end of updating the UPI Payment call for Token Generation(Push To VPA)
			           
              if (push2VPAStatus.equalsIgnoreCase("SUCCESS")) {	
   					    flag = "token Generated";
   					 mRepLogger.info( "push2VPAStatus :: "+flag);
						url=propertyReader.getvalue("P2VInitiation");
						url+=token;
						type="P2VInitiation";
						JSONObject jobj1=new JSONObject();
						
						System.out.println("GET Request for HTTPRequestResponse Call as a URL::"+url);
						 mRepLogger.info("GET Request for HTTPRequestResponse Call as a URL::"+url);
   					HTTPRequestResponse hrr1=new HTTPRequestResponse();
					   checkStatusres =hrr1.sendHTTPRequest(url, type , jobj1.toString(),cm);//Initiation call for push to vpa
						System.out.println("Response for P2VInitiation ::"+checkStatusres);
						 mRepLogger.info( "Response from P2VInitiation::"+checkStatusres);
						JSONObject push2VPARes1=(JSONObject) jParse.parse(checkStatusres);
					    collectStatus=(String)push2VPARes1.get("result");
					    TransTempID=(String)push2VPARes1.get("tranid");
					    merchtranid=(String)push2VPARes1.get("merchTranId");
						CollectTxnID=(String)push2VPARes1.get("wCollectTxnId");
						custrefID=(String)push2VPARes1.get("wCustmerRefId");
						msg=collectStatus;
						
						//start of updating UPI Payment call for P2VInitiation(Push To VPA)
			              String values1 = "'" + pid + "','" + loanNo + "','"+dateforDB+"','P2VInitiation','GET: " +url + "','"+ checkStatusres + "','"+collectStatus+"','" + unqOrderID +"','" + custVPA+"'";
			            	 String columns1 = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,ORDERID,CUST_VPA";
			            	 String table1 = "LCS_UPI_History_Table";
			              mRepLogger.info(paymentType + " VPA details for checkUPIPayment(P2VInitiation(Push To VPA)) is getting updated in LCS_UPI_History_Table");
				           System.out.println(paymentType + " VPA details for checkUPIPayment(P2VInitiation(Push To VPA)) is getting updated in LCS_UPI_History_Table");
				           String InsertQuery1="INSERT INTO dbo."+table1+" ("+columns1+") VALUES ("+values1+")";
				    		   mRepLogger.info("Insert Query  : "+InsertQuery1);
				    		   List<String> result1 = ifr.getDataFromDB(InsertQuery1);
				           mRepLogger.info(paymentType + " VPA details for checkUPIPayment(P2VInitiation(Push To VPA)) is updated in LCS_UPI_History_Table" + result1);
				           System.out.println(paymentType + " VPA details for checkUPIPayment(P2VInitiation(Push To VPA)) is updated in LCS_UPI_History_Table" + result1);
				     //end of updating the UPI Payment call for P2VInitiation(Push To VPA)
				           
						if(collectStatus.equalsIgnoreCase("SUCCESS")){
							url=propertyReader.getvalue("P2VCheckStatus");
							type="P2VCheckStatus";
							String p2vchecksum=merchId.trim()+merchChanId.trim()+transactionID.trim();
							CommonWebserviceCalls cws1 = new CommonWebserviceCalls();
	                String p2venc_checksum = cws1.encryptData(propertyReader.getvalue("PublicKey"), p2vchecksum,cm);
//							JSONObject p2vrequest=new JSONObject();
							p2vrequest.put("merchId",merchId);
							p2vrequest.put("merchChanId",merchChanId);
							p2vrequest.put("unqTxnId",transactionID);
							p2vrequest.put("checkSum",p2venc_checksum);
							System.out.println("Request for HTTPRequestResponse Call (Push To VPA Check Status)::"+url);
							 mRepLogger.info("Request for HTTPRequestResponse Call (Push To VPA Check Status)::"+url);
							
							HTTPRequestResponse hrr11=new HTTPRequestResponse();
					     checkStatusres =hrr11.sendHTTPRequest(url, type , p2vrequest.toString(),cm);//check status API call (final call)
						   System.out.println("Response for P2VInitiation ::"+checkStatusres);
						   mRepLogger.info( "Response from P2VInitiation::"+checkStatusres);
						    
							JSONObject push2VPARes11=(JSONObject) jParse.parse(checkStatusres);
							merchtranid=(String)push2VPARes11.get("merchTranId");
						   CollectTxnID=(String)push2VPARes11.get("wCollectTxnId");
							checkstatus=(String)push2VPARes11.get("result");
							msg=checkstatus;
							
				        //start of updating UPI Payment call for check status(Push To VPA)
				        String values11 = "'" + pid + "','" + loanNo + "','"+dateforDB+"','Check Status','" +p2vrequest.toString() + "','"+ checkStatusres + "','"+checkstatus+"','" + unqOrderID +"','" + custVPA+"'";
				        String columns11 = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,ORDERID,CUST_VPA";
				        String table11 = "LCS_UPI_History_Table";
				        mRepLogger.info(paymentType + " VPA details for checkUPIPayment is getting updated in LCS_UPI_History_Table");
					     System.out.println(paymentType + " VPA details for checkUPIPaymentt is getting updated in LCS_UPI_History_Table");
					     String InsertQuery11="INSERT INTO dbo."+table11+" ("+columns11+") VALUES ("+values11+")";
					     mRepLogger.info("Insert Query  : "+InsertQuery11);
					     List<String> result11 = ifr.getDataFromDB(InsertQuery11);
					     mRepLogger.info(paymentType + " VPA details for checkUPIPayment is updated in LCS_UPI_History_Table" + result11);
					     System.out.println(paymentType + " VPA details for checkUPIPayment is updated in LCS_UPI_History_Table" + result11);
					     //end of updating the UPI Payment call for check status(Push To VPA)
					     
							if(checkstatus.equalsIgnoreCase("SUCCESS")){
								flag="True";
							}
							else{
								flag="False";
							}
//							CustomInfoLogger.info( "push2VPACheckStatus response:: "+msg);
							 mRepLogger.info( "push2VPACheckStatus :: "+flag);
							
						}
                    }
					 else {
	   					flag = "False";
	   				 mRepLogger.info( "push2VPAStatus :: "+flag);
					 }
              transID=transactionID;
	            
		     }
		  }
	    else if(paymentType.equalsIgnoreCase("Dynamic VPA")){

			type="Dynamic VPA";
			LocalDateTime myDtObj = LocalDateTime.now();
			DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss");
			DateTimeFormatter DBFormatOb = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String formattedDate = myDtObj.format(myFormatObj);
			String transactionID = "T" + unqCustID.concat(formattedDate);
			String unqOrderID = "O" + unqCustID.concat(formattedDate);
			String amt = ifr.getValue("qCollectionEntry_Collection_Amount").toString().trim();//
		    String customerVpa = ifr.getValue("qUpiPaymentDet_CustVPA").toString().trim();
		    String remarks = ifr.getValue("qUpiPaymentDet_Pay_Remarks").toString().trim();
		    String customerMobileno = ifr.getValue("qUpiPaymentDet_MobNo").toString().trim();
			String CollectTxnID="";
			String custrefID="";
			String checkstatus="";
		    flag="False";
		   url = propertyReader.getvalue("TokenGenerationURL").trim();
		   String checksum = merchId.trim() + merchChanId.trim() + transactionID.trim() + amt.trim() + customerVpa.trim() + currency.trim() + remarks.trim();
	       CommonWebserviceCalls cws = new CommonWebserviceCalls();
	       String enc_checksum = cws.encryptData(propertyReader.getvalue("PublicKey"), checksum,cm);
		   if (url != null && merchId != null && merchChanId != null) {
//                    JSONObject jobj=new JSONObject();
                    jobj.put("merchId", merchId.trim());
                    jobj.put("merchChanId", merchChanId.trim());
                    jobj.put("unqTxnId", transactionID.trim());
                    jobj.put("amount", amt.trim());
                    jobj.put("customerVpa", customerVpa.trim());
                    jobj.put("currency", currency.trim());
                    jobj.put("remarks", remarks.trim());
                    jobj.put("orderId", unqOrderID.trim());
                    jobj.put("customerMobileno", customerMobileno.trim());
                    jobj.put("checkSum", enc_checksum.trim());
                    System.out.println( "Request for HTTPRequestResponse Call(Dynamic VPA)::"+jobj);
                    mRepLogger.info( "Request for HTTPRequestResponse Call(Dynamic VPA)::"+jobj);
					HTTPRequestResponse hrr=new HTTPRequestResponse();
					checkStatusres =hrr.sendHTTPRequest(url, type , jobj.toString(),cm);	//Token Generation Call			
					System.out.println("Response for Check Status ::"+checkStatusres);
					 mRepLogger.info( "Response from HTTPRequestResponse Call::"+checkStatusres);
					JSONObject push2VPARes=(JSONObject) jParse.parse(checkStatusres);
					push2VPAStatus=(String)push2VPARes.get("result");
					token=(String)push2VPARes.get("data");
//					merchtranid=(String)push2VPARes.get("merchTranId");
					msg=push2VPAStatus;
					
					//start of updating UPI Payment call for Token Generation(Dynamic VPA)
		              String values = "'" + pid + "','" + loanNo + "','"+dateforDB+"','Token Generation','" +jobj.toString() + "','"+ checkStatusres + "','"+push2VPAStatus+"','" + unqOrderID +"','" + custVPA+"'" ;
		            	 String columns = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,ORDERID,CUST_VPA";
		            	 String table = "LCS_UPI_History_Table";
		              mRepLogger.info(paymentType + " VPA details for checkUPIPayment(Token Generation(Dynamic VPA)) is getting updated in LCS_UPI_History_Table");
			           System.out.println(paymentType + " VPA details for checkUPIPayment(Token Generation(Dynamic VPA)) is getting updated in LCS_UPI_History_Table");
			           String InsertQuery="INSERT INTO dbo."+table+" ("+columns+") VALUES ("+values+")";
			    		   mRepLogger.info("Insert Query  : "+InsertQuery);
			    		   List<String> result = ifr.getDataFromDB(InsertQuery);
			           mRepLogger.info(paymentType + " VPA details for checkUPIPayment(Token Generation(Dynamic VPA)) is updated in LCS_UPI_History_Table" + result);
			           System.out.println(paymentType + " VPA details for checkUPIPayment(Token Generation(Dynamic VPA)) is updated in LCS_UPI_History_Table" + result);
			        //end of updating the UPI Payment call for Token Generation(Dynamic VPA)
			           
              if (push2VPAStatus.equalsIgnoreCase("SUCCESS")) {	
   					    flag = "token Generated";
   					 mRepLogger.info( "Dynamic VPA Status :: "+flag);
						url=propertyReader.getvalue("P2VInitiation");
						url+=token;
						type="DVInitiation";
						JSONObject jobj1=new JSONObject();
						
						System.out.println("GET Request for HTTPRequestResponse Call (Dynamic VPA) as a URL::"+url);
						mRepLogger.info("GET Request for HTTPRequestResponse Call (Dynamic VPA) as a URL::"+url);
   					HTTPRequestResponse hrr1=new HTTPRequestResponse();
					   checkStatusres =hrr1.sendHTTPRequest(url, type , jobj1.toString(),cm);//Initiation call for push to vpa
						System.out.println("Response for Dynamic VPA Initiation ::"+checkStatusres);
						mRepLogger.info( "Response from Dynamic VPA Initiation::"+checkStatusres);
						JSONObject push2VPARes1=(JSONObject) jParse.parse(checkStatusres);
					   collectStatus=(String)push2VPARes1.get("result");
					   TransTempID=(String)push2VPARes1.get("tranid");
					   merchtranid=(String)push2VPARes1.get("merchTranId");
						CollectTxnID=(String)push2VPARes1.get("wCollectTxnId");
						custrefID=(String)push2VPARes1.get("wCustmerRefId");
						msg=collectStatus;
						
						//start of updating UPI Payment call for DVInitiation(Dynamic VPA)
			              String values1 = "'" + pid + "','" + loanNo + "','"+dateforDB+"','P2VInitiation','GET: " +url + "','"+ checkStatusres + "','"+collectStatus+"','" + unqOrderID +"','" + custVPA+"'";
			            	 String columns1 = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,ORDERID,CUST_VPA";
			            	 String table1 = "LCS_UPI_History_Table";
			              mRepLogger.info(paymentType + " VPA details for checkUPIPayment(P2VInitiation(Dynamic VPA)) is getting updated in LCS_UPI_History_Table");
				           System.out.println(paymentType + " VPA details for checkUPIPayment(P2VInitiation(Dynamic VPA)) is getting updated in LCS_UPI_History_Table");
				           String InsertQuery1="INSERT INTO dbo."+table1+" ("+columns1+") VALUES ("+values1+")";
				    		   mRepLogger.info("Insert Query  : "+InsertQuery1);
				    		   List<String> result1 = ifr.getDataFromDB(InsertQuery1);
				           mRepLogger.info(paymentType + " VPA details for checkUPIPayment(P2VInitiation(Dynamic VPA)) is updated in LCS_UPI_History_Table" + result1);
				           System.out.println(paymentType + " VPA details for checkUPIPayment(P2VInitiation(Dynamic VPA)) is updated in LCS_UPI_History_Table" + result1);
				     //end of updating the UPI Payment call for DVInitiation(Dynamic VPA)
				           
						if(collectStatus.equalsIgnoreCase("SUCCESS")){
							url=propertyReader.getvalue("P2VCheckStatus");
							type="Dynamic VPA CheckStatus";
							String p2vchecksum=merchId.trim()+merchChanId.trim()+transactionID.trim();
							CommonWebserviceCalls cws1 = new CommonWebserviceCalls();
	                String p2venc_checksum = cws1.encryptData(propertyReader.getvalue("PublicKey"), p2vchecksum,cm);
							p2vrequest.put("merchId",merchId);
							p2vrequest.put("merchChanId",merchChanId);
							p2vrequest.put("unqTxnId",transactionID);
							p2vrequest.put("checkSum",p2venc_checksum);
							System.out.println("Request for HTTPRequestResponse Call (Dynamic VPA Check Status)::"+url);
							mRepLogger.info("Request for HTTPRequestResponse Call (Dynamic VPA Check Status)::"+url);
							
							HTTPRequestResponse hrr11=new HTTPRequestResponse();
					     checkStatusres =hrr11.sendHTTPRequest(url, type , p2vrequest.toString(),cm);//check status API call (final call)
						   System.out.println("Response for Dynamic VPA Initiation::"+checkStatusres);
						   mRepLogger.info( "Response from Dynamic VPA Initiation::"+checkStatusres);
						    
							JSONObject push2VPARes11=(JSONObject) jParse.parse(checkStatusres);
							merchtranid=(String)push2VPARes11.get("merchTranId");
						   CollectTxnID=(String)push2VPARes11.get("wCollectTxnId");
							checkstatus=(String)push2VPARes11.get("result");
							msg=checkstatus;
							
							//start of updating UPI Payment call for check status
				              String values11 = "'" + pid + "','" + loanNo + "','"+dateforDB+"','Check Status','" + p2vrequest.toString() + "','"+ checkStatusres + "','"+checkstatus+"','" + unqOrderID +"','" + custVPA+"'" ;
				            	 String columns11 = "PID,LOANNO,REQ_DATE,SERVICE_NAME,INPUT_REQ,OUTPUT_RESP,STATUS,ORDERID,CUST_VPA";
				            	 String table11 = "LCS_UPI_History_Table";
				              mRepLogger.info(paymentType + " VPA details for checkUPIPayment is getting updated in LCS_UPI_History_Table");
					            System.out.println(paymentType + " VPA details for checkUPIPaymentt is getting updated in LCS_UPI_History_Table");
					            String InsertQuery11="INSERT INTO dbo."+table11+" ("+columns11+") VALUES ("+values11+")";
					    		    mRepLogger.info("Insert Query  : "+InsertQuery11);
					    		    List<String> result11 = ifr.getDataFromDB(InsertQuery11);
					            mRepLogger.info(paymentType + " VPA details for checkUPIPayment is updated in LCS_UPI_History_Table" + result11);
					            System.out.println(paymentType + " VPA details for checkUPIPayment is updated in LCS_UPI_History_Table" + result11);
					      //end of updating the UPI Payment call for check status
					            
							if(checkstatus.equalsIgnoreCase("SUCCESS")){
								flag="True";
							}
							else{
								flag="False";
							}
//							CustomInfoLogger.info( "push2VPACheckStatus response:: "+msg);
							 mRepLogger.info( "Dynamic VPA CheckStatus :: "+flag);						 
						}
                    }
					 else {
	   					flag = "False";
	   				 mRepLogger.info( "Dynamic VPA CheckStatuss :: "+flag);
					 }
              transID=transactionID;
		     }
		  
	    }
	    jObjReturn.put("Status", flag);
		 jObjReturn.put("Msg", msg);
		 jObjReturn.put("txnid", transID);
		 System.out.println("Response From Server(JSON Object) ::"+jObjReturn);
		 mRepLogger.info( "Response send to client::"+jObjReturn);
		 return jObjReturn.toString();	    
//      return sr;
	}
	catch(Exception e){
		JSONObject errjson=new JSONObject();
		  mRepLogger.info("Exception ::"+e.getMessage());
		  mErrLogger.info("Exception ::"+e.getMessage());
		  System.out.println("Exception ::"+e.getMessage());
			e.printStackTrace();
			errjson.put("Status","False");
			errjson.put("Msg",e.getMessage());
			return (errjson.toString());
	}
}

public String validateSettlement(){ 
	
	boolean b=false;
	
	mRepLogger.info(":::: Inside validating the settlement date ::::");
	
	try{ 
		Properties p=getServiceProperties();
		String t24Dt=p.getProperty("PreClosureCurrentDateInT24");
		String gridDt="";
		JSONArray quotationGrid = ifr.getDataFromGrid("preClosureSettlementGrid");
		if(quotationGrid.size()>0){ 
			
			gridDt=ifr.getTableCellValue("preClosureSettlementGrid", 0, 0);
			mRepLogger.info("Date from the settlement grid ::"+gridDt+", Date from ini file/T24 to compare ::"+t24Dt);
			
			if(t24Dt!=null && t24Dt.equalsIgnoreCase("current")){ 
				Date cd=new Date();
        		String cdStr= new SimpleDateFormat("dd/MM/yyyy").format(cd);
        		if(gridDt.equals(cdStr)){ 
        			b=true;
        		}
			}else if(t24Dt!=null && !t24Dt.equalsIgnoreCase("current") && gridDt.equals(t24Dt)){ 
				b=true;
			}
		}
		
	}catch(Exception e){ 
		
		mRepLogger.info("Exception in validating the settlement date ::validateSettlement method, check error logs for details::"+e.getMessage());
		mErrLogger.info("",e);
	}
	
	mRepLogger.info(":::: Status of Validation of Settlement ::::"+Boolean.toString(b));
	
	return Boolean.toString(b);
}

//public static String getXMLValueOfKey(String bucName,String subTag,String Key){ 
//	
//	
//	Node ofConfigNode = null;
//	String value="";
//	try {
//		String xPath = null;
//		xPath = "./*/BucMap[@bucName='"+bucName+"']";
//		ofConfigNode = configuration.searchObjectGraph(xPath, configuration.getConfigurationXmlText()).item(0);
//		// server node
//		xPath = "./"+subTag;
//		Node serverInfoNode = configuration.searchObjectGraph(xPath, (Element) ofConfigNode).item(0);
//
//		
//		xPath = "./Key[@name = '"+Key+"']";
//		value = configuration.searchObjectGraph(xPath, (Element) serverInfoNode).item(0).getTextContent()
//				.trim();
//		
//	} catch (Exception e) {
//        StringWriter errors = new StringWriter();
//        e.printStackTrace(new PrintWriter(errors));
//		LogMe.logMe(LogMe.LOG_LEVEL_ERROR, e);
//		
//	}
//	
//	return value ;
//	
//}
////public String getValueFromXMLCustom(String mainTag,String Key){
//    
//    
//    Node ofConfigNode = null;
//    String value="";
//    try {
//        String xPath = null;
//        xPath = "./*/"+mainTag;
//        Node InfoNode = configuration.searchObjectGraph(xPath, configuration.getConfigurationXmlText()).item(0);
//       
//        xPath = "./Key[@name = '"+Key+"']";
//        value = configuration.searchObjectGraph(xPath, (Element) InfoNode).item(0).getTextContent()
//                .trim();
//       
//    } catch (Exception e) {
//        StringWriter errors = new StringWriter();
//        e.printStackTrace(new PrintWriter(errors));
//        LogMe.logMe(LogMe.LOG_LEVEL_ERROR, e);
//       
//    }
//   
//    return value ;
//   
//}	
	
	

}