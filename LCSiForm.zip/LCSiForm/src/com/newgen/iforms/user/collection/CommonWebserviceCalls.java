package com.newgen.iforms.user.collection;

//import static com.newgen.custom.log.CustomLogger.CustomInfoLogger;

import java.security.KeyFactory;
import java.security.KeyPairGenerator;
import java.security.KeyPair;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import org.apache.log4j.*;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.PropertyConfigurator;
import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Hex;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

//import com.newgen.mcap.core.external.logging.concrete.LogMe;
import com.sun.jersey.core.util.Base64;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.log4j.*;
//public static final org.apache.log4j.Logger mRepLogger = org.apache.log4j.Logger.getLogger("Reportlog");

public class CommonWebserviceCalls {

	public String sendHTTPRequest(String url,String headerKey, String headerVal, CollectionCommonMethod cm) {
     
		cm.mRepLogger.info("Inside CommonWebserviceCalls.java");
		//LogMe.logMe(LogMe.LOG_LEVEL_DEBUG,"Inside CommonWebserviceCalls.java");
		System.out.println("Inside CommonWebserviceCalls.java");
		String resp = "";

		try {
			cm.mRepLogger.info("Inside CommonWebserviceCalls.java");
			//LogMe.logMe(LogMe.LOG_LEVEL_DEBUG,"Inside CommonWebserviceCalls.java");
			System.out.println("Inside try CommonWebserviceCalls.java");
			HttpPost post = new HttpPost(url);
			post.setEntity(new StringEntity(headerVal));
		//	post.addHeader("Content-Type", "text/plain");
//			post.addHeader("Content-Length", "<calculated when request is sent>");
			post.addHeader("Host", "<calculated when request is sent>");
			post.addHeader("User-Agent", "PostmanRuntime/7.28.2");
			post.addHeader("Accept", "*/*");
			post.addHeader("Accept-Encoding", "gzip, deflate, br");
			post.addHeader("Connection", "keep-alive");
			post.addHeader("Content-Type", "application/json");
//			post.setEntity(new StringEntity(headerVal));
			System.out.println("Before Sending Request in try CommonWebserviceCalls.java");
			CloseableHttpClient httpClient = HttpClients.createDefault();			
			CloseableHttpResponse response = httpClient.execute(post);
			System.out.println("After Sending Request in try CommonWebserviceCalls.java");
//			resp = response.getStatusLine().getStatusCode();
//			resp = Integer.toString(response.getStatusLine().getStatusCode());
			HttpEntity entity = response.getEntity();
      	resp = EntityUtils.toString(entity);

		} catch (Exception e) {
			resp = "-1";
			//CustomInfoLogger.info("Exception :: in CommonWebserviceCalls.java");
			e.printStackTrace();
			//CustomInfoLogger.info(e);	
			//LogMe.logMe(LogMe.LOG_LEVEL_DEBUG,"Exception during sendHTTPRequest>>>"+e.getMessage());
			System.out.println("Exception :: in CommonWebserviceCalls.java");
		}

		return resp;
	}
	
	public String encryptData(String pkey,String checksum,CollectionCommonMethod cm){ 
		
		String en_str="";
		cm.mRepLogger.info("Checksum in CommonWebserviceCalls.java::"+checksum);
		
		try{ 
//			KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
//			generator.initialize(2048);
//			KeyPair pair = generator.generateKeyPair();
//			PrivateKey privateKey = pair.getPrivate();
			cm.mRepLogger.info("Inside try block of encryptData() in CommonWebserviceCalls.java");
			byte[] encodedPublicKey = Base64.decode(pkey);
			cm.mRepLogger.info("Encoded Public Key::"+encodedPublicKey);
			X509EncodedKeySpec spec = new X509EncodedKeySpec(encodedPublicKey);
			cm.mRepLogger.info("After X509EncodedKeySpec");
		    KeyFactory kf = KeyFactory.getInstance("RSA");
		    Cipher cipher= Cipher.getInstance("RSA");
		    cm.mRepLogger.info("After Cipher Instance creation");
		    cipher.init(Cipher.ENCRYPT_MODE, kf.generatePublic(spec));
		    cm.mRepLogger.info("After Cipher Instance Initialization");
		    byte cipher_bytearr[]=cipher.doFinal(checksum.getBytes());
		    cm.mRepLogger.info(" Cipher Byte Array after encryption ::"+cipher_bytearr);
//		    char en_str_chararr[]=Hex.encodeHex(cipher_bytearr);
		    String en_checksum=Hex.encodeHexString(cipher_bytearr);
		    cm.mRepLogger.info("After encoding in encodeHex()::"+en_checksum);
		    en_str=en_checksum.toString();
		    cm.mRepLogger.info("Encrypted Checksum in CommonWebserviceCalls.java::"+en_str);
		    System.out.println("Encrypted Checksum in CommonWebserviceCalls.java::"+en_str);
		    
		}catch(Exception e){ 
			cm.mRepLogger.info("Exception in CommonWebserviceCalls.java::");
			cm.mRepLogger.info("Exception :: "+e.getMessage());
			cm.mErrLogger.info("Exception in CommonWebserviceCalls.java:: "+e.getMessage());
			System.out.println("Exception in CommonWebserviceCalls.java::");
			e.printStackTrace();
			
		}
		
		return en_str;
	}

}
