package com.newgen.iforms.user.collection.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.user.collection.CollectionCommonMethod;
import com.newgen.webserviceclient.NGWebServiceClient;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


public class CollectionCommonServices {

	private IFormReference ifr = null;
	CollectionCommonMethod cm = new CollectionCommonMethod(ifr);
	
	public CollectionCommonServices(IFormReference ifr) {
		cm.mRepLogger.info("Inside CommonMethods!");
		this.ifr = ifr;
	}
	
	public String getProperties(String fileName) {
		
		String fetchXML=null;
		FileInputStream fis = null;
		try{
			
			String path = System.getProperty("jboss.home.dir") + File.separator + "bin" + File.separator
					+ "customServiceProperties" + File.separator + fileName;
			  
			fis = new FileInputStream(path);
			fetchXML = IOUtils.toString(fis);
			cm.mRepLogger.info("result of the XML Req-->"+fetchXML);
			
		}catch(Exception e){
			
			cm.mErrLogger.info("Exception in reading the XML webservice-->"+e.getMessage());
//			e.printStackTrace();
		}finally{
			try {
				if(fis!=null){ 
					fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
//				e.printStackTrace();
			}
		}
		
		return fetchXML;

	}
	
    private static Document convertStringToDocument(String xmlStr) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
        DocumentBuilder builder;  
        try  
        {  
            builder = factory.newDocumentBuilder();  
            Document doc = builder.parse( new InputSource( new StringReader( xmlStr ) ) ); 
            return doc;
        } catch (Exception e) {  
        	CollectionCommonMethod.mErrLogger.info("Exception in convertStringToDocument-->"+e.getMessage());
//			e.printStackTrace();  
        } 
        return null;
    }
    
    private static String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
        	CollectionCommonMethod.mErrLogger.info("Exception in convertDocumentToString-->"+e.getMessage());
//			e.printStackTrace();
        }
        
        return "";
    }
	
	public String triggerFlaggingAndUnFlagging(String flagType,String PID,String loanNo){ 
		
		String updtRequest="SUCCESS";
		String failureMsg="";
		Properties p=null;
		String service=(flagType!=null && flagType.equals("1"))?"RepoMarking":"RepoRelease";
		
		try{
			p=new Properties();
			p.load(new StringReader(getProperties("serviceINI.properties")));
			
			String strReq=getProperties("LEG.REP.FLAG.REQ.xml");
			Document doc=convertStringToDocument(strReq);
			if(doc!=null){ 
			
			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("*");
			for (int i = 0; i < nodeList.getLength(); i++) {
		        Node node = nodeList.item(i);
		        if (node.getNodeType() == Node.ELEMENT_NODE) {
		            
		            cm.mRepLogger.info("Req node name=>"+node.getNodeName());
		            if(node.getNodeName()!=null && !node.getNodeName().equals("")){ 
		            	if(node.getNodeName().equalsIgnoreCase("company")){ 
		            		
		            		node.setTextContent(getCompanyCode());
		            	}else if(node.getNodeName().equalsIgnoreCase("password")){ 
		            		
		            		node.setTextContent(p.getProperty("password"));
		            	}else if(node.getNodeName().equalsIgnoreCase("userName")){ 
		            		
		            		node.setTextContent(p.getProperty("userName"));
		            	}else if(node.getNodeName().equalsIgnoreCase("ArrangementID")){ 
		            		
		            		node.setTextContent(loanNo);
		            	}else if(node.getNodeName().equalsIgnoreCase("mL.GK.FIELD.NAME")){ 
		            		
		            		String attr=node.getAttributes().getNamedItem("m").getNodeValue();
			            	//repo
		            		if(attr!=null && attr.equals("2")){ 
			            		
		            			NodeList childNodes=node.getChildNodes();
			            		for(int j=0;j<childNodes.getLength();j++){
					            	Node cN=childNodes.item(j);
					            	 
				            		if(cN.getNodeName().equalsIgnoreCase("LGKFIELDVAL")){ 
				            			cN.setTextContent(flagType);
				            			
				            		}
					            		
					            }
			            	}
			            	
		            	}
		            	
		            }
		        }
		    } 
            
			String finalReq=convertDocumentToString(doc);
			cm.mRepLogger.info("final xml after update=>"+finalReq);
			
			
			String resp=executeSOAPCall(PID,loanNo,service,finalReq,p.getProperty("EndpointURL"));
//			String resp=getProperties("TestResp.xml");
			cm.mRepLogger.info("Response from Service=>"+resp);
			//parsing the resonse
			if(resp!=null && !resp.trim().equals("")){ 
				
				Document respDoc=convertStringToDocument(resp);
				if(respDoc!=null){
				respDoc.getDocumentElement().normalize();
				
				NodeList respNodeList = respDoc.getElementsByTagName("Status");
				if(respNodeList.getLength()>0){ 
				
					MainStatus:	
					for (int i = 0; i < respNodeList.getLength(); i++) {
				        Node node = respNodeList.item(i);
				        if (!updtRequest.equalsIgnoreCase("failed")) {
				            cm.mRepLogger.info("Resp node name=>"+node.getNodeName());
				            
				            NodeList childNodes=node.getChildNodes();
				            for(int j=0;j<childNodes.getLength();j++){
				            	Node cN=childNodes.item(j);
				            	if(cN.getNodeType() == Node.ELEMENT_NODE){ 
				            	
				            		if(cN.getNodeName().equalsIgnoreCase("successIndicator") && (cN.getTextContent()==null || 
				            				cN.getTextContent().equalsIgnoreCase("T24Error"))){ 
				            			
				            			failureMsg="T24Error : "+getErrorMsg(childNodes);
				            			updtRequest="FAILED";
				            			break MainStatus;
				            		}
				            		else if(cN.getNodeName().equalsIgnoreCase("successIndicator") && (cN.getTextContent()==null || 
			            				!cN.getTextContent().equalsIgnoreCase("Success"))){ 
			            			
				            			updtRequest="FAILED";
				            			break;
				            		}
				            		
				            	}
				            }
				            
				        }else{ 
				        	
				        	updtRequest="FAILED";
	            			break;
				        }
				    }
				
				}else{ 
					
					updtRequest="FAILED";
				}
				
			}
			}else{ 
				
				updtRequest="FAILED";
				
			}
			
		}else{ 
			
			cm.mRepLogger.info("XML Request is empty in the provided file");
			
		}
			
			
		}catch(Exception e){
			
			cm.mErrLogger.info("Exception in triggerFlaggingAndUnFlagging-->"+e.getMessage());
//			e.printStackTrace();
			
		}
		
		if(!failureMsg.equals("")){
			
			updtRequest=updtRequest+"~~"+failureMsg;
		}
		
		return updtRequest;
		
	}
	
	public String executeSOAPCall(String PID, String loanNo, String Service, String SOAP_inxml, String EndPointurl) {
        
        String SOAPResponse_xml = "";
        try {
            NGWebServiceClient ngwsclnt = new NGWebServiceClient(true);
            String action = "";

//            SOAPResponse_xml = ngwsclnt.ExecuteWs(SOAP_inxml, EndPointurl, action);
            WebServiceCalls ws=new WebServiceCalls(false);
//            SOAPResponse_xml = ws.ExecuteWs(SOAP_inxml, EndPointurl, Service,cm);
            SOAPResponse_xml = ws.callSoapService(cm, SOAP_inxml, EndPointurl, "POST", Service);
//            SOAPResponse_xml = SOAPResponse_xml.replaceAll("'", "''");
            
            String histQuery="INSERT INTO dbo.LCS_T24_History_Table (PID, LOANNO, CAPTURED_DATE, SERVICE_NAME, INPUT_XML, "
            		+ "OUTPUT_XML) VALUES ('"+PID+"', '"+loanNo+"', getDate(), '"+Service+"', '"+SOAP_inxml+"', '"+(SOAPResponse_xml.replaceAll("'", "''"))+"')";
            cm.mRepLogger.info("Query to save the history to T24 table ::"+histQuery);
            List<List<String>> histStatus=ifr.getDataFromDB(histQuery);
            cm.mRepLogger.info("response for the t24 history=>"+histStatus);

        } catch (Exception e) {
        	cm.mErrLogger.info("Exception in executeSOAPCall-->"+e.getMessage());
//			e.printStackTrace();
        }
        return SOAPResponse_xml;
    }
	
	
	public String getErrorMsg(NodeList childNodes){ 
		
		String errMsg="";
		
		for(int j=0;j<childNodes.getLength();j++){
        	Node cN=childNodes.item(j);
        	if(cN.getNodeType() == Node.ELEMENT_NODE){
        		if(cN.getNodeName().equalsIgnoreCase("messages")){ 

        			errMsg=cN.getTextContent();
        			break;
        		}
        	} 
        }
		
		return errMsg;
		
		
	}
	
	
	public String fetchRepaymentSchedule(String PID,String loanNo){ 
		
		String updtRequest="SUCCESS";
		String failureMsg="";
		Properties p=null;
		String service="RepaymentSchedule";
		JSONArray jArr=new JSONArray();
		try{
			p=new Properties();
			p.load(new StringReader(getProperties("serviceINI.properties")));
			
			String strReq=getProperties("GK.LOAN.SCHEDULE.REQ.xml");
			Document doc=convertStringToDocument(strReq);
			if(doc!=null){ 
			
			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("*");
			for (int i = 0; i < nodeList.getLength(); i++) {
		        Node node = nodeList.item(i);
		        if (node.getNodeType() == Node.ELEMENT_NODE) {
		            
		            cm.mRepLogger.info("Req node name=>"+node.getNodeName());
		            if(node.getNodeName()!=null && !node.getNodeName().equals("")){ 
		            	if(node.getNodeName().equalsIgnoreCase("company")){ 
		            		
		            		node.setTextContent(getCompanyCode());
		            	}else if(node.getNodeName().equalsIgnoreCase("password")){ 
		            		
		            		node.setTextContent(p.getProperty("password"));
		            	}else if(node.getNodeName().equalsIgnoreCase("userName")){ 
		            		
		            		node.setTextContent(p.getProperty("userName"));
		            	}else if(node.getNodeName().equalsIgnoreCase("criteriaValue")){ 
		            		
		            		node.setTextContent(loanNo);
		            	}
		            	
		            }
		        }
		    } 
            
			String finalReq=convertDocumentToString(doc);
			cm.mRepLogger.info("final xml after update=>"+finalReq);
			
			
			String resp=executeSOAPCall(PID,loanNo,service,finalReq,p.getProperty("EndpointURL_Repay"));
//			String resp=getProperties("TestResp.xml");
			cm.mRepLogger.info("Response from Service=>"+resp);
			//parsing the resonse
			
			String finalResp=parseSoapResp(resp);
			
			if(finalResp.contains("~~")){ 
				
				//returning to the caller as the response frmo the service is a failure.
//				updtRequest=finalResp.split("~~")[0];
//				updtRequest=updtRequest+"~~"+finalResp.split("~~")[1];
				return finalResp;
			}
			else if(finalResp.equalsIgnoreCase("success")){ 
			
				//if the response is success then parse it and push the data to repaymentgrid
				updtRequest=finalResp;
				String columns=p.getProperty("RepaymentFeildsMapping");
				String[] col=columns.split(",");
				Map<String,String> colMap=new HashMap<String,String>();
				for(int k=0;k<col.length;k++){ 
					
					colMap.put(col[k].split("~")[0], col[k].split("~")[1]);
				}
//				cm.mRepLogger.info("Response from the repayment schedule WS : "+resp);
				Document respRepayDoc=convertStringToDocument(resp);
				if(respRepayDoc!=null){ 
					
					respRepayDoc.getDocumentElement().normalize();
					NodeList respRepayDocNodeList = respRepayDoc.getElementsByTagName("mGKENQINTPRIOSDETSDetailType");
					
					for (int i = 0; i < respRepayDocNodeList.getLength(); i++) {
				        Node node = respRepayDocNodeList.item(i);
				        if (node.getNodeType() == Node.ELEMENT_NODE) {
				        	JSONObject jObj=new JSONObject();
				        	NodeList childNodes=node.getChildNodes();
				        	
				        	boolean flg=true;
				        	for(int j=0;j<childNodes.getLength();j++){
				            	Node cN=childNodes.item(j); 
				            	
				            	if (cN.getNodeType() == Node.ELEMENT_NODE) { 
				            		
				            		if(cN.getNodeName().equalsIgnoreCase("TITLE")){ 
				            			flg=false;
				            			break;
				            		}
				            		if(colMap.containsKey(cN.getNodeName())){ 
				            			
				            			if(cN.getNodeName().equalsIgnoreCase("DSCHEDULEDATE") && 
				            					cN.getTextContent()!=null && !cN.getTextContent().trim().equals("")){ 
				            				Date date1 = new SimpleDateFormat("dd MMM yyyy").parse(cN.getTextContent().trim());
											String val = new SimpleDateFormat("dd/MM/yyyy").format(date1);
											jObj.put(colMap.get(cN.getNodeName()), val);
				            			}else{ 
				            				jObj.put(colMap.get(cN.getNodeName()), cN.getTextContent().trim());
				            			}
				            			
				            		}
				            		
				            	}
				        	
				            	
				        	}
				        	
				        	if(flg)
				        	jArr.add(jObj);
				        	
				        }
				    }
					
					ifr.clearTable("RepaymentDetailsGrid");
					if(jArr.size()>0){ 
						
						ifr.addDataToGrid("RepaymentDetailsGrid", jArr);
					}
					
				}
			}
			
			
			
		}else{ 
			
			cm.mRepLogger.info("XML Request is empty in the provided file");
			
		}
			
			
		}catch(Exception e){
			
			cm.mErrLogger.info("Exception in triggerFlaggingAndUnFlagging-->"+e.getMessage());
//			e.printStackTrace();
			
		}
		
		if(!updtRequest.equalsIgnoreCase("FAILED")){ 
			
			updtRequest=updtRequest+"~~"+jArr.size();
		}
		
		return updtRequest;
	}
	
	public String GenerateRepaymentSchedule(String PID,String loanNo,String doctype,String JSdata)
	{
		String updtRequest="SUCCESS";
		String failureMsg="";
		Properties p=null;
		String service="RepaymentSchedule";
		JSONArray jArr=new JSONArray();
		try{
			p=new Properties();
			p.load(new StringReader(getProperties("serviceINI.properties")));
			
			String strReq=getProperties("GK.LOAN.SCHEDULE.REQ.xml");
			Document doc=convertStringToDocument(strReq);
			if(doc!=null){ 
			
			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("*");
			for (int i = 0; i < nodeList.getLength(); i++) {
		        Node node = nodeList.item(i);
		        if (node.getNodeType() == Node.ELEMENT_NODE) {
		            
		            cm.mRepLogger.info("Req node name=>"+node.getNodeName());
		            if(node.getNodeName()!=null && !node.getNodeName().equals("")){ 
		            	if(node.getNodeName().equalsIgnoreCase("company")){ 
		            		
		            		node.setTextContent(getCompanyCode());
		            	}else if(node.getNodeName().equalsIgnoreCase("password")){ 
		            		
		            		node.setTextContent(p.getProperty("password"));
		            	}else if(node.getNodeName().equalsIgnoreCase("userName")){ 
		            		
		            		node.setTextContent(p.getProperty("userName"));
		            	}else if(node.getNodeName().equalsIgnoreCase("criteriaValue")){ 
		            		
		            		node.setTextContent(loanNo);
		            	}
		            	
		            }
		        }
		    } 
            
			String finalReq=convertDocumentToString(doc);
			cm.mRepLogger.info("final xml after update=>"+finalReq);
			
			
			String resp=executeSOAPCall(PID,loanNo,service,finalReq,p.getProperty("EndpointURL_Repay"));
//			String resp=getProperties("TestResp.xml");
			cm.mRepLogger.info("Response from Service=>"+resp);
			//parsing the resonse
			
			String finalResp=parseSoapResp(resp);
			
			if(finalResp.contains("~~")){ 
				
				//returning to the caller as the response frmo the service is a failure.
//				updtRequest=finalResp.split("~~")[0];
//				updtRequest=updtRequest+"~~"+finalResp.split("~~")[1];
				return finalResp;
			}
			else if(finalResp.equalsIgnoreCase("success")){ 
			
				//if the response is success then parse it and push the data to repaymentgrid
//				updtRequest=finalResp;
				String columns=p.getProperty("RepaymentFeildsMapping");
				String[] col=columns.split(",");
				Map<String,String> colMap=new HashMap<String,String>();
				for(int k=0;k<col.length;k++){ 
					
					colMap.put(col[k].split("~")[0], col[k].split("~")[1]);
				}
//				cm.mRepLogger.info("Response from the repayment schedule WS : "+resp);
				Document respRepayDoc=convertStringToDocument(resp);
				if(respRepayDoc!=null){ 
					
					respRepayDoc.getDocumentElement().normalize();
					NodeList respRepayDocNodeList = respRepayDoc.getElementsByTagName("mGKENQINTPRIOSDETSDetailType");
					
					for (int i = 0; i < respRepayDocNodeList.getLength(); i++) {
				        Node node = respRepayDocNodeList.item(i);
				        if (node.getNodeType() == Node.ELEMENT_NODE) {
				        	JSONObject jObj=new JSONObject();
				        	NodeList childNodes=node.getChildNodes();
				        	
				        	boolean flg=true;
				        	for(int j=0;j<childNodes.getLength();j++){
				            	Node cN=childNodes.item(j); 
				            	
				            	if (cN.getNodeType() == Node.ELEMENT_NODE) { 
				            		
				            		if(cN.getNodeName().equalsIgnoreCase("TITLE")){ 
				            			flg=false;
				            			break;
				            		}
				            		if(colMap.containsKey(cN.getNodeName())){ 
				            			
				            			if(cN.getNodeName().equalsIgnoreCase("DSCHEDULEDATE") && 
				            					cN.getTextContent()!=null && !cN.getTextContent().trim().equals("")){ 
				            				Date date1 = new SimpleDateFormat("dd MMM yyyy").parse(cN.getTextContent().trim());
											String val = new SimpleDateFormat("dd/MM/yyyy").format(date1);
											jObj.put(colMap.get(cN.getNodeName()), val);
				            			}else{ 
				            				jObj.put(colMap.get(cN.getNodeName()), cN.getTextContent().trim());
				            			}
				            			
				            		}
				            		
				            	}
				        	
				            	
				        	}
				        	
				        	if(flg)
				        	jArr.add(jObj);
				        	
				        }
				    }
					String DelQuery="DELETE FROM NG_COLL_LoanRepaymentSchedule where pInstanceID='"+PID+"'";
					ifr.getDataFromDB(DelQuery);
					if(jArr.size()>0){
						cm.mRepLogger.info("JSON Array : "+jArr);
						for(int i=0;i<jArr.size();i++)
						{
							JSONObject obj=(JSONObject) jArr.get(i);
							cm.mRepLogger.info("JSON obj : "+obj);
						String InsertQuey="INSERT INTO dbo.NG_COLL_LoanRepaymentSchedule(pInstanceID, LoanAccountNo, Due_Date, Installment_Amount, Principal_Amount, Interest_Amount, Interest_Paid, Principal_Outstanding,Total_Outstanding)\r\n" + 
								"VALUES ('"+PID+"','"+loanNo+"','"+obj.get("Due Date")+"',"+obj.get("Installment Amt.").toString().replace(",","")+","+obj.get("Principle Amt.").toString().replace(",","")+","+ obj.get("Interest Amt.").toString().replace(",","")+","+obj.get("Interest Paid").toString().replace(",","")+","+obj.get("Principle Outstanding").toString().replace(",","")+","+obj.get("Total Outstanding").toString().replace(",","")+")";
						cm.mRepLogger.info("Insert Query : "+InsertQuey);
						ifr.getDataFromDB(InsertQuey);
						}
						//ifr.addDataToGrid("RepaymentDetailsGrid", jArr);
						
						//added this logic in the caller function
						/*String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
								+ doctype + "'";
						cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
						List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
						cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
						cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);*/
					}
					
				}
			}
			
			
			
		}else{ 
			
			cm.mRepLogger.info("XML Request is empty in the provided file");
			
		}
			
			
		}catch(Exception e){
			
			cm.mErrLogger.info("Exception in triggerFlaggingAndUnFlagging-->"+e.getMessage());
//			e.printStackTrace();
			
		}
		
/*		if(!updtRequest.equalsIgnoreCase("FAILED")){ 
			
			updtRequest=updtRequest+"~~"+jArr.size();
		}*/
		
		return updtRequest;
	}
	

	//generating the SOA with grid data.
	
	public String GenerateSOA(String PID,String loanNo,String doctype,String JSdata)
	{
		String updtRequest="SUCCESS";
		String failureMsg="";
		Properties p=null;
		String service="SOA";
		JSONArray jArr=new JSONArray();
		cm.mRepLogger.info("<<<<<<<<<<<Inside GenerateSOA method>>>>>>>>>>>");
//		cm.mRepLogger.info("Row Index for the SOA ::"+JSdata);
//		cm.mRepLogger.info(ifr.getTableCellValue("Outward_Document_ListView", Integer.parseInt(JSdata), 9));
//		cm.mRepLogger.info(ifr.getTableCellValue("Outward_Document_ListView", Integer.parseInt(JSdata), 10));
		
		//from date
		String fDt=(ifr.getTableCellValue("Outward_Document_ListView", Integer.parseInt(JSdata), 9)).toString();
		
		Date fdate = CollectionCommonMethod.parseDate(fDt,false);
		if(fdate!=null)
		fDt = new SimpleDateFormat("yyyyMMdd").format(fdate);
		
		//to date
		String tDt=(ifr.getTableCellValue("Outward_Document_ListView", Integer.parseInt(JSdata), 10)).toString();
		
		Date tdate = CollectionCommonMethod.parseDate(tDt,false);
		if(tdate!=null)
		tDt = new SimpleDateFormat("yyyyMMdd").format(tdate);
		
		cm.mRepLogger.info("Generating SOA from "+fDt+" to "+tDt);
		if(fDt==null || tDt==null){ 
			
			cm.mRepLogger.info("From Date or To Date are missing, So SOA cannot be generated ");
			return "From Date or To Date are missing";
		}
		
		try{
			p=new Properties();
			p.load(new StringReader(getProperties("serviceINI.properties")));
			
			String strReq=getProperties("WS.SOA.REQ.xml");
			Document doc=convertStringToDocument(strReq);
			if(doc!=null){ 
			
			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("*");
			String nxtNodeVal="";
			for (int i = 0; i < nodeList.getLength(); i++) {
		        Node node = nodeList.item(i);
		        if (node.getNodeType() == Node.ELEMENT_NODE) {
		            
		            cm.mRepLogger.info("Req node name=>"+node.getNodeName());
		            if(node.getNodeName()!=null && !node.getNodeName().equals("")){ 
		            	if(node.getNodeName().equalsIgnoreCase("company")){ 
		            		
		            		node.setTextContent(getCompanyCode());
		            	}else if(node.getNodeName().equalsIgnoreCase("password")){ 
		            		
		            		node.setTextContent(p.getProperty("password"));
		            	}else if(node.getNodeName().equalsIgnoreCase("userName")){ 
		            		
		            		node.setTextContent(p.getProperty("userName"));
		            	}else if(node.getNodeName().equalsIgnoreCase("columnName")){ 
		            		String ndTxt=node.getTextContent();
		            		if(ndTxt!=null && !ndTxt.trim().equals("") && ndTxt.trim().equalsIgnoreCase("ARR.ID")){ 
		            			
		            			nxtNodeVal=loanNo;
		            		}else if(ndTxt!=null && !ndTxt.trim().equals("") && ndTxt.trim().equalsIgnoreCase("FROM.DATE")){ 
		            			
		            			nxtNodeVal=fDt;
		            		}else if(ndTxt!=null && !ndTxt.trim().equals("") && ndTxt.trim().equalsIgnoreCase("TO.DATE")){ 
		            			
		            			nxtNodeVal=tDt;
		            		}
		            		
		            	}else if(node.getNodeName().equalsIgnoreCase("criteriaValue")){ 
		            		
		            		node.setTextContent(nxtNodeVal);
		            	}
		            	
		            }
		        }
		    } 
            
			String finalReq=convertDocumentToString(doc);
			cm.mRepLogger.info("final SOA xml after update=>"+finalReq);
			
			
			String resp=executeSOAPCall(PID,loanNo,service,finalReq,p.getProperty("EndpointURL"));
//			String resp=getProperties("TestResp.xml");
			cm.mRepLogger.info("Response from Service=>"+resp);
			//parsing the resonse
			
			String finalResp=parseSoapResp(resp);
			
			if(finalResp.contains("~~")){ 
				
				//returning to the caller as the response from the service is a failure.

				return finalResp;
			}
			else if(finalResp.equalsIgnoreCase("success")){ 
			
				//if the response is success then parse it and push the data to repaymentgrid
//				updtRequest=finalResp;
				String columns=p.getProperty("SOAGridFeilds");
				String[] col=columns.split(",");
				List<String> colMap=Arrays.asList(col);

				String lineCols=p.getProperty("SOALinearFields");
				String[] lCols=lineCols.split(",");
				List<String> linrColMap=Arrays.asList(lCols);
				JSONObject jObjLinr=new JSONObject();
				
//				cm.mRepLogger.info("Response from the repayment schedule WS : "+resp);
				Document respRepayDoc=convertStringToDocument(resp);
				if(respRepayDoc!=null){ 
					
					respRepayDoc.getDocumentElement().normalize();
					NodeList respRepayDocNodeList = respRepayDoc.getElementsByTagName("mGKSTMTACCTENTYDetailType");
					
					for (int i = 0; i < respRepayDocNodeList.getLength(); i++) {
				        Node node = respRepayDocNodeList.item(i);
				        if (node.getNodeType() == Node.ELEMENT_NODE) {
				        	JSONObject jObj=new JSONObject();
				        	
				        	NodeList childNodes=node.getChildNodes();
				        	
				        	boolean flg=true;
				        	for(int j=0;j<childNodes.getLength();j++){
				            	Node cN=childNodes.item(j); 
				            	
				            	if (cN.getNodeType() == Node.ELEMENT_NODE) { 
				            		
				            		//linear data json
				            		if(i==0 && linrColMap.contains(cN.getNodeName())){ 
				            			
				            			String txt=cN.getTextContent().trim();
				            			if(cN.getNodeName().equalsIgnoreCase("DISBDATE")){ 
				            				
				            				if(txt!=null && !txt.trim().equals("")){ 
				            					
				            					Date txtdate = CollectionCommonMethod.parseDate(txt,false);
				            					if(txtdate!=null)
				            					txt = new SimpleDateFormat("dd-MM-yyyy").format(txtdate);
				            				}else{ 
				            					
				            					txt="";
				            				}
				            				
				            				jObjLinr.put(cN.getNodeName(), txt);
				            			}else{ 
				            				jObjLinr.put(cN.getNodeName(), txt);
				            			}
				            			
				            		}
				            		
				            		//grid data json
				            		if(colMap.contains(cN.getNodeName())){ 
				            			
				            			String txt=cN.getTextContent().trim();
				            			if(cN.getNodeName().equalsIgnoreCase("DEBITAMT") || cN.getNodeName().equalsIgnoreCase("CREDITAMT") || 
				            					cN.getNodeName().equalsIgnoreCase("BNCDEBIT") || cN.getNodeName().equalsIgnoreCase("BNCCREDIT") || 
				            					cN.getNodeName().equalsIgnoreCase("LTEDEBIT") || cN.getNodeName().equalsIgnoreCase("LTECREDIT")){ 
				            				
				            				if(txt==null || txt.trim().equals("")){ 
				            					
				            					txt="0";
				            				}
				            			}
				            			
				            			if(cN.getNodeName().equalsIgnoreCase("TRANSDATE") || cN.getNodeName().equalsIgnoreCase("VALUEDATE") || 
				            					cN.getNodeName().equalsIgnoreCase("DISBDATE")){ 
				            				
				            				if(txt!=null && !txt.trim().equals("")){ 
				            					
				            					Date txtdate = CollectionCommonMethod.parseDate(txt,false);
//				            					cm.mRepLogger.info("found the date format : "+txtdate);
//				            					cm.mRepLogger.info("final date format : "+(new SimpleDateFormat("dd/MM/yyyy").format(txtdate)));
				            					if(txtdate!=null)
				            					txt = new SimpleDateFormat("dd-MM-yyyy").format(txtdate);
				            				}else{ 
				            					
				            					txt="";
				            				}
				            			}
				            			
				            			jObj.put(cN.getNodeName(), txt);
				            			
				            		}
				            		
				            	}
				        	
				            	
				        	}
				        	
				        	if(flg)
				        	jArr.add(jObj);
				        	
				        }
				    }
					
					//inserting the linear data
					String linrDelQuery="DELETE FROM NG_COLL_SOA_LINEAR_DATA where pInstanceID='"+PID+"'";
					ifr.getDataFromDB(linrDelQuery);
					if(jObjLinr.size()>0){ 
						
						String linrInsertQuey="INSERT INTO dbo.NG_COLL_SOA_LINEAR_DATA (VALUEDATE,FROMDATE,TODATE,ARRID,CUSTOMERID,CUSTOMERNAME,CUSTOMERADDR,CUSTOMERPHONE,BRANCH,PRODUCT,INTRATE,TENURE,INSPERIOD,SANCAMT,DISBAMT,FREQUENCY,INSCOMPLETED,FUTCOUNT,EMIAMOUNT,STATUS,PRINCIPALPAID,INTERESTPAID,FUTINS,PRINCIPLEOD,INTERESTOD,CHARGEOD,UNCAMT,CHARGENETOFF,OSNETOFF,pInstanceID)\r\n" + 
								"VALUES ('"+jObjLinr.get("DISBDATE")+"','"+jObjLinr.get("FROMDATE")+"','"+jObjLinr.get("TODATE")+"','"+jObjLinr.get("ARRID")+"','"+jObjLinr.get("CUSTOMERID")+"','"+jObjLinr.get("CUSTOMERNAME")+"','"+jObjLinr.get("CUSTOMERADDR")+"','"+jObjLinr.get("CUSTOMERPHONE")+"','"+jObjLinr.get("BRANCH")+"','"+jObjLinr.get("PRODUCT")+"','"+jObjLinr.get("INTRATE")+"','"+jObjLinr.get("TENURE")+"','"+jObjLinr.get("INSPERIOD")+"','"+jObjLinr.get("SANCAMT")+"','"+jObjLinr.get("DISBAMT")+"','"+jObjLinr.get("FREQUENCY")+"','"+jObjLinr.get("INSCOMPLETED")+"','"+jObjLinr.get("FUTCOUNT")+"','"+jObjLinr.get("EMIAMOUNT")+"','"+jObjLinr.get("STATUS")+"','"+jObjLinr.get("PRINCIPALPAID")+"','"+jObjLinr.get("INTERESTPAID")+"','"+jObjLinr.get("FUTINS")+"','"+jObjLinr.get("PRINCIPLEOD")+"','"+jObjLinr.get("INTERESTOD")+"','"+jObjLinr.get("CHARGEOD")+"','"+jObjLinr.get("UNCAMT")+"','"+jObjLinr.get("CHARGENETOFF")+"','"+jObjLinr.get("OSNETOFF")+"','"+PID+"')";
						cm.mRepLogger.info("Insert Query : "+linrInsertQuey);
						ifr.getDataFromDB(linrInsertQuey);
					}
					
					//inserting the cmplx data
					String DelQuery="DELETE FROM NG_COLL_SOA_CMPLX_DATA where pInstanceID='"+PID+"'";
					ifr.getDataFromDB(DelQuery);
					if(jArr.size()>0){
						cm.mRepLogger.info("JSON Array : "+jArr);
						for(int i=0;i<jArr.size();i++)
						{
							JSONObject obj=(JSONObject) jArr.get(i);
							cm.mRepLogger.info("JSON obj : "+obj);
						String InsertQuey="INSERT INTO dbo.NG_COLL_SOA_CMPLX_DATA (TRANSDATE,VALUEDATE,PARTICULAR,DEBITAMT,CREDITAMT,BNCDEBIT,BNCCREDIT,LTEDEBIT,LTECREDIT,ARRID,pInstanceID)\r\n" + 
								"VALUES ('"+obj.get("TRANSDATE")+"','"+obj.get("VALUEDATE")+"','"+obj.get("PARTICULAR")+"','"+obj.get("DEBITAMT")+"','"+obj.get("CREDITAMT")+"','"+obj.get("BNCDEBIT")+"','"+obj.get("BNCCREDIT")+"','"+obj.get("LTEDEBIT")+"','"+obj.get("LTECREDIT")+"','"+loanNo+"','"+PID+"')";
						cm.mRepLogger.info("Insert Query : "+InsertQuey);
						ifr.getDataFromDB(InsertQuey);
						}
						
					}
					
					//generating the document.
					//this logic moved to caller (initaitor)
					/*String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
							+ doctype + "'";
					cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
					List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
					cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
					cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);*/
					
				}
			}
			
			
			
		}else{ 
			
			cm.mRepLogger.info("XML Request is empty in the provided file");
			
		}
			
			
		}catch(Exception e){
			
			cm.mErrLogger.info("Exception in triggerFlaggingAndUnFlagging-->"+e.getMessage());
			return "FAILED~~Error in generating the SOA, Please contact administrator.";
		}
		
/*		if(!updtRequest.equalsIgnoreCase("FAILED")){ 
			
			updtRequest=updtRequest+"~~"+jArr.size();
		}*/
		
		return updtRequest;
	}
	
	
	public String triggerPreclsActivity(String PID, String loanNo) {

		String updtRequest = "SUCCESS";

		String failureMsg = "";
		Properties p = null;
		String service = "PreClosureActivity";
		
		try {
			p = new Properties();
			p.load(new StringReader(getProperties("serviceINI.properties")));

			String strReq = getProperties("PRECLOSE.ACT.REQ.xml");
			Document doc = convertStringToDocument(strReq);
			if (doc != null) {

				doc.getDocumentElement().normalize();
				NodeList nodeList = doc.getElementsByTagName("*");
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node node = nodeList.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE) {

						cm.mRepLogger.info("Req node name=>" + node.getNodeName());
						if (node.getNodeName() != null && !node.getNodeName().equals("")) {
							if (node.getNodeName().equalsIgnoreCase("company")) {

								node.setTextContent(getCompanyCode());
							} else if (node.getNodeName().equalsIgnoreCase("password")) {

								node.setTextContent(p.getProperty("password"));
							} else if (node.getNodeName().equalsIgnoreCase("userName")) {

								node.setTextContent(p.getProperty("userName"));
							} else if (node.getNodeName().equalsIgnoreCase("Arrangement")) {

								node.setTextContent(loanNo);
							}

						}
					}
				}

				String finalReq = convertDocumentToString(doc);
				cm.mRepLogger.info("final xml after update=>" + finalReq);

				String resp = executeSOAPCall(PID, loanNo, service, finalReq, p.getProperty("EndpointURL"));
				// String resp=getProperties("TestResp.xml");
				cm.mRepLogger.info("Response from Service=>" + resp);
				
				if(!resp.equalsIgnoreCase("FAIL")){ 
					String finalResp = parseSoapResp(resp);
					if (finalResp.contains("~~")) {
						return finalResp;
					} else if (finalResp.equalsIgnoreCase("success")) {
						return updtRequest;
					}					
				}else{ 
					
					return "FAILED";
				}


			}

		} catch (Exception e) {
			cm.mErrLogger.info("Exception in triggerPreclsActivity-->"+e.getMessage());
//			e.printStackTrace();
		}

		return updtRequest;
	}
	
	public String fetchPreClosure(String PID,String loanNo){ 
		
		String preclsactvresp=triggerPreclsActivity(PID,loanNo);
		String updtRequest="SUCCESS";
		
		if(preclsactvresp.equalsIgnoreCase("success")){ 
		
		String failureMsg="";
		Properties p=null;
		String service="PreClosureEnquiry";
		
		try{
			
			p=new Properties();
			p.load(new StringReader(getProperties("serviceINI.properties")));
			String strReq=getProperties("PRECLOSE.ENQ.REQ.xml");
			Document doc=convertStringToDocument(strReq);
			if(doc!=null){ 
			
			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("*");
			for (int i = 0; i < nodeList.getLength(); i++) {
		        Node node = nodeList.item(i);
		        if (node.getNodeType() == Node.ELEMENT_NODE) {
		            
		            cm.mRepLogger.info("Req node name=>"+node.getNodeName());
		            if(node.getNodeName()!=null && !node.getNodeName().equals("")){ 
		            	if(node.getNodeName().equalsIgnoreCase("company")){ 
		            		
		            		node.setTextContent(getCompanyCode());
		            	}else if(node.getNodeName().equalsIgnoreCase("password")){ 
		            		
		            		node.setTextContent(p.getProperty("password"));
		            	}else if(node.getNodeName().equalsIgnoreCase("userName")){ 
		            		
		            		node.setTextContent(p.getProperty("userName"));
		            	}else if(node.getNodeName().equalsIgnoreCase("criteriaValue")){ 
		            		
		            		node.setTextContent(loanNo);
		            	}
		            	
		            }
		        }
		    } 
            
			String finalReq=convertDocumentToString(doc);
			cm.mRepLogger.info("final xml after update=>"+finalReq);
			
			Thread.sleep(Long.parseLong(p.getProperty("PreClosureEnquiryDelaySeconds"))*1000);	//waiting for some time before hitting the pre closure enquiry/2nd service.

			String resp=executeSOAPCall(PID,loanNo,service,finalReq,p.getProperty("EndpointURL"));
//			String resp=getProperties("TestResp.xml");
			cm.mRepLogger.info("Response from Service=>"+resp);
			//parsing the response
			
			String finalResp = parseSoapResp(resp);
			if (finalResp.contains("~~")) {
				return finalResp;
			} else if (finalResp.equalsIgnoreCase("success")) {
				
				updtRequest=finalResp;
				String columns=p.getProperty("PreClosureFieldsMapping");
				String gridCol=p.getProperty("PreClosureGridMapping");
				String gridID=p.getProperty("PreClosureGridID");
				String preCurrDate=p.getProperty("PreClosureCurrentDateInT24");
				String[] col=columns.split(",");
				String[] gridCols=gridCol.split(",");
				Map<String,String> colMap=new HashMap<String,String>();
				Map<String,String> colGridMap=new HashMap<String,String>();
				JSONArray jarr=new JSONArray();
				
				for(int k=0;k<col.length;k++){ 
					
					colMap.put(col[k].split("~")[0], col[k].split("~")[1]);
					
					//clearing the data in the fields as new data will be posted further.
					//Handling the below code in JS.
					/*String id=col[k].split("~")[1];
					if(id.contains("##")){ 
						String[] idArr=id.split("##");
						for(int q=0;q<idArr.length;q++){ 
							ifr.setValue(idArr[q], "0");
						}
					}else{ 
						
						ifr.setValue(id, "0");
					}*/
					
				}
				for(int m=0;m<gridCols.length;m++){ 
					
					colGridMap.put(gridCols[m].split("~")[0], gridCols[m].split("~")[1]);
				}
				
				Document respPreClsDoc=convertStringToDocument(resp);
				if(respPreClsDoc!=null){ 
					
					respPreClsDoc.getDocumentElement().normalize();
					NodeList respPreClsNodeList = respPreClsDoc.getElementsByTagName("mGKENQPRECLOSEDetailType");
					
					for (int i = 0; i < respPreClsNodeList.getLength(); i++) {
						JSONObject jobj=new JSONObject();
						Node node = respPreClsNodeList.item(i);
//				        if (node.getNodeType() == Node.ELEMENT_NODE && checkRowContent(node)) {
				        if (node.getNodeType() == Node.ELEMENT_NODE) {	
				        	NodeList childNodes=node.getChildNodes();
				        	
				        	//getting current date from prop file - only for UAT (as UAT T24 date is backdated).
				        	String iniDate="";
				        	if(preCurrDate!=null && preCurrDate.equalsIgnoreCase("current")){ 
				        		Date cd=new Date();
				        		iniDate= new SimpleDateFormat("dd/MM/yyyy").format(cd);		        		
				        	}else{ 
				        		iniDate=preCurrDate;
				        	}
				        	
				        	for(int j=0;j<childNodes.getLength();j++){
				            	Node cN=childNodes.item(j); 
				            	
				            	if (cN.getNodeType() == Node.ELEMENT_NODE) { 
				            		
				            		cm.mRepLogger.info(iniDate+"---iniDate---");
				            		if(cN.getNodeName().equalsIgnoreCase("billdate")){ 
				            			//setting values to form fields.
				            			cm.mRepLogger.info("BILLDATE FOUND-->"+cN.getTextContent().trim());
				            			String Dtval=cN.getTextContent().trim().replaceAll(",", "");
				            			if(Dtval!=null && !Dtval.equals("")){ 
				            				Date date1 = new SimpleDateFormat("dd MMM yyyy").parse(Dtval);
											String servDt = new SimpleDateFormat("dd/MM/yyyy").format(date1);
											if(servDt!=null && servDt.equals(iniDate)){ 
												setPreClosureDataToApportionMent(colMap,node);
											}
				            			}
				            	
				            		}
				            		
				            		//setting values to form fields
				            		/*if(colMap.containsKey(cN.getNodeName())){ 
				            			
				            			String formID=colMap.get(cN.getNodeName());
				            			String val=cN.getTextContent().trim().replaceAll(",", "");
				            			val=(val!=null && !val.equals("")) ? val : "0";
				            			
				            			//setting the value to multiple fields.
				            			for(int y=0;y<formID.split("##").length;y++){ 
				            				String extVal=ifr.getValue(formID.split("##")[y]).toString();
				            				if(extVal!=null && !extVal.trim().equals("")){ 
				            					
				            					ifr.setValue(formID.split("##")[y], String.valueOf((Double.valueOf(extVal)+Double.valueOf(val))));
				            				}else{ 
				            					
				            					ifr.setValue(formID.split("##")[y], val);
				            				}
				            				
				            			}
				            			
				            		}*/
				            		
				            		//setting values to grid.
				            		if(colGridMap.containsKey(cN.getNodeName())){ 
				            			
				            			String gridColName=colGridMap.get(cN.getNodeName());
				            			String val=cN.getTextContent().trim().replaceAll(",", "");
				            			val=(val!=null && !val.equals("")) ? val : "0";
				            			
				            			if(cN.getNodeName().equalsIgnoreCase("BILLDATE") || cN.getNodeName().equalsIgnoreCase("INFOPAYDATE")){ 
				            				
				            				if(val!=null && !val.equals("") && !val.equals("0")){ 
				            					Date date1 = new SimpleDateFormat("dd MMM yyyy").parse(val);
												val = new SimpleDateFormat("dd/MM/yyyy").format(date1);
												jobj.put(gridColName,val);
				            				}
				            				
				            			}else{ 
				            				
				            				if(jobj.containsKey(gridColName)){ 
				            					String extVal=(jobj.get(gridColName)!=null) ? (String)jobj.get(gridColName) : "0";
				            					jobj.put(gridColName, String.valueOf(Double.valueOf(val)+Double.valueOf(extVal)));
				            				}else{ 
				            					
				            					jobj.put(gridColName,val);
				            				}
				            			}
				            			
				            			
				            		}
				            		
				            	}
				        	
				        	}
				        	
				        }
				        
//				        break;

	            		//adding to json array.
			        	jarr.add(jobj);		
				    }
					
					//setting values to grid.
					if(jarr.size()>0){ 
						
						ifr.clearTable(gridID);
//						JSONArray jarr=new JSONArray();
//						jarr.add(jobj);
						ifr.addDataToGrid(gridID, jarr);
					}
					
					
				}
				
				
				return updtRequest;
			}else{ 
				
				updtRequest=finalResp;
			}
			
			
			
		}else{ 
			
			cm.mRepLogger.info("XML Request is empty in the provided file");
			
		}
			
			
		}catch(Exception e){
			
			cm.mErrLogger.info("Exception in fetchPreClosure-->"+e.getMessage());
//			e.printStackTrace();
			
		}
		
		
		}else{ 
			
			cm.mErrLogger.info("Error in Preclosure Activity before the enquiry.");
			updtRequest=preclsactvresp;
		}
		
		return updtRequest;
	}


public String parseSoapResp(String resp){ 
	
	String updtRequest="SUCCESS";
	String failureMsg="";
	
	if(resp!=null && !resp.trim().equals("") && !resp.trim().equalsIgnoreCase("FAIL")){ 
		
		Document respDoc=convertStringToDocument(resp);
		if(respDoc!=null){
		respDoc.getDocumentElement().normalize();
		
		NodeList respNodeList = respDoc.getElementsByTagName("Status");
		if(respNodeList.getLength()>0){ 
		
			MainStatus:	
			for (int i = 0; i < respNodeList.getLength(); i++) {
		        Node node = respNodeList.item(i);
		        if (!updtRequest.equalsIgnoreCase("failed")) {
//		            cm.mRepLogger.info("Resp node name=>"+node.getNodeName());
		            
		            NodeList childNodes=node.getChildNodes();
		            for(int j=0;j<childNodes.getLength();j++){
		            	Node cN=childNodes.item(j);
		            	if(cN.getNodeType() == Node.ELEMENT_NODE){ 
		            	
		            		if(cN.getNodeName().equalsIgnoreCase("successIndicator") && (cN.getTextContent()==null || 
		            				cN.getTextContent().equalsIgnoreCase("T24Error") || cN.getTextContent().equalsIgnoreCase("TWSError"))){ 
		            			
		            			failureMsg="T24Error : "+getErrorMsg(childNodes);
		            			updtRequest="FAILED";
		            			break MainStatus;
		            		}
		            		else if(cN.getNodeName().equalsIgnoreCase("successIndicator") && (cN.getTextContent()==null || 
	            				!cN.getTextContent().equalsIgnoreCase("Success"))){ 
	            			
		            			updtRequest="FAILED";
		            			break;
		            		}
		            		
		            	}
		            }
		            
		        }else{ 
		        	
		        	updtRequest="FAILED";
        			break;
		        }
		    }
		
		}else{ 
			
			updtRequest="FAILED";
		}
		
	}
	}else{ 
		
		updtRequest="FAILED";
		
		if(resp!=null && resp.trim().equalsIgnoreCase("FAIL")){ 
			failureMsg="Connectivity issue with T24, Please contact administrator";
		}else{ 
			failureMsg="No response received from T24 service";
		}
	}
	
	if(!failureMsg.equals("")){ 
		
		updtRequest=updtRequest+"~~"+failureMsg;
	}
	
	return updtRequest;
}

	
//fetching the document parameters from T24.

public String fetchDocParams(String PID, String loanNo) {

	String updtRequest = "SUCCESS";

	String failureMsg = "";
	Properties p = null;
	String service = "IssueDocument";
	
	try {
		p = new Properties();
		p.load(new StringReader(getProperties("serviceINI.properties")));

		String strReq = getProperties("ISS.DOC.AMT.REQ.xml");
		Document doc = convertStringToDocument(strReq);
		if (doc != null) {

			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("*");
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {

					cm.mRepLogger.info("Req node name=>" + node.getNodeName());
					if (node.getNodeName() != null && !node.getNodeName().equals("")) {
						if (node.getNodeName().equalsIgnoreCase("company")) {

							node.setTextContent(getCompanyCode());
						} else if (node.getNodeName().equalsIgnoreCase("password")) {

							node.setTextContent(p.getProperty("password"));
						} else if (node.getNodeName().equalsIgnoreCase("userName")) {

							node.setTextContent(p.getProperty("userName"));
						} else if (node.getNodeName().equalsIgnoreCase("criteriaValue")) {

							node.setTextContent(loanNo);
						}

					}
				}
			}

			String finalReq = convertDocumentToString(doc);
			cm.mRepLogger.info("final xml after update=>" + finalReq);

			String resp = executeSOAPCall(PID, loanNo, service, finalReq, p.getProperty("EndpointURL"));
			// String resp=getProperties("TestResp.xml");
			cm.mRepLogger.info("Response from Service=>" + resp);
			
			if(resp.equalsIgnoreCase("FAIL")){  
				
				return resp;
			}
			
			String finalResp = parseSoapResp(resp);

			if (finalResp.contains("~~")) {
				return finalResp;
			} else if (finalResp.equalsIgnoreCase("success")) {
				
				String query=p.getProperty("IssueDocumentFieldMappingQuery");
				
				Document respDocIssue=convertStringToDocument(resp);
				if(respDocIssue!=null){ 
					
					respDocIssue.getDocumentElement().normalize();
					NodeList respIssueDocNodeList = respDocIssue.getElementsByTagName("mGKENQISSDOCDetailType");
					
					for (int i = 0; i < respIssueDocNodeList.getLength(); i++) {
				        Node node = respIssueDocNodeList.item(i);
				        if (node.getNodeType() == Node.ELEMENT_NODE) {
				        	
				        	NodeList childNodes=node.getChildNodes();
				        	
				        	for(int j=0;j<childNodes.getLength();j++){
				            	Node cN=childNodes.item(j); 
				            	
				            	if (cN.getNodeType() == Node.ELEMENT_NODE) { 
				            		
				            		if(query.contains("##"+cN.getNodeName()+"##")){ 
				            			
				            			String val=cN.getTextContent().trim().replaceAll(",", "");
				            			query=query.replaceAll("##"+cN.getNodeName()+"##", (val.equals("") ? "NULL" : val));
				            			
				            		}
				            		
				            	}
				        	
				            	
				        	}
				        	
				        	
				        }
				        
				    }
					
					query=query.replaceAll("##PID##", PID);
					
					ifr.getDataFromDB(query);
					
				}
				
				return updtRequest;
			}else{ 
				
				updtRequest=finalResp;
			}

		}

	} catch (Exception e) {
		cm.mErrLogger.info("Exception in triggerPreclsActivity-->"+e.getMessage());
//		e.printStackTrace();
	}

	return updtRequest;
}

//fetchcompany code / branch code
public String getCompanyCode() {
    String branch_Code = "";
    String Query = "SELECT Org_Unique_ID FROM RLOS_MASTER_ORGANISATION"
            + " WITH(NOLOCK) WHERE Org_Name='"+ifr.getValue("Branch_Details").toString().trim()+"'";
    
    List<List<String>> brnchLst=ifr.getDataFromDB(Query);
    
    if(brnchLst.size()>0){ 
    	
    	branch_Code=brnchLst.get(0).get(0);
    }
    
    return branch_Code;
}


public void setPreClosureDataToApportionMent(Map<String,String> m, Node n){ 
	
	cm.mRepLogger.info("MAP=1==>"+m);
	cm.mRepLogger.info("NODE=1==>"+n);	
	
	NodeList childNodes=n.getChildNodes();
	for(int j=0;j<childNodes.getLength();j++){
    	Node cN=childNodes.item(j);  
    	cm.mRepLogger.info("CHILD NODE===>"+cN.getNodeName());	
    	if(m.containsKey(cN.getNodeName())){ 
    		
    		String formID=m.get(cN.getNodeName());
    		String val=cN.getTextContent().trim().replaceAll(",", "");
    		val=(val!=null && !val.equals("")) ? val : "0";   		
    		//setting the value to multiple fields.
    		for(int y=0;y<formID.split("##").length;y++){ 
    			String extVal=ifr.getValue(formID.split("##")[y]).toString();
    			if(extVal!=null && !extVal.trim().equals("")){ 
    				
    				ifr.setValue(formID.split("##")[y], String.valueOf((Double.valueOf(extVal)+Double.valueOf(val))));
    			}else{ 
    				
    				ifr.setValue(formID.split("##")[y], val);
    			}
    			
    		}
    	}
	}	
	
}

//setting bounce/late/pre closure charges from grid to apportionment if any saved data is available & then calling the waiver to waiveoff any charges on tab click.
public void setPreClosureDataToApportionMentOnTabClick(){ 
	
	cm.mErrLogger.info("Setting the values to preclosure apportionment on tab click, if the settlement is already available in grid");
	
	try{ 
		Properties p=new Properties();
		p.load(new StringReader(getProperties("serviceINI.properties")));
		String gridID=p.getProperty("PreClosureGridID");
		String preCurrDate=p.getProperty("PreClosureCurrentDateInT24");
    	String iniDate="";
    	if(preCurrDate!=null && preCurrDate.equalsIgnoreCase("current")){ 
    		Date cd=new Date();
    		iniDate= new SimpleDateFormat("dd/MM/yyyy").format(cd);		        		
    	}else{ 
    		iniDate=preCurrDate;
    	}
    	
		JSONArray jarr=ifr.getDataFromGrid(gridID);
		
		if(jarr!=null)
			for(int i=0;i<jarr.size();i++){ 
				JSONObject jobjRow=(JSONObject) jarr.get(i);
				String billDt=jobjRow.get("Bill Date").toString();
				if(billDt!=null){ 
					Date d=CollectionCommonMethod.parseDate(billDt, false);
					String strGridDT=new SimpleDateFormat("dd/MM/yyyy").format(d);
					
					if(iniDate.equals(strGridDT)){ 
						
						String bf=jobjRow.get("Bounce Fee").toString();
						String bfgst=jobjRow.get("Bounce Fee GST").toString();
						String lf=jobjRow.get("Late Fee").toString();
						String lfgst=jobjRow.get("Late Fee GST").toString();
						String pc=jobjRow.get("Pre Closure Amt.").toString();
						String pcgst=jobjRow.get("Pre Closure GST").toString();
						String pcamt=jobjRow.get("Bill Amt.").toString();
						
						BigDecimal bffinal=(bf==null || bf.trim().equals("")) ? BigDecimal.ZERO : new BigDecimal(bf);
						BigDecimal bfgfinal=(bfgst==null || bfgst.trim().equals("")) ? BigDecimal.ZERO : new BigDecimal(bfgst);
						BigDecimal lffinal=(lf==null || lf.trim().equals("")) ? BigDecimal.ZERO : new BigDecimal(lf);
						BigDecimal lfgfinal=(lfgst==null || lfgst.trim().equals("")) ? BigDecimal.ZERO : new BigDecimal(lfgst);
						BigDecimal pcfinal=(pc==null || pc.trim().equals("")) ? BigDecimal.ZERO : new BigDecimal(pc);
						BigDecimal pcgfinal=(pcgst==null || pcgst.trim().equals("")) ? BigDecimal.ZERO : new BigDecimal(pcgst);
						BigDecimal pcamtfinal=(pcamt==null || pcamt.trim().equals("")) ? BigDecimal.ZERO : new BigDecimal(pcamt);
						
						ifr.setValue("q_Apportionment_I_Bounce_Charges", bffinal.add(bfgfinal).toString());
						ifr.setValue("q_Apportionment_I_LP_Charges", lffinal.add(lfgfinal).toString());
						ifr.setValue("q_Apportionment_I_Pre_closure_Charges", pcfinal.add(pcgfinal).toString());
						ifr.setValue("q_Apportionment_I_Pre_closure_amount", pcamtfinal.toString());
						break;
					}
					
				}
				
			}
		
	}catch(Exception e){ 
		
		cm.mErrLogger.info("Error in setting the values to preclosure apportionment on tab click, if the settlement is already available in grid");
		cm.mErrLogger.info("",e);
	}
	
	
}

public boolean checkRowContent(Node n){ 
	
	boolean b=false;
	
	NodeList childNodes=n.getChildNodes();
	for(int j=0;j<childNodes.getLength();j++){
    	Node cN=childNodes.item(j);  
    	if(cN.getTextContent()!=null && !cN.getTextContent().trim().equals("")){ 
    		
    		b=true;
    		break;
    	}

	}
	return b;
}

}
