package com.newgen.iforms.user.collection;

import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.FormDef;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.iforms.user.collection.services.CollectionCommonServices;
import com.newgen.iforms.user.collection.services.Status;

public class CollectionEntry implements IFormServerEventHandler {
	private IFormReference ifr = null;
	CollectionCommonMethod cm = new CollectionCommonMethod(ifr);

	public CollectionEntry() {
		cm.mRepLogger.info("<--Inside CollectionEntry-->");
		// logger = new CustomLogger();
	}

	@Override
	public void beforeFormLoad(FormDef arg0, IFormReference arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public String executeCustomService(FormDef arg0, IFormReference arg1, String arg2, String arg3, String arg4) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONArray executeEvent(FormDef arg0, IFormReference arg1, String arg2, String arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String executeServerEvent(IFormReference ifr, String ControlID, String EventType, String JSdata) {
		this.ifr = ifr;

		// CollectionCommonMethod cm = new CollectionCommonMethod(ifr);

		/*
		 * try {
		 * 
		 * String query =
		 * "update CMPLX_COLL_CRE_Collection_Receipt_Entry set Authorizor_Date=getDate() where TransactionId='"
		 * + formConfig.getConfigElement("ProcessInstanceId") +
		 * "' and Fragment_ID='" + formConfig.getConfigElement("WorkitemId") +
		 * "'"; cm.mRepLogger.info("Payment_Authorization Query:::" + query);
		 * //formObject.setNGValue(
		 * "Collection_Receipt_Entry_Details_Authorizer_ID", strUserName);
		 * ifr.saveDataInDB(query); StrData contains PID as well as Mobile no.
		 * 
		 * // Sendinf SMS code String
		 * requestID=getSequenceNumber(ProcessInstanceId); String
		 * mobileNo=formObject.getNGValue("CustomerInformation_Mobile_No_1");
		 * String messageText=otherMessage.replace("#Collection_Amount#",
		 * Collection_Receipt_Entry_Details_Collection_Amount);
		 * messageText=messageText.replace("#LoanNo#",
		 * formObject.getNGValue("Loan_Account_No"));
		 * messageText=messageText.replace("#Collection_Entry_Date#",
		 * formObject.getNGValue(
		 * "Collection_Receipt_Entry_Details_Collection_Entry_Date"));
		 * messageText=messageText.replace("#RequestID#", requestID); String
		 * smsQuery=
		 * "INSERT INTO [dbo].[NG_SMSEMAIL_COMMON]([RequestId],[OriginatingChannel],[RequestType],[MobileNumber],[MessageText],[Priority],[GroupID],[RequestCounter],[Loan_Account_No]) VALUES ('"
		 * +requestID+"','COLL','SMS','"+mobileNo+"','"+messageText+"','"+
		 * priority+ "','AUBANK','"+requestCounter+"','"+formObject.getNGValue(
		 * "Loan_Account_No")+ "')";
		 * cm.mRepLogger.info("smsQuery::::"+smsQuery); int
		 * status=formObject.saveDataIntoDataSource(smsQuery);
		 * cm.mRepLogger.info("sms insert status::"+status); }
		 * 
		 * } catch (Exception e) { e.printStackTrace(); }
		 */

		if (ControlID.equalsIgnoreCase("fetchOnDemandData")) {
			cm.mRepLogger.info("executeServerEvent Inside fetchOnDemandData: ");
			cm.mRepLogger.info("For Control ID -->" + JSdata);
			cm.populateDumpData(JSdata, ifr.getValue("Loan_Account_No").toString(), ifr);

			//setting the role of the user in the role variable only if user clicks the decision tab.
			if(JSdata.contains("fetchBtnActionHistory")){ 
				cm.setRoleOfUser();
			}

		}
		if (ControlID.equalsIgnoreCase("DocumentGeneration")) {
			if (EventType.equalsIgnoreCase("FormLoad")) {
				return cm.onformLoadHandler_OutDocument_CAGL(ifr, ControlID, EventType, JSdata, ifr.getActivityName());
			} else {
				// Generate Document - By Vaibhav
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WITH(NOLOCK) WHERE Document_Name='"
						+ doctype + "'";
				cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
				try {

					Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
					JSONObject jRet = new JSONObject();
					jRet.put("Status", Boolean.toString(docStatus.isStatus()));
					jRet.put("Msg", docStatus.getMsg());
					jRet.put("SubMsg", docStatus.getSubMsg());
					jRet.put("DocName", doctype);
					// saving the outward document grid.
					cm.saveDocData();
					return jRet.toString();

				} catch (Exception e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					cm.mErrLogger.info("Error in executeserverevent-->" + e.getMessage());
				}

			}

		}

		if (ControlID.equalsIgnoreCase("postDocGenOrUpdate")) {

			// saving the outward document grid.
			cm.saveDocData();
		}
		
		if (ControlID.equalsIgnoreCase("apportionmentFetch")) {

			// saving the outward document grid.
			cm.fetchApportionmentData(JSdata);
		}
		
		if(ControlID.equalsIgnoreCase("getTabIdToValidate")) {
			return cm.getTabIdToValidate(JSdata);
			
		}
		
		if(ControlID.equalsIgnoreCase("DisableTabOnLoad")) {
			cm.disableTabsOnLoad();
			
		}
		if(ControlID.equalsIgnoreCase("repaymentScheduleFetch")) {
			return cm.fetchRepaySchedule();
			
		}
		if(ControlID.equalsIgnoreCase("ActionHistoryData")) {
			cm.actionAndDecisionHistoryUpdation("ActionHistory",JSdata);
			
		}
	
		if(ControlID.equalsIgnoreCase("DecisionHistoryData")) {
			cm.actionAndDecisionHistoryUpdation("DecisionHistory",JSdata);
			
		}
		if(ControlID.equalsIgnoreCase("OnChangeActionCode")) {
			
			cm.mRepLogger.info("Inside OnChangeActionCode");
			String fieldsToCLear = cm.actionCodeOnChange(JSdata);
			cm.mRepLogger.info("Returning Old Fields that are to be cleared -->" + fieldsToCLear);
			return fieldsToCLear;
		}
		if(ControlID.equalsIgnoreCase("getCurrentUserRole")) {

			return cm.getCurrentUserRole();

		}
		if(ControlID.equalsIgnoreCase("setInwardDocumentCategory")) {
			
			return cm.setInwardDocumentCategory(JSdata);
		}

		if(ControlID.equalsIgnoreCase("GenerateSOA")) {

		CollectionCommonServices cs = new CollectionCommonServices(ifr);
		JSONObject jRet=new JSONObject();
		
		try {

			String st=cs.GenerateSOA(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);

			if(st!=null && st.equalsIgnoreCase("SUCCESS")){ 
				
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
						+ doctype + "'";
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
				
				cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
				jRet.put("Status", Boolean.toString(docStatus.isStatus()));
				jRet.put("Msg", docStatus.getMsg());
				jRet.put("SubMsg", docStatus.getSubMsg());
				jRet.put("DocName", doctype);
				
			}else if(st!=null && st.startsWith("FAILED")){ 
				
				jRet.put("Status", Boolean.toString(false));
				jRet.put("Msg", st.split("~~")[1]);
				jRet.put("SubMsg", "NA");
				jRet.put("DocName", "SOA");
				
			}
			
			// saving the outward document grid.
			cm.saveDocData();
			
		} catch (Exception e) {
			cm.mErrLogger.info("Error in generating the SOA execute server event-->",e);
			jRet.put("Status", Boolean.toString(false));
			jRet.put("Msg", "Issue in generating the Document :");
			jRet.put("SubMsg", "NA");
			jRet.put("DocName", "SOA");
		}
		
		return jRet.toString();
		
//		return cs.GenerateSOA(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);
		
		//below code to be removed and above return statement to be uncommented.
		/*String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='SOA'";
		cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
		List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
		cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
		try {
			cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
		
		if(ControlID.equalsIgnoreCase("GenerateRepaymentSchedule")) {
		CollectionCommonServices cs = new CollectionCommonServices(ifr);
		JSONObject jRet=new JSONObject();
		
		try {

			String st=cs.GenerateRepaymentSchedule(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);
			
			if(st!=null && st.equalsIgnoreCase("SUCCESS")){ 
				
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
						+ doctype + "'";
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
				
				cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
				jRet.put("Status", Boolean.toString(docStatus.isStatus()));
				jRet.put("Msg", docStatus.getMsg());
				jRet.put("SubMsg", docStatus.getSubMsg());
				jRet.put("DocName", doctype);
				
			}else if(st!=null && st.startsWith("FAILED")){ 
				
				jRet.put("Status", Boolean.toString(false));
				jRet.put("Msg", st.split("~~")[1]);
				jRet.put("SubMsg", "NA");
				jRet.put("DocName", "Loan Repayment Schedule");
				
			}
			
			// saving the outward document grid.
			cm.saveDocData();
			
		} catch (Exception e) {
			cm.mErrLogger.info("Error in generating the Loan Repayment Schedule execute server event-->",e);
			jRet.put("Status", Boolean.toString(false));
			jRet.put("Msg", "Issue in generating the Document :");
			jRet.put("SubMsg", "NA");
			jRet.put("DocName", "Loan Repayment Schedule");
		}
		
		return jRet.toString();

	}
		return "CollectionEntry Complete!!";
	}

	@Override
	public String getCustomFilterXML(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String setMaskedValue(String arg0, String arg1) {
		// TODO Auto-generated method stub
		return arg1;
	}

	@Override
	public JSONArray validateSubmittedForm(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

}
