package com.newgen.iforms.user.collection;

//import static com.newgen.custom.log.CustomLogger.CustomInfoLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;


import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONValue;
import org.json.simple.JSONArray;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.opc.OPCPackage;
//import org.apache.poi.xwpf.converter.pdf.PdfConverter;
//import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import fr.opensagres.poi.xwpf.converter.pdf.PdfOptions;
import fr.opensagres.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.log4j.*;
//public static final org.apache.log4j.Logger mRepLogger = org.apache.log4j.Logger.getLogger("Reportlog");

public class HTTPRequestResponse {
	public String sendHTTPRequest(String requrl, String type, String jsonString, CollectionCommonMethod cm) throws IOException, JSONException {
	    // CommonMethods commonMethObj = new CommonMethods();
	    System.out.println("Starting");
	    System.out.println("Inside startAPIExecution Call");
	    String sessionoutput = "";
	    String strStatus = "";
	    String ErrorMsg="";
	    String CodeMsg="";
	    String temp="";
	    String temp1="";
	    String temp2="";
	    String temp3="";
	    String temp4="";
	    String temp5="";
	    String temp6="";
	    String temp7="";
	    String temp8="";
	    String temp9="";
	    String temp0="";
	    String transactionID="";
	    String data="";
	    String merchTranId="";
		 String wCollectTxnId="";
		 String wCustmerRefId="";
	    JSONObject Resobj = new JSONObject();
	    JSONObject tempjson = new JSONObject();
	    JSONObject jsonObj1 =new JSONObject();
	    JSONObject transtempjson=new JSONObject();
	    JSONObject jsonObj11=new JSONObject();
	    JSONParser parser = new JSONParser();  
	    URL url = new URL(requrl);
	    
	    cm.mRepLogger.info("Inside sendHTTPRequest() call in HTTPRequestResponse with request::"+jsonString);
	    System.out.println("Inside sendHTTPRequest() call in HTTPRequestResponse with request::"+jsonString);
	    HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
	    try {

	    	  JSONObject json = (JSONObject) parser.parse(jsonString);       
		     transactionID=(String) json.get("unqtxnid");
		     System.out.println("Transaction ID ==> " + transactionID);
		     cm.mRepLogger.info("Transaction ID ==> " + transactionID);
	        System.out.println("URL ==> " + requrl);
	        cm.mRepLogger.info("URL ==> " + requrl);
	        
	        String stringToParse = jsonString;
	        System.out.println("Normal Content =====> " + stringToParse);
	        cm.mRepLogger.info("Normal Content =====> ::"+stringToParse);
	        JSONObject jsonObj =  (JSONObject) parser.parse(stringToParse);
	        String strJsonObj = jsonObj.toString();
	        System.out.println("Before disablessl verification");
	        cm.mRepLogger.info("Before disablessl verification Content =====> ::"+stringToParse);
	        disableSslVerification();
	        System.out.println("After disablessl verification");
	        cm.mRepLogger.info("After disablessl verification Content =====> ::"+stringToParse);
	        
	        conn.setAllowUserInteraction(false);
	        
	        if(type.equalsIgnoreCase("P2VInitiation"))
			    conn.setRequestMethod("GET");
	        else
			    conn.setRequestMethod("POST");
//	        conn.setRequestProperty("Content-Length", "<calculated when request is sent>");
			  conn.setRequestProperty("Host", "<calculated when request is sent>");
			  conn.setRequestProperty("User-Agent", "PostmanRuntime/7.26.10");
			  conn.setRequestProperty("Accept", "*/*");
			  conn.setRequestProperty("Accept-Encoding", "gzip, deflate, br");
			  conn.setRequestProperty("Connection", "keep-alive");
			  conn.setRequestProperty("Content-Type", "application/json");				
	       conn.setDoOutput(true);
	        // post the input data
	        OutputStream os = conn.getOutputStream();
	        os.write(strJsonObj.getBytes());
	        os.flush();
	        if (conn.getResponseCode() != 200) {
	        	String response="";
	        	String output;
	        	BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				   //throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode()+" message : "+conn.getResponseMessage());
				   JSONArray jobj = new JSONArray();
				   System.out.println("Output from Server .... \n");
				   while ((output = br.readLine()) != null) {
					  response=response+output;
				   }
				   ErrorMsg=response;
				   Resobj.put("responseCode",conn.getResponseCode());
				   Resobj.put("message", ErrorMsg);
				   //throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode() +" Response Message : "+conn.getResponseMessage());
//				   return Resobj;
	        } else {


				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

				String output;
				String response="";
				
				//LogMe.logMe(LogMe.LOG_LEVEL_DEBUG,"Output from Server .... \n");
				System.out.println("Output from Server .... \n");
				while ((output = br.readLine()) != null) {
					response=response+output;
				}
				//LogMe.logMe(LogMe.LOG_LEVEL_DEBUG,"Response Message : "+output);
				
				Resobj.put("responseCode",conn.getResponseCode());
				Resobj.put("message", response);
				System.out.println("HTTP Response JSON in HTTPRequestResponse.java  ==> " + response);
				cm.mRepLogger.info("HTTP Response JSON in HTTPRequestResponse.java  ==> " + response);
			   
				if(type.equalsIgnoreCase("Single Collect")){// || type.equalsIgnoreCase("Push to VPA")){
					cm.mRepLogger.info("Inside Single Collect condition(in HTTPRequestResponse.java:154)==>"+response);
					jsonObj11 = (JSONObject) parser.parse(response); 
					Object Obj=jsonObj11.get("data");
//					JSONArray array = (JSONArray)Obj;			
					JSONObject obj2 = (JSONObject)Obj;
					temp=(String) obj2.get("merchTranId");
					temp1= (String) obj2.get("wCollectTxnId");
					temp2=(String)jsonObj11.get("result");
					tempjson.put("result",temp2);				
					tempjson.put("merchTranId", temp);
					tempjson.put("wCollectTxnId",temp1);
					tempjson.put("tranid",transactionID);
					CodeMsg=tempjson.toString();
					System.out.println("Inside try Response (Single Collect)::"+CodeMsg);
					cm.mRepLogger.info("Inside try Response (Single Collect)::"+CodeMsg);
				}
				else if(type.equalsIgnoreCase("Check Status")){
					cm.mRepLogger.info("Inside Check Status condition(in HTTPRequestResponse.java:171)==>"+response);
					jsonObj11 = (JSONObject) parser.parse(response); 
					Object Obj=jsonObj11.get("data");
					JSONArray array = (JSONArray)Obj;
					JSONObject datajson=(JSONObject)array.get(0);
					temp=(String) datajson.get("result");
					temp1=(String) datajson.get("tranid");
					temp2=(String) datajson.get("txnid");
					temp3=(String) datajson.get("dateTime");
					temp4=(String) datajson.get("amount");
					temp5=(String) datajson.get("debitVpa");
					temp6=(String) datajson.get("creditVpa");
					temp7=(String) datajson.get("remarks");
									
					tempjson.put("result",temp);
					tempjson.put("tranid",temp1);
					tempjson.put("txnid",temp2);
					tempjson.put("dateTime",temp3);
					tempjson.put("amount",temp4);
					tempjson.put("debitVpa",temp5);
					tempjson.put("creditVpa",temp6);
					tempjson.put("remarks",temp7);
					tempjson.put("transid",transactionID);
					CodeMsg=tempjson.toString();
					System.out.println("Inside try Response (Check status)::"+CodeMsg);
					cm.mRepLogger.info("Inside try Response (Check status)::"+CodeMsg);
					}
				else if(type.equalsIgnoreCase("Push to VPA") || type.equalsIgnoreCase("Dynamic VPA")){   //Token generation
					cm.mRepLogger.info("Inside "+type+"condition(in HTTPRequestResponse.java:199)==>"+response);
					   jsonObj1 =  (JSONObject) parser.parse(response);
					   cm.mRepLogger.info("Inside HTTPRequestResponse.java ("+type+")::"+jsonObj1);
						String datacheckString=(String) jsonObj1.get("data");
						temp2=(String)jsonObj1.get("result");
						tempjson.put("result",temp2);				
						tempjson.put("data", datacheckString);
						CodeMsg=tempjson.toString();
						System.out.println("Inside try Response ("+type+" Token Generation)::"+CodeMsg);
						cm.mRepLogger.info("Inside try Response ("+type+" Token Generation)::"+CodeMsg);
					}
					else if(type.equalsIgnoreCase("P2VInitiation") || type.equalsIgnoreCase("DVInitiation")){ //Push To VPA Initiation using token generated
						cm.mRepLogger.info("Inside "+type+"condition(in HTTPRequestResponse.java:211)==>"+response);
						jsonObj1 =  (JSONObject) parser.parse(response);
					   cm.mRepLogger.info("Inside HTTPRequestResponse.java ("+type+")::"+jsonObj1);
					   JSONObject datacheckString=(JSONObject) jsonObj1.get("data");
					   merchTranId=(String)datacheckString.get("merchTranId");
						wCollectTxnId=(String)datacheckString.get("wCollectTxnId");
						wCustmerRefId=(String)datacheckString.get("wCustmerRefId");
						cm.mRepLogger.info("Inside HTTPRequestResponse.java ("+type+")::"+datacheckString);
						if(merchTranId != "" || wCustmerRefId != "" || wCustmerRefId != ""){
						   Object Obj=jsonObj1.get("data");
//							JSONArray array = (JSONArray)Obj;			
							JSONObject obj2 = (JSONObject)Obj;
							temp=(String) obj2.get("merchTranId");
							temp1=(String) obj2.get("wCollectTxnId");
							temp2=(String) obj2.get("wCustmerRefId");
						}
						temp3=(String)jsonObj1.get("result");
						tempjson.put("result",temp3);				
						tempjson.put("merchTranId", temp);
						tempjson.put("wCollectTxnId",temp1);
						tempjson.put("wCustmerRefId",temp2);
						CodeMsg=tempjson.toString();
						System.out.println("Inside try Response ("+type+")::"+CodeMsg);
						cm.mRepLogger.info("Inside try Response ("+type+")::"+CodeMsg);
					}
					
					else if(type.equalsIgnoreCase("P2VCheckStatus") || type.equalsIgnoreCase("Dynamic VPA CheckStatus")){  //Check Status using Token Initiation
						  cm.mRepLogger.info("Inside "+type+"condition(in HTTPRequestResponse.java:238)==>"+response);
						  jsonObj1 =  (JSONObject) parser.parse(response);
					     JSONObject datacheckString=(JSONObject) jsonObj1.get("data");
							data=datacheckString.toString();
							cm.mRepLogger.info("Inside HTTPRequestResponse.java ("+type+")::"+data);					
							Object Obj=jsonObj1.get("data");
//							JSONArray array = (JSONArray)Obj;			
							JSONObject obj2 = (JSONObject)Obj;
							temp=(String) obj2.get("merchTranId");
							temp1= (String) obj2.get("wCollectTxnId");
						
						temp2=(String)jsonObj1.get("result");
						tempjson.put("result",temp2);				
						tempjson.put("merchTranId", temp);
						tempjson.put("wCollectTxnId",temp1);
						tempjson.put("tranid",transactionID);
						CodeMsg=tempjson.toString();
						System.out.println("Inside try Response ("+type+")::"+CodeMsg);
						cm.mRepLogger.info("Inside try Response ("+type+")::"+CodeMsg);
					}
					else if(type.equalsIgnoreCase("ValidateCustVPA")){
						cm.mRepLogger.info("Inside "+type+"condition(in HTTPRequestResponse.java:199)==>"+response);
					  jsonObj1 =  (JSONObject) parser.parse(response);
					  cm.mRepLogger.info("Inside HTTPRequestResponse.java (ValidateCustVPA)::"+jsonObj1);
					  temp=(String)jsonObj1.get("result");
					  temp2=(String)jsonObj1.get("customerName");
					  tempjson.put("result",temp);
					  tempjson.put("customerName",temp2);
					  CodeMsg=tempjson.toString();
					  System.out.println("Inside try Response (validate)::"+CodeMsg);
					  cm.mRepLogger.info("Inside try Response (validate)::"+CodeMsg);
					}
//					LogMe.logMe(LogMe.LOG_LEVEL_DEBUG,"Response Object: "+Resobj);
					System.out.println("Inside Try Final Response in (HTTPRequestResponse.java)::"+CodeMsg);
					
		        }               		      		        
		    } catch (Exception e) {

			e.printStackTrace();
			Resobj.put("responseCode",conn.getResponseCode());
			Resobj.put("message", ErrorMsg);
        System.out.println("Inside Catch Response::"+Resobj);
        cm.mRepLogger.info("Inside Catch Response::"+Resobj);
		 }
//	    return Resobj;
	    
//	    Object obj = JSONValue.parse(Resobj.toString());
//	    JSONArray array = (JSONArray)obj;
//	      
//	    //tempjson.add(Resobj.);
//	    JSONObject obj2 = (JSONObject)array.get(0);
//	    CodeMsg=(String)obj2.get("result");
//	    System.out.println("Response Message ::"+CodeMsg);
//	    temp=(String)getSth.get("code");
//	    if(temp.equalsIgnoreCase("00")){
//	    	 CodeMsg=(String)Resobj.get("result");
//	    }	    
//	    else {
//	    	CodeMsg=(String)Resobj.get("result");
//	    }
	    System.out.println("Response JSON in HTTPRequestResponse.java ==> " + CodeMsg);
	    cm.mRepLogger.info("Response JSON in HTTPRequestResponse.java for ==> " + CodeMsg);
	    return CodeMsg;
	}
	private static void disableSslVerification() {
	    //  CommonMethods commonMethObj = new CommonMethods();
	    try {
	        System.out.println("Inside Disable Verification");
	        // Create a trust manager that does not validate certificate chains
	        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {

	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }

	            @Override
	            public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
	            }

	            @Override
	            public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
	            }
	        }
	        };
	        // Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {

	            @Override
	            public boolean verify(String string, SSLSession ssls) {
	                return true;
	            }
	        };
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	    } catch(NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } catch(KeyManagementException e) {
	        e.printStackTrace();
	    }
	}
}
