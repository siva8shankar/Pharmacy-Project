package com.newgen.iforms.user.collection;

import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.FormDef;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.iforms.user.collection.services.Status;

public class DMS_Archival implements IFormServerEventHandler {

	private IFormReference ifr = null;
	CollectionCommonMethod cm = null;
	
	public DMS_Archival(CollectionCommonMethod cm,IFormReference ifr) {
		cm.mRepLogger.info("<--Inside DMS_Archival-->");
		// logger = new CustomLogger();
		this.ifr = ifr;
		this.cm=cm;
	}
	
	@Override
	public void beforeFormLoad(FormDef arg0, IFormReference arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public String executeCustomService(FormDef arg0, IFormReference arg1, String arg2, String arg3, String arg4) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONArray executeEvent(FormDef arg0, IFormReference arg1, String arg2, String arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String executeServerEvent(IFormReference ifr, String ControlID, String EventType, String JSdata) {
		// TODO Auto-generated method stub
		switch (ControlID) {	
			case "fetchOnDemandData": {
				cm.mRepLogger.info("DMS_Archival executeServerEvent Inside fetchOnDemandData: ");
				cm.mRepLogger.info("For Control ID -->" + JSdata);
				cm.populateDumpData(JSdata, ifr.getValue("Loan_Account_No").toString(), ifr);
				
				//setting the role of the user in the role variable only if user clicks the decision tab.
				if(JSdata.contains("fetchBtnActionHistory")){ 
					cm.setRoleOfUser();
				}
				
				break;
			}
			
		}
	
		return null;
	}

	@Override
	public String getCustomFilterXML(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String setMaskedValue(String arg0, String arg1) {
		// TODO Auto-generated method stub
		return arg1;
	}

	@Override
	public JSONArray validateSubmittedForm(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

}
