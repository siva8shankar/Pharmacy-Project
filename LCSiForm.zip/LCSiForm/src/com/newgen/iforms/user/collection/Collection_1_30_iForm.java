package com.newgen.iforms.user.collection;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.json.simple.JSONArray;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.newgen.iforms.FormDef;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.util.ScoreCardResponseParser;
import com.newgen.util.StatCardGeneration;

/**
 *
 * @author Administrator
 */
public class Collection_1_30_iForm implements IFormServerEventHandler {
	private IFormReference ifr = null;
	CollectionCommonMethod cm = new CollectionCommonMethod(ifr);
	public Collection_1_30_iForm() {
		cm.mRepLogger.info("<--Inside Collection_1_30_iForm-->");
		// logger = new CustomLogger();
	}

	@Override
	public void beforeFormLoad(FormDef fd, IFormReference ifr) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	@Override
	public String setMaskedValue(String string, String string1) {
		// throw new UnsupportedOperationException("Not supported yet."); //To change
		// body of generated methods, choose Tools | Templates.
		return string1;
	}

	@Override
	public JSONArray executeEvent(FormDef fd, IFormReference ifr, String string, String string1) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	@Override
	public String executeServerEvent(IFormReference ifr, String ControlID, String EventType, String JSdata) {
		this.ifr = ifr;

		//CollectionCommonMethod cm = new CollectionCommonMethod(ifr);

		String columnNames = "";
		String fieldNames = "";
		String tableName = "";

		cm.mRepLogger.info("Inside: executeServerEvent");
		cm.mRepLogger.info("ControlID : " + ControlID);
		cm.mRepLogger.info("EventType : " + EventType);
		cm.mRepLogger.info("JSdata : " + JSdata);
		cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent JSdata: " + JSdata);
		if (JSdata != null && !JSdata.equalsIgnoreCase("") && JSdata.equalsIgnoreCase("CollectionEntrySave")) {
			String processInstanceId = EventType;
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent processInstanceId: " + processInstanceId);
			String updateCollectionQuery = "update CMPLX_COLL_CRE_Collection_Receipt_Entry set Fragment_ID = (select max(WorkItemId)+1 from WFINSTRUMENTTABLE where ProcessInstanceID =  '"
					+ processInstanceId + "') where TransactionId = '" + processInstanceId + "' and Fragment_ID = 1";
			cm.mRepLogger.info(
					"Collection_1_30_iForm executeServerEvent updateCollectionQuery: " + updateCollectionQuery);
			ifr.saveDataInDB(updateCollectionQuery);
		}

		if (JSdata != null && !JSdata.equalsIgnoreCase("") && JSdata.equalsIgnoreCase("LegalSave")) {
			String processInstanceId = EventType;
			cm.mRepLogger.info(
					"Collection_1_30_iForm executeServerEvent LegalSave processInstanceId: " + processInstanceId);
			String updateLegalSaveQuery = "update CMPLX_COLL_LI_Legal_Initiation set WorkitemId = (select max(WorkItemId)+1 from WFINSTRUMENTTABLE where ProcessInstanceID =  '"
					+ processInstanceId + "') where TransactionId = '" + processInstanceId + "' and WorkitemId = 1";
			System.out
					.println("Collection_1_30_iForm executeServerEvent updateLegalSaveQuery: " + updateLegalSaveQuery);
			ifr.saveDataInDB(updateLegalSaveQuery);
		}

		switch (ControlID) {
		
			case "fetchBtnLoanDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent inside fetchBtnLoanDetails: ");
			ifr.getControlValue("Loan_Account_No").toString();
//			columnNames = "cod_acct_no,COD_CUST_ID as Customer_ID,nam_product as Product_Name,COD_PROD_CATEGORY,cod_sched_type,amt_net_disbursed as [Loan_Disbursal_Status],amt_net_disbursed as [Loan_Amount],DAT_SANCTION as [Loan_Booking_Date],CTR_TERM_MONTHS as [Tenure],AMT_ADVANCES as [Advance_EMI],dat_first_instal as [First_EMI_Date],dat_stage_end as [Last_EMI_Date],frq_instal as [Installment_Frequency],COD_SCHED_TYPE as [EMI_pattern],net_rate as [Interest_Rate],DAT_NEXT_DUE as [EMI_Due_Date],ctr_instal as [No_of_EMI_Billed],no_of_emi_received as [No_of_EMI_Received],no_of_emi_pending as [No_of_EMI_Pending],sourced_by as [Sourced_By],srcd_by_name_and_emp_id as [Sourced_By_Name],srcd_person_contact_no as [Sourced_Person_Contact_No],zone as [Zone],region as [Region],state as [State],area as [Area],hub_cluster as [Hub],CODCCBRN as [Branch],child_loan_yes_no as [Child_Loan],no_of_child_loans as [No_of_Child_Loans],invoice_details as [Invoice_Details],prdcttyp_cnsmr_hshld_gds as [Product_Type],AMT_ORIG_VALUE as [Valuation_Amt],ltv_ratio as [LTV],DISB_AMT_PENDING as [Disbursement Amount Pending]";
//			fieldNames = "qLoanDetails_Customer_ID,qLoanDetails_Product_Name,qLoanDetails_Sub_Product,qLoanDetails_Loan_Category,qLoanDetails_Loan_Disbursal_Status,qLoanDetails_Loan_Amount,qLoanDetails_Loan_Booking_Date,qLoanDetails_Tenure,qLoanDetails_Advance_EMI,qLoanDetails_First_EMI_Date,qLoanDetails_Last_EMI_Date,qLoanDetails_Installment_Frequency,qLoanDetails_EMI_Pattern,qLoanDetails_Interest_Rate,qLoanDetails_EMI_Due_Date,qLoanDetails_No_of_EMI_Billed,qLoanDetails_No_of_EMI_Received,qLoanDetails_No_of_EMI_Pending,qLoanDetails_Sourced_By,qLoanDetails_Sourced_By_Name,qLoanDetails_Sourced_Prson_Contact_No,qLoanDetails_Zone,qLoanDetails_Region,qLoanDetails_State,qLoanDetails_Area,qLoanDetails_Hub,qLoanDetails_Branch,qLoanDetails_Child_Loan,qLoanDetails_No_of_Child_Loans,qLoanDetails_Invoice_Details,qLoanDetails_Product_Type,qLoanDetails_Valuation_Amt,qLoanDetails_LTV,qLoanDetails_Loan_Disbursal_New";
//			tableName = "ST_Coll_Loan_OverdueDetails";
			//cm.populateFields(columnNames, fieldNames, tableName, loanAccountNo, ifr);
			break;
		}

		case "fetchBtnAssetDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnAssetDetails: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String assetDetailsQuery = "select cod_coll_type,AssetCount,DealerName,VehicleType,FuelType from ST_Coll_ASSET_DTLS where cod_acct_no='"
					+ loanAccountNo + "'";
			String columnNamesAssetDetails = "Asset Name,Quantity,Dealer Name,Vehicle Type,Fuel Type";
			cm.populateListView(columnNamesAssetDetails, assetDetailsQuery, "table31", ifr);
			break;
		}

		case "fetchBtnPDDDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnPDDDetails: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String PDDDetailsQuery = "select pndg_pdds from ST_Coll_PDDDetails where cod_acct_no='" + loanAccountNo
					+ "'";
			String columnNamesPDDDetails = "Pending PDD";
			cm.populateListView(columnNamesPDDDetails, PDDDetailsQuery, "table4", ifr);
			break;
		}

		case "fetchBtnAssetInsurance": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnAssetInsurance: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String assetDetailsQuery = "select cod_coll_type,cod_insur_type,cod_ins_ref_num,nam_insurer,IDVInsured_DeclaredValue,amt_prem,Validfrom,dat_next_remit from ST_Coll_ASSET_INSURNC_DTLS where cod_acct_no='"
					+ loanAccountNo + "'";
			String columnNamesAssetDetails = "Asset Name,Risk Type,Document No,Insurance Company,Sum Insured,Premium Amount,Valid From,Valid To";
			cm.populateListView(columnNamesAssetDetails, assetDetailsQuery, "table32", ifr);
			break;
		}

		case "fetchBtnOverdueDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnOverdueDetails: ");
			ifr.getControlValue("Loan_Account_No").toString();
//			columnNames = "cod_acct_no,lst_pymnt_rcvd_amnt, dat_last_payment,lst_pymnt_rcvd_month,othr_chrgs_clctn_month,unadjusted_fund,principal_outstanding,interest_outstanding,emi_with_insurance";
//			fieldNames = "qOverdueDetails_Last_Payment_Received_Amount,qOverdueDetails_Last_Payment_Received_Date,qOverdueDetails_Payment_Received_for_the_Month,qOverdueDetails_Other_Charges_Collection_for_the_month,qOverdueDetails_Unadjusted_Fund,qOverdueDetails_Principal_Outstanding,qOverdueDetails_Interest_Outstanding,qOverdueDetails_EMI_with_Insurance";
//			tableName = "ST_Coll_Loan_OverdueDetails";
			//cm.populateFields(columnNames, fieldNames, tableName, loanAccountNo, ifr);
			break;
		}

		case "fetchBtnDelinquencyString": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnDelinquencyString: ");
//			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
//			columnNames = "cod_acct_no,";
//			fieldNames = "qBucketDetails_DPD,qBucketDetails_Current_Bucket,qBucketDetails_Previous_Bucket,qBucketDetails_LoanResolution_Status";
//			tableName = "ST_Coll_Loan_OverdueDetails";
			//cm.populateFields(columnNames, fieldNames, tableName, loanAccountNo, ifr);
			break;
		}

		case "fetchBtnPaymentMatrix": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnPaymentMatrix: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String paymentMatrixQuery = "select month,dpd,cmltve_mnthy_pymnt,dat_last_payment from ST_Coll_DPD_Payment_Matrix where cod_acct_no='"
					+ loanAccountNo + "'";
			;
			String columnNamesPaymentMatrix = "Month,DPD,Cummulative Monthly Payment,Last Payment Date of the Month";
			cm.populateListView(columnNamesPaymentMatrix, paymentMatrixQuery, "table45", ifr);
			break;
		}

		case "fetchBtnRepayment": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnRepayment: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String repaymentQuery = "select ctr_instal as [Installment_No],date_instal as [Due_Date],amt_instal_outst as [Installment_Amount],amt_principal as [Principal_Amount],amt_interest as [Interest_Amount],excess as [Excess],amt_charge_outst as [Other_Charges],amt_princ_bal as [Principal_Amount],amt_arrears_due as [Installment_Amount_Received],bill_flag as [Bill_Flag],advance_flag as [Advance_Flag],od_days as [OD_Days],repayment_mode as [Repayment_Mode],ref_instr_no as [Cheque_Number],dat_instr as [Cheque_Date],nam_bank as [Bank_Name],cod_payee_brn as [branch_name],amt_txn_lcy as [Amount],cod_payee_acct as [Account_No],flg_process as [Status] from ST_Coll_Future_Installment_Repayment WITH(NOLOCK) where cod_acct_no = '"
					+ loanAccountNo + "'";
			String columnNamesRepayment = "Installment No,Due Date,Installment Amount,Principle Amount,Interest Amount,Excess,Other Charges,Principle Outstanding,Installment Amount Received,Bill Flag,Advanced Flag,OD Days,Repayment Mode,Cheque No,Cheque Date,Bank Name,Branch,Amount,Account No";
			cm.populateListView(columnNamesRepayment, repaymentQuery, "table38", ifr);
			break;
		}

		case "fetchBtnSPDC": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnSPDC: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String SPDCQuery = "select ref_instr_no as [Cheque_Number],dat_instr as [Cheque_Date],nam_bank as [Bank_Name],cod_payee_brn as [branch_name],amt_txn_lcy as [Amount],cod_payee_acct as [Account_No],COD_DRAWEE_ACCT as [SPDC]from ST_Coll_PDC_SPDC_Details WITH(NOLOCK) where cod_acct_no = '"
					+ loanAccountNo + "'";
			String columnNamesSPDC = "Cheque No,Cheque Date,Bank Name,Branch,Amount,Account No,SPDC";
			cm.populateListView(columnNamesSPDC, SPDCQuery, "table39", ifr);
			break;
		}

		case "fetchBtnBreakupOfExpenses": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnBreakupOfExpenses: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String breakupExpensesQuery = "select cod_acct_no,cod_arrear_type as [Expense_Type],amt_arrears_assessed as [Amount_Due],dat_min_due as [Min_Due_Date],dat_last_payment as [Last_Payment_Date],amt_arrears_paid as [Amount_Paid] from ST_Coll_BreakupofExpenses WITH(NOLOCK) where cod_acct_no='"
					+ loanAccountNo + "'";
			String columnNamesBreakupExpenses = "Loan No,Expense Type,Amount Due,Min Due Date,Last Payment Date,Amount Paid";
			cm.populateListView(columnNamesBreakupExpenses, breakupExpensesQuery, "table40", ifr);
			break;
		}

		case "fetchBtnBreakupOfOtherCharges": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnBreakupOfOtherCharges: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String breakupChargesQuery = "select charge_decrp_typ as charge_desc,charge_amount as charge_amount,due_date as due_date,due_amount as due_amount,date_paid as date_paid from ST_Coll_Charges_File WITH(NOLOCK) where cod_acct_no =  '"
					+ loanAccountNo + "'";
			String columnNamesBreakupOtherCharges = "Charge Description,Charge Amount,Due Date,Due Amount,Date Paid";
			cm.populateListView(columnNamesBreakupOtherCharges, breakupChargesQuery, "table41", ifr);
			break;
		}

		case "fetchBtnBounceDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnBounceDetails: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String bounceDetailsQuery = "SELECT [installment_numeric] as Installment_No,[ref_chq_no_txn] as Cheque_No,[cod_bi_rej] as Bounce_Reason,[dat_txn] as 'Due Date',[amt_txn_lcy] as 'Instrument Amount',[bncd_instrmnt_md] as 'Bounce Instrument Mode',[cod_bank] as Bank,[nam_branch_shrt] as 'Bank Branch',[dat_instr] as 'Instrument Date',[flg_pdc] as 'Flag PDC',[billing_or_coll_chq] as 'Billing or Collection Cheque',[dat_txn1] as 'Bounce Date' FROM [dbo].[ST_Coll_BounceDump] where [cod_acct_no] = '"
					+ loanAccountNo + "'";
			String columnNamesBounceDetails = "Installment_No,Cheque_No,Bounce_Reason,Due Date,Instrument Amount,Bounce Instrument Mode,Bank,Bank Branch,Instrument Date,Flag PDC,Billing or Collection Cheque,Bounce Date";
			cm.populateListView(columnNamesBounceDetails, bounceDetailsQuery, "table42", ifr);
			break;
		}

		case "fetchBtnPaymentDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnPaymentDetails: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String paymentDetailsQuery = "select txn_date, txn_amount, COD_CHNL_ID, REF_TXN_NO, TXT_TXN_DESC, payment_mode, payment_received_against from [ST_Coll_PaymentDump] where [cod_acct_no] = '"
					+ loanAccountNo + "'";
			String columnNamesPaymentDetails = "Payment Date,Amount,Payment Received Channel,Transaction Number,Narration,Payment Mode,Payment Received Against";
			cm.populateListView(columnNamesPaymentDetails, paymentDetailsQuery, "table29", ifr);
			break;
		}

		case "fetchBtnCollateralDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnCollateralDetails: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String columnNamesCollateralDetails = "Collateral Type,Secured,Collateral ID,Collateral Code,Collateral Currency,Home Branch,Document Code,Collateral Cover Value,Charge Type,Manufacturing Year,Model,Last Value,Market Value,Deed Status,Custodian Name,Deeds Sent Date,Expected Return Date,Chasis Number,Engine Number,Registration Number";
			String collateralDetailsQuery = "select COD_COLL_TYPE,FLG_COLL_SEC,COD_COLLAT_ID,COD_COLL,COD_CCY,COD_COLL_HOMEBRN,COD_COLL_DOC,AMT_ORIG_VALUE,COD_CHARGE_TYPE,TXT_DESC_MAKE,TXT_DESC_MODEL,DAT_LAST_VAL,AMT_MARKET_VAL,COD_CUSTODY_STATUS,NAM_CUSTODIAN,DAT_DEED_SENT,DAT_DEED_RETURN,COD_CHASSIS_NO,COD_ENGINE_NO,COD_REGN_NO,COD_MFG_YEAR from ST_Coll_CollateralDetails where [cod_acct_no] = '"
					+ loanAccountNo + "'";
			;
			cm.populateListView(columnNamesCollateralDetails, collateralDetailsQuery, "table44", ifr);
			break;
		}

		case "fetchBtnActionHistory": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnActionHistory: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String columnNamesActionHistory = "Loan Account No,Comments,UserName,Action Date,Current Bucket,DPD,Geo Tagging,Issue Description,Queue Name,Action Code,Paid Amount,Follow-UpDate,PTP Date,Payment Mode,Payment Amount,Channel Mode,Paid Receipt No,Paid Collection Executive Name,PINCode,No of Follow-Up,Name,Relationship";
			String actionHistoryQuery = "SELECT cod_acct_no,Comments,Username,Action_Date,Current_Bucket,DPD,Geo_Tagging,Issue_Description,Queue_Name,Action_Code,Paid_Amount,Meeting_Date,Promise_To_Pay_Date_and_Time,PTP_Mode,PTP_Amount,Paid_Channel_Mode,Paid_Receipt_No,Paid_Collection_Executive_Name,Pincode,Number_of_Follow_Up,Name,Relationship FROM NG_Coll_ActionHistoryGrid where [cod_acct_no] = '"
					+ loanAccountNo + "'";
			;
			cm.populateListView(columnNamesActionHistory, actionHistoryQuery, "table50", ifr);
			break;
		}

		case "fetchBtnCommentHistory": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnCommentHistory: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String columnNamesCommentHistory = "Loan Account No,Comments,UserName,Workstep Name,Date,Action,UserAction";
			String commentHistoryQuery = "select cod_acct_no,Comments,Username,WorkstepName,Date_old,Action,UserAction from NG_Coll_CommentHistoryGrid where [cod_acct_no] = '"
					+ loanAccountNo + "'";
			;
			cm.populateListView(columnNamesCommentHistory, commentHistoryQuery, "table47", ifr);
			break;
		}

		case "fetchBtnTopSection": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnTopSection: ");
//			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
//			columnNames = "cod_acct_no,cod_acct_no,cod_acct_no_old,cod_cust_id,nam_cust_shrt,nam_contact_person,ref_cust_phone,dat_acct_open,amt_net_disbursed,ctr_term_months,amt_instal,flg_repayment_mode,group_individual_loan,nam_product,COD_PROD_TYPE,asset_name,cod_regn_no,dpd,dpd_bom,amt_princ_balance,outstanding_pre_emi_amount,amt_arrears_charges,BAL_OUTSTANDING,resolution_status";
//			fieldNames = "label401,Old_Loan_Account_No,CustomerID,Customer_Name,Contact_Person,Customer_Contact_No,Loan_Booking_date,Loan_Amount,CollectionTenure,EMI_Amount,Repayment_Mode,Loan_Type,Product_Name,Sub_Product,Asset_Name,Vehicle_No,DPD,DPD_BOM,DPD_String,Total_Amount_Due,Outstanding_Pre_EMI_Amount,Total_Outstanding,loanResolution";
//			tableName = "ST_Coll_TopSection";
		//	cm.populateFields(columnNames, fieldNames, tableName, loanAccountNo, ifr);
			break;
		}

		case "fetchBtnCustomerInformation": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnCustomerInformation: ");
//			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
//			columnNames = "cod_acct_no,constitution,COD_CUST_ID,dat_birth_cust,FATHER_SPOUSE_NAME,nam_spouse_cust,txt_cust_sex,address_1,nam_custadr_city,txt_custadr_zip,nam_custadr_state,nam_custadr_cntry,address_1,NAM_EMPADR_CITY,TXT_EMPADR_ZIP,NAM_EMPADR_STATE,NAM_EMPADR_CNTRY,address_3,NAM_PERMADR_CITY,TXT_PERMADR_ZIP,NAM_PERMADR_STATE,NAM_PERMADR_CNTRY,ref_phone_mobile3,mobile_no_2,ref_cust_phone_off,REF_CUST_PHONE,ref_cust_email,referrence_1,referrence_1_contact_no,referrence_2,referrence_2_contact_no,both_point_rented_yn";
//			fieldNames = "qCustInfo_Constitution,qCustInfo_Company_Name,qCustInfo_DOB,qCustInfo_Father_Name,qCustInfo_Husband_Name,qCustInfo_Gender,qCustInfo_Address_1,qCustInfo_City_1,qCustInfo_Zip_Code_1,qCustInfo_State_1,qCustInfo_Country_1,qCustInfo_Address_2,qCustInfo_City_2,qCustInfo_Zip_Code_2,qCustInfo_State_2,qCustInfo_Country_2,qCustInfo_Address_3,qCustInfo_City_3,qCustInfo_Zip_Code_3,qCustInfo_State_3,qCustInfo_Country_3,qCustInfo_Mobile_No_1,qCustInfo_Mobile_No_2,qCustInfo_Office_Phone,qCustInfo_Home_Phone,qCustInfo_E_Mail,qCustInfo_Referrence_1,qCustInfo_Referrence_1_Contact_No,qCustInfo_Referrence_2,qCustInfo_Referrence_2_Contact_No,qCustInfo_Both_Point_Rented";
//			tableName = "ST_Coll_CustomerInformation";
			//cm.populateFields(columnNames, fieldNames, tableName, loanAccountNo, ifr);
			break;
		}

		case "fetchBtnCustomerProfile": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnCustomerProfile: ");
//			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
//			columnNames = "LOAN_NO_NEW,EMIMAP_PRODUCT,FUEL_TYPE, TYPE_OF_VEHICLE, END_USE_OF_VEHICLE, WHO_WILL_DRIVE_THE_VEHICLE, CATEGORY, SEGMENT, SEGMENT_SJ, SECTOR, INDUSTRY, SUB_INDUSTRY, DESIGNATION, EXISTING_LOANS_AU, RELATED_AS, DISTANCE_FROM_BRANCH, END_USE_OF_LOAN";
//			fieldNames = "qCustomerProfile_Emimap_product,qCustomerProfile_Fuel_type,qCustomerProfile_Type_of_vehicle,qCustomerProfile_End_use_of_vehicle,qCustomerProfile_Who_will_drive_the_vehicle,qCustomerProfile_Category,qCustomerProfile_Segment,qCustomerProfile_Segment_SJ,qCustomerProfile_Sector,qCustomerProfile_Industry,qCustomerProfile_Sub_Industry,qCustomerProfile_Designation,qCustomerProfile_Existing_Loans_AU,qCustomerProfile_Related_As,qCustomerProfile_Distance_From_Branch,qCustomerProfile_End_Use_Of_Loan";
//			tableName = "NG_Coll_CustomerProfile";
		//	cm.populateFields(columnNames, fieldNames, tableName, loanAccountNo, ifr);
			break;
		}

		case "fetchBtnGeneralDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnGeneralDetails: ");
//			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
//			columnNames = "cod_acct_no,region,NAM_CUSTADR_STATE,area,hub_cluster,branch_name,zone,BAL_OUTSTANDING,emp_id,emp_name,emp_phone,emp_role,NAM_RELN_MGR,NAM_RELN_MGR,rlsn_prtfl_mngr_contact_no,emp_name,emp_role,dpd_bom,resolution_status,Status,FLG_SECURITIZED,secutized_model";
//			fieldNames = "Region,State,Area,Hub,Branch,Zone,Total_Principal_Outstanding,Collection_Executive_ID,Collection_Executive_Name,Collection_Executive_Contact_No,Collection_Executive_Role,Relationship_Manager,Relationship_Manager_Name,Relationship_Manage_Contact_No,Tele_Calling_Executive,Tele_Calling_Executive_Role,Collection_Queue,Loan_Status_new,Loan_Assignment_Status,Secutized_Status,Secutized_Model";
//			tableName = "ST_Coll_TopSection";
			//cm.populateFields(columnNames, fieldNames, tableName, loanAccountNo, ifr);
			break;
		}

		case "fetchBtnCustomerId": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnCustomerId: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String columnNamesCustomerId = "ID Type,ID Value";
			String customerIdQuery = "select INV_PAN_NO as [ID_Number],'PAN' as [ID_Type] from ST_Coll_CustomerInformation WITH(NOLOCK) where cod_acct_no = '"
					+ loanAccountNo
					+ "' union select CONVERT (NVARCHAR(20),COD_AADHAAR_NO) as [ID_Number], 'Aadhar Number' as [ID_Type] from ST_Coll_CustomerInformation where cod_acct_no = '"
					+ loanAccountNo + "'";
			cm.populateListView(columnNamesCustomerId, customerIdQuery, "table35", ifr);
			break;
		}

		case "fetchBtnCoApplicantDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnCoApplicantDetails: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String columnNamesCoApplicantDetails = "Customer_ID,Name,Father_Name,Relationship_with_Customer,Address,City,PIN,State,Mobile_Number,Contact_Number";
			String coApplicantDetailsQuery = "select cod_cust as [Customer_ID],cod_acct_cust_rel as [Account_Relationship],nam_cust_shrt as [Name],FATHER_SPOUSE_NAME as [Father_Name],cod_rel as [Relationship_with_Customer],address as [Address],nam_custadr_city as [City],txt_custadr_zip as [PIN],nam_custadr_state as [State],ref_phone_mobile as [Mobile_Number],ref_cust_phone as [Contact_Number] from ST_Coll_Co_Applicants WITH(NOLOCK) where cod_acct_no = '"
					+ loanAccountNo + "'";
			cm.populateListView(columnNamesCoApplicantDetails, coApplicantDetailsQuery, "table36", ifr);
			break;
		}

		case "fetchBtnLinkedAgreements": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchBtnLinkedAgreements: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			String columnNamesLinkedAgreements = "Linked Account No,Linked Flag,Principal Outstanding,Interest Outstanding,Total Outstanding,DPD,Due Date";
			String linkedAgreementsQuery = "select cod_lnk_cust_id,cod_lnk_acct_flg,Principal_Outstanding,Interest_Outstanding,Total_Outstanding,DPD,Due_Date from ST_Coll_LNK_AGREMNT_DTLS where cod_acct_no='"
					+ loanAccountNo + "'";
			cm.populateListView(columnNamesLinkedAgreements, linkedAgreementsQuery, "grid_linked_agreement", ifr);
			break;
		}

		case "fetchSettlementDetails": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside fetchSettlementDetails: ");
			String columnNamesSettlementDetails = "Component,Settlement_Amount,Waiver_Amount,Final_Amount";
			String linkedSettlementQuery = "select Component, Settlement_Amount, Waiver_Amount, Final_Amount from CMPLX_COLL_FC_Settlement_Grid";
			cm.populateListView(columnNamesSettlementDetails, linkedSettlementQuery, "grid_settlement", ifr);
			break;
		}

		/*case "btnGenerateStatCard": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside btnGenerateStatCard: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
			File file = new File(new StatCardGeneration().generateStatCard(ifr, loanAccountNo, JSdata));
//			String downloadDocURL = "http://13.71.1.77:8080/webdesktop/stat-card-download?documentName=" + file;
			String downloadDocURL="";
			// String addDocURL =
			// "http://127.0.0.1:8080/webdesktop/ODAddDocument.jsp?documentName="
			// + file;
			
			 * + "&processfolderindex="+ generalDataParser.getValueOf("FolderId") +
			 * "&documentid=" + documentId + "&pdfdestinationPath=" + gt.finalPDFPath +
			 * "&doccount=" + doCount + "&prequalificationletter=" + selectedRowIndex +
			 * "&isindex=" + isIndex;
			 
			return downloadDocURL;
		}*/

		case "button101":
		case "btnFetchScoreCard": {
			cm.mRepLogger.info("Collection_1_30_iForm executeServerEvent Inside btnFetchScoreCard: ");
			String loanAccountNo = ifr.getControlValue("Loan_Account_No").toString();
//			String wsEndPoint = "http://13.71.1.77:8080/axis2/services/CollScoreCard1_V_WebService";
			String wsEndPoint="";
			String query = "select Action_Code, count(Action_Code) as \"Count\" from NG_Coll_ActionHistoryGrid where Action_Code = 'Refuse to Pay' and cod_acct_no = '"
					+ loanAccountNo
					+ "' group by Action_Code union select Action_Code, count(Action_Code) as \"Count\" from NG_Coll_ActionHistoryGrid where Action_Code = 'Broken PTP' and cod_acct_no = '"
					+ loanAccountNo
					+ "' group by Action_Code union select Action_Code, count(Action_Code) as \"Count\" from NG_Coll_ActionHistoryGrid where Action_Code = 'Legal' and cod_acct_no = '"
					+ loanAccountNo
					+ "' group by Action_Code union select Action_Code, count(Action_Code) as \"Count\" from NG_Coll_ActionHistoryGrid where Action_Code = 'Initiate_Repo' and cod_acct_no = '"
					+ loanAccountNo
					+ "' group by Action_Code union select Action_Code, count(Action_Code) as \"Count\" from NG_Coll_ActionHistoryGrid where Action_Code = 'NC Line ringing not responding' and cod_acct_no = '"
					+ loanAccountNo
					+ "' group by Action_Code union select Action_Code, count(Action_Code) as \"Count\" from NG_Coll_ActionHistoryGrid where Action_Code = 'PTP' and cod_acct_no = '"
					+ loanAccountNo
					+ "' group by Action_Code union select Action_Code, count(Action_Code) as \"Count\" from NG_Coll_ActionHistoryGrid where Action_Code = 'Meeting Request' and cod_acct_no = '"
					+ loanAccountNo
					+ "' group by Action_Code union select Action_Code, count(Action_Code) as \"Count\" from NG_Coll_ActionHistoryGrid where Action_Code = 'Door Lock' and cod_acct_no = '"
					+ loanAccountNo + "' group by Action_Code";
			cm.mRepLogger.info("query: " + query);
			ArrayList rsList = (ArrayList) ifr.getDataFromDB(query);
			ArrayList actionCodeList;
			String actionCode;
			String actionCount;
			cm.mRepLogger.info(rsList);

			HashMap rsMap = new HashMap();
			rsMap.put("Refuse to Pay", 0);
			rsMap.put("Broken PTP", 0);
			rsMap.put("Legal", 0);
			rsMap.put("Initiate_Repo", 0);
			rsMap.put("NC Line ringing not responding", 0);
			rsMap.put("PTP", 0);
			rsMap.put("Meeting Request", 0);
			rsMap.put("Door Lock", 0);
			rsMap.put("Cheque Bounce", 0);
			rsMap.put("Complaint Against Customer", 0);

			for (int i = 0; i < rsList.size(); i++) {
				actionCodeList = (ArrayList) rsList.get(i);
				actionCode = (String) actionCodeList.get(0);
				actionCount = (String) actionCodeList.get(1);
				if (rsMap.containsKey(actionCode)) {
					rsMap.put(actionCode, actionCount);
				}
			}

			cm.mRepLogger.info(rsMap);

			String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:scor=\"http://scorecardrule.V.CollScoreCard1/\"> <soap:Header/> <soap:Body> <scor:executeRuleset> <!--Optional:--> <args0> <!--Optional:--> <cabinetName>ibps14aug</cabinetName> <!--Optional:--> <inobj> <!--Optional:--> <brokenptp_count>"
					+ rsMap.get("Broken PTP") + "</brokenptp_count> <!--Optional:--> <chequebounce_count>"
					+ rsMap.get("Cheque Bounce") + "</chequebounce_count> <!--Optional:--> <complaintagainstcustomer_>"
					+ rsMap.get("Complaint Against Customer")
					+ "</complaintagainstcustomer_> <!--Optional:--> <customernoresponse_count>"
					+ rsMap.get("NC Line ringing not responding")
					+ "</customernoresponse_count> <!--Optional:--> <doorclosed_count>" + rsMap.get("Door Lock")
					+ "</doorclosed_count> <!--Optional:--> <initiaterepossessionproce>" + rsMap.get("Initiate_Repo")
					+ "</initiaterepossessionproce> <!--Optional:--> <legalactioninitiation_cou>" + rsMap.get("Legal")
					+ "</legalactioninitiation_cou> <!--Optional:--> <meetingrequest_count>"
					+ rsMap.get("Meeting Request") + "</meetingrequest_count> <!--Optional:--> <promisetopay_count>"
					+ rsMap.get("PTP") + "</promisetopay_count> <!--Optional:--> <refusetopay_count>"
					+ rsMap.get("Refuse to Pay")
					+ "</refusetopay_count> </inobj> <!--Optional:--> <loginReqd></loginReqd> <!--Optional:--> <password>system123#</password> <!--Optional:--> <userName>badmin</userName> </args0> </scor:executeRuleset> </soap:Body> </soap:Envelope>";

			cm.mRepLogger.info(xml);
			try {
				URL url = new URL(wsEndPoint);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8");
				conn.setRequestMethod("POST");
				conn.setDoOutput(true);
				conn.setDoInput(true);
				DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
				wr.writeBytes(xml);
				wr.flush();
				wr.close();

				String responseStatus = conn.getResponseMessage();
				cm.mRepLogger.info(responseStatus);
				BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				cm.mRepLogger.info(in);

				ScoreCardResponseParser responseParser = new ScoreCardResponseParser();
				// String formattedSOAPResponse = responseParser.formatXML(response.toString());
				// cm.mRepLogger.info(formattedSOAPResponse);
				HashMap scores = responseParser.parseResponse(conn.getInputStream());
				cm.mRepLogger.info(scores);

				in.close();

				ifr.setValue("qBehavioralScorecard_BrokenPromise",
						(String) scores.get("qBehavioralScorecard_BrokenPromise"));
				ifr.setValue("qBehavioralScorecard_ChequeBounce",
						(String) scores.get("qBehavioralScorecard_ChequeBounce"));
				ifr.setValue("qBehavioralScorecard_ComplaintAgainstCustomer",
						(String) scores.get("qBehavioralScorecard_ComplaintAgainstCustomer"));
				ifr.setValue("qBehavioralScorecard_CustomerNoResponse",
						(String) scores.get("qBehavioralScorecard_CustomerNoResponse"));
				ifr.setValue("qBehavioralScorecard_DoorClosed", (String) scores.get("qBehavioralScorecard_DoorClosed"));
				ifr.setValue("qBehavioralScorecard_RefuseToPay",
						(String) scores.get("qBehavioralScorecard_RefuseToPay"));
				ifr.setValue("qBehavioralScorecard_LegalActionInitiation",
						(String) scores.get("qBehavioralScorecard_LegalActionInitiation"));
				ifr.setValue("qBehavioralScorecard_MeetingRequest",
						(String) scores.get("qBehavioralScorecard_MeetingRequest"));
				ifr.setValue("qBehavioralScorecard_PromisetoPay",
						(String) scores.get("qBehavioralScorecard_PromisetoPay"));
				ifr.setValue("qBehavioralScorecard_InitiateRepossessionProcess",
						(String) scores.get("qBehavioralScorecard_InitiateRepossessionProcess"));

				Integer total = Integer.parseInt(scores.get("qBehavioralScorecard_BrokenPromise").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_ChequeBounce").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_ComplaintAgainstCustomer").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_CustomerNoResponse").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_DoorClosed").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_RefuseToPay").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_LegalActionInitiation").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_MeetingRequest").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_PromisetoPay").toString())
						+ Integer.parseInt(scores.get("qBehavioralScorecard_InitiateRepossessionProcess").toString());

				cm.mRepLogger.info("Total" + total);
				ifr.setValue("qBehavioralScorecard_Total", total.toString());
			} catch (Exception e) {
//				e.printStackTrace();
			}
			break;
		}
		case "apportionmentFetch": {

			cm.fetchApportionmentData(JSdata);
			break;
		}
//		case "ActionHistoryData":{
//			cm.ActionHistoryUpdation(JSdata);
//			break;
//	}
		
		case "ActionHistoryData":{
			cm.actionAndDecisionHistoryUpdation("ActionHistory",JSdata);
			break;
		}
	
		case "DecisionHistoryData":{
			cm.actionAndDecisionHistoryUpdation("DecisionHistory",JSdata);
			break;
		}
		}
		return "Inside executeServerEvent";
		// throw new UnsupportedOperationException("Not supported yet."); //To change
		// body of generated methods, choose Tools | Templates.
	}

	@Override
	public JSONArray validateSubmittedForm(FormDef fd, IFormReference ifr, String string) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	@Override
	public String executeCustomService(FormDef fd, IFormReference ifr, String string, String string1, String string2) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	@Override
	public String getCustomFilterXML(FormDef fd, IFormReference ifr, String string) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}
}
