package com.newgen.iforms.user.collection.services;


import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;

import com.newgen.iforms.user.collection.CollectionCommonMethod;

public class WebServiceCalls {      
	private static Logger NGWSlogger = Logger.getLogger(WebServiceCalls.class.getName());
	private static boolean GENERATELOG=false;
	public WebServiceCalls(boolean GENERATE_LOG)
	{
		GENERATELOG=GENERATE_LOG;
	}
	
	public String executews_proxy_http(String InXml,String EndPointUrl,String proxy_Enabled,String proxy_IP,String proxy_port,String proxy_user,String proxy_password,String http_authentication,String http_user,String http_password,String append_url,String sSOAPAction) 
	{		
		String strout="FAIL";
		if (GENERATELOG){NGWSlogger.info("**********************Start processing a new request");}
		if (GENERATELOG){NGWSlogger.info("Inside executews_proxy_http");}
		try
		{
			if(proxy_Enabled.equalsIgnoreCase("true") || http_authentication.equalsIgnoreCase("true"))
			{
				if (GENERATELOG){NGWSlogger.info("Proxy enabled set to true or http_authentication true");}
				Authenticator.setDefault(new NGAuthenticator(proxy_user, proxy_password, proxy_IP, http_user,http_password,proxy_Enabled,http_authentication));
			}
		}
		catch (Exception e)
		{
			NGWSlogger.info("Error in setting authentication"+e);
		}
		String EndPoint=EndPointUrl;
		if (append_url.equalsIgnoreCase("true") && http_authentication.equalsIgnoreCase("true"))
		{
			if (GENERATELOG){NGWSlogger.info("Append url set to true");}
			if (EndPoint.indexOf("?")>-1)
			{
				EndPoint=EndPoint+"&UserName="+http_user+"&Password="+http_password;
			}
			else
			{
				EndPoint=EndPoint+"?UserName="+http_user+"&Password="+http_password;
			}
		}
		
		strout=ExecuteWs(InXml,EndPoint,sSOAPAction,null);
		if (GENERATELOG){NGWSlogger.info("++++++++End processing a request+++++++++++++");}
		return strout;
	}
	
	public String ExecuteWs(String InXml,String EndPoint)
    {
        String s2;
        SOAPConnection soapconnection=null;
        MessageFactory messagefactory=null;
        if(GENERATELOG)
            NGWSlogger.info("Inside execute ExecuteWs");
        s2 = "FAIL";
        try
        {
            ignoreCertificates();
            SOAPConnectionFactory soapconnectionfactory = SOAPConnectionFactory.newInstance();
            soapconnection = soapconnectionfactory.createConnection();
            messagefactory = MessageFactory.newInstance();
            if(GENERATELOG)
                NGWSlogger.info("Message factory initialization done");
        }
        catch(Exception exception) 
        { 
        	NGWSlogger.info("Error in SOAP Message execution "+exception);
        }
        if(GENERATELOG)
            NGWSlogger.info((new StringBuilder()).append("Soap Inxml=").append(InXml).toString());
        if(GENERATELOG)
            NGWSlogger.info((new StringBuilder()).append("Soap EndPoint=").append(EndPoint).toString());
        try
        {
        	SOAPMessage soapmessage = messagefactory.createMessage();
            SOAPPart soappart = soapmessage.getSOAPPart();
            StreamSource streamsource = new StreamSource(new StringReader(InXml));
            soappart.setContent(streamsource);
            soapmessage.saveChanges();
            if(GENERATELOG)
                NGWSlogger.info("Soap Message prepared");
            SOAPMessage soapmessage1 = soapconnection.call(soapmessage, EndPoint);
            if(GENERATELOG)
                NGWSlogger.info("Soap Message Executed");
            ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
            soapmessage1.writeTo(bytearrayoutputstream);
            s2 = new String(bytearrayoutputstream.toByteArray());
            if(GENERATELOG)
                NGWSlogger.info("Soap Message as string");
        }
        catch(Exception e)
        {
        	NGWSlogger.info("Error in SOAP Message execution "+e);
        }
       
        return s2;
    }
	
	public String ExecuteWs(String InXml,String EndPoint,String sSOAPAction,CollectionCommonMethod cm)
	{
		cm.mRepLogger.info("<<<<<<<<<<<Inside the ExecuteES of the SOAP>>>>>>>>>>"+sSOAPAction+"<<<<<<<<<<");
		System.setProperty("java.net.useSystemProxies", "true");
		String strOutXml="FAIL";
		SOAPConnectionFactory scf =null;
		SOAPConnection conn =null;
		MessageFactory mf =null;
		try
		{
			ignoreCertificates();
			scf =SOAPConnectionFactory.newInstance();
			conn =scf.createConnection();
			mf =MessageFactory.newInstance();			
			
		}
		catch (Exception ex)
		{
			cm.mRepLogger.info("Error in SOAP Message execution ",ex);
		}
		cm.mRepLogger.info("Soap Inxml="+InXml);
		cm.mRepLogger.info("Soap EndPoint="+EndPoint);
		try
			{
				SOAPMessage msg = mf.createMessage();
				MimeHeaders headers = msg.getMimeHeaders();
				headers.addHeader("SOAPAction",sSOAPAction);
         
				SOAPPart sp = msg.getSOAPPart();	
				StreamSource prepMsg =new StreamSource(new StringReader(InXml));
				sp.setContent(prepMsg);
				
				msg.saveChanges();
         
   
				cm.mRepLogger.info("Soap Message prepared");
				SOAPMessage rp = conn.call(msg, EndPoint);
				cm.mRepLogger.info("Soap Message Executed");
				ByteArrayOutputStream out1 = new ByteArrayOutputStream();         
				rp.writeTo(out1);  
				strOutXml = new String(out1.toByteArray());
				cm.mRepLogger.info("Soap Message as string");
			}
			catch (Exception ex1)
			{
				cm.mRepLogger.info("Error in SOAP Message execution ",ex1);
			}
			finally
			{
				try
				{
					conn.close();
					scf=null;
					mf=null;	
				}
				catch (Exception ex){}
			}
			return strOutXml;
	}
	
	public static String callSoapService(CollectionCommonMethod cm, String soapRequest,String url,String sSOAPAction, String Service) {
		cm.mRepLogger.info("<<<<<<<<<ENTERED callSoapService TO CALL "+Service+">>>>>>>>>");
		String finalvalue="FAIL";
		StringBuffer response = new StringBuffer();
		HttpsURLConnection conns= null;
		DataOutputStream wr = null;
		try {
	        URL obj = new URL(url);
//	        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	        
	        // Create all-trusting host name verifier
	        //added this as ICMP (Internet Control Message Protocol) is switched off in server.
				HostnameVerifier allHostsValid = new HostnameVerifier() {
					public boolean verify(String hostname, SSLSession session) {
						return true;
					}
				};
	        
				conns= (HttpsURLConnection) obj.openConnection();
        	conns.setHostnameVerifier(allHostsValid);

	        conns.setRequestMethod(sSOAPAction);//POST / GET
	        conns.setRequestProperty("Content-Type","text/xml; charset=utf-8"); 
	        conns.setDoOutput(true);
	        wr = new DataOutputStream(conns.getOutputStream());
	        wr.writeBytes(soapRequest);
	        wr.flush();
	        wr.close();
	        String responseStatus = conns.getResponseMessage();
	        cm.mRepLogger.info(responseStatus);
	        BufferedReader in = new BufferedReader(new InputStreamReader(
	        		conns.getInputStream()));
	        String inputLine;
	        
	        while ((inputLine = in.readLine()) != null) {
	            response.append(inputLine);
	        }
	        in.close();
	        
	        finalvalue= response.toString();
	        
	        return finalvalue;
	        } 
	       catch (Exception e) {
	    	   finalvalue="FAIL";
	    	   cm.mRepLogger.info("Exception in callSoapService for "+Service+" :: (Please check the error log for more details) :: "+e.getMessage());
	    	   cm.mErrLogger.info("Exception :: "+Service+" :: ",e);
	       }finally{ 
	    	   
	    	   try{ 
	    		   if(wr!=null)
	    		   wr.close();
	    	   }catch(Exception e){ 
	    		   cm.mErrLogger.info("Error in closing the DataOutputStream :: ",e);
	    	   }
	    	   
	       }
		
		return finalvalue;
	}
	
	public void ignoreCertificates() throws Exception 
	{                  
	  TrustManager tm = new TrustManager();         
	  //TrustManagerFactory tmf =  TrustManagerFactory.getInstance("SunX509", "SunJSSE"); 
        // TrustManager trustAllCerts[] = tmf.getTrustManagers();   
	  TrustManager[] trustAllCerts = {tm};                                    
	  // create an all trusting HostnameVerifier                  
	  HostnameVerifier AllowAllHostnameVerifier = new HostnameVerifier() {                          
		 
		  public boolean verify(String urlHostName, SSLSession session) {                                  
			  return true;                          
			  }                  
			  };                                    
			  // Install the all-trusting trust manager                  
			  SSLContext sc = SSLContext.getInstance("SSL");                  
			  sc.init(null, trustAllCerts, new java.security.SecureRandom());       
			  HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());     
			  HttpsURLConnection.setDefaultHostnameVerifier(AllowAllHostnameVerifier);   
	}  
	
	static class TrustManager implements X509TrustManager {                  
	 @Override                  
		 public void checkClientTrusted(X509Certificate[] arg0, String arg1)throws CertificateException {}                    
	 @Override                  
		 public void checkServerTrusted(X509Certificate[] arg0, String arg1)throws CertificateException {}                    
	 @Override                  
		 public X509Certificate[] getAcceptedIssuers() {return null;}          
	 }
	
	private class NGAuthenticator extends Authenticator
    {   
		private String proxy_user;
        private String proxy_password;
        private String proxy_IP;
        private String http_user;
        private String http_password;
        private String proxyenabled;
        public NGAuthenticator(String proxyUser, String proxyPasswd, String proxyHost,String basicAuthUser, String basicAuthPasswd,String proxyenabled,String httpenabled)
        {
            this.proxy_user = null;
            this.proxy_password = null;
            this.proxy_IP = null;
            this.http_user = null;
            this.http_password = null;
			this.proxyenabled = null;
			this.proxy_user = proxyUser;
            this.proxy_password = proxyPasswd;
            this.proxy_IP = proxyHost;
            this.http_user = basicAuthUser;
            this.http_password = basicAuthPasswd;
			this.proxyenabled = proxyenabled;

        }
        protected PasswordAuthentication getPasswordAuthentication()
        {            
            if(proxyenabled.equalsIgnoreCase("true") && getRequestingHost().equalsIgnoreCase(proxy_IP))
			{
					System.out.println("getRequestingHost="+getRequestingHost());
				return new PasswordAuthentication(proxy_user, proxy_password.toCharArray());
			}
            else
			{
				System.out.println("http authentication"+getRequestingHost());
				return new PasswordAuthentication(http_user, http_password.toCharArray());
			}
        }      
    }
 } 