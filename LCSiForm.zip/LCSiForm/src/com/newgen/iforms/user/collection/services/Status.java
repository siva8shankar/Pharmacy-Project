package com.newgen.iforms.user.collection.services;

public class Status {

	private boolean status;
	private boolean subStatus;
	private String msg;
	private String subMsg;
	
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public boolean isSubStatus() {
		return subStatus;
	}
	public void setSubStatus(boolean subStatus) {
		this.subStatus = subStatus;
	}
	public String getSubMsg() {
		return subMsg;
	}
	public void setSubMsg(String subMsg) {
		this.subMsg = subMsg;
	}
	
	
	
}
