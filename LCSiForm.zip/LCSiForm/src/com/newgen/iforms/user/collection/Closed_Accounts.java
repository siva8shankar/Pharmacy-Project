package com.newgen.iforms.user.collection;

import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.newgen.iforms.FormDef;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.iforms.user.collection.services.CollectionCommonServices;
import com.newgen.iforms.user.collection.services.Status;

public class Closed_Accounts implements IFormServerEventHandler {
	private IFormReference ifr = null;
	CollectionCommonMethod cm = null;

	public Closed_Accounts(CollectionCommonMethod cm, IFormReference ifr) {
		cm.mRepLogger.info("<--Inside Closed_Accounts-->");
		// logger = new CustomLogger();
		this.ifr = ifr;
		this.cm = cm;
	}
	
	@Override
	public void beforeFormLoad(FormDef arg0, IFormReference arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String executeCustomService(FormDef arg0, IFormReference arg1, String arg2, String arg3, String arg4) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JSONArray executeEvent(FormDef arg0, IFormReference arg1, String arg2, String arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String executeServerEvent(IFormReference ifr, String ControlID, String EventType, String JSdata) {
		cm.mRepLogger.info("Closed_Accounts: Inside executeServerEvent");
		cm.mRepLogger.info("Closed_Accounts: ControlID : " + ControlID);
		cm.mRepLogger.info("Closed_Accounts: EventType : " + EventType);
		cm.mRepLogger.info("Closed_Accounts: JSdata : " + JSdata);
		// TODO Auto-generated method stub
		
		switch (ControlID) {
		case "GetActionCodeValue": {
			cm.mRepLogger.info("Initiator executeServerEvent Inside GetActionCodeValue: ");
			return cm.getActionCodeValues(ifr.getActivityName(), ifr);
		}
		
		case "DocumentGeneration": {
			if (EventType.equalsIgnoreCase("FormLoad")) {
				return cm.onformLoadHandler_OutDocument_CAGL(ifr, ControlID, EventType, JSdata, ifr.getActivityName());
				
			} else {
				// Generate Document - By Vaibhav
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
						+ doctype + "'";
				cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
				try {

					Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
					JSONObject jRet=new JSONObject();
					cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
					jRet.put("Status", Boolean.toString(docStatus.isStatus()));
					jRet.put("Msg", docStatus.getMsg());
					jRet.put("SubMsg", docStatus.getSubMsg());
					jRet.put("DocName", doctype);
					
					// saving the outward document grid.
					cm.saveDocData();
					
					return jRet.toString();

				} catch (Exception e) {
					// TODO Auto-generated catch block
					// e.printStackTrace();
					cm.mErrLogger.info("Error in executeserverevent-->" + e.getMessage());
				}
				break;

			}
		}
		
		case "fetchOnDemandData": {
			cm.mRepLogger.info("Closed_Accounts executeServerEvent Inside fetchOnDemandData: ");
			cm.mRepLogger.info("For Control ID -->" + JSdata);
			cm.populateDumpData(JSdata, ifr.getValue("Loan_Account_No").toString(), ifr);
			
			//setting the role of the user in the role variable only if user clicks the decision tab.
			if(JSdata.contains("fetchBtnActionHistory")){ 
				cm.setRoleOfUser();
			}
			
			break;
		}
		
		case "GenerateSOA":{ 

			CollectionCommonServices cs = new CollectionCommonServices(ifr);
			JSONObject jRet=new JSONObject();
			
			try {

				String st=cs.GenerateSOA(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);

				if(st!=null && st.equalsIgnoreCase("SUCCESS")){ 
					
					String doctype = EventType;
					String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
							+ doctype + "'";
					List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
					Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
					
					cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
					jRet.put("Status", Boolean.toString(docStatus.isStatus()));
					jRet.put("Msg", docStatus.getMsg());
					jRet.put("SubMsg", docStatus.getSubMsg());
					jRet.put("DocName", doctype);
					
				}else if(st!=null && st.startsWith("FAILED")){ 
					
					jRet.put("Status", Boolean.toString(false));
					jRet.put("Msg", st.split("~~")[1]);
					jRet.put("SubMsg", "NA");
					jRet.put("DocName", "SOA");
					
				}
				
				// saving the outward document grid.
				cm.saveDocData();
				
			} catch (Exception e) {
				cm.mErrLogger.info("Error in generating the SOA execute server event-->",e);
				jRet.put("Status", Boolean.toString(false));
				jRet.put("Msg", "Issue in generating the Document :");
				jRet.put("SubMsg", "NA");
				jRet.put("DocName", "SOA");
			}
			
			return jRet.toString();
			
//			return cs.GenerateSOA(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);
			
			//below code to be removed and above return statement to be uncommented.
			/*String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='SOA'";
			cm.mRepLogger.info("Query for ExactDocType-----> " + Query);
			List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
			cm.mRepLogger.info("ExactDocType ------> " + ExactDocType.get(0).get(0));
			try {
				cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		}
		
		case "GenerateRepaymentSchedule": {
		CollectionCommonServices cs = new CollectionCommonServices(ifr);
		JSONObject jRet=new JSONObject();
		
		try {

			String st=cs.GenerateRepaymentSchedule(ifr.getValue("pInstanceID").toString(),ifr.getValue("Loan_Account_No").toString(),EventType,JSdata);
			
			if(st!=null && st.equalsIgnoreCase("SUCCESS")){ 
				
				String doctype = EventType;
				String Query = "SELECT Org_ExactDocType FROM NG_LCS_Master_Documents_List WHERE Document_Name='"
						+ doctype + "'";
				List<List<String>> ExactDocType = ifr.getDataFromDB(Query);
				Status docStatus = cm.generateDocument(ifr, ExactDocType.get(0).get(0), JSdata);
				
				cm.mRepLogger.info("---------XML---------"+docStatus.getSubMsg()+"---------XML--------");
				jRet.put("Status", Boolean.toString(docStatus.isStatus()));
				jRet.put("Msg", docStatus.getMsg());
				jRet.put("SubMsg", docStatus.getSubMsg());
				jRet.put("DocName", doctype);
				
			}else if(st!=null && st.startsWith("FAILED")){ 
				
				jRet.put("Status", Boolean.toString(false));
				jRet.put("Msg", st.split("~~")[1]);
				jRet.put("SubMsg", "NA");
				jRet.put("DocName", "Loan Repayment Schedule");
				
			}
			
			// saving the outward document grid.
			cm.saveDocData();
			
		} catch (Exception e) {
			cm.mErrLogger.info("Error in generating the Loan Repayment Schedule execute server event-->",e);
			jRet.put("Status", Boolean.toString(false));
			jRet.put("Msg", "Issue in generating the Document :");
			jRet.put("SubMsg", "NA");
			jRet.put("DocName", "Loan Repayment Schedule");
		}
		
		return jRet.toString();

	}
		}
		return null;
	}

	@Override
	public String getCustomFilterXML(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String setMaskedValue(String arg0, String arg1) {
		// TODO Auto-generated method stub
		return arg1;
	}

	@Override
	public JSONArray validateSubmittedForm(FormDef arg0, IFormReference arg1, String arg2) {
		// TODO Auto-generated method stub
		return null;
	}

}
