/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormListenerFactory;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.iforms.user.collection.Address_Update_Branch;
import com.newgen.iforms.user.collection.Address_Update_Central;
import com.newgen.iforms.user.collection.Auction;
import com.newgen.iforms.user.collection.Charge_Waiver;
import com.newgen.iforms.user.collection.Closed_Accounts;
import com.newgen.iforms.user.collection.CollectionCommonMethod;
import com.newgen.iforms.user.collection.Collection_Escalation;
import com.newgen.iforms.user.collection.Collection_PickUp;
import com.newgen.iforms.user.collection.DMS_Archival;
import com.newgen.iforms.user.collection.Document_Generation;
import com.newgen.iforms.user.collection.Exit;
import com.newgen.iforms.user.collection.Expense_Approval;
import com.newgen.iforms.user.collection.Initiate_Legal_Action;
import com.newgen.iforms.user.collection.Initiate_Sale_Approval;
import com.newgen.iforms.user.collection.Initiator;
import com.newgen.iforms.user.collection.Legal_Action_Approval;
import com.newgen.iforms.user.collection.Legal;
import com.newgen.iforms.user.collection.Legal_Update;
import com.newgen.iforms.user.collection.Action_From_Manager;
import com.newgen.iforms.user.collection.PTP;
import com.newgen.iforms.user.collection.Payment_Correction;
import com.newgen.iforms.user.collection.Payment_Posting;
import com.newgen.iforms.user.collection.Pre_Part_Closure_Request;
import com.newgen.iforms.user.collection.Quote_Approval;
import com.newgen.iforms.user.collection.Ready_For_Release;
import com.newgen.iforms.user.collection.Repayment_Swap_Branch;
import com.newgen.iforms.user.collection.Repayment_Swap_Central;
import com.newgen.iforms.user.collection.Repo_Marked;
import com.newgen.iforms.user.collection.Repo_Marking;
import com.newgen.iforms.user.collection.Repo_Release_Approval;
import com.newgen.iforms.user.collection.Repo_and_Sale;
import com.newgen.iforms.user.collection.Sale_and_Valuation;
import com.newgen.iforms.user.collection.Skip_Cases;
import com.newgen.iforms.user.collection.Skip_Cases_Escalation;

/********************************************************************
 * NEWGEN SOFTWARE TECHNOLOGIES LIMITED Group : CIG Product / Project : CAGL_LCS
 * Module : <IFormUser> File Name : <File Name> Author : <Sidhant Mittal> Date
 * written : 08/07/2020 (DD/MM/YYYY) Description : <Description> CHANGE HISTORY
 ***********************************************************************************************
 * Date Change By Change Description (Bug No. (If Any)) (DD/MM/YYYY)
 ************************************************************************************************/

public class LCS implements IFormListenerFactory {
	

	@Override
	public IFormServerEventHandler getClassInstance(IFormReference iformObj) {
		CollectionCommonMethod cm=new CollectionCommonMethod(iformObj);
		String activityName = "";
		String processName = "";
		processName = iformObj.getProcessName();
		activityName = iformObj.getActivityName();
		cm.mRepLogger.info("<---Inside LCS Class before returning activity specific class--->");
		cm.mRepLogger.info("processName>>> v1.1" + processName);
		cm.mRepLogger.info("Actual activity name>>>" + activityName);

		if (processName.equalsIgnoreCase("LCS")) {
			if (activityName.equalsIgnoreCase("Initiator")) {
				cm.mRepLogger.info("Initiator Activity Identified");
				return new Initiator(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Collection_Escalation")) {
				cm.mRepLogger.info("Collection_Escalation Activity Identified");
				return new Collection_Escalation(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Skip_Cases")) {
				cm.mRepLogger.info("Skip_Cases Activity Identified");
				return new Skip_Cases(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Skip_Cases_Escalation")) {
				cm.mRepLogger.info("Skip_Cases_Escalation Activity Identified");
				return new Skip_Cases_Escalation(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Payment_Posting")) {
				cm.mRepLogger.info("Payment_Posting Activity Identified");
				return new Payment_Posting(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Pre_Part_Closure_Request")) {
				cm.mRepLogger.info("Pre_Part_Closure_Request Activity Identified");
				return new Pre_Part_Closure_Request(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Charge_Waiver")) {
				cm.mRepLogger.info("Charge_Waiver Activity Identified");
				return new Charge_Waiver(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("PTP")) {
				cm.mRepLogger.info("PTP Activity Identified");
				return new PTP(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Payment_Correction")) {
				cm.mRepLogger.info("Payment_Correction Activity Identified");
				return new Payment_Correction(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Document_Generation")) {
				cm.mRepLogger.info("Document Activity Identified");
				return new Document_Generation(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Address_Update_Branch")) {
				cm.mRepLogger.info("Address_Update_Branch Activity Identified");
				return new Address_Update_Branch(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Repayment_Swap_Branch")) {
				cm.mRepLogger.info("Repayment_Swap_Branch Activity Identified");
				return new Repayment_Swap_Branch(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Manager_Action")) {
				cm.mRepLogger.info("Manager_Action Activity Identified");
				return new Action_From_Manager(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Address_Update_Central")) {
				cm.mRepLogger.info("Address_Update_Central Activity Identified");
				return new Address_Update_Central(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Repayment_Swap_Central")) {
				cm.mRepLogger.info("Repayment_Swap_Central Activity Identified");
				return new Repayment_Swap_Central(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Action_From_Manager")) {
				cm.mRepLogger.info("Repayment_Swap_Central Activity Identified");
				return new Action_From_Manager(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Collection_PickUp")) {
				cm.mRepLogger.info("Collection_PickUp Activity Identified");
				return new Collection_PickUp(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Legal")) {
				cm.mRepLogger.info("Legal Activity Identified");
				return new Legal(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Initiate_Legal_Action")) {
				cm.mRepLogger.info("Initiate_Legal_Action Activity Identified");
				return new Initiate_Legal_Action(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Legal_Action_Approval")) {
				cm.mRepLogger.info("Legal_Action_Approval Activity Identified");
				return new Legal_Action_Approval(cm,iformObj);
			} else if (activityName.equalsIgnoreCase("Legal_Update")) {
				cm.mRepLogger.info("Legal_Update Activity Identified");
				return new Legal_Update(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Expense_Approval")) {
				cm.mRepLogger.info("Expense_Approval Activity Identified");
				return new Expense_Approval(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Repo_and_Sale")) {
				cm.mRepLogger.info("Repo_and_Sale Activity Identified");
				return new Repo_and_Sale(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Repo_Marking")) {
				cm.mRepLogger.info("Repo_Marking Activity Identified");
				return new Repo_Marking(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Repo_Marked")) {
				cm.mRepLogger.info("Repo_Marked Activity Identified");
				return new Repo_Marked(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Repo_Release_Approval")) {
				cm.mRepLogger.info("Repo_Release_Approval Activity Identified");
				return new Repo_Release_Approval(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Initiate_Sale_Approval")) {
				cm.mRepLogger.info("Initiate_Sale_Approval Activity Identified");
				return new Initiate_Sale_Approval(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Sale_and_Valuation")) {
				cm.mRepLogger.info("Sale_and_Valuation Activity Identified");
				return new Sale_and_Valuation(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Quote_Approval")) {
				cm.mRepLogger.info("Quote_Approval Activity Identified");
				return new Quote_Approval(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Auction")) {
				cm.mRepLogger.info("Auction Activity Identified");
				return new Auction(cm,iformObj);
			}else if (activityName.equalsIgnoreCase("Ready_For_Release")) {
				cm.mRepLogger.info("Ready_For_Release Activity Identified");
				return new Ready_For_Release(cm,iformObj);
			}else if(activityName.equalsIgnoreCase("DMS_Archival")){ 
				cm.mRepLogger.info("DMS_Archival Activity Identified");
				return new DMS_Archival(cm,iformObj);
			}else if(activityName.equalsIgnoreCase("Closed_Accounts")){ 
				cm.mRepLogger.info("Closed_Accounts Identified");
				return new Closed_Accounts(cm,iformObj);
			}else if(activityName.equalsIgnoreCase("Exit")){ 
				cm.mRepLogger.info("Exit Identified");
				return new Exit(cm,iformObj);
			}
			

		}
		return null;
		// return new Collection_1_30_iForm();
	}

}
