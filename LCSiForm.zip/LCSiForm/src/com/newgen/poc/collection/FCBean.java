/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.poc.collection;

import java.io.Serializable;

/**
 *
 * @author Administrator
 */
public class FCBean implements Serializable{

    String LoggedInUserName;
    String LoggedInUserID;
    String LoanNo;
    String LoanProduct;
    String ApplicantName;
    String AddressLine1;
    String AddressLine2;
    String AddressLine3;
    String AddressLine4;
    String AddressCity;
    String AddressState;
    String AddressCountry;
    String AddressZip;
    String ApplicantPhoneNo;
    String Subject;
    String RateMethod;
    String PaymentSource;
    String BalanceAmount;
    String OverdueInstallments;
    String InterestTillLockingPeriod;
    String UnbilledInstallment;
    String EMIWithInsurance;
    String LegalCharges;
    String SeizingCharges;
    String ChequeBouncing;
    String CollectionCharges;
    String ServiceFees;
    String OtherDues;
    String PrePaymentInterest;
    String LPPAmount;
    String UnrealizedAmount;
    String ExcessAmount;
    String TotalAmountReceivable;
    String VehicleRegistrationNo;
    String VehicleEngineNo;
    String VehicleChassisNo;
    String VehicleMake;
    String VehicleModel;

    public String getRateMethod() {
        return RateMethod;
    }

    public void setRateMethod(String RateMethod) {
        this.RateMethod = RateMethod;
    }

    public String getPaymentSource() {
        return PaymentSource;
    }

    public void setPaymentSource(String PaymentSource) {
        this.PaymentSource = PaymentSource;
    }

    
    public String getLoggedInUserName() {
        return LoggedInUserName;
    }

    public void setLoggedInUserName(String LoggedInUserName) {
        this.LoggedInUserName = LoggedInUserName;
    }

    public String getLoggedInUserID() {
        return LoggedInUserID;
    }

    public void setLoggedInUserID(String LoggedInUserID) {
        this.LoggedInUserID = LoggedInUserID;
    }

        public String getApplicantPhoneNo() {
        return ApplicantPhoneNo;
    }

    public void setApplicantPhoneNo(String ApplicantPhoneNo) {
        this.ApplicantPhoneNo = ApplicantPhoneNo;
    }

    public String getVehicleMake() {
        return VehicleMake;
    }

    public void setVehicleMake(String VehicleMake) {
        this.VehicleMake = VehicleMake;
    }

    public String getVehicleModel() {
        return VehicleModel;
    }

    public void setVehicleModel(String VehicleModel) {
        this.VehicleModel = VehicleModel;
    }

    public String getVehicleRegistrationNo() {
        return VehicleRegistrationNo;
    }

    public void setVehicleRegistrationNo(String VehicleRegistrationNo) {
        this.VehicleRegistrationNo = VehicleRegistrationNo;
    }

    public String getVehicleEngineNo() {
        return VehicleEngineNo;
    }

    public void setVehicleEngineNo(String VehicleEngineNo) {
        this.VehicleEngineNo = VehicleEngineNo;
    }

    public String getVehicleChassisNo() {
        return VehicleChassisNo;
    }

    public void setVehicleChassisNo(String VehicleChassisNo) {
        this.VehicleChassisNo = VehicleChassisNo;
    }

    public String getLoanProduct() {
        return LoanProduct;
    }

    public void setLoanProduct(String LoanProduct) {
        this.LoanProduct = LoanProduct;
    }

    public String getAddressLine1() {
        return AddressLine1;
    }

    public void setAddressLine1(String AddressLine1) {
        this.AddressLine1 = AddressLine1;
    }

    public String getAddressLine2() {
        return AddressLine2;
    }

    public void setAddressLine2(String AddressLine2) {
        this.AddressLine2 = AddressLine2;
    }

    public String getAddressLine3() {
        return AddressLine3;
    }

    public void setAddressLine3(String AddressLine3) {
        this.AddressLine3 = AddressLine3;
    }

    public String getAddressLine4() {
        return AddressLine4;
    }

    public void setAddressLine4(String AddressLine4) {
        this.AddressLine4 = AddressLine4;
    }

    public String getAddressCity() {
        return AddressCity;
    }

    public void setAddressCity(String AddressCity) {
        this.AddressCity = AddressCity;
    }

    public String getAddressState() {
        return AddressState;
    }

    public void setAddressState(String AddressState) {
        this.AddressState = AddressState;
    }

    public String getAddressCountry() {
        return AddressCountry;
    }

    public void setAddressCountry(String AddressCountry) {
        this.AddressCountry = AddressCountry;
    }

    public String getAddressZip() {
        return AddressZip;
    }

    public void setAddressZip(String AddressZip) {
        this.AddressZip = AddressZip;
    }

    public String getApplicantName() {
        return ApplicantName;
    }

    public void setApplicantName(String ApplicantName) {
        this.ApplicantName = ApplicantName;
    }

    public String getBalanceAmount() {
        return BalanceAmount;
    }

    public void setBalanceAmount(String BalanceAmount) {
        this.BalanceAmount = BalanceAmount;
    }

    public String getOverdueInstallments() {
        return OverdueInstallments;
    }

    public void setOverdueInstallments(String OverdueInstallments) {
        this.OverdueInstallments = OverdueInstallments;
    }

    public String getInterestTillLockingPeriod() {
        return InterestTillLockingPeriod;
    }

    public void setInterestTillLockingPeriod(String InterestTillLockingPeriod) {
        this.InterestTillLockingPeriod = InterestTillLockingPeriod;
    }

    public String getUnbilledInstallment() {
        return UnbilledInstallment;
    }

    public void setUnbilledInstallment(String UnbilledInstallment) {
        this.UnbilledInstallment = UnbilledInstallment;
    }

    public String getEMIWithInsurance() {
        return EMIWithInsurance;
    }

    public void setEMIWithInsurance(String EMIWithInsurance) {
        this.EMIWithInsurance = EMIWithInsurance;
    }

    public String getLegalCharges() {
        return LegalCharges;
    }

    public void setLegalCharges(String LegalCharges) {
        this.LegalCharges = LegalCharges;
    }

    public String getSeizingCharges() {
        return SeizingCharges;
    }

    public void setSeizingCharges(String SeizingCharges) {
        this.SeizingCharges = SeizingCharges;
    }

    public String getChequeBouncing() {
        return ChequeBouncing;
    }

    public void setChequeBouncing(String ChequeBouncing) {
        this.ChequeBouncing = ChequeBouncing;
    }

    public String getCollectionCharges() {
        return CollectionCharges;
    }

    public void setCollectionCharges(String CollectionCharges) {
        this.CollectionCharges = CollectionCharges;
    }

    public String getServiceFees() {
        return ServiceFees;
    }

    public void setServiceFees(String ServiceFees) {
        this.ServiceFees = ServiceFees;
    }

    public String getOtherDues() {
        return OtherDues;
    }

    public void setOtherDues(String OtherDues) {
        this.OtherDues = OtherDues;
    }

    public String getPrePaymentInterest() {
        return PrePaymentInterest;
    }

    public void setPrePaymentInterest(String PrePaymentInterest) {
        this.PrePaymentInterest = PrePaymentInterest;
    }

    public String getLPPAmount() {
        return LPPAmount;
    }

    public void setLPPAmount(String LPPAmount) {
        this.LPPAmount = LPPAmount;
    }

    public String getUnrealizedAmount() {
        return UnrealizedAmount;
    }

    public void setUnrealizedAmount(String UnrealizedAmount) {
        this.UnrealizedAmount = UnrealizedAmount;
    }

    public String getExcessAmount() {
        return ExcessAmount;
    }

    public void setExcessAmount(String ExcessAmount) {
        this.ExcessAmount = ExcessAmount;
    }

    public String getTotalAmountReceivable() {
        return TotalAmountReceivable;
    }

    public void setTotalAmountReceivable(String TotalAmountReceivable) {
        this.TotalAmountReceivable = TotalAmountReceivable;
    }

    public String getSubject() {
        return Subject;
    }

    public void setSubject(String Subject) {
        this.Subject = Subject;
    }

    public String getLoanNo() {
        return LoanNo;
    }

    public void setLoanNo(String LoanNo) {
        this.LoanNo = LoanNo;
    }

   

}
