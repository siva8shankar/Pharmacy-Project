/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.poc.collection;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class SOABean implements Serializable{

    String LoggedInUserName;
    String LoggedInUserID;

    /**
     * ****section 1 Customer Details Start ****
     */
    String ApplicantName;
    String CoApplicantName;
    String GuarantorName;
    String Address;

    /**
     * ****section 1 Customer Details End ****
     */
    /**
     * ****section 2 Loan Details Start ****
     */
    String Branch;
    String LoanAccountNo;
    String Product;
    String Scheme;
    String LoanSanctionDate;
    String InstallmentStartDate;
    String Frequency;
    String RateType;
    String AmountSanctioned;
    String AmountDisbursed;
    String RateOfInterest;
    String TenureMonths;
    String InstallmentAmount;
    String InstallmentEndDate;
    String TotalInstallment;
    String AdvanceInstallment;

    /**
     * ****section 2 Loan Details END ****
     */
    /**
     * ****section 3 Loan Status Start ****
     */
    String LoanStatus;
    String LoanClosureFlag;
    String InstallmentsBilled;
    String InstallmentsReceived;
    String InstallmentsOverDueNos;
    String ChequesBounced;
    String ExcessAmount;
    String AverageDelay;
    String CaseFlagRepo;
    String CaseFlagInsurance;
    String LoanClosureDate;
    String PrincipalPaid;
    String InterestPaid;
    String InstallmentDueAmount;
    String OtherChargesDue;
    String TotalOverdue;
    String PeakDelay;
    String CaseFlaglegal;
    String LoanSuraksha;

    /**
     * ****section 3 Loan Status END ****
     */
    /**
     * ****section 4 Collateral Details (In Wheels) Start ****
     */
    String Model;
    String Manufacturer;
    String EngineNo;
    String CollateralAmountSD;
    String VehicleNo;
    String ChasisNo;
    String LinkedLoanNumbers;
    /**
     * ****section 4 Collateral Details (In Wheels) END ****
     */

    /**
     * ****section 5 Collateral Details (In Mortgage) Start ****
     */
    String CollateralAmountSD5;
    String PropertyAddress;
    String AssetDesc;
    String LinkedLoanNumbers5;

    /**
     * ****section 5 Collateral Details (In Mortgage) END ****
     */
    
    /**
     * ****section 6 SOA details Start ****
     */
    ArrayList soaDataList = new ArrayList();

    /**
     * ****section 6 SOA details END ****
     */
    public String getLoggedInUserName() {
        return LoggedInUserName;
    }

    public void setLoggedInUserName(String LoggedInUserName) {
        this.LoggedInUserName = LoggedInUserName;
    }

    public String getLoggedInUserID() {
        return LoggedInUserID;
    }

    public void setLoggedInUserID(String LoggedInUserID) {
        this.LoggedInUserID = LoggedInUserID;
    }

    public String getApplicantName() {
        return ApplicantName;
    }

    public void setApplicantName(String ApplicantName) {
        this.ApplicantName = ApplicantName;
    }

    public String getCoApplicantName() {
        return CoApplicantName;
    }

    public void setCoApplicantName(String CoApplicantName) {
        this.CoApplicantName = CoApplicantName;
    }

    public String getGuarantorName() {
        return GuarantorName;
    }

    public void setGuarantorName(String GuarantorName) {
        this.GuarantorName = GuarantorName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String Branch) {
        this.Branch = Branch;
    }

    public String getLoanAccountNo() {
        return LoanAccountNo;
    }

    public void setLoanAccountNo(String LoanAccountNo) {
        this.LoanAccountNo = LoanAccountNo;
    }

    public String getProduct() {
        return Product;
    }

    public void setProduct(String Product) {
        this.Product = Product;
    }

    public String getScheme() {
        return Scheme;
    }

    public void setScheme(String Scheme) {
        this.Scheme = Scheme;
    }

    public String getLoanSanctionDate() {
        return LoanSanctionDate;
    }

    public void setLoanSanctionDate(String LoanSanctionDate) {
        this.LoanSanctionDate = LoanSanctionDate;
    }

    public String getInstallmentStartDate() {
        return InstallmentStartDate;
    }

    public void setInstallmentStartDate(String InstallmentStartDate) {
        this.InstallmentStartDate = InstallmentStartDate;
    }

    public String getFrequency() {
        return Frequency;
    }

    public void setFrequency(String Frequency) {
        this.Frequency = Frequency;
    }

    public String getRateType() {
        return RateType;
    }

    public void setRateType(String RateType) {
        this.RateType = RateType;
    }

    public String getAmountSanctioned() {
        return AmountSanctioned;
    }

    public void setAmountSanctioned(String AmountSanctioned) {
        this.AmountSanctioned = AmountSanctioned;
    }

    public String getAmountDisbursed() {
        return AmountDisbursed;
    }

    public void setAmountDisbursed(String AmountDisbursed) {
        this.AmountDisbursed = AmountDisbursed;
    }

    public String getRateOfInterest() {
        return RateOfInterest;
    }

    public void setRateOfInterest(String RateOfInterest) {
        this.RateOfInterest = RateOfInterest;
    }

    public String getTenureMonths() {
        return TenureMonths;
    }

    public void setTenureMonths(String TenureMonths) {
        this.TenureMonths = TenureMonths;
    }

    public String getInstallmentAmount() {
        return InstallmentAmount;
    }

    public void setInstallmentAmount(String InstallmentAmount) {
        this.InstallmentAmount = InstallmentAmount;
    }

    public String getInstallmentEndDate() {
        return InstallmentEndDate;
    }

    public void setInstallmentEndDate(String InstallmentEndDate) {
        this.InstallmentEndDate = InstallmentEndDate;
    }

    public String getTotalInstallment() {
        return TotalInstallment;
    }

    public void setTotalInstallment(String TotalInstallment) {
        this.TotalInstallment = TotalInstallment;
    }

    public String getAdvanceInstallment() {
        return AdvanceInstallment;
    }

    public void setAdvanceInstallment(String AdvanceInstallment) {
        this.AdvanceInstallment = AdvanceInstallment;
    }

    public String getLoanStatus() {
        return LoanStatus;
    }

    public void setLoanStatus(String LoanStatus) {
        this.LoanStatus = LoanStatus;
    }

    public String getLoanClosureFlag() {
        return LoanClosureFlag;
    }

    public void setLoanClosureFlag(String LoanClosureFlag) {
        this.LoanClosureFlag = LoanClosureFlag;
    }

    public String getInstallmentsBilled() {
        return InstallmentsBilled;
    }

    public void setInstallmentsBilled(String InstallmentsBilled) {
        this.InstallmentsBilled = InstallmentsBilled;
    }

    public String getInstallmentsReceived() {
        return InstallmentsReceived;
    }

    public void setInstallmentsReceived(String InstallmentsReceived) {
        this.InstallmentsReceived = InstallmentsReceived;
    }

    public String getInstallmentsOverDueNos() {
        return InstallmentsOverDueNos;
    }

    public void setInstallmentsOverDueNos(String InstallmentsOverDueNos) {
        this.InstallmentsOverDueNos = InstallmentsOverDueNos;
    }

    public String getChequesBounced() {
        return ChequesBounced;
    }

    public void setChequesBounced(String ChequesBounced) {
        this.ChequesBounced = ChequesBounced;
    }

    public String getExcessAmount() {
        return ExcessAmount;
    }

    public void setExcessAmount(String ExcessAmount) {
        this.ExcessAmount = ExcessAmount;
    }

    public String getAverageDelay() {
        return AverageDelay;
    }

    public void setAverageDelay(String AverageDelay) {
        this.AverageDelay = AverageDelay;
    }

    public String getCaseFlagRepo() {
        return CaseFlagRepo;
    }

    public void setCaseFlagRepo(String CaseFlagRepo) {
        this.CaseFlagRepo = CaseFlagRepo;
    }

    public String getCaseFlagInsurance() {
        return CaseFlagInsurance;
    }

    public void setCaseFlagInsurance(String CaseFlagInsurance) {
        this.CaseFlagInsurance = CaseFlagInsurance;
    }

    public String getLoanClosureDate() {
        return LoanClosureDate;
    }

    public void setLoanClosureDate(String LoanClosureDate) {
        this.LoanClosureDate = LoanClosureDate;
    }

    public String getPrincipalPaid() {
        return PrincipalPaid;
    }

    public void setPrincipalPaid(String PrincipalPaid) {
        this.PrincipalPaid = PrincipalPaid;
    }

    public String getInterestPaid() {
        return InterestPaid;
    }

    public void setInterestPaid(String InterestPaid) {
        this.InterestPaid = InterestPaid;
    }

    public String getInstallmentDueAmount() {
        return InstallmentDueAmount;
    }

    public void setInstallmentDueAmount(String InstallmentDueAmount) {
        this.InstallmentDueAmount = InstallmentDueAmount;
    }

    public String getOtherChargesDue() {
        return OtherChargesDue;
    }

    public void setOtherChargesDue(String OtherChargesDue) {
        this.OtherChargesDue = OtherChargesDue;
    }

    public String getTotalOverdue() {
        return TotalOverdue;
    }

    public void setTotalOverdue(String TotalOverdue) {
        this.TotalOverdue = TotalOverdue;
    }

    public String getPeakDelay() {
        return PeakDelay;
    }

    public void setPeakDelay(String PeakDelay) {
        this.PeakDelay = PeakDelay;
    }

    public String getCaseFlaglegal() {
        return CaseFlaglegal;
    }

    public void setCaseFlaglegal(String CaseFlaglegal) {
        this.CaseFlaglegal = CaseFlaglegal;
    }

    public String getLoanSuraksha() {
        return LoanSuraksha;
    }

    public void setLoanSuraksha(String LoanSuraksha) {
        this.LoanSuraksha = LoanSuraksha;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getManufacturer() {
        return Manufacturer;
    }

    public void setManufacturer(String Manufacturer) {
        this.Manufacturer = Manufacturer;
    }

    public String getEngineNo() {
        return EngineNo;
    }

    public void setEngineNo(String EngineNo) {
        this.EngineNo = EngineNo;
    }

    public String getCollateralAmountSD() {
        return CollateralAmountSD;
    }

    public void setCollateralAmountSD(String CollateralAmountSD) {
        this.CollateralAmountSD = CollateralAmountSD;
    }

    public String getVehicleNo() {
        return VehicleNo;
    }

    public void setVehicleNo(String VehicleNo) {
        this.VehicleNo = VehicleNo;
    }

    public String getChasisNo() {
        return ChasisNo;
    }

    public void setChasisNo(String ChasisNo) {
        this.ChasisNo = ChasisNo;
    }

    public String getLinkedLoanNumbers() {
        return LinkedLoanNumbers;
    }

    public void setLinkedLoanNumbers(String LinkedLoanNumbers) {
        this.LinkedLoanNumbers = LinkedLoanNumbers;
    }

    public String getCollateralAmountSD5() {
        return CollateralAmountSD5;
    }

    public void setCollateralAmountSD5(String CollateralAmountSD5) {
        this.CollateralAmountSD5 = CollateralAmountSD5;
    }

    public String getPropertyAddress() {
        return PropertyAddress;
    }

    public void setPropertyAddress(String PropertyAddress) {
        this.PropertyAddress = PropertyAddress;
    }

    public String getAssetDesc() {
        return AssetDesc;
    }

    public void setAssetDesc(String AssetDesc) {
        this.AssetDesc = AssetDesc;
    }

    public String getLinkedLoanNumbers5() {
        return LinkedLoanNumbers5;
    }

    public void setLinkedLoanNumbers5(String LinkedLoanNumbers5) {
        this.LinkedLoanNumbers5 = LinkedLoanNumbers5;
    }   
    
}
