/*
 * @(#)GenerateBondReceiptServlet.java
 *
 * Copyright (c) 1992-2008 Newgen Software Technologies, Inc.
 * A-6, Satsang Vihar Marg, Qutab Institutional Area, New Delhi -110 067 INDIA
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Newgen
 * Software Technologies, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with newgen.

 *Group									: CIG
 *Product / Project						: OmniDocs 6.1
 *Module									: AXA Webservice
 *File Name								: NGWebServiceSupport.java
 *Author									: Ajay Kumar Pandey
 *Date written (DD/MM/YYYY)              : 18/08/2009
 *Description							: This is supporting class for Newgen Webservices.
-------------------------------------------------------------------------
CHANGE HISTORY
-------------------------------------------------------------------------
Date				Change By		Change Description (Bug No. (If Any))

 */
package com.newgen.poc.collection;

/**
 *
 * @author Administrator
 */
public class Base64
{

    /**
     * 
     * @param data
     * @return
     */
    public String encode(String data)
    {
        return (getString(encode(getBinaryBytes(data))));
    }

    /**
     * 
     * @param data
     * @return
     */
    public byte[] encode(byte[] data)
    {
        int c;
        int len = data.length;
        StringBuffer ret = new StringBuffer(((len / 3) + 1) * 4);
        for (int i = 0; i < len; ++i)
        {
            c = (data[i] >> 2) & 0x3f;
            ret.append(cvt.charAt(c));
            c = (data[i] << 4) & 0x3f;
            if (++i < len)
            {
                c |= (data[i] >> 4) & 0x0f;
            }
            ret.append(cvt.charAt(c));
            if (i < len)
            {
                c = (data[i] << 2) & 0x3f;
                if (++i < len)
                {
                    c |= (data[i] >> 6) & 0x03;
                }
                ret.append(cvt.charAt(c));
            }
            else
            {
                ++i;
                ret.append((char) fillchar);
            }

            if (i < len)
            {
                c = data[i] & 0x3f;
                ret.append(cvt.charAt(c));
            }
            else
            {
                ret.append((char) fillchar);
            }
        }

        return (getBinaryBytes(ret.toString()));
    }

    /**
     * 
     * @param data
     * @return
     */
    public String decode(String data)
    {
        return (getString(decode(getBinaryBytes(data))));
    }

    /**
     * 
     * @param data
     * @return
     */
    public byte[] decode(byte[] data)
    {
        int c;
        int c1;
        int len = data.length;
        StringBuffer ret = new StringBuffer((len * 3) / 4);
        for (int i = 0; i < len; ++i)
        {
            c = cvt.indexOf(data[i]);
            ++i;
            c1 = cvt.indexOf(data[i]);
            c = ((c << 2) | ((c1 >> 4) & 0x3));
            ret.append((char) c);
            if (++i < len)
            {
                c = data[i];
                if (fillchar == c)
                {
                    break;
                }
                c = cvt.indexOf((char) c);
                c1 = ((c1 << 4) & 0xf0) | ((c >> 2) & 0xf);
                ret.append((char) c1);
            }

            if (++i < len)
            {
                c1 = data[i];
                if (fillchar == c1)
                {
                    break;
                }
                c1 = cvt.indexOf((char) c1);
                c = ((c << 6) & 0xc0) | c1;
                ret.append((char) c);
            }
        }

        return (getBinaryBytes(ret.toString()));
    }

    /**
     * 
     * @param arr
     * @return
     */
    public String getString(byte[] arr)
    {
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < arr.length; ++i)
        {
            buf.append((char) arr[i]);
        }
        return (buf.toString());
    }

    /**
     * 
     * @param str
     * @return
     */
    public byte[] getBinaryBytes(String str)
    {
        byte[] b = new byte[str.length()];
        for (int i = 0; i < b.length; ++i)
        {
            b[i] = (byte) str.charAt(i);
        }
        return (b);
    }
    private final int fillchar = '=';

    // 00000000001111111111222222
    // 01234567890123456789012345
    private final String cvt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" // 22223333333333444444444455
            // 67890123456789012345678901
            + "abcdefghijklmnopqrstuvwxyz" // 555555556666
            // 234567890123
            + "0123456789+/";
}		// end of Base64 class.
