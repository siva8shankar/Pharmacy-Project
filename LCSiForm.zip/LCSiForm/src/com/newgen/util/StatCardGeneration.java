package com.newgen.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.user.collection.CollectionCommonMethod;

public class StatCardGeneration {
	HashMap<String, String> fieldLabelMap = new HashMap<String, String>();
	HashMap<String, String> fieldValueMap = new HashMap<String, String>();
	//CollectionCommonMethod cm = new CollectionCommonMethod(ifr);
	
	public StatCardGeneration() {
		fieldLabelMap.put("cod_acct_no", "Loan Account No");
		fieldLabelMap.put("cod_acct_no_old", "Old Loan Account No(Reference No)");
		fieldLabelMap.put("cod_cust_id", "Customer ID/Member ID");
		fieldLabelMap.put("nam_cust_shrt", "Customer Name");
		fieldLabelMap.put("nam_contact_person", "Contact Person");
		fieldLabelMap.put("ref_cust_phone", "Customer Contact No");
		fieldLabelMap.put("dat_acct_open", "Loan Booking Date");
		fieldLabelMap.put("amt_net_disbursed", "Loan Amount/Disbursement Amount");
		fieldLabelMap.put("ctr_term_months", "Tenure");
		fieldLabelMap.put("amt_instal", "EMI Amount");
		fieldLabelMap.put("flg_repayment_mode", "Repayment Mode");
		fieldLabelMap.put("nam_product", "Product Name");
		fieldLabelMap.put("asset_name", "Asset Name");
		//fieldLabelMap.put("", "Sub Product");
		//fieldLabelMap.put("", "Vehicle No");
		fieldLabelMap.put("dpd", "DPD");
		fieldLabelMap.put("dpd_bom", "DPD_BOM");
		//fieldLabelMap.put("", "DPD_String");
		fieldLabelMap.put("amt_princ_balance", "Total Amount Due / Total EMI Outstanding");
		fieldLabelMap.put("outstanding_pre_emi_amount", "Outstanding Pre EMI Amount");
		fieldLabelMap.put("amt_arrears_charges", "Charges Overdue");
		fieldLabelMap.put("BAL_OUTSTANDING", "Total Outstanding");
		fieldLabelMap.put("repoflag", "Repo Flag & Status");
		fieldLabelMap.put("legalflag", "Legal Flag & Status");
		fieldLabelMap.put("group_individual_loan", "Loan Type / Category");
		fieldLabelMap.put("lst_pymnt_rcvd_amnt", "Last Payment Received Amount");
		fieldLabelMap.put("dat_last_payment", "Last Payment Received Date");
		fieldLabelMap.put("lst_pymnt_rcvd_month", "Payment Received for the Month");
		fieldLabelMap.put("othr_chrgs_clctn_month", "Other Charges Collection (month)");
		fieldLabelMap.put("unadjusted_fund", "Unadjusted Fund");
		fieldLabelMap.put("principal_outstanding", "Principal Outstanding");
		fieldLabelMap.put("interest_outstanding", "Interest Outstanding");
		fieldLabelMap.put("emi_with_insurance", "EMI with Insurance");	
	}
	
	public String generateStatCard(IFormReference ifr, String loanAccountNo, String fieldString) {
		System.out.println("StatCardGeneration:::::::::::generateStatCard");
		Date date = new Date();
		String[] today = date.toString().split(" ");
		String filepath = "statcards";
		String filename = loanAccountNo+"_stat_card_"+today[1]+"_"+today[2]+"_"+today[5]+".pdf";
		Document document = new Document();	
		try {
			PdfWriter.getInstance(document, new FileOutputStream(filepath + "\\" + filename));
		} catch (FileNotFoundException | DocumentException e1) {
			e1.printStackTrace();
		}
		String topSectionFields; 
		String overdueFields;

		if(fieldString.endsWith("#") && fieldString.startsWith("#")){
			topSectionFields = "";
			overdueFields = "";
		}else if(fieldString.startsWith("#")) {
			topSectionFields = "";
			overdueFields = fieldString.substring(1, fieldString.length());
		}else if(fieldString.endsWith("#")){
			topSectionFields = fieldString.substring(0, fieldString.length()-1);
			overdueFields = "";
		}else {
			topSectionFields = fieldString.split("#")[0];
			overdueFields = fieldString.split("#")[1];
		}
		
		if(!topSectionFields.equalsIgnoreCase("")) {
			String topSectionQuery = "select "+topSectionFields+" from ST_Coll_TopSection where cod_acct_no='"+loanAccountNo+"'";
			System.out.println(topSectionQuery);
			List<List<String>> topSectionRS = ifr.getDataFromDB(topSectionQuery);
			createFieldValueMap(topSectionFields.split(","), topSectionRS);
		}

		if(!overdueFields.equalsIgnoreCase("")) {
			String overdueQuery = "select "+overdueFields+" from ST_Coll_Loan_OverdueDetails where cod_acct_no='"+loanAccountNo+"'";
			System.out.println(overdueQuery);
			List<List<String>> overdueRS = ifr.getDataFromDB(overdueQuery);
			createFieldValueMap(overdueFields.split(","), overdueRS);
		}

		document.open();
		addContent(topSectionFields.split(","), overdueFields.split(","), document);
		System.out.println("Stat Card Successfully Generated for "+ifr.getControlValue("Loan_Account_No").toString()+"...");
		return filename;
	}

	private void createFieldValueMap(String[] fieldsIds, List<List<String>> fieldValues) {							                              
		System.out.println("StatCardGeneration:::::::::::createFieldValueMap");
		for(int i=0; i<fieldsIds.length; i++) {
			if(!fieldValueMap.containsKey(fieldsIds[i])) {
				fieldValueMap.put(fieldsIds[i], fieldValues.get(0).get(i));
			}
		}
	}

	private void addMetaData(IFormReference ifr, Document document) {
		System.out.println("StatCardGeneration:::::::::::addMetaData");
		document.addTitle("Customer Stat Card");
		document.addAuthor(ifr.getUserName());
		document.addSubject(ifr.getControlValue("Loan_Account_No").toString()+" Stat Card");		
	}
	
	private void addContent(String[] topSectionFields, String[] overdueFields, Document document) {
		System.out.println("StatCardGeneration:::::::::::addContent");
		Font headerFont = new Font(FontFamily.HELVETICA, 18, Font.BOLD);
		Font labelFont = new Font(FontFamily.HELVETICA, 12, Font.BOLD);
		Font valueFont = new Font(FontFamily.COURIER, 12);
		Paragraph header = new Paragraph();
		header.setAlignment(Element.ALIGN_CENTER);		
		header.setFont(headerFont);
		header.add("ABC Bank");		
		try {
			document.add(header);
		} catch (DocumentException e1) {
			e1.printStackTrace();
		}
		PdfPTable table = new PdfPTable(2);
		table.setSpacingBefore(20);
		PdfPCell cell = null;
		for(int i=0; i<topSectionFields.length; i++) {
			if(fieldLabelMap.containsKey(topSectionFields[i]))
			{
				cell=new PdfPCell(new Paragraph(fieldLabelMap.get(topSectionFields[i]), labelFont));
				table.addCell(cell);			
				cell=new PdfPCell(new Paragraph(fieldValueMap.get(topSectionFields[i]), valueFont));
				table.addCell(cell);
			}
		}
		for(int i=0; i<overdueFields.length; i++) {
			if(fieldLabelMap.containsKey(overdueFields[i]))
			{
				cell=new PdfPCell(new Paragraph(fieldLabelMap.get(overdueFields[i]), labelFont));
				table.addCell(cell);
				cell=new PdfPCell(new Paragraph(fieldValueMap.get(overdueFields[i]), valueFont));
				table.addCell(cell);
			}
		}
		try {
			document.add(table);
		} catch (DocumentException e) {
			e.printStackTrace();
		}
        document.close();
	}
}
