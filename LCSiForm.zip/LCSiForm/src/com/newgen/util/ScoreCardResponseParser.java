package com.newgen.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class ScoreCardResponseParser {

	public Document parseXmlFile(String in) {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputSource is = new InputSource(new StringReader(in));
			return db.parse(is);
		} catch (IOException | ParserConfigurationException | SAXException e) {
			throw new RuntimeException(e);
		}
	}
	
	public String formatXML(String unformattedXml) {
		try {
			Document document = parseXmlFile(unformattedXml);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			transformerFactory.setAttribute("indent-number", 3);
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(document);
			StreamResult xmlOutput = new StreamResult(new StringWriter());
			transformer.transform(source, xmlOutput);
			return xmlOutput.getWriter().toString();
		} catch (TransformerException e) {
			throw new RuntimeException(e);
		}
    }
	
	public HashMap parseResponse(InputStream response) {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		HashMap scores = new HashMap();
		try {
			DocumentBuilder db = dbFactory.newDocumentBuilder();
			Document doc = db.parse(response);
			doc.getDocumentElement().normalize();
			NodeList nlist = doc.getElementsByTagName("outobj");
			for(int i=0; i<nlist.getLength(); i++) {
				Node node = nlist.item(i);
				if(node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;
					scores.put("qBehavioralScorecard_BrokenPromise", element.getElementsByTagName("brokenpromise").item(0).getTextContent());
					scores.put("qBehavioralScorecard_ChequeBounce", element.getElementsByTagName("chequebounce").item(0).getTextContent());
					scores.put("qBehavioralScorecard_ComplaintAgainstCustomer", element.getElementsByTagName("complaintagainstcustome").item(0).getTextContent());
					scores.put("qBehavioralScorecard_CustomerNoResponse", element.getElementsByTagName("customernoresponse").item(0).getTextContent());
					scores.put("qBehavioralScorecard_DoorClosed", element.getElementsByTagName("doorclosed").item(0).getTextContent());
					scores.put("qBehavioralScorecard_RefuseToPay", element.getElementsByTagName("initiaterepossessionpro").item(0).getTextContent());
					scores.put("qBehavioralScorecard_LegalActionInitiation", element.getElementsByTagName("legalactioninitiation").item(0).getTextContent());
					scores.put("qBehavioralScorecard_MeetingRequest", element.getElementsByTagName("meetingrequest").item(0).getTextContent());
					scores.put("qBehavioralScorecard_PromisetoPay", element.getElementsByTagName("promisetopay").item(0).getTextContent());
					scores.put("qBehavioralScorecard_InitiateRepossessionProcess", element.getElementsByTagName("refusetopay").item(0).getTextContent());
				}
			}
		} catch (Exception e) {
//			e.printStackTrace();
		}
		return scores;	
	}

	/*public static void main(String[] args) {
		HashMap scores = new ScoreCardResponseParser().parseResponse();
		System.out.println(scores);
	}*/
}
