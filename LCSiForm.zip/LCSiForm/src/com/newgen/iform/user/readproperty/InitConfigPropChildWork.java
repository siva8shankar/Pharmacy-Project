package com.newgen.iform.user.readproperty;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.user.collection.CollectionCommonMethod;

public class InitConfigPropChildWork {
	static private Properties propChild = new Properties();
	private static IFormReference ifr = null;
	static CollectionCommonMethod cm = new CollectionCommonMethod(ifr);
	static {
		try {
			String directory = System.getProperty("user.dir");
			directory = directory + File.separator + "LCS_Config" + File.separator + "LCS.properties";
			File confFile = new File(directory);
			if (!confFile.exists()) {
				System.out.println("File Not Found");
				throw new Exception("File not found");
			}
			FileInputStream fis = new FileInputStream(confFile);
			propChild.load(fis);

		} catch (Exception ex) {
//			ex.printStackTrace();
//			throw new ExceptionInInitializerError("Error in reading conf.properties file. ");
			cm.mErrLogger.info("Error in InitConfigPropChildWork-->" + ex.getMessage());
		}
	}

	public String getProperty(String key) throws Exception {
		String val = null;
		val = propChild.getProperty(key);
		if (val == null) {
			throw new Exception("No value found for Key:" + key.toLowerCase().trim());
		} else {
			return val;
		}

	}

	public String serverIP() {
		InitConfigPropChildWork initConfigPropChildWork = new InitConfigPropChildWork();
		String strValues = "";
		String x = null;
		try {
			strValues = initConfigPropChildWork.getProperty("strJtsIP");

		} catch (Exception e) {
			cm.mErrLogger.info("Error in serverIP-->" + e.getMessage());
		}
		return strValues;

	}

	public int serverport() {
		InitConfigPropChildWork initConfigPropChildWork = new InitConfigPropChildWork();
		int strValues = 0;
		String x = null;
		try {
			strValues = Integer.parseInt(initConfigPropChildWork.getProperty("sJbossPort"));

		} catch (Exception e) {
//			e.printStackTrace();
			cm.mErrLogger.info("Error in serverport-->" + e.getMessage());
		}
		return strValues;

	}

	public int wrapperPort() {
		InitConfigPropChildWork initConfigPropChildWork = new InitConfigPropChildWork();
		int strValues = 0;
		String x = null;
		try {

			strValues = Integer.parseInt(initConfigPropChildWork.getProperty("wrapperPort"));

		} catch (Exception e) {
//			e.printStackTrace();
			cm.mErrLogger.info("Error in wrapperPort-->" + e.getMessage());
		}
		return strValues;

	}

}
